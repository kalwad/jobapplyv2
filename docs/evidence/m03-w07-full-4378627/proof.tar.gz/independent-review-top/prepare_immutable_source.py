"""Read-only fixed Git object bodies and separate working-tree/runtime pins."""
from pathlib import Path
from datetime import UTC, datetime
import hashlib,json,os,stat,subprocess,time
H=Path(__file__).resolve().parent
R=Path('/Users/tanishkalwad/jobapplyv2')
COMMIT='4378627d13317f4488f1e8c5d9264cb5b85b853d'
TREE='7cf263603d40f8ec823e951febe5eba1dd4f07e0'
env={**os.environ,'GIT_OPTIONAL_LOCKS':'0','PYTHONDONTWRITEBYTECODE':'1'}
base=['git','--no-optional-locks','-c','core.fsmonitor=false','-C',str(R)]
receipts=[]
def group(pid):
    try:os.killpg(pid,0);return 'PRESENT'
    except ProcessLookupError:return 'ABSENT'
def run(args):
    child=subprocess.Popen(base+args,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    out,err=child.communicate(timeout=30)
    row={'argv':base+args,'pid':child.pid,'pgid':child.pid,'reaped':child.returncode is not None,'exit_code':child.returncode,'group_after_wait':group(child.pid),'signals':[],'stderr_bytes':len(err)}
    receipts.append(row)
    assert row['exit_code']==0 and row['reaped'] and row['group_after_wait']=='ABSENT' and not err,row
    return out
started=time.monotonic()
raw=run(['ls-tree','-r','-z',COMMIT]);(H/'git-ls-tree.raw').write_bytes(raw)
entries=[]
for line in raw.split(b'\0'):
    if not line:continue
    head,name=line.split(b'\t',1);mode,kind,oid=head.split(b' ')
    assert kind==b'blob' and mode in (b'100644',b'100755')
    name=name.decode('utf-8');assert not Path(name).is_absolute() and '..' not in Path(name).parts
    entries.append((name,mode.decode(),oid.decode()))
assert len(entries)==2364 and len({n for n,_,_ in entries})==2364
child=subprocess.Popen(base+['cat-file','--batch'],env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
assert child.stdin and child.stdout and child.stderr
total=0
def object_body(oid,kind,retain=False):
    global total
    assert time.monotonic()-started<55
    child.stdin.write((oid+'\n').encode());child.stdin.flush()
    header=child.stdout.readline(256);parts=header.rstrip(b'\n').split(b' ')
    assert len(parts)==3 and parts[0].decode()==oid and parts[1].decode()==kind
    size=int(parts[2]);assert 0<=size<=256*1024*1024
    total+=size;assert total<=2*1024*1024*1024
    framed=hashlib.sha1((kind+' '+str(size)).encode()+b'\0');sha=hashlib.sha256();left=size;chunks=[]
    while left:
        piece=child.stdout.read(min(left,1024*1024));assert piece
        left-=len(piece);framed.update(piece);sha.update(piece)
        if retain:chunks.append(piece)
    assert child.stdout.read(1)==b'\n' and framed.hexdigest()==oid
    return size,sha.hexdigest(),b''.join(chunks)
_,_,commitbody=object_body(COMMIT,'commit',True)
assert commitbody.splitlines()[0]==('tree '+TREE).encode()
files={}
for name,mode,oid in entries:
    retain=name=='scripts/python-test-inventory.v1.json'
    size,sha,body=object_body(oid,'blob',retain)
    files[name]={'bytes':size,'sha256':sha,'git_blob':oid,'git_mode':mode,'full_mode':stat.S_IFREG|(0o755 if mode=='100755' else 0o644)}
    if retain:(H/'immutable-python-test-inventory.v1.json').write_bytes(body)
child.stdin.close();code=child.wait(timeout=10);err=child.stderr.read();assert not err
custody={'pid':child.pid,'pgid':child.pid,'reaped':child.returncode is not None,'exit_code':code,'group_after_wait':group(child.pid),'signals':[],'ended_utc':datetime.now(UTC).isoformat()}
assert custody['reaped'] and code==0 and custody['group_after_wait']=='ABSENT'
source={'scope':'Exact immutable fixed-commit Git blob bodies with SHA1 framing, size, SHA256 and encoded regular/executable Git classes; not arbitrary OS permission modes or a working-tree snapshot. Read-only Git optional locks disabled.','git_batch_custody':custody,'commit':COMMIT,'tree':TREE,'blob_count':len(files),'seconds':time.monotonic()-started,'all_git_blob_SHA1_framings_verified':True,'commit_object_SHA1_framing_verified':True,'files':files}
(H/'immutable-git-source-sha256.json').write_text(json.dumps(source,indent=2)+'\n')
def disk(p):
    s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink();b=p.read_bytes()
    return {'bytes':len(b),'full_mode':s.st_mode,'sha256':hashlib.sha256(b).hexdigest()}
working={}
for name,pin in files.items():
    row=disk(R/name);assert row['bytes']==pin['bytes'] and row['sha256']==pin['sha256'];assert bool(row['full_mode']&0o111)==(pin['git_mode']=='100755');working[name]=row
runtime={p.relative_to(R).as_posix():disk(p) for p in sorted((R/'apps/desktop/src-tauri/runtime-payload').rglob('*')) if p.is_file()}
assert len(runtime)==40
head=run(['rev-parse','HEAD']).decode().strip();tree=run(['rev-parse','HEAD^{tree}']).decode().strip();status=run(['status','--porcelain','--untracked-files=all']).decode()
assert head==COMMIT and tree==TREE and status==''
index=R/'.git/index';indexpin=disk(index) if index.is_file() else None
snapshot={'utc':datetime.now(UTC).isoformat(),'source':working,'runtime':runtime,'head':head,'tree':tree,'status':status,'index':indexpin,'scope':'Finite initial physical source/runtime/HEAD/tree/status and optional index content pin during root freeze; separate from immutable Git-class modes and no full verdict.'}
(H/'initial-source-runtime.json').write_text(json.dumps(snapshot,indent=2)+'\n');(H/'git-read-closures.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(json.dumps({'map_path':str(H/'immutable-git-source-sha256.json'),'map_sha256':hashlib.sha256((H/'immutable-git-source-sha256.json').read_bytes()).hexdigest(),'catalog_path':str(H/'immutable-python-test-inventory.v1.json'),'catalog_sha256':hashlib.sha256((H/'immutable-python-test-inventory.v1.json').read_bytes()).hexdigest(),'blob_count':len(files),'runtime':len(runtime),'git_batch_custody':custody,'other_read_children':len(receipts),'bytes_framed':total}))
