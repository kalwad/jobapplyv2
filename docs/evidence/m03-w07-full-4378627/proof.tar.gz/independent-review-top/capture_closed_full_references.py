"""Prepare immutable reviewer copies only after actual root full closure."""
from pathlib import Path
import hashlib
import json
import stat

H = Path(__file__).resolve().parent
E = H.parents[1]
F = E / 'full-4378627'
assert (F / 'closure.json').is_file(), 'Actual full closure required'
rows = {}
def copy(source, target):
    s = source.lstat()
    assert stat.S_ISREG(s.st_mode) and not source.is_symlink()
    b = source.read_bytes()
    if target.exists():
        assert target.read_bytes() == b and target.lstat().st_mode == s.st_mode
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(b)
        target.chmod(stat.S_IMODE(s.st_mode))
    assert source.read_bytes() == b and source.lstat().st_mode == s.st_mode
    name = target.relative_to(H).as_posix()
    row = {'path': name, 'origin': str(source), 'bytes': len(b), 'full_mode': s.st_mode, 'sha256': hashlib.sha256(b).hexdigest()}
    assert name not in rows or rows[name] == row
    rows[name] = row
for record_file in ('initial-reference-source-pins.json', 'initial-root-reference-pins.json', 'root-visual-reference-pins.json'):
    for record in json.loads((H / record_file).read_bytes()):
        source, target = Path(record['origin']), H / record['path']
        copy(source, target)
        assert {key: rows[record['path']][key] for key in ('bytes', 'full_mode', 'sha256')} == {key: record[key] for key in ('bytes', 'full_mode', 'sha256')}
original = json.loads((H / 'original-wrapper-pin.json').read_bytes())
copy(Path(original['origin']), H / original['path'])
for name in ('before.json', 'after.json', 'closure.json', 'context.json', 'end-context.json', 'results.json', 'doctor.log', 'verify.log', 'wrapper-executed.py', 'retention-observer-executed.py'):
    copy(F / name, H / 'reference/full' / name)
(H / 'copied-members.json').write_text(json.dumps(list(rows.values()), indent=2)+'\n')
print(json.dumps({'copied_closed_regular_files': len(rows), 'body_mode_origin_endpoints_equal': True}))
