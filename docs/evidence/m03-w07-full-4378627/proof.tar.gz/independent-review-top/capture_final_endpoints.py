"""Read-only physical endpoints after actual full closure; no subject execution."""
from pathlib import Path
from datetime import UTC,datetime
import hashlib,json,os,stat,subprocess
H=Path(__file__).resolve().parent;R=Path('/Users/tanishkalwad/jobapplyv2')
mapping=json.loads((H/'immutable-git-source-sha256.json').read_text());initial=json.loads((H/'initial-source-runtime.json').read_text())
def disk(p):
    s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink();b=p.read_bytes();return {'bytes':len(b),'full_mode':s.st_mode,'sha256':hashlib.sha256(b).hexdigest()}
source={n:disk(R/n) for n in mapping['files']}
runtime={p.relative_to(R).as_posix():disk(p) for p in sorted((R/'apps/desktop/src-tauri/runtime-payload').rglob('*')) if p.is_file()}
receipts=[]
def git(*args):
    argv=['git','--no-optional-locks','-c','core.fsmonitor=false','-C',str(R),*args]
    p=subprocess.Popen(argv,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'},stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);out,err=p.communicate(timeout=20)
    try:os.killpg(p.pid,0);group='PRESENT'
    except ProcessLookupError:group='ABSENT'
    receipt={'argv':argv,'pid':p.pid,'pgid':p.pid,'reaped':p.returncode is not None,'exit_code':p.returncode,'group_after_wait':group,'signals':[]};receipts.append(receipt)
    assert p.returncode==0 and not err and group=='ABSENT';return out.decode().strip()
head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}');status=git('status','--porcelain','--untracked-files=all')
assert source==initial['source'] and runtime==initial['runtime'] and len(source)==2364 and len(runtime)==40 and head==mapping['commit'] and tree==mapping['tree'] and status==''
index=R/'.git/index';indexpin=disk(index) if index.is_file() else None
out={'utc':datetime.now(UTC).isoformat(),'source':source,'runtime':runtime,'head':head,'tree':tree,'status':status,'index':indexpin,'source_runtime_HEAD_tree_status_equal_initial':True,'index_content_pin_equal_initial':indexpin==initial['index'],'scope':'Finite endpoint observation, not proof of no transient writes or future canonical state.'}
(H/'final-source-runtime.json').write_text(json.dumps(out,indent=2)+'\n');(H/'final-git-read-closures.json').write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ('source','runtime','index')}))
