"""Review actual closed full evidence; outcome is parsed, never assumed."""
from pathlib import Path
import ast
import hashlib
import json
import re
import stat

H = Path(__file__).resolve().parent
checks = []
def read(name):
    return json.loads((H / name).read_bytes())
def check(name, value):
    checks.append({'name': name, 'pass': bool(value)})
    assert value, name
def pin(path):
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode) and not path.is_symlink()
    body = path.read_bytes()
    return {'bytes': len(body), 'full_mode': s.st_mode, 'sha256': hashlib.sha256(body).hexdigest()}

mapping = read('immutable-git-source-sha256.json')
initial = read('initial-source-runtime.json')
final = read('final-source-runtime.json')
check('immutable map exact separate new source', pin(H / 'immutable-git-source-sha256.json')['sha256'] == 'fdc4904daf5ab550e7cc5373c95d354447f50477574cd19d4ddb80f53dc4ade0' and mapping['commit'] == '4378627d13317f4488f1e8c5d9264cb5b85b853d' and mapping['tree'] == '7cf263603d40f8ec823e951febe5eba1dd4f07e0' and mapping['blob_count'] == len(mapping['files']) == 2364 and sum(r['bytes'] for r in mapping['files'].values()) == 664848279 and mapping['all_git_blob_SHA1_framings_verified'])
for name, expected in mapping['files'].items():
    row = initial['source'][name]
    check('initial physical source versus immutable:' + name, row['bytes'] == expected['bytes'] and row['sha256'] == expected['sha256'] and bool(row['full_mode'] & 0o111) == (expected['git_mode'] == '100755'))
check('own finite source runtime Git endpoints equal', initial['source'] == final['source'] and initial['runtime'] == final['runtime'] and len(final['runtime']) == 40 and initial['head'] == final['head'] == mapping['commit'] and initial['tree'] == final['tree'] == mapping['tree'] and initial['status'] == final['status'] == '')
check('own optional index content endpoints equal', initial['index'] == final['index'] and final['index_content_pin_equal_initial'])
git_receipts = read('git-read-closures.json') + [mapping['git_batch_custody']] + read('final-git-read-closures.json')
check('eight finite own read-only Git children', len(git_receipts) == 8)
for row in git_receipts:
    check('own Git custody:' + str(row['pid']), row['reaped'] and row['exit_code'] == 0 and row['group_after_wait'] == 'ABSENT' and row['signals'] == [])
for row in read('copied-members.json'):
    expected = {k: row[k] for k in ('bytes', 'full_mode', 'sha256')}
    check('retained body/fullmode:' + row['path'], pin(H / row['path']) == expected)
    check('retained closed origin endpoint:' + row['path'], pin(Path(row['origin'])) == expected)

before = read('reference/full/before.json')
after = read('reference/full/after.json')
closure = read('reference/full/closure.json')
context = read('reference/full/context.json')
end = read('reference/full/end-context.json')
stages = read('reference/full/results.json')
check('root full source runtime snapshots equal', before == after and len(before['source']) == 2364 and len(before['runtime']) == 40 and before['git_status'] == '')
for name, row in before['source'].items():
    check('root physical source versus different snapshot:' + name, {k: row[k] for k in ('bytes', 'full_mode', 'sha256')} == initial['source'][name] and row['mode'] == stat.S_IMODE(row['full_mode']))
root_runtime = {'apps/desktop/src-tauri/runtime-payload/' + name: {k: row[k] for k in ('bytes', 'full_mode', 'sha256')} for name, row in before['runtime'].items()}
check('root runtime versus different snapshot', root_runtime == initial['runtime'])
check('root immediate fixed commit/tree endpoints equal', context['commit'] == end['commit'] == mapping['commit'] and context['tree'] == end['tree'] == mapping['tree'])
check('two actual stages retained in order', len(stages) == 2 and [r['name'] for r in stages] == ['doctor', 'verify'])
for row in stages:
    check('root stage owned closure:' + row['name'], row['direct_child_reaped'] and row['observed_group'] == 'ABSENT' and not row['timeout'] and not row['outer_cleanup_signals'])
check('root closure endpoint statements exact', closure['source_count'] == 2364 and closure['runtime_count'] == 40 and closure['source_bytes_modes_unchanged'] and closure['runtime_bytes_modes_unchanged'] and closure['commit_and_tree_equal_at_end_observation'] and closure['git_status_before'] == closure['git_status_after'] == '')
check('root outcome truthfulness versus exit codes', closure['all_commands_exit_zero'] == all(r['exit_code'] == 0 for r in stages))
check('executed full wrapper exact retained original', (H / 'reference/full/wrapper-executed.py').read_bytes() == (H / 'reference/original-full-wrapper.py').read_bytes())

log = (H / 'reference/full/verify.log').read_text()
registry = read('reference/source/scripts/verification-suites.json')
tail = log[log.rfind('== verification summary =='):] if '== verification summary ==' in log else ''
actual = {m.group(1): m.group(2) for m in re.finditer(r'(?m)^([^\s]+)[ \t]+ACTIVE[ \t]+(PASS|FAIL)[ \t]*', tail)}
check('actual completed registry summary', len(actual) == 20 and set(actual) == {suite['id'] for suite in registry['suites']})
check('actual printed aggregate exit matches owned stage', f'verification exit code: {stages[1]["exit_code"]}' in tail)
failed_ids = re.findall(r'(?m)^FAILED (.+)$', log)
python_summaries = re.findall(r'(?m)^=+ (?:(\d+) failed, )?(\d+) passed in ([0-9.]+)s(?: \([^\r\n]+\))? =+$', log)
check('one actual terminal Python summary', len(python_summaries) == 1)
python_failed = int(python_summaries[0][0] or '0')
python_passed = int(python_summaries[0][1])
python_seconds = float(python_summaries[0][2])
catalog = read('immutable-python-test-inventory.v1.json')
check('exact catalog and actual Python total', len(catalog['common']['node_ids']) == 2815 and len(catalog['posix_only_node_ids']) == 2 and python_failed + python_passed == 2817)
check('exact failed-ID count matches terminal summary', len(failed_ids) == python_failed)
check('Python summary agrees component outcome', actual['python'] == ('FAIL' if python_failed else 'PASS'))
for name in ('scripts/tests/test_ubuntu_gnome_boundaries.py', 'scripts/linux_gnome/ubuntu_gnome_guest.py', 'scripts/verification-suites.json'):
    expected = mapping['files'][name]
    row = pin(H / 'reference/source' / name)
    check('selected source body exact:' + name, row['bytes'] == expected['bytes'] and row['sha256'] == expected['sha256'])
guest = ast.parse((H / 'reference/source/scripts/linux_gnome/ubuntu_gnome_guest.py').read_text())
augmented = [node for node in guest.body if isinstance(node, ast.AugAssign) and isinstance(node.target, ast.Name) and node.target.id == 'OPERATIONS']
expected_finish_assignment = ast.parse('OPERATIONS = OPERATIONS[:-1] + SHELL_OPERATIONS + OPERATIONS[-1:]').body[0]
finish_assignments = [node for node in guest.body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'OPERATIONS' for target in node.targets)]
check('source-preserved terminal finish construction', len(augmented) == 0 and len(finish_assignments) == 1 and ast.dump(finish_assignments[0], include_attributes=False) == ast.dump(expected_finish_assignment, include_attributes=False))

visual = read('visual-review.json')
retention = read('visual-retention.json')
root_visual = read('reference/root-retained-visual/retention.json')
check('actual all19 visual inspection and source joins', visual['result']['checks'] == 419 and all(row['pass'] for row in visual['checks']) and visual['result']['capture_png_paths_inspected'] == 19 and all(row['entire_capture_visually_inspected'] and row['finding'] is None for row in visual['visual_inspection']))
marker = re.search(r'(?m)^[ \t]*17 passed \([^\r\n]+\)[ \t]*$', log)
check('anchored actual visual17 then Python markers', marker is not None and log.find('$ uv run pytest -c pyproject.toml', marker.end()) >= 0 and retention['actual_visual17_and_Python_start_seen'])
own = {row['path']: row for row in retention['all_original_files']}
root = {row['path']: {k: row[k] for k in ('path', 'bytes', 'full_mode', 'sha256')} for row in root_visual['all_original_files']}
check('different and root complete visual inventory join', own == root and len(own) == 67 and root_visual['selected_count'] == 33 and root_visual['png'] == 19 and root_visual['metadata'] == 14 and root_visual['excluded_attachment_aliases_are_exact_duplicate_bodies'])
check('retained root visual observer source digest exact', hashlib.sha256((H / 'reference/full/retention-observer-executed.py').read_bytes()).hexdigest() == root_visual['executed_observer_sha256'])
visual_receipts = sorted((H / 'qa').glob('visual-observe-*/receipt.json'))
check('own bounded visual observers all closed', bool(visual_receipts))
for path in visual_receipts:
    row = json.loads(path.read_bytes())
    check('visual observer custody:' + path.parent.name, row['reaped'] and row['exit_code'] == 0 and row['group_after_wait'] == 'ABSENT' and row['signals'] == [] and not row['timeout'] and row['immutable_source_map_equal'])
all_pass = all(row['exit_code'] == 0 for row in stages) and all(value == 'PASS' for value in actual.values()) and python_failed == 0
result = {'verdict': 'CLEAR_FINITE_ACTUAL_LOCAL_FULL_PASS' if all_pass else 'CONFIRMED_ACTUAL_LOCAL_FULL_FAILURE', 'data_joins': len(checks), 'all_record_consistency_checks_pass': True, 'commit': mapping['commit'], 'tree': mapping['tree'], 'source_files': 2364, 'source_blob_payload_bytes': 664848279, 'runtime_files': 40, 'actual_stage_exits': {r['name']: r['exit_code'] for r in stages}, 'actual_active_suites': actual, 'actual_python_failed': python_failed, 'actual_python_passed': python_passed, 'actual_python_seconds': python_seconds, 'failed_ids': failed_ids, 'source_runtime_Git_and_optional_index_endpoints_equal': True, 'all67visual_files_retained': True, 'all19PNG_paths_inspected': True, 'aggregate_summary_is_individual_passing_ID_proof': False, 'CI_or_native_platform_or_model_or_gate_or_release_credit': False, 'scope': 'Finite actual local full on fixed new source, no substitution for original failed374 local/CI records or later source/platform/model qualification.'}
(H / 'data-review.json').write_text(json.dumps({'result': result, 'checks': checks}, indent=2)+'\n')
print(json.dumps(result, indent=2))
