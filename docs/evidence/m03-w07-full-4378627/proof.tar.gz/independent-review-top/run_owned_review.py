"""Own and reap one bounded inert data-review helper, never product code."""
from pathlib import Path
from datetime import UTC, datetime
import hashlib
import json
import os
import subprocess
import sys
import time

H = Path(__file__).resolve().parent
label, name = sys.argv[1:]
assert label.isascii() and label.replace('-', '').isalnum()
assert name in ('audit_visual.py', 'audit_closed_full.py', 'capture_final_endpoints.py')
folder = H / 'qa' / label
folder.mkdir(parents=True, exist_ok=False)
def lease():
    return {p.name: {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'full_mode': p.lstat().st_mode} for p in (H / name, H / 'immutable-git-source-sha256.json', H / 'immutable-python-test-inventory.v1.json')}
before = lease()
args = ['/Users/tanishkalwad/.local/share/uv/python/cpython-3.12.13-macos-aarch64-none/bin/python3.12', '-I', '-S', '-B', str(H / name)]
start = datetime.now(UTC).isoformat()
clock = time.monotonic()
with (folder / 'stdout.log').open('wb') as out, (folder / 'stderr.log').open('wb') as err:
    child = subprocess.Popen(args, cwd=H, stdin=subprocess.DEVNULL, stdout=out, stderr=err, start_new_session=True)
    code = child.wait(timeout=55)
try:
    os.killpg(child.pid, 0)
except ProcessLookupError:
    group = 'ABSENT'
else:
    group = 'PRESENT'
after = lease()
row = {'argv': args, 'pid': child.pid, 'pgid': child.pid, 'reaped': child.returncode is not None, 'exit_code': code, 'group_after_wait': group, 'signals': [], 'timeouts': [], 'start_utc': start, 'end_utc': datetime.now(UTC).isoformat(), 'seconds': time.monotonic()-clock, 'leased_inputs_before': before, 'leased_inputs_after': after, 'leased_inputs_equal': before == after, 'scope': 'Bounded inert own reviewer helper; source/data/hash/AST reads only, no subject import/tests/browser/native/model/network.'}
(folder / 'receipt.json').write_text(json.dumps(row, indent=2)+'\n')
print(json.dumps({k: row[k] for k in ('pid', 'exit_code', 'reaped', 'group_after_wait', 'seconds', 'leased_inputs_equal')}))
assert child.returncode is not None and group == 'ABSENT' and before == after
raise SystemExit(code)
