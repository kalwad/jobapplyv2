"""Independent immutable-source/full-run data audit; no product execution."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import stat
import subprocess
import tarfile

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
BASE = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/full-35b4628')
OUT = BASE.parent / 'full-35b4628-independent-review'
PROPOSAL = BASE.parent / 'full-35b4628-metadata-proposal'
OUT.mkdir(exist_ok=True)
PROPOSAL.mkdir(exist_ok=True)
checks = []
def sha(raw): return hashlib.sha256(raw).hexdigest()
def load(name): return json.loads((BASE / name).read_bytes())
def dump(value): return (json.dumps(value, indent=2) + '\n').encode()
def put(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    assert path.read_bytes() == raw
def check(name, valid):
    checks.append({'name': name, 'pass': bool(valid)})
    assert valid, name

context, before, after, closure, results = [load(n) for n in ['context.json', 'before.json', 'after.json', 'closure.json', 'results.json']]
commit = '35b46287dc754a5987d653490ab49f978647ca26'
tree = 'f0789de7f5c82f6931eebe489110fcb771130724'
check('exact35b context', context['commit'] == commit and context['tree'] == tree)
git_tree = subprocess.check_output(['git', 'rev-parse', commit + '^{tree}'], cwd=ROOT, text=True).strip()
check('immutable Git object tree matches context', git_tree == tree)
raw_git = subprocess.check_output(['git', 'archive', '--format=tar', commit], cwd=ROOT)
with tarfile.open(fileobj=io.BytesIO(raw_git)) as archive:
    git_files = {}
    git_content = {}
    for member in archive.getmembers():
        if member.isdir(): continue
        check('immutable regular Git member ' + member.name, member.isfile())
        raw = archive.extractfile(member).read()
        git_files[member.name] = {'bytes': len(raw), 'git_mode': '100755' if member.mode & 0o111 else '100644', 'sha256': sha(raw)}
        if member.name in ['scripts/python-test-inventory.v1.json', 'scripts/verification-suites.json', 'scripts/verify.py']:
            git_content[member.name] = raw
check('1998 exact immutable Git bytes sizes and executable bits', len(git_files) == len(before['source']) == 1998 and set(git_files) == set(before['source']) and all(row['bytes'] == before['source'][name]['bytes'] and row['sha256'] == before['source'][name]['sha256'] and (row['git_mode'] == '100755') == bool(before['source'][name]['mode'] & 0o111) for name, row in git_files.items()))
check('all1998 source full permission-mode endpoints equal', before['source'] == after['source'])
check('all40 runtime endpoint bytes/modes equal', len(before['runtime']) == 40 and before['runtime'] == after['runtime'])
check('both source snapshots clean', before['git_status'] == after['git_status'] == '')
check('closure counters and observed neutrality agree', closure['source_count'] == 1998 and closure['runtime_count'] == 40 and closure['source_bytes_modes_unchanged'] and closure['runtime_bytes_modes_unchanged'] and closure['git_status_before'] == closure['git_status_after'] == '' and closure['all_commands_exit_zero'])
check('exact doctor and no-argument full commands', [r['name'] for r in results] == ['doctor', 'verify'] and [r['argv'] for r in results] == [['pnpm', 'run', 'doctor'], ['pnpm', 'verify']])
for row in results:
    check('actual command exit0/no timeout ' + row['name'], row['exit_code'] == 0 and not row['timeout'])
    check('actual direct reap/observed group absence/no cleanup signals ' + row['name'], row['direct_child_reaped'] and row['observed_group'] == 'ABSENT' and row['outer_cleanup_signals'] == [])
check('actual measured command durations', 7 < results[0]['seconds'] < 8 and 1170 < results[1]['seconds'] < 1171)
doctor = (BASE / 'doctor.log').read_text()
verify = (BASE / 'verify.log').read_text()
lines = verify.splitlines()
check('doctor28PASS zero warning/fail', doctor.endswith('summary: 28 pass, 0 warning, 0 fail, 0 not-yet-applicable\n'))
check('doctor exact source status and45checks', 'Working tree state                              PASS               clean' in doctor and 'PASS: all checks passed (45 check groups)' in doctor)
check('doctor recorded requested pinned toolchain', all(value in doctor for value in ['Node 24.18.0', 'pnpm 11.17.0', 'uv 0.11.32', 'Python 3.12.13', 'cargo 1.97.1', 'rustc 1.97.1', '@playwright/test 1.62.0']))
summary_text = verify.split('== verification summary ==\n')[-1]
suites = re.findall(r'^(\S+)\s+ACTIVE\s+PASS\s*$', summary_text, re.M)
expected_suites = ['toolchain', 'format', 'lint', 'typecheck', 'unit-ts', 'contract-gen', 'fixture-corpus', 'evaluation-corpus', 'contract', 'build', 'e2e-browser', 'w14-public-controlled', 'w14-public-contact-controlled', 'visual', 'python', 'rust', 'portability', 'traceability', 'status', 'integrity']
check('all20 exact ACTIVE suites ordinary PASS', suites == expected_suites)
check('inner no-argument verification finalexit0', verify.startswith('$ uv run python scripts/verify.py\n') and verify.endswith('verification exit code: 0\n'))
unit_start = next(i for i, line in enumerate(lines) if line == '$ pnpm exec turbo run test --force -- --reporter=default')
unit_end = next(i for i, line in enumerate(lines) if i > unit_start and line == '$ pnpm generate:contracts --check')
ts_counts = [int(match[1]) for line in lines[unit_start:unit_end] if (match := re.search(r'Tests\s+(\d+) passed \(\d+\)', line))]
check('15 actual TypeScript package summaries total4006', len(ts_counts) == 15 and sum(ts_counts) == 4006)
browser_rows = [{'line': i + 1, 'text': line, 'count': int(match[1]), 'duration': match[2]} for i, line in enumerate(lines) if (match := re.fullmatch(r'\s+(\d+) passed \(([^)]+)\)', line))]
check('four actual browser executions262/2/62/3', [row['count'] for row in browser_rows] == [262, 2, 62, 3])
check('actual browser durations8.5m/1.6s/40s/5.3s', [row['duration'] for row in browser_rows] == ['8.5m', '1.6s', '40.0s', '5.3s'])
collect_start = next(i for i, line in enumerate(lines) if line.startswith('$ uv run pytest ') and '--collect-only -q' in line)
collect_end = next(i for i, line in enumerate(lines) if i > collect_start and line.startswith('$ '))
ids = [line for line in lines[collect_start + 1:collect_end] if line.startswith(('scripts/', 'services/')) and '::' in line]
inventory = json.loads(git_content['scripts/python-test-inventory.v1.json'])
expected_ids = inventory['common']['node_ids'] + inventory['posix_only_node_ids']
check('1860 unique actual canonical collection IDs equal immutable inventory', len(ids) == len(set(ids)) == 1860 and set(ids) == set(expected_ids) and len(expected_ids) == 1860)
check('1858common and2POSIX inventory scopes', inventory['common']['count'] == len(inventory['common']['node_ids']) == 1858 and len(inventory['posix_only_node_ids']) == 2)
python_summaries = [line for line in lines if re.fullmatch(r'=+ 1860 passed in 391\.37s \(0:06:31\) =+', line)]
check('exact ordinary1860PythonPASS391.37s once', len(python_summaries) == 1)
python_command = next(line for line in lines if line.startswith('$ uv run pytest ') and '--collect-only' not in line)
check('Python execution strict canonical module list/no plugin autoload', '--strict-markers --strict-config --disable-plugin-autoload' in python_command and ' -k ' not in python_command and ' -m ' not in python_command and ' --lf' not in python_command)
rust_test_commands = [line for line in lines if line.startswith('$ cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml')]
check('all3 registered desktop modes execute', rust_test_commands == ['$ cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml', '$ cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml --all-features', '$ cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml --features tauri/custom-protocol'])
rust_summary_rows = [{'line': i + 1, 'text': line} for i, line in enumerate(lines) if line.startswith('test result: ok. 234 passed;')]
check('234ordinary nativePASS each3 zero ignored/filtered', len(rust_summary_rows) == 3 and all('; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in row['text'] for row in rust_summary_rows))
native_ids = []
for command in rust_test_commands:
    start = lines.index(command)
    end = next(i for i in range(start + 1, len(lines)) if lines[i].startswith('test result: ok. 234 passed;'))
    selected = [match[1] for line in lines[start + 1:end] if (match := re.fullmatch(r'test (.+) \.\.\. ok', line))]
    check('234 exact unique successful cases ' + command, len(selected) == len(set(selected)) == 234)
    native_ids.append(selected)
check('same234 desktop names across3 modes', set(native_ids[0]) == set(native_ids[1]) == set(native_ids[2]))
check('native helper and contract harness1/10 PASS', 'test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in verify and 'test result: ok. 10 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in verify)
rust_start = next(i for i, line in enumerate(lines) if i > collect_end and line == '$ cargo fmt --manifest-path services/native-host/Cargo.toml --check')
rust_end = lines.index('$ python3 scripts/check_portability.py --quiet')
native_commands = [line[2:] for line in lines[rust_start:rust_end] if line.startswith('$ cargo ') or line == '$ pnpm --filter @japp/desktop build']
check('15 Rust/frontend commands through final build', len(native_commands) == 15 and native_commands[-1] == 'cargo build --locked --manifest-path apps/desktop/src-tauri/Cargo.toml')
integrity_start = lines.index('$ git ls-files')
integrity_end = lines.index('== verification summary ==')
listed = [line for line in lines[integrity_start + 1:integrity_end] if line]
check('integrity output lists exact1998 Git files', listed == sorted(git_files))
check('current measured runtime mode and manifest identity', before['runtime']['manifest.json']['sha256'] == 'c9049a3f63572c0de9b114700e9326bebc0518166840133cce9548565c58de1d' and before['runtime']['japp-orchestrator/japp-orchestrator']['mode'] == 0o755)
wrapper = (BASE / 'wrapper-executed.py').read_text()
check('wrapper records directwait/reap and read-only postreapgroupcheck', 'start_new_session=True' in wrapper and 'code = child.wait(timeout=budget)' in wrapper and 'os.killpg(child.pid, 0)' in wrapper and "'outer_cleanup_signals': signals" in wrapper)
selected_lines = [{'line': i + 1, 'text': line} for i, line in enumerate(lines) if line in python_summaries or line.startswith('test result: ok. 234 passed;') or re.fullmatch(r'\s+(262|2|62|3) passed \([^)]+\)', line)]
limits = ['This full observation evaluates immutable35b/f078 and1998tracked paths only; later FIFO corrections or other working-tree changes are not validated by it.', 'Snapshots establish matching before/after bytes and full modes, not an exhaustive history of intermediate filesystem mutations. Git binds file bytes/sizes and executable bits; it does not retain full POSIX permissions. The25 read-only0444 and1973 ordinary0644 source modes are snapshot observations.', 'Outer results record direct children reaped, observed groupsABSENT and zero cleanup signals. Numeric group IDs are not retained in results; unobserved escaped descendants are not proven absent.', 'The wrapper inherits the development environment with Node/Python PATH prefixes; it is not a clean-environment or packaged-GUI experiment.', 'Browser figures are four separate executions, not unique-case totals or performance certification. No new GUI, foreign package, live model or milestone acceptance follows.', 'Source-known FIFO guard correction and freshCI40782097996 remain pending separately. Prior failed runs remain separate and failed.']
summary = {'schema': 'M03_W06_IMMUTABLE35B_LOCAL_FULL_V1', 'head': commit, 'tree': tree, 'tracked_files': 1998, 'runtime_files': 40, 'source_before_after_equals_immutable_git': True, 'runtime_bytes_modes_before_after_equal': True, 'doctor': {'pass': 28, 'warning': 0, 'fail': 0, 'seconds': results[0]['seconds']}, 'verify': {'active_pass': 20, 'seconds': results[1]['seconds'], 'typescript': 4006, 'python': 1860, 'python_seconds': 391.37, 'desktop_native_per_mode': 234, 'desktop_modes': 3, 'browser': browser_rows}, 'root_execution_closure': results, 'selected_inner_rows': selected_lines, 'decision': 'CLEAR_SOURCE_BOUND_LOCAL_FULL_OBSERVATION', 'limits': limits, 'states': {'M03_W06': 'IN_PROGRESS', 'verified': 38, 'total': 300, 'M03': 'IN_PROGRESS', 'release': 'NOT_READY'}}
put(OUT / 'SUMMARY.json', dump(summary))
# Per-file equality is one complete1998-row join; keep the report compact.
regular_checks = [row for row in checks if not row['name'].startswith('immutable regular Git member ')]
put(OUT / 'CHECKS.json', dump({'decision': summary['decision'], 'explicit_check_count': len(regular_checks), 'regular_git_members_checked': 1998, 'checks': regular_checks, 'git_snapshot': git_files, 'collected_python_ids_sha256': sha(('\n'.join(ids) + '\n').encode()), 'native_mode_name_sha256s': [sha(('\n'.join(sorted(rows)) + '\n').encode()) for rows in native_ids]}))
review = '# Independent immutable35b local full-run review\n\nDecision: CLEAR for the source-bound local full observation. W06 remains IN_PROGRESS;38/300 VERIFIED;M03IN_PROGRESS;releaseNOT_READY.\n\n' + f'{len(regular_checks)} explicit checks and1998 regular Git-member checks pass. Both source endpoints match immutable35b46287/tree f0789de7 Git blobs, sizes and executable bits for all1998 files; full permission modes match between snapshots and both Git status endpoints are clean. The40 runtime byte/mode endpoints match, with the knownc9049a3f manifest. Both outer commands exit0, direct children are reaped, recorded groups areABSENT and outer cleanup signals are empty.\n\n' + 'Raw inner logs establish doctor28PASS7.642166s and no-argument verify20ACTIVE PASS1170.553932s: TypeScript4006; exactly1860 canonical Python node IDs,1858common+2POSIX, and1860PASS391.37s; the same234 registered desktop cases PASS in each of three modes with no ignored/filtered cases; all15 Rust/frontend commands reach the final build. Four separate browser executions report262(8.5m),2(1.6s),62(40.0s),3(5.3s). The1-case native host and10-case contract harness also pass.\n\n' + '\n'.join('- ' + value for value in limits) + '\n\nNo test, compiler, browser, native app, model or canonical write was performed by this reviewer. Only retained files and immutable Git objects were read.\n'
put(OUT / 'REVIEW.md', review.encode())
selected = {}
for path in sorted(BASE.iterdir()):
    check('finite actual evidence regularfile ' + path.name, path.is_file() and not path.is_symlink())
    selected['actual/' + path.name] = path.read_bytes()
for name in ['SUMMARY.json', 'CHECKS.json', 'REVIEW.md']:
    selected['review/' + name] = (OUT / name).read_bytes()
selected['review/audit-executed.py'] = Path(__file__).read_bytes()
index = [{'path': name, 'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(selected.items())]
selected['retention-index.json'] = dump({'scope': 'Finite closed35b local full source/data proof; no native images', 'files': index})
packed = io.BytesIO()
with gzip.GzipFile(fileobj=packed, mode='wb', mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w') as archive:
        for name, raw in sorted(selected.items()):
            member = tarfile.TarInfo(name); member.size = len(raw); member.mode = 0o644; member.mtime = 0
            archive.addfile(member, io.BytesIO(raw))
proof = packed.getvalue()
with tarfile.open(fileobj=io.BytesIO(proof)) as archive:
    check('every finite safe archive member readback matches', len(archive.getmembers()) == len(selected) and all(member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts and archive.extractfile(member).read() == selected[member.name] for member in archive.getmembers()))
put(OUT / 'proof.tar.gz', proof)
artifact = {'archive': {'bytes': len(proof), 'sha256': sha(proof), 'safe_regular_members': len(selected)}, 'review_sha256': sha(review.encode()), 'actual_raw_verify': {'bytes': (BASE / 'verify.log').stat().st_size, 'sha256': sha((BASE / 'verify.log').read_bytes())}, 'scope': summary['decision']}
evidence = Path('docs/evidence/m03-w06-local-full-35b')
data = {'README.md': review.encode(), 'artifact.json': dump(artifact), 'summary.json': dump(summary), 'retention-manifest.json': dump({'schema': 'FINITE_REGULAR_ARCHIVE_V1', 'files': index}), 'proof.tar.gz': proof}
changes = []
for name, raw in data.items():
    relative = evidence / name
    put(PROPOSAL / 'after' / relative, raw)
    changes.append({'path': relative.as_posix(), 'before_sha256': None, 'after_sha256': sha(raw)})
entry = '## Immutable35b local full verification (2026-10-28)\n\nClean35b46287/tree f0789de7 runs doctor28PASS7.642s and all20ACTIVE suitesPASS1170.553932s: TypeScript4006/Python1860PASS391.37s/native234each3/browser262+2+62+3. All1998tracked file blobs/sizes/executablebits match immutableGit; fullpermissionmodes equal between endpoints; runtime40byte/mode endpoints equal; both outer children reaped/groupsABSENT/zero cleanup signals. Independent source/data review CLEAR; exact raw proof docs/evidence/m03-w06-local-full-35b. This validates35b only: the subsequent source-known FIFO correction and freshCI40782097996 are pending separately. Earlier failed runs remain failed and separately retained. No escaped-descendant, clean-environment, newGUI/foreignpackage/certification or milestone acceptance claim is added. W06IN_PROGRESS;38/300VERIFIED;M03IN_PROGRESS;releaseNOT_READY.\n\n'
for name, anchor in [('docs/PROJECT_STATUS.md', '## Active work\n'), ('docs/TEST_EVIDENCE.md', '## Update rules\n'), ('docs/KNOWN_ISSUES.md', '## Current native macOS development package')]:
    before_raw = (ROOT / name).read_bytes(); text = before_raw.decode()
    if anchor not in text:
        anchor = '## Current hosted Windows failures'
    position = text.index(anchor)
    if name == 'docs/PROJECT_STATUS.md':
        position += len(anchor)
        paragraph = entry.split('\n\n', 1)[1].strip()
        after_text = text[:position] + '\n- Immutable35b local full (2026-10-28): ' + paragraph + '\n' + text[position:]
    else:
        after_text = text[:position] + entry + text[position:]
    put(PROPOSAL / 'before' / name, before_raw)
    put(PROPOSAL / 'after' / name, after_text.encode())
    changes.append({'path': name, 'before_sha256': sha(before_raw), 'after_sha256': sha(after_text.encode())})
put(PROPOSAL / 'PLAN.json', dump({'scope': '5E/3docs; immutable35b full evidence only; no implementation or status transitions', 'changes': changes, 'review': str(OUT / 'REVIEW.md'), 'review_sha256': sha(review.encode()), 'preimage_check_required': True, 'states': summary['states']}))
print(json.dumps({'review': str(OUT / 'REVIEW.md'), 'review_sha256': sha(review.encode()), 'explicit_checks': len(regular_checks), 'git_regular_members': 1998, 'archive': artifact['archive'], 'proposal': str(PROPOSAL), 'proposal_paths': len(changes)}, indent=2))
