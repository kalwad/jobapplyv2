from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import stat
import subprocess
import sys
import time

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
OUT = Path(sys.argv[1])
OUT.mkdir(exist_ok=False)

def snapshot():
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).split(b'\0')
    result = {}
    for raw in paths:
        if raw:
            path = ROOT / os.fsdecode(raw)
            info = path.lstat()
            assert stat.S_ISREG(info.st_mode)
            result[os.fsdecode(raw)] = {'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    runtime = ROOT / 'apps/desktop/src-tauri/runtime-payload'
    staged = {}
    for path in sorted(runtime.rglob('*')):
        info = path.lstat()
        if stat.S_ISDIR(info.st_mode):
            continue
        assert stat.S_ISREG(info.st_mode)
        staged[path.relative_to(runtime).as_posix()] = {'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    return {'source': result, 'runtime': staged, 'git_status': subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)}

assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True) == ''
before = snapshot()
(OUT / 'before.json').write_text(json.dumps(before, indent=2, sort_keys=True) + '\n')
(OUT / 'wrapper-executed.py').write_bytes(Path(__file__).read_bytes())
context = {'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(), 'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip(), 'start_utc': datetime.datetime.now(datetime.UTC).isoformat()}
(OUT / 'context.json').write_text(json.dumps(context, indent=2) + '\n')
env = dict(os.environ)
env['PATH'] = '/opt/homebrew/opt/node@24/bin:/Users/tanishkalwad/.local/share/uv/python/cpython-3.12.13-macos-aarch64-none/bin:' + env['PATH']
results = []
for name, argv, budget in [('doctor', ['pnpm', 'run', 'doctor'], 180), ('verify', ['pnpm', 'verify'], 2700)]:
    start = time.monotonic()
    with (OUT / (name + '.log')).open('wb') as output:
        child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        timeout = False
        signals = []
        try:
            code = child.wait(timeout=budget)
        except subprocess.TimeoutExpired:
            timeout = True
            # The timed-out direct child is still unreaped here. Signal its
            # owned group before waiting; do not infer ownership after reaping.
            for sig in [signal.SIGTERM, signal.SIGKILL]:
                try:
                    os.killpg(child.pid, sig)
                    signals.append(sig.name)
                except ProcessLookupError:
                    pass
                if sig == signal.SIGTERM:
                    time.sleep(1)
            code = child.wait(timeout=10)
    try:
        os.killpg(child.pid, 0)
        group = 'PRESENT_AFTER_DIRECT_CHILD_REAP; NO_POST_REAP_SIGNAL'
    except ProcessLookupError:
        group = 'ABSENT'
    row = {'name': name, 'argv': argv, 'exit_code': code, 'timeout': timeout, 'seconds': time.monotonic() - start, 'direct_child_reaped': child.returncode is not None, 'observed_group': group, 'outer_cleanup_signals': signals}
    results.append(row)
    (OUT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    if code != 0 or group != 'ABSENT':
        break
after = snapshot()
(OUT / 'after.json').write_text(json.dumps(after, indent=2, sort_keys=True) + '\n')
closure = {'end_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'source_count': len(before['source']), 'runtime_count': len(before['runtime']), 'source_bytes_modes_unchanged': before['source'] == after['source'], 'runtime_bytes_modes_unchanged': before['runtime'] == after['runtime'], 'git_status_before': before['git_status'], 'git_status_after': after['git_status'], 'all_commands_exit_zero': len(results) == 2 and all(r['exit_code'] == 0 and not r['timeout'] and r['observed_group'] == 'ABSENT' for r in results)}
(OUT / 'closure.json').write_text(json.dumps(closure, indent=2) + '\n')
print(json.dumps(closure), flush=True)
raise SystemExit(0 if closure['all_commands_exit_zero'] and before == after else 1)
