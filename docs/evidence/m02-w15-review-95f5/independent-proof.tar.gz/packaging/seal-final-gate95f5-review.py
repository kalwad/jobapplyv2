from pathlib import Path,PurePosixPath
import hashlib,json,tarfile,io
B=Path('/tmp/japp-m02-w15-independent-audit');O=Path('/tmp/japp-m02-w15-independent-final-gate95f5-retained');assert not O.exists();O.mkdir();selected={}
def add(p,n):
 q=PurePosixPath(n);assert p.is_file() and not p.is_symlink() and n not in selected and not q.is_absolute() and '..' not in q.parts;selected[n]=p
for d in ['final-gate-a-verdict95f5','actual-predecision95f5-pack-review','actual-predecision95f5-pack-review-attempt2','actual-pack-reader-history','final-pack-governance-scope-review','documentary-pack-builder-source-review','final-pack-source-proposal-review']:
 for p in sorted((B/d).rglob('*')):
  assert not p.is_symlink()
  if p.is_file():add(p,'review/'+p.relative_to(B).as_posix())
for name in ['audit-actual-predecision-pack95f5.py','audit-actual-predecision-pack95f5-corrected.py','actual-pack-first-reader.stdout.log','actual-pack-first-reader.stderr.log','emit-final-gate-a-verdict95f5.py','review-final-pack-proposal.py']:
 add(B/name,'review/'+name)
add(Path(__file__),'packaging/seal-final-gate95f5-review.py')
rows=[]
for n,p in sorted(selected.items()):
 b=p.read_bytes();rows.append({'path':n,'source':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
manifest={'candidate_commit':'95f5b09f43d9bef06d6158ea0bb8b9e0e3aa9123','candidate_tree':'b85166b035fbf90a1b8c85d54f52461ccc422dd6','predecision_pack_sha256':'sha256:5085d94111a2dab8aba4f879f9ffb197287bd436d8df5193aef8aaafc505f5aa','independent_verdict_sha256':'sha256:b86bca4619fe541e6a82b0ef01175c35de3ebcbd344798efc33f340929b729cf','recommendation':'PASS','owner_decision':'PENDING','authoritative_gate_state':'IN_PROGRESS','gate_pass_authorized':False,'files':rows};mp=O/'retention-manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');ap=O/'proof.tar.gz'
with tarfile.open(ap,'w:gz') as t:
 for row in rows:
  b=Path(row['source']).read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'];m=tarfile.TarInfo(row['path']);m.size=len(b);m.mode=0o644;m.mtime=0;t.addfile(m,io.BytesIO(b))
 b=mp.read_bytes();m=tarfile.TarInfo('retention-manifest.json');m.size=len(b);m.mode=0o644;m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(ap,'r:gz') as t:
 members=t.getmembers();assert len(members)==len(rows)+1 and len({m.name for m in members})==len(members)
 for row in rows:
  m=t.getmember(row['path']);b=t.extractfile(m).read();assert m.isfile() and len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'] and b==Path(row['source']).read_bytes()
 assert t.extractfile('retention-manifest.json').read()==mp.read_bytes()
r={'archive':str(ap),'archive_bytes':ap.stat().st_size,'archive_sha256':hashlib.sha256(ap.read_bytes()).hexdigest(),'regular_members':len(rows)+1,'explicit_source_members':len(rows),'exhaustive_postwrite_and_source_recapture':'PASS','recommendation':'PASS','owner_decision':'PENDING','gate_pass_authorized':False,'predecision_pack_sha256':manifest['predecision_pack_sha256'],'independent_verdict_sha256':manifest['independent_verdict_sha256']};(O/'archive-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
