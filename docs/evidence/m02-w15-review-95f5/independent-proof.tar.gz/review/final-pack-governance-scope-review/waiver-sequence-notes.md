# Final documentary pack: waiver authority and sequencing

## Current assessment: explicit v2 proposal

This v2 assessment supersedes the historical v1 assessment retained below. Reviewed exact files:

- `/tmp/japp-m02-w15-final-pack-proposal-20261018/pack-plan-v2.json`, SHA-256 `dde4eee19ab0b8487e008c27ac75a93225cfa26b6c9c36d52456bee78c20295b`.
- `/tmp/japp-m02-w15-final-pack-proposal-20261018/candidate-index.preparation-v2.json`, SHA-256 `6fcb44e8cd248fc5b82fb957ac05de2ed0c4adb0d4ef8ef7c09ca003a0828ff2`.

Both hashes were checked against the supplied identities. Candidate Git identity remains commit `95f5b09f43d9bef06d6158ea0bb8b9e0e3aa9123`, tree `b85166b035fbf90a1b8c85d54f52461ccc422dd6`.

**Accepted authority locatability is now sufficient.** The v2 index at1691–1705 explicitly declares the three narrow waiver categories and points to `governance-and-manifests/docs/DECISIONS.md`. The v2 plan at789–792 lists that exact member, 45,230 bytes, SHA-256 `805b5ea2f7fa17c6007b991cc0dca3a228c7d4baf7cc6a9b1953f5635ef88413`. A checksum of the frozen candidate's `docs/DECISIONS.md` matches that declaration. Accepted OD-035/ADR-0006 and OD-036/ADR-0007 are locatable at the source rows/headings cited below. The earlier v1 missing-authority-locator observation is closed. No additional typed-v2 record structure or waived execution is required.

**One small final-publication token correction remains.** At `candidate-index.preparation-v2.json:1693`, `waivers.holdout.result` is `WAIVED_BY_OWNER`; at1716, `frozen_corpus.holdout_execution` is `WAIVED_BY_OWNER_NOT_EXECUTED`. Those honestly describe nonexecution, but the canonical final holdout result should be `WAIVED_BY_OWNER_ADR_0006`. The final Gate A report and ledger must pair the exact standalone field `Holdout result: WAIVED_BY_OWNER_ADR_0006`, with explanation separately. This follows the existing narrative PASS checker at `scripts/validate_status.py:2206–2232`, independently of typed v2 contracts. Retain the original pending records as history and do not turn waiver/nonexecution into PASS. ADR-0007 categories already carry the exact token and remain zero-case/unexecuted observations.

**Independent-to-owner sequencing is correct and still pending.** The v2 sequence at1678–1683 preserves actual evidence closure, then a finalized predecision pack, then a separate independent verdict bound to that pack/source, then the actual owner decision. Final verdict and owner-approval fields are correctly null/PENDING at preparation time. Once those actual records exist, final documentary references need their source locators, identities/dates and exact candidate/pack/verdict bindings as described below. That is expected later finalization, not a defect requiring an owner decision now or a circular self-containing predecision pack.

No other gap was identified within the assigned waiver/sequence scope. The 140-file declaration and 103-asset/corpus claims were not independently audited here; the parent reviewer covers that inventory. No archive was opened and no actors/tests/imports/network/source-inventory recapture or repository edits were performed. Additional v2 inspection used JSON projection/field search and checksum comparison of these two JSON files and the one frozen authority document only.

## Historical v1 assessment (superseded by v2 above)

Review scope: the two proposed JSON files, frozen candidate source and read-only Git identity only. No actors, imports/tests, network, archive opening/import, source-inventory recapture or repository edits were performed. Corpus/result inventory is outside this supplemental scope. No typed GateEvidenceBundleV2 publication or waived evidence execution is required by this review.

Candidate identity confirmed with `git rev-parse HEAD HEAD^{tree}` in `/tmp/japp-m02-w15-final-candidate3-20261018/clone`:

- Commit: `95f5b09f43d9bef06d6158ea0bb8b9e0e3aa9123`
- Tree: `b85166b035fbf90a1b8c85d54f52461ccc422dd6`

## What is already correct

The preparation index declares `authority: NONE`, Gate IN_PROGRESS, owner PENDING and null final verdict/approval fields. The plan likewise leaves actual final pack, gate verdict and owner decision null. These are honest preparation states, not final acceptance claims.

The sequence at `candidate-index.preparation.json:1678–1683` is correct: actual current evidence closure; finalized predecision input/index and pack; independent inspection of that actual pack with a separate verdict bound to its digest/source; presentation of verdict and pack for the actual owner decision; a later decision record/ledger linking all three. Its explicit avoidance of a self-hash cycle and rewriting older PENDING records is appropriate. Accepted ADR-0006/0007 authorizes the named process/evidence waivers; it supplies neither a future independent verdict nor owner approval of an unknown future Gate A verdict.

The accepted authority is present and locatable in the frozen candidate:

- `docs/DECISIONS.md:64`: accepted OD-035 owner row.
- `docs/DECISIONS.md:407`: `### ADR-0006 — Continuous execution and owner-controlled holdout waiver`; accepted status at409; approval/decision at411–412. Scope is owner-controlled holdout and per-W stopping, preserving other evidence and never relabeling waiver as execution/PASS.
- `docs/DECISIONS.md:65`: accepted OD-036 owner row.
- `docs/DECISIONS.md:424`: `### ADR-0007 — Direct Simplify comparison and executed public-form evidence waiver`; accepted status at426; approval/decision at428–429; exact scope at430. Only DIRECT_SIMPLIFY_COMPARISON and EXECUTED_PUBLIC_FORM_EVIDENCE are waived; independent/source-bound owner review and all nonwaived requirements remain.

## Minimal final documentary completion fields

1. **Waiver authority locators and scope.** Neither proposed JSON currently explicitly locates OD-035/ADR-0006 or OD-036/ADR-0007. Add concise references to the frozen candidate commit, `docs/DECISIONS.md`, the owner-row IDs and exact ADR headings above, plus their accepted status and narrow scope. If the final pack is intended to be self-contained, provide a member/nested-member locator to retained authority bytes; a pinned Git commit/path/heading is adequate as an external source locator when the candidate repository is intentionally the source. Do not replace the accepted authority with the pack author's assertion. No typed-v2 owner-waiver object or new source-record digest format is imposed.
2. **Exact final holdout waiver token and nonexecution meaning.** Add the final documentary holdout assessment `WAIVED_BY_OWNER_ADR_0006`, explicitly unexecuted/unpassed. The final Gate A report and critical-gate ledger must pair the exact field `Holdout result: WAIVED_BY_OWNER_ADR_0006`; put explanation on a separate line. Candidate `docs/gates/AUTOFILL_FEASIBILITY_GATE.md:90` and `docs/CRITICAL_GATES.md:126` still use descriptive `WAIVED_BY_OWNER (...)`. Those are valid historical/nonfinal explanations, but `_gate_holdout_problems` at `scripts/validate_status.py:2206–2232` accepts a waiver for final PASS only when the paired values exactly equal the canonical token and the accepted source authority is present. Preserve the ADR-0007 pair `Simplify comparison result: WAIVED_BY_OWNER_ADR_0007` / `Public-form evidence result: WAIVED_BY_OWNER_ADR_0007`; neither becomes executed/PASS.
3. **Actual independent verdict followed by actual owner decision.** After the final predecision pack exists, the separate independent record must identify the reviewer, actual verdict/date, candidate commit/tree and exact pack digest/source locator. The later owner record must locate the actual owner decision/date and identify that same candidate/pack and independent verdict record/digest. Fill final publication references only from those actual records. Preparation null/PENDING values may remain as preserved history; the predecision pack itself need not contain its own future verdict or approval. Existing sequence wording already supplies the correct order; no extra approval or waived-execution step is needed.

These are final-publication documentary gaps, not reasons to fabricate a verdict, infer owner approval from ADR-0007, rerun actors, mutate the frozen candidate or demand waived hidden/public/comparator observations.

## Exact sources read

- `/tmp/japp-m02-w15-final-pack-proposal-20261018/pack-plan.json` (full plan)
- `/tmp/japp-m02-w15-final-pack-proposal-20261018/candidate-index.preparation.json` (metadata/locator/sequence/limits and field searches; no result-inventory audit)
- Frozen candidate `docs/DECISIONS.md` (OD rows and ADR-0006/0007 bodies)
- Frozen candidate `docs/CRITICAL_GATES.md` (waiver/state/reviewer/owner field search)
- Frozen candidate `docs/gates/AUTOFILL_FEASIBILITY_GATE.md` (waiver/state/reviewer/owner field search)
- Frozen candidate `scripts/validate_status.py` (source-preimage recognizers at1953–2006 and2081–2140; narrative holdout check at2206–2232)

All conclusions are manual source/JSON review. No runtime validator was called and no archive contents were verified in this follow-up.
