"""Seal the historical f3 review; no current working-tree neutrality claim."""
from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path
import stat
import tarfile

H = Path(__file__).resolve().parent
def info(path):
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode) and not path.is_symlink()
    b = path.read_bytes()
    return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(), 'full_mode': s.st_mode}
def dump(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n')
assert info(H / 'immutable-git-source-sha256.json')['sha256'] == '4ab7ec940114f598574d5d09c242bb6dc8f0968562174fac45428e74fbadd528'
assert info(H / 'immutable-python-test-inventory.v1.json')['sha256'] == '691537e00c2b306233b17cc77a6ed79d5c1122ca87d492f5b4adaf4b78a244db'
result = json.loads((H / 'data-review.json').read_bytes())
assert result['result']['verdict'] == 'CLEAR_FINITE_ACTUAL_LOCAL_FULL_PASS' and result['result']['data_joins'] == 4833 and all(row['pass'] for row in result['checks'])
for row in json.loads((H / 'copied-members.json').read_bytes()):
    expected = {key: row[key] for key in ('bytes', 'sha256', 'full_mode')}
    assert info(H / row['path']) == expected
    # These finite selected historical origins remain checked. No entire current
    # canonical source/HEAD/status assertion after root begins a later adoption.
    assert info(Path(row['origin'])) == expected
qa = []
for path in sorted((H / 'qa').glob('*/receipt.json')):
    row = json.loads(path.read_bytes())
    assert row['reaped'] and row['exit_code'] == 0 and row['group_after_wait'] == 'ABSENT' and row['signals'] == []
    qa.append({'path': str(path.relative_to(H)), 'pid': row['pid']})
assert len(qa) == 8
excluded = {'manifest.json', 'proof.tar.gz', 'SEAL.json'}
files = {p.relative_to(H).as_posix(): info(p) for p in sorted(H.rglob('*')) if p.is_file() and p.relative_to(H).as_posix() not in excluded}
manifest = {'schema_version': 1, 'file_count': len(files), 'bytes': sum(row['bytes'] for row in files.values()), 'files': files, 'scope': 'Historical actual f3 local-full review only; all indexed members regular, manifest/proof/seal self-excluded. Later working-tree source/HEAD state is not asserted.'}
dump(H / 'manifest.json', manifest)
with tarfile.open(H / 'proof.tar.gz', 'w:gz', compresslevel=6) as archive:
    for name in [*files, 'manifest.json']:
        archive.add(H / name, arcname=name, recursive=False)
with tarfile.open(H / 'proof.tar.gz', 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(files)+1 and all(item.isfile() and not item.name.startswith('/') and '..' not in Path(item.name).parts for item in members)
    for item in members:
        stream = archive.extractfile(item)
        assert stream is not None
        body = stream.read()
        pin = info(H / item.name)
        assert len(body) == pin['bytes'] and hashlib.sha256(body).hexdigest() == pin['sha256']
seal = {'utc': datetime.now(UTC).isoformat(), 'verdict': 'CLEAR_FINITE_ACTUAL_LOCAL_FULL_PASS', 'REVIEW': info(H / 'REVIEW.md'), 'findings': info(H / 'source-findings.json'), 'DATA': info(H / 'data-review.json'), 'manifest': info(H / 'manifest.json'), 'proof': info(H / 'proof.tar.gz'), 'indexed_regular_members': len(files), 'proof_safe_regular_members': len(files)+1, 'own_closed_helpers': qa, 'scope': 'Exact historical f3 local full PASS and finite visual/source/custody review. Original374 failures unchanged, pendingCI/laterworkingtree/native/model/gate/release outside this verdict.'}
dump(H / 'SEAL.json', seal)
print(json.dumps(seal))
