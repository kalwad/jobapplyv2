# Failed f5a CI campaign retained

CI40914184628 attempt1 is FAILURE. macOS/Ubuntu each20ACTIVE PASS; Windows19PASS plus Python FAIL (2474passes and2errors in the same oversized-field case setup/teardown). The raw traceback reaches PYTEST_CURRENT_TEST environment assignment and the32767-character Windows limit; the case body is not credited. All other suites, including ordinary4006TS,278/2/62/17 browser/public/contact/visual, and platform native cases in three modes, retain their actual results. No later fixture correction is validated here.

The three canonical checkouts actually used merge719b966… with treeaa9fbaa9… and two parents including sourcef5a05bad…. All2255 immutable local Git bodies were independently joined by framedSHA1/SHA256/size/full regular/executable mode to the complete API trees. This is not a current dirty-tree claim or a separate network fetch of every blob.

The dependent native package matrix was actually skipped and produced zero exports. GNOME prepare/lifecycle runs succeeded only as no-root-request metadata gates with zero install/VM/product actors; they supply no native acceptance. Windows Server2025 is not Windows11 acceptance.

proof.tar.gz retains three terminal run records, eight terminal job outcomes, five complete executed job logs, all three complete official logZIPs and safe maps, four artifact API metadata/member maps, both tiny policy artifacts, source commitments and the different7863/7863 review. Original large diagnostics/visual payload ZIPs and complete source bodies stay outside; retention-manifest.json names these omissions and preserves exact commitments. The differently named playwright-failure artifact does not establish a browser failure: all ordinary Playwright suites passed.

The reviewer executed no subject/import, API request, rerun, cancellation, package/native/GUI actor, install, VM or canonical write. An initial reviewer-only literal traceback expectation mismatch is retained in observer-v1 and explicitly corrected. No work-package/state/release promotion follows from this recorded failure.
