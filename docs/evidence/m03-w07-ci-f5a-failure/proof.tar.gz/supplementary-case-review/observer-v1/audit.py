"""Read retained official logs and immutable inventory; never execute subject."""
from pathlib import Path
import hashlib,json,re,shlex
from collections import Counter
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');P=E/'ci-f5a05ba';S='f5a05bad78d8421a5c1e0094eb928fdbb464cdc7';results={};checks=[]
def check(n,v):
 checks.append({'name':n,'pass':bool(v)})
 if not v:raise ValueError(n)
O=Path(__file__).parent
raw=(P/'actual-source-python-inventory.json').read_bytes();inventory=json.loads(raw)
source=json.loads((P/'immutable-git-source-sha256.json').read_bytes());check('immutable exact inventory body',hashlib.sha256(raw).hexdigest()==source['files']['scripts/python-test-inventory.v1.json']['sha256'])
for job,platform,count,native_count in [(123589894788,'Windows2025',2475,316),(123589894855,'Mac15',2477,342),(123589895607,'Ubuntu24.04',2477,338)]:
 path=P/f'runs/40914184628/closed-jobs/{job}.log';original=path.read_text();log=re.sub(r'^\d{4}-\d\d-\d\dT\S+Z ','',original,flags=re.M);log=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',log);lines=log.splitlines()
 summary=log[log.rfind('== verification summary =='):];rows=re.findall(r'^([a-z0-9-]+)[ \t]+(ACTIVE)[ \t]+(PASS|FAIL)[ \t]*(.*)$',summary,re.M)
 check(platform+' actual20 suite rows',len(rows)==20)
 check(platform+' exact failure set',[r[0] for r in rows if r[2]=='FAIL']==(['python'] if platform=='Windows2025' else []))
 check(platform+' doctor28',bool(re.search(r'^summary: 28 pass, 0 warning, 0 fail, 0 not-yet-applicable$',log,re.M)))
 ci=next(i for i,l in enumerate(lines) if l.startswith('$ uv run pytest ') and '--collect-only' in l);ce=next(i for i in range(ci+1,len(lines)) if re.match(str(count)+r' tests collected',lines[i]));collected=[l for l in lines[ci+1:ce] if re.match(r'^(scripts|services|packages)/.+::',l)]
 expected=inventory['common']['node_ids']+([] if platform=='Windows2025' else inventory['posix_only_node_ids'])
 opaque='services/orchestrator/tests/test_service_api.py::test_every_route_requires_session_auth[***'
 missing=sorted(set(expected)-set(collected));observed_opaque=[n for n in collected if n==opaque]
 projected=[opaque if n in missing else n for n in expected]
 check(platform+' collection matches source-bound masked multiset',len(collected)==count and len(missing)==len(observed_opaque)==12 and all(n.startswith('services/orchestrator/tests/test_service_api.py::test_every_route_requires_session_auth[Bearer ') for n in missing) and Counter(projected)==Counter(collected))
 masking={'raw_opaque_line':opaque,'raw_count':len(observed_opaque),'source_bound_possible_ids':missing,'source_projection_counter_equal':Counter(projected)==Counter(collected),'individual_masked_case_identity_established':False,'masking_mechanism_or_cause_observed':False,'limit':'Twelve raw identities/status suffixes collapse; this is a source-bound multiset projection, not proof of each original raw identity.'}

 ei=next(i for i in range(ce+1,len(lines)) if lines[i].startswith('$ uv run pytest ') and '--collect-only' not in lines[i]);ca=shlex.split(lines[ci][2:]);ea=shlex.split(lines[ei][2:]);check(platform+' execution same selection',[a for a in ca if a not in ('--collect-only','-q')]==ea)
 py_summary=[l for l in lines[ei:] if re.match(r'^=+ \d+ passed',l)];check(platform+' one actual pytest execution summary',len(py_summary)==1)
 check(platform+' actual pytest final outcome',bool(re.match(r'^=+ 2474 passed, 2 errors in 1066\.57s',py_summary[0])) if platform=='Windows2025' else bool(re.match(r'^=+ 2477 passed in ',py_summary[0])))
 start=log.index('$ pnpm exec turbo run test --force --concurrency=2 -- --reporter=default');stop=log.index('$ pnpm exec turbo run build --force');ts=log[start:stop];counts=re.findall(r'^(@japp/[^:]+):test:\s+Tests\s+([0-9]+) passed \(\2\)\s*$',ts,re.M)
 check(platform+' fresh4006 TS15',len(counts)==len({n for n,_ in counts})==15 and sum(int(n) for _,n in counts)==4006 and 'Cached:    0 cached, 15 total' in ts)
 modes={}
 for cmd in ['$ cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml','$ cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml --all-features','$ cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml --features tauri/custom-protocol']:
  a=lines.index(cmd);b=next((i for i in range(a+1,len(lines)) if lines[i].startswith('$ ')),len(lines));section='\n'.join(lines[a+1:b]);names=re.findall(r'^test (.+) \.\.\. ok$',section,re.M);check(platform+' native'+str(native_count)+':'+cmd,len(names)==len(set(names))==native_count and f'test result: ok. {native_count} passed; 0 failed;' in section);modes[cmd]=names
 check(platform+' native three exact sets',len({frozenset(ns) for ns in modes.values()})==1)
 check(platform+' separate native1+contract10',all(f'test result: ok. {n} passed; 0 failed;' in log for n in [1,10]))
 browser={}
 for label,run,listcmd,want in [('browser','$ pnpm exec playwright test\n','$ pnpm exec playwright test --list',278),('public','$ pnpm exec playwright test --config e2e/extension/public-research/playwright.config.ts\n','$ pnpm exec playwright test --config e2e/extension/public-research/playwright.config.ts --list',2),('contact','$ pnpm exec playwright test --config e2e/extension/public-contact/playwright.config.ts --reporter=list,json\n','$ pnpm exec playwright test --config e2e/extension/public-contact/playwright.config.ts --reporter=list,json --list',62),('visual','$ pnpm exec playwright test e2e/visual --output test-results/visual\n','$ pnpm exec playwright test e2e/visual --output test-results/visual --list',17)]:
  a=log.index(run);b=log.index(listcmd,a+len(run));c=log.find('\n$ ',b+len(listcmd));c=len(log) if c<0 else c
  actual=re.findall(r'^  [✓✔]\s+\d+ (?:\[.*?\] › )?(?:e2e/)?(.+:\d+:\d+ › .+) \([\d.]+(?:ms|s|m)\)$',log[a:b],re.M);listed=re.findall(r'^  (?:\[.*?\] › )?(.+:\d+:\d+ › .+)$',log[b:c],re.M)
  if label in ('public','contact'):actual=[v.split(':',1)[0].replace('\\','/').rsplit('/',1)[-1]+':'+v.split(':',1)[1] for v in actual]
  check(platform+' actual browser/discovery IDs '+label,len(actual)==len(set(actual))==len(listed)==len(set(listed))==want and set(actual)==set(listed))
  final=[l.strip() for l in log[a:b].splitlines() if re.match(r'\s*'+str(want)+r' passed \(',l)];check(platform+' browser actual summary '+label,len(final)==1);browser[label]={'count':want,'summary':final[0],'actual_cases':actual}
 results[platform]={'collection_masking':masking,'job_id':job,'conclusion':'failure' if platform=='Windows2025' else 'success','suite_rows':[{'id':a,'state':b,'result':c,'detail':d} for a,b,c,d in rows],'actual_collection_count':count,'actual_collection_sorted_sha256':hashlib.sha256(('\n'.join(sorted(collected))+'\n').encode()).hexdigest(),'collection_node_ids':collected,'pytest_actual_summary':py_summary[0],'typescript_package_counts':counts,'native_unique_per_mode':native_count,'native_actual_case_sets':modes,'browser':browser}
(O/'actual-suite-results.json').write_text(json.dumps({'scope':'Different read-only raw-case projection review. Twelve opaque masked IDs per platform are a multiset projection only; individual identities unresolved. Windows failure remains explicit; no packaged/native GUI/platform credit','checks':checks,'passed':len(checks),'jobs':results},indent=2)+'\n');print(json.dumps({'passed':len(checks),'jobs':{k:{'conclusion':v['conclusion'],'python':v['pytest_actual_summary'],'TS':sum(int(n) for _,n in v['typescript_package_counts']),'native_per_mode':v['native_unique_per_mode']} for k,v in results.items()}}))
