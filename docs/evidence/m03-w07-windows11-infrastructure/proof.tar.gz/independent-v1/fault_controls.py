"""Finally-only AST control probes: no subject import, processes, native or files.

The subject is read as data. Only extracted cleanup control flow runs, with
fake owner, TPM, path, observer, source and publication callbacks. Negative
controls remove one exact Owner.close exception guard from that same AST;
they are synthetic and never described as historical source bytes.
"""
from __future__ import annotations

import argparse
import ast
import copy
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace


class FakePath:
    def __init__(self, name):
        self.name = name

    def __truediv__(self, name):
        return FakePath(self.name + "/" + str(name))

    def __str__(self):
        return self.name

    def is_file(self):
        return False

    def exists(self):
        return False


def extract(path, negative=False):
    raw = path.read_bytes()
    module = ast.parse(raw)
    main = next(n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == "main")
    bracket = next(n for n in main.body if isinstance(n, ast.Try) and n.finalbody)
    body = copy.deepcopy(bracket.finalbody)
    removed = []
    if negative:
        class RemoveCloseGuard(ast.NodeTransformer):
            def visit_Try(self, node):
                if any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                       and isinstance(n.func.value, ast.Name) and n.func.value.id == "owner"
                       and n.func.attr == "close" for line in node.body for n in ast.walk(line)):
                    removed.append(ast.unparse(node))
                    return node.body
                return self.generic_visit(node)
        wrapper = ast.Module(body=body, type_ignores=[])
        wrapper = RemoveCloseGuard().visit(wrapper)
        body = wrapper.body
        assert len(removed) == 1, "Exactly one controlled guard removal required"
    function = ast.FunctionDef(name="probe_finally", args=ast.arguments(
        posonlyargs=[], args=[], kwonlyargs=[], kw_defaults=[], defaults=[]),
        body=body, decorator_list=[])
    # A final cleanup may delegate a small local observation helper. Include
    # only referenced local function definitions, never imports or top-level
    # assignments, and replace every external operation with a callback.
    defs = {n.name: n for n in module.body if isinstance(n, ast.FunctionDef) and n.name != "main"}
    helpers = {}
    queue = [function]
    while queue:
        node = queue.pop()
        for call in ast.walk(node):
            if isinstance(call, ast.Call) and isinstance(call.func, ast.Name):
                name = call.func.id
                if name in defs and name not in helpers and name not in {"source_binding", "audit_bundle", "retain"}:
                    helpers[name] = copy.deepcopy(defs[name])
                    queue.append(helpers[name])
    final = ast.Module(body=[ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0), *helpers.values(), function], type_ignores=[])
    ast.fix_missing_locations(final)
    return compile(final, str(path) + ":finally-only-fake-control", "exec"), {
        "source_sha256": hashlib.sha256(raw).hexdigest(),
        "finally_AST_sha256": hashlib.sha256(ast.dump(final).encode()).hexdigest(),
        "synthetic_negative": negative, "removed_guard": removed,
        "included_local_helpers": sorted(helpers),
    }


def probe(path, label, *, negative=False, close_error=False, observer_error=False,
          tpm_error=False, live_vm=False, rmtree_error=False, endpoint_error=False):
    code, provenance = extract(path, negative)
    events = []
    child = SimpleNamespace(pid=41001, returncode=None if live_vm else 0)
    tpmchild = SimpleNamespace(pid=41002, returncode=None)
    owner = SimpleNamespace(child=child, qmp=None, pending_commands=[])

    def close():
        events.append("owner.close")
        if close_error:
            raise OSError("controlled owner cleanup fault")
        child.returncode = 0
        return {"direct_child_reaped": True, "group_after_reap": "ABSENT", "pending_commands": []}
    owner.close = close

    def observe(_pid):
        events.append("group.observe")
        if observer_error:
            raise OSError("controlled group observation fault")
        return False

    def tpm_close():
        events.append("tpm.close")
        if tpm_error:
            raise OSError("controlled TPM cleanup fault")
        tpmchild.returncode = 0
    tpm = SimpleNamespace(child=tpmchild, signals=[], terminate_unreaped=tpm_close)
    before = {"exact": "fake source endpoint"}

    def endpoint(*_args, **_kwargs):
        events.append("source.endpoint")
        if endpoint_error:
            raise OSError("controlled source observer fault")
        return before

    def bundle(*_args, **_kwargs):
        events.append("bundle.endpoint")
        return {}

    def write(path, _value):
        events.append("publish:" + str(path))

    def retain(*_args, **_kwargs):
        events.append("retain")

    def remove(_path):
        events.append("work.remove")
        if rmtree_error:
            raise OSError("controlled private cleanup fault")

    result = {"status": "SCOPED_NATIVE_WINDOWS11_LIFECYCLE_PASS" if "vm.py" in path.name else "DOWNLOAD_ONLY_UNREVIEWED_CANDIDATE_COMPLETE",
              "actual_native_Windows11_acceptance": "vm.py" in path.name}
    args = SimpleNamespace(proof=FakePath("proof"), output=FakePath("candidate"), source=FakePath("source"),
                           expected_head="a" * 40, bundle=FakePath("bundle"), bundle_sha256="b" * 64)
    env = {"owner": owner, "tpm": tpm, "args": args, "work": FakePath("private-work"),
           "result": result, "before": before, "package": {"fake": True}, "group_exists": observe,
           "source_binding": endpoint, "audit_bundle": bundle, "write": write, "retain": retain,
           "shutil": SimpleNamespace(rmtree=remove)}
    error = None
    try:
        exec(code, env)
        env["probe_finally"]()
    except Exception as exc:
        error = type(exc).__name__
    published = any(event.endswith("/closure.json") for event in events)
    if negative:
        expected = error == "OSError" and not published and "retain" not in events
    else:
        expected = error is None and published and "retain" in events
        if close_error or tpm_error or observer_error or rmtree_error or endpoint_error:
            expected = expected and result["status"] not in {"SCOPED_NATIVE_WINDOWS11_LIFECYCLE_PASS", "DOWNLOAD_ONLY_UNREVIEWED_CANDIDATE_COMPLETE"}
        if path.name == "windows11_vm.py":
            expected = expected and (("tpm.close" in events) is (not live_vm))
            if live_vm or tpm_error or observer_error:
                expected = expected and "work.remove" not in events
            if close_error or tpm_error or observer_error or rmtree_error or endpoint_error:
                expected = expected and result["actual_native_Windows11_acceptance"] is False
    return {"label": label, "pass": expected, "error": error, "events": events, "synthetic_result": result,
            "fake_TPM_reaped": tpmchild.returncode is not None, "provenance": provenance,
            "all_operations_fake": True, "actual_processes_native_calls_or_filesystem_mutations": 0}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    vm = args.source / "scripts/windows11/windows11_vm.py"
    candidate = args.source / "scripts/windows11/windows11_candidate.py"
    rows = [
        probe(vm, "synthetic_negative_VM_owner_close", negative=True, close_error=True),
        probe(candidate, "synthetic_negative_candidate_owner_close", negative=True, close_error=True),
        probe(vm, "final_VM_normal_cleanup"),
        probe(vm, "final_VM_owner_close_fault_reaped_QEMU", close_error=True),
        probe(vm, "final_VM_owner_close_fault_live_QEMU", close_error=True, live_vm=True),
        probe(vm, "final_VM_group_observer_fault", close_error=True, observer_error=True),
        probe(vm, "final_VM_TPM_cleanup_fault", tpm_error=True),
        probe(vm, "final_VM_private_work_removal_fault", rmtree_error=True),
        probe(vm, "final_VM_source_endpoint_fault", endpoint_error=True),
        probe(candidate, "final_candidate_owner_close_fault", close_error=True),
        probe(candidate, "final_candidate_private_work_removal_fault", rmtree_error=True),
        probe(candidate, "final_candidate_source_endpoint_fault", endpoint_error=True),
    ]
    report = {"scope": __doc__, "total": len(rows), "passed": sum(r["pass"] for r in rows), "rows": rows}
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"total": report["total"], "passed": report["passed"], "failed": [r for r in rows if not r["pass"]]}))
    return 0 if report["total"] == report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
