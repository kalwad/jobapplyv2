from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time
P=Path(__file__).parent;S=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/windows11-native-vm-preparation/v1');start=datetime.datetime.now(datetime.UTC).isoformat();began=time.monotonic();before={str(p.relative_to(S/'after')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (S/'after').rglob('*') if p.is_file()};argv=['/usr/bin/python3','-I','-S','-B',str(P/'fault_controls.py'),'--source',str(S/'after'),'--output',str(P/'fault-control-results.json')];signals=[]
with (P/'fault-controls.stdout').open('wb') as out,(P/'fault-controls.stderr').open('wb') as err:
 child=subprocess.Popen(argv,stdout=out,stderr=err,start_new_session=True)
 try:code=child.wait(timeout=20)
 except subprocess.TimeoutExpired:
  if child.returncode is None:os.killpg(child.pid,signal.SIGTERM);signals.append('SIGTERM')
  code=child.wait(timeout=5)
try:os.killpg(child.pid,0);group='PRESENT'
except ProcessLookupError:group='ABSENT'
after={str(p.relative_to(S/'after')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (S/'after').rglob('*') if p.is_file()};receipt={'argv':argv,'cwd':str(P),'started_utc':start,'ended_utc':datetime.datetime.now(datetime.UTC).isoformat(),'elapsed_seconds':time.monotonic()-began,'pid':child.pid,'pgid':child.pid,'exit_code':code,'direct_child_reaped':child.returncode is not None,'group_after_wait':group,'signals':signals,'source25_before_after_equal':before==after,'source25_sha256':before,'scope':'reviewer child only; finally-only extracted subject control flow with fake callbacks; no product/native/VM/network/install actors'};(P/'fault-controls-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');assert code==0 and group=='ABSENT' and not signals and before==after;print(json.dumps({'closed':code,'group':group,'source25_equal':before==after}))
