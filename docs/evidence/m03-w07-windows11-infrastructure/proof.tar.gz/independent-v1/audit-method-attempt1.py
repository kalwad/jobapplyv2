from pathlib import Path,PurePosixPath
import ast,hashlib,json,stat,tarfile
P=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/windows11-native-vm-preparation/v1');O=Path(__file__).parent;E=P.parents[1];C=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def ck(n,v):
 C.append({'name':n,'pass':bool(v)})
 if not v:raise ValueError(n)
def row(p):
 s=p.lstat();ck('regular '+str(p.relative_to(P)),stat.S_ISREG(s.st_mode));return {'bytes':s.st_size,'mode':oct(stat.S_IMODE(s.st_mode)),'sha256':sha(p.read_bytes())}
def js(n):return json.loads((P/n).read_bytes())
for n,pin in [('SOURCE.json','309d89034e5c20f9c3578f65faaa0d6460507a9120aef2dcc968758d4041039e'),('HANDOFF.json','9d46a1d4aae503dfdd9f0c54ae594e95cc3ccee93e68feb40b3058884a2fa37d'),('MANIFEST.json','e747abdffe762fe42daff5f5aaf06a4edda99f26824714493c8ed5e1eaa15e48'),('proof.tar.gz','a6324fdbfa85b24676d27c5c60f1dc14fa3e2296b273803818bb57fc68699e2d')]:ck(n+' exact final pin',sha((P/n).read_bytes())==pin)
src=js('SOURCE.json');manifest=js('MANIFEST.json')['members']
for selection in [src['files'],manifest]:
 for name,r in selection.items():ck('sealed retained '+name,row(P/name)==r)
with tarfile.open(P/'proof.tar.gz','r:gz') as tf:
 members=tf.getmembers();names=[m.name for m in members];ck('261 unique archive regular',len(names)==len(set(names))==261 and all(m.isfile() for m in members));ck('archive member exact manifest plus manifest',set(names)==set(manifest)|{'MANIFEST.json'})
 for m in members:
  q=PurePosixPath(m.name);ck('safe archive '+m.name,str(q)==m.name and not q.is_absolute() and '..' not in q.parts and '\\' not in m.name);data=tf.extractfile(m).read();ck('archive bytes '+m.name,data==(P/m.name).read_bytes() and m.mode==stat.S_IMODE((P/m.name).stat().st_mode))
a=js('ADOPTION.json');ck('25 adoption targets',len(a['targets'])==25 and sum(r['operation']=='add' for r in a['targets'])==19 and sum(r['operation']=='replace' for r in a['targets'])==6)
for r in a['targets']:
 ck('adoption after '+r['path'],row(P/'after'/r['path'])==r['after'])
 if r['before'] is not None:ck('adoption preimage '+r['path'],row(P/'before'/r['path'])==r['before'])
immutable=json.loads((E/'ci-f5a05ba/immutable-git-source-sha256.json').read_bytes())['files'];allowed={'apps/desktop/src-tauri/src/lib.rs','apps/desktop/src-tauri/src/main.rs'}
for phase in ['pure-actual-v10','composed-collection-actual-v2']:
 before=js(phase+'/source-before.json');after=js(phase+'/source-after.json');ck(phase+' exact source/runtime/head/tree/status endpoints',before==after);ck(phase+' source2255/runtime40',len(before['source'])==2255 and len(before['runtime'])==40);ck(phase+' f5a exact HEAD/tree',before['head']=='f5a05bad78d8421a5c1e0094eb928fdbb464cdc7' and before['tree']=='aa9fbaa9addd16052eaeca6259852bc00bb03702');ck(phase+' exact two dirty native paths',set(l[3:] for l in before['status'].splitlines())==allowed)
 for name,r in before['source'].items():
  if name not in allowed:ck(phase+' immutable f5a body '+name,r['sha256']==immutable[name]['sha256'] and r['bytes']==immutable[name]['bytes'])
 ck(phase+' inputs endpoints',js(phase+'/inputs-before.json')==js(phase+'/inputs-after.json'))
 for r in js(phase+'/commands.json'):
  ck(phase+' bounded command custody '+r['name'],r['exit_code']==0 and r['direct_child_reaped'] is True and r['owned_group_absent'] is True and r['timed_out'] is False and not r['signals'] and r['seconds']<=r['timeout_seconds']+5)
  for st in ['stdout','stderr']:ck(phase+' exact raw '+r['name']+st,sha((P/phase/(r['name']+'.'+st)).read_bytes())==r[st+'_sha256'])
final={r['path']:r['after'] for r in a['targets']};pure=js('pure-actual-v10/inputs-after.json');composition=js('composed-collection-actual-v2/inputs-after.json');ck('only inventory changed after pure QA',set(k for k in pure if pure[k]!=final[k])=={'scripts/python-test-inventory.v1.json'});ck('all final25 exact composed collection',composition==final)
raw=(P/'pure-actual-v10/01-fixtures.stdout').read_text();ck('actual147 pure passed','147 passed' in raw);collect=(P/'pure-actual-v10/07-exact-collection.stdout').read_text();newids=[l for l in collect.splitlines() if l.startswith('scripts/tests/') and '::' in l];ck('actual147 unique pure IDs',len(newids)==len(set(newids))==147)
full=(P/'composed-collection-actual-v2/03-full-collection.stdout').read_text();ids=[l for l in full.splitlines() if l.startswith(('scripts/','services/','packages/')) and '::' in l];old=json.loads((E/'ci-f5a05ba/actual-source-python-inventory.json').read_bytes());oldids=set(old['common']['node_ids']+old['posix_only_node_ids']);new=js('after/scripts/python-test-inventory.v1.json');ck('2624 actual unique full collection',len(ids)==len(set(ids))==2624);ck('all2477 old plus147exact actualpure',set(ids)==oldids|set(newids) and not oldids&set(newids));ck('same2POSIX only',new['posix_only_node_ids']==old['posix_only_node_ids']);ck('2622exactcommon',len(new['common']['node_ids'])==len(set(new['common']['node_ids']))==2622 and set(new['common']['node_ids'])==set(ids)-set(old['posix_only_node_ids']));ck('common sorted digest',new['common']['sha256']==sha(('\n'.join(sorted(new['common']['node_ids']))+'\n').encode()))
ck('catalog checker and wholeportability actualPASS',all('PASS' in (P/'composed-collection-actual-v2'/n).read_text() for n in ['04-catalog-and-fixture-policy.stdout','05-whole-portability.stdout']))
# Independently bind source policy literals to the exact frozen bodies.
checker=ast.parse((P/'after/scripts/check_portability.py').read_bytes());assignments={n.targets[0].id:n.value for n in checker.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
for n,pin in ast.literal_eval(assignments['WINDOWS11_NATIVE_PINS']).items():ck('checker native exactbody '+n,sha((P/'after/scripts/windows11'/n).read_bytes())==pin)
for n,r in ast.literal_eval(assignments['CANDIDATE_AUXILIARY_WORKFLOWS']).items():
 if n.startswith('windows11-'):ck('checker workflow exactbody '+n,len((P/'after/.github/workflows'/n).read_bytes())==r[0] and sha((P/'after/.github/workflows'/n).read_bytes())==r[1])
# Separate explicit one-ID catalog composition; no rewrite of parent source seal.
Q=E/'windows11-param-id-composition-v1';cp=json.loads((Q/'SOURCE.json').read_bytes());ck('composition sourcepin',sha((Q/'SOURCE.json').read_bytes())=='4ce20a45a933879ef5310f9ac71ad9c99bf840ec3c1dd5754dfa9c61e864baec');paths=list((Q/'after').rglob('python-test-inventory.v1.json'));ck('one composed catalog',len(paths)==1);composed=json.loads(paths[0].read_bytes());mapping=json.loads((E/'windows-pytest-param-id-preparation/v1/id-mapping.json').read_bytes());ck('composition exact one mapped ID',set(new['common']['node_ids'])-set(composed['common']['node_ids'])=={mapping['old_id']} and set(composed['common']['node_ids'])-set(new['common']['node_ids'])=={mapping['new_id']});ck('all147 additions and2POSIX preserved',set(newids)<=set(composed['common']['node_ids']) and composed['posix_only_node_ids']==new['posix_only_node_ids']);ck('composed2622 digest',composed['common']['count']==2622 and composed['common']['sha256']==sha(('\n'.join(sorted(composed['common']['node_ids']))+'\n').encode()))
(O/'data-audit.json').write_text(json.dumps({'scope':'different finite source/retained-data review; subject not imported; no actor or actual target claim','passed':len(C),'checks':C},indent=2)+'\n');print(json.dumps({'passed':len(C)}))
