from pathlib import Path
import ast,hashlib,json,stat,subprocess
P=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/windows-pytest-param-id-preparation/v1');O=Path(__file__).parent; checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def check(n,v):
 checks.append({'name':n,'pass':bool(v)})
 if not v:raise ValueError(n)
def entry(p):
 s=p.lstat();check('regular '+str(p.relative_to(P)),stat.S_ISREG(s.st_mode));return {'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'sha256':sha(p.read_bytes())}
src=json.loads((P/'SOURCE.json').read_bytes());check('SOURCE pin',sha((P/'SOURCE.json').read_bytes())=='cea8b5e4355a20b94554a99425000f0da04736137ce268767e0d793505a58b4b')
for rel,rows in src['changes'].items():
 for side,row in rows.items():check(side+' '+rel,entry(P/side/rel)==row)
old=ast.parse((P/'before/scripts/tests/test_ubuntu_gnome_signed_indexes.py').read_text());new=ast.parse((P/'after/scripts/tests/test_ubuntu_gnome_signed_indexes.py').read_text());calls=[x for x in ast.walk(new) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and isinstance(x.func.value,ast.Name) and x.func.value.id=='pytest' and x.func.attr=='param'];check('one explicit pytest.param',len(calls)==1);call=calls[0];check('exact explicit stable ID',len(call.args)==1 and len(call.keywords)==1 and call.keywords[0].arg=='id' and ast.literal_eval(call.keywords[0].value)=='oversized-field')
class Unwrap(ast.NodeTransformer):
 def visit_Call(self,node):
  return node.args[0] if node is call else self.generic_visit(node)
new=Unwrap().visit(new);check('all other module AST incl all test bodies/payload expressions unchanged',ast.dump(old,include_attributes=False)==ast.dump(new,include_attributes=False))
mapping=json.loads((P/'id-mapping.json').read_bytes());before=json.loads((P/'before/scripts/python-test-inventory.v1.json').read_bytes());after=json.loads((P/'after/scripts/python-test-inventory.v1.json').read_bytes());a=before['common']['node_ids'];b=after['common']['node_ids'];check('exact sole ID mapping',set(a)-set(b)=={mapping['old_id']} and set(b)-set(a)=={mapping['new_id']});check('same2475common unique',len(a)==len(b)==len(set(a))==len(set(b))==2475);check('exact2POSIX unchanged',before['posix_only_node_ids']==after['posix_only_node_ids'] and len(after['posix_only_node_ids'])==2)
for c in [before,after]:
 ids=c['common']['node_ids'];check('catalog derived count',c['common']['count']==len(ids));check('catalog sorted digest',c['common']['sorted_node_ids_sha256']==sha(('\n'.join(sorted(ids))+'\n').encode()))
# No other catalog fields except the one ID and derived digest may differ.
normalized=json.loads(json.dumps(after));normalized['common']['node_ids']=[mapping['old_id'] if x==mapping['new_id'] else x for x in normalized['common']['node_ids']];normalized['common']['sorted_node_ids_sha256']=before['common']['sorted_node_ids_sha256'];check('all other catalog fields unchanged',normalized==before)
collections=[]
for i,want in [(1,mapping['old_id']),(2,mapping['new_id'])]:
 text=(P/f'{i:02d}.stdout').read_text();ids=[l for l in text.splitlines() if l.startswith('scripts/tests/') and '::' in l];check('actual24 collection '+str(i),len(ids)==len(set(ids))==24 and want in ids);collections.append(ids)
check('actual collections exact one mapping',set(collections[0])-{mapping['old_id']}==set(collections[1])-{mapping['new_id']});check('payload length exceeds Windows env limit remains',isinstance(call.args[0],ast.BinOp) and ast.literal_eval(call.args[0].left)==b'x' and ast.literal_eval(call.args[0].right)==65537);check('corrected raw test24PASS','24 passed' in (P/'03.stdout').read_text())
for i,r in enumerate(src['commands'],1):
 check('command custody '+str(i),r['exit_code']==0 and r['reaped'] is True and r['group']=='ABSENT' and r['signals']==[])
 for stream in ['stdout','stderr']:check('raw '+str(i)+stream,entry(P/f'{i:02d}.{stream}')==r[stream])
for rel,row in src['refs'].items():
 raw=subprocess.run(['/usr/bin/git','--no-optional-locks','-C','/Users/tanishkalwad/jobapplyv2','show','f5a05bad78d8421a5c1e0094eb928fdbb464cdc7:'+rel],capture_output=True,timeout=10,check=True).stdout;check('immutable canonical reference '+rel,sha(raw)==row['sha256'] and len(raw)==row['bytes'])
(O/'data-audit.json').write_text(json.dumps({'scope':'finite source and retained-data only; no subject imports/test execution or corrected Windows claim','checks':checks,'passed':len(checks)},indent=2)+'\n');print(json.dumps({'passed':len(checks)}))
