from pathlib import Path
import datetime
import hashlib
import json
import os
import stat
import subprocess
import sys

E=Path(__file__).parent
R=Path('/Users/tanishkalwad/jobapplyv2')
W=E/'windows11-native-vm-preparation/v2'
P=E/'windows-pytest-param-id-preparation/v1'
C=E/'windows11-param-id-composition-v2'
O=E/'windows11-canonical-adoption-v1'
review=Path(sys.argv[1]);review_sha=sys.argv[2];manifest_sha=sys.argv[3]
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def row(p):
    s=p.lstat();assert stat.S_ISREG(s.st_mode)
    b=p.read_bytes();return {'bytes':len(b),'mode':stat.S_IMODE(s.st_mode),'sha256':hashlib.sha256(b).hexdigest()}
def check(p,expected):
    value=row(p);mode=expected['mode'];mode=int(mode,8) if isinstance(mode,str) else mode
    assert value=={**expected,'mode':mode},str(p)
def dump(n,x): (O/n).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def snapshot():
    raw=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=R)
    files={os.fsdecode(n):row(R/os.fsdecode(n)) for n in sorted(set(raw.split(b'\0'))-{b''})}
    b=R/'apps/desktop/src-tauri/runtime-payload'
    runtime={p.relative_to(b).as_posix():row(p) for p in sorted(b.rglob('*')) if not p.is_dir()}
    return {'files':files,'runtime':runtime,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=R,text=True)}
assert digest(W/'SOURCE.json')=='167b9efccc423c3998320fbadc80d9e9d38cfce96672afb42f3b2d47481f888d'
assert digest(P/'SOURCE.json')=='cea8b5e4355a20b94554a99425000f0da04736137ce268767e0d793505a58b4b'
assert digest(C/'SOURCE.json')=='bbb6110110b2aab0a72670062609e524761e44c5335f41bf20dd8125d344a4d6'
assert digest(review/'REVIEW.md')==review_sha and digest(review/'manifest.json')==manifest_sha
assert digest(E/'windows-pytest-param-id-independent-review/v1/REVIEW.md')=='917a194aad10369c45c19cb6627d598492b57e1fa20763fef2c2dfc3e6caadba'
assert digest(E/'windows-pytest-param-id-independent-review/v1/manifest.json')=='5bdb043579f5405997512dcfa54ed2614b9fdde9495f7fe69abac045c7fcea4a'
assert digest(R/'apps/desktop/src-tauri/src/lib.rs')=='53ce147f3cf175371eefafdfc296363d8cf57f928f4609f35a527fb84a08b4f9'
assert digest(R/'apps/desktop/src-tauri/src/main.rs')=='85d95119a4ebcfeb4122020a8d33a0e62eb9e850721a53c64b0fd07e5807bce3'
source=json.loads((W/'SOURCE.json').read_text());adoption=json.loads((W/'ADOPTION.json').read_text())
for name,expected in source['files'].items(): check(W/name,expected)
for name,expected in json.loads((P/'SOURCE.json').read_text())['refs'].items():check(R/name,expected)
for item in adoption['targets']:
    name=item['path'];p=R/name;check(W/'after'/name,item['after'])
    if item['operation']=='add':assert not p.exists() and not p.is_symlink()
    else:assert item['operation']=='replace';check(p,item['before'])
    for parent in p.parents:
        if parent==R:break
        if parent.exists():assert parent.is_dir() and not parent.is_symlink()
before=snapshot()
assert before['head']==adoption['base_head'] and before['tree']==adoption['base_tree']
assert before['status']==' M apps/desktop/src-tauri/src/lib.rs\n M apps/desktop/src-tauri/src/main.rs\n'
assert len(before['files'])==2255 and len(before['runtime'])==40
O.mkdir();dump('before.json',before);(O/'observer-executed.py').write_bytes(Path(__file__).read_bytes())
for item in adoption['targets']:
    name=item['path'];p=R/name
    if item['operation']=='replace':
        q=O/'preimages'/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes());os.chmod(q,row(p)['mode'])
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((W/'after'/name).read_bytes());os.chmod(p,int(item['after']['mode'],8));check(p,item['after'])
win=snapshot();dump('after-exact-win11.json',win)
replaced={x['path'] for x in adoption['targets'] if x['operation']=='replace'}
added={x['path'] for x in adoption['targets'] if x['operation']=='add'}
assert {n for n in before['files'] if before['files'][n]!=win['files'][n]}==replaced
assert set(win['files'])-set(before['files'])==added and len(win['files'])==2274
assert before['runtime']==win['runtime'] and before['head']==win['head'] and before['tree']==win['tree']
fixture='scripts/tests/test_ubuntu_gnome_signed_indexes.py';catalog='scripts/python-test-inventory.v1.json'
q=O/'preimages'/fixture;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((R/fixture).read_bytes());os.chmod(q,row(R/fixture)['mode'])
assert (R/catalog).read_bytes()==(C/'before-inventory.json').read_bytes()
short=json.loads((P/'SOURCE.json').read_text());check(R/fixture,short['changes'][fixture]['before']);check(P/'after'/fixture,short['changes'][fixture]['after'])
(R/fixture).write_bytes((P/'after'/fixture).read_bytes())
assert digest(C/'after-inventory.json')=='aa7cbc869d1540fe5edc7a14b69d84bad57bfed4db08ff5ea45dd066e007035b'
(R/catalog).write_bytes((C/'after-inventory.json').read_bytes())
after=snapshot();dump('after-composed.json',after)
assert set(after['files'])==set(win['files'])
assert {n for n in win['files'] if win['files'][n]!=after['files'][n]}=={fixture,catalog}
assert before['runtime']==after['runtime'] and before['head']==after['head'] and before['tree']==after['tree']
dump('APPLIED.json',{'observed_utc':datetime.datetime.now(datetime.UTC).isoformat(),'win11_exact_targets':len(adoption['targets']),'win11_replaced':sorted(replaced),'win11_added':sorted(added),'separate_short_id_and_catalog_composition':[fixture,catalog],'all_other_source_runtime_fullmodes_and_head_tree_preserved':True,'inventory_source_count':len(after['files']),'win11_review':{'path':str(review),'review_sha256':review_sha,'manifest_sha256':manifest_sha},'scope':'SOURCE_ADOPTION_ONLY_NOT_CANONICAL_TEST_OR_NATIVE_VM_PASS'})
print(json.dumps({'source_files':len(after['files']),'win11_paths':len(adoption['targets']),'short_id_mapped_separately':True,'status':after['status']}))
