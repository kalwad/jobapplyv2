from pathlib import Path
import hashlib,json,stat
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');A=E/'windows11-canonical-adoption-v1';F=E/'windows11-canonical-focus-v1';W=E/'windows11-native-vm-preparation/v2';P=E/'windows-pytest-param-id-preparation/v1';Q=E/'windows11-param-id-composition-v2';O=Path(__file__).parent;C=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def ck(n,v):
 C.append({'name':n,'pass':bool(v)})
 if not v:raise ValueError(n)
def js(p):return json.loads(p.read_bytes())
def row(p):
 s=p.lstat();ck('regular retained '+str(p),stat.S_ISREG(s.st_mode));return {'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'sha256':sha(p.read_bytes())}
def normalize(r):return {**r,'mode':int(r['mode'],8) if isinstance(r['mode'],str) else r['mode']}
ck('executed exact guarded adopter',(A/'observer-executed.py').read_bytes()==(E/'adopt-windows11-and-short-id-v2.py').read_bytes());ck('executed exact bounded focus wrapper',(F/'wrapper-executed.py').read_bytes()==(E/'run-windows11-canonical-focus-v1.py').read_bytes())
before=js(A/'before.json');win=js(A/'after-exact-win11.json');after=js(A/'after-composed.json');ck('2255 to2274source/runtime40',len(before['files'])==2255 and len(win['files'])==len(after['files'])==2274 and len(before['runtime'])==40)
immutable=js(E/'ci-f5a05ba/immutable-git-source-sha256.json')['files'];native={'apps/desktop/src-tauri/src/lib.rs':'53ce147f3cf175371eefafdfc296363d8cf57f928f4609f35a527fb84a08b4f9','apps/desktop/src-tauri/src/main.rs':'85d95119a4ebcfeb4122020a8d33a0e62eb9e850721a53c64b0fd07e5807bce3'}
ck('before exact immutable f5a2255 paths',set(before['files'])==set(immutable))
for n,r in before['files'].items():
 ck('before body '+n,r['sha256']==(native[n] if n in native else immutable[n]['sha256']));ck('before Gitexecuteclass '+n,bool(r['mode']&0o111)==(immutable[n]['git_mode']=='100755'))
ck('before exacttwoM',set(l[3:] for l in before['status'].splitlines())==set(native))
adopt=js(W/'ADOPTION.json')['targets'];replaced={r['path'] for r in adopt if r['operation']=='replace'};added={r['path'] for r in adopt if r['operation']=='add'};ck('exact Win25 six replaced19added',len(adopt)==25 and len(replaced)==6 and len(added)==19);ck('exact added pathset',set(win['files'])-set(before['files'])==added and set(before['files'])<=set(win['files']));ck('only six originals changed exactWin stage',{n for n in before['files'] if before['files'][n]!=win['files'][n]}==replaced)
for r in adopt:
 n=r['path'];ck('Win exact reviewed afterimage '+n,win['files'][n]==normalize(r['after']))
 if r['before'] is not None:ck('Win exact preimage '+n,before['files'][n]==normalize(r['before']) and row(A/'preimages'/n)==before['files'][n])
fixture='scripts/tests/test_ubuntu_gnome_signed_indexes.py';catalog='scripts/python-test-inventory.v1.json';ck('only explicit fixture plus catalog composition changes',{n for n in win['files'] if win['files'][n]!=after['files'][n]}=={fixture,catalog} and set(win['files'])==set(after['files']));ck('original fixture preimage retained',row(A/'preimages'/fixture)==before['files'][fixture]);ck('reviewed exact fixture afterimage',after['files'][fixture]==normalize(js(P/'SOURCE.json')['changes'][fixture]['after']));ck('reviewed catalog exact afterimage',after['files'][catalog]==row(Q/'after-inventory.json'));ck('reviewed catalog intermediate exact',win['files'][catalog]==row(Q/'before-inventory.json'))
for stage,s in [('Win',win),('composed',after)]:
 ck(stage+'runtime40 exact preserved',s['runtime']==before['runtime']);ck(stage+'f5a exact HEAD/tree preserved',s['head']==before['head']=='f5a05bad78d8421a5c1e0094eb928fdbb464cdc7' and s['tree']==before['tree']=='aa9fbaa9addd16052eaeca6259852bc00bb03702')
# A synthetic exact expected projection proves every unmodified body and full permission mode.
expected=dict(before['files']);expected.update({r['path']:normalize(r['after']) for r in adopt});ck('complete exact2274Win projection',expected==win['files']);expected[fixture]=normalize(js(P/'SOURCE.json')['changes'][fixture]['after']);expected[catalog]=row(Q/'after-inventory.json');ck('complete exact2274combined projection',expected==after['files'])
prior=js(E/'full-f5a05ba/before.json')['runtime'];ck('all40 runtime rows equal independently reviewed full',before['runtime']==prior)
fb=js(F/'before.json');fa=js(F/'after.json');ck('focus complete retained before equals adoption after',fb==after);ck('focus all2274/runtime40/headtree/status fullmodes neutral',fb==fa)
# Exact complete historical dirty status, excluding later documentation additions.
for stage,s,modified in [('Win',win,replaced|set(native)),('composed',after,replaced|set(native)|{fixture})]:
 rows=s['status'].splitlines();ck(stage+'exact historical dirty file statuses',len(rows)==len(modified)+len(added) and {x[3:] for x in rows if x.startswith(' M ')}==modified and {x[3:] for x in rows if x.startswith('?? ')}==added)
commands=js(F/'results.json');ck('nine actual commands',len(commands)==9)
for i,r in enumerate(commands,1):
 ck('bounded custody '+str(i),r['exit_code']==0 and r['group']=='ABSENT' and r['reaped'] is True and not r['signals'] and r['timeout'] is False and 0<=r['seconds']<180)
 for stream in ['stdout','stderr']:ck('raw exact '+str(i)+stream,row(F/f'{i:02d}.{stream}')==r[stream])
ck('strictLinux15',commands[2]['argv'][commands[2]['argv'].index('--platform')+1]=='linux' and 'scripts/windows11' in commands[2]['argv'] and (F/'03.stdout').read_text()=='Success: no issues found in 15 source files\n')
fixtures=['scripts/tests/test_windows11_inputs.py','scripts/tests/test_windows11_request.py','scripts/tests/test_windows11_isolation.py','scripts/tests/test_windows11_resources.py','scripts/tests/test_ubuntu_gnome_signed_indexes.py','scripts/tests/test_ci_workflow.py'];w=commands[3]['argv'];ck('strictWin32 exact sixcommonfixtures',w[w.index('--platform')+1:] == ['win32',*fixtures] and (F/'04.stdout').read_text()=='Success: no issues found in 6 source files\n')
prettier=['.github/windows11','.github/workflows/windows11-native-prepare.yml','.github/workflows/windows11-native-lifecycle.yml','package.json',catalog,'scripts/verification-suites.json'];ck('Prettier exactsix inputs',commands[4]['argv']==['pnpm','exec','prettier','--check',*prettier] and 'All matched files use Prettier code style!' in (F/'05.stdout').read_text());ck('actual213 focused PASS','213 passed in 3.23s' in (F/'06.stdout').read_text() and commands[5]['argv'][-6:]==fixtures)
collected=[l for l in (F/'07.stdout').read_text().splitlines() if l.startswith(('scripts/','services/','packages/')) and '::' in l];c=js(Q/'after-inventory.json');expectedids=c['common']['node_ids']+c['posix_only_node_ids'];ck('actual canonical2624 exact mapped catalog',len(collected)==len(set(collected))==2624 and set(collected)==set(expectedids));ck('actual canonical common2622 sorted digest',len(c['common']['node_ids'])==2622 and c['common']['sha256']==sha(('\n'.join(sorted(set(collected)-set(c['posix_only_node_ids'])))+'\n').encode()))
old=js(E/'ci-f5a05ba/actual-source-python-inventory.json');mapping=js(P/'id-mapping.json');new147=[l for l in (W/'pure-actual-v2/07-exact-collection.stdout').read_text().splitlines() if l.startswith('scripts/tests/') and '::' in l];expectedold=(set(old['common']['node_ids'])-{mapping['old_id']})|{mapping['new_id']}|set(old['posix_only_node_ids']);ck('old2477exactsole mapping plus147additions',set(collected)==expectedold|set(new147) and len(new147)==147 and not expectedold&set(new147));ck('same2POSIX',c['posix_only_node_ids']==old['posix_only_node_ids'] and len(c['posix_only_node_ids'])==2);focused=[n for n in collected if n.split('::',1)[0] in fixtures];ck('exact213 catalog focus cases',len(focused)==213)
ck('actual portabilityPASS',(F/'08.stdout').read_text()=='PASS: portability policy validated\n');integrity=(F/'09.stdout').read_text();ck('actual integrity ACTIVEPASS only', 'integrity      ACTIVE               PASS' in integrity and 'verification exit code: 0' in integrity)
(O/'data-audit.json').write_text(json.dumps({'scope':'retained adoption/focus phase endpoints only; no current working-tree, fullsuite, native or VM claim','passed':len(C),'checks':C,'actual_focus_cases':213,'actual_collection_cases':2624,'common_count':2622,'new_fixture_cases':147},indent=2)+'\n');print(json.dumps({'passed':len(C),'focus':213,'collection':2624}))
