# CLEAR — recorded canonical adoption and focused validation

Different finite retained-data review of `windows11-canonical-adoption-v1`, `windows11-canonical-focus-v1` and their exact saved observer/wrapper sources. All4632 checks pass. Root integrated the reviewed Windows11 v2 source before applying the separately reviewed explicit pytest ID/catalog composition. No unexpected source change, dropped case or endpoint drift was found in the recorded phases.

The2255-file initial source inventory joins the previously independently verified immutable f5a body map, except the exact separately reviewed native lib/main afterimages. The first stage applies exactly25 reviewed Windows11 targets: six replacements and19 additions. Its complete2274-file projection equals the old inventory plus those exact afterimages, including full recorded permission modes. All replacement and original fixture preimages are retained and exact. The second stage changes exactly `scripts/tests/test_ubuntu_gnome_signed_indexes.py` and `scripts/python-test-inventory.v1.json`, matching the reviewed fixture and composition-v2 after-catalog. Every other source row, all40 runtime rows, HEAD/tree and native lib/main bytes remain exact. Runtime rows also match the independently reviewed full-f5a snapshot.

The focused validation starts at the exact composed adoption endpoint and finishes with identical2274 source/40 runtime bytes, permission modes, historical dirty status and f5a HEAD/tree. Both executable observer copies equal their supplied sources. This review uses the saved phase snapshots; later evidence/documentation registration is outside that comparison. It makes no claim that the current working tree still equals those historical snapshots.

All nine actual commands exit0/reaped/groupsABSENT, with no signals or timeouts,16.00691020686645 seconds of measured command time. Their exact raw stdout/stderr sizes, permission modes and SHA256 values join the receipts. Results are:

- Ruff PASS and54 files already formatted.
- Linux-target mypy PASS for15 source files: checker, Windows11 source island and six selected fixtures.
- Windows-target mypy PASS for six selected common fixture modules. This is a prospective type-analysis target; it is not Windows execution or the entire92-file common registry scope. The latter was separately validated in the frozen v2 preparation.
- Prettier PASS over the exact six selected input targets: request-template directory, two workflows, package metadata, Python inventory and verification registry.
- Actual focused pytest213PASS in3.23s. The six selected fixture modules contain exactly213 IDs in the complete recorded catalog.
- Actual full canonical collection2624 unique IDs, exactly the reviewed2622 common IDs plus the unchanged two POSIX-only IDs. Every prior2477 ID survives with exactly the one reviewed oversized-ID mapping, and all147 new Windows11 IDs remain exact. The recomputed sorted common-ID digest matches the after-catalog.
- Portability PASS and integrity ACTIVE/PASS with verification exit0.

The unchanged collection command's source roots and strict configuration/marker flags, the focus selection and all quality scopes are retained. The executed adopter guards exact source/review pins, preimages, fresh additions and real parent directories before writing. Recorded final afterimages independently match those guarded inputs; no current canonical file read, rerun, source import, build/native/GUI/VM/install actor or source write was used by this reviewer.

This clears the recorded adoption/focus evidence for registration. It is not a new clean-commit full-suite result, actual corrected hosted Windows/package result, source-only target C# compile, dependency/media candidate review, campaign release, VM/native behavior, Windows11/GNOME or milestone acceptance. The original f5a hosted CI failure, skipped package and frozen v1/HOLD history remain unchanged; later source/commit validation must be fresh.
