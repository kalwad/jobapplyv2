from pathlib import Path
import hashlib
import io
import json
import stat
import tarfile

E=Path(__file__).parent;O=E/'m03-w07-windows11-infrastructure-evidence-v1';O.mkdir()
files={}
def add(p,n):
 assert n not in files and stat.S_ISREG(p.lstat().st_mode);files[n]=p
def tree(p,prefix):
 for x in sorted(p.rglob('*')):
  if x.is_dir() and not x.is_symlink():continue
  add(x,prefix+'/'+x.relative_to(p).as_posix())
for version in ['v1','v2']:
 p=E/'windows11-native-vm-preparation'/version
 for name in ['SOURCE.json','HANDOFF.json','ADOPTION.json','MANIFEST.json','README.md','proof.tar.gz']:
  assert (p/name).is_file();add(p/name,'source-'+version+'/'+name)
 tree(E/'windows11-native-vm-independent-review'/version,'independent-'+version)
P=E/'windows-pytest-param-id-preparation/v1'
for name in ['SOURCE.json','HANDOFF.md','results.json','id-mapping.json','observer-executed.py']:
 add(P/name,'short-id/'+name)
for i in range(1,7):
 for suffix in ['stdout','stderr']:add(P/f'{i:02}.{suffix}',f'short-id/{i:02}.{suffix}')
for directory in ['reference','before','after']:
 for p in sorted((P/directory).rglob('*')):
  if any(x in {'.pytest_cache','.ruff_cache','mypy-cache','__pycache__'} for x in p.relative_to(P).parts):continue
  if p.is_dir() and not p.is_symlink():continue
  add(p,'short-id/'+p.relative_to(P).as_posix())
tree(E/'windows-pytest-param-id-independent-review/v1','short-id-independent')
tree(E/'windows11-param-id-composition-v2','explicit-catalog-composition')
tree(E/'windows11-canonical-adoption-v1','canonical-adoption')
for p in sorted((E/'windows11-canonical-focus-v1').iterdir()):
 if p.is_file():add(p,'canonical-focus/'+p.name)
tree(E/'windows11-canonical-independent-review/v1','canonical-independent')
add(Path(__file__),'observer/packaging-executed.py')
rows=[]
with tarfile.open(O/'proof.tar.gz','w:gz') as archive:
 for name,p in sorted(files.items()):
  b=p.read_bytes();s=p.lstat();m=tarfile.TarInfo(name);m.size=len(b);m.mode=stat.S_IMODE(s.st_mode);archive.addfile(m,io.BytesIO(b));rows.append({'path':name,'source_path':str(p),'bytes':len(b),'mode':m.mode,'sha256':hashlib.sha256(b).hexdigest()})
with tarfile.open(O/'proof.tar.gz','r:gz') as archive:
 members=archive.getmembers();assert len(members)==len(rows)
 for m,r in zip(members,rows,strict=True):
  f=archive.extractfile(m);assert f is not None;b=f.read();p=Path(r['source_path']);assert m.isfile() and m.name==r['path'] and m.mode==r['mode'] and len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'] and b==p.read_bytes() and stat.S_IMODE(p.stat().st_mode)==r['mode']
def dump(n,x):(O/n).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
p=O/'proof.tar.gz';proof={'path':'proof.tar.gz','bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()};dump('artifact.json',proof)
dump('retention-manifest.json',{'members':rows,'regular_members':len(rows),'all_original_archive_bytes_fullmodes_join':True,'omissions':['Original parent envelopes declare their selected subsets and historical gaps; full immutable canonical/runtime bodies and unused historical source preparation outputs remain outside.','Canonical pytest scratch fixture outputs omitted; actual raw nine-command receipts, source/runtime maps and different4632-join review retained.','Source preparation and finite data/AST/control checks are not target Windows compile or VM/product execution.']})
dump('summary.json',{'scope':'REVIEWED_WINDOWS11_INFRASTRUCTURE_AND_SHORT_ID_COMPOSED_ADOPTED_FOCUSED_NOT_NATIVE','source_v1':'309d89034e5c20f9c3578f65faaa0d6460507a9120aef2dcc968758d4041039e','source_v1_verdict':'HOLD_F1_COMMON_WINDOWS_TYPE_IMPORT_BOUNDARY','source_v2':'167b9efccc423c3998320fbadc80d9e9d38cfce96672afb42f3b2d47481f888d','source_v2_verdict':'CLEAR_AFTER_NARROW_FIXTURE_CORRECTION','source_v2_data_joins':9778,'source_v1_retained_data_joins':6247,'source_v1_fake_cleanup_controls':12,'root_short_id_source':'cea8b5e4355a20b94554a99425000f0da04736137ce268767e0d793505a58b4b','root_short_id_review_joins':59,'root_composition':'bbb6110110b2aab0a72670062609e524761e44c5335f41bf20dd8125d344a4d6','canonical_focus_closure':json.loads((E/'windows11-canonical-focus-v1/closure.json').read_text()),'canonical_focus_cases':213,'canonical_collected_cases':2624,'common':2622,'posix_only':2,'new_windows_cases':147,'canonical_independent_data_joins':4632,'native_compile_media_install_VM_or_product_actors':0,'template_enabled':False,'proof':proof})
(O/'README.md').write_text('''# Windows11 infrastructure and explicit fixture composition

Reviewed source for one prospective disposable officialWindows11x64 evaluation
VM on a standard publicUbuntu24.04/KVM runner. The inactive templates require an
exact source/testedmerge/tree/originalcuratedWindowspackage/rootrequest binding.
DOWNLOAD_ONLY retains an UNREVIEWED officialpublisherISO/signedAPT host-tool
candidate without install or VM. Different actual candidate/tool/CPU/media review
and exact root ONE_REVIEWED_VM release remain prerequisites. No candidate was
downloaded, target PowerShell/C# compiled, software installed or VM/product actor
run by this preparation/adoption. WindowsServerCI is not Windows11 evidence.

Complete sourcev1/HOLD stays immutable: one common test imported Linux-only
resource helpers into Windows-target Mypy. V2 changes only that test's established
ModuleType fixture boundary, preserving all existing bodies/assertions/payloads,
147IDs/full2624catalog and24productionafterimages. Actual outside147pure/strict
checks and full commonWin32Mypy92sourcefiles pass, distinct from Windows execution.
Different fullv1 review6247joins/12fakecleanupcontrols plus v2 review9778joins
clear their scopes; failed drafts/observer errors and retention limits remain.

Root first adopts the exact25reviewedv2afterimages (6replace/19add), preserving
the reviewed lib/main native entry fixes. Root separately applies the reviewed
same65537-byte oversized pytest input with one short explicit parameter ID and
composes that one-ID mapping into the2622common catalog, retaining all147 added
cases and original2POSIX metadata. No input, assertion, guard or count is reduced.
Old/new24 collections and strictchecks, different59source/data review, exact
composition and guarded canonical preimages/maps/receipts remain.

Actual combined canonical nine-command focus closes0: scopedRuff/format,
LinuxstrictMypy15files, Windows-targetMypy six selected fixtures,6Prettierinputs,
213focusedtests3.23s,2624completecollection0.44s, wholeportability and integrity.
This selected Windows-target check does not replace the separately bound full92
common target check. All2274source/runtime40 bytes/full permissions/status/HEAD/
tree endpoints match, children reaped/groupsABSENT/no signals/timeouts. Different
4632datajoinsCLEAR. This collection is not full2624execution; fresh cleanfull and
hostednativepackages remain required. Original f5a hostedfailure remains separate.

Host capacity uses actual48GiB physicalfree/8GiB availableRAM/2CPUs/KVM, distinct
from sparse80GiB capacity. Conditional cleanup permits only exact unused Android/
.NET roots on the disposable GitHubhost with guarded metadata/tool/capacity
receipts; it never ran on the Mac. Exact mtools aliases/targets, officialVM
requirements, virtualdisplay limitations, standardfixture/privilegedattestation
separation, ownedjobs/handles and genuineReady/auth/crash/Close/Quit/keyboard/
accelerator/cleanup oracles remain in the reviewed source. No bypass or physical
GPU/nativeOS qualification is inferred from configuration.

Selected original/archive bytes/full modes join; parent envelopes declare their
own subsets/omissions. No M03/W07, platform/accessibility certification, final
visual baseline, model/store activation or release acceptance is added.
''')
print(json.dumps({'directory':str(O),'members':len(rows),'proof':proof}))
