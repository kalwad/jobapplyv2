from pathlib import Path
import ast
import hashlib
import json
import os
import stat
import subprocess
import time

E=Path(__file__).parent
R=Path('/Users/tanishkalwad/jobapplyv2')
P=E/'windows-pytest-param-id-preparation/v1'
P.mkdir(parents=True)
names=['scripts/tests/test_ubuntu_gnome_signed_indexes.py','scripts/linux_gnome/ubuntu_gnome_signed_indexes.py','scripts/python-test-inventory.v1.json','pyproject.toml']
def sha(body): return hashlib.sha256(body).hexdigest()
def row(path):
    info=path.lstat();assert stat.S_ISREG(info.st_mode);body=path.read_bytes()
    return {'bytes':len(body),'mode':stat.S_IMODE(info.st_mode),'sha256':sha(body)}
refs={}
for name in names:
    refs[name]=row(R/name)
    q=P/'reference'/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((R/name).read_bytes());os.chmod(q,refs[name]['mode'])
name=names[0]
before=(R/name).read_text()
old='    "payload", [b"Package: a\\npackage: b\\n", b" continuation\\n", b"x" * 65537]\n'
new='    "payload",\n    [\n        b"Package: a\\npackage: b\\n",\n        b" continuation\\n",\n        pytest.param(b"x" * 65537, id="oversized-field"),\n    ],\n'
assert before.count(old)==1
after=before.replace(old,new)
for phase,body in [('before',before),('after',after)]:
    base=P/phase
    for source in [names[0],names[1],names[3]]:
        target=base/source;target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(body.encode() if source==name else (R/source).read_bytes())
        os.chmod(target,refs[source]['mode'])
before_tree=ast.parse(before);after_tree=ast.parse(after)
for a,b in zip(before_tree.body,after_tree.body,strict=True):
    if isinstance(a,ast.FunctionDef) and a.name=='test_duplicate_continuation_and_oversized_fields_refused':
        assert isinstance(b,ast.FunctionDef) and ast.dump(ast.Module(body=a.body,type_ignores=[]))==ast.dump(ast.Module(body=b.body,type_ignores=[]))
        aa=a.decorator_list[0];bb=b.decorator_list[0]
        assert isinstance(aa,ast.Call) and isinstance(bb,ast.Call)
        assert ast.dump(aa.args[0])==ast.dump(bb.args[0])
        vals=aa.args[1];newvals=bb.args[1];assert isinstance(vals,ast.List) and isinstance(newvals,ast.List)
        assert len(vals.elts)==len(newvals.elts)==3
        assert [ast.dump(x) for x in vals.elts[:2]]==[ast.dump(x) for x in newvals.elts[:2]]
        last=newvals.elts[2];assert isinstance(last,ast.Call) and ast.unparse(last.func)=='pytest.param' and ast.dump(last.args[0])==ast.dump(vals.elts[2])
        assert [ast.unparse(k) for k in last.keywords]==["id='oversized-field'"]
    else:
        assert ast.dump(a)==ast.dump(b)
inventory=json.loads((R/names[2]).read_text())
ids=inventory['common']['node_ids'];matches=[x for x in ids if x.startswith(name+'::test_duplicate_continuation_and_oversized_fields_refused[') and len(x)>32767]
assert len(matches)==1
old_id=matches[0];new_id=name+'::test_duplicate_continuation_and_oversized_fields_refused[oversized-field]'
assert new_id not in ids
inventory['common']['node_ids']=sorted(new_id if x==old_id else x for x in ids)
inventory['common']['sha256']=sha(('\n'.join(inventory['common']['node_ids'])+'\n').encode())
assert inventory['common']['count']==len(ids)==2475
assert max(len(x+' (teardown)') for x in inventory['common']['node_ids'])<32767
target=P/'after'/names[2];target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(inventory,indent=2)+'\n')
env=dict(os.environ);env.update({'PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','PYTHONDONTWRITEBYTECODE':'1','PYTHONHASHSEED':'0'})
commands=[]
for phase in ['before','after']:
    cwd=P/phase
    specs=[['/Users/tanishkalwad/jobapplyv2/.venv/bin/python','-B','-m','pytest','-c','pyproject.toml','--collect-only','-q',name]]
    if phase=='after':
        specs.extend([
            ['/Users/tanishkalwad/jobapplyv2/.venv/bin/python','-B','-m','pytest','-c','pyproject.toml','-q',name],
            ['/Users/tanishkalwad/jobapplyv2/.venv/bin/python','-B','-m','ruff','check','--config','pyproject.toml',name],
            ['/Users/tanishkalwad/jobapplyv2/.venv/bin/python','-B','-m','ruff','format','--check','--config','pyproject.toml',name],
            ['/Users/tanishkalwad/jobapplyv2/.venv/bin/python','-B','-m','mypy','--config-file','pyproject.toml','--cache-dir',str(P/'mypy-cache'),name],
        ])
    for argv in specs:
        i=len(commands)+1;start=time.monotonic()
        with (P/f'{i:02}.stdout').open('wb') as out,(P/f'{i:02}.stderr').open('wb') as err:
            child=subprocess.Popen(argv,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
            code=child.wait(timeout=60)
        try:os.killpg(child.pid,0);group='PRESENT'
        except ProcessLookupError:group='ABSENT'
        result={'phase':phase,'argv':argv,'cwd':str(cwd),'exit_code':code,'seconds':time.monotonic()-start,'reaped':child.poll() is not None,'group':group,'signals':[],'stdout':row(P/f'{i:02}.stdout'),'stderr':row(P/f'{i:02}.stderr')};commands.append(result)
        (P/'results.json').write_text(json.dumps(commands,indent=2)+'\n')
        assert code==0 and group=='ABSENT'
old_collection=(P/'01.stdout').read_text().splitlines();new_collection=(P/'02.stdout').read_text().splitlines()
old_nodes={x for x in old_collection if x.startswith(name+'::')};new_nodes={x for x in new_collection if x.startswith(name+'::')}
assert old_nodes-new_nodes=={old_id} and new_nodes-old_nodes=={new_id} and len(old_nodes)==len(new_nodes)
assert all(row(R/n)==r for n,r in refs.items())
(P/'observer-executed.py').write_bytes(Path(__file__).read_bytes())
(P/'id-mapping.json').write_text(json.dumps({'old_id':old_id,'new_id':new_id,'old_utf16_code_units':len(old_id.encode('utf-16-le'))//2,'new_utf16_code_units':len(new_id.encode('utf-16-le'))//2,'unchanged_test_body_and_payload_AST':True,'total_cases_unchanged':len(new_nodes),'canonical_refs_unchanged':True},indent=2)+'\n')
source={'refs':refs,'changes':{n:{'before':refs[n],'after':row(P/'after'/n)} for n in [names[0],names[2]]},'scope':'ONE_OVERSIZED_PARAM_ID_ONLY_PAYLOAD_ORACLES_COUNT_UNCHANGED_NOT_WINDOWS_EXECUTION','commands':commands}
(P/'SOURCE.json').write_text(json.dumps(source,indent=2,sort_keys=True)+'\n')
print(json.dumps({'source_sha256':sha((P/'SOURCE.json').read_bytes()),'case_count':len(new_nodes),'commands_zero':len(commands),'old_id_length':len(old_id),'new_id_length':len(new_id),'canonical_changes':False}))
