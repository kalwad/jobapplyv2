from pathlib import Path,PurePosixPath
import ast,hashlib,json,stat,tarfile
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');P=E/'windows11-native-vm-preparation/v2';V=E/'windows11-native-vm-preparation/v1';O=Path(__file__).parent;C=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def ck(n,v):
 C.append({'name':n,'pass':bool(v)})
 if not v:raise ValueError(n)
def row(p):
 s=p.lstat();ck('regular '+str(p.relative_to(P)),stat.S_ISREG(s.st_mode));return {'bytes':s.st_size,'mode':oct(stat.S_IMODE(s.st_mode)),'sha256':sha(p.read_bytes())}
def js(n):return json.loads((P/n).read_bytes())
for n,pin in [('SOURCE.json','167b9efccc423c3998320fbadc80d9e9d38cfce96672afb42f3b2d47481f888d'),('HANDOFF.json','5eaf9125a20f83884ef7181c69e1987388078e380b93fdfa68ae5f6c9a0b6820'),('MANIFEST.json','17db2bf63d4b89e27ff3fd7e9a6a7de45f0799e900b0725ade3d004b88a0f16f'),('proof.tar.gz','02c0ef416c1db06f9151768bdd8942bec6f09a06ae4e62884d195aa1df2ad2b1')]:ck(n+' exact final pin',sha((P/n).read_bytes())==pin)
for data in [js('SOURCE.json')['files'],js('MANIFEST.json')['members']]:
 for n,r in data.items():ck('sealed member '+n,row(P/n)==r)
manifest=js('MANIFEST.json')['members']
with tarfile.open(P/'proof.tar.gz','r:gz') as tf:
 ms=tf.getmembers();ck('107 unique safe regular archive',len(ms)==len({m.name for m in ms})==107 and all(m.isfile() for m in ms) and {m.name for m in ms}==set(manifest)|{'MANIFEST.json'})
 for m in ms:
  q=PurePosixPath(m.name);ck('safe '+m.name,str(q)==m.name and not q.is_absolute() and '..' not in q.parts and '\\' not in m.name);ck('archive exact '+m.name,tf.extractfile(m).read()==(P/m.name).read_bytes() and m.mode==stat.S_IMODE((P/m.name).stat().st_mode))
files={str(p.relative_to(P/'after')):p.read_bytes() for p in (P/'after').rglob('*') if p.is_file()};old={str(p.relative_to(V/'after')):p.read_bytes() for p in (V/'after').rglob('*') if p.is_file()};ck('exact25 paths',set(files)==set(old) and len(files)==25);changed={n for n in files if files[n]!=old[n]};ck('only resource test boundary changed',changed=={'scripts/tests/test_windows11_resources.py'})
# All original function bodies, including helper rows and all test assertions, are exact.
name=next(iter(changed));a=ast.parse(old[name]);b=ast.parse(files[name]);fa={n.name:n for n in a.body if isinstance(n,ast.FunctionDef)};fb={n.name:n for n in b.body if isinstance(n,ast.FunctionDef)};ck('only added loader fixture function',set(fb)-set(fa)=={'resources'} and not set(fa)-set(fb))
for n in fa:ck('exact original function body '+n,ast.dump(ast.Module(body=fa[n].body,type_ignores=[]),include_attributes=False)==ast.dump(ast.Module(body=fb[n].body,type_ignores=[]),include_attributes=False))
ck('no direct source-island import',not any(isinstance(n,ast.Import) and any(x.name=='windows11_resources' for x in n.names) for n in b.body));loader=fb['resources'];ck('ModuleType loader fixture',isinstance(loader.returns,ast.Name) and loader.returns.id=='ModuleType' and any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='fixture' for n in loader.decorator_list));sdk=next(n for n in ast.parse(files['scripts/windows11/windows11_resources.py']).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SDK_ROOTS' for t in n.targets));oldvalues=ast.literal_eval(sdk.value);param=fb['test_exact_root_and_complete_real_ancestors_admitted'].decorator_list[0];ck('same two SDK payload values',tuple(ast.literal_eval(param.args[1]))==oldvalues)
# Full endpoint/command checks on final independent phases.
immutable=json.loads((E/'ci-f5a05ba/immutable-git-source-sha256.json').read_bytes())['files'];native={'apps/desktop/src-tauri/src/lib.rs':'53ce147f3cf175371eefafdfc296363d8cf57f928f4609f35a527fb84a08b4f9','apps/desktop/src-tauri/src/main.rs':'85d95119a4ebcfeb4122020a8d33a0e62eb9e850721a53c64b0fd07e5807bce3'}
for phase in ['pure-actual-v2','composed-collection-actual-v1']:
 s=js(phase+'/source-before.json');ck(phase+'2255runtime40 fully neutral endpoints',s==js(phase+'/source-after.json') and len(s['source'])==2255 and len(s['runtime'])==40);ck(phase+'exact f5a2M context',s['head']=='f5a05bad78d8421a5c1e0094eb928fdbb464cdc7' and s['tree']=='aa9fbaa9addd16052eaeca6259852bc00bb03702' and set(l[3:] for l in s['status'].splitlines())==set(native))
 for n,r in s['source'].items():
  ck(phase+' sourceimmutablebody '+n,r['sha256']==(native[n] if n in native else immutable[n]['sha256']));ck(phase+' sourceGitexecuteclass '+n,bool(int(r['mode'],8)&0o111)==(immutable[n]['git_mode']=='100755'))
 ck(phase+' all25 controlled inputs neutral',js(phase+'/inputs-before.json')==js(phase+'/inputs-after.json'))
 for r in js(phase+'/commands.json'):
  ck(phase+' command '+r['name'],r['exit_code']==0 and r['direct_child_reaped'] and r['owned_group_absent'] and not r['timed_out'] and not r['signals'])
  for stream in ['stdout','stderr']:ck(phase+' raw '+r['name']+stream,sha((P/phase/(r['name']+'.'+stream)).read_bytes())==r[stream+'_sha256'])
 closure=js(phase+'/closure.json');ck(phase+'closure noactors',closure['failure'] is None and closure['source_runtime_full_modes_status_head_tree_equal'] and all(closure[k]==0 for k in ['native_calls','VMs','media_downloads','product_actors']))
ck('actual147PASS','147 passed' in (P/'pure-actual-v2/01-fixtures.stdout').read_text());ids=[l for l in (P/'pure-actual-v2/07-exact-collection.stdout').read_text().splitlines() if l.startswith('scripts/tests/') and '::' in l];oldids=[l for l in (V/'pure-actual-v10/07-exact-collection.stdout').read_text().splitlines() if l.startswith('scripts/tests/') and '::' in l];ck('exact147 original runtime IDs',len(ids)==len(set(ids))==147 and ids==oldids)
full=[l for l in (P/'composed-collection-actual-v1/03-full-collection.stdout').read_text().splitlines() if l.startswith(('scripts/','packages/','services/')) and '::' in l];prior=[l for l in (V/'composed-collection-actual-v2/03-full-collection.stdout').read_text().splitlines() if l.startswith(('scripts/','packages/','services/')) and '::' in l];ck('exact2624 full original catalog IDs',len(full)==len(set(full))==2624 and full==prior);ck('catalog byte exact parent',files['scripts/python-test-inventory.v1.json']==old['scripts/python-test-inventory.v1.json'])
r=next(r for r in js('composed-collection-actual-v1/commands.json') if r['name']=='05-common-win32-typeanalysis');ck('prospective common win32 typeanalysis92PASS','Success: no issues found in 92 source files' in (P/'composed-collection-actual-v1/05-common-win32-typeanalysis.stdout').read_text());registry=json.loads(files['scripts/verification-suites.json']);suite=next(s for s in registry['suites'] if s['id']=='typecheck');shared=next(c for c in suite['commands'] if c[:3]==['uv','run','mypy'] and '--platform' not in c);actual=r['argv'];start=actual.index('--cache-dir');normalized=actual[start+2:];ck('all exact unchanged common source targets',normalized==shared[3:] and 'scripts/tests' in normalized and actual[actual.index('--platform')+1]=='win32');ck('whole portability actualPASS','PASS: portability policy validated' in (P/'composed-collection-actual-v1/06-whole-portability.stdout').read_text())
(O/'data-audit.json').write_text(json.dumps({'scope':'different finite source/retained-data correction review; no subject import or actors','passed':len(C),'checks':C},indent=2)+'\n');print(json.dumps({'passed':len(C)}))
