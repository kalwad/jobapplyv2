from pathlib import Path
import difflib,hashlib,json,shutil
base=Path('/tmp/japp-owner-external-waiver');history=base/'history/proposal-001'
if history.exists():raise SystemExit('Refusing to overwrite proposal history')
history.mkdir(parents=True)
for name in ['governance-proposal.patch','proposal-manifest.json','owner-authority-record.json','owner-authority-lines.json','accepted-adr-0007.md','accepted-owner-record.preimage.bin']:
 shutil.copy2(base/name,history/name)
shutil.copytree(base/'afterimages',history/'afterimages')
p=base/'afterimages/docs/DECISIONS.md';s=p.read_text()
s=s.replace('2026-10-16; ADR-0006 |\n\n| OD-036','2026-10-16; ADR-0006 |\n| OD-036',1)
s=s.replace('no numerical threshold or compatibility change |\n\n| ADR-0007','no numerical threshold or compatibility change |\n| ADR-0007',1)
p.write_text(s)
p=base/'afterimages/docs/TEST_EVIDENCE.md';s=p.read_text()
s=s.replace('Neither accepted waiver promotes a milestone or supplies a future gate verdict.\n\n\n\n\n\n#### Scoped corrective closeout','Neither accepted waiver promotes a milestone or supplies a future gate verdict.\n\n#### Scoped corrective closeout',1)
p.write_text(s)
manifest=json.loads((base/'proposal-manifest.json').read_text());paths=[x['path'] for x in manifest['paths']]
patch=''
for relative in paths:
 pre=(base/'preimages'/relative).read_bytes();post=(base/'afterimages'/relative).read_bytes()
 patch+=f'diff --git a/{relative} b/{relative}\n'
 patch+=''.join(difflib.unified_diff(pre.decode().splitlines(True),post.decode().splitlines(True),fromfile='a/'+relative,tofile='b/'+relative))
 for item in manifest['paths']:
  if item['path']==relative:item['afterimage_sha256']=hashlib.sha256(post).hexdigest()
(base/'governance-proposal.patch').write_text(patch)
manifest['format_version']='ADR0007_EXTERNAL_EVIDENCE_GOVERNANCE_PROPOSAL_2'
manifest['previous_proposal']='history/proposal-001/governance-proposal.patch'
manifest['previous_proposal_sha256']=hashlib.sha256((history/'governance-proposal.patch').read_bytes()).hexdigest()
manifest['patch_sha256']=hashlib.sha256((base/'governance-proposal.patch').read_bytes()).hexdigest()
manifest['patch_bytes']=(base/'governance-proposal.patch').stat().st_size
(base/'proposal-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(manifest['patch_sha256'],manifest['patch_bytes'])
