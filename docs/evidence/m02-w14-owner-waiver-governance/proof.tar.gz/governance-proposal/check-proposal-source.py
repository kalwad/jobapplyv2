from pathlib import Path, PurePosixPath
import hashlib,json,re,tarfile
root=Path('/Users/tanishkalwad/jobapplyv2');base=Path('/tmp/japp-owner-external-waiver')
manifest=json.loads((base/'proposal-manifest.json').read_text())
checks={}
checks['nine_document_only_scope']=len(manifest['paths'])==9 and all(x['path'].endswith('.md') and x['path'].startswith('docs/') for x in manifest['paths'])
checks['root_all_nine_preimages_still_exact']=all((root/x['path']).read_bytes()==(base/'preimages'/x['path']).read_bytes() for x in manifest['paths'])
def table_states(text):
 return [tuple(c.strip() for c in line.strip('|').split('|'))[:2] for line in text.splitlines() if re.match(r'^\| `?M\d{2}(?:-W\d{2})?`? \|',line)]
checks['all_milestone_package_states_unchanged']=table_states((base/'preimages/docs/PROJECT_STATUS.md').read_text())==table_states((base/'afterimages/docs/PROJECT_STATUS.md').read_text())
checks['critical_gate_table_unchanged']=(base/'preimages/docs/PROJECT_STATUS.md').read_text().split('## Critical gates\n',1)[1].split('## Active work',1)[0]==(base/'afterimages/docs/PROJECT_STATUS.md').read_text().split('## Critical gates\n',1)[1].split('## Active work',1)[0]
for rel in ['docs/CRITICAL_GATES.md','docs/gates/AUTOFILL_FEASIBILITY_GATE.md','docs/gates/RESUME_PAGEFIT_FEASIBILITY_GATE.md','docs/gates/WORKDAY_GUIDED_PRE_SUBMIT_GATE.md']:
 pre=(base/'preimages'/rel).read_text();post=(base/'afterimages'/rel).read_text()
 checks['unchanged_lifecycle_and_owner_fields:'+rel]=re.findall(r'^- (?:State|Owner decision|Independent reviewer):.*$',pre,re.M)==re.findall(r'^- (?:State|Owner decision|Independent reviewer):.*$',post,re.M)
pre_dec=(base/'preimages/docs/DECISIONS.md').read_text();post_dec=(base/'afterimages/docs/DECISIONS.md').read_text()
def accepted_adr6(text):
 row=re.findall(r'^\| OD-035 \|.*$',text,re.M);section=re.search(r'^### ADR-0006\b[^\n]*\n.*?(?=^##(?:#)? |\Z)',text,re.M|re.S).group().rstrip('\n')+'\n'
 return b'japp-owner-holdout-waiver-v1\0'+(row[0]+'\n'+section).encode()
checks['adr6_exact_existing_preimage_unchanged']=accepted_adr6(pre_dec)==accepted_adr6(post_dec)
authority=json.loads((base/'owner-authority-lines.json').read_text())
checks['exact_unique_adr7_authority_lines']=all(post_dec.splitlines().count(value)==1 for value in authority.values())
checks['accepted_adr7_not_quoted_gate_pass']=post_dec.count('### ADR-0007 —')==1 and '- Status: ACCEPTED' in (base/'accepted-adr-0007.md').read_text() and 'final gate verdict' in authority['decision']
checks['zero_pending_tokens']=not re.search(r'__PENDING_[A-Z0-9_]+__',(base/'governance-proposal.patch').read_text())
root_authority=json.loads((base/'owner-authority-record.json').read_text())
checks['master_exact_original_unchanged']=hashlib.sha256((root/'docs/MASTER_IMPLEMENTATION_SPEC.md').read_bytes()).hexdigest()==root_authority['master_spec_sha256']
for gate,fields in [('AUTOFILL_FEASIBILITY',['Simplify comparison result','Public-form evidence result']),('RESUME_PAGEFIT_FEASIBILITY',['Simplify comparison result']),('WORKDAY_GUIDED_PRE_SUBMIT',['Simplify comparison result','Public-form evidence result'])]:
 ledger=(base/'afterimages/docs/CRITICAL_GATES.md').read_text().split('## '+gate+'\n',1)[1].split('\n## ',1)[0]
 report=(base/'afterimages/docs/gates'/(gate+'_GATE.md')).read_text()
 checks['exact_paired_waiver_fields:'+gate]=all(ledger.splitlines().count('- '+field+': WAIVED_BY_OWNER_ADR_0007')==1 and report.splitlines().count(field+': WAIVED_BY_OWNER_ADR_0007')==1 for field in fields)
ci=root/'docs/evidence/m02-w14-1d490d-ci/proof.tar.gz';data=ci.read_bytes()
with tarfile.open(ci,'r:gz') as archive:members=archive.getmembers()
ci_record={'path':str(ci.relative_to(root)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'regular_members':len(members),'safe_unique_regular':len(set(m.name for m in members))==len(members) and all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in members)}
checks['quoted_exact1d_native_archive_binding']=ci_record['sha256']=='6a95092246555fe34d41e106fe7ce46c4166820948f17cdeb2ad94270c875dff' and ci_record['bytes']==878591 and ci_record['regular_members']==94 and ci_record['safe_unique_regular']
report={'format_version':'ADR0007_PROPOSAL_SOURCE_CHECKS_1','scope':'Read-only proposal bytes/lifecycle/authority/pairing and native archive-reference inspection; not executed repo tests or a substitute for independent source/machine acceptance review.','checks':checks,'all_checks_pass':all(checks.values()),'adr6_source_record_digest':'sha256:'+hashlib.sha256(accepted_adr6(pre_dec)).hexdigest(),'adr7_source_record_audit_digest':root_authority['record_digest_for_audit'],'native_archive_reference':ci_record,'root_mutations_tests_builds_browsers':0}
(base/'proposal-source-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
if not report['all_checks_pass']:raise SystemExit('Proposal source check failed')
