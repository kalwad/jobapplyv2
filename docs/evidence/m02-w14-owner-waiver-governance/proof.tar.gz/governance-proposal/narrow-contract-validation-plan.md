# ADR-0007 narrow acceptance and validation plan

This is a source-only plan, not an executed test report. Validation owns the outside implementation proposal; root is the only checkout writer.

The existing canonical gate v2 schemas do not need alteration: they do not encode Simplify/public-form sources as dedicated flags. Preserve every frozen schema, expected corpus, scored result, required nonwaived benchmark reference and completeness check. Add source-aware recognition only for the agreed paired narrative labels `Simplify comparison result` and `Public-form evidence result`, with exact token `WAIVED_BY_OWNER_ADR_0007`. Gate A/C use both; Gate B's Simplify obligation uses its relevant field. This authority grants no gate verdict.

Bind one unique accepted ADR-0007 heading/section, OD-036 row, exact direct owner quote, Decision and closed Waiver scope. `owner-authority-lines.json` provides the exact agreed strings. `accepted-owner-record.preimage.bin` and `owner-authority-record.json` supply a versioned audit digest; the narrative convention does not accept a caller digest as independent authority. Preserve ADR-0006's exact existing accepted authority and schema semantics.

Meaningful cases to retain/add:

- Exact accepted authority plus correctly paired applicable waiver fields is recognized; observed public/Simplify cases remain zero and no schema/corpus/current state is relabelled passed.
- Missing, proposed, rejected, superseded or duplicated ADR/OD; altered owner quote, Decision or scope; a different owner record; symlink/unreadable/malformed source; and forged token variants fail closed.
- One-sided, missing, duplicated, stale or conflicting ledger/report waiver fields, including token strings containing PASS/execution claims, fail closed.
- Neither waiver removes controlled/absolute numeric or physical-safety checks, legacy/other benchmark refs, runtime/corpus/evidence bindings, actual native/platform/packaging checks, independent review or concrete source-bound owner decision. Positive waiver fixtures with each of those obligations removed remain invalid through existing acceptance checks.
- Adding unrelated future ADR text does not invent or remove this exact authority, and adding ADR-0007 preserves the existing ADR-0006 authority bytes/digest.
- Mixed requirements retain actual task usability, accessibility, owner visual approval, originality/non-affiliation and public UI-reference work. Only direct Simplify-relative and public-form-execution components are waived.
- Current W14/Gate A stay IN_PROGRESS; W15/M03 stay NOT_STARTED,31 packages VERIFIED and no READY package until remaining applicable audits actually clear.

After reviewed integration, root should run new focused validator tests, the full status suite, applicable static/type/format checks, status validation and traceability checks; then perform the required affected verification at the new source. Historical exact1d CI/native results do not certify new waiver/validator bytes. Record only actual commands/results after execution. No product regression should be removed or rewritten to match a waiver.

Owner-decision nuance: continuous execution authorizes work and this accepted amendment. It does not establish a source-bound final Gate A PASS for an unknown future W15 verdict. Existing canonical owner_decision_state COMPLETE and paired narrative Owner decision PASS requirements remain in force; resolve that concrete record after the eligible independent verdict exists.
