from pathlib import Path
import difflib, hashlib, json, re, shutil
root=Path('/Users/tanishkalwad/jobapplyv2')
base=Path('/tmp/japp-owner-external-waiver')
paths=['docs/DECISIONS.md','docs/PROJECT_STATUS.md','docs/KNOWN_ISSUES.md','docs/CRITICAL_GATES.md','docs/gates/AUTOFILL_FEASIBILITY_GATE.md','docs/gates/RESUME_PAGEFIT_FEASIBILITY_GATE.md','docs/gates/WORKDAY_GUIDED_PRE_SUBMIT_GATE.md','docs/COMPATIBILITY_MATRIX.md','docs/TEST_EVIDENCE.md']
if (base/'preimages').exists():raise SystemExit('Refusing to overwrite first proposal preimages')
for relative in paths:
 for part in ('preimages','afterimages'):
  target=base/part/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/relative,target)
heading='### ADR-0007 — Direct Simplify comparison and executed public-form evidence waiver'
owner_row='| OD-036 | Waive direct Simplify comparison and executed public-form evidence throughout the project; preserve all other completion, safety, measurement and review requirements. Continue until the project is finished and validated. | ACCEPTED | Owner message 2026-10-17; ADR-0007 |'
approval='- Owner approval: direct instruction in this chat on 2026-10-17: "Waive the Simplify comparison and public-form evidence requirements too. Keep going through all remaining milestones until the entire project is finished and validated."'
decision='- Decision: remove direct Simplify comparison and executed public-form evidence as completion prerequisites throughout this project. Record the affected requirements as WAIVED_BY_OWNER under OD-036 / ADR-0007; preserve actual historical outcomes and never relabel nonexecution as PASS. Continue successive eligible packages under ADR-0006 without per-W stopping. Numerical accuracy, safety and performance thresholds, controlled-corpus execution, native-platform proof, independent review, other comparison baselines, product capabilities, actual usability, accessibility, visual approval and all other non-comparison requirements remain binding. This decision grants no public ATS support, superiority claim or final gate verdict.'
scope='- Waiver scope: DIRECT_SIMPLIFY_COMPARISON and EXECUTED_PUBLIC_FORM_EVIDENCE only, project-wide. Only the directly comparative Simplify component of a mixed requirement is waived; public-form evidence means execution-based validation on third-party public application forms, including public no-submit/dry-run requirements. Other components remain required. Public UI-reference observation, actual Simplify-experienced-user task studies, accessibility, visual approval and originality/non-affiliation requirements are not waived.'
adr='\n'.join([
heading,'','- Status: ACCEPTED','- Date proposed / date decided: 2026-10-17 / 2026-10-17',approval,decision,scope,
'- Observed constraint: M02-W14 retains zero scored public-form cases and zero direct Simplify cases despite real public attempts and readiness inspection. The owner explicitly removes these two external evidence prerequisites and instructs continuous completion. Existing local/native/legacy observations retain their exact source and scope.',
'- Alternatives considered: retain the two prerequisites contrary to the owner; falsely relabel missing observations as passed; record the narrow accepted waiver while retaining all other requirements, selected.',
'- Tradeoffs: direct competitor-relative and public-form generalization assurance is absent for waived observations. Controlled results do not become public-form results, and missing comparator outcomes cannot establish parity, superiority or production ATS support.',
'- Security/privacy impact: no authorization to automate credentials, bypass CAPTCHA/access/consent boundaries, expose private application data, submit unapproved applications, or copy competitor code/assets. Existing no-submit and uncertainty safeguards remain binding.',
'- Data-migration impact: none. Preserve frozen manifests, inputs, raw outcomes, comparison history, originally approved master-specification bytes and completed package anchors.',
'- Benchmark and gate impact: only the two named evidence categories and directly comparative Simplify metric components are WAIVED_BY_OWNER_ADR_0007, not executed or passed. Absolute/controlled numerical accuracy, safety and performance thresholds, legacy/other baselines and complete affected regression remain required. Every critical gate still requires source-bound independent review and its concrete owner decision. This record neither supplies nor conditionally preapproves an unknown future gate verdict.',
'- Test impact: preserve all product regressions, native-platform validation and frozen canonical schema/corpus bytes. Add narrow source-aware recognition of the exact accepted OD/ADR and paired waiver fields; reject missing, proposed, duplicate, forged, stale or one-sided authority and any execution/PASS substitution. Existing holdout authority under ADR-0006 remains unchanged. No blanket skip, expected-result rewrite or completeness bypass is authorized.',
'- Contract precedence: this subsequent owner override amends the originally approved v1.4 requirements without rewriting their exact bytes or reviewed traceability mappings. Mixed work packages retain every nonwaived deliverable. Continue eligible validated work; do not promote W14, start W15, accept M02 or pass Gate A before their remaining applicable evidence and review are complete.',
'- Rollback plan: only a later explicit owner decision can restore the waived prerequisites. Preserve original manifests, readiness records and actual attempts so renewed execution remains possible.',
'- Spec sections, requirements, milestones, schemas, gates, and compatibility promises affected: direct Simplify/public-form evidence portions of §2.2/§2.3/§5/§8/§9/§12, REQ-RES-016, REQ-WD-021, REQ-GATE-002/004/016 and mixed comparison work in M02/M05/M19–M20/M28/M38; the project-wide waiver does not remove any product capability or the non-comparison portions of familiarity/usability/visual requirements. No canonical schema or measured compatibility/support claim changes.',
])+'\n'
p=base/'afterimages/docs/DECISIONS.md';s=p.read_text()
if 'OD-036' in s or '### ADR-0007' in s:raise SystemExit('Next decision ID is already used')
s=s.replace('\n## Architecture decision records\n','\n'+owner_row+'\n\n## Architecture decision records\n',1)
adr_row='| ADR-0007 | Direct Simplify comparison and executed public-form evidence waiver | ACCEPTED | 2026-10-17 | Only direct Simplify/public-form evidence prerequisites project-wide; all other requirements and concrete gate decisions preserved |'
s=s.replace('\n### ADR-0001 —', '\n'+adr_row+'\n\n### ADR-0001 —',1)
s=s.replace('\n## ADR template\n','\n'+adr+'\n## ADR template\n',1);p.write_text(s)
(base/'accepted-adr-0007.md').write_text(adr)
(base/'owner-authority-lines.json').write_text(json.dumps({'heading':heading,'owner_row':owner_row,'approval':approval,'decision':decision,'scope':scope},indent=2)+'\n')

p=base/'afterimages/docs/PROJECT_STATUS.md';s=p.read_text()
s=s.replace('Repository revision: M02-W14 scoped corrective closeout; clean730 full/R9 pass and nativefc CI pass; next final-head CI pending','Repository revision: M02-W14; accepted ADR-0007 external-evidence waiver; historical exact1d native CI passes; remaining W14/W15 review pending',1)
s=s.replace('Last updated: 2026-10-16T23:43:00Z','Last updated: 2026-10-17',1)
lines=s.splitlines()
for i,line in enumerate(lines):
 if line.startswith('- Latest native platform evidence:'):
  lines[i]='- Latest native platform evidence: exact1d490d1230b443c31fd4a9d8732064552affe149 CI run38984225730/attempt1 SUCCESS on Ubuntu/macOS/Windows; tested merged8de57146b6ef183cf6229701e5089c904175ce9/treeac98b18d71fffc6cc0ff7fc07ccd32ccda8133d9 equals1d. All19 suites pass; Python Ubuntu1454/456.26s, macOS1454/407.38s, Windows1452/726.21s with only declared FIFO/socket capability differences. Each includes status201/contact11/contracts2524/compiler8 twice/browser242/controlled62 plus2 inspection cases and tracked-clean. Native proof is docs/evidence/m02-w14-1d490d-ci; independent archive27 review is clear. CI sample1/settle0, including macOS1662.458292ms, is not local target20 evidence. This historical exact1d result does not certify later waiver source changes; old stackless contact F remains UNPROVEN.'
 elif line.startswith('- Remaining evidence:'):
  lines[i]='- Remaining evidence: direct Simplify comparison and executed public-form evidence are WAIVED_BY_OWNER_ADR_0007 under accepted OD-036; actual cases remain0 and no public support or competitor parity/superiority is inferred. KI-0089 remains OPEN for final eligible independent W15/source-bound owner Gate A decision. Remaining W14 audit/closeout must clear first; the waiver itself promotes no package or gate. Other numerical/safety/performance/controlled/native/legacy/usability/accessibility/visual requirements remain binding.'
 elif line.startswith('- Owner instruction (OD-035 / ADR-0006):'):
  lines[i]='- Owner instructions: OD-035 / ADR-0006 waives owner-controlled holdout and per-W stopping; OD-036 / ADR-0007 waives only direct Simplify comparison and executed public-form evidence project-wide. Continue successive eligible validated packages. Neither record supplies executed results, a final independent verdict or an unknown future owner gate PASS.'
s='\n'.join(lines)+'\n'
s=s.replace('Clean730 full and actualR9 pass; nativefc CI closes fixture scope; public/Simplify/formalW15 incomplete, holdout waived','Clean730 full/actualR9 and exact1d native CI pass; direct Simplify/public-form evidence waived; remaining W14 audit/formalW15 decision pending',1)
s=s.replace('- KI-0089 (HIGH, OPEN) — Gate A public scored coverage, actual Simplify comparison and final independent review/decision remain incomplete.','- KI-0089 (HIGH, OPEN) — Direct Simplify/public-form portions are waived by ADR-0007; final eligible independent review and source-bound Gate A owner decision remain incomplete.',1)
p.write_text(s)

p=base/'afterimages/docs/KNOWN_ISSUES.md';s=p.read_text()
s=s.replace('ADR-0006 waives owner-controlled holdout only; public/Simplify/scoped legacy comparisons and independent review are not passed by that waiver.', 'ADR-0006 waives owner-controlled holdout; accepted ADR-0007 additionally waives direct Simplify comparison and executed public-form evidence. Neither waiver supplies execution or PASS. Scoped legacy baselines, all nonwaived measurement and independent review remain required.',1)
a=s.index('### KI-0089 —');b=s.index('\n### KI-0090 —',a)
old=s[a:b]
new='''### KI-0089 — Gate A final independent review and decision remain incomplete

- Severity: HIGH
- State: OPEN
- Discovered: 2026-10-16 during M02-W14 final evidence reconciliation
- Affects: M02-W14; M02-W15; M02 acceptance and Autofill Feasibility Gate
- Description: accepted OD-036 / ADR-0007 waives the direct Simplify comparison and executed public-form evidence portions of this finding. Actual public scored cases and direct Simplify cases remain0, not PASS. Final eligible independent W15 review and the concrete source-bound owner Gate A decision remain incomplete; remaining W14 audit/closeout must clear before that final review.
- Reproduction: inspect current W14/W15/package/gate states and the pending independent-review/owner-decision sections. Historical public attempts, Simplify readiness, original missing-observation finding and all supplemental review records remain retained below. No downstream readiness follows from this waiver.
- Workaround: only the two external evidence prerequisites are WAIVED_BY_OWNER_ADR_0007; owner holdout remains waived by ADR-0006. Preserve all numerical, safety, controlled/native, other-baseline, usability/accessibility/visual and review obligations, along with CAPTCHA/authentication/consent/transport/no-submit boundaries.
- Resolution + evidence link: OPEN for the nonwaived independent review and source-bound gate decision. Complete the remaining applicable W14 audit/closeout, then execute eligible M02-W15 against exact evidence and record its actual verdict; the continuous-work instruction supplies no fabricated verdict. See accepted ADR-0007, docs/CRITICAL_GATES.md and docs/gates/AUTOFILL_FEASIBILITY_GATE.md.
- Historical finding before the 2026-10-17 waiver:

'''+old.replace('### KI-0089 — Gate A has incomplete externally executed evidence\n\n','',1).replace('- Severity: HIGH\n- State: OPEN\n- Discovered: 2026-10-16 during M02-W14 final evidence reconciliation\n- Affects: M02-W14; M02-W15; M02 acceptance and Autofill Feasibility Gate\n','',1)
s=s[:a]+new+s[b:];p.write_text(s)

p=base/'afterimages/docs/CRITICAL_GATES.md';s=p.read_text()
anchor='- Any change to gate-relevant components triggers the complete affected\n'
waiver_rule='- Direct Simplify comparison and executed public-form evidence requirements are\n  WAIVED_BY_OWNER_ADR_0007 under accepted OD-036 / ADR-0007 project-wide.\n  These are nonexecution assessments, not passing observed results. Mixed\n  requirements retain all other components; controlled/absolute thresholds,\n  native evidence, other baselines, actual usability/accessibility/visual\n  approval and source-bound independent/owner gate decisions remain required.\n'
s=s.replace(anchor,waiver_rule+anchor,1)
a=s.index('## AUTOFILL_FEASIBILITY\n');b=s.index('\n### Metric table',a)
block=s[a:b]
old_start=block.index('- Known limitations:')
block=block[:old_start]+'''- Known limitations: controlled clean730 full and actualR9 evidence and exact1d
  native CI are separately retained; the remaining W14 audit and formal W15
  decision are not inferred from those proofs. Actual scored public-form and
  direct Simplify cases remain0, with only those prerequisites waived below.
  Other feature/measurement scopes remain limited to their actual evidence.
- Simplify comparison result: WAIVED_BY_OWNER_ADR_0007
- Public-form evidence result: WAIVED_BY_OWNER_ADR_0007
- Next permitted action: finish remaining applicable M02-W14 audit/closeout,
  then run independent eligible M02-W15 on exact final evidence. M03 stays
  NOT_STARTED until actual Gate A PASS and M02 acceptance.
'''
s=s[:a]+block+s[b:]
for dimension in ['Greenhouse/Lever/Workday research comparison versus Simplify','Simplify comparison','Manual corrections versus Simplify on the same certified matrix']:
 lines=s.splitlines()
 for i,line in enumerate(lines):
  if line.startswith('| '+dimension+' |') and line.endswith('| — |'):lines[i]=line[:-len('| — |')]+'| WAIVED_BY_OWNER_ADR_0007 (not executed or passed) |'
 s='\n'.join(lines)+'\n'
for gate,fields in [('RESUME_PAGEFIT_FEASIBILITY',['Simplify comparison result']),('WORKDAY_GUIDED_PRE_SUBMIT',['Simplify comparison result','Public-form evidence result'])]:
 start=s.index('## '+gate+'\n');end=s.find('\n## ',start+1);end=len(s) if end==-1 else end
 block=s[start:end];marker='- Independent review: pending.'
 if block.count(marker)!=1:raise SystemExit('Unexpected gate pending marker '+gate)
 block=block.replace(marker,'\n'.join('- '+field+': WAIVED_BY_OWNER_ADR_0007' for field in fields)+'\n'+marker,1)
 s=s[:start]+block+s[end:]
p.write_text(s)

for relative,fields in [('docs/gates/AUTOFILL_FEASIBILITY_GATE.md',['Simplify comparison result','Public-form evidence result']),('docs/gates/RESUME_PAGEFIT_FEASIBILITY_GATE.md',['Simplify comparison result']),('docs/gates/WORKDAY_GUIDED_PRE_SUBMIT_GATE.md',['Simplify comparison result','Public-form evidence result'])]:
 p=base/'afterimages'/relative;s=p.read_text()
 if relative.endswith('AUTOFILL_FEASIBILITY_GATE.md'):
  s=s.replace('- Evaluated revision: clean730 local full and actualR9 pass; nativefc three-OS CI separately passes. These close scoped corrective issues only. Final W14/W15/owner Gate A acceptance and next final-head native CI remain pending; older source observations remain historical.', '- Evaluated revision: retained clean730 local full/actualR9 and exact1d native three-OS CI are separate completed scopes. The accepted 2026-10-17 evidence waiver supplies no new execution or final W14/W15/owner Gate A verdict; remaining review is pending.',1)
  s=s.replace('The complete numerical and zero-tolerance table in spec §2.3 remains in force. OD-035 / ADR-0006 waives owner-controlled hidden holdout and per-package stopping only. Visible corpus, physical safety, accuracy, full-settlement performance, actual public/Simplify/legacy comparison and independent-review obligations remain individually reportable. No threshold is weakened to obtain PASS.', 'The numerical and zero-tolerance requirements outside the expressly waived comparison/public-form categories remain in force. OD-035 / ADR-0006 waives owner-controlled holdout/per-W stopping; OD-036 / ADR-0007 waives only direct Simplify comparison and executed public-form evidence. Visible controlled corpus, physical safety, absolute accuracy/performance, other baselines and independent/source-bound owner review remain required. No unexecuted observation becomes PASS.',1)
  s=s.replace('## Supplemental comparison and public preparation','## Historical supplemental comparison and public preparation',1)
  s=s.replace('## Current scoped corrective closeout — 2026-10-16','## Historical scoped corrective closeout — 2026-10-16',1)
 else:
  s=s.replace('waived (spec §1.4.6, §2.3 gate decision rules).','waived without an accepted owner decision (spec §1.4.6, §2.3 gate decision rules); the two accepted ADR-0007 exceptions are recorded separately below.',1)
  if relative.endswith('WORKDAY_GUIDED_PRE_SUBMIT_GATE.md'):
   s=s.replace('- Public no-submit structural dry-run inventory (sanitized).','- Public no-submit structural dry-run inventory: WAIVED_BY_OWNER_ADR_0007; preserve any actual historical observations.',1)
   s=s.replace('- Same-input manual Simplify comparison worksheets.','- Same-input manual Simplify comparison: WAIVED_BY_OWNER_ADR_0007; other baselines remain required.',1)
 waiver='## Accepted owner evidence waiver — 2026-10-17\n\n'+'\n'.join(field+': WAIVED_BY_OWNER_ADR_0007' for field in fields)+'\n\n'
 waiver+='Accepted OD-036 / ADR-0007 removes only direct Simplify comparison and executed public-form evidence prerequisites project-wide. These assessments are not executed or passed observations and provide no public ATS support or competitor parity/superiority claim. Other components of mixed requirements, controlled/absolute thresholds, actual usability/accessibility/visual approval, other baselines, native proof and independent/source-bound owner gate decisions remain required. Original specification, frozen corpus and historical records stay unchanged. This record changes no package/gate state.\n\n'
 if relative.endswith('AUTOFILL_FEASIBILITY_GATE.md'):
  waiver+='Current public scored cases and direct Simplify cases remain0. Their historical attempts/readiness records below remain exact. KI-0089 is OPEN for final eligible independent W15/source-bound owner decision; remaining W14 audit/closeout must clear first. Continuous execution authorizes progressing eligible validated work and does not grant a fabricated unknown future verdict.\n\n'
 anchor='## Historical development evaluation runs' if relative.endswith('AUTOFILL_FEASIBILITY_GATE.md') else '## Evaluation runs'
 s=s.replace(anchor,waiver+anchor,1);p.write_text(s)

p=base/'afterimages/docs/COMPATIBILITY_MATRIX.md';s=p.read_text()
anchor='## M02-W14 research observations (non-support claims, 2026-10-16)'
notice='''## Owner evidence waiver — 2026-10-17

Direct Simplify comparison and executed public-form evidence prerequisites are WAIVED_BY_OWNER_ADR_0007 under accepted OD-036 / ADR-0007. Actual direct Simplify/public scored cases remain0. Historical rows below retain their observations and source bindings; their older pending-prerequisite language is historical. A waiver grants no public ATS support, compatibility, parity or superiority. Production support rows still require their nonwaived measured fixture/controlled evidence, versions, scoped compatibility record and applicable gate decision. Product capabilities, controlled/native verification and other baselines remain required.

'''
s=s.replace(anchor,notice+anchor,1);p.write_text(s)

p=base/'afterimages/docs/TEST_EVIDENCE.md';s=p.read_text();anchor='### M02-W14 — Visible development campaigns and supplemental comparison preparation (2026-10-16)'
notice='''#### Accepted external-evidence waiver and exact1d native CI scope — 2026-10-17

The owner's direct instruction is recorded as accepted OD-036 / ADR-0007 in docs/DECISIONS.md. Direct Simplify comparison and executed public-form evidence are WAIVED_BY_OWNER_ADR_0007; actual cases remain0. This is an authority/policy record, not a test execution or passing external observation. All original public attempts/readiness/raw scores and the originally adopted master-specification bytes remain unchanged. Other controlled/absolute accuracy, safety, performance, native, legacy-baseline, actual usability/accessibility/visual and independent/source-bound gate-decision requirements remain binding.

The exact prior head1d490d1230b443c31fd4a9d8732064552affe149 native CI run38984225730/attempt1 completes SUCCESS on all3 platforms; tested merged8de57146b6ef183cf6229701e5089c904175ce9/treeac98b18d71fffc6cc0ff7fc07ccd32ccda8133d9 equals1d. Ubuntu1454 Python/456.26s, macOS1454/407.38s and Windows1452/726.21s reconcile to the declared capability-gated FIFO/socket difference; status201/contact11/contracts2524/compiler8 twice/browser242/controlled62 plus2 inspection cases and all19 active suites/tracked-clean pass on each. Complete native proof: docs/evidence/m02-w14-1d490d-ci/proof.tar.gz, SHA-256 6a95092246555fe34d41e106fe7ce46c4166820948f17cdeb2ad94270c875dff,878591bytes/94 regular members/5118706payload bytes, with separate secondary archive review27/27. Source/API/raw reviews and original history remain retained alongside. CI timing is one sample/settle0; macOS1662.458292ms is an observed single sample, not a passing target20 result. Separately retained clean730 target20 p951447.4198340000003ms and full-settlement contact200 remain separate source/campaign scopes. The old stackless contact F cause remains UNPROVEN despite fresh success. This exact1d CI does not certify subsequent waiver/validator changes.

Narrow source-aware waiver validation and its focused tests must bind the exact accepted OD/ADR and the paired Simplify/public-form narrative fields while preserving all other completeness checks. This proposal records no not-yet-run implementation/test result. W14/Gate A remain IN_PROGRESS,31/300 packages VERIFIED, W15/M03 NOT_STARTED, no READY package and release NOT_READY while remaining W14 audit/closeout and formal eligible W15/source-bound owner decision are pending. Neither accepted waiver promotes a milestone or supplies a future gate verdict.

'''
s=s.replace(anchor,anchor+'\n\n'+notice,1);p.write_text(s)

# Record authority and preservation without importing or executing repo validators.
pre_dec=(base/'preimages/docs/DECISIONS.md').read_text();post_dec=(base/'afterimages/docs/DECISIONS.md').read_text()
def adr6_record(text):
 row=re.findall(r'^\| OD-035 \|.*$',text,re.M)
 match=re.search(r'^### ADR-0006\b[^\n]*\n.*?(?=^##(?:#)? |\Z)',text,re.M|re.S)
 if len(row)!=1 or match is None:raise SystemExit('Missing exact existing ADR6 authority')
 return row[0]+'\n'+match.group().rstrip('\n')+'\n'
if adr6_record(pre_dec)!=adr6_record(post_dec):raise SystemExit('Existing ADR6 authority changed')
preimage=b'japp-owner-external-evidence-waiver-v1\0'+(owner_row+'\n'+adr).encode()
authority={'heading':heading,'owner_row':owner_row,'approval':approval,'decision':decision,'scope':scope,'record_preimage_domain':'japp-owner-external-evidence-waiver-v1\\0','record_digest_for_audit':'sha256:'+hashlib.sha256(preimage).hexdigest(),'adr6_authority_unchanged':True,'master_spec_sha256':hashlib.sha256((root/'docs/MASTER_IMPLEMENTATION_SPEC.md').read_bytes()).hexdigest(),'master_spec_changed':False,'traceability_or_frozen_schema_changed':False,'actual_owner_gate_decision':'PENDING_SOURCE_BOUND_CONCRETE_VERDICT','package_and_gate_state_changes':False}
(base/'owner-authority-record.json').write_text(json.dumps(authority,indent=2)+'\n')
(base/'accepted-owner-record.preimage.bin').write_bytes(preimage)
patch='';entries=[]
for relative in paths:
 pre=(base/'preimages'/relative).read_bytes();post=(base/'afterimages'/relative).read_bytes()
 patch+=f'diff --git a/{relative} b/{relative}\n'
 patch+=''.join(difflib.unified_diff(pre.decode().splitlines(True),post.decode().splitlines(True),fromfile='a/'+relative,tofile='b/'+relative))
 entries.append({'path':relative,'preimage_sha256':hashlib.sha256(pre).hexdigest(),'afterimage_sha256':hashlib.sha256(post).hexdigest()})
(base/'governance-proposal.patch').write_text(patch)
manifest={'format_version':'ADR0007_EXTERNAL_EVIDENCE_GOVERNANCE_PROPOSAL_1','scope':'Accepted ADR0007/OD036 plus minimal current nine-document governance and exact1d native evidence reconciliation. No spec/traceability/schema/corpus/product source/test edits or package/gate promotion. Root sole writer.','state':'OUTSIDE_PROPOSAL_REQUIRES_NARROW_MACHINE_CONTRACT_AND_REVIEW_BEFORE_ROOT_APPLY','paths':entries,'patch_sha256':hashlib.sha256((base/'governance-proposal.patch').read_bytes()).hexdigest(),'patch_bytes':(base/'governance-proposal.patch').stat().st_size,'authority_record':'owner-authority-record.json','authority_record_sha256':hashlib.sha256((base/'owner-authority-record.json').read_bytes()).hexdigest(),'pending_tokens':sorted(set(re.findall(r'__PENDING_[A-Z0-9_]+__',patch))),'root_mutations_tests_builds_browsers':0}
(base/'proposal-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
