from pathlib import Path,PurePosixPath
import gzip,hashlib,io,json,tarfile
OUT=Path('/tmp/japp-owner-waiver-governance-retained-20261017')
assert not OUT.exists();OUT.mkdir()
payload={}
def sha(b):return hashlib.sha256(b).hexdigest()
def add(n,b):
 p=PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts and n not in payload;payload[n]=b
for prefix,root in [('governance-proposal',Path('/tmp/japp-owner-external-waiver')),('governance-peer',Path('/tmp/japp-owner-external-waiver-independent-review')),('root-integration',Path('/tmp/japp-owner-waiver-root-integration-20261017'))]:
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink(),p
  if p.is_file():add(prefix+'/'+p.relative_to(root).as_posix(),p.read_bytes())
assert 'root-integration/commands.json' in payload
commands=json.loads(payload['root-integration/commands.json']);assert len(commands['records'])==7 and all(x['exit_code']==0 for x in commands['records'])
add('source/retention-builder.py',Path(__file__).read_bytes())
rows=[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(payload.items())]
add('retained-members.json',(json.dumps({'files':rows},indent=2)+'\n').encode())
archive=OUT/'proof.tar.gz'
with archive.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as g:
  with tarfile.open(fileobj=g,mode='w',format=tarfile.PAX_FORMAT) as t:
   for n,b in sorted(payload.items()):
    info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b))
allrows=[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(payload.items())]
manifest={'archive_path':'proof.tar.gz','archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'regular_members':len(allrows),'files':allrows,'scope':'Exact owner ADR7 governance proposal/preimages/afterimages/history/authority plus independent governance review and actual root seven-command integration; no gate verdict or owner gate approval.'}
(OUT/'retention-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers();assert len(members)==len(allrows)
 for member,row in zip(members,allrows):
  assert member.isfile() and member.name==row['path'];b=t.extractfile(member).read();assert len(b)==row['bytes'] and sha(b)==row['sha256']
print(json.dumps({k:manifest[k] for k in ('archive_sha256','archive_bytes','regular_members')},indent=2))
