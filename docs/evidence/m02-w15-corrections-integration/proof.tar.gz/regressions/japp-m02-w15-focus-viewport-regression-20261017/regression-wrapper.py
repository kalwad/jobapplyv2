from __future__ import annotations

import argparse
import base64
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
NODE = "/opt/homebrew/opt/node@24/bin/node"
PNPM = "/opt/homebrew/opt/node@24/bin/pnpm"
HEAD = "507a7687b004937fbf0dc48e5e80a35d30fe9b6e"
TREE = "235bc696fb37e887b5efa817039276a775a18e2e"
NEW_TEST = "e2e/extension/extension-w15-focus-viewport.spec.ts"
NEW_TEST_SHA = "bfa455c32f082067c286ae7a1536cd3e3b1bf4bec5c4da8ba71e7df2e13857d1"
LEAF = "apps/extension/src/drivers/text-like-drivers.ts"
LEAF_SHA = {
    "red": "91756f25933420b515a974021cd7c4cf6c06795656b7eec10763cadbe1a1d923",
    "green": "8e3c5ca6b4ea217e765edebd7fbdafb8aaca88e631de4453a8b6668657fbd755",
}
PREFIXES = [
    "W15 native ",
    "preserves current value",
    "fresh native validity ",
    "TX1/TEXT1/TEXT2/UNDO1:",
    "SEL1/RAD1/CHK1/DATE1:",
    "TX2/TX3/TX4/TX5/TX6:",
    "FW1/FW2:",
    "FW3/VAL1/VAL2/DATE2:",
    "TX7:",
    "UNDO2 and frame/document authority:",
    "W14 peer: focus slot reassignment to Employer refuses an approved applicant write",
    "W13 index: mutation during awaited descriptor hashing refuses obsolete global uniqueness",
    "ROOT2/GEN2: replacing the application root invalidates old state and stale addresses cannot authorize a current action",
]
GREEN_COUNTS = {
    "extension-w15-focus-viewport.spec.ts": 4,
    "extension-w14-focus-value.spec.ts": 8,
    "extension-w14-native-validity.spec.ts": 6,
    "extension-drivers.spec.ts": 7,
    "extension-w14-shadow-peer.spec.ts": 1,
    "extension-semantic-index.spec.ts": 1,
    "extension-dynamic.spec.ts": 1,
}


def now():
    return dt.datetime.now(dt.UTC).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


parser = argparse.ArgumentParser()
parser.add_argument("stage", choices=["red", "green"])
parser.add_argument("action", choices=["prepare", "run"])
args = parser.parse_args()
STAGE = args.stage
CLONE = BASE / STAGE / "clone"
PROOF = BASE / STAGE / "proof"
PROOF.mkdir(exist_ok=True)
ENV = dict(os.environ)
ENV["PATH"] = "/opt/homebrew/opt/node@24/bin:" + ENV.get("PATH", "")
ENV.pop("JAPP_W13_PERFORMANCE_SAMPLES", None)
ENV["PLAYWRIGHT_JSON_OUTPUT_NAME"] = str(PROOF / "results.json")
COUNTS = {Path(NEW_TEST).name: 4} if STAGE == "red" else GREEN_COUNTS
FILES = ["e2e/extension/" + name for name in COUNTS]
PATTERN = re.escape(PREFIXES[0]) if STAGE == "red" else "|".join(re.escape(prefix) for prefix in PREFIXES)
ARGV = [PNPM, "exec", "playwright", "test", *FILES, "--grep", PATTERN, "--reporter=line,json"]


def save(name, value):
    (PROOF / name).write_text(json.dumps(value, indent=2) + "\n")


def capture(argv):
    return subprocess.check_output(argv, cwd=CLONE, env=ENV, text=True).strip()


def sources():
    tracked = subprocess.check_output(["git", "ls-files", "-z"], cwd=CLONE).split(b"\0")
    paths = sorted({path.decode() for path in tracked if path} | {NEW_TEST})
    files = []
    for rel in paths:
        data = (CLONE / rel).read_bytes()
        files.append({"path": rel, "bytes": len(data), "sha256": sha(data), "test_overlay": rel == NEW_TEST})
    status = subprocess.check_output(["git", "status", "--porcelain=v1", "-z"], cwd=CLONE)
    return {"at": now(), "head": capture(["git", "rev-parse", "HEAD"]), "tree": capture(["git", "rev-parse", "HEAD^{tree}"]), "status": [entry.decode() for entry in status.split(b"\0") if entry], "tracked_diff_binary": capture(["git", "diff", "--binary"]), "files": files, "total_bytes": sum(item["bytes"] for item in files)}


def verify_sources(value):
    assert value["head"] == HEAD and value["tree"] == TREE
    expected_status = ["?? " + NEW_TEST]
    if STAGE == "green":
        expected_status.insert(0, " M " + LEAF)
    assert value["status"] == expected_status, value["status"]
    found = {item["path"]: item["sha256"] for item in value["files"]}
    assert found[NEW_TEST] == NEW_TEST_SHA
    assert found[LEAF] == LEAF_SHA[STAGE]


def runtime():
    code = "import {captureRuntimeInventory} from './e2e/extension/legacy-paired-options/runtime-inventory.ts'; console.log(JSON.stringify(captureRuntimeInventory(process.cwd())));"
    value = json.loads(capture([NODE, "--input-type=module", "-e", code]))
    assert len(value["files"]) == 355
    assert value["total_bytes"] == (3371960 if STAGE == "red" else 3371983)
    if STAGE == "red":
        assert value["digest"] == "sha256:3b6c0e0c0950b03e3bb9e1f12b27bb8d385174c36fb4b68ef3345597aa8b3502"
    return value


def toolchain():
    result = {"at": now(), "node": capture([NODE, "--version"]), "node_exec_path": capture([NODE, "-p", "process.execPath"]), "pnpm": capture([PNPM, "--version"]), "playwright": capture([PNPM, "exec", "playwright", "--version"]), "python": sys.version, "platform": platform.platform()}
    assert result["node"] == "v24.18.0" and result["pnpm"] == "11.17.0" and result["playwright"] == "Version 1.62.0"
    for rel in ["pnpm-lock.yaml", "node_modules/.pnpm/lock.yaml"]:
        data = (CLONE / rel).read_bytes()
        result[rel] = {"bytes": len(data), "sha256": sha(data)}
    return result


def builds():
    result = {"at": now(), "scope": "Actual build output endpoints; fresh-clone BEFORE absent; canonical Playwright builds both MV3 variants and mock lab", "directories": {}}
    for rel in ["apps/extension/dist/chrome-mv3", "apps/extension/dist/invalid-ack/chrome-mv3", "apps/mock-ats-lab/dist"]:
        root = CLONE / rel
        files = []
        for path in sorted(root.rglob("*")):
            if path.is_file():
                data = path.read_bytes()
                files.append({"path": path.relative_to(CLONE).as_posix(), "bytes": len(data), "sha256": sha(data)})
        result["directories"][rel] = {"exists": root.exists(), "files": files, "total_bytes": sum(item["bytes"] for item in files)}
    return result


def specs(value):
    found = []
    def visit(suites):
        for suite in suites:
            found.extend(suite.get("specs", []))
            visit(suite.get("suites", []))
    visit(value["suites"])
    return found


def discovery():
    argv = ARGV[:-1] + ["--list", "--reporter=json"]
    env = dict(ENV)
    env.pop("PLAYWRIGHT_JSON_OUTPUT_NAME", None)
    result = subprocess.run(argv, cwd=CLONE, env=env, capture_output=True)
    (PROOF / "discovery.stdout.json").write_bytes(result.stdout)
    (PROOF / "discovery.stderr.log").write_bytes(result.stderr)
    save("discovery-command.json", {"at": now(), "argv": argv, "cwd": str(CLONE), "exit_code": result.returncode, "scope": "Canonical --list only; no global setup/build/browser"})
    found = specs(json.loads(result.stdout))
    counts = {name: sum(len(item["tests"]) for item in found if Path(item["file"]).name == name) for name in COUNTS}
    summary = {"at": now(), "exit_code": result.returncode, "counts": counts, "total_specs": len(found), "total_tests": sum(len(item["tests"]) for item in found), "titles": [item["title"] for item in found]}
    save("discovery-summary.json", summary)
    assert result.returncode == 0 and counts == COUNTS and summary["total_tests"] == sum(COUNTS.values()) and len(found) == sum(COUNTS.values()), summary
    return summary


def retain_native():
    source = CLONE / "test-results"
    if source.exists():
        shutil.copytree(source, PROOF / "native-test-results")
    files = []
    for path in sorted((PROOF / "native-test-results").rglob("*")):
        if path.is_file():
            data = path.read_bytes()
            files.append({"path": path.relative_to(PROOF).as_posix(), "bytes": len(data), "sha256": sha(data)})
    save("native-artifact-retention.json", {"at": now(), "files": files})


def analyze(exit_code):
    value = json.loads((PROOF / "results.json").read_text())
    found = specs(value)
    observations = []
    for item in found:
        assert len(item["tests"]) == 1 and len(item["tests"][0]["results"]) == 1
        result = item["tests"][0]["results"][0]
        observation = {"title": item["title"], "file": item["file"], "status": result["status"], "duration_ms": result["duration"], "errors": result.get("errors", [])}
        if Path(item["file"]).name == Path(NEW_TEST).name:
            attached = [a for a in result.get("attachments", []) if a["name"] == "native-focus-viewport"]
            assert len(attached) == 1
            raw = base64.b64decode(attached[0]["body"])
            data = json.loads(raw)
            (PROOF / ("viewport-" + data["control"]["type"] + "-" + data["operation"] + ".json")).write_bytes(raw)
            observation["viewport_evidence"] = data
            assert data["before"]["viewport"] == {"x": 0, "y": 400}
            assert data["after"]["events"] == {"focus": 1, "blur": 1, "input": 1, "change": 1, "active_at_focus": True, "trusted_focus": True}
            assert data["afterNative"]["native_mutation_count"] - data["beforeNative"]["native_mutation_count"] == 1
            assert data["after"]["value"] == data["control"]["intended" if data["operation"] == "EXECUTE" else "prior"]
            outcome = data["completed"]["items"][0]["result"]["outcome"] if data["operation"] == "EXECUTE" else data["completed"]["outcome"]["result"]["outcome"]
            assert outcome == "VERIFIED"
            if STAGE == "red":
                assert result["status"] == "failed" and data["after"]["viewport"] != data["before"]["viewport"]
                assert all("after.viewport" in error.get("snippet", "") for error in result.get("errors", []))
            else:
                assert result["status"] == "passed" and data["after"]["viewport"] == data["before"]["viewport"]
        observations.append(observation)
    summary = {"at": now(), "stage": STAGE, "child_exit_code": exit_code, "test_count": len(found), "stats": value["stats"], "passed": sum(o["status"] == "passed" for o in observations), "failed": sum(o["status"] == "failed" for o in observations), "source_overlay_unchanged": True, "scope": "Viewport behavior/safety regression only; no native128 performance or Gate verdict", "observations": observations}
    save("regression-summary.json", summary)
    assert len(found) == sum(COUNTS.values())
    assert (exit_code == 1 and summary["failed"] == 4) if STAGE == "red" else (exit_code == 0 and summary["passed"] == 28)
    return summary


if args.action == "prepare":
    before = sources()
    verify_sources(before)
    save("prepared-sources.json", before)
    save("prepared-runtime.json", runtime())
    save("prepared-tools.json", toolchain())
    save("prepared-build.json", builds())
    found = discovery()
    print(json.dumps({"stage": STAGE, "prepared_only": True, "discovered_tests": found["total_tests"]}), flush=True)
else:
    assert (BASE / "root-authorization.json").exists()
    assert not (PROOF / "invocation-started.json").exists(), "ONE_INVOCATION_PER_STAGE"
    found = json.loads((PROOF / "discovery-summary.json").read_text())
    assert found["exit_code"] == 0 and found["counts"] == COUNTS
    if STAGE == "green":
        red = json.loads((BASE / "red/proof/regression-summary.json").read_text())
        assert red["failed"] == 4 and red["child_exit_code"] == 1
    before = sources()
    verify_sources(before)
    before_runtime = runtime()
    save("before-sources.json", before)
    save("before-runtime.json", before_runtime)
    save("before-tools.json", toolchain())
    save("before-build.json", builds())
    save("command.json", {"at": now(), "argv": ARGV, "cwd": str(CLONE), "environment": {key: ENV.get(key) for key in ["PATH", "PLAYWRIGHT_JSON_OUTPUT_NAME", "JAPP_W13_PERFORMANCE_SAMPLES"]}, "trace": "original retain-on-failure", "root_authorization": json.loads((BASE / "root-authorization.json").read_text())})
    save("invocation-started.json", {"at": now(), "stage": STAGE, "one_invocation_only": True})
    started = time.monotonic()
    proc = subprocess.Popen(ARGV, cwd=CLONE, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    with (PROOF / "run.log").open("wb") as log:
        assert proc.stdout is not None
        for line in proc.stdout:
            log.write(line)
            log.flush()
            sys.stdout.buffer.write(line)
            sys.stdout.buffer.flush()
    code = proc.wait()
    save("completion.json", {"at": now(), "exit_code": code, "duration_s": time.monotonic() - started})
    retain_native()
    after = sources()
    save("after-sources.json", after)
    save("after-runtime.json", runtime())
    save("after-tools.json", toolchain())
    save("after-build.json", builds())
    verify_sources(after)
    assert before["files"] == after["files"] and before["tracked_diff_binary"] == after["tracked_diff_binary"]
    assert json.loads((PROOF / "after-runtime.json").read_text()) == before_runtime
    summary = analyze(code)
    print(json.dumps({key: value for key, value in summary.items() if key != "observations"}, indent=2), flush=True)
    sys.exit(code)
