# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w15-focus-viewport.spec.ts >> W15 native UNDO text preserves viewport and real focus
- Location: e2e/extension/extension-w15-focus-viewport.spec.ts:43:5

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 1

  Object {
    "x": 0,
-   "y": 400,
+   "y": 1924,
  }
```

# Test source

```ts
  94  |           seed,
  95  |         );
  96  |         if (operation === "UNDO") {
  97  |           const initial = await dynExecute(h, [tx]);
  98  |           expect(initial.items).toHaveLength(1);
  99  |           const item = initial.items[0];
  100 |           expect(item?.status).toBe("EXECUTED");
  101 |           if (item?.status !== "EXECUTED")
  102 |             throw new Error("initial execution absent");
  103 |           expect(item.result.outcome).toBe("VERIFIED");
  104 |           expect(item.undo_available).toBe(true);
  105 |         }
  106 |         const before = await h.page.evaluate(() => {
  107 |           const target = document.querySelector("input");
  108 |           if (target === null) throw new Error("target absent");
  109 |           const events = {
  110 |             focus: 0,
  111 |             blur: 0,
  112 |             input: 0,
  113 |             change: 0,
  114 |             active_at_focus: false,
  115 |             trusted_focus: false,
  116 |           };
  117 |           (window as unknown as Record<string, unknown>).__viewportFocusEvents =
  118 |             events;
  119 |           target.addEventListener("focus", (event) => {
  120 |             events.focus += 1;
  121 |             events.active_at_focus = document.activeElement === target;
  122 |             events.trusted_focus = event.isTrusted;
  123 |           });
  124 |           for (const name of ["blur", "input", "change"] as const)
  125 |             target.addEventListener(name, () => {
  126 |               events[name] += 1;
  127 |             });
  128 |           window.scrollTo(0, 400);
  129 |           return {
  130 |             viewport: { x: window.scrollX, y: window.scrollY },
  131 |             viewport_height: window.innerHeight,
  132 |             target_document_top:
  133 |               target.getBoundingClientRect().top + window.scrollY,
  134 |           };
  135 |         });
  136 |         expect(before.viewport).toEqual({ x: 0, y: 400 });
  137 |         expect(before.target_document_top).toBeGreaterThan(
  138 |           before.viewport.y + before.viewport_height,
  139 |         );
  140 |         const beforeNative = await witness.snapshot();
  141 |         pending =
  142 |           operation === "EXECUTE"
  143 |             ? dynExecute(h, [tx])
  144 |             : runtimeMessage(
  145 |                 h.controller,
  146 |                 buildUndoTabRequest(seed, h.tabId, {
  147 |                   transaction_id: tx.transaction_id,
  148 |                   address: tx.address,
  149 |                   settle: { budget_ms: 75 },
  150 |                 }),
  151 |               );
  152 |         const completed = await pending;
  153 |         pending = undefined;
  154 |         const afterNative = await witness.snapshot();
  155 |         const after = await h.page.evaluate(() => ({
  156 |           value: document.querySelector("input")?.value,
  157 |           viewport: { x: window.scrollX, y: window.scrollY },
  158 |           events: (window as unknown as Record<string, unknown>)
  159 |             .__viewportFocusEvents,
  160 |         }));
  161 |         await info.attach("native-focus-viewport", {
  162 |           body: JSON.stringify(
  163 |             {
  164 |               control,
  165 |               operation,
  166 |               before,
  167 |               after,
  168 |               beforeNative,
  169 |               afterNative,
  170 |               completed,
  171 |             },
  172 |             null,
  173 |             2,
  174 |           ),
  175 |           contentType: "application/json",
  176 |         });
  177 |         if (operation === "EXECUTE") {
  178 |           const outcome = completed as Awaited<ReturnType<typeof dynExecute>>;
  179 |           expect(outcome.items).toHaveLength(1);
  180 |           const item = outcome.items[0];
  181 |           expect(item?.status).toBe("EXECUTED");
  182 |           if (item?.status !== "EXECUTED") throw new Error("execution absent");
  183 |           expect(item.result.outcome).toBe("VERIFIED");
  184 |         } else {
  185 |           const outcome = parseUndoTabResult(completed);
  186 |           expect(outcome?.outcome.status).toBe("COMPLETED");
  187 |           if (outcome?.outcome.status !== "COMPLETED")
  188 |             throw new Error("undo absent");
  189 |           expect(outcome.outcome.result.outcome).toBe("VERIFIED");
  190 |         }
  191 |         expect(after.value).toBe(
  192 |           operation === "EXECUTE" ? control.intended : control.prior,
  193 |         );
> 194 |         expect(after.viewport).toEqual(before.viewport);
      |                                ^ Error: expect(received).toEqual(expected) // deep equality
  195 |         expect(after.events).toEqual({
  196 |           focus: 1,
  197 |           blur: 1,
  198 |           input: 1,
  199 |           change: 1,
  200 |           active_at_focus: true,
  201 |           trusted_focus: true,
  202 |         });
  203 |         expect(
  204 |           afterNative.native_mutation_count -
  205 |             beforeNative.native_mutation_count,
  206 |         ).toBe(1);
  207 |       } finally {
  208 |         await pending?.catch(() => undefined);
  209 |         await witness.dispose();
  210 |         await h.page.close();
  211 |         await h.controller.close();
  212 |       }
  213 |     });
  214 |   }
  215 | }
  216 | 
```