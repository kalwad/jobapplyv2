# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w15-text-viewport.spec.ts >> W15 text viewport EXECUTE text preserves real focus
- Location: e2e/extension/extension-w15-text-viewport.spec.ts:43:5

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 1

  Object {
    "x": 0,
-   "y": 400,
+   "y": 1924,
  }
```

# Test source

```ts
  102 |           expect(initial.items).toHaveLength(1);
  103 |           const item = initial.items[0];
  104 |           expect(item?.status).toBe("EXECUTED");
  105 |           if (item?.status !== "EXECUTED")
  106 |             throw new Error("initial execution absent");
  107 |           expect(item.result.outcome).toBe("VERIFIED");
  108 |           expect(item.undo_available).toBe(true);
  109 |         }
  110 |         const before = await h.page.evaluate(() => {
  111 |           const target = document.querySelector<
  112 |             HTMLInputElement | HTMLTextAreaElement
  113 |           >("input,textarea");
  114 |           if (target === null) throw new Error("target absent");
  115 |           const events = {
  116 |             focus: 0,
  117 |             blur: 0,
  118 |             input: 0,
  119 |             change: 0,
  120 |             active_at_focus: false,
  121 |             trusted_focus: false,
  122 |           };
  123 |           (window as unknown as Record<string, unknown>).__viewportFocusEvents =
  124 |             events;
  125 |           target.addEventListener("focus", (event) => {
  126 |             events.focus += 1;
  127 |             events.active_at_focus = document.activeElement === target;
  128 |             events.trusted_focus = event.isTrusted;
  129 |           });
  130 |           for (const name of ["blur", "input", "change"] as const)
  131 |             target.addEventListener(name, () => {
  132 |               events[name] += 1;
  133 |             });
  134 |           window.scrollTo(0, 400);
  135 |           return {
  136 |             viewport: { x: window.scrollX, y: window.scrollY },
  137 |             viewport_height: window.innerHeight,
  138 |             target_document_top:
  139 |               target.getBoundingClientRect().top + window.scrollY,
  140 |           };
  141 |         });
  142 |         expect(before.viewport).toEqual({ x: 0, y: 400 });
  143 |         expect(before.target_document_top).toBeGreaterThan(
  144 |           before.viewport.y + before.viewport_height,
  145 |         );
  146 |         const beforeNative = await witness.snapshot();
  147 |         pending =
  148 |           operation === "EXECUTE"
  149 |             ? dynExecute(h, [tx])
  150 |             : runtimeMessage(
  151 |                 h.controller,
  152 |                 buildUndoTabRequest(seed, h.tabId, {
  153 |                   transaction_id: tx.transaction_id,
  154 |                   address: tx.address,
  155 |                   settle: { budget_ms: 75 },
  156 |                 }),
  157 |               );
  158 |         const completed = await pending;
  159 |         pending = undefined;
  160 |         const afterNative = await witness.snapshot();
  161 |         const after = await h.page.evaluate(() => ({
  162 |           value: document.querySelector<HTMLInputElement | HTMLTextAreaElement>(
  163 |             "input,textarea",
  164 |           )?.value,
  165 |           viewport: { x: window.scrollX, y: window.scrollY },
  166 |           events: (window as unknown as Record<string, unknown>)
  167 |             .__viewportFocusEvents,
  168 |         }));
  169 |         await info.attach("native-focus-viewport", {
  170 |           body: JSON.stringify(
  171 |             {
  172 |               control,
  173 |               operation,
  174 |               before,
  175 |               after,
  176 |               beforeNative,
  177 |               afterNative,
  178 |               completed,
  179 |             },
  180 |             null,
  181 |             2,
  182 |           ),
  183 |           contentType: "application/json",
  184 |         });
  185 |         if (operation === "EXECUTE") {
  186 |           const outcome = completed as Awaited<ReturnType<typeof dynExecute>>;
  187 |           expect(outcome.items).toHaveLength(1);
  188 |           const item = outcome.items[0];
  189 |           expect(item?.status).toBe("EXECUTED");
  190 |           if (item?.status !== "EXECUTED") throw new Error("execution absent");
  191 |           expect(item.result.outcome).toBe("VERIFIED");
  192 |         } else {
  193 |           const outcome = parseUndoTabResult(completed);
  194 |           expect(outcome?.outcome.status).toBe("COMPLETED");
  195 |           if (outcome?.outcome.status !== "COMPLETED")
  196 |             throw new Error("undo absent");
  197 |           expect(outcome.outcome.result.outcome).toBe("VERIFIED");
  198 |         }
  199 |         expect(after.value).toBe(
  200 |           operation === "EXECUTE" ? control.intended : control.prior,
  201 |         );
> 202 |         expect(after.viewport).toEqual(before.viewport);
      |                                ^ Error: expect(received).toEqual(expected) // deep equality
  203 |         expect(after.events).toEqual({
  204 |           focus: 1,
  205 |           blur: 1,
  206 |           input: 1,
  207 |           change: 1,
  208 |           active_at_focus: true,
  209 |           trusted_focus: true,
  210 |         });
  211 |         expect(
  212 |           afterNative.native_mutation_count -
  213 |             beforeNative.native_mutation_count,
  214 |         ).toBe(1);
  215 |       } finally {
  216 |         await pending?.catch(() => undefined);
  217 |         await witness.dispose();
  218 |         await h.page.close();
  219 |         await h.controller.close();
  220 |       }
  221 |     });
  222 |   }
  223 | }
  224 | 
```