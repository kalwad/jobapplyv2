# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w15-text-viewport.spec.ts >> W15 text viewport UNDO textarea preserves real focus
- Location: e2e/extension/extension-w15-text-viewport.spec.ts:43:5

# Error details

```
Error: actual W09 did not authorize fixture
```

# Test source

```ts
  1   | /** Native text and textarea focus preserve viewport and real events. */
  2   | import { test, expect } from "./support/extension-test.ts";
  3   | import { installW14NativeWitness } from "./support/autofill-w14-native-witness.ts";
  4   | import {
  5   |   openHarness,
  6   |   setFixture,
  7   |   scanFrames,
  8   |   foundTopFrame,
  9   |   descriptorByLabel,
  10  |   buildTransaction,
  11  |   dynExecute,
  12  |   runtimeMessage,
  13  | } from "./support/research-harness.ts";
  14  | import {
  15  |   buildApprovedRecordSet,
  16  |   resolveFieldDecision,
  17  |   stableSemanticId,
  18  | } from "../../packages/form-engine/src/index.ts";
  19  | import {
  20  |   buildUndoTabRequest,
  21  |   parseUndoTabResult,
  22  | } from "../../apps/extension/src/driver-protocol.ts";
  23  | 
  24  | const controls = [
  25  |   {
  26  |     type: "text",
  27  |     label: "First name",
  28  |     concept: "FIRST_NAME",
  29  |     prior: "Prior",
  30  |     intended: "Synthetic",
  31  |   },
  32  |   {
  33  |     type: "textarea",
  34  |     label: "First name",
  35  |     concept: "FIRST_NAME",
  36  |     prior: "Prior multiline",
  37  |     intended: "Synthetic multiline",
  38  |   },
  39  | ] as const;
  40  | 
  41  | for (const control of controls) {
  42  |   for (const operation of ["EXECUTE", "UNDO"] as const) {
  43  |     test(`W15 text viewport ${operation} ${control.type} preserves real focus`, async ({
  44  |       extensionContext,
  45  |       extensionId,
  46  |       serviceWorker,
  47  |     }, info) => {
  48  |       const h = await openHarness(
  49  |         extensionContext,
  50  |         extensionId,
  51  |         serviceWorker,
  52  |         "/native/",
  53  |       );
  54  |       const witness = await installW14NativeWitness(
  55  |         extensionContext,
  56  |         h.page,
  57  |         extensionId,
  58  |       );
  59  |       let pending: Promise<unknown> | undefined;
  60  |       try {
  61  |         await setFixture(
  62  |           h,
  63  |           `<form data-japp-application-root="true"><div style="height:2500px"></div><label for="target">${control.label}</label>${
  64  |             control.type === "textarea"
  65  |               ? `<textarea id="target" name="${control.concept}" aria-invalid="false" required>${control.prior}</textarea>`
  66  |               : `<input id="target" name="${control.concept}" type="text" aria-invalid="false" value="${control.prior}" required>`
  67  |           }</form>`,
  68  |         );
  69  |         const top = foundTopFrame(await scanFrames(h));
  70  |         const field = descriptorByLabel(top.descriptors, control.label);
  71  |         expect(field.control_kind).toBe(
  72  |           control.type === "textarea" ? "TEXTAREA" : "TEXT",
  73  |         );
  74  |         const seed = `w15-text-viewport-${control.type}-${operation}`;
  75  |         const approval = await resolveFieldDecision({
  76  |           descriptor: field,
  77  |           records: buildApprovedRecordSet([
  78  |             {
  79  |               recordId: await stableSemanticId("record", seed),
  80  |               concept: control.concept,
  81  |               policy: "FILL_FROM_EXPLICIT_RECORD",
  82  |               confirmation: { state: "MISSING" },
  83  |               valueConfidence: 1,
  84  |             },
  85  |           ]),
  86  |           correlationId: await stableSemanticId("cor", seed),
  87  |         });
  88  |         if (
  89  |           approval.status !== "RESOLVED" ||
  90  |           approval.resolution.decision.final_decision !== "FILL"
  91  |         )
> 92  |           throw new Error("actual W09 did not authorize fixture");
      |                 ^ Error: actual W09 did not authorize fixture
  93  |         const intended = { kind: "TEXT" as const, text: control.intended };
  94  |         const tx = await buildTransaction(
  95  |           field,
  96  |           intended,
  97  |           approval.resolution.decision,
  98  |           seed,
  99  |         );
  100 |         if (operation === "UNDO") {
  101 |           const initial = await dynExecute(h, [tx]);
  102 |           expect(initial.items).toHaveLength(1);
  103 |           const item = initial.items[0];
  104 |           expect(item?.status).toBe("EXECUTED");
  105 |           if (item?.status !== "EXECUTED")
  106 |             throw new Error("initial execution absent");
  107 |           expect(item.result.outcome).toBe("VERIFIED");
  108 |           expect(item.undo_available).toBe(true);
  109 |         }
  110 |         const before = await h.page.evaluate(() => {
  111 |           const target = document.querySelector<
  112 |             HTMLInputElement | HTMLTextAreaElement
  113 |           >("input,textarea");
  114 |           if (target === null) throw new Error("target absent");
  115 |           const events = {
  116 |             focus: 0,
  117 |             blur: 0,
  118 |             input: 0,
  119 |             change: 0,
  120 |             active_at_focus: false,
  121 |             trusted_focus: false,
  122 |           };
  123 |           (window as unknown as Record<string, unknown>).__viewportFocusEvents =
  124 |             events;
  125 |           target.addEventListener("focus", (event) => {
  126 |             events.focus += 1;
  127 |             events.active_at_focus = document.activeElement === target;
  128 |             events.trusted_focus = event.isTrusted;
  129 |           });
  130 |           for (const name of ["blur", "input", "change"] as const)
  131 |             target.addEventListener(name, () => {
  132 |               events[name] += 1;
  133 |             });
  134 |           window.scrollTo(0, 400);
  135 |           return {
  136 |             viewport: { x: window.scrollX, y: window.scrollY },
  137 |             viewport_height: window.innerHeight,
  138 |             target_document_top:
  139 |               target.getBoundingClientRect().top + window.scrollY,
  140 |           };
  141 |         });
  142 |         expect(before.viewport).toEqual({ x: 0, y: 400 });
  143 |         expect(before.target_document_top).toBeGreaterThan(
  144 |           before.viewport.y + before.viewport_height,
  145 |         );
  146 |         const beforeNative = await witness.snapshot();
  147 |         pending =
  148 |           operation === "EXECUTE"
  149 |             ? dynExecute(h, [tx])
  150 |             : runtimeMessage(
  151 |                 h.controller,
  152 |                 buildUndoTabRequest(seed, h.tabId, {
  153 |                   transaction_id: tx.transaction_id,
  154 |                   address: tx.address,
  155 |                   settle: { budget_ms: 75 },
  156 |                 }),
  157 |               );
  158 |         const completed = await pending;
  159 |         pending = undefined;
  160 |         const afterNative = await witness.snapshot();
  161 |         const after = await h.page.evaluate(() => ({
  162 |           value: document.querySelector<HTMLInputElement | HTMLTextAreaElement>(
  163 |             "input,textarea",
  164 |           )?.value,
  165 |           viewport: { x: window.scrollX, y: window.scrollY },
  166 |           events: (window as unknown as Record<string, unknown>)
  167 |             .__viewportFocusEvents,
  168 |         }));
  169 |         await info.attach("native-focus-viewport", {
  170 |           body: JSON.stringify(
  171 |             {
  172 |               control,
  173 |               operation,
  174 |               before,
  175 |               after,
  176 |               beforeNative,
  177 |               afterNative,
  178 |               completed,
  179 |             },
  180 |             null,
  181 |             2,
  182 |           ),
  183 |           contentType: "application/json",
  184 |         });
  185 |         if (operation === "EXECUTE") {
  186 |           const outcome = completed as Awaited<ReturnType<typeof dynExecute>>;
  187 |           expect(outcome.items).toHaveLength(1);
  188 |           const item = outcome.items[0];
  189 |           expect(item?.status).toBe("EXECUTED");
  190 |           if (item?.status !== "EXECUTED") throw new Error("execution absent");
  191 |           expect(item.result.outcome).toBe("VERIFIED");
  192 |         } else {
```