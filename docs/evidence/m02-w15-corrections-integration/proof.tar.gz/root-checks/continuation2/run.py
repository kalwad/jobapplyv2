from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
out=Path(__file__).parent
root=Path('/Users/tanishkalwad/jobapplyv2')
env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@24/bin:'+env['PATH'];env['R10_ACTOR_SOURCE']=str(root/'e2e/extension/legacy-paired-options-r10/legacy-browser.mjs')
r10=sorted(str(p.relative_to(root)) for p in (root/'e2e/extension/legacy-paired-options-r10').glob('*.test.mjs'))
steps=[('extension-unit',['pnpm','--filter','@japp/extension','test']),('r10-pure',['node','--experimental-vm-modules','--test',*r10]),('typecheck',['pnpm','typecheck']),('lint',['pnpm','lint']),('format',['pnpm','format:check']),('status',['uv','run','python','scripts/validate_status.py']),('traceability',['pnpm','traceability:check']),('diff',['git','diff','--check'])]
steps=steps[1:]
rows=[]
for name,argv in steps:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 with (out/(name+'.log')).open('wb') as stream:r=subprocess.run(argv,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
 b=(out/(name+'.log')).read_bytes();row=dict(name=name,argv=argv,cwd=str(root),started_at=start,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-t,exit_code=r.returncode,log_bytes=len(b),log_sha256=hashlib.sha256(b).hexdigest());rows.append(row)
 (out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print(b.decode(errors='replace')[-12000:],flush=True);raise SystemExit(r.returncode)
