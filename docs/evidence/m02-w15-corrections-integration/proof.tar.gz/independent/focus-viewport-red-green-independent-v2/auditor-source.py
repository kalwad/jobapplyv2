"""Pure independent raw review of the rejected shared focus proposal."""
from pathlib import Path, PurePosixPath
import base64
import hashlib
import json
import re
import zipfile

BASE = Path('/tmp/japp-m02-w15-focus-viewport-regression-20261017')
OUT = Path('/tmp/japp-m02-w15-independent-audit/focus-viewport-red-green-independent-v2')
assert not OUT.exists()
OUT.mkdir()
(OUT / 'inspection-attempt1-error.json').write_text(json.dumps({
    'scope': 'PRELIMINARY_PURE_INSPECTION_ERROR_NOT_PRODUCT_TEST_FAILURE',
    'error': 'KeyError: status_porcelain',
    'cause': 'Assumed earlier diagnostic snapshot key; this wrapper actually uses status.',
    'correction': 'Read actual snapshot schema and compare status unchanged. No product assertion or input changed.',
}, indent=2) + '\n')
sha = lambda body: hashlib.sha256(body).hexdigest()
canon = lambda value: json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
mutation = {'INPUT_VALUE', 'TEXTAREA_VALUE', 'SELECT_VALUE', 'INPUT_CHECKED', 'INPUT_FILES', 'SELECT_INDEX', 'ACTIVATION'}
original = json.loads(Path('/tmp/japp-m02-w15-final-candidate-20261017/proof/before.json').read_text())
original_rows = {row['path']: row for row in original['tracked_files']}
reports = []
for stage, total, expected_pass, expected_fail in [('red', 4, 0, 4), ('green', 28, 26, 2)]:
    proof = BASE / stage / 'proof'
    read = lambda name: json.loads((proof / name).read_text())
    report = read('results.json')
    specs = []
    def visit(suite):
        specs.extend(suite.get('specs', []))
        for child in suite.get('suites', []):
            visit(child)
    for suite in report['suites']:
        visit(suite)
    assert len(specs) == total and len({s['title'] for s in specs}) == total
    assert not report['errors']
    stats = report['stats']
    assert stats['expected'] == expected_pass and stats['unexpected'] == expected_fail
    assert stats['skipped'] == stats['flaky'] == 0
    before, after = read('before-sources.json'), read('after-sources.json')
    for key in ['head', 'tree', 'status', 'tracked_diff_binary', 'files', 'total_bytes']:
        assert before[key] == after[key], (stage, key)
    assert before['head'] == '507a7687b004937fbf0dc48e5e80a35d30fe9b6e'
    assert before['tree'] == '235bc696fb37e887b5efa817039276a775a18e2e'
    overlay_rows = {row['path']: row for row in before['files']}
    assert set(overlay_rows) - set(original_rows) == {'e2e/extension/extension-w15-focus-viewport.spec.ts'}
    assert not set(original_rows) - set(overlay_rows)
    changed = [path for path in original_rows if any(original_rows[path][key] != overlay_rows[path][key] for key in ['path', 'bytes', 'sha256'])]
    assert changed == ([] if stage == 'red' else ['apps/extension/src/drivers/text-like-drivers.ts'])
    assert overlay_rows['e2e/extension/extension-w15-focus-viewport.spec.ts']['sha256'] == 'bfa455c32f082067c286ae7a1536cd3e3b1bf4bec5c4da8ba71e7df2e13857d1'
    runtime = read('before-runtime.json')
    assert runtime == read('after-runtime.json')
    assert len(runtime['files']) == 355
    assert runtime['digest'] == ('sha256:3b6c0e0c0950b03e3bb9e1f12b27bb8d385174c36fb4b68ef3345597aa8b3502' if stage == 'red' else 'sha256:4c78af0e37d42b2b868425759e2dd215e1d1a45bb09736a0fbf11bb0e3b9c638')
    observations = []
    for spec in specs:
        assert len(spec['tests']) == 1
        test = spec['tests'][0]
        assert test['expectedStatus'] == 'passed' and len(test['results']) == 1
        result = test['results'][0]
        assert result['retry'] == 0 and result['status'] in {'passed', 'failed'}
        if not spec['title'].startswith('W15 native '):
            assert stage == 'green' and result['status'] == 'passed'
            continue
        attachment = next(a for a in result['attachments'] if a['name'] == 'native-focus-viewport')
        body = base64.b64decode(attachment['body'], validate=True)
        value = json.loads(body)
        kind, operation = value['control']['type'], value['operation']
        retained = (proof / f'viewport-{kind}-{operation}.json').read_bytes()
        assert retained == body
        expected_value = value['control']['intended' if operation == 'EXECUTE' else 'prior']
        assert value['after']['value'] == expected_value
        completed = value['completed']
        outcome = completed['items'][0]['result'] if operation == 'EXECUTE' else completed['outcome']['result']
        assert outcome['outcome'] == 'VERIFIED' and outcome['persistence_verified']
        assert value['before']['viewport'] == {'x': 0, 'y': 400}
        expected_y = (400 if kind == 'text' else 1926) if stage == 'green' else (1924 if kind == 'text' else 1926)
        assert value['after']['viewport'] == {'x': 0, 'y': expected_y}
        assert value['after']['events'] == {'focus': 1, 'blur': 1, 'input': 1, 'change': 1, 'active_at_focus': True, 'trusted_focus': True}
        snapshots = [value['beforeNative'], value['afterNative']]
        for native in snapshots:
            assert native['source'] == 'CDP_EXTENSION_ISOLATED_REALM_NATIVE_1'
            assert native['realm'] == 'ACTUAL_EXTENSION_CONTENT_SCRIPT'
            assert native['coverage'] == 'COMPLETE_INSTALLED_NATIVE_SURFACES'
            witnesses = native['witnesses']
            assert [w['sequence'] for w in witnesses] == list(range(1, len(witnesses) + 1))
            assert native['witnesses_digest'] == 'sha256:' + sha(canon(witnesses).encode())
            assert native['native_mutation_count'] == sum(w['surface'] in mutation for w in witnesses)
        start = len(value['beforeNative']['witnesses'])
        assert value['afterNative']['witnesses'][:start] == value['beforeNative']['witnesses']
        delta = value['afterNative']['witnesses'][start:]
        assert [w['surface'] for w in delta] == ['FOCUS', 'INPUT_VALUE', 'EVENT_DISPATCH', 'EVENT_DISPATCH', 'BLUR']
        assert all(w['succeeded'] for w in delta)
        assert delta[1]['value_digest'] == 'sha256:' + sha(canon(expected_value).encode())
        assert value['afterNative']['native_mutation_count'] - value['beforeNative']['native_mutation_count'] == 1
        failed = result['status'] == 'failed'
        if failed:
            errors = result.get('errors', [])
            assert len(errors) == 1 and errors[0]['location']['line'] == 194
            assert 'expect(after.viewport).toEqual(before.viewport)' in errors[0]['message']
        observations.append({'title': spec['title'], 'status': result['status'], 'viewport_before': value['before']['viewport'],
            'viewport_after': value['after']['viewport'], 'events_independently_read': value['after']['events'],
            'native_mutation_delta_independently_recomputed': 1, 'verified_value_matches': True,
            'later_event_native_test_assertions_executed': not failed, 'attachment_sha256': sha(body)})
    retained_inventory = read('native-artifact-retention.json')['files']
    trace_rows = []
    for ref in retained_inventory:
        path = PurePosixPath(ref['path'])
        assert not path.is_absolute() and '..' not in path.parts
        body = (proof / ref['path']).read_bytes()
        assert len(body) == ref['bytes'] and sha(body) == ref['sha256']
        if ref['path'].endswith('trace.zip'):
            with zipfile.ZipFile(proof / ref['path']) as trace:
                names = set()
                members = []
                contexts = []
                for item in trace.infolist():
                    path = PurePosixPath(item.filename)
                    assert not path.is_absolute() and '..' not in path.parts and item.filename not in names
                    names.add(item.filename)
                    payload = trace.read(item)
                    members.append({'path': item.filename, 'bytes': len(payload), 'sha256': sha(payload)})
                    if item.filename.endswith('.trace'):
                        events = [json.loads(line) for line in payload.decode().splitlines()]
                        contexts.extend(e for e in events if e['type'] == 'context-options')
                trace_rows.append({'path': ref['path'], 'sha256': ref['sha256'], 'members': members, 'contexts': contexts})
    reports.append({'stage': stage, 'passed': expected_pass, 'failed': expected_fail, 'ordinary_tests': total,
        'source_overlay_unchanged': True, 'original_source_delta_paths': changed,
        'runtime_digest': runtime['digest'], 'observations': observations,
        'retained_artifact_count': len(retained_inventory), 'trace_inventories': trace_rows})
    for name in ['results.json', 'completion.json', 'command.json', 'native-artifact-retention.json']:
        (OUT / f'{stage}-{name}').write_bytes((proof / name).read_bytes())
    for value in observations:
        kind = 'text' if ' text ' in value['title'] else 'date'
        operation = 'EXECUTE' if ' EXECUTE ' in value['title'] else 'UNDO'
        (OUT / f'{stage}-viewport-{kind}-{operation}.json').write_bytes((proof / f'viewport-{kind}-{operation}.json').read_bytes())
findings = {'result': 'SHARED_VIEWPORT_CLAIM_REJECTED_BY_ACTUAL_DATE_FAILURES', 'authority': 'NONE', 'reports': reports,
    'limits': ['Raw native/event observations are independently rechecked; failed date tests did not execute their later event/native assertions.',
               'Installed native witness records call sequence/value hashes, not focus options or viewport at each internal call. Endpoints cannot locate scroll exactly at focus, setter, events or blur.',
               'Retained traces contain surrounding Playwright/CDP actions and snapshots, not an instrumented per-native-call scroll timeline. No unrecorded date-UA causation is inferred.',
               'Original shared proposal, four RED failures and two GREEN date failures remain immutable. No actor, test weakening, viewport restoration or runtime source authoring performed.']}
(OUT / 'findings.json').write_text(json.dumps(findings, indent=2) + '\n')
(OUT / 'auditor-source.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'result': findings['result'], 'stages': [{k: r[k] for k in ['stage', 'passed', 'failed', 'ordinary_tests', 'retained_artifact_count']} for r in reports]}))
