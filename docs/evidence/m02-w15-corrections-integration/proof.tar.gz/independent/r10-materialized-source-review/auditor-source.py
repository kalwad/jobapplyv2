"""Read-only closure of the actual R10 materialization/current root bytes."""
from pathlib import Path
import hashlib
import json

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
FROZEN = Path('/tmp/japp-m02-w15-r10-frozen-for-final-candidate-20261018')
PROPOSAL = Path('/tmp/japp-m02-w15-r10-preparation/proposal/e2e/extension/legacy-paired-options-r10')
OUT = Path('/tmp/japp-m02-w15-independent-audit/r10-materialized-source-review')
assert not OUT.exists()
OUT.mkdir()
sha = lambda body: 'sha256:' + hashlib.sha256(body).hexdigest()
canon = lambda value: json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
manifest_bytes = (FROZEN / 'frozen-source-manifest.json').read_bytes()
assert sha(manifest_bytes) == 'sha256:f3beb54dc561118f8f78cda76140fc94ecfc320d7ab901e542a9710bfd7757e5'
manifest = json.loads(manifest_bytes)
assert manifest['source_graph_files'] == len(manifest['files']) == 36
changed = []
for row in manifest['files']:
    body = (FROZEN / row['path']).read_bytes()
    assert len(body) == row['bytes'] and sha(body) == row['sha256']
    assert body == (ROOT / row['path']).read_bytes()
    name = Path(row['path']).name if '/preimages/' not in row['path'] else 'preimages/' + Path(row['path']).name
    if body != (PROPOSAL / name).read_bytes():
        changed.append(name)
assert set(changed) == {'campaign.lock.json', 'campaign.lock.sha256', 'predeclaration.json', 'source-bindings.json', 'r10-readiness.json'}
here = ROOT / 'e2e/extension/legacy-paired-options-r10'
bindings = json.loads((here / 'source-bindings.json').read_text())
policy = bindings['candidate_runtime_inventory_policy']
rows = []
seen = set()
total = 0
def add(path):
    global total
    assert path not in seen
    file = ROOT / path
    assert file.is_file() and not file.is_symlink()
    body = file.read_bytes()
    seen.add(path)
    total += len(body)
    assert len(rows) < policy['max_files'] and total <= policy['max_total_bytes']
    rows.append({'path': path, 'sha256': sha(body)})
def walk(name):
    directory = ROOT / name
    assert directory.is_dir() and not directory.is_symlink()
    for item in sorted(directory.iterdir(), key=lambda p: p.name):
        assert not item.is_symlink()
        path = item.relative_to(ROOT).as_posix()
        if item.is_dir():
            if item.name not in policy['excluded_directory_names']:
                walk(path)
        else:
            assert item.is_file()
            if not any(item.name.endswith(suffix) for suffix in policy['excluded_file_suffixes']):
                add(path)
for name in policy['directories']:
    walk(name)
for name in policy['files']:
    add(name)
rows.sort(key=lambda r: r['path'])
assert set(policy['required_runtime_paths']) <= seen
runtime = {'files': rows, 'digest': sha(canon(rows)), 'total_bytes': total}
assert len(rows) == 355 and total == 3372811
assert runtime['digest'] == 'sha256:4f5a9608eb23a80a15a81b4a79494901907c4ad7e5c6a996fbce455b498c77d5'
assert bindings['candidate_runtime_sources'] == rows and bindings['candidate_runtime_inventory_digest'] == runtime['digest']
freeze = json.loads((FROZEN / 'source-only-freeze-record.json').read_text())
assert freeze['source_inventory_before'] == freeze['source_inventory_after'] == runtime
assert freeze['builder_sha256'] == 'sha256:81c5d367992e200c97fcbdb93f3e497e1f070eb2f2907a597fb48c34ed3edc3a'
old = json.loads((ROOT / 'e2e/extension/legacy-paired-options/source-bindings.json').read_text())
before = json.loads(Path('/tmp/japp-m02-w15-final-candidate-20261017/proof/before.json').read_text())
before_files = {r['path']: r for r in before['tracked_files']}
old_rows = {r['path']: r['sha256'] for r in old['candidate_runtime_sources']}
differences = [r['path'] for r in rows if r['sha256'] != old_rows[r['path']]]
assert differences == ['apps/extension/src/drivers/text-like-drivers.ts', 'e2e/extension/support/extension-test.ts']
byte_deltas = [{'path': name, 'before_bytes': before_files[name]['bytes'], 'after_bytes': len((ROOT / name).read_bytes())} for name in differences]
observer = bindings['native_observer']
assert observer == old['native_observer']
assert sha((ROOT / observer['helper_path']).read_bytes()) == observer['helper_sha256']
lock_bytes = (here / 'campaign.lock.json').read_bytes()
lock = json.loads(lock_bytes)
assert sha(lock_bytes) == 'sha256:0b7cdbb06061ef6f2ec6c4a0c3c26cf7fcaf701ac7e6a1ac48131d1d85f0fd09'
assert len(lock['files']) == 34 and len({r['path'] for r in lock['files']}) == 34
for row in lock['files']:
    assert sha((here / row['path']).read_bytes()) == row['sha256']
assert (here / 'campaign.lock.sha256').read_text() == sha(lock_bytes) + '\n'
for row in json.loads((ROOT / 'e2e/extension/legacy-paired-options/campaign.lock.json').read_text())['files']:
    assert sha((ROOT / 'e2e/extension/legacy-paired-options' / row['path']).read_bytes()) == row['sha256']
readiness = json.loads((here / 'r10-readiness.json').read_text())
assert readiness['state'] == 'SOURCE_BOUND_REVIEWED'
assert readiness['candidate_runtime_inventory_digest'] == runtime['digest'] and readiness['candidate_runtime_inventory_count'] == 355
assert all(readiness[key] is None for key in ['exact_future_full_pass_commit', 'exact_future_full_pass_tree', 'future_full_completion_sha256', 'future_tools_before_sha256', 'future_tools_after_sha256', 'root_execution_release'])
declaration = json.loads((here / 'predeclaration.json').read_text())
assert declaration['candidate_runtime_inventory_digest'] == runtime['digest'] and declaration['candidate_runtime_inventory_count'] == 355
assert bindings['predeclaration_digest'] == sha((here / 'predeclaration.json').read_bytes())
findings = {'result': 'CLEAR_EXACT_MATERIALIZED_SOURCE_NO_EXECUTION_RELEASE', 'authority': 'NONE',
    'frozen_manifest_sha256': sha(manifest_bytes), 'materialized_graph_files': 36, 'all_root_copies_exact': True,
    'changed_materialization_metadata_only': changed, 'lock_digest': sha(lock_bytes), 'lock_entries': 34,
    'runtime_files': 355, 'actual_runtime_bytes': total, 'runtime_digest': runtime['digest'],
    'runtime_deltas_from_original507a': byte_deltas, 'native_helper_contract_unchanged': True,
    'all65_original_R9_locked_files_unchanged': True, 'future_full_release_fields_null': True,
    'bookkeeping_correction': 'Parent message3372099 was stale focus-only byte total. Actual materializer before/after and independent current capture are3372811 (old3371960 +139focus +712fixture). Digest4f5a and all355row hashes agree.',
    'scope': 'Source-only actual materialization plus current dirty-root identity check before final commit. No Git-clean, full-suite, target-performance, native, comparison or gate PASS claim.',
    'root_writes': 0, 'reviewer_actor_executions': 0}
(OUT / 'findings.json').write_text(json.dumps(findings, indent=2) + '\n')
for name in ['frozen-source-manifest.json', 'source-only-freeze-record.json']:
    (OUT / name).write_bytes((FROZEN / name).read_bytes())
(OUT / 'auditor-source.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({key: findings[key] for key in ['result', 'materialized_graph_files', 'actual_runtime_bytes', 'runtime_digest', 'lock_digest']}))
