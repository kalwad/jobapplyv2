"""Read/hash/source-data review only; no R10 code imported or invoked."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import tarfile

BASE = Path('/tmp/japp-m02-w15-r10-preparation')
PROPOSAL = BASE / 'proposal/e2e/extension/legacy-paired-options-r10'
R9 = Path('/Users/tanishkalwad/jobapplyv2/e2e/extension/legacy-paired-options')
OUT = Path('/tmp/japp-m02-w15-independent-audit/r10-final-source-proposal-review')
assert not OUT.exists()
OUT.mkdir()
sha = lambda body: 'sha256:' + hashlib.sha256(body).hexdigest()
read = lambda name: json.loads((BASE / name).read_text())
manifest_bytes = (BASE / 'proposal-source-manifest.json').read_bytes()
assert sha(manifest_bytes) == 'sha256:ac84dc54974d82418e64403ffa4e38825d308183a9d28e82b3e842e2bb630bcf'
manifest = json.loads(manifest_bytes)
assert manifest['source_graph_files'] == len(manifest['files']) == 36
rows = {}
exact = []
for row in manifest['files']:
    name = row['path']
    p = PurePosixPath(name)
    assert not p.is_absolute() and '..' not in p.parts and name not in rows
    body = (PROPOSAL / name).read_bytes()
    assert len(body) == row['bytes'] and sha(body) == row['sha256']
    rows[name] = row
    if (R9 / name).exists() and (R9 / name).read_bytes() == body:
        exact.append(name)
assert len(exact) == 23
lock = json.loads((PROPOSAL / 'campaign.lock.json').read_text())
assert len(lock['files']) == 34
assert {r['path'] for r in lock['files']} == set(rows) - {'campaign.lock.json', 'campaign.lock.sha256'}
for row in lock['files']:
    assert sha((PROPOSAL / row['path']).read_bytes()) == row['sha256']
assert (PROPOSAL / 'campaign.lock.sha256').read_text() == sha((PROPOSAL / 'campaign.lock.json').read_bytes()) + '\n'
old_lock = json.loads((R9 / 'campaign.lock.json').read_text())
assert len(old_lock['files']) == 65
for row in old_lock['files']:
    assert sha((R9 / row['path']).read_bytes()) == row['sha256']
bindings = json.loads((PROPOSAL / 'source-bindings.json').read_text())
old_bindings = json.loads((R9 / 'source-bindings.json').read_text())
same_keys = ['cases', 'legacy_source_identity', 'legacy_sources', 'sources', 'native_observer',
             'candidate_runtime_inventory_policy', 'limitations', 'inputs_digest', 'oracles_digest',
             'legacy_projections_digest', 'meter_function_sha256']
assert all(bindings[key] == old_bindings[key] for key in same_keys)
assert bindings['candidate_runtime_sources'] is None and bindings['candidate_runtime_inventory_digest'] is None
assert bindings['r10_campaign']['outcomes_inherited'] is False
observer = bindings['native_observer']
assert sha((R9.parents[2] / observer['helper_path']).read_bytes()) == observer['helper_sha256']
identity = read('final-review-identity.json')
for row in identity['files']:
    body = (BASE / row['path']).read_bytes()
    assert len(body) == row['bytes'] and sha(body) == row['sha256']
assert sha((BASE / 'bind-r10-source.py').read_bytes()) == 'sha256:81c5d367992e200c97fcbdb93f3e497e1f070eb2f2907a597fb48c34ed3edc3a'
assert sha((BASE / 'run-r10.py').read_bytes()) == 'sha256:52b2eeff55f0897622c5c167286327775cd97c7efbb308f848d305c953617bc3'
release = read('r10-release.json')
assert release['state'] == 'SOURCE_ONLY_ALL_FUTURE_PINS_NULL'
assert all(release[key] is None for key in ['source_root', 'legacy_root', 'output', 'full_proof_directory',
    'candidate_commit', 'candidate_tree', 'campaign_lock_digest', 'runtime_inventory_digest',
    'full_completion_sha256', 'full_independent_verdict_path', 'full_independent_verdict_sha256',
    'node_binary_sha256', 'pnpm_binary_sha256', 'legacy_python_binary_sha256', 'root_source_review_release'])
records = read('execution-record.derived.json')
supplement = read('execution-record-supplement.derived.json')
historical = supplement['historical_test_source_retention']
assert sha((BASE / historical['retained_version']).read_bytes()) == historical['sha256']
for row in records['rows']:
    assert sha((BASE / row['actor_source']).read_bytes()) == row['actor_sha256']
    test_path = historical['retained_version'] if row['phase'] == historical['phase'] else row['test_source']
    assert sha((BASE / test_path).read_bytes()) == row['test_sha256']
    assert sha((BASE / row['stdout']).read_bytes()) == row['stdout_sha256']
for row in supplement['final_actual_checks']:
    assert sha((BASE / row['raw_stdout']).read_bytes()) == row['sha256']
assert sha((PROPOSAL / 'legacy-browser.mjs').read_bytes()) == supplement['final_actor_source_sha256']
assert sha((PROPOSAL / 'legacy-browser-cleanup.test.mjs').read_bytes()) == supplement['final_test_source_sha256']
def node_counts(name, passed, failed):
    text = (BASE / name).read_text()
    for key, number in [('tests', passed + failed), ('pass', passed), ('fail', failed), ('cancelled', 0), ('skipped', 0), ('todo', 0)]:
        assert re.search(r'^ℹ ' + key + r' ' + str(number) + r'\s*$', text, re.M), (name, key)
node_counts('cleanup-test/red.stdout.log', 3, 4)
node_counts('cleanup-test/green.stdout.log', 7, 0)
node_counts('cleanup-test/final-static-source-actor-green.stdout.log', 7, 0)
node_counts('cleanup-test/final-static-source-existing-pure.stdout.log', 35, 0)
archive_dir = Path('/tmp/japp-m02-w15-r10-preparation-retained')
archive = archive_dir / 'proof.tar.gz'
assert sha(archive.read_bytes()) == 'sha256:db1018d635d94b76c699e338255235a1937ba305c1edd68cfec85349df850770'
archive_members = []
with tarfile.open(archive, 'r:gz') as tar:
    seen = set()
    for member in tar:
        p = PurePosixPath(member.name)
        assert not p.is_absolute() and '..' not in p.parts and member.name not in seen and member.isfile()
        seen.add(member.name)
        body = tar.extractfile(member).read()
        archive_members.append({'path': member.name, 'bytes': len(body), 'sha256': sha(body)})
assert len(archive_members) == 108
findings = {'result': 'CLEAR_SOURCE_ONLY_FUTURE_EXECUTION_NOT_RELEASED', 'authority': 'NONE',
    'proposal_manifest_sha256': sha(manifest_bytes), 'source_graph_files': 36, 'lock_entries': 34,
    'exact_R9_files': exact, 'original65_R9_locked_files_unchanged': True,
    'facts_oracles_observer_policy_scoring_contract_bindings_exact': same_keys,
    'source_files': manifest['files'], 'final_review_identity': identity,
    'fake_actor_author_unit_results': {'original': {'pass': 3, 'fail': 4}, 'corrected': {'pass': 7, 'fail': 0}, 'final_exact_source': {'pass': 7, 'fail': 0}, 'existing_pure': {'pass': 35, 'fail': 0}},
    'retained_preparation_archive': {'sha256': sha(archive.read_bytes()), 'bytes': archive.stat().st_size, 'regular_members': archive_members},
    'review_scope': 'Direct changed executable/schema/test/coordinator/builder reads plus exhaustive36-file/source-data/hash closure and author raw-unit review. Exact23 inherited bodies reuse prior R9 reads and byte equality; no fresh line-by-line reread claim.',
    'limits': ['Builder main/coordinator/actors uninvoked. Current null release cannot supply future full PASS or comparison result.',
               'Materialized runtime/lock/manifest must receive exact source review before commit; SOURCE_BOUND_REVIEWED marker alone does not certify an unreviewed output.',
               'Actual new full proof and the filled release/coordinator/independent FULL_COMPONENT verdict schema require fresh source review before execution.',
               'Future full-component CLEAR_EXACT_FULL_PASS would be limited to raw full verification; R10 and owner gate decision remain outstanding.',
               'Coordinator exact cwd pin requires filled source_root to agree with actual serial doctor/verify clone identity, or a separately reviewed source-equivalence change.',
               'Historical formatted test preimage is later reconstruction matching earlier digest, expressly not original before-run filesystem snapshot. Derived execution records have no reconstructed timestamps.',
               'No actor, browser, build, network or runtime source authoring was performed by reviewer. No Gate A PASS follows.'],
    'root_writes': 0, 'reviewer_actor_executions': 0}
(OUT / 'findings.json').write_text(json.dumps(findings, indent=2) + '\n')
for name in ['proposal-source-manifest.json', 'final-review-identity.json', 'execution-record.derived.json', 'execution-record-supplement.derived.json', 'bind-r10-source.py', 'run-r10.py', 'r10-release.json']:
    (OUT / name).write_bytes((BASE / name).read_bytes())
(OUT / 'auditor-source.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({key: findings[key] for key in ['result', 'proposal_manifest_sha256', 'source_graph_files', 'lock_entries', 'original65_R9_locked_files_unchanged']}))
