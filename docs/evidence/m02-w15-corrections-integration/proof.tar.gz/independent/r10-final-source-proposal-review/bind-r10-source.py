"""Source-only R10 freeze proposal builder. No build, browser, server or root mutation."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import stat

BASE = Path(__file__).resolve().parent
PROPOSAL = BASE / 'proposal/e2e/extension/legacy-paired-options-r10'


def sha(body):
    return 'sha256:' + hashlib.sha256(body).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()


def read(path):
    if path.is_symlink() or not stat.S_ISREG(path.lstat().st_mode):
        raise RuntimeError('R10_REGULAR_NO_SYMLINK_SOURCE_REQUIRED:' + str(path))
    return path.read_bytes()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def require_frozen_native_observer(root, bindings):
    observer = bindings['native_observer']
    if sha(read(root / observer['helper_path'])) != observer['helper_sha256']:
        raise RuntimeError('R10_FROZEN_NATIVE_OBSERVER_CHANGED_REVIEW_REQUIRED')


def capture(root, policy):
    rows = []
    total_bytes = 0
    seen = set()

    def add(name):
        nonlocal total_bytes
        if name in seen or Path(name).is_absolute() or '..' in Path(name).parts:
            raise RuntimeError('R10_RUNTIME_PATH_DUPLICATE_OR_REFUSED:' + name)
        body = read(root / name)
        if len(rows) >= policy['max_files'] or total_bytes + len(body) > policy['max_total_bytes']:
            raise RuntimeError('R10_RUNTIME_CAPACITY')
        seen.add(name)
        total_bytes += len(body)
        rows.append({'path': name, 'sha256': sha(body)})

    def walk(name):
        directory = root / name
        if directory.is_symlink() or not directory.is_dir():
            raise RuntimeError('R10_RUNTIME_DIRECTORY_REQUIRED:' + name)
        for child in sorted(directory.iterdir(), key=lambda path: path.name):
            if child.is_symlink():
                raise RuntimeError('R10_RUNTIME_SYMLINK_REFUSED:' + str(child))
            child_name = child.relative_to(root).as_posix()
            if child.is_dir():
                if child.name not in policy['excluded_directory_names']:
                    walk(child_name)
            elif child.is_file():
                if not any(child.name.endswith(suffix) for suffix in policy['excluded_file_suffixes']):
                    add(child_name)
            else:
                raise RuntimeError('R10_RUNTIME_NONREGULAR_REFUSED:' + child_name)

    for directory in policy['directories']:
        walk(directory)
    for name in policy['files']:
        add(name)
    if not set(policy['required_runtime_paths']).issubset(seen):
        raise RuntimeError('R10_REQUIRED_RUNTIME_PATH_MISSING')
    rows.sort(key=lambda row: row['path'])
    return {'files': rows, 'digest': sha(canonical(rows)), 'total_bytes': total_bytes}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--reviewed-proposal-manifest-sha256', required=True)
    args = parser.parse_args()
    source = args.candidate_root
    output = args.output
    if not source.is_absolute() or not source.is_dir() or source.is_symlink():
        raise RuntimeError('R10_ABSOLUTE_REGULAR_CANDIDATE_SOURCE_ROOT_REQUIRED')
    source = source.resolve()
    if not output.is_absolute() or output.exists() or output.is_symlink():
        raise RuntimeError('R10_FRESH_ABSOLUTE_OUTPUT_REQUIRED')
    if source == output or source in output.parents or BASE == output or BASE in output.parents:
        raise RuntimeError('R10_FRESH_OUTSIDE_SOURCE_AND_PROPOSAL_OUTPUT_REQUIRED')
    manifest_bytes = read(BASE / 'proposal-source-manifest.json')
    if sha(manifest_bytes) != args.reviewed_proposal_manifest_sha256:
        raise RuntimeError('R10_REVIEWED_SOURCE_PROPOSAL_COMMITMENT_REQUIRED')
    manifest = json.loads(manifest_bytes)
    declared = {row['path']: row['sha256'] for row in manifest['files']}
    proposal_paths = sorted(PROPOSAL.rglob('*'))
    if any(path.is_symlink() or (not path.is_dir() and not path.is_file()) for path in proposal_paths):
        raise RuntimeError('R10_PROPOSAL_SYMLINK_OR_NONREGULAR_REFUSED')
    actual = {path.relative_to(PROPOSAL).as_posix(): sha(read(path)) for path in proposal_paths if path.is_file()}
    if declared != actual:
        raise RuntimeError('R10_REVIEWED_PROPOSAL_SOURCE_DRIFT')
    bindings = json.loads(read(PROPOSAL / 'source-bindings.json'))
    require_frozen_native_observer(source, bindings)
    first = capture(source, bindings['candidate_runtime_inventory_policy'])
    output.mkdir()
    destination = output / 'e2e/extension/legacy-paired-options-r10'
    shutil.copytree(PROPOSAL, destination, symlinks=False)
    bindings['candidate_runtime_sources'] = first['files']
    bindings['candidate_runtime_inventory_digest'] = first['digest']
    bindings['r10_campaign']['status'] = 'SOURCE_BOUND_NOT_EXECUTED_FULL_PASS_PENDING'
    declaration = json.loads(read(destination / 'predeclaration.json'))
    declaration['candidate_runtime_inventory_digest'] = first['digest']
    declaration['candidate_runtime_inventory_count'] = len(first['files'])
    declaration['status'] = 'SOURCE_BOUND_NOT_EXECUTED_FULL_PASS_PENDING'
    write(destination / 'predeclaration.json', declaration)
    bindings['predeclaration_digest'] = sha(read(destination / 'predeclaration.json'))
    write(destination / 'source-bindings.json', bindings)
    readiness = json.loads(read(destination / 'r10-readiness.json'))
    readiness['state'] = 'SOURCE_BOUND_REVIEWED'
    readiness['candidate_runtime_inventory_digest'] = first['digest']
    readiness['candidate_runtime_inventory_count'] = len(first['files'])
    readiness['note'] = 'Runtime source freeze only. All exact future full-PASS commit, proof and tool pins remain null in source preparation; actual execution requires separately reviewed out-of-band R10 release descriptor after exact clean committed full PASS. No actor has been invoked.'
    write(destination / 'r10-readiness.json', readiness)
    lock = json.loads(read(destination / 'campaign.lock.json'))
    lock['status'] = 'FROZEN_R10_RUNTIME_SOURCE_ONLY_NO_ACTORS_FULL_PASS_PENDING'
    lock['files'] = [{'path': name, 'sha256': sha(read(destination / name))} for name in sorted(declared) if name not in ['campaign.lock.json', 'campaign.lock.sha256']]
    write(destination / 'campaign.lock.json', lock)
    (destination / 'campaign.lock.sha256').write_text(sha(read(destination / 'campaign.lock.json')) + '\n')
    second = capture(source, bindings['candidate_runtime_inventory_policy'])
    if first != second:
        raise RuntimeError('R10_SOURCE_CHANGED_DURING_FREEZE_RETAIN_OUTPUT_AS_FAILED')
    for row in lock['files']:
        if sha(read(destination / row['path'])) != row['sha256']:
            raise RuntimeError('R10_OUTPUT_RECAPTURE_DRIFT')
    record = {'authority': 'NONE', 'gate_pass': False, 'builder_sha256': sha(read(Path(__file__))), 'reviewed_proposal_manifest_sha256': args.reviewed_proposal_manifest_sha256,
              'candidate_source_root': str(source), 'source_inventory_before': first, 'source_inventory_after': second,
              'campaign_lock_digest': sha(read(destination / 'campaign.lock.json')), 'candidate_actor_invocations': 0, 'legacy_actor_invocations': 0,
              'candidate_exact_commit': None, 'candidate_exact_tree': None, 'full_pass_proof': None,
              'scope': 'Source-only materialization. No Git-clean/commit, build, executable dependency, full-suite, browser or product acceptance claim.'}
    write(output / 'source-only-freeze-record.json', record)
    frozen_files = [{'path': path.relative_to(output).as_posix(), 'bytes': path.stat().st_size, 'sha256': sha(read(path))} for path in sorted(destination.rglob('*')) if path.is_file()]
    write(output / 'frozen-source-manifest.json', {'authority': 'NONE', 'gate_pass': False,
          'campaign_lock_path': 'e2e/extension/legacy-paired-options-r10/campaign.lock.json',
          'campaign_lock_digest': record['campaign_lock_digest'], 'source_graph_files': len(frozen_files), 'files': frozen_files,
          'candidate_exact_commit': None, 'full_pass_proof': None, 'actor_invocations': 0})
    import difflib
    patch = []
    for row in frozen_files:
        path = output / row['path']
        patch.extend(difflib.unified_diff([], path.read_text().splitlines(True), fromfile='/dev/null', tofile='b/' + row['path']))
    (output / 'r10-frozen-source.patch').write_text(''.join(patch))
    print(json.dumps({'campaign_source': str(destination), 'lock': record['campaign_lock_digest'], 'runtime': first['digest'], 'runtime_files': len(first['files']),
                      'frozen_source_manifest': str(output / 'frozen-source-manifest.json'), 'frozen_source_manifest_sha256': sha(read(output / 'frozen-source-manifest.json')), 'actor_invocations': 0}))


if __name__ == '__main__':
    main()
