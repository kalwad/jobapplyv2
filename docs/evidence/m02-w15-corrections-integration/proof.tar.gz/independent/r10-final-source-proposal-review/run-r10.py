"""Explicit post-freeze coordinator; preparation/import never runs a campaign."""

from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import signal
import stat
import subprocess
import sys
import time


# Out-of-band future release pins. These stay null during source preparation.
RELEASE_PATH = Path(__file__).with_name("r10-release.json")
RELEASE = json.loads(RELEASE_PATH.read_text())
ROOT = None
LEGACY = None
OUT = None
FROZEN = None
HERE = None
DIST = None
NODE = Path('/opt/homebrew/opt/node@24/bin/node')
PYTHON = None
HEAD = None
TREE = None
LOCK = None
RUNTIME = None
FROZEN_WRAPPER_SHA = None
RUNTIME_COUNT = None


def require_future_release():
    global ROOT, LEGACY, OUT, FROZEN, HERE, DIST, PYTHON
    global HEAD, TREE, LOCK, RUNTIME, FROZEN_WRAPPER_SHA, RUNTIME_COUNT
    required = ['source_root', 'legacy_root', 'output', 'full_proof_directory',
                'candidate_commit', 'candidate_tree', 'campaign_lock_digest',
                'runtime_inventory_digest', 'runtime_inventory_count',
                'full_wrapper_path', 'full_wrapper_sha256', 'full_completion_sha256',
                'full_commands_sha256', 'full_before_sha256', 'full_after_sha256',
                'full_wrapper_command_sha256', 'full_aggregate_log_sha256',
                'full_independent_verdict_path', 'full_independent_verdict_sha256',
                'node_binary_sha256', 'pnpm_binary_sha256', 'legacy_python_binary_sha256',
                'root_source_review_release']
    if RELEASE.get('state') != 'FROZEN_REVIEWED_AFTER_EXACT_FULL_PASS' or any(RELEASE.get(key) is None for key in required):
        raise RuntimeError('R10_SOURCE_ONLY_FUTURE_FULL_PASS_PINS_REQUIRED')
    import re
    if not all(re.fullmatch('[0-9a-f]{40}', RELEASE[key]) for key in ['candidate_commit', 'candidate_tree']):
        raise RuntimeError('R10_EXACT_CANDIDATE_COMMIT_TREE_REQUIRED')
    for key in required:
        if key.endswith('_sha256') or key.endswith('_digest'):
            if not isinstance(RELEASE[key], str) or not re.fullmatch('sha256:[0-9a-f]{64}', RELEASE[key]):
                raise RuntimeError('R10_EXACT_DIGEST_REQUIRED:' + key)
    if not isinstance(RELEASE['runtime_inventory_count'], int) or RELEASE['runtime_inventory_count'] <= 0:
        raise RuntimeError('R10_RUNTIME_COUNT_REQUIRED')
    for key in ['source_root', 'legacy_root', 'output', 'full_proof_directory', 'full_wrapper_path', 'full_independent_verdict_path']:
        if not isinstance(RELEASE[key], str) or not Path(RELEASE[key]).is_absolute():
            raise RuntimeError('R10_ABSOLUTE_RELEASE_PATH_REQUIRED:' + key)
    ROOT, LEGACY, OUT, FROZEN = (Path(RELEASE[key]) for key in ['source_root', 'legacy_root', 'output', 'full_proof_directory'])
    HERE = ROOT / 'e2e/extension/legacy-paired-options-r10'
    DIST = ROOT / 'apps/extension/dist/chrome-mv3'
    PYTHON = LEGACY / 'evaluation-runtime/bin/python'
    HEAD, TREE = RELEASE['candidate_commit'], RELEASE['candidate_tree']
    LOCK, RUNTIME = RELEASE['campaign_lock_digest'], RELEASE['runtime_inventory_digest']
    RUNTIME_COUNT = RELEASE['runtime_inventory_count']
    FROZEN_WRAPPER_SHA = RELEASE['full_wrapper_sha256']


def sha(body):
    return 'sha256:' + hashlib.sha256(body).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()


def read(path):
    return json.loads(path.read_text())


def write(name, value):
    path = OUT / name
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, timeout=30).decode().strip()


def files(directory):
    result = []
    for path in sorted(directory.rglob('*')):
        if path.is_symlink():
            raise RuntimeError('INVENTORY_SYMLINK_REFUSED:' + str(path))
        if path.is_dir():
            continue
        if not stat.S_ISREG(path.lstat().st_mode):
            raise RuntimeError('INVENTORY_NONREGULAR_REFUSED:' + str(path))
        body = path.read_bytes()
        result.append({'path': path.relative_to(directory).as_posix(), 'bytes': len(body), 'sha256': sha(body)})
    return result


def snapshot(include_build):
    tracked = []
    for name in subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT, timeout=30).decode().split('\0'):
        if not name:
            continue
        path = ROOT / name
        if path.is_symlink() or not stat.S_ISREG(path.lstat().st_mode):
            raise RuntimeError('TRACKED_REGULAR_SOURCE_REQUIRED:' + name)
        body = path.read_bytes()
        tracked.append({'path': name, 'bytes': len(body), 'sha256': sha(body)})
    bindings = read(HERE / 'source-bindings.json')
    runtime = [{'path': row['path'], 'sha256': sha((ROOT / row['path']).read_bytes())} for row in bindings['candidate_runtime_sources']]
    vendor = [{'path': row['path'], 'sha256': sha((LEGACY / row['path']).read_bytes())} for row in bindings['legacy_sources']]
    if len(runtime) != RUNTIME_COUNT or sha(canonical(runtime)) != RUNTIME or runtime != bindings['candidate_runtime_sources']:
        raise RuntimeError('CURRENT_RUNTIME_BINDING_DRIFT')
    if len(vendor) != 31 or vendor != bindings['legacy_sources']:
        raise RuntimeError('LEGACY_VENDOR_BINDING_DRIFT')
    if sha((HERE / 'campaign.lock.json').read_bytes()) != LOCK:
        raise RuntimeError('LOCK_DRIFT')
    return {'captured_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'status': git('status', '--porcelain=v1', '--untracked-files=normal'), 'tracked_files': tracked, 'tracked_inventory_digest': sha(canonical(tracked)), 'runtime_sources': runtime, 'runtime_digest': sha(canonical(runtime)), 'vendor_sources': vendor, 'comparison_sources': files(HERE), 'build_files': files(DIST) if include_build else None}


def clean_exact(value):
    return value['head'] == HEAD and value['tree'] == TREE and value['status'] == ''


def sanitized_environment():
    env = os.environ.copy()
    stripped = []
    for key in list(env):
        if key == 'TEST_WORKER_INDEX' or key.startswith(('JAPP_W14_PUBLIC', 'JAPP_W14_PAIRED', 'JAPP_W13_', 'JAPP_R10_')) or key in {'JAPP_W14_ARTIFACT_DIRECTORY', 'JAPP_W14_REQUIRE_TARGET_PERFORMANCE', 'PLAYWRIGHT_JSON_OUTPUT_NAME', 'PLAYWRIGHT_JSON_OUTPUT_FILE', 'PLAYWRIGHT_JSON_OUTPUT_DIR'}:
            stripped.append(key)
            del env[key]
    env['PATH'] = str(NODE.parent) + os.pathsep + env.get('PATH', '')
    env.update(JAPP_W14_PAIRED_EXPECTED_LOCK=LOCK, JAPP_W14_PAIRED_OPTIONS_EVALUATION='1')
    env.update(JAPP_R10_RELEASE_DESCRIPTOR=str(RELEASE_PATH.resolve()), JAPP_R10_RELEASE_DESCRIPTOR_SHA256=sha(RELEASE_PATH.read_bytes()))
    return env, sorted(stripped)


def run_stage(name, argv, env, timeout, stage_env=None):
    actual = env.copy()
    actual.update(stage_env or {})
    # The coordinator never supplies a worker index; Playwright alone owns it.
    actual.pop('TEST_WORKER_INDEX', None)
    log = OUT / (name + '.log')
    stderr_log = OUT / (name + '.stderr.log')
    record = {'stage': name, 'argv': argv, 'cwd': str(ROOT), 'timeout_seconds': timeout, 'task_environment': {k: v for k, v in actual.items() if k.startswith('JAPP_W14_PAIRED_') or k.startswith('JAPP_R10_') or k.startswith('PLAYWRIGHT_JSON_')}, 'worker_index_supplied': False, 'started_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'signals': [], 'cleanup_scope': 'OWNED_COORDINATOR_CHILD_PROCESS_GROUP_ONLY', 'os_descendants_outside_owned_group': 'UNOBSERVED'}
    started = time.monotonic()
    with log.open('xb') as stream, stderr_log.open('xb') as error_stream:
        child = subprocess.Popen(argv, cwd=ROOT, env=actual, stdout=stream, stderr=error_stream, start_new_session=True)
        record['pid'] = child.pid
        try:
            record['exit_code'] = child.wait(timeout=timeout)
            record['timed_out'] = False
        except BaseException as failure:
            record['timed_out'] = isinstance(failure, subprocess.TimeoutExpired)
            record['wait_error'] = {'type': type(failure).__name__, 'message': str(failure)[:500]}
            def owned_group_alive():
                child.poll()  # Reap the direct leader without assuming the group ended.
                try:
                    os.killpg(child.pid, 0)
                    return True
                except ProcessLookupError:
                    return False

            for sig, grace in [(signal.SIGTERM, 10), (signal.SIGKILL, 5)]:
                if not owned_group_alive():
                    break
                try:
                    os.killpg(child.pid, sig)
                    record['signals'].append(sig.name)
                except ProcessLookupError:
                    break
                deadline = time.monotonic() + grace
                while time.monotonic() < deadline and owned_group_alive():
                    time.sleep(0.05)
            record['exit_code'] = child.poll()
            record['owned_group_after_abort'] = 'STILL_PRESENT' if owned_group_alive() else 'GONE'
    record['ended_at'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    record['duration_seconds'] = time.monotonic() - started
    record['log_sha256'] = sha(log.read_bytes())
    record['log_bytes'] = log.stat().st_size
    record['stderr_sha256'] = sha(stderr_log.read_bytes())
    record['stderr_bytes'] = stderr_log.stat().st_size
    write(name + '.command.json', record)
    if record['timed_out'] or 'wait_error' in record or record['exit_code'] != 0:
        raise RuntimeError('STAGE_FAILED:' + name)
    return log.read_bytes()


def capture_tools(env, pnpm, suffix):
    node = run_stage('node-version-' + suffix, [str(NODE), '--version'], env, 30).decode().strip()
    package = run_stage('pnpm-version-' + suffix, [pnpm, '--version'], env, 30).decode().strip()
    code = "import importlib.metadata as m,json,sys; print(json.dumps({'python':sys.version,'executable':sys.executable,'dependencies':sorted(d.metadata['Name'].lower().replace('_','-')+'=='+d.version for d in m.distributions())},sort_keys=True))"
    python = json.loads(run_stage('legacy-python-' + suffix, [str(PYTHON), '-c', code], env, 30))
    frozen = sorted((HERE / 'preimages/evaluation-runtime.freeze.txt').read_text().splitlines())
    if node != 'v24.18.0' or package != '11.17.0' or not python['python'].startswith('3.12.13 ') or python['dependencies'] != frozen or len(frozen) != 13:
        raise RuntimeError('PINNED_TOOL_OR_PYTHON_DEPENDENCY_DRIFT')
    return {'coordinator_python': {'version': sys.version, 'executable': sys.executable, 'binary_sha256': sha(Path(sys.executable).read_bytes())}, 'node_version': node, 'node_path': str(NODE), 'node_realpath': str(NODE.resolve()), 'node_binary_sha256': sha(NODE.read_bytes()), 'pnpm_version': package, 'pnpm_path': pnpm, 'pnpm_realpath': str(Path(pnpm).resolve()), 'pnpm_binary_sha256': sha(Path(pnpm).read_bytes()), 'legacy_python': python, 'legacy_python_binary_sha256': sha(PYTHON.read_bytes())}


def specs(report):
    def walk(suites):
        for suite in suites:
            yield from suite.get('specs', [])
            yield from walk(suite.get('suites', []))
    return list(walk(report.get('suites', [])))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute-after-root-full-pass', action='store_true', required=True)
    args = parser.parse_args()
    if not args.execute_after_root_full_pass:
        raise RuntimeError('EXPLICIT_ROOT_RELEASE_REQUIRED')
    require_future_release()
    # All source and proof commitments are checked before creating output or tools.
    named = {
        'completion.json': 'full_completion_sha256', 'commands.json': 'full_commands_sha256',
        'before.json': 'full_before_sha256', 'after.json': 'full_after_sha256',
        'wrapper-command.json': 'full_wrapper_command_sha256', 'aggregate.log': 'full_aggregate_log_sha256',
    }
    for name, field in named.items():
        if sha((FROZEN / name).read_bytes()) != RELEASE[field]:
            raise RuntimeError('R10_FROZEN_FULL_PROOF_COMMITMENT_DRIFT:' + name)
    completion_bytes = (FROZEN / 'completion.json').read_bytes()
    completion = json.loads(completion_bytes)
    command_bytes = (FROZEN / 'commands.json').read_bytes()
    commands = json.loads(command_bytes)
    opened_bytes, closed_bytes = ((FROZEN / name).read_bytes() for name in ['before.json', 'after.json'])
    opened, closed = json.loads(opened_bytes), json.loads(closed_bytes)
    wrapper = read(FROZEN / 'wrapper-command.json')
    if sha(Path(RELEASE['full_wrapper_path']).read_bytes()) != FROZEN_WRAPPER_SHA or wrapper.get('wrapper_sha256') != FROZEN_WRAPPER_SHA.removeprefix('sha256:') or wrapper.get('expected_head') != HEAD:
        raise RuntimeError('R10_EXACT_FULL_WRAPPER_IDENTITY_REQUIRED')
    target_flags = {'JAPP_W13_PERFORMANCE_SAMPLES': '20', 'JAPP_W14_REQUIRE_TARGET_PERFORMANCE': '1', 'JAPP_W14_ARTIFACT_DIRECTORY': str(FROZEN / 'w14'), 'JAPP_W14_W06_ARTIFACT_DIRECTORY': str(FROZEN / 'mounted32')}
    if wrapper.get('task_environment') != target_flags:
        raise RuntimeError('R10_UNCHANGED_FULL_TARGET_ENVIRONMENT_REQUIRED')
    doctor = [row for row in commands if row.get('name') == 'doctor']
    aggregate = [row for row in commands if row.get('name') == 'aggregate']
    if len(doctor) != 1 or len(aggregate) != 1:
        raise RuntimeError('R10_EXACT_ONE_DOCTOR_ONE_AGGREGATE_REQUIRED')
    doctor, aggregate = doctor[0], aggregate[0]
    if doctor.get('argv') != ['pnpm', 'run', 'doctor'] or aggregate.get('argv') != ['pnpm', 'verify'] or doctor.get('cwd') != str(ROOT) or aggregate.get('cwd') != str(ROOT) or doctor.get('exit_code') != 0 or aggregate.get('exit_code') != 0 or doctor.get('ended_at', '') > aggregate.get('started_at', ''):
        raise RuntimeError('R10_EXACT_SERIAL_DOCTOR_FULL_PASS_REQUIRED')
    if doctor.get('log_sha256') != sha((FROZEN / 'doctor.log').read_bytes()).removeprefix('sha256:') or doctor.get('log_bytes') != (FROZEN / 'doctor.log').stat().st_size:
        raise RuntimeError('R10_DOCTOR_LOG_RECONCILIATION_REQUIRED')
    if aggregate.get('log_sha256') != RELEASE['full_aggregate_log_sha256'].removeprefix('sha256:') or aggregate.get('log_bytes') != (FROZEN / 'aggregate.log').stat().st_size:
        raise RuntimeError('R10_FULL_LOG_RECONCILIATION_REQUIRED')
    if completion.get('exit_code') != 0 or completion.get('head_unchanged') is not True or completion.get('tree_unchanged') is not True or completion.get('tracked_inventory_unchanged') is not True or completion.get('status_before') != '' or completion.get('status_after') != '' or not clean_exact(opened) or not clean_exact(closed) or opened.get('tracked_files') != closed.get('tracked_files') or opened.get('tracked_inventory_digest') != closed.get('tracked_inventory_digest'):
        raise RuntimeError('R10_EXACT_CLEAN_FROZEN_FULL_PASS_COMPLETION_REQUIRED')
    verdict_path = Path(RELEASE['full_independent_verdict_path'])
    if sha(verdict_path.read_bytes()) != RELEASE['full_independent_verdict_sha256']:
        raise RuntimeError('R10_ACTUAL_INDEPENDENT_FULL_VERDICT_REQUIRED')
    # Required descriptor is prepared only from the new closed independent raw
    # audit. Its schema and raw source binding must be source-reviewed at freeze.
    verdict = read(verdict_path)
    if verdict.get('candidate_commit') != HEAD or verdict.get('candidate_tree') != TREE or verdict.get('full_completion_sha256') != RELEASE['full_completion_sha256'] or verdict.get('recommendation') != 'CLEAR_EXACT_FULL_PASS' or verdict.get('all_actual_checks_passed') is not True:
        raise RuntimeError('R10_INDEPENDENT_EXACT_FULL_PASS_NOT_CLEAR')
    if OUT.exists() or OUT.is_symlink() or ROOT.resolve() == OUT.resolve() or ROOT.resolve() in OUT.resolve().parents or not OUT.is_absolute():
        raise RuntimeError('FRESH_OUTSIDE_RUN_DIRECTORY_REQUIRED')
    before = snapshot(False)
    if not clean_exact(before):
        raise RuntimeError('EXACT_CLEAN_FUTURE_R10_CANDIDATE_SOURCE_REQUIRED')
    env, stripped = sanitized_environment()
    pnpm = shutil.which('pnpm', path=env['PATH'])
    if pnpm is None:
        raise RuntimeError('PINNED_PNPM_MISSING')
    OUT.mkdir()
    write('before.json', before)
    write('coordinator.json', {'authority': 'NONE', 'script_sha256': sha(Path(__file__).read_bytes()), 'argv': [sys.executable, *sys.argv], 'invocation_cwd': str(Path.cwd()), 'expected_head': HEAD, 'expected_tree': TREE, 'expected_lock': LOCK, 'expected_runtime': RUNTIME, 'prior_full_completion_sha256': sha(completion_bytes), 'prior_full_before_snapshot_sha256': sha(opened_bytes), 'prior_full_after_snapshot_sha256': sha(closed_bytes), 'prior_full_command_sha256': sha(command_bytes), 'release_descriptor_sha256': sha(RELEASE_PATH.read_bytes()), 'campaign_revision': 10, 'removed_environment_variable_names_only': stripped, 'outcomes_inherited': False, 'candidate_output': str(OUT / 'candidate'), 'legacy_output': str(OUT / 'legacy')})
    before_tools = None
    before_actors = None
    success = False
    error = None
    try:
        before_tools = capture_tools(env, pnpm, 'before')
        write('tools-before.json', before_tools)
        if before_tools['node_binary_sha256'] != RELEASE['node_binary_sha256'] or before_tools['pnpm_binary_sha256'] != RELEASE['pnpm_binary_sha256'] or before_tools['legacy_python_binary_sha256'] != RELEASE['legacy_python_binary_sha256']:
            raise RuntimeError('R10_EXACT_RELEASE_TOOL_BINARY_DRIFT')
        preflight = "import {loadCampaign} from './e2e/extension/legacy-paired-options-r10/campaign.mjs';const c=loadCampaign({candidateRoot:" + json.dumps(str(ROOT)) + ",legacyRoot:" + json.dumps(str(LEGACY)) + "});process.stdout.write(JSON.stringify({lock:c.lock_digest,cases:c.inputs.length})+'\\n');"
        run_stage('source-preflight', [str(NODE), '--input-type=module', '-e', preflight], env, 60)
        run_stage('default-build', [pnpm, '--filter', '@japp/extension', 'build'], env, 300)
        before_actors = snapshot(True)
        write('before-actors.json', before_actors)
        if not clean_exact(before_actors) or before_actors['tracked_inventory_digest'] != before['tracked_inventory_digest']:
            raise RuntimeError('SOURCE_CHANGED_DURING_FRESH_BUILD')
        cli = [str(NODE), str(ROOT / 'node_modules/@playwright/test/cli.js'), 'test', '--config', 'e2e/extension/legacy-paired-options-r10/playwright.config.ts']
        discovery_bytes = run_stage('discovery', cli + ['--list', '--reporter=json'], env, 60, {'JAPP_W14_PAIRED_OPTIONS_OUTPUT': str(OUT / 'discovery')})
        with (OUT / 'discovery.json').open('xb') as stream:
            stream.write(discovery_bytes)
        discovery = json.loads(discovery_bytes)
        bindings = read(HERE / 'source-bindings.json')
        expected_titles = ['paired explicit approved options: ' + row['fixture_id'] for row in bindings['cases']]
        declared_specs = specs(discovery)
        if discovery.get('errors') or [row['title'] for row in declared_specs] != expected_titles or len(declared_specs) != 4 or discovery['config']['workers'] != 1 or any(project['retries'] != 0 for project in discovery['config']['projects']):
            raise RuntimeError('EXACT_FOUR_DISCOVERY_REQUIRED')
        run_stage('candidate', cli + ['--reporter=list,json'], env, 360, {'JAPP_W14_PAIRED_OPTIONS_OUTPUT': str(OUT / 'candidate'), 'PLAYWRIGHT_JSON_OUTPUT_NAME': str(OUT / 'candidate-report.json')})
        candidate_report = read(OUT / 'candidate-report.json')
        if candidate_report.get('errors') or any(candidate_report['stats'][key] != value for key, value in {'expected': 4, 'unexpected': 0, 'skipped': 0, 'flaky': 0}.items()):
            raise RuntimeError('EXACT_FOUR_NORMAL_CANDIDATE_PASSES_REQUIRED')
        candidates = list((OUT / 'candidate').rglob('paired-options-candidate.json'))
        expected_ids = {row['case_id'] for row in bindings['cases']}
        if len(candidates) != 4 or {read(path)['case_id'] for path in candidates} != expected_ids:
            raise RuntimeError('FOUR_CANDIDATE_RAW_ARTIFACTS_REQUIRED')
        run_stage('legacy-launch', [str(NODE), str(HERE / 'run-legacy.mjs')], env, 240, {'JAPP_W14_PAIRED_CANDIDATE_ROOT': str(ROOT), 'JAPP_W14_PAIRED_LEGACY_ROOT': str(LEGACY), 'JAPP_W14_PAIRED_PYTHON': str(PYTHON), 'JAPP_W14_PAIRED_PLAYWRIGHT_MODULE': str(ROOT / 'node_modules/@playwright/test/index.mjs'), 'JAPP_W14_PAIRED_LEGACY_OUTPUT': str(OUT / 'legacy')})
        legacy = read(OUT / 'legacy/paired-options-legacy.json')
        control = read(OUT / 'legacy.control.json')
        if legacy.get('complete') is not True or legacy.get('source_stability') is not True or len(legacy.get('results', [])) != 4 or control.get('complete') is not True or control.get('campaign_lock_digest') != LOCK:
            raise RuntimeError('FRESH_COMPLETE_LEGACY_FOUR_REQUIRED')
        run_stage('offline-compare', [str(NODE), str(HERE / 'compare-paired.mjs'), str(OUT / 'candidate'), str(OUT / 'legacy/paired-options-legacy.json'), str(OUT / 'paired-comparison.json')], env, 60)
        worksheet = read(OUT / 'paired-comparison.json')
        if worksheet.get('campaign_lock_digest') != LOCK or len(worksheet.get('cases', [])) != 4 or sum(len(row['fields']) for row in worksheet['cases']) != 40:
            raise RuntimeError('EXACT_NEW_FOUR_CASE_FORTY_FIELD_JOIN_REQUIRED')
        run_stage('source-postflight', [str(NODE), '--input-type=module', '-e', preflight], env, 60)
        success = True
    except BaseException as failure:
        error = {'type': type(failure).__name__, 'message': str(failure)[:1000]}
    finally:
        after = None
        after_tools = None
        evidence_errors = []
        try:
            after = snapshot(before_actors is not None)
            write('after.json', after)
        except BaseException as failure:
            evidence_errors.append({'scope': 'after_snapshot', 'type': type(failure).__name__, 'message': str(failure)[:1000]})
        try:
            after_tools = capture_tools(env, pnpm, 'after')
            write('tools-after.json', after_tools)
        except BaseException as failure:
            evidence_errors.append({'scope': 'after_tools', 'type': type(failure).__name__, 'message': str(failure)[:1000]})
        checks = {'clean_exact_head_tree': clean_exact(after) if after is not None else False, 'all_tracked_bytes_unchanged': before['tracked_inventory_digest'] == after['tracked_inventory_digest'] if after is not None else False, 'runtime_unchanged': before['runtime_sources'] == after['runtime_sources'] if after is not None else False, 'vendor_unchanged': before['vendor_sources'] == after['vendor_sources'] if after is not None else False, 'comparison_sources_unchanged': before['comparison_sources'] == after['comparison_sources'] if after is not None else False, 'tools_unchanged': before_tools == after_tools if before_tools is not None and after_tools is not None else False, 'fresh_build_unchanged_through_actors': before_actors['build_files'] == after['build_files'] if before_actors is not None and after is not None else False}
        write('completion.json', {'authority': 'NONE', 'pipeline_exit_success': success and not evidence_errors and all(checks.values()), 'error': error, 'evidence_errors': evidence_errors, 'checks': checks, 'outcomes_inherited': False, 'gate_pass': False, 'candidate_cleanup_scope': 'Normal fixture context.close/profile removal awaited by passing tests; no per-case OS descendant certificate.', 'legacy_cleanup_scope': 'Use raw legacy.control.json and legacy artifact normal context/profile records; OS browser descendants UNOBSERVED.', 'actual_metrics': 'REQUIRE_READ_ONLY_AUDIT_OF_NEW_RAW_WORKSHEET_INCLUDING_UNEXPECTED_NATIVE_ARRAYS', 'ended_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())})
    return 0 if success and not evidence_errors and all(checks.values()) else 1


if __name__ == '__main__':
    raise SystemExit(main())
