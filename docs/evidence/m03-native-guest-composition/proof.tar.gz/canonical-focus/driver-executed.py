from pathlib import Path
from datetime import UTC,datetime
import json,hashlib,stat,subprocess,os,signal,time
R=Path('/Users/tanishkalwad/jobapplyv2');E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');O=E/'native-guest-canonical-focus-v2';assert not O.exists();O.mkdir();(O/'driver-executed.py').write_bytes(Path(__file__).read_bytes())
def tree(root):return {p.relative_to(root).as_posix():row(p) for p in sorted(root.rglob('*')) if p.is_file()}
def row(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink();b=p.read_bytes();return {'bytes':len(b),'mode':stat.S_IMODE(s.st_mode),'sha256':hashlib.sha256(b).hexdigest()}
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
def snap():return {'source':{os.fsdecode(n):row(R/os.fsdecode(n)) for n in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=R).split(b'\0') if n},'runtime':tree(R/'apps/desktop/src-tauri/runtime-payload'),'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain','--untracked-files=all')}
before=snap();assert len(before['source'])==2333 and len(before['runtime'])==40;(O/'before.json').write_text(json.dumps(before,indent=2)+'\n');records=[];env=dict(os.environ);env['PATH']='/opt/homebrew/opt/node@24/bin:'+env['PATH']
def run(name,args,budget=180):
 tick=time.monotonic();start=datetime.now(UTC).isoformat()
 with (O/(name+'.log')).open('wb') as out:
  child=subprocess.Popen(args,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,start_new_session=True);pid=child.pid;expired=False;sigs=[]
  try:code=child.wait(timeout=budget)
  except subprocess.TimeoutExpired:
   expired=True
   for sig in [signal.SIGTERM,signal.SIGKILL]:
    try:os.killpg(pid,sig);sigs.append(sig.name)
    except ProcessLookupError:pass
   code=child.wait(timeout=10)
 try:os.killpg(pid,0);group='PRESENT'
 except ProcessLookupError:group='ABSENT'
 record={'name':name,'argv':args,'cwd':str(R),'pid':pid,'pgid':pid,'start_utc':start,'end_utc':datetime.now(UTC).isoformat(),'seconds':time.monotonic()-tick,'exit_code':code,'timeout':expired,'reaped':child.returncode is not None,'group':group,'signals':sigs};records.append(record);(O/'results.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True);assert code==0 and not expired and group=='ABSENT'
u=['uv','run','--no-sync','--offline'];tests=['scripts/tests/test_windows11_inputs.py', 'scripts/tests/test_windows11_request.py', 'scripts/tests/test_windows11_isolation.py', 'scripts/tests/test_windows11_resources.py', 'scripts/tests/test_native_shell_capture.py', 'scripts/tests/test_native_timestamp.py', 'scripts/tests/test_linux_bytecode_marshal.py', 'scripts/tests/test_linux_gnome_isolation.py', 'scripts/tests/test_ci_workflow.py', 'scripts/tests/test_ubuntu_gnome_signed_indexes.py']
try:
 run('ruff',u+['ruff','check','--config','pyproject.toml','scripts/check_portability.py','scripts/windows11','scripts/linux_gnome','scripts/tests'])
 run('format',u+['ruff','format','--check','--config','pyproject.toml','scripts/check_portability.py','scripts/windows11','scripts/linux_gnome','scripts/tests'])
 run('mypy-linux',u+['mypy','--config-file','pyproject.toml','--platform','linux','scripts/check_portability.py','scripts/windows11','scripts/linux_gnome',*tests])
 run('mypy-win32',u+['mypy','--config-file','pyproject.toml','--platform','win32',*tests])
 run('prettier',['pnpm','exec','prettier','--check','scripts/python-test-inventory.v1.json'])
 run('focused-python',u+['pytest','-c','pyproject.toml','--strict-config','--strict-markers','-p','no:cacheprovider','--basetemp',str(O/'pytest-temp'),'-q',*tests])
 run('collection',u+['pytest','-c','pyproject.toml','--strict-config','--strict-markers','-p','no:cacheprovider','--collect-only','-q','services/orchestrator/tests','scripts/tests'])
 run('portability',u+['python','scripts/check_portability.py','--quiet'])
 run('integrity',u+['python','scripts/verify.py','--suite','integrity'])
 run('diff-check',['git','diff','--check'])
finally:
 after=snap();(O/'after.json').write_text(json.dumps(after,indent=2)+'\n');closure={'end_utc':datetime.now(UTC).isoformat(),'logical_source':len(before['source']),'runtime':len(before['runtime']),'all_source_runtime_bytes_fullmodes_status_head_tree_equal':before==after,'commands':len(records),'all_ten_commands_closed_zero':len(records)==10 and all(r['exit_code']==0 and not r['timeout'] and r['group']=='ABSENT' and r['reaped'] and not r['signals'] for r in records)};(O/'closure.json').write_text(json.dumps(closure,indent=2)+'\n');print(json.dumps(closure),flush=True);assert before==after
