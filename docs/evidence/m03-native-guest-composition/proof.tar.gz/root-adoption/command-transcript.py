# Exact original stdin Python body, retained after tool execution; this file itself was not executed.
from pathlib import Path
import hashlib,json,stat,os,subprocess,datetime,importlib.util,py_compile,struct
R=Path('/Users/tanishkalwad/jobapplyv2');E=R.parent/'jobapplyv2-evidence/resume-20261028';P=E/'m03-native-guest-composition/v1';V=E/'m03-native-guest-composition-independent-review/v1';O=E/'native-guest-canonical-adoption/v2';O.mkdir(parents=True,exist_ok=False)
def row(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink();b=p.read_bytes();return {'bytes':len(b),'full_mode':s.st_mode,'sha256':hashlib.sha256(b).hexdigest()}
def snapshot():
 names=[os.fsdecode(n) for n in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=R).split(b'\0') if n]
 return {'source':{n:row(R/n) for n in names},'runtime':{p.relative_to(R).as_posix():row(p) for p in sorted((R/'apps/desktop/src-tauri/runtime-payload').rglob('*')) if p.is_file()}}
assert row(P/'SOURCE.json')['sha256']=='bb72f9308e2d3207d450887a0f5c29b32d537864a63def4f3d32d4318188669c';assert row(V/'REVIEW.md')['sha256']=='5b8b877bf9d245f978b013df2e7eb4b53379a28c581bdf8c80d6840a3320fac4'
rows=json.loads((P/'SOURCE.json').read_bytes())['paths'];assert len(rows)==13;before=snapshot();oldcaches={};allowed={v['path'] for v in rows}
for v in rows:
 p=R/v['path'];assert (row(p) if p.exists() else None)==v['before'];assert row(P/'after'/v['path'])==v['after']
 if p.exists():
  q=O/'before'/v['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes());q.chmod(stat.S_IMODE(p.lstat().st_mode))
 if p.suffix=='.py' and p.parent in [R/'scripts/linux_gnome',R/'scripts/windows11']:
  cache=Path(importlib.util.cache_from_source(str(p)))
  if cache.exists():
   s=cache.lstat();assert stat.S_ISREG(s.st_mode) and not cache.is_symlink() and s.st_uid==os.getuid() and s.st_nlink==1;oldcaches[v['path']]={'path':cache,'before':row(cache)};q=O/'old-owned-caches'/cache.relative_to(R);q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(cache.read_bytes());q.chmod(stat.S_IMODE(s.st_mode))
(O/'before.json').write_text(json.dumps(before,indent=2)+'\n');(O/'adoption-plan.json').write_text(json.dumps(rows,indent=2)+'\n')
for v in rows:
 p=R/v['path'];p.write_bytes((P/'after'/v['path']).read_bytes());p.chmod(stat.S_IMODE(v['after']['full_mode']));assert row(p)==v['after']
actions=[]
for name,v in oldcaches.items():
 p=R/name;cache=v['path'];assert row(cache)==v['before'];s=p.stat();expected=importlib.util.MAGIC_NUMBER+struct.pack('<III',0,int(s.st_mtime)&0xffffffff,s.st_size);old=cache.read_bytes();assert old[:16]!=expected
 py_compile.compile(str(p),cfile=str(cache),dfile=str(p),doraise=True,optimize=0,invalidation_mode=py_compile.PycInvalidationMode.TIMESTAMP);assert cache.read_bytes()[:16]==expected;actions.append({'source':name,'cache':cache.relative_to(R).as_posix(),'before':v['before'],'after':row(cache),'old_header_hex':old[:16].hex(),'new_header_hex':expected.hex()})
after=snapshot();assert all(after['source'][n]==v for n,v in before['source'].items() if n not in allowed);assert after['runtime']==before['runtime'];assert len(after['source'])==len(before['source'])+3;assert len(actions)==5
(O/'after.json').write_text(json.dumps(after,indent=2)+'\n');(O/'cache-actions.json').write_text(json.dumps(actions,indent=2)+'\n');result={'utc':datetime.datetime.now(datetime.UTC).isoformat(),'adopted_paths':13,'source_before':len(before['source']),'source_after':len(after['source']),'added_paths':3,'all_unselected_source_bytes_modes_and_runtime_equal':True,'exact_five_owned_newly_stale_caches_regenerated':5,'old_cache_bytes_retained':True,'scope':'Guarded exact reviewed composition. Standardtimestampcompile ofknownOWNsource only, no unknownload/sourceexecution/cachedeletion. No native/COM/provider/VM/API/model action.'};(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
