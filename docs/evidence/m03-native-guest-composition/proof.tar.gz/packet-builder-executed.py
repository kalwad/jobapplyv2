"""Retain closed, explicitly selected local evidence; never execute subjects."""
from pathlib import Path, PurePosixPath
import datetime, gzip, hashlib, io, json, os, stat, sys, tarfile

E = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
config_path = Path(sys.argv[1])
config = json.loads(config_path.read_bytes())
output = Path(config['output'])
assert output.is_relative_to(E) and not output.exists()

def row(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink()
    body = path.read_bytes()
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest(), 'full_mode': info.st_mode}

for binding in config['pins']:
    assert row(Path(binding['path']))['sha256'] == binding['sha256']
selected = {}
for item in config['files']:
    name = item['archive_path']
    q = PurePosixPath(name)
    assert q.as_posix() == name and not q.is_absolute() and '..' not in q.parts and '\\' not in name
    assert name not in selected
    path = Path(item['source_path'])
    assert path.is_relative_to(E)
    selected[name] = path
selected['packet-builder-executed.py'] = Path(__file__)
selected['packet-config.json'] = config_path
assert sum(row(path)['bytes'] for path in selected.values()) <= 100 * 1024 * 1024
output.mkdir(parents=True)
records = []
with (output / 'proof.tar.gz').open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, path in sorted(selected.items()):
                value = row(path)
                body = path.read_bytes()
                info = tarfile.TarInfo(name)
                info.size = len(body)
                info.mode = stat.S_IMODE(value['full_mode'])
                archive.addfile(info, io.BytesIO(body))
                records.append({'path': name, 'source_path': str(path), 'mode': info.mode, **value})
by_name = {record['path']: record for record in records}
seen = set()
with tarfile.open(output / 'proof.tar.gz') as archive:
    for info in archive:
        assert info.isfile() and not info.issym() and not info.islnk() and info.name not in seen
        seen.add(info.name)
        value = by_name[info.name]
        stream = archive.extractfile(info)
        assert stream is not None
        body = stream.read()
        assert len(body) == value['bytes'] and hashlib.sha256(body).hexdigest() == value['sha256'] and info.mode == value['mode']
        assert row(Path(value['source_path'])) == {key: value[key] for key in ('bytes', 'sha256', 'full_mode')}
assert seen == set(by_name)
for binding in config['pins']:
    assert row(Path(binding['path']))['sha256'] == binding['sha256']

def dump(name, value):
    (output / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

dump('retention-manifest.json', {'files': records, 'file_count': len(records), 'all_selected_bytes_full_modes_verified': True, 'pins': config['pins'], 'scope': config['retention_scope'], 'created_utc': datetime.datetime.now(datetime.UTC).isoformat()})
dump('artifact.json', {'path': 'proof.tar.gz', 'mode': stat.S_IMODE((output / 'proof.tar.gz').stat().st_mode), **row(output / 'proof.tar.gz')})
dump('summary.json', config['summary'])
(output / 'README.md').write_text(config['readme'])
print(json.dumps({'path': str(output), 'members': len(records), 'proof': row(output / 'proof.tar.gz')}))
