# Independent actual guest adoption, cache and focus review

Verdict: **CLEAR_FINITE_ACTUAL_GUEST_ADOPTION_CACHE_AND_FOCUS**. All 2,591 finite source/data joins pass. Exact adoption, retained cache outcomes and the closed focus campaign agree with their stated scope. No actionable adoption discrepancy was established. This is not a new source-design, native acceptance or complete-project verdict.

The reviewed records are `native-guest-canonical-adoption/v2` and `native-guest-canonical-focus-v2`, closed **2026-10-29T20:29:20.319352+00:00**. `copied-members.json` binds the exact retained copies, origins, full modes and SHA-256 commitments. The underlying prepared composition SOURCE is `bb72f9308e2d3207d450887a0f5c29b32d537864a63def4f3d32d4318188669c`, independently reviewed at `5b8b877bf9d245f978b013df2e7eb4b53379a28c581bdf8c80d6840a3320fac4`.

## Guarded adoption and finite context

All thirteen plan rows match that reviewed SOURCE and its afterimages. Ten existing preimages match the retained canonical before snapshot and saved beforeimages; three additions are absent in that before snapshot. The source set grows from **2,330 to 2,333** by exactly those three additions. Every unselected source byte/full-mode entry and all forty runtime-payload entries remain equal between adoption endpoints.

The previous closed source phase contained 2,310 logical files. The new pre-adoption phase adds twenty evidence paths under `docs/evidence/` and changes exactly four factual documentation paths: `COMPATIBILITY_MATRIX.md`, `KNOWN_ISSUES.md`, `PROJECT_STATUS.md` and `TEST_EVIDENCE.md`. Those context changes are separated from the thirteen-path implementation adoption. No unsupported assertion that the whole repository stayed unchanged across these distinct phases is made.

The adoption after projection exactly matches the focus before projection, accounting explicitly for their different runtime-map roots and metadata field names. Focus before and after source, runtime, HEAD, tree and status records are equal. HEAD is `a7caf7101a7445294c8776c6c09c6cbd0d107bc9`, tree `9173225507ad3c4a43c1f4978cc5f005a30264f7`. These are closed-phase records; later authorized root metadata changes are outside this review. No direct index-file digest or absence-of-transient-writes proof is supplied.

## Recorded replacements and independent cache observation

The root records five existing owned cache replacements: GNOME AT-SPI, guest, provision and VM helpers, plus Windows input validation. Each original retained byte/full-mode pin joins the previously reviewed after-cache observation. The transcript checks regular, nonsymlink, same-owner, single-link files; guards the selected source beforeimages; and uses CPython 3.12.13 standard `py_compile`, timestamp invalidation, optimize=0 and the exact absolute `dfile`. Cache bytes are never loaded as code.

The reviewer independently observes **twenty** regular cache entries in the two finite GNOME/Windows islands. All twenty headers, source mtime/size values, CPython magic, zero flags and complete inert graph commitments match trusted approved-source compilation with the exact absolute filename. Source is compiled only into memory and never executed. All five replaced originals differ in both header and source commitment and remain refused. Fourteen other observed cache byte/full-mode pins match the earlier observation.

The twentieth entry is the newly registered `ubuntu_gnome_shell.cpython-312.pyc`. Its approved source/header/signature are valid. It was absent from the previous nineteen-entry observation; **its writer was not independently observed**. Ordinary focused pytest creation is an inference consistent with the new helper import, not direct writer custody. There is no complete immediately pre-focus cache inventory. Consequently this review does not claim that only five cache files changed throughout focus, or that all other caches everywhere remained unchanged. Five manual replacements, fourteen matching historical pins and one newly observed registered helper are distinct evidence statements.

The original tool stdin body is retained after execution as `command-transcript.py`, with a comment explaining that this retained file itself was not executed. Provenance reports tool exit zero and explicitly records that the tool interpreter PID/process group was not independently measured. The reviewer verifies the content outcome and record joins without inventing that missing custody evidence.

## Closed canonical focus evidence

The executed focus driver is exact with its retained original source. All ten sequential commands report exit zero:

- Ruff, format, catalog Prettier, Linux strict checking of 33 files and prospective Win32 checking of ten selected fixtures.
- **441 Python tests passed in 6.89 seconds**.
- **2,788 unique collected IDs**, exactly the catalog: 2,786 common and the unchanged two POSIX IDs, with the correct ID commitment.
- Portability, integrity and diff checks pass; integrity explicitly reports verification exit code zero.

All ten direct command children are recorded reaped, with their original groups absent and no signal or timeout. The driver checks each result before proceeding. Collection of 2,788 IDs is not execution of all 2,788 tests. The pure/source/strict records do not establish native Windows/GNOME, C#/PowerShell/COM/provider behavior, VM execution, native GUI measurements or complete aggregate validation. No extra 693-case replay or source-design re-audit was performed.

## Observer history and limits

The first read-only capture expected the prior nineteen cache paths and stopped upon seeing the valid newly registered twentieth entry. Its failed condition, error, partial-copy state and correction are retained in `history/initial-capture-failure.json`. The partial reference copies remain exact; no successful data index was published by that failed capture. The corrected observation explicitly retains the larger inventory and its provenance limit rather than hiding or treating it as five-only history.

Both reviewer-owned pure children, cache observation and final data audit, exit zero, are reaped, have absent original process groups, use no signals/timeouts and preserve all retained-copy endpoints. The earlier capture ran under the tool-owned interpreter with no independent numeric custody record; it is not silently included in those two child receipts. Inert copied cache binaries are proof artifacts, not generated/imported caches. No canonical source, original cache or runtime was changed by the reviewer; no unknown cache was unmarshaled, no helper source executed and no native/API/model actor ran.

Prior failed campaigns and source-preparation history remain unchanged. Clean aggregate verification, CI and any native acceptance remain root-owned future work. This finite CLEAR grants no milestone, gate or finished-product claim.
