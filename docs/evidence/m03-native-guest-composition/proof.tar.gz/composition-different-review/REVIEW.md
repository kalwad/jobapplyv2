# Independent guest13 / COMv2 / current-parser composition review

Verdict: **CLEAR_FINITE_GUEST_COMPOSITION_SOURCE_PREPARATION**. All 4,251 source/data joins pass. No actionable merge defect was established. This is a finite review of the prepared 13-path composition, not canonical adoption or native acceptance.

The immutable subject is `m03-native-guest-composition/v1`: SOURCE `bb72f9308e2d3207d450887a0f5c29b32d537864a63def4f3d32d4318188669c`, HANDOFF `b69e4e80ae544eb18e2d4e5c082411aa0b4fbebc0d202ced136357804ae41bad`, REPORT `24082cddcf3984cd23744c29b819c042719a878208d531a8dd78442e7ac38259`, manifest `f878eec31aefc9fd12661d55f2c9c964f3f85ea54999163a6a24f0cc8c4aac1d`, proof `25e56880b23eb1eeab82e3bcb0d2bc669ccdb1ec6fde1fd52f42ffd6c47c1d53`. All 1,363 manifest members and 1,364 safe regular archive members were checked before copying. `copied-members.json` binds exact reviewer copies and immutable origins by bytes, full modes and SHA-256. No mutable draft was reviewed.

## Merge source checks

The 13 selected before/after paths match `SOURCE.json` and the actual tested projection. Ten existing preimages match the previously closed root 2,310-source-file phase; the three proposed additions are absent in that phase. Seventeen finite source/config context pins match that closed source context. Concurrent authorized root evidence additions remain disclosed; no present whole-canonical epoch equality is asserted.

Nine guest afterimages remain exact with original guest SOURCE `0be49bb8f05a5a5468ef0e404bf70d13affbd2fbffea354201174b780bc3796f`, reviewed at `c42b4e3b442ceec31475abc95f88aaf3dc4ea6ca59e47dd1779417e88eb25ac2`. Four paths have explicit composition:

- The C# afterimage is exactly `5337bf5e16c0755d8269cf22d94b86eb39ac0397b71abccc07e27746b4d52b8e`, bound to COMv2 SOURCE `071e95a67d68c635255fba13b6600a84ef062ea5eb273ad4dedb4b1a7eb7fb4a` and different source/compile review `8692081830129696bad66a676fdedd6b2b179b9c4f7e3d05716bbc20e5f02114`. The earlier managed-role compiler failure remains historical; this review did not run a compiler or call COM.
- `windows11_inputs.py` is byte-exact original guest source with one portable-path expression replacement: `actual.add(str(node.relative_to(root)))` becomes `actual.add(node.relative_to(root).as_posix())`. The complete `original_package` function AST equals the current corrected preimage. Both existing Windows portable-path test bodies remain exact and pass in the fresh replay.
- `check_portability.py` changes only `LINUX_INFRASTRUCTURE_MODULES`, `WINDOWS11_NATIVE_PINS`, and `WINDOWS11_SHARED_HELPERS`. Independently restoring those three original assignments reconstructs the entire current parser checker byte-for-byte, SHA-256 `5aa4395e7b7fd07671c70b9a0fa9244cf0e5a612a3c00615f3b5fa96541d6dd0`. Every current function/class AST is unchanged. All 75 parser-test bodies remain byte/full-mode exact.
- The catalog retains all current 2,704 IDs, adds the 83 explicit original guest IDs and the single actual registered-module case `scripts/tests/test_linux_gnome_isolation.py::test_every_registered_module_is_required[ubuntu_gnome_shell.py]`. It contains 2,786 common IDs and the unchanged two POSIX IDs, with the expected canonical ID commitment.

Every other file in the finite projection matches its closed root preimage. All 64 previous Python test/oracle files are whole-file exact, including the current parser and portable-path corrections. No old test expectation or safety oracle was changed to obtain the composition's result.

## Actual independent and retained validation

Fresh execution on the reviewer's exact copy reports **157 passed, 3 deselected** in the pure route, timestamp, parser and portable-path controls. The three omitted parser cases create temporary bytecode fixtures; their names and selection are retained in `run_pytest.py`. The remaining 72 parser cases and all 83 explicit guest cases, plus the two portable-path cases, execute successfully. This replay does not call a native provider, API, VM or model.

The reviewer also performs a fresh full collection: **2,788 unique IDs**, exactly the catalog set. These IDs are retained in `fresh-collection.json`. Collection does not establish execution of all 2,788 tests.

The author's 246 retained data checks pass. All nine retained QA children are reaped, original groups absent, with no signals/timeouts and equal projection/finite-component endpoint records. The seven final authoritative commands report exit zero and bind all 13 final afterimages. Their raw evidence reports **375 passing pure tests**, Linux strict checking of 31 files, prospective Win32 strict checking of eight selected fixtures, Ruff, formatting, catalog formatting and full 2,788-ID collection. These 375 tests and strict checks are audited author runs; the fresh reviewer execution count is 157.

The original guest behavior and thresholds retain the bounds of their existing source reviews. No target C#, PowerShell, COM provider, guest OS, native 200-percent GUI, lifecycle, runtime, complete aggregate or hosted workflow qualification follows from this pure composition evidence.

## Failure history and custody limits

The author retained the initial reader stop caused by five concurrently added authorized root evidence files. It occurred before composition and was corrected by distinguishing finite source from evidence metadata. The first composer then applied original AST offsets to expanded copied text, producing an invalid checker. Actual collection correctly failed with **1,950 collected / six import errors** and a SyntaxError. The malformed checker, composer, context and raw closed receipt remain in `subject/history/initial-stale-ast-offset` and `subject/qa/initial-full-collection`. The corrected 2,788-ID collection initially exposed a 2,787-ID explicit-only catalog; that exact intermediate catalog is retained, and the final implicit case was added and rechecked. None of these states is relabeled as passing.

One reviewer audit first compared the original guest's `mode` metadata field directly with the copy's `full_mode` field. It correctly stopped on that observer schema mismatch; the exact pre-fix body and failed raw receipt remain in `history/` and `qa/data/`. Explicit field normalization preserves the identical full-mode value; the corrected authoritative audit exits zero. Nonexecuting inspection filename/type mistakes are recorded separately and are not validation results.

All four reviewer-owned children are reaped, original groups absent, with no signals/timeouts and exact retained-copy endpoints. Disposable pytest fixtures are excluded from the proof; the full source copy, raw results and custody records are retained. No canonical file or original cache was written, no unknown cache loaded, and no native/API/model actor ran. Guarded root preimage/absence revalidation and canonical validation remain the next steps. This review grants no milestone, gate or finished-product claim.
