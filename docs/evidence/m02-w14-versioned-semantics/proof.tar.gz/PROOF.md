# Versioned semantic freeze repair

The W06 manifest pinned the exact unversioned semantic emitter source. Gate-v2 work grew that source and the V1 catalog, causing `CORPUS_DRIFT` and making the historical Python 1.1/110 assertions false. This correction restores the exact V1 emitter, catalog and generated TypeScript/Python semantic runtime bytes. A distinct V2 emitter/catalog/runtime carries the reviewed 1.2.0/114 semantics.

Candidate patch: `versioned-semantics.patch`

SHA-256: `cc2d5d81f6acbf4d99b4e0f53ae9f98b7a8de01cf5a2cb90298bc4095e1a3920`

The 24-file patch changes no active-root source directly. It does not touch `verify.py`, `test_validate_status.py`, browser/runtime drivers, public registries or evidence. Parent integration must preserve its unrelated current edits.

## Preserved inputs

- `frozen-preimages.json` records four exact historical V1 hashes, including emitter `d69b85650c220435e06a69186f099e89aa857834354394e47f86966fa821bc02` and catalog `31722639c611cc94bfd9cc31a6e631433c6b145d2b2d8c9d5446aac31d3db1c3`.
- `w06-frozen-artifact-proof.json`: all 103 W06 artifacts match original byte counts and hashes, total 1,530,479 bytes.
- `source-manifest.json`: all 81 schemas, original 511-case corpus, new 79-case corpus and both compatibility baselines are byte-identical to a744ff2 (91 files). New V2 catalog bytes exactly equal a744ff2's reviewed current catalog, still version 1.2.0/114.
- No corpus manifest, W06 expected truth or compatibility baseline was regenerated.

## Current behavior and consumers

Generation emits and exports both distinct APIs. Existing V1 consumers keep the exact historical 110-rule runtime; current cross-language adapters and compatibility witnesses explicitly use the 114-rule V2 runtime. Both raw catalog inputs appear in generated provenance. V2 loading requires all V1 bindings unchanged. Rust checks both catalog versions and the full inherited binding tuple.

Compatibility retains original V1 path/version/hash, original rules and executable witnesses. The additive V2 declaration identifies its inherited digest and exactly four new gate rules. Coordinated V1 path/version/hash changes cannot gain authority from V2 adoption. Existing historical V1-only minor-advance fixture now explicitly constructs V1-only baseline/candidate states; its original assertions remain. New adversarial cases reject removed V2 metadata, current hash drift, inheritance drift, missing binding declarations and coordinated version/hash fabrication.

The existing Python provenance test strictly checks six inputs instead of five while preserving every prior input check. One new Python semantic test separately checks V2 positives, inherited V1 exactness and false holdout validity. The exact inventory is 1,452 common / 1,454 POSIX; `inventory-and-freeze-final.json` verifies the collected node-ID set.

## Validation

All commands ran in the outside workspace with pinned Node 24.18.0, pnpm 11.17.0 and existing installed dependencies; workspace package links point to outside packages. Rust runs used `--locked --offline`.

- Final sealed-source full contracts: **2,524 PASS**, 21 files, 71.51s (`contracts-final-complete.log`). Real TypeScript/Python/Rust adapters exercise all 79 new cases and all retained contract/historical witnesses. Source hashes were checked unchanged after completion.
- Generated Python suite: **173 PASS** (`python-generated-final.log`).
- Rust harness: **10 PASS** (`rust-final.log`).
- W06 ATS matrix: **20 PASS** (`matrix.log`).
- Evaluation corpus units: **218 PASS** (`corpus-tests.log`); `corpus:check` PASS with original W06 digest (`corpus-check.log`).
- Generated outputs: **191 files byte-identical** under `generate:contracts --check`. Compatibility check: **compatible=true, findings=[]**, additive declarations only.
- Contract typecheck, targeted typed ESLint, Prettier, Ruff lint/format, mypy (three source files), cargo format and reverse patch check PASS.

Final proof hashes are in `proof-manifest.json`. Earlier logs retain the generator snapshot race and the historical fixture failure for audit; they are intermediate, superseded by the final sealed run. No browser campaign or target-performance assertion ran as part of this repair. Root must validate the integrated candidate and rebind any pre-execution source lock before later paired runs.
