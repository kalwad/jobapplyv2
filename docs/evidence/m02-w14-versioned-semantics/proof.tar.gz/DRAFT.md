# Frozen W06 correction — source draft only

Active root is frozen a744ff2 while the current browser campaign finishes.
This draft changes only /tmp/japp-w14-versioned-semantics/tree. No generation,
build or test has been run; generated files still show the prior root artifacts.

Exact cause: the sole changed W06 artifact is generator/semantic-rules.ts,
323307/d69b85650c220435e06a69186f099e89aa857834354394e47f86966fa821bc02
→331227/05329c19dc0f71fcccb7e2141a39802add5efc2ae2a28d9f9d5a6d1315a103c6.
All102 other source artifacts remain exact. Added v2 evaluator source must not
be put back into that frozen file.

Restored original emitter and v1catalog bytes from4d6a3e5. Preserved source
hashes in frozen-preimages.json. New full emitter semantic-rules-v2.ts and
new full catalog semantic-rules.v2.json own114 current rules, catalog1.2.0.
The V2 loader requires exact inherited110 bindings from the restored V1 loader.

Generator1.7.0 emits both unchanged V1 semantic runtimes/API and explicit V2
runtimes/API. Generated models/wrappers are structural (no hidden semantic
calls), so emit-python.ts/emit-typescript.ts need no changes; package exports
include both and current compatibility adapters explicitly call V2 semantics.
The Rust test adapter reads/validates both catalogs and refuses changed inherited
bindings. Original Python1.1/110 checks remain unchanged; one new Python node
validates current1.2/114 and inherited bindings plus waived-valid refusal.
Inventory common1451→1452, POSIX1454 expected.

Compatibility metadata preserves the fixed V1 catalog object and all old rules
and witnesses. A strict optional V2 layer binds its own path/version/hash,
inherited digest and exact four added gate rule IDs. Existing original-path,
hash, rule mutation/removal and accepted/rejected witness checks remain. New
V2 removal/hash/inheritance/list mutation probes are added. Both committed
baseline files and all frozen W06 checks/expectations are untouched.

After release: format, generate/drift check, exact original runtime hashes,
all103 W06 source commitments, corpus-check, contracts2524+ and real79×3 corpus,
existing/new Python semantic tests plus inventory collection, strict types/lint,
and unchanged compatibility baseline. No rebaseline/regenerated W06 corpus.
