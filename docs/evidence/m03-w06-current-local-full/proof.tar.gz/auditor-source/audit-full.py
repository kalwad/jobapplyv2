#!/usr/bin/env python3
"""Independent, read-only reconciliation of one explicitly closed W06 full run.

This auditor does not execute/import any product code or the producer wrapper.
Git is used only to read immutable objects at the pinned historical commit.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import traceback

HEAD = None
TREE = None
ROOT = Path("/Users/tanishkalwad/jobapplyv2")
PROOF = None
SOURCE_COUNT = None
WRAPPER = Path("/tmp/japp-m03-w06-clean-root-after-windows-correction-20261019.py")
WRAPPER_SHA = "2c54c0e21f98f6652bf6b654d6431e0d9b1c39c0a338d8f96593583506857762"
RUNTIME_MANIFEST_SHA = "c9049a3f63572c0de9b114700e9326bebc0518166840133cce9548565c58de1d"
MAIN_SHA = "fc2293a3d6425093c03ada543249ccdc2050038613cf984b3983aada18032c7c"
ANSI = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
SUITES = ["toolchain", "format", "lint", "typecheck", "unit-ts", "contract-gen", "fixture-corpus", "evaluation-corpus", "contract", "build", "e2e-browser", "w14-public-controlled", "w14-public-contact-controlled", "visual", "python", "rust", "portability", "traceability", "status", "integrity"]


def digest_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def identity(path: Path) -> dict:
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"bytes": path.stat().st_size, "sha256": digest}


def json_file(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value) -> None:
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def git(*argv: str) -> bytes:
    return subprocess.check_output(["git", *argv], cwd=ROOT)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--confirm-root-reported-completed", action="store_true", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--proof", type=Path, required=True)
    parser.add_argument("--head", required=True)
    parser.add_argument("--tree", required=True)
    parser.add_argument("--source-count", type=int, required=True)
    args = parser.parse_args()
    global HEAD, TREE, PROOF, SOURCE_COUNT
    HEAD, TREE, PROOF, SOURCE_COUNT = args.head, args.tree, args.proof.resolve(), args.source_count
    assert re.fullmatch(r"[0-9a-f]{40}", HEAD) and re.fullmatch(r"[0-9a-f]{40}", TREE)
    assert HEAD == "660f9f1deea129ceccba48c9d560daf1791a95ff"
    assert TREE == "be68bdb19d7de4948dba354a4f13543572c5b517"
    assert SOURCE_COUNT == 1961
    out = args.output.resolve()
    # Output can never fall within the product checkout or producer proof/run tree.
    assert not out.is_relative_to(ROOT.resolve())
    assert not out.is_relative_to(PROOF.resolve())
    assert out != PROOF.parent and not PROOF.is_relative_to(out)
    assert not out.exists(), "fresh, separate audit output required"
    for required in ("after.json", "runtime-after.json", "doctor-result.json", "closure.json"):
        assert (PROOF / required).is_file(), f"closed producer record missing: {required}"
    out.mkdir(parents=True, exist_ok=False)
    checks: list[dict] = []
    details: dict = {"product_full_result": "UNOBSERVED", "current_execution_anchor": "660f9f1/1961", "historical_results_not_transferred": ["e0a501b failed full18PASS2FAIL", "localRust componentPASS/observerfooterFAIL"]}
    originals: dict = {}

    def check(name: str, ok: bool, evidence=None) -> None:
        checks.append({"id": name, "pass": bool(ok), "evidence": evidence})

    def command_sections(text: str) -> list[dict]:
        matches = list(re.finditer(r"^\$ (.+)$", text, re.MULTILINE))
        return [{"argv_text": m.group(1), "start": m.start(), "body_start": m.end(),
                 "end": matches[i + 1].start() if i + 1 < len(matches) else len(text)}
                for i, m in enumerate(matches)]

    try:
        # All source/provenance inputs are finite regular files. Retain their identities,
        # without copying tracked archives, installed applications, or dependency caches.
        for p in sorted(PROOF.rglob("*")):
            assert not p.is_symlink(), f"symlink in producer proof: {p}"
            if p.is_file():
                originals[p.relative_to(PROOF).as_posix()] = identity(p)
        originals["EXTERNAL/executed-source-wrapper.py"] = identity(WRAPPER)
        outer = PROOF.with_name(PROOF.name + ".outer.log")
        if outer.is_file():
            originals["EXTERNAL/outer.log"] = identity(outer)
        check("wrapper_original_and_executed_bytes", identity(WRAPPER)["sha256"] == WRAPPER_SHA and identity(PROOF / "executed-wrapper.py")["sha256"] == WRAPPER_SHA)

        actual_results = {}
        for label in ("doctor", "verify"):
            path = PROOF / (label + "-result.json")
            if path.is_file():
                raw_result = json_file(path)
                actual_results[label] = {k: raw_result.get(k) for k in ("exit_code", "outer_timeout", "wait_error", "log_bytes", "log_sha256")}
            else:
                actual_results[label] = {"status": "NOT_RETAINED_NO_EXECUTION_INFERRED"}
        details["actual_command_outcomes_before_positive_checks"] = actual_results
        details["product_full_result"] = (
            "FAIL" if any(type(x.get("exit_code")) is int and x["exit_code"] != 0 for x in actual_results.values())
            else "COMMAND_EXIT0_NOT_YET_AUDITED" if all(x.get("exit_code") == 0 for x in actual_results.values())
            else "UNOBSERVED")
        verify_path = PROOF / "verify.log"
        if verify_path.is_file():
            observed_text = ANSI.sub("", verify_path.read_text(encoding="utf-8"))
            observed_footer = observed_text.rsplit("== verification summary ==", 1)[-1]
            details["actual_suite_rows_before_positive_checks"] = re.findall(r"^([a-z][a-z0-9-]+)\s+(ACTIVE|NOT_YET_APPLICABLE|REQUIRED_MISSING)\s+(PASS|FAIL|NOT_YET_APPLICABLE|REQUIRED_MISSING)\b", observed_footer, re.MULTILINE)
            details["actual_failure_sections_before_positive_checks"] = re.findall(r"^FAILURE ([^\n]+):$", observed_footer, re.MULTILINE)
            details["actual_aggregate_exit_lines_before_positive_checks"] = re.findall(r"^verification exit code: (\d+)$", observed_text, re.MULTILINE)

        before = json_file(PROOF / "before.json")
        after = json_file(PROOF / "after.json")
        rb = json_file(PROOF / "runtime-before.json")
        ra = json_file(PROOF / "runtime-after.json")
        env = json_file(PROOF / "environment.json")
        closure = json_file(PROOF / "closure.json")
        check("before_after_pinned_head_tree_clean", all(s["head"] == HEAD and s["tree"] == TREE and s["status"] == "" and len(s["files"]) == SOURCE_COUNT for s in (before, after)), {"before_head": before["head"], "after_head": after["head"], "tree": before["tree"], "tracked_count": len(before["files"])})
        check("all_tracked_snapshot_bytes_identical", before == after)
        check("runtime40_before_after_identical", rb == ra and len(rb) == 40)
        check("runtime_manifest_and_main_pins", rb.get("manifest.json", {}).get("sha256") == RUNTIME_MANIFEST_SHA and sum(r["sha256"] == MAIN_SHA for r in rb.values()) == 1)
        runtime_root = ROOT / "apps/desktop/src-tauri/runtime-payload"
        physical_runtime = {}
        for path in sorted(runtime_root.rglob("*")):
            assert not path.is_symlink(), f"symlink in runtime payload: {path}"
            if path.is_file():
                physical_runtime[path.relative_to(runtime_root).as_posix()] = {**identity(path), "mode": oct(path.stat().st_mode & 0o777)}
        check("closed_current_runtime40_physical_confirmation", physical_runtime == rb == ra, {"count": len(physical_runtime), "bytes": sum(row["bytes"] for row in physical_runtime.values())})
        check("producer_closure_flags_scoped", all(closure.get(k) is True for k in ("source_unchanged", "runtime40_unchanged", "both_commands_executed", "all_executed_commands_exit0")) and all(closure.get(k) is False for k in ("milestone_accepted", "gui_execution", "hosted_ci")), closure)

        # Historical Git objects supply an independent byte witness. Do not compare a
        # later mutable checkout or claim executable snapshots for dependencies.
        tree = git("rev-parse", f"{HEAD}^{{tree}}").decode().strip()
        listed = git("ls-tree", "-r", "-z", HEAD)
        git_rows: dict = {}
        object_paths: dict[str, list[str]] = {}
        for record in listed.split(b"\0"):
            if not record:
                continue
            meta, path_raw = record.split(b"\t", 1)
            mode, kind, oid = meta.decode().split()
            path = path_raw.decode("utf-8")
            assert kind == "blob" and mode in {"100644", "100755"}, (path, kind, mode)
            assert not PurePosixPath(path).is_absolute() and ".." not in PurePosixPath(path).parts
            git_rows[path] = {"git_sha1": oid, "git_mode": mode}
            object_paths.setdefault(oid, []).append(path)
        check("immutable_git_tree_path_set", tree == TREE and set(git_rows) == set(before["files"]) and len(git_rows) == SOURCE_COUNT)
        blob_rows: dict = {}
        blob_ok = True
        batch = subprocess.Popen(["git", "cat-file", "--batch"], cwd=ROOT, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
        assert batch.stdin is not None and batch.stdout is not None
        try:
            for oid, paths in object_paths.items():
                batch.stdin.write((oid + "\n").encode()); batch.stdin.flush()
                got, kind, size_str = batch.stdout.readline().decode().strip().split()
                size = int(size_str)
                assert got == oid and kind == "blob"
                sha256 = hashlib.sha256()
                sha1 = hashlib.sha1(f"blob {size}\0".encode(), usedforsecurity=False)
                remaining = size
                while remaining:
                    chunk = batch.stdout.read(min(1024 * 1024, remaining))
                    assert chunk, "short immutable Git blob"
                    sha256.update(chunk); sha1.update(chunk); remaining -= len(chunk)
                assert batch.stdout.read(1) == b"\n"
                assert sha1.hexdigest() == oid
                actual = {"bytes": size, "sha256": sha256.hexdigest()}
                for path in paths:
                    same = actual == before["files"][path] == after["files"][path]
                    blob_ok &= same
                    blob_rows[path] = {**git_rows[path], **actual, "before_after_match": same}
        finally:
            batch.stdin.close()
            assert batch.wait(timeout=30) == 0
        check("all_pinned_source_immutable_git_blob_hashes_and_sizes", blob_ok and len(blob_rows) == SOURCE_COUNT, {"unique_blob_count": len(object_paths), "tracked_bytes": sum(x["bytes"] for x in before["files"].values())})
        write_json(out / "immutable-git-blob-closure.json", blob_rows)

        # Read the exact committed source inputs; never import a repository module.
        registry_data = git("show", f"{HEAD}:scripts/verification-suites.json")
        inventory_data = git("show", f"{HEAD}:scripts/python-test-inventory.v1.json")
        registry = json.loads(registry_data)
        inventory = json.loads(inventory_data)
        source_inputs = {"scripts/verification-suites.json": {"bytes": len(registry_data), "sha256": digest_bytes(registry_data)}, "scripts/python-test-inventory.v1.json": {"bytes": len(inventory_data), "sha256": digest_bytes(inventory_data)}}
        check("registry_exact20_suite_order", [s["id"] for s in registry["suites"]] == SUITES)
        common_ids = inventory["common"]["node_ids"]
        expected_python = sorted(common_ids + inventory["posix_only_node_ids"])
        canonical_digest = lambda ids: digest_bytes(("\n".join(ids) + "\n").encode())
        check("python_declared_common1799_posix1801", len(common_ids) == 1799 and len(expected_python) == 1801 and len(set(expected_python)) == 1801 and canonical_digest(common_ids) == inventory["common"]["sha256"], {"common_count": len(common_ids), "posix_count": len(expected_python), "common_sha256": canonical_digest(common_ids), "posix_sha256": canonical_digest(expected_python), "posix_only_node_ids": inventory["posix_only_node_ids"]})

        # Producer command records bind complete curated outer environment and logs.
        curated = env["complete_curated_inherited_environment"]
        forbidden = ["JAPP_W13_PERFORMANCE_SAMPLES", "JAPP_W14_REQUIRE_TARGET_PERFORMANCE", "JAPP_W14_ARTIFACT_DIRECTORY", "JAPP_W14_W06_ARTIFACT_DIRECTORY"]
        inherited = {"HOME", "USER", "LOGNAME", "TMPDIR", "LANG", "LC_ALL", "CARGO_HOME", "RUSTUP_HOME", "SDKROOT", "DEVELOPER_DIR", "MACOSX_DEPLOYMENT_TARGET", "XDG_CACHE_HOME"}
        fixed = {"PATH", "UV_OFFLINE", "CARGO_NET_OFFLINE", "COREPACK_ENABLE_NETWORK", "GIT_CONFIG_GLOBAL", "GIT_CONFIG_SYSTEM"}
        check("curated_outer_env_closed_key_set_and_modes", set(curated) <= inherited | fixed and fixed <= set(curated) and "HOME" in curated and not any(k in curated for k in forbidden) and curated["PATH"].startswith("/opt/homebrew/opt/node@24/bin:") and curated["UV_OFFLINE"] == "true" and curated["CARGO_NET_OFFLINE"] == "true" and curated["COREPACK_ENABLE_NETWORK"] == "0" and curated["GIT_CONFIG_GLOBAL"] == curated["GIT_CONFIG_SYSTEM"] == "/dev/null")
        check("five_successful_tool_probes_wrapper_bound", env["wrapper_sha256"] == WRAPPER_SHA and set(env["probes"]) == {"node", "pnpm", "python", "uv", "rust"} and all(p["exit_code"] == 0 and p["executable"] and re.fullmatch(r"[0-9a-f]{64}", p["executable_sha256"]) for p in env["probes"].values()), env["probes"])
        expected_probes = {"node": (["node", "--version"], "v24.18.0\n"), "pnpm": (["pnpm", "--version"], "11.17.0\n"), "python": (["uv", "run", "python", "--version"], "Python 3.12.13\n"), "uv": (["uv", "--version"], "uv 0.11.32 (3010295ae 2026-07-23 aarch64-apple-darwin)\n"), "rust": (["rustc", "--version"], "rustc 1.97.1 (8bab26f4f 2026-07-14)\n")}
        check("tool_probe_literal_argv_and_version_output", all(env["probes"][name]["argv"] == argv and env["probes"][name]["stdout"] == stdout and env["probes"][name]["stderr"] == "" for name, (argv, stdout) in expected_probes.items()))
        records = {}
        for label, argv, timeout in (("doctor", ["pnpm", "run", "doctor"], 300), ("verify", ["pnpm", "verify"], 3600)):
            upfront = json_file(PROOF / (label + "-upfront.json"))
            result = json_file(PROOF / (label + "-result.json"))
            check(label + "_upfront_unchanged_in_result", all(result.get(k) == v for k, v in upfront.items()))
            check(label + "_exact_command_source_env_exit0", result["argv"] == argv and result["cwd"] == str(ROOT) and result["environment"] == curated and result["timeout_seconds"] == timeout and result["source_snapshot_sha256"] == identity(PROOF / "before.json")["sha256"] and result["exit_code"] == 0 and result["outer_timeout"] is False and result["executable_sha256_before"] == result["executable_sha256_after"], result)
            check(label + "_complete_log_hash_size", {"bytes": result["log_bytes"], "sha256": result["log_sha256"]} == identity(PROOF / (label + ".log")))
            launch = json_file(PROOF / (label + "-launch.json"))
            check(label + "_owned_session_group_closed", result.get("owned_leader_reaped") is True
                  and result.get("owned_group_after") == "GONE" and result.get("cleanup") == []
                  and launch.get("owned_pid") == launch.get("owned_new_session_group") == result.get("owned_pid")
                  and result.get("descendants_outside_owned_group") == "UNOBSERVED", launch)
            records[label] = result
        dt = datetime.fromisoformat
        check("doctor_then_verify_serial_timestamps", dt(records["doctor"]["started_utc"]) < dt(records["doctor"]["ended_utc"]) <= dt(records["verify"]["started_utc"]) < dt(records["verify"]["ended_utc"]) <= dt(closure["ended_utc"]))
        doctor = ANSI.sub("", (PROOF / "doctor.log").read_text())
        check("actual_repository_doctor28_pass_no_warning_fail_na", "summary: 28 pass, 0 warning, 0 fail, 0 not-yet-applicable" in doctor and "$ python3 scripts/doctor.py" in doctor)
        details["commands"] = {label: {k: rec[k] for k in ("argv", "started_utc", "ended_utc", "elapsed_seconds", "exit_code", "outer_timeout", "log_bytes", "log_sha256")} for label, rec in records.items()}
        if outer.is_file():
            outer_lines = outer.read_text(encoding="utf-8").splitlines()
            outer_json = [json.loads(line) for line in outer_lines if line.startswith("{")]
            check("closed_outer_handle_phase_records_match", len(outer_json) == 3 and outer_json[-1] == closure and all(outer_json[i] == {"label": label, "exit_code": records[label]["exit_code"], "seconds": records[label]["elapsed_seconds"]} for i, label in enumerate(("doctor", "verify"))), {"line_count": len(outer_lines), "json_record_count": len(outer_json)})

        log = ANSI.sub("", (PROOF / "verify.log").read_text(encoding="utf-8"))
        sections = command_sections(log)
        write_json(out / "command-sections.json", [{k: v for k, v in s.items() if k != "body_start"} for s in sections])
        summary = log.rsplit("== verification summary ==", 1)[-1]
        suite_rows = re.findall(r"^([a-z][a-z0-9-]+)\s+(ACTIVE|NOT_YET_APPLICABLE|REQUIRED_MISSING)\s+(PASS|FAIL|NOT_YET_APPLICABLE|REQUIRED_MISSING)\b", summary, re.MULTILINE)
        check("aggregate_all20_active_pass_exact_order", suite_rows == [(s, "ACTIVE", "PASS") for s in SUITES], suite_rows)
        check("aggregate_exit0_no_failure_section", re.findall(r"^verification exit code: (\d+)$", log, re.MULTILINE) == ["0"] and "\nFAILURE " not in summary)

        def unique_command(prefix: str, *, after_pos: int = -1) -> dict:
            found = [s for s in sections if s["start"] > after_pos and s["argv_text"].startswith(prefix)]
            assert len(found) == 1, (prefix, len(found))
            return found[0]

        def body(section: dict, end: int | None = None) -> str:
            return log[section["body_start"]:section["end"] if end is None else end]

        unit = unique_command("pnpm exec turbo run test --force")
        unit_end = unique_command("pnpm generate:contracts --check")["start"]
        unit_body = body(unit, unit_end)
        vitest_counts = [int(n) for n in re.findall(r"Tests\s+(\d+) passed", unit_body)]
        check("typescript_unit4006_actual_ordinary_summaries", sum(vitest_counts) == 4006 and "--reporter=default" in unit["argv_text"] and not re.search(r"\b[1-9]\d* (?:skipped|todo|pending|failed)\b", unit_body), {"per_package_pass_counts": vitest_counts, "total": sum(vitest_counts)})
        details["typescript_unit"] = {"per_package_pass_counts": vitest_counts, "total": sum(vitest_counts)}

        # Each Playwright execution is distinct. Default tests may include the visual
        # cases which are also executed separately by the explicit visual suite.
        browser_commands = [("default", "pnpm exec playwright test", 262), ("controlled_inspection", "pnpm exec playwright test --config e2e/extension/public-research/playwright.config.ts", 2), ("controlled_contact", "pnpm exec playwright test --config e2e/extension/public-contact/playwright.config.ts --reporter=list,json", 62), ("visual", "pnpm exec playwright test e2e/visual --output test-results/visual", 3)]
        browser_stats = {}
        for label, command, count in browser_commands:
            executions = [s for s in sections if s["argv_text"] == command]
            check(label + "_one_exact_browser_execution", len(executions) == 1)
            if len(executions) != 1:
                continue
            part = body(executions[0])
            passed = re.findall(r"^\s*(\d+) passed(?:\s|$)", part, re.MULTILINE)
            bad = re.findall(r"^\s*\d+ (?:failed|skipped|flaky|did not run|interrupted)\b", part, re.MULTILINE)
            running = re.findall(r"^Running (\d+) tests? using (\d+) workers?", part, re.MULTILINE)
            check(label + "_ordinary_pass_summary", passed == [str(count)] and not bad and running and running[0][0] == str(count), {"passed": passed, "nonordinary": bad, "running": running})
            browser_stats[label] = {"passed": passed, "running": running}
        details["browser_executions"] = browser_stats
        # Report printed benchmark observations only, without calling the default
        # suite a 20-sample performance or Gate A rerun.
        target_lines = re.findall(r"^W13_TARGET_P95 (\{[^\n]+\})$", log, re.MULTILINE)
        contact_lines = re.findall(r"^W14_DEVELOPMENT (\{[^\n]+\})$", log, re.MULTILINE)
        check("one_default_target_and_contact_log_record", len(target_lines) == len(contact_lines) == 1)
        if len(target_lines) == len(contact_lines) == 1:
            target_record = json.loads(target_lines[0])
            contact_record = json.loads(contact_lines[0])
            check("default_target_one_sample_zero_settle_scope", target_record["samples"] == 1 and target_record["settle_budget_ms"] == 0 and target_record["threshold_ms"] == 1500 and target_record["scope"] == "TARGET_MACHINE_LOWER_BOUND_HARNESS_VALIDATION")
            check("contact_log_is_scoped200_case_observation", contact_record["recorded_cases"] == contact_record["metrics"]["executed_cases"] == contact_record["metrics"]["scored_cases"] == 200 and contact_record["metrics"]["full_settle_scan_fill_timing"]["sample_count"] == 200 and contact_record["metrics"]["full_settle_scan_fill_timing"]["scope"] == "ONE_EXECUTION_PER_DIFFERENT_W12_PAGE_75MS_SETTLEMENT_20MS_RERENDER")
            details["performance_observations_from_log_not_independent_raw_replay"] = {"default_target": target_record, "contact200": contact_record}

        collection = [s for s in sections if s["argv_text"].startswith("uv run pytest ") and "--collect-only -q" in s["argv_text"]]
        execution = [s for s in sections if s["argv_text"].startswith("uv run pytest ") and "--collect-only" not in s["argv_text"]]
        check("python_exact_one_collection_and_execution", len(collection) == len(execution) == 1)
        if len(collection) == len(execution) == 1:
            collected = re.findall(r"^((?:scripts/tests|services/orchestrator/tests)/[^\n]+::[^\n]+)$", body(collection[0]), re.MULTILINE)
            collected = [s.strip() for s in collected]
            check("python_full1801_ids_match_committed_inventory", len(collected) == len(set(collected)) == 1801 and sorted(collected) == expected_python, {"count": len(collected), "sha256": canonical_digest(sorted(collected))})
            collection_summaries = re.findall(r"^(?:=+\s*)?(\d+) tests collected in (\d+\.\d+)s(?: \([^\n]+\))?(?:\s*=+)?$", body(collection[0]), re.MULTILINE)
            check("python_collection1801_summary", len(collection_summaries) == 1 and collection_summaries[0][0] == "1801", collection_summaries)
            py_summary = re.findall(r"^=+\s+(\d+) passed in (\d+\.\d+)s(?: \([^\n]+\))?\s+=+$", body(execution[0]), re.MULTILINE)
            check("python_actual1801_pass_no_skips_failures", len(py_summary) == 1 and py_summary[0][0] == "1801" and not re.search(r"^=+[^\n]*\b(?:failed|skipped|xfailed|xpassed|deselected|errors?|warnings?)\b", body(execution[0]), re.MULTILINE), py_summary)
            canonical_py_flags = ["-c pyproject.toml", "--rootdir=.", "--confcutdir=.", "-o addopts=", "-ra --strict-markers --strict-config", "--disable-plugin-autoload"]
            check("python_canonical_flags_both_commands", all(all(flag in s["argv_text"] for flag in canonical_py_flags) for s in (collection[0], execution[0])))
            details["python"] = {"collected_count": len(collected), "collected_sha256": canonical_digest(sorted(collected)), "common_count": len(common_ids), "common_sha256": canonical_digest(common_ids), "ordinary_execution_summary": py_summary}
            write_json(out / "python-collected-node-ids.json", sorted(collected))

        rust_suite = next(s for s in registry["suites"] if s["id"] == "rust")
        expected_rust = [" ".join(argv) for argv in rust_suite["commands"]]
        start_after = execution[0]["start"] if len(execution) == 1 else unit_end
        matched_rust = []
        pos = start_after
        for command in expected_rust:
            matches = [s for s in sections if s["start"] > pos and s["argv_text"] == command]
            assert matches, f"missing native command: {command}"
            chosen = matches[0]
            matched_rust.append(chosen); pos = chosen["start"]
        check("all15_registered_rust_commands_in_order", len(matched_rust) == len(expected_rust) == 15, expected_rust)
        native_modes = []
        for i, section in enumerate(matched_rust):
            command = section["argv_text"]
            end = matched_rust[i + 1]["start"] if i + 1 < len(matched_rust) else section["end"]
            part = body(section, end)
            if command.startswith("cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml"):
                ids = re.findall(r"^test (\S+) \.\.\. ok$", part, re.MULTILINE)
                summaries = re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s", part)
                check("native_mode_ordinary232_" + str(len(native_modes) + 1), len(ids) == len(set(ids)) == 232 and summaries and sum(int(s[0]) for s in summaries) == 232 and all(all(int(n) == 0 for n in s[1:5]) for s in summaries), {"command": command, "case_count": len(ids), "summaries": summaries})
                native_modes.append({"command": command, "case_ids": sorted(ids), "summaries": summaries})
        check("native_same232_ids_all3_modes", len(native_modes) == 3 and native_modes[0]["case_ids"] == native_modes[1]["case_ids"] == native_modes[2]["case_ids"])
        details["native"] = {"mode_count": len(native_modes), "cases_per_mode": [len(m["case_ids"]) for m in native_modes], "registered_command_count": len(matched_rust), "gui_execution": False, "hosted_ci": False}
        write_json(out / "native-mode-cases.json", native_modes)
        write_json(out / "source-inputs.json", source_inputs)

        # Rehash the closed finite producer originals to detect a concurrent change.
        changed = []
        for name, old in originals.items():
            path = WRAPPER if name == "EXTERNAL/executed-source-wrapper.py" else outer if name == "EXTERNAL/outer.log" else PROOF / name
            if identity(path) != old:
                changed.append(name)
        check("all_finite_originals_stable_during_audit", not changed, changed)
    except BaseException as exc:
        check("audit_completed_without_checker_error", False, {"type": type(exc).__name__, "message": str(exc)})
        (out / "checker-error.txt").write_text(traceback.format_exc(), encoding="utf-8")

    outcome = "PASS" if checks and all(c["pass"] for c in checks) else "FAIL"
    if outcome == "PASS":
        details["product_full_result"] = "PASS"
    findings = {"decision": outcome, "product_full_result": details.get("product_full_result", "UNOBSERVED"), "scope": "W06_CURRENT_LOCAL_CANONICAL_FULL_DATA_REVIEW", "head": HEAD, "tree": TREE, "product_execution_performed_by_auditor": False, "milestone_authority": "NONE", "gui_execution_claim": False, "hosted_ci_claim": False, "checks": checks, "passed": sum(c["pass"] for c in checks), "total": len(checks), "details": details, "closed_producer_input_identities": originals, "auditor_source": identity(Path(__file__)), "completed_utc": datetime.now(timezone.utc).isoformat()}
    write_json(out / "findings.json", findings)
    lines = [f"# W06 current local full evidence review: {outcome}", "", f"Independent reconciliation: {findings['passed']}/{findings['total']} checks passed against `{HEAD}` / tree `{TREE}`.", "", "This report audits retained local data. It does not decide milestone acceptance, establish a new GUI execution, or validate native hosted platforms. Default benchmark observations are not a fresh 20-sample Gate A experiment.", "", "The producer records the complete curated outer environment. It does not serialize every nested child environment or provide a whole dependency/cache/upfront native test-binary image. Its command-owned new-session groups have explicit termination/reaping receipts; escaped descendants remain unobserved. Version probes still use bounded direct subprocess calls.", "", "Tool probe scope is literal: the Python-version probe hashes the resolved `uv` launcher, and pnpm/Node launcher hashes do not authenticate every nested executable. All historical source comparisons use immutable pinned Git objects, not a later mutable checkout.", "", "## Failed checks", ""]
    failed = [c for c in checks if not c["pass"]]
    lines += [f"- `{c['id']}`: {json.dumps(c['evidence'], ensure_ascii=False)}" for c in failed] or ["None."]
    if outcome == "PASS":
        if "commands" in details:
            doctor_rec = details["commands"]["doctor"]
            verify_rec = details["commands"]["verify"]
            lines += ["", "## Raw-derived observations", "", f"Repository doctor: `{' '.join(doctor_rec['argv'])}`, exit {doctor_rec['exit_code']}, {doctor_rec['elapsed_seconds']:.9f}s; 28 ordinary PASS, no warnings/failures/N/A. It completed before aggregate start.", "", f"Aggregate: `{' '.join(verify_rec['argv'])}`, exit {verify_rec['exit_code']}, {verify_rec['elapsed_seconds']:.9f}s; exact 20 ACTIVE/PASS summary. Verify log: {verify_rec['log_bytes']} bytes, SHA-256 `{verify_rec['log_sha256']}`."]
        if "typescript_unit" in details and "python" in details and "native" in details:
            lines += ["", f"TypeScript unit summaries total {details['typescript_unit']['total']} ordinary passes. Python: {details['python']['collected_count']} exact collected POSIX IDs, comprising {details['python']['common_count']} common IDs plus the declared FIFO/socket pair; actual summary `{details['python']['ordinary_execution_summary']}` with no skip/deselection. All 15 registered Rust-stage commands occur in order; each of three desktop feature modes passes the same {details['native']['cases_per_mode']} case cohort with zero failed/ignored/measured/filtered cases. This is three executions of the same 232-case cohort."]
        if "browser_executions" in details:
            observed_browser = {name: stats['passed'] for name, stats in details['browser_executions'].items()}
            lines += ["", f"Browser ordinary pass summaries by execution: `{observed_browser}`. The default execution may already include visual cases; these are execution counts, not a claim of distinct cases across commands."]
        if "performance_observations_from_log_not_independent_raw_replay" in details:
            perf = details["performance_observations_from_log_not_independent_raw_replay"]
            lines += ["", f"Printed timing scopes: default native128 {perf['default_target']['samples']}-sample / {perf['default_target']['settle_budget_ms']}ms-settle value {perf['default_target']['p95_ms']}ms; separate 200 different W12 page observations with 75ms settlement / 20ms rerender have printed p95 {perf['contact200']['metrics']['full_settle_scan_fill_timing']['p95_ms']}ms. These are log-record observations, without a fresh independent contact raw replay or 20-sample performance claim."]
        lines += ["", f"All {SOURCE_COUNT} tracked-file path/size/SHA-256 rows match both snapshots and independently authenticated immutable Git blobs. The unchanged runtime payload has 40 files / {sum(row['bytes'] for row in rb.values()) if 'rb' in locals() else 'unknown'} bytes; closed physical read-back confirms the same bytes/modes, manifest `{RUNTIME_MANIFEST_SHA}` and main `{MAIN_SHA}`.", "", "Historical e0a501b full18PASS2FAIL and localRust componentPASS/observerfooterFAIL remain separate original anchors. Historical W04 auditor preparation retains its initial 41/42 collection-summary observer correction; the whole-line anchored expression is preserved here. That historical result is not a W06 attempt or outcome. All W06 checks in this report derive from its own closed records; no earlier W04/W05 execution credit is inherited. The canonical native cohort is232 per mode; the earlier183 focus and outside187 derivative remain separate; the separate outside selected four-case recovery derivative keeps its own execution identity."]
    else:
        lines += ["", "Positive aggregate/count/source summaries are withheld because one or more audit checks failed. Actual producer command exits and aggregate rows captured before positive checks remain in findings.json; product FAIL is never changed to PASS, and an auditor exception is not a product test result. Actual raw-derived details and every refusal/error are retained in findings.json; no positive execution or source-neutrality claim is inferred from expected pins."]
    lines += ["", "See `findings.json`, `immutable-git-blob-closure.json`, `python-collected-node-ids.json`, and `native-mode-cases.json` for exact identities, raw-derived counts, and case joins. All failed checker attempts must remain historical if a later parser correction is required.", ""]
    (out / "REVIEW.md").write_text("\n".join(lines), encoding="utf-8")
    members = {p.relative_to(out).as_posix(): identity(p) for p in sorted(out.rglob("*")) if p.is_file()}
    write_json(out / "audit-member-manifest.json", {"self_excluded": "audit-member-manifest.json", "files": members})
    print(json.dumps({"decision": outcome, "passed": findings["passed"], "total": findings["total"], "output": str(out), "review": identity(out / "REVIEW.md"), "manifest": identity(out / "audit-member-manifest.json")}))
    return 0 if outcome == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
