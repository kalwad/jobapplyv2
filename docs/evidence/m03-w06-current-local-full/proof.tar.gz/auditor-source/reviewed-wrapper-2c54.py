"""Clean current-root doctor/full after reviewed Windows manifest+failure-log correction; exact1961 source, bounded snapshots and curated recorded env."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import platform
import shutil
import signal
import traceback
import subprocess
import time

ap = argparse.ArgumentParser()
ap.add_argument('--expect-head', required=True)
ap.add_argument('--out-dir', type=Path, required=True)
args = ap.parse_args()
R = Path('/Users/tanishkalwad/jobapplyv2')
B = args.out_dir.resolve()
B.mkdir(exist_ok=False)
shutil.copy2(__file__, B / 'executed-wrapper.py')
def sha(p):
    return hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
def write(n,v):
    with (B/n).open('x') as f:
        json.dump(v,f,indent=2)
        f.write('\n')
env = {k: os.environ[k] for k in ['HOME','USER','LOGNAME','TMPDIR','LANG','LC_ALL','CARGO_HOME','RUSTUP_HOME','SDKROOT','DEVELOPER_DIR','MACOSX_DEPLOYMENT_TARGET','XDG_CACHE_HOME'] if k in os.environ}
env.update(PATH='/opt/homebrew/opt/node@24/bin:'+os.environ['PATH'], UV_OFFLINE='true', CARGO_NET_OFFLINE='true', COREPACK_ENABLE_NETWORK='0', GIT_CONFIG_GLOBAL='/dev/null', GIT_CONFIG_SYSTEM='/dev/null')
for key in ['JAPP_W13_PERFORMANCE_SAMPLES','JAPP_W14_REQUIRE_TARGET_PERFORMANCE','JAPP_W14_ARTIFACT_DIRECTORY','JAPP_W14_W06_ARTIFACT_DIRECTORY']:
    assert key not in env
def git(*argv):
    return subprocess.check_output(['git',*argv],cwd=R,env=env)
def snapshot():
    names=git('ls-files','-z').decode().rstrip('\0').split('\0')
    files={}
    for n in names:
        p=R/n
        assert p.is_file() and not p.is_symlink(),n
        files[n]={'bytes':p.stat().st_size,'sha256':sha(p)}
    return {'head':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'status':git('status','--porcelain=v1','--untracked-files=all').decode(),'files':files}
before=snapshot()
assert before['head']==args.expect_head and not before['status'] and len(before['files'])==1961
write('before.json',before)
runtime=R/'apps/desktop/src-tauri/runtime-payload'
def runtime_snapshot():
    rows={}
    for p in sorted(runtime.rglob('*')):
        assert not p.is_symlink()
        if p.is_file():rows[p.relative_to(runtime).as_posix()]={'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)}
    return rows
runtime_before=runtime_snapshot()
assert len(runtime_before)==40 and runtime_before['manifest.json']['sha256']=='c9049a3f63572c0de9b114700e9326bebc0518166840133cce9548565c58de1d'
write('runtime-before.json',runtime_before)
probes={}
for name,argv in [('node',['node','--version']),('pnpm',['pnpm','--version']),('python',['uv','run','python','--version']),('uv',['uv','--version']),('rust',['rustc','--version'])]:
    exe=Path(shutil.which(argv[0],path=env['PATH'])).resolve(strict=True)
    p=subprocess.run(argv,cwd=R,env=env,capture_output=True,text=True,timeout=60,check=False)
    probes[name]={'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'executable':str(exe),'executable_sha256':sha(exe)}
    assert p.returncode==0
write('environment.json',{'platform':platform.platform(),'machine':platform.machine(),'complete_curated_inherited_environment':dict(env),'probes':probes,'wrapper_sha256':sha(B/'executed-wrapper.py'),'scope':'Current W06 canonical defaults; no20-sample GateA rerun, new GUI, whole dependency/cache or upfront complete binary image claim'})
records=[]
for label,argv,timeout in [('doctor',['pnpm','run','doctor'],300),('verify',['pnpm','verify'],3600)]:
    exe=Path(shutil.which(argv[0],path=env['PATH'])).resolve(strict=True)
    rec={'argv':argv,'cwd':str(R),'environment':dict(env),'executable':str(exe),'executable_sha256_before':sha(exe),'started_utc':datetime.now(timezone.utc).isoformat(),'timeout_seconds':timeout,'source_snapshot_sha256':sha(B/'before.json')}
    write(label+'-upfront.json',rec)
    start=time.monotonic()
    print('RUN '+label+' '+rec['started_utc'],flush=True)
    timed_out=False;failure=None;cleanup=[]
    with (B/(label+'.log')).open('xb') as out:
        child=subprocess.Popen(argv,cwd=R,env=dict(env),stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
        def owned_group_alive():
            child.poll()
            try:os.killpg(child.pid,0);return True
            except ProcessLookupError:return False
        try:
            write(label+'-launch.json',{'owned_pid':child.pid,'owned_new_session_group':child.pid,'utc':datetime.now(timezone.utc).isoformat()})
            child.wait(timeout=timeout)
            until=time.monotonic()+2
            while owned_group_alive() and time.monotonic()<until:time.sleep(.05)
            if owned_group_alive():raise RuntimeError('Owned command group outlived direct child')
        except BaseException as error:
            failure=error;timed_out=isinstance(error,subprocess.TimeoutExpired)
            rec['wait_error']={'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
            for sig,seconds in [(signal.SIGTERM,10),(signal.SIGKILL,5)]:
                if not owned_group_alive():break
                try:os.killpg(child.pid,sig);cleanup.append({'signal':int(sig),'owned_pgid':child.pid})
                except ProcessLookupError:break
                until=time.monotonic()+seconds
                while owned_group_alive() and time.monotonic()<until:time.sleep(.05)
        code=child.poll() if failure is None else 124
        rec.update(owned_pid=child.pid,owned_leader_reaped=child.returncode is not None,owned_group_after='PRESENT' if owned_group_alive() else 'GONE',cleanup=cleanup,descendants_outside_owned_group='UNOBSERVED')
    rec.update(exit_code=code,elapsed_seconds=time.monotonic()-start,ended_utc=datetime.now(timezone.utc).isoformat(),outer_timeout=timed_out,log_bytes=(B/(label+'.log')).stat().st_size,log_sha256=sha(B/(label+'.log')),executable_sha256_after=sha(exe))
    write(label+'-result.json',rec)
    records.append(rec)
    print(json.dumps({'label':label,'exit_code':code,'seconds':rec['elapsed_seconds']}),flush=True)
    if code:break
after=snapshot();write('after.json',after)
runtime_after=runtime_snapshot();write('runtime-after.json',runtime_after)
verdict={'source_unchanged':before==after,'runtime40_unchanged':runtime_before==runtime_after,'both_commands_executed':len(records)==2,'all_executed_commands_exit0':all(x['exit_code']==0 for x in records),'ended_utc':datetime.now(timezone.utc).isoformat(),'milestone_accepted':False,'gui_execution':False,'hosted_ci':False}
write('closure.json',verdict)
print(json.dumps(verdict),flush=True)
raise SystemExit(0 if all(verdict[k] for k in ['source_unchanged','runtime40_unchanged','both_commands_executed','all_executed_commands_exit0']) else 1)
