# W06 current local full evidence review: PASS

Independent reconciliation: 49/49 checks passed against `660f9f1deea129ceccba48c9d560daf1791a95ff` / tree `be68bdb19d7de4948dba354a4f13543572c5b517`.

This report audits retained local data. It does not decide milestone acceptance, establish a new GUI execution, or validate native hosted platforms. Default benchmark observations are not a fresh 20-sample Gate A experiment.

The producer records the complete curated outer environment. It does not serialize every nested child environment or provide a whole dependency/cache/upfront native test-binary image. Its command-owned new-session groups have explicit termination/reaping receipts; escaped descendants remain unobserved. Version probes still use bounded direct subprocess calls.

Tool probe scope is literal: the Python-version probe hashes the resolved `uv` launcher, and pnpm/Node launcher hashes do not authenticate every nested executable. All historical source comparisons use immutable pinned Git objects, not a later mutable checkout.

## Failed checks

None.

## Raw-derived observations

Repository doctor: `pnpm run doctor`, exit 0, 7.410095750s; 28 ordinary PASS, no warnings/failures/N/A. It completed before aggregate start.

Aggregate: `pnpm verify`, exit 0, 1155.893347333s; exact 20 ACTIVE/PASS summary. Verify log: 727914 bytes, SHA-256 `fe315ba1080061c7cc7127b055483e64910d72245eb227e4ab8b93edb262cb11`.

TypeScript unit summaries total 4006 ordinary passes. Python: 1801 exact collected POSIX IDs, comprising 1799 common IDs plus the declared FIFO/socket pair; actual summary `[('1801', '376.12')]` with no skip/deselection. All 15 registered Rust-stage commands occur in order; each of three desktop feature modes passes the same [232, 232, 232] case cohort with zero failed/ignored/measured/filtered cases. This is three executions of the same 232-case cohort.

Browser ordinary pass summaries by execution: `{'default': ['262'], 'controlled_inspection': ['2'], 'controlled_contact': ['62'], 'visual': ['3']}`. The default execution may already include visual cases; these are execution counts, not a claim of distinct cases across commands.

Printed timing scopes: default native128 1-sample / 0ms-settle value 834.6884170000012ms; separate 200 different W12 page observations with 75ms settlement / 20ms rerender have printed p95 872.2247080000234ms. These are log-record observations, without a fresh independent contact raw replay or 20-sample performance claim.

All 1961 tracked-file path/size/SHA-256 rows match both snapshots and independently authenticated immutable Git blobs. The unchanged runtime payload has 40 files / 29902565 bytes; closed physical read-back confirms the same bytes/modes, manifest `c9049a3f63572c0de9b114700e9326bebc0518166840133cce9548565c58de1d` and main `fc2293a3d6425093c03ada543249ccdc2050038613cf984b3983aada18032c7c`.

Historical e0a501b full18PASS2FAIL and localRust componentPASS/observerfooterFAIL remain separate original anchors. Historical W04 auditor preparation retains its initial 41/42 collection-summary observer correction; the whole-line anchored expression is preserved here. That historical result is not a W06 attempt or outcome. All W06 checks in this report derive from its own closed records; no earlier W04/W05 execution credit is inherited. The canonical native cohort is232 per mode; the earlier183 focus and outside187 derivative remain separate; the separate outside selected four-case recovery derivative keeps its own execution identity.

See `findings.json`, `immutable-git-blob-closure.json`, `python-collected-node-ids.json`, and `native-mode-cases.json` for exact identities, raw-derived counts, and case joins. All failed checker attempts must remain historical if a later parser correction is required.
