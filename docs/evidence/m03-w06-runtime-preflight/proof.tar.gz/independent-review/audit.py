"""Independent retained-data audit; does not invoke product/tools/actors."""
from pathlib import Path
import hashlib,json,re,datetime
BASE=Path(__file__).parent.parent;OUT=Path(__file__).parent
checks=[]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads((BASE/path).read_text())
def check(name,ok,detail=None):checks.append({'name':name,'pass':bool(ok),'detail':detail})
p=read('PLAN.json');c=read('closure.json');idx=read('INDEX.json');before=read('before.json');after=read('after.json');catalog=read('default-catalog.json')
check('closed plan/wrapper hashes exact',sha(BASE/'PLAN.json')==c['plan_sha256']== 'ffd976bef3f4dedc9988287c6bf9f2bb011775e014e30733ff7cba1518fe785b' and sha(BASE/'run.py')==c['wrapper_sha256']=='0586ffea59a7fc15f27f56cf4da0ab1bafa6bb509c9584c11dafe506dbe5ddfe')
check('index binds actual closure/before/after/catalog',all(sha(BASE/name)==idx[key] for name,key in [('closure.json','closure_sha256'),('before.json','before_sha256'),('after.json','after_sha256'),('default-catalog.json','default_catalog_sha256')]))
check('native before/after2004 source byte/kind inventories exact',len(before['source'])==2004 and before['source']==after['source'] and before['source_count']==after['source_count']==2004)
check('native before/after40 runtime byte/kind inventories exact',len(before['runtime'])==40 and before['runtime']==after['runtime'] and before['runtime_count']==after['runtime_count']==40)
check('HEAD/tree/status same; dirty source correctly retained',all(before[k]==after[k] for k in ['head','tree','status']) and before['head']==p['expected_head']=='35b46287dc754a5987d653490ab49f978647ca26' and before['tree']=='f0789de7f5c82f6931eebe489110fcb771130724' and bool(before['status']))
check('snapshot modes are explicitly unavailable',all('mode' not in row for rows in [before['source'],after['source'],before['runtime'],after['runtime']] for row in rows))
check('catalog238 distinct actual names',len(catalog)==len(set(catalog))==238)
check('14 planned/recorded/executed/successful; none unexecuted',len(p['steps'])==len(idx['phases'])==c['executed_phases']==c['successful_phases']==14 and c['unexecuted']==[])
check('closure truth flags no cleanup signals',all(c[k] for k in ['source_unchanged','runtime_unchanged','git_identity_status_unchanged','all_released_groups_gone_reaped']) and c['outer_cleanup_signal_count']==0)
records=[];binary=None
for step,index in zip(p['steps'],idx['phases']):
 name=step['name'];path=BASE/'records'/(name+'.json');row=json.loads(path.read_text());out=BASE/'records'/(name+'.stdout');err=BASE/'records'/(name+'.stderr');raw=out.read_text();records.append(row)
 check(name+' raw receipt hash matches INDEX',row['name']==index['name']==name and sha(path)==index['record_sha256'])
 check(name+' stdout/stderr exact receipt hashes',sha(out)==row['stdout_sha256'] and sha(err)==row['stderr_sha256'])
 check(name+' actual exit0 no wrapper/timeout/cleanup errors',row['exit_code']==index['exit_code']==0 and not row.get('timed_out',False) and all(k not in row for k in ['wrapper_error','cleanup_error']) and row['cleanup']==[])
 check(name+' actual created direct child reaped/groupgone',row['process_creation']=='CREATED' and row['owned_leader_reaped'] is True and row['owned_group_after']=='GONE' and isinstance(row['owned_pid'],int))
 check(name+' exact planned finite argv/timeout',row['timeout_seconds']==step['timeout_seconds'] and row['elapsed_seconds']<step['timeout_seconds'] and row['argv']==([binary,*step['test_args']] if step.get('dynamic_binary') else step['argv']))
 if name=='compile-default-test-binary':
  artifacts=[json.loads(line) for line in raw.splitlines() if line.startswith('{')];artifacts=[a for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='japp_desktop' and a.get('profile',{}).get('test') and a.get('executable')]
  check('compile supplies exactly one actual test-binary path',len(artifacts)==1 and artifacts[0]['executable']==row['actual_library_test_binary']['path']);binary=row['actual_library_test_binary']['path']
 if name=='list-default':
  names=[line.removesuffix(': test') for line in raw.splitlines() if line.endswith(': test')];check('raw actual list exactly matches238 catalog',sorted(names)==catalog and len(names)==238)
 if name.startswith(('focus-','test-')):
  counts=[dict(zip(('passed','failed','ignored','measured','filtered'),map(int,x))) for x in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',raw)];names=re.findall(r'^test (.+) \.\.\. ok$',raw,re.M)
  check(name+' raw parsed counts agree both receipts',counts==row['actual_rust_counts']==index['actual_rust_counts'])
  if name.startswith('focus-'):check(name+' exact1PASS/237filtered and original selector5sec cap',names==[step['selector']] and counts==[{'passed':1,'failed':0,'ignored':0,'measured':0,'filtered':237}] and step['selector'] in catalog and step['timeout_seconds']==5)
  else:check(name+' full238 exact names no failed ignored filtered',len(names)==238 and sorted(names)==catalog and counts[0]=={'passed':238,'failed':0,'ignored':0,'measured':0,'filtered':0} and all(all(x[k]==0 for k in ['failed','ignored','filtered']) for x in counts))
 if name.startswith('clippy-'):check(name+' strict all-target warning-denial flags','--all-targets' in row['argv'] and row['argv'][-3:]==['--','-D','warnings'])
selectors=[x['selector'] for x in p['steps'] if 'selector' in x];check('exact four expected new selectors',len(selectors)==4 and {x.rsplit('::',1)[1] for x in selectors}=={'prechecked_runtime_replaced_with_fifo_is_rejected_before_read','prechecked_payload_replaced_with_fifo_is_rejected_before_read','prechecked_runtime_replaced_with_symlink_is_rejected_before_read','valid_regular_runtime_is_still_accepted_with_nonblocking_open'})
joins=read('independent-review/source-join.json');source={x['path']:x for x in before['source']};check('both actual executed source bodies retained from exact snapshots',len(joins)==2 and all(sha(BASE/x['retained'])==source[x['path']]['sha256']==x['sha256'] for x in joins))
# The later browser projection is a separate actor after one TS option fix.
w11=json.loads((BASE.parent.parent/'w11-actual/browser-v1/before.json').read_text());delta=[k for k,row in source.items() if (row['bytes'],row['sha256'])!=(w11['source'][k]['bytes'],w11['source'][k]['sha256'])];check('later W11 snapshot differs only corrected TS browser-option file',delta==['e2e/visual/desktop-catalog.spec.ts'],delta)
result={'reviewer':'/root/current_ci_repair','scope':'INDEPENDENT_RETAINED_NATIVE14PHASE_DATA_REVIEW_NOT_SOURCE_OR_WHOLECURRENT_ACCEPTANCE','utc':datetime.datetime.now(datetime.UTC).isoformat(),'clear':all(x['pass'] for x in checks),'checks_passed':sum(x['pass'] for x in checks),'checks':checks,'reference_head':before['head'],'reference_tree':before['tree'],'dirty_status':before['status'],'source_count':2004,'runtime_count':40,'permission_modes':'NOT_RECORDED_IN_THIS_ACTOR_SNAPSHOTS','actual_modes':{'default':238,'allfeatures':238,'customprotocol':238},'new_selectors':selectors,'all_groups_gone_direct_children_reaped':True,'cleanup_signals':0,'source_review':'Separate pre-execution REVIEW.md; this post-execution audit does not backdate execution into that source-only review','later_browser_source_delta':delta,'states':{'M03-W06':'IN_PROGRESS','M03-W11':'NOT_STARTED','M03':'IN_PROGRESS','verified':38,'release':'NOT_READY'}}
(OUT/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'clear':result['clear'],'checks_passed':result['checks_passed'],'checks':len(checks),'failed':[x for x in checks if not x['pass']]}))
