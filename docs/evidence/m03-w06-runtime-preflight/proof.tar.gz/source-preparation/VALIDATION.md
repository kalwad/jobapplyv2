Source-only proposal; no compilation, test, runtime actor, or root cache access
has been performed. The canonical 35b full run must finish before adoption or
validation. Only the two files in SOURCE.json are proposed for change.

The production gaps are lstat-to-open windows. ConfiguredRuntime used File::open;
runtime_integrity::read_checked used O_NOFOLLOW without O_NONBLOCK. Replacing a
previously regular final component with a FIFO can block either acquisition
before the held metadata check or next permit checkpoint. Both afterimages use
O_NOFOLLOW | O_CLOEXEC | O_NONBLOCK on Unix, retain O_NONBLOCK throughout regular
reads, and perform the original held-file identity validation before hashing.
No permit/check call count, chunk cap, cancellation assertion, digest check,
final identity check, or non-Unix acquisition behavior is changed.

The helpers expose the actual production acquisition boundary to tests. The
FIFO cases retain regular metadata, rename the original, install an actual FIFO
at that exact name, and call the same helper with no writer. The symlink case
points to the retained original inode, so a later inode comparison alone cannot
substitute for O_NOFOLLOW. The positive runtime case checks successful hashing
and acceptance; the existing exact_compiled_payload_is_accepted test remains
unchanged and exercises payload success through the new helper.

After the frozen full run closes:

1. Verify both canonical preimage hashes in SOURCE.json, or reconcile this narrow
   change with any subsequently adopted W09 overlay. Apply source.patch only
   after the source review is CLEAR. Keep every existing test assertion/body.
2. Run cargo fmt --all -- --check. If formatting changes are needed, retain and
   review that source-only delta before executing tests. Run the project's
   strict Clippy checks for the supported feature profiles.
3. Build the exact library test binary with cargo test --locked --lib --no-run
   --message-format=json under a root-owned finite compilation cap. Record the
   actual compiler-artifact executable and its hash; do not guess a target path.
4. Execute each of the following exact selectors in a fresh owned process group
   with --exact --nocapture, a five-second outer deadline, captured stdout/stderr,
   and bounded TERM/KILL/reap restricted to that group. The FIFO tests have no
   rescue writer: defective blocking code is intentionally detected by this
   outer deadline. A thread-local timeout or post-return elapsed assertion alone
   cannot bound a blocked open. Record actual test count 1, exit status, process
   closure, and source/binary hashes for each selected run.

   service::platform::tests::prechecked_runtime_replaced_with_fifo_is_rejected_before_read
   service::platform::tests::prechecked_runtime_replaced_with_symlink_is_rejected_before_read
   service::platform::tests::valid_regular_runtime_is_still_accepted_with_nonblocking_open
   service::runtime_integrity::tests::prechecked_payload_replaced_with_fifo_is_rejected_before_read
   service::runtime_integrity::tests::exact_compiled_payload_is_accepted
   service::runtime_integrity::tests::payload_chunk_verification_honors_mid_file_cancellation
   service::runtime_integrity::tests::file_growth_during_open_read_is_rejected_at_size_plus_one

5. Run the normal complete Rust validations for default, all-features, and
   custom-protocol profiles; compare the actual test catalogs with the prior
   catalogs (four added cases on Unix, no removed/renamed cases). Preserve every
   existing assertion and the meaningful positive payload/runtime checks.
6. Retain the actual macOS results and obtain the normal Ubuntu/Windows CI
   results. Until those execute, make no runtime PASS or platform completion
   claim. This source proposal currently has zero executed new tests.

This change closes final-component FIFO acquisition blocking and prevents a
replaced symlink from being followed at the runtime open. It does not claim to
preempt arbitrary in-flight regular-file IO or resolve all ancestor-path races.
