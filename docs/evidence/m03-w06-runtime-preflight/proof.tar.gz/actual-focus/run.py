from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import signal
import subprocess
import time

BASE = Path(__file__).resolve().parent
PLAN_SHA = "ffd976bef3f4dedc9988287c6bf9f2bb011775e014e30733ff7cba1518fe785b"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    assert sha(BASE / "PLAN.json") == PLAN_SHA
    plan = json.loads((BASE / "PLAN.json").read_text())
    root = Path(plan["root"])
    env = dict(os.environ)
    env.update(plan["environment_overrides"])
    records = BASE / "records"
    records.mkdir(mode=0o700)
    temporary = BASE / "tmp"
    temporary.mkdir(mode=0o700)
    env["TMPDIR"] = str(temporary)

    def git(*arguments):
        return subprocess.check_output(["/usr/bin/git", *arguments], cwd=root)

    def entry(path, label):
        if path.is_symlink():
            raw = os.readlink(path).encode()
            kind = "SYMLINK"
        else:
            raw = path.read_bytes()
            kind = "FILE"
        return {"path": label, "kind": kind, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}

    def snapshot():
        logical = sorted(set(git("ls-files", "-z", "--cached", "--others", "--exclude-standard").decode().split("\0")) - {""})
        source = [entry(root / name, name) for name in logical]
        runtime_root = root / plan["runtime_root"]
        runtime = [entry(path, str(path.relative_to(runtime_root))) for path in sorted(runtime_root.rglob("*")) if path.is_file() or path.is_symlink()]
        return {
            "utc": utc(),
            "head": git("rev-parse", "HEAD").decode().strip(),
            "tree": git("rev-parse", "HEAD^{tree}").decode().strip(),
            "status": git("status", "--porcelain=v1", "--untracked-files=all").decode(),
            "source": source,
            "source_count": len(source),
            "runtime": runtime,
            "runtime_count": len(runtime),
        }

    before = snapshot()
    assert before["head"] == plan["expected_head"]
    assert before["runtime_count"] == plan["expected_runtime_files"]
    (BASE / "before.json").write_text(json.dumps(before, indent=2) + "\n")
    results = []
    binary = None
    binary_sha = None
    listed = set()

    def group_state(pid):
        try:
            os.killpg(pid, 0)
        except ProcessLookupError:
            return "GONE"
        except PermissionError:
            return "EXISTS_NOT_AUTHORIZED"
        return "EXISTS"

    def run(step):
        nonlocal binary, binary_sha, listed
        name = step["name"]
        args = step.get("argv")
        if step.get("dynamic_binary"):
            assert binary is not None and sha(binary) == binary_sha
            args = [str(binary), *step["test_args"]]
        stdout_path = records / (name + ".stdout")
        stderr_path = records / (name + ".stderr")
        row = {"name": name, "argv": args, "cwd": str(root), "environment_overrides": {**plan["environment_overrides"], "TMPDIR": str(temporary)}, "timeout_seconds": step["timeout_seconds"], "started_utc": utc(), "cleanup": [], "process_creation": "PENDING"}
        started = time.monotonic()
        process = None
        try:
            with stdout_path.open("xb") as stdout_file, stderr_path.open("xb") as stderr_file:
                process = subprocess.Popen(args, cwd=root, env=env, stdin=subprocess.DEVNULL, stdout=stdout_file, stderr=stderr_file, start_new_session=True)
                row.update(process_creation="CREATED", owned_pid=process.pid)
                deadline = started + step["timeout_seconds"]
                cleanup_stage = 0
                while True:
                    # poll reaps a finished retained child. Never signal after
                    # this call reports terminal status.
                    code = process.poll()
                    if code is not None:
                        break
                    now = time.monotonic()
                    if now >= deadline:
                        row["timed_out"] = True
                        if cleanup_stage == 2:
                            raise RuntimeError("owned leader did not reap within cleanup cap")
                        sig = signal.SIGTERM if cleanup_stage == 0 else signal.SIGKILL
                        try:
                            os.killpg(process.pid, sig)
                            row["cleanup"].append({"signal": int(sig), "target": "OWNED_NOT_REAPED_GROUP"})
                        except ProcessLookupError:
                            row["cleanup"].append({"signal": int(sig), "target": "OWNED_NOT_REAPED_GROUP", "result": "GONE"})
                        cleanup_stage += 1
                        deadline = now + 5
                    time.sleep(0.01)
                row["exit_code"] = code
                row["owned_leader_reaped"] = process.returncode is not None
                row["owned_group_after"] = group_state(process.pid)
            if name == "compile-default-test-binary" and row["exit_code"] == 0:
                artifacts = []
                for line in stdout_path.read_text().splitlines():
                    message = json.loads(line)
                    if message.get("reason") == "compiler-artifact" and message.get("target", {}).get("name") == "japp_desktop" and message.get("profile", {}).get("test") and message.get("executable"):
                        artifacts.append(Path(message["executable"]))
                assert len(artifacts) == 1
                binary = artifacts[0]
                binary_sha = sha(binary)
                row["actual_library_test_binary"] = {"path": str(binary), "bytes": binary.stat().st_size, "sha256": binary_sha}
            if name == "list-default" and row["exit_code"] == 0:
                listed = {line.removesuffix(": test") for line in stdout_path.read_text().splitlines() if line.endswith(": test")}
                selectors = {s["selector"] for s in plan["steps"] if "selector" in s}
                assert selectors <= listed
                row["actual_listed_cases"] = len(listed)
                row["new_selectors_present"] = True
                (BASE / "default-catalog.json").write_text(json.dumps(sorted(listed), indent=2) + "\n")
            if name.startswith("focus-") or name.startswith("test-"):
                raw = stdout_path.read_text()
                counts = [dict(zip(("passed", "failed", "ignored", "measured", "filtered"), map(int, match))) for match in re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;", raw)]
                row["actual_rust_counts"] = counts
                assert counts and all(c["failed"] == 0 and c["ignored"] == 0 for c in counts)
                if name.startswith("focus-"):
                    assert len(counts) == 1 and counts[0]["passed"] == 1
                    assert step["selector"] in raw
                else:
                    assert max(c["passed"] for c in counts) == len(listed)
                    assert all(c["filtered"] == 0 for c in counts)
        except BaseException as exc:
            row["wrapper_error"] = repr(exc)
            if process is None:
                row["process_creation"] = "UNKNOWN_ON_CONSTRUCTOR_EXCEPTION"
            elif process.returncode is None:
                # This owner has not reaped the child. An exception retains the
                # exact process group until bounded termination/reap.
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                    row["cleanup"].append({"signal": int(signal.SIGKILL), "target": "OWNED_NOT_REAPED_GROUP_EXCEPTION"})
                except ProcessLookupError:
                    pass
                try:
                    row["exit_code"] = process.wait(timeout=5)
                    row["owned_leader_reaped"] = True
                    row["owned_group_after"] = group_state(process.pid)
                except BaseException as cleanup_error:
                    row["cleanup_error"] = repr(cleanup_error)
        finally:
            row["elapsed_seconds"] = time.monotonic() - started
            row["ended_utc"] = utc()
            for label, path in (("stdout", stdout_path), ("stderr", stderr_path)):
                if path.exists():
                    row[label + "_sha256"] = sha(path)
            (records / (name + ".json")).write_text(json.dumps(row, indent=2) + "\n")
            results.append(row)
        print(json.dumps({key: row.get(key) for key in ("name", "exit_code", "elapsed_seconds", "owned_group_after", "actual_listed_cases", "actual_rust_counts", "wrapper_error")}), flush=True)
        return row.get("exit_code") == 0 and row.get("owned_group_after") == "GONE" and not row.get("timed_out") and "wrapper_error" not in row

    try:
        for step in plan["steps"]:
            if not run(step):
                break
    finally:
        after = snapshot()
        (BASE / "after.json").write_text(json.dumps(after, indent=2) + "\n")
        executed = {row["name"] for row in results}
        closure = {
            "scope": plan["scope"],
            "plan_sha256": PLAN_SHA,
            "wrapper_sha256": sha(Path(__file__)),
            "source_count_before": before["source_count"],
            "source_count_after": after["source_count"],
            "source_unchanged": before["source"] == after["source"],
            "git_identity_status_unchanged": all(before[key] == after[key] for key in ("head", "tree", "status")),
            "runtime_count_before": before["runtime_count"],
            "runtime_count_after": after["runtime_count"],
            "runtime_unchanged": before["runtime"] == after["runtime"],
            "executed_phases": len(results),
            "successful_phases": sum(row.get("exit_code") == 0 and not row.get("timed_out") and "wrapper_error" not in row and row.get("owned_group_after") == "GONE" for row in results),
            "unexecuted": [step["name"] for step in plan["steps"] if step["name"] not in executed],
            "all_released_groups_gone_reaped": all(row.get("owned_leader_reaped") and row.get("owned_group_after") == "GONE" for row in results),
            "outer_cleanup_signal_count": sum(len(row["cleanup"]) for row in results),
            "actual_default_catalog_cases": len(listed),
            "closed_utc": utc(),
        }
        (BASE / "closure.json").write_text(json.dumps(closure, indent=2) + "\n")
        print(json.dumps(closure), flush=True)


if __name__ == "__main__":
    main()
