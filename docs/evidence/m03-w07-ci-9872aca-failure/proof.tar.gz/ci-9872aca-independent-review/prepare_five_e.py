from pathlib import Path
import gzip, hashlib, io, json, stat, tarfile

E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028'); S=E/'ci-9872aca'; R=Path(__file__).parent
P=R/'five-e-proposal'; relative='docs/evidence/m03-w07-ci-9872aca-failure'; D=P/'after'/relative; D.mkdir(parents=True,exist_ok=False)
report=json.loads((R/'actual-data-checks.json').read_bytes()); assert report['passed_checks']==report['total_checks']==510 and report['run_conclusion']=='failure'
selected=[]
for name in ['collector-context.json','collector-closure.json','collector-executed.py','api-receipts.json','head-commit.json','head-tree.json','immutable-git-source-sha256.json','immutable-source-api-join.json','checkout-source-bindings.json','terminal-run.json','terminal-jobs.json','official-logs.zip','log-members.json','source-delta-from-204bc06.json']:
    selected.append(S/name)
selected += sorted((S/'closed-jobs').glob('*')) + sorted((S/'source-bindings').glob('*'))
selected += [p for p in (S/'artifacts').glob('*.*') if p.suffix=='.json' or p.name=='12866490529.zip']
selected.append(sorted((S/'artifact-lists').glob('*.json'))[-1])
U=S/'artifacts/12865484769-contents'
for folder in ['worker','pipeline','pipeline-preflight','deb-inspection','runtime-build']:
    for p in (U/folder).glob('*'):
        if p.is_file() and p.suffix in ('.json','.stdout','.stderr','.py','.txt'):
            selected.append(p)
for name in ['audit.py','actual-data-checks.json','REVIEW.md','manifest.json','prepare_five_e.py']:
    selected.append(R/name)
files={str(p.relative_to(E)):p for p in selected if p.is_file()}
manifest={name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_mode':stat.S_IMODE(p.stat().st_mode)}for name,p in files.items()}
archive=D/'proof.tar.gz'
with archive.open('wb')as output:
    with gzip.GzipFile(fileobj=output,mode='wb',mtime=0,filename='')as gz:
        with tarfile.open(fileobj=gz,mode='w')as tar:
            for name,p in files.items():
                body=p.read_bytes();member=tarfile.TarInfo(name);member.size=len(body);member.mode=manifest[name]['source_mode'];member.mtime=0;tar.addfile(member,io.BytesIO(body))
with tarfile.open(archive,'r:gz')as tar:
    members=tar.getmembers();assert len(members)==len(files)
    for member in members:
        assert member.isfile()and not member.name.startswith('/')and'..'not in Path(member.name).parts
        body=tar.extractfile(member).read();assert len(body)==manifest[member.name]['bytes']and hashlib.sha256(body).hexdigest()==manifest[member.name]['sha256']
retention={'canonical_archive':'all5complete rawjobs+officialrunlogZIP+source/API bindings+all460artifactmember inventories+allselected diagnostic/raw closure records+original Windows artifact ZIP','outside_only':'original196288284-byte Ubuntu artifactZIP and expanded payload/SDK/deb bytes remain under ci-9872aca; not copied into canonical archive','ubuntu_original_zip':report['artifacts'][1],'downloaded_subject_execution':False}
summary={k:v for k,v in report.items()if k!='checks'};summary.update(schema='M03_W07_TERMINAL_FIXED9872_CI_FAILURE_V1',canonical_state_promotion='NONE',retention=retention)
artifact={'scope':report['scope'],'archive':{'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'safe_regular_members':len(files)},'review_sha256':hashlib.sha256((R/'REVIEW.md').read_bytes()).hexdigest(),'audit_sha256':hashlib.sha256((R/'actual-data-checks.json').read_bytes()).hexdigest(),'retention':retention}
for name,value in [('summary.json',summary),('artifact.json',artifact),('retention-manifest.json',{'safe_regular_members':len(files),'archive_member_bytes':sum(r['bytes']for r in manifest.values()),'archive_members':manifest})]:
    (D/name).write_text(json.dumps(value,indent=2)+'\n')
(D/'README.md').write_text('''# Terminal9872 CI: three canonical passes, two package failures

[Run40795147477](https://github.com/kalwad/jobapplyv2/actions/runs/40795147477) attempt1 completed FAILURE. Allthree canonical Mac/Ubuntu/Windows jobs pass all20ACTIVE suites, each15freshTS tasks/4006PASS. Actual Python counts are2120/2120/2118 (Windows omits twoPOSIX cases); native counts342/338/316 in eachthree modes. Allfive jobs check out merge1f7ee086340d8125b127178a19b79a0283aef1a8, whose2141-blob treef2d982dfe441ca6a98c2f9ae2862c3efd1e4373a equals head9872acaf6191ce77fd1c077ef27ea972b71b8315. These results remain distinct from old204 failures and the local9872 full.

Both dependent native-package jobs FAIL. Windows refuses three discovered MSVC dumpbin candidates before build/actor. Ubuntu builds runtime/.deb, then phase11 static inspection rejects with generic STATIC_VALIDATION_REJECTED; the underlying criterion was not retained. The owned inspector child is reaped, untimed-out and observed session cleanup is clean, so the generic wrapper error is not attributed to process cleanup. No native service actor phase is reached. Original checkout source bytes/full modes and clean status are preserved.

The independent510-join review verifies terminal verdicts, every rawjob against official fullrunZIP, actual source/tree identities, both API-digest-matched artifact ZIPs and460expanded safe regular members/retention manifests. The compact archive retains all5rawjobs, officiallogZIP, source/API/member maps, selected diagnostic/closure records and the complete336423-byte Windows artifactZIP. The original196288284-byte Ubuntu ZIP plus payload/SDK/.deb bodies remain outside under ci-9872aca; their exact API IDs, originalZIP digest and full371-member map are retained here, but those large bodies are deliberately not embedded in this canonical projection. This is not an assertion of indefinite hosted artifact availability.

No downloaded subject executable was run by the collector/reviewer. Hosted WindowsServer2025 is not native Windows11desktop, and UbuntuCI is not defaultGNOME GUI. No package acceptance, certifiedplatform, GUI, milestone or release promotion. Documentaryf104 is separate from immutable tested9872. See artifact.json/retention-manifest.json for every physical safe regular member and summary.json for precise scopes and limits.
''')
plan={'scope':'five new terminalCI failure evidence files only; no source/prose/state changes or subject execution','operations':[]}
for p in sorted(D.iterdir()):
    assert not(Path('/Users/tanishkalwad/jobapplyv2')/relative/p.name).exists()
    plan['operations'].append({'operation':'add','path':relative+'/'+p.name,'expected_preimage':'ABSENT','afterimage':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(P/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'plan_sha256':hashlib.sha256((P/'PLAN.json').read_bytes()).hexdigest(),'archive_uncompressed_bytes':sum(v['bytes']for v in manifest.values()),**artifact},indent=2))
