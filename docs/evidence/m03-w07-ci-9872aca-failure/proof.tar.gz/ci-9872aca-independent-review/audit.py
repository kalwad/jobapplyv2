"""Independent terminal CI read-only data joins; no artifact execution/imports."""
from pathlib import Path, PurePosixPath
import hashlib, json, re, stat, zipfile
B = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/ci-9872aca')
OUT = Path(__file__).parent
checks = []
def check(name, value, detail=None): checks.append({'name': name, 'pass': bool(value), 'detail': detail})
def load(name): return json.loads((B/name).read_bytes())
def sha(data): return hashlib.sha256(data).hexdigest()
def file_sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while body := stream.read(1024*1024): digest.update(body)
    return digest.hexdigest()
run = load('terminal-run.json'); jobs = load('terminal-jobs.json')['jobs']; closure = load('collector-closure.json')
immutable = load('immutable-git-source-sha256.json'); bindings = load('checkout-source-bindings.json')
head = '9872acaf6191ce77fd1c077ef27ea972b71b8315'; tree = 'f2d982dfe441ca6a98c2f9ae2862c3efd1e4373a'; merge = '1f7ee086340d8125b127178a19b79a0283aef1a8'
check('fixed attempt1 terminal failure', run['id'] == 40795147477 and run['run_attempt'] == 1 and run['head_sha'] == head and run['status'] == 'completed' and run['conclusion'] == 'failure')
check('five terminal jobs, three canonical success and two package failure', len(jobs) == 5 and all(j['status'] == 'completed' for j in jobs) and all(j['conclusion'] == ('success' if j['name'].startswith('doctor + verify') else 'failure') for j in jobs))
binding = bindings[merge]
check('actual merge exact2141 head tree and parent', binding['same_tree_as_run_head'] and binding['tree'] == tree == immutable['tree'] and binding['blob_count'] == 2141 == immutable['blob_count'] and head in binding['parents'] and immutable['commit'] == head)
head_tree = load('head-tree.json'); api_files = {x['path']: x for x in head_tree['tree'] if x['type'] == 'blob'}
check('all immutable Git OID/mode/size API joins', set(api_files) == set(immutable['files']) and all(api_files[p]['sha'] == r['git_blob'] and api_files[p]['mode'] == r['git_mode'] and api_files[p]['size'] == r['bytes'] for p,r in immutable['files'].items()))
log_members = load('log-members.json'); rows_by_job = []
for job in jobs:
    identity = job['id']; path = B/f'closed-jobs/{identity}.log'; raw = path.read_bytes()
    plain = '\n'.join(re.sub(r'^\d{4}-\d\d-\d\dT[^ ]+ ', '', line) for line in raw.decode().splitlines())
    plain = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', plain)
    found = re.search(r'log -1 --format=%H\n[^\n]*?\b([0-9a-f]{40})\s*\n', plain)
    check('actual checkout '+str(identity), found is not None and found.group(1) == merge)
    check('complete job log equals official run ZIP '+str(identity), any(m['bytes'] == len(raw) and m['sha256'] == sha(raw) and m['path'].endswith(job['name']+'.txt') for m in log_members))
    check('job API head identity '+str(identity), job['head_sha'] == head)
    row = {'id': identity, 'name': job['name'], 'conclusion': job['conclusion'], 'raw_log_bytes': len(raw), 'raw_log_sha256': sha(raw), 'checkout': merge, 'tree': tree}
    if job['name'].startswith('doctor + verify'):
        section = plain.split('== verification summary ==\n')[-1]
        suites = re.findall(r'^(\S+)[ \t]+ACTIVE[ \t]+(PASS|FAIL)[ \t]*(.*)$', section, re.M)
        check('all20 distinct ACTIVE PASS '+str(identity), len(suites) == len({s[0] for s in suites}) == 20 and all(s[1] == 'PASS' for s in suites) and 'verification exit code: 0' in section)
        unit = plain.split('$ pnpm exec turbo run test --force --concurrency=2 -- --reporter=default\n')[1].split('$ pnpm generate:contracts --check')[0]
        totals = re.findall(r'^(?:@japp/[^:]+:test:)?[ \t]+Tests[ \t]+(\d+) passed \(\d+\)', unit, re.M)
        check('actual15 fresh tasks4006 TS '+str(identity), len(totals) == 15 and sum(map(int, totals)) == 4006 and 'Cached:    0 cached, 15 total' in unit)
        python_count = 2118 if 'windows' in job['name'] else 2120
        python = re.search(r'^=+ '+str(python_count)+r' passed in ([\d.]+)s[^\n]*=+$', plain, re.M)
        check('actual ordinary Python count '+str(identity), python is not None)
        native_count = 316 if 'windows' in job['name'] else 342 if 'macos' in job['name'] else 338
        native = re.findall(r'^test result: ok\. '+str(native_count)+r' passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;.*$', plain, re.M)
        check('actual desktop native each three modes '+str(identity), len(native) == 3)
        check('post-verify tracked status check executed '+str(identity), 'verification left tracked changes' in section and '##[error]' not in section)
        row.update(passed_suites=20, failed_suites=0, unit_ts=4006, unit_tasks=15, python_passed=python_count, python_seconds=float(python.group(1)) if python else None, native_ids_each_mode=native_count, native_modes=3)
    rows_by_job.append(row)

artifacts = json.loads(sorted((B/'artifact-lists').glob('*.json'))[-1].read_bytes())['artifacts']; artifact_rows = []
for artifact in artifacts:
    identity = artifact['id']; path = B/f'artifacts/{identity}.zip'; members = load(f'artifacts/{identity}-members.json'); digest = file_sha(path)
    check('artifact API digest and size '+str(identity), artifact['size_in_bytes'] == path.stat().st_size and artifact['digest'] == 'sha256:'+digest and not artifact['expired'])
    with zipfile.ZipFile(path) as archive:
        regular = {m.filename.replace('\\','/'): m for m in archive.infolist() if not m.is_dir()}
        check('all safe regular ZIP members '+str(identity), len(regular) == len(members) and set(regular) == {r['path'] for r in members} and all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and stat.S_IFMT(m.external_attr >> 16) in (0, stat.S_IFREG) for n,m in regular.items()))
        for member in members:
            retained = B/f'artifacts/{identity}-contents'/member['path']
            check('retained artifact member '+str(identity)+'/'+member['path'], retained.is_file() and not retained.is_symlink() and retained.stat().st_size == member['bytes'] and file_sha(retained) == member['sha256'])
    retained = B/f'artifacts/{identity}-contents'; before = json.loads((retained/'worker/original-source-before.json').read_bytes()); after = json.loads((retained/'worker/original-source-after.json').read_bytes()); result = json.loads((retained/'worker/ci-result.json').read_bytes())
    check('package original2141 source endpoints same '+str(identity), before == after and before['head'] == merge and before['tree'] == tree and len(before['files']) == 2141)
    check('package original source all immutable bodies '+str(identity), set(before['files']) == set(immutable['files']) and all(before['files'][p]['bytes'] == r['bytes'] and before['files'][p]['sha256'] == r['sha256'] for p,r in immutable['files'].items()))
    check('package incomplete honest current status '+str(identity), result['status'] == 'PREPARATION_INCOMPLETE' and not result['canonical_verification_waived'] and not result['gui_claim'] and result['original_source_bytes_and_modes_equal'] and result['original_source_clean'] and result['within_whole_cleanup_deadline'])
    verification = load(f'artifacts/{identity}-retention-verification.json')
    check('artifact retention manifests exact '+str(identity), bool(verification) and all(v['all_exact'] for v in verification))
    artifact_rows.append({'id': identity, 'name': artifact['name'], 'bytes': path.stat().st_size, 'sha256': digest, 'safe_regular_members': len(members)})
check('all two artifacts retained and no subject execution', len(artifacts) == 2 and {a['id'] for a in artifacts} == set(closure['downloaded_artifacts']) and len(closure['downloaded_jobs']) == 5 and closure['no_subject_execution'] and closure['canonical_writes'] == 0)
W = B/'artifacts/12866490529-contents/worker'
choices = (W/'vswhere-dumpbin.stdout').read_text().splitlines()
check('Windows exact three candidate ambiguity', len(choices) == 3 and all(p.endswith('dumpbin.exe') for p in choices) and all(any(v in p for p in choices) for v in ['14.29.30133','14.44.35207','14.51.36231']))
U = B/'artifacts/12865484769-contents'
session = json.loads((U/'pipeline/11-package-inspect.session-result.json').read_bytes()); inspection = json.loads((U/'deb-inspection/inspection.json').read_bytes())
check('Ubuntu static rejection, not timeout or cleanup failure', inspection['status'] == 'PACKAGE_STATIC_INSPECTION_FAILED' and inspection['failure'] == 'STATIC_VALIDATION_REJECTED' and session['exit_code'] == 1 and not session['timed_out'] and session['direct_child_reaped'] and session['cleanup']['signals'] == [] and session['cleanup']['session_members_absent'] and session['cleanup']['remaining'] == [])
check('Ubuntu inspector source identities retained', file_sha(U/'deb-inspection/inspector-executed.py') == inspection['executed_inspector_sha256'] and file_sha(U/'deb-inspection/shared-inspector-executed.py') == inspection['executed_shared_inspector_sha256'])
report = {'scope':'INDEPENDENT_TERMINAL_FIXED9872_CI_DATA_JOIN_NO_ARTIFACT_EXECUTION','verdict':'CLEAR_AS_RECORDED_THREE_CANONICAL_PASSES_TWO_PACKAGE_FAILURES','passed_checks':sum(c['pass'] for c in checks),'total_checks':len(checks),'checks':checks,'run':run['id'],'run_url':run['html_url'],'run_conclusion':run['conclusion'],'head':head,'tree':tree,'actual_merge':merge,'tracked_blobs':2141,'jobs':rows_by_job,'artifacts':artifact_rows,'windows_package_cause':'PATH lookup missing dumpbin; vswhere selected VS18 installation returns three MSVC versions; exact-one candidate guard refuses before build','ubuntu_package_observation':'Runtime and .deb built; phase11 static inspector rejects with only generic STATIC_VALIDATION_REJECTED; actual underlying rejected criterion unretained; no native service actor reached','no_subject_execution':True,'canonical_writes':0,'limits':['Hosted WindowsServer2025 is not Windows11 native desktop','Ubuntu CI package static observation is not defaultGNOME GUI','No package acceptance/final GUI/certification/release/milestone promotion','Old204CI failure and local9872 aggregate remain separate outcomes']}
(OUT/'actual-data-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':report['passed_checks'],'total':len(checks),'failures':[c['name'] for c in checks if not c['pass']],'jobs':rows_by_job,'artifacts':artifact_rows},indent=2))
assert all(c['pass'] for c in checks)
