"""Own one bounded GET-only CI collector; retain outer process custody."""
from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time
E=Path(__file__).parent;O=E/'ci-f3a1c6f-root-observer';O.mkdir(exist_ok=False)
PY='/Users/tanishkalwad/.local/share/uv/python/cpython-3.12.13-macos-aarch64-none/bin/python3.12'
script=E/'next-head-ci-collector-preparation/v2/collect-next-head.py';config=E/'ci-f3a1c6f-config.json'
assert hashlib.sha256(script.read_bytes()).hexdigest()=='9cc226bb9d18c5a9a89ef0967f9a1b96f1cbb79cc99c6f8cfb3aa7e205af70b6'
assert hashlib.sha256(config.read_bytes()).hexdigest()=='96f0769ef92e4392f9039d46ca9dd60bb399397f809e3471e580abed697e673e'
(O/'executed-observer.py').write_bytes(Path(__file__).read_bytes())
now=lambda:datetime.datetime.now(datetime.UTC).isoformat()
start=now();t=time.monotonic();signals=[];stop=None
with (O/'stdout').open('xb') as out,(O/'stderr').open('xb') as err:
    child=subprocess.Popen([PY,'-I','-S','-B',str(script),'--collect','--config',str(config)],stdout=out,stderr=err,start_new_session=True,cwd='/Users/tanishkalwad/jobapplyv2')
    (O/'started.json').write_text(json.dumps({'utc':start,'pid':child.pid,'pgid':child.pid,'deadline_seconds':14400})+'\n')
    print(json.dumps({'collector_started':child.pid,'pgid':child.pid,'evidence':str(O)}),flush=True)
    try:
        code=child.wait(timeout=14400)
    except subprocess.TimeoutExpired:
        stop='TIMEOUT'
        if child.poll() is None:
            try:os.killpg(child.pid,signal.SIGTERM);signals.append('SIGTERM')
            except ProcessLookupError:pass
        try:code=child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            if child.poll() is None:
                try:os.killpg(child.pid,signal.SIGKILL);signals.append('SIGKILL')
                except ProcessLookupError:pass
            code=child.wait(timeout=10)
try:os.killpg(child.pid,0);state='PRESENT'
except ProcessLookupError:state='ABSENT'
def rec(name):
    p=O/name;return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
receipt={'start_utc':start,'end_utc':now(),'elapsed_seconds':time.monotonic()-t,'pid':child.pid,'pgid':child.pid,'reaped':child.returncode is not None,'exit_code':code,'group_after_wait':state,'signals':signals,'stop_reason':stop,'stdout':rec('stdout'),'stderr':rec('stderr'),'scope':'GET-only collector outer custody. Terminal product/job results are in collector evidence; exit0 alone is not product PASS.'}
(O/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
raise SystemExit(code if code is not None and code>=0 else 1)
