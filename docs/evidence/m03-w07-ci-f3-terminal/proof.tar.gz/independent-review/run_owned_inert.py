"""Own one bounded inert retained-data capture; no API or collector execution."""
from pathlib import Path
from datetime import datetime,UTC
import hashlib,json,os,subprocess,sys,time
H=Path(__file__).resolve().parent;label,name=sys.argv[1:]
assert label.isascii() and label.replace('-','').isalnum()
assert name in ('retain_closed_collector.py','capture_outer_closure.py')
q=H/'qa'/label;q.mkdir(parents=True,exist_ok=False)
paths=[H/name,H/'retained/config.json',H/'retained/immutable-source-map.json',H/'retained/expected-catalog.json']
def pins():return {str(p):{'bytes':p.stat().st_size,'full_mode':p.lstat().st_mode,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths}
before=pins();clock=time.monotonic();start=datetime.now(UTC).isoformat();argv=['/Users/tanishkalwad/.local/share/uv/python/cpython-3.12.13-macos-aarch64-none/bin/python3.12','-I','-S','-B',str(H/name)]
with (q/'stdout.log').open('xb') as out,(q/'stderr.log').open('xb') as err:
 p=subprocess.Popen(argv,cwd=H,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True);code=p.wait(timeout=55)
try:os.killpg(p.pid,0);group='PRESENT'
except ProcessLookupError:group='ABSENT'
after=pins();receipt={'argv':argv,'pid':p.pid,'pgid':p.pid,'reaped':p.returncode is not None,'exit_code':code,'group_after_wait':group,'signals':[],'timeouts':[],'start_utc':start,'end_utc':datetime.now(UTC).isoformat(),'seconds':time.monotonic()-clock,'lease_before':before,'lease_after':after,'leased_inputs_equal':before==after,'scope':'This inert local capture only; existing remote CI/collector owners are distinct.'}
(q/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k] for k in ('pid','exit_code','reaped','group_after_wait','seconds','leased_inputs_equal')}));assert group=='ABSENT' and before==after
raise SystemExit(code)
