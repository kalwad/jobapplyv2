"""Prepared generic read-only next-head collector. No network at import.

The bd4 collector's GET custody, pagination, safe ZIP and retention mechanisms
are retained. Exact future head/tree/runs come only from root-supplied config.
Execution requires an explicit --collect invocation after separate root review.
"""
from pathlib import Path, PurePosixPath
import argparse,datetime,hashlib,json,os,re,signal,stat,subprocess,time,zipfile
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
PREPARATION=Path(__file__).parent
receipts=[];closed_jobs=set();artifacts_done=set();artifact_attempts={};checkout_bindings={};previous={};terminal=set();failures=[]
def now():return datetime.datetime.now(datetime.UTC).isoformat()
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        while chunk:=stream.read(1024*1024):h.update(chunk)
    return h.hexdigest()
def dump(path,obj):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,indent=2)+'\n')
def group_state(pid):
    try:os.killpg(pid,0);return 'PRESENT'
    except ProcessLookupError:return 'ABSENT'
def api(endpoint,name,*,timeout=50,binary=False,max_bytes=32*1024*1024):
    target=BASE/name;target.parent.mkdir(parents=True,exist_ok=True);start=now();started=time.monotonic();signals=[];stop=None;code=None;child=None
    error=target.with_name(target.name+'.stderr')
    try:
        with target.open('xb') as output,error.open('xb') as stderr:
            child=subprocess.Popen(['gh','api','--method','GET',REPO+endpoint],stdout=output,stderr=stderr,start_new_session=True)
            try:
                while child.poll() is None:
                    if time.monotonic()-started>timeout:stop='TIMEOUT';break
                    if target.stat().st_size>max_bytes or error.stat().st_size>1024*1024:stop='OUTPUT_LIMIT';break
                    time.sleep(.1)
                if stop is not None:
                    try:os.killpg(child.pid,signal.SIGTERM);signals.append('SIGTERM')
                    except ProcessLookupError:pass
                    try:code=child.wait(timeout=5)
                    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);signals.append('SIGKILL');code=child.wait(timeout=5)
                else:code=child.wait(timeout=5)
            finally:
                if child.returncode is None:
                    try:os.killpg(child.pid,signal.SIGTERM);signals.append('SIGTERM')
                    except ProcessLookupError:pass
                    try:code=child.wait(timeout=5)
                    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);signals.append('SIGKILL');code=child.wait(timeout=5)
    except BaseException as exc:
        dump(BASE/'collector-exception.json',{'endpoint':endpoint,'name':name,'error_type':type(exc).__name__,'error':str(exc),'utc':now()});raise
    receipt={'endpoint':endpoint,'method':'GET','start_utc':start,'end_utc':now(),'exit_code':code,'path':name,'bytes':target.stat().st_size,'sha256':digest(target),'stderr_bytes':error.stat().st_size,'stderr_sha256':digest(error),'pid':child.pid,'pgid':child.pid,'child_reaped':child.returncode is not None,'group_after_wait':group_state(child.pid),'signals':signals,'stop_reason':stop}
    receipts.append(receipt);dump(BASE/'api-receipts.json',receipts)
    if code!=0 or stop is not None:return None
    if target.stat().st_size>max_bytes:return None
    if binary:return target
    try:return json.loads(target.read_text())
    except ValueError as exc:
        dump(target.with_name(target.name+'.parse-error.json'),{'error':str(exc),'raw_retained':True});return None
def paginated(endpoint,key,name,index):
    all_rows=[];total=None
    for page in range(1,11):
        data=api(endpoint+('&' if '?' in endpoint else '?')+f'per_page=100&page={page}',f'{name}/{index:03d}-p{page}.json')
        if data is None:return None
        if total is None:total=data['total_count']
        assert total<=1000,'finite API list bound'
        all_rows.extend(data[key])
        if len(all_rows)>=total:break
    assert len(all_rows)==total
    return {'total_count':total,key:all_rows}
def safe_unzip(path,target,*,max_total=1536*1024*1024,max_file=600*1024*1024):
    target.mkdir(parents=True,exist_ok=False);members=[];seen=set();total=0;started=time.monotonic()
    with zipfile.ZipFile(path) as archive:
        assert len(archive.infolist())<=12000,'member count bound'
        for item in archive.infolist():
            name=item.filename;pure=PurePosixPath(name);canonical=pure.as_posix()
            assert '\\' not in name and '\0' not in name and not pure.is_absolute() and '..' not in pure.parts and pure.parts and all(':' not in p for p in pure.parts),'unsafe ZIP path'
            assert name.rstrip('/')==canonical and canonical not in seen,'noncanonical/duplicate ZIP path';seen.add(canonical)
            mode=item.external_attr>>16;kind=stat.S_IFMT(mode);assert kind in (0,stat.S_IFREG,stat.S_IFDIR),'nonregular archive node'
            p=target/canonical
            if item.is_dir():assert kind in (0,stat.S_IFDIR);p.mkdir(parents=True,exist_ok=True);continue
            assert kind!=stat.S_IFDIR and item.file_size<=max_file,'single member/class bound';total+=item.file_size;assert total<=max_total,'expanded byte bound'
            p.parent.mkdir(parents=True,exist_ok=True)
            with archive.open(item) as src,p.open('xb') as out:
                size=0
                while chunk:=src.read(1024*1024):
                    assert time.monotonic()-started<120,'expanded archive wallclock bound';size+=len(chunk);assert size<=item.file_size;out.write(chunk)
            assert size==item.file_size
            members.append({'path':canonical,'bytes':size,'sha256':digest(p),'zip_mode':mode,'zip_create_system':item.create_system,'zip_external_attr':item.external_attr,'retained_full_mode':p.lstat().st_mode})
    return members
def source_join(tree):
    assert not tree['truncated']
    api_files={x['path']:x for x in tree['tree'] if x['type']=='blob'}
    return {'blob_count':len(api_files),'exact_paths':set(api_files)==set(immutable['files']),'all_oid_mode_size_equal':set(api_files)==set(immutable['files']) and all(api_files[p]['sha']==r['git_blob'] and api_files[p]['mode']==r['git_mode'] and api_files[p].get('size')==r['bytes'] for p,r in immutable['files'].items()),'local_bodies_SHA1_framed_SHA256_and_Git_modes':True}
def checkout_role(workflow_path):
    if workflow_path=='.github/workflows/ci.yml':return 'canonical_pr_merge'
    assert workflow_path in ('.github/workflows/ubuntu-gnome-prepare.yml','.github/workflows/windows11-native-lifecycle.yml','.github/workflows/ubuntu-gnome-lifecycle.yml','.github/workflows/windows11-native-prepare.yml'),'unknown checkout workflow'
    return 'auxiliary_direct_source'
def bind_checkout(job_id,path,role):
    assert role in ('canonical_pr_merge','auxiliary_direct_source'),'unknown checkout role'
    raw=path.read_text(errors='replace');found=re.search(r'log -1 --format=%H\r?\n[^\r\n]*?\b([0-9a-f]{40})\s*\r?\n',raw)
    if not found:
        dump(BASE/f'checkout-unobserved/{job_id}.json',{'job_id':job_id,'reason':'official checkout hash line not observed; no checkout source assumption'});return
    commit=found.group(1)
    if commit not in checkout_bindings:
        info=api('git/commits/'+commit,'source-bindings/'+commit+'-commit.json')
        if info is None:return
        tree_id=info['tree']['sha'];tree=api('git/trees/'+tree_id+'?recursive=1','source-bindings/'+commit+'-tree.json')
        if tree is None:return
        checkout_bindings[commit]={'observed_checkout_commit':commit,'observed_in_jobs':[],'tree':tree_id,'same_tree_as_run_head':tree_id==TREE,'is_distinct_from_api_head':commit!=HEAD,'parents':[x['sha'] for x in info['parents']],'source_join':source_join(tree)}
    checkout_bindings[commit]['parents_match_start_PR_base_and_source']=(checkout_bindings[commit]['parents']==[CONFIG['expected_base_commit'],HEAD])
    checkout_bindings[commit]['observed_in_jobs'].append(job_id);
    identity_matches_role=(commit!=HEAD and checkout_bindings[commit]['parents_match_start_PR_base_and_source']) if role=='canonical_pr_merge' else commit==HEAD
    matches=identity_matches_role and checkout_bindings[commit]['same_tree_as_run_head'] and checkout_bindings[commit]['source_join']['all_oid_mode_size_equal']
    checkout_bindings[commit].setdefault('observed_job_role_matches',[]).append({'job_id':job_id,'role':role,'identity_matches_role':identity_matches_role,'matches':matches})
    if not matches:
        failures.append({'kind':'CHECKOUT_SOURCE_BINDING_MISMATCH','job':job_id,'observed_commit':commit});
    dump(BASE/'checkout-source-bindings.json',checkout_bindings)
    print(json.dumps({'checkout_binding':checkout_bindings[commit]}),flush=True)
def retention_manifests(target):
    verification=[]
    for manifest in target.rglob('manifest.json'):
        try:value=json.loads(manifest.read_text())
        except (UnicodeError,ValueError):continue
        if not isinstance(value,dict) or not isinstance(value.get('files'),dict):continue
        verified=[]
        for name,row in value['files'].items():
            q=PurePosixPath(name);assert isinstance(name,str) and not q.is_absolute() and '..' not in q.parts and q.as_posix()==name and '\\' not in name
            p=manifest.parent/name
            verified.append({'path':name,'present_regular':p.is_file() and not p.is_symlink(),'matches':p.is_file() and p.stat().st_size==row['bytes'] and digest(p)==row['sha256'],'full_mode':p.lstat().st_mode if p.exists() else None})
        verification.append({'manifest':manifest.relative_to(target).as_posix(),'declared_count':value.get('file_count'),'declared_bytes':value.get('bytes'),'verified_members':verified,'all_exact':all(x['present_regular'] and x['matches'] for x in verified)})
    return verification
def collect_artifacts(run,index):
    data=paginated(f'actions/runs/{run}/artifacts','artifacts',f'runs/{run}/artifact-lists',index)
    if data is None:return
    for artifact in data['artifacts']:
        identity=artifact['id'];attempt=artifact_attempts.get(identity,0)
        if identity in artifacts_done or artifact['expired'] or attempt>=3:continue
        artifact_attempts[identity]=attempt+1;folder=f'artifacts/{identity}';dump(BASE/f'{folder}/metadata.json',artifact)
        if artifact['size_in_bytes']>1536*1024*1024:
            dump(BASE/f'{folder}/not-downloaded.json',{'reason':'artifact exceeds finite bound','metadata':artifact});artifacts_done.add(identity);continue
        path=api(f'actions/artifacts/{identity}/zip',f'{folder}/attempt-{attempt+1}.zip',timeout=240,binary=True,max_bytes=1536*1024*1024)
        if path is None:continue
        target=BASE/f'{folder}/contents-attempt-{attempt+1}'
        try:
            members=safe_unzip(path,target);dump(BASE/f'{folder}/members-attempt-{attempt+1}.json',members);verification=retention_manifests(target);dump(BASE/f'{folder}/retention-verification-attempt-{attempt+1}.json',verification)
            artifacts_done.add(identity)
            retained={'artifact_id':identity,'run':run,'name':artifact['name'],'archive':str(path.relative_to(BASE)),'archive_bytes':path.stat().st_size,'archive_sha256':digest(path),'safe_regular_members':len(members),'retention_manifests_exact':all(x['all_exact'] for x in verification),'contents':str(target.relative_to(BASE))}
            dump(BASE/f'{folder}/closure.json',retained);print(json.dumps({'artifact_retained':retained}),flush=True)
            exports=[]
            for p in target.rglob('*'):
                if p.is_file() and (p.name=='windows-portable.zip' or p.name.endswith('.deb') or p.name.endswith('.AppImage')):exports.append({'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p),'full_mode':p.lstat().st_mode})
            if exports:dump(BASE/f'{folder}/package-export-candidates.json',{'artifact':retained,'files':exports,'scope':'Retained bytes only; no install, native run, release, or platform acceptance.'});print(json.dumps({'package_export_candidates':exports,'artifact_id':identity,'artifact_name':artifact['name']}),flush=True)
        except (OSError,ValueError,AssertionError,zipfile.BadZipFile) as exc:
            dump(BASE/f'{folder}/retention-error-attempt-{attempt+1}.json',{'metadata':artifact,'error_type':type(exc).__name__,'error':str(exc),'raw_zip_retained':True});print(json.dumps({'artifact_review_error':identity,'attempt':attempt+1,'error_type':type(exc).__name__,'error':str(exc)}),flush=True)


def local_json(path,limit):
    path=Path(path);assert path.is_absolute() and path.is_relative_to(E)
    info=path.lstat();assert stat.S_ISREG(info.st_mode) and info.st_size<=limit
    return json.loads(path.read_bytes())
def hexpin(value,length):
    return isinstance(value,str) and re.fullmatch('[0-9a-f]{'+str(length)+'}',value) is not None
def relative_source(path):
    return isinstance(path,str) and bool(path) and '\\' not in path and PurePosixPath(path).as_posix()==path and not PurePosixPath(path).is_absolute() and '..' not in PurePosixPath(path).parts and all(':' not in part for part in PurePosixPath(path).parts)
def load_config(path):
    config=local_json(path,65536)
    required={'schema_version','output_directory','repository','expected_source_commit','expected_source_tree','expected_base_commit','pull_request','expected_head_ref','expected_base_ref','source_manifest','catalog','runs','canonical_verify_jobs','package_job_prefix','package_platforms'}
    assert isinstance(config,dict) and set(config)==required and config['schema_version']==1
    assert re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',config['repository'])
    for key in ('expected_source_commit','expected_source_tree','expected_base_commit'):assert hexpin(config[key],40),key
    for key in ('expected_head_ref','expected_base_ref'):assert isinstance(config[key],str) and 1<=len(config[key])<=256 and not any(ord(c)<32 for c in config[key])
    assert type(config['pull_request']) is int and config['pull_request']>0
    output=Path(config['output_directory']);assert output.is_absolute() and output.parent==E and re.fullmatch(r'ci-[a-zA-Z0-9-]{7,80}',output.name) and not output.exists()
    binding=config['source_manifest'];assert isinstance(binding,dict) and set(binding)=={'path','sha256'} and hexpin(binding['sha256'],64)
    immutable=local_json(binding['path'],16*1024*1024);assert digest(Path(binding['path']))==binding['sha256']
    assert immutable['commit']==config['expected_source_commit'] and immutable['tree']==config['expected_source_tree'] and immutable['all_git_blob_SHA1_framings_verified'] is True
    files=immutable['files'];assert isinstance(files,dict) and 1<=len(files)<=10000 and immutable['blob_count']==len(files)
    assert sum(row['bytes'] for row in files.values())<1024*1024*1024
    for name,row in files.items():
        assert relative_source(name) and type(row['bytes']) is int and 0<=row['bytes']<1024*1024*1024 and hexpin(row['git_blob'],40) and hexpin(row['sha256'],64) and row['git_mode'] in ('100644','100755')
    custody=immutable['git_batch_custody'];assert custody['reaped'] is True and custody['exit_code']==0 and custody['group_after_wait']=='ABSENT' and custody['signals']==[]
    catalog=config['catalog'];assert isinstance(catalog,dict) and set(catalog)=={'source_path','local_path','sha256'} and relative_source(catalog['source_path']) and hexpin(catalog['sha256'],64)
    body_path=Path(catalog['local_path']);value=local_json(body_path,4*1024*1024);body=body_path.read_bytes();row=files[catalog['source_path']]
    assert hashlib.sha256(body).hexdigest()==catalog['sha256']==row['sha256'] and len(body)==row['bytes'] and hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()==row['git_blob']
    assert set(value)=={'schema_version','normalization_version','common','posix_only_node_ids'} and value['schema_version']==1 and value['normalization_version']==1
    common=value['common'];ids=common['node_ids'];posix=value['posix_only_node_ids']
    assert isinstance(ids,list) and isinstance(posix,list) and 1<=len(ids)<=100000 and len(posix)<=1000 and all(isinstance(s,str) and 0<len(s)<=16384 for s in ids+posix)
    assert len(ids)==len(set(ids))==common['count'] and len(posix)==len(set(posix)) and not set(ids)&set(posix) and hashlib.sha256(('\n'.join(ids)+'\n').encode()).hexdigest()==common['sha256']
    runs=config['runs'];assert isinstance(runs,list) and len(runs)==5 and len({r['id'] for r in runs})==5 and len({r['workflow_path'] for r in runs})==5
    assert [r['role'] for r in runs].count('canonical')==1 and [r['role'] for r in runs].count('disabled_policy')==4
    for run in runs:
        assert set(run)=={'id','name','attempt','workflow_path','workflow_sha256','role','authorization_job'} and type(run['id']) is int and run['id']>0 and type(run['attempt']) is int and 1<=run['attempt']<=10
        assert isinstance(run['name'],str) and 1<=len(run['name'])<=256 and isinstance(run['authorization_job'],str) and len(run['authorization_job'])<=128
        assert relative_source(run['workflow_path']) and run['workflow_path'].startswith('.github/workflows/') and files[run['workflow_path']]['sha256']==run['workflow_sha256']
    verify=config['canonical_verify_jobs'];assert isinstance(verify,list) and len(verify)==len(set(verify))==3 and all(isinstance(s,str) and 1<=len(s)<=256 for s in verify)
    assert isinstance(config['package_job_prefix'],str) and 1<=len(config['package_job_prefix'])<=128
    assert isinstance(config['package_platforms'],list) and 1<=len(config['package_platforms'])<=10 and all(isinstance(x,str) and 1<=len(x)<=128 for x in config['package_platforms'])
    return config,immutable,{'source_path':catalog['source_path'],'sha256':catalog['sha256'],'common_count':len(ids),'posix_only_count':len(posix),'expected_windows_count':len(ids),'expected_posix_count':len(ids)+len(posix),'scope':'Expected collection inventory from exact pinned immutable commit, not execution or PASS evidence.'}

def summarize_terminals():
    records=[]
    for run_id,expected in RUN_CONFIG.items():
        folder=BASE/'runs'/str(run_id)
        run=json.loads((folder/'terminal-run.json').read_bytes());jobs=json.loads((folder/'terminal-jobs.json').read_bytes())['jobs']
        record={'run_id':run_id,'workflow':expected['name'],'role':expected['role'],'API_conclusion':run['conclusion'],'actual_jobs':[{'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'runner_name':j.get('runner_name'),'labels':j.get('labels')} for j in jobs]}
        artifacts=[];exports=[];policy=[]
        for path in (BASE/'artifacts').glob('*/closure.json'):
            retained=json.loads(path.read_bytes())
            if retained['run']!=run_id:continue
            artifacts.append(retained)
            candidate=path.parent/'package-export-candidates.json'
            if candidate.exists():exports += json.loads(candidate.read_bytes())['files']
            for request in (BASE/retained['contents']).rglob('request.json'):
                if request.stat().st_size>4096:continue
                try:value=json.loads(request.read_bytes())
                except (UnicodeError,ValueError):continue
                if isinstance(value,dict) and value.get('enabled')=='false' and value.get('status')=='SKIP_NO_ROOT_REQUEST':policy.append({'path':str(request.relative_to(BASE)),'sha256':digest(request),'status':'SKIP_NO_ROOT_REQUEST'})
        record['retained_artifact_ids']=[r['artifact_id'] for r in artifacts];record['retained_package_export_candidates']=exports
        if expected['role']=='canonical':
            verification=[]
            for name in CONFIG['canonical_verify_jobs']:
                matches=[j for j in jobs if j['name']==name]
                verification.append({'expected_job':name,'unique_actual_job':len(matches)==1,'actual_matches':[{'id':j['id'],'conclusion':j['conclusion']} for j in matches]})
            record['three_canonical_verification_outcomes']=verification
            record['dependent_package_jobs']=[{'id':j['id'],'name':j['name'],'conclusion':j['conclusion']} for j in jobs if j['name'].startswith(CONFIG['package_job_prefix'])]
            record['expected_package_platforms']=CONFIG['package_platforms']
            record['all_three_success_as_API_metadata']=all(v['unique_actual_job'] and v['actual_matches'][0]['conclusion']=='success' for v in verification)
            record['package_scope']='Actual dependent jobs are retained, including an unexpanded skipped matrix if observed. Exports are retained bytes only; no native install/run/release/platform acceptance is inferred.'
        else:
            authorization=[j for j in jobs if j['name']==expected['authorization_job']];downstream=[j for j in jobs if j['name']!=expected['authorization_job']]
            record['disabled_policy_artifact_markers']=policy
            record['disabled_policy_as_recorded']=bool(policy and len(authorization)==1 and authorization[0]['conclusion']=='success' and downstream and all(j['conclusion']=='skipped' for j in downstream))
            record['native_execution_credit']=False
            record['policy_scope']='Authorization success plus explicit disabled request artifact and downstream SKIP describe policy only. Unexpected/missing marker or downstream execution is retained without a disabled-success assumption.'
        records.append(record)
    dump(BASE/'terminal-outcomes.json',{'runs':records,'failures':failures,'tested_checkout_bindings':checkout_bindings,'scope':'Official terminal metadata/log/artifact observations; all failures remain failures. No default-GNOME/Windows11/native/release claim. Masked parameter IDs and raw test summaries require separate case audit.'})


def main(config_path):
    global BASE,HEAD,TREE,RUNS,RUN_CONFIG,REPO,CONFIG,immutable,pull
    CONFIG,immutable,catalog=load_config(config_path)
    BASE=Path(CONFIG['output_directory']);BASE.mkdir(exist_ok=False)
    HEAD=CONFIG['expected_source_commit'];TREE=CONFIG['expected_source_tree']
    RUN_CONFIG={r['id']:r for r in CONFIG['runs']};RUNS={k:r['name'] for k,r in RUN_CONFIG.items()}
    REPO='repos/'+CONFIG['repository']+'/'
    (BASE/'immutable-git-source-sha256.json').write_bytes(Path(CONFIG['source_manifest']['path']).read_bytes())
    (BASE/'expected-catalog.json').write_bytes(Path(CONFIG['catalog']['local_path']).read_bytes())
    (BASE/'collector-config.json').write_bytes(Path(config_path).read_bytes())
    (BASE/'collector-executed.py').write_bytes(Path(__file__).read_bytes())
    (BASE/'collector-reference-bd4.py').write_bytes((PREPARATION/'reference/collect-ci-bd4cffd.py').read_bytes())
    dump(BASE/'collector-context.json',{'runs':RUN_CONFIG,'head':HEAD,'tree':TREE,'expected_base':CONFIG['expected_base_commit'],'source_blobs':len(immutable['files']),'catalog':catalog,'start_utc':now(),'scope':'READ_ONLY_GET_API_OFFICIAL_LOG_ARTIFACT_RETENTION; NO_CANONICAL_WRITES_OR_SUBJECT_EXECUTION','parent_collector_sha256':digest(PREPARATION/'reference/collect-ci-bd4cffd.py'),'source_body_binding':immutable['scope'],'limitations':['Local immutable Git body proof is distinct from API OID/mode/size inventory; all API blob bodies are not separately downloaded','Git regular/executable classes do not attest arbitrary target OS permissions','Opaque/masked Bearer-param test IDs cannot be de-redacted; platform multiplicity and exact direct IDs need a separate terminal case audit','Catalog expectations do not prove execution or PASS','A build-host WindowsServer result does not certify Windows11; Ubuntu build-host data does not certify default GNOME','Metadata-only policy success is not native execution, package acceptance or export release']})
    head=api('git/commits/'+HEAD,'head-commit.json');assert head and head['sha']==HEAD and head['tree']['sha']==TREE
    pull=api('pulls/'+str(CONFIG['pull_request']),'pull-request-start.json')
    assert pull and pull['head']['sha']==HEAD and pull['head']['ref']==CONFIG['expected_head_ref'] and pull['base']['ref']==CONFIG['expected_base_ref'] and pull['base']['sha']==CONFIG['expected_base_commit']
    source=api('git/trees/'+TREE+'?recursive=1','head-tree.json');assert source and source_join(source)['all_oid_mode_size_equal']
    dump(BASE/'immutable-source-api-join.json',source_join(source))
    poll_delay=30
    for index in range(181):
        round_changed=False
        for run_id,expected_name in RUNS.items():
            if run_id in terminal:continue
            folder=f'runs/{run_id}';run=api(f'actions/runs/{run_id}',f'{folder}/snapshots/{index:03d}-run.json');data=paginated(f'actions/runs/{run_id}/jobs','jobs',f'{folder}/snapshots/jobs',index)
            if run is None or data is None:continue
            assert run['head_sha']==HEAD and run['run_attempt']==RUN_CONFIG[run_id]['attempt'] and run['name']==expected_name and run['path']==RUN_CONFIG[run_id]['workflow_path'] and run['event']=='pull_request'
            jobs=data['jobs'];state=(run['status'],run['conclusion'],tuple((j['id'],j['name'],j['status'],j['conclusion'],next((s['number'] for s in j['steps'] if s['status']=='in_progress'),None)) for j in jobs))
            if state!=previous.get(run_id):
                round_changed=True
                print(json.dumps({'observed_utc':now(),'run':run_id,'name':expected_name,'status':run['status'],'conclusion':run['conclusion'],'jobs':[{'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'current_step':next((s['name'] for s in j['steps'] if s['status']=='in_progress'),None)} for j in jobs]}),flush=True);previous[run_id]=state
            new_closed=False
            for job in jobs:
                if job['status']!='completed' or job['id'] in closed_jobs:continue
                closed_jobs.add(job['id']);new_closed=True;dump(BASE/f'{folder}/closed-jobs/{job["id"]}.json',job)
                if job['conclusion']=='skipped':continue
                path=api(f'actions/jobs/{job["id"]}/logs',f'{folder}/closed-jobs/{job["id"]}.log',binary=True,max_bytes=64*1024*1024)
                if path is None:failures.append({'kind':'LOG_NOT_RETAINED','run':run_id,'job':job['id']});continue
                bind_checkout(job['id'],path,checkout_role(RUN_CONFIG[run_id]['workflow_path']));print(json.dumps({'closed_job_retained':job['id'],'run':run_id,'name':job['name'],'conclusion':job['conclusion'],'bytes':path.stat().st_size,'sha256':digest(path)}),flush=True)
                if job['conclusion']!='success':
                    raw=path.read_text(errors='replace');tail=raw[raw.rfind('== verification summary =='):] if '== verification summary ==' in raw else raw[-16000:];(BASE/f'{folder}/closed-jobs/{job["id"]}-failure-excerpt.txt').write_text(tail);failures.append({'kind':'TERMINAL_JOB_FAILURE','run':run_id,'job':job['id'],'name':job['name'],'conclusion':job['conclusion']})
            if new_closed or run['status']=='completed':collect_artifacts(run_id,index)
            if run['status']=='completed':
                dump(BASE/f'{folder}/terminal-run.json',run);dump(BASE/f'{folder}/terminal-jobs.json',data)
                logs=api(f'actions/runs/{run_id}/logs',f'{folder}/official-logs.zip',timeout=120,binary=True,max_bytes=256*1024*1024)
                if logs is not None:
                    try:members=safe_unzip(logs,BASE/f'{folder}/logs',max_total=256*1024*1024,max_file=64*1024*1024);dump(BASE/f'{folder}/log-members.json',members)
                    except (OSError,ValueError,AssertionError,zipfile.BadZipFile) as exc:dump(BASE/f'{folder}/log-retention-error.json',{'error_type':type(exc).__name__,'error':str(exc)})
                terminal.add(run_id);print(json.dumps({'terminal_run':run_id,'name':expected_name,'conclusion':run['conclusion'],'jobs':len(jobs)}),flush=True)
            dump(BASE/'collector-progress.json',{'updated_utc':now(),'terminal_runs':sorted(terminal),'closed_jobs':sorted(closed_jobs),'artifact_ids_retained':sorted(artifacts_done),'failures':failures,'checkout_bindings':checkout_bindings})
        if len(terminal)==len(RUNS):
            summarize_terminals();dump(BASE/'collector-closure.json',{'end_utc':now(),'terminal_runs':sorted(terminal),'closed_jobs':sorted(closed_jobs),'artifact_ids_retained':sorted(artifacts_done),'checkout_bindings':checkout_bindings,'failures':failures,'no_subject_execution':True,'canonical_writes':0});print(json.dumps({'collector_terminal':True,'runs':len(terminal),'jobs':len(closed_jobs),'artifacts':len(artifacts_done),'failures':failures}),flush=True);break
        if index==180:dump(BASE/'collector-time-limit.json',{'end_utc':now(),'product_conclusion':'UNOBSERVED_NOT_ASSUMED','polls':181});break
        poll_delay=30 if round_changed else min(60,poll_delay+15)
        time.sleep(poll_delay)

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument("--collect",action="store_true",required=True);parser.add_argument("--config",type=Path,required=True);args=parser.parse_args();main(args.config)
