"""Retain closed old collector bytes only; no imports or API calls."""
from pathlib import Path
from datetime import UTC, datetime
import hashlib
import json
import stat

E = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
SOURCE = E / 'ci-f3a1c6f'
OUT = E / 'ci-f3a1c6f-independent-review/v1'
TARGET = OUT / 'raw-collector'
assert (SOURCE / 'collector-closure.json').is_file()
assert (SOURCE / 'terminal-outcomes.json').is_file()
def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(1024*1024):
            h.update(chunk)
    return h.hexdigest()
def inventory(root):
    rows = {}
    for p in sorted(root.rglob('*')):
        s = p.lstat()
        if stat.S_ISDIR(s.st_mode):
            continue
        assert stat.S_ISREG(s.st_mode) and not p.is_symlink()
        rows[p.relative_to(root).as_posix()] = {'bytes': s.st_size, 'sha256': digest(p), 'full_mode': s.st_mode}
    assert 1 <= len(rows) <= 12000
    assert sum(row['bytes'] for row in rows.values()) <= 2048 * 1024 * 1024
    return rows
before = inventory(SOURCE)
TARGET.mkdir(exist_ok=False)
for name, pin in before.items():
    source = SOURCE / name
    dest = TARGET / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    with source.open('rb') as src, dest.open('xb') as out:
        while chunk := src.read(1024 * 1024):
            out.write(chunk)
    dest.chmod(stat.S_IMODE(pin['full_mode']))
copied = inventory(TARGET)
after = inventory(SOURCE)
assert before == copied == after
(OUT / 'collector-retention.json').write_text(json.dumps({'utc': datetime.now(UTC).isoformat(), 'source': str(SOURCE), 'source_before': before, 'source_after': after, 'copy': copied, 'all_bytes_fullmodes_equal': True, 'files': len(before), 'bytes': sum(row['bytes'] for row in before.values()), 'scope': 'Closed retained-data copy, no API/network/collector rerun/canonical or source execution. Outer collector owner custody supplied separately by root.'}, indent=2) + '\n')
print(json.dumps({'files': len(before), 'bytes': sum(row['bytes'] for row in before.values()), 'all_bytes_fullmodes_equal': True}))
