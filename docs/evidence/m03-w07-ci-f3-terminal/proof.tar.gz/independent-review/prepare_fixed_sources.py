"""Inert fixed-S workflow read and retained-source preparation; no API calls."""
from __future__ import annotations

import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import time

E = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
OUT = E / 'ci-f3a1c6f-independent-review/v1'
ROOT = Path('/Users/tanishkalwad/jobapplyv2')
CONFIG = E / 'ci-f3a1c6f-config.json'
MAP = E / 'clean-full-f3a1c6f-independent-review/v1/immutable-git-source-sha256.json'
CAT = E / 'clean-full-f3a1c6f-independent-review/v1/immutable-python-test-inventory.v1.json'

def sha(body: bytes) -> str:
    return hashlib.sha256(body).hexdigest()

def dump(name: str, value: object) -> None:
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def record(path: Path) -> dict[str, object]:
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode)
    body = path.read_bytes()
    return {'path': str(path), 'bytes': len(body), 'sha256': sha(body), 'full_mode': info.st_mode}

cfg_body = CONFIG.read_bytes()
assert sha(cfg_body) == '96f0769ef92e4392f9039d46ca9dd60bb399397f809e3471e580abed697e673e'
cfg = json.loads(cfg_body)
mapping_body = MAP.read_bytes()
assert sha(mapping_body) == cfg['source_manifest']['sha256']
mapping = json.loads(mapping_body)
cat_body = CAT.read_bytes()
assert sha(cat_body) == cfg['catalog']['sha256']
paths = [row['workflow_path'] for row in cfg['runs']]
assert len(paths) == len(set(paths)) == 5
pins_before = {str(p): record(p) for p in (CONFIG, MAP, CAT)}
selected = {name: mapping['files'][name] for name in paths}
request = ''.join(selected[name]['git_blob'] + '\n' for name in paths).encode()
command = ['git', '--no-optional-locks', '-c', 'core.fsmonitor=false', 'cat-file', '--batch']
started = datetime.datetime.now(datetime.UTC).isoformat()
clock = time.monotonic()
child = subprocess.Popen(command, cwd=ROOT, env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
output, error = child.communicate(request)
assert child.returncode == 0 and not error
try:
    os.killpg(child.pid, 0)
except ProcessLookupError:
    group = 'ABSENT'
else:
    group = 'PRESENT'
assert group == 'ABSENT'
cursor = 0
bodies = {}
for name in paths:
    line_end = output.index(b'\n', cursor)
    oid, kind, count = output[cursor:line_end].decode().split()
    size = int(count)
    cursor = line_end + 1
    body = output[cursor:cursor + size]
    cursor += size
    assert output[cursor:cursor + 1] == b'\n'
    cursor += 1
    row = selected[name]
    assert kind == 'blob' and oid == row['git_blob']
    assert size == row['bytes'] and sha(body) == row['sha256']
    assert hashlib.sha1(b'blob ' + str(size).encode() + b'\0' + body).hexdigest() == oid
    target = OUT / 'fixed-source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(body)
    bodies[name] = {**row, 'copied_body': record(target)}
assert cursor == len(output)
retained = {}
for source, relative in [
    (CONFIG, 'retained/config.json'),
    (MAP, 'retained/immutable-source-map.json'),
    (CAT, 'retained/expected-catalog.json'),
    (E / 'next-head-ci-collector-preparation/v2/collect-next-head.py', 'retained/collector-prepared.py'),
    (E / 'next-head-ci-collector-preparation/v2/SOURCE.json', 'retained/collector-preparation-SOURCE.json'),
    (E / 'next-head-ci-collector-preparation/v2/manifest.json', 'retained/collector-preparation-manifest.json'),
    (E / 'next-head-ci-collector-preparation/v2/SEAL.json', 'retained/collector-preparation-SEAL.json'),
]:
    before = record(source)
    target = OUT / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(source.read_bytes())
    after = record(source)
    assert before == after
    retained[relative] = {'source': before, 'copy': record(target)}
pins_after = {str(p): record(p) for p in (CONFIG, MAP, CAT)}
assert pins_before == pins_after
dump('fixed-source-preparation.json', {
    'source_commit': cfg['expected_source_commit'], 'source_tree': cfg['expected_source_tree'],
    'source_body_map_blob_count': mapping['blob_count'],
    'fixed_source_files': bodies, 'retained': retained,
    'input_pins_before': pins_before, 'input_pins_after': pins_after,
    'git_batch_custody': {'command': command, 'start_utc': started, 'end_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'elapsed_seconds': time.monotonic() - clock, 'pid': child.pid, 'pgid': child.pid, 'exit_code': child.returncode, 'reaped': True, 'group_after_wait': group, 'signals_sent': [], 'timeouts': []},
    'scope': 'Read-only fixed object reads. No current HEAD/PR-head requirement; no network/API/subject execution/canonical writes. Current CI collector remains active; no terminal verdict.'
})
print(json.dumps({'fixed_workflows': len(bodies), 'source_blobs': mapping['blob_count'], 'git_child': child.pid, 'exit': child.returncode, 'group': group, 'pins_equal': pins_before == pins_after}))
