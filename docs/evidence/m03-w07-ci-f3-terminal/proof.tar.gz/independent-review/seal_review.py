"""Seal original CI actual result, preserving raw originals and explicit archive duplicate map."""
from pathlib import Path
from datetime import datetime,UTC
import hashlib,json,stat,tarfile
H=Path(__file__).resolve().parent
excluded={'manifest.json','proof.tar.gz','SEAL.json','proof-selection.json'}
def info(p):
 st=p.lstat();assert stat.S_ISREG(st.st_mode) and not p.is_symlink();d=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):d.update(b)
 return {'bytes':st.st_size,'full_mode':st.st_mode,'sha256':d.hexdigest()}
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def load(p):return json.loads(p.read_bytes())
data=load(H/'data-review.json');package=load(H/'package-record-review.json');finding=load(H/'source-findings.json')
assert data['check_count']==14079 and data['all_data_checks_pass'] and all(r['pass'] for r in data['checks']) and package['result']['checks']==7728 and all(r['pass'] for r in package['checks']) and finding['verdict']=='CONFIRMED_ACTUAL_CI_VERIFY_PASS_PACKAGE_FAILURE'
assert data['three_platform_API_success'] and data['three_platform_complete_log_success'] and data['original_collector_failures']==[{'kind':'TERMINAL_JOB_FAILURE','run':40956683963,'job':123763607069,'name':'native development package (windows-2025)','conclusion':'failure'}]
ret=load(H/'collector-retention.json');assert ret['source_before']==ret['copy']==ret['source_after'] and ret['files']==1247 and ret['bytes']==1409686724
for n,r in ret['copy'].items():assert info(H/'raw-collector'/n)==r and info(Path(ret['source'])/n)==r
qa=[]
for p in sorted((H/'qa').glob('*/receipt.json')):
 r=load(p);assert r['reaped'] and r['exit_code']==0 and r['group_after_wait']=='ABSENT' and r['signals']==[] and r['timeouts']==[] and r['leased_inputs_equal'];qa.append({'path':str(p.relative_to(H)),'pid':r['pid']})
assert len(qa)==5
files={str(p.relative_to(H)):info(p) for p in sorted(H.rglob('*')) if p.is_file() and str(p.relative_to(H)) not in excluded}
selection=[];omissions=[]
text_suffixes={'.json','.jsonl','.log','.txt','.md','.stderr','.stdout','.py','.ps1','.sh','.rs','.sql','.toml','.lock','.yaml','.yml'}
for n,r in files.items():
 parts=Path(n).parts
 if len(parts)>=6 and parts[:2]==('raw-collector','artifacts') and parts[3]=='contents-attempt-1' and Path(n).suffix not in text_suffixes:
  archive='/'.join(parts[:3])+'/attempt-1.zip';member='/'.join(parts[4:]);assert archive in files
  omissions.append({'path':n,**r,'reconstruct_from_exact_zip':archive,'zip_member':member,'basis':'Original selected archive and extracted member were CRC/size/SHA256 joined by actual audit. Full original expanded outside copy remains immutable.'})
 else:selection.append(n)
dump(H/'proof-selection.json',{'included_regular_paths':selection+['proof-selection.json','manifest.json'],'expanded_archive_duplicate_omissions':omissions,'scope':'Omit only verified duplicate expanded nontext bodies from proof payload. All archive originals and raw text retained. Full outside manifest indexes every file; no artifact byte loss from retained ZIP representation.'})
files['proof-selection.json']=info(H/'proof-selection.json')
manifest={'schema_version':1,'file_count':len(files),'bytes':sum(r['bytes'] for r in files.values()),'files':files,'scope':'All outside review members except self/proof/seal. Proof payload selection and recoverable duplicate mappings explicit in proof-selection.json. All indexed files safe regular, bytes and full modes.'};dump(H/'manifest.json',manifest)
with tarfile.open(H/'proof.tar.gz','w:gz',compresslevel=1) as tar:
 for n in selection+['proof-selection.json','manifest.json']:tar.add(H/n,arcname=n,recursive=False)
with tarfile.open(H/'proof.tar.gz','r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(selection)+2
 for m in members:
  assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
  p=H/m.name;r=info(p);f=tar.extractfile(m);assert f is not None;d=hashlib.sha256();size=0
  while b:=f.read(1024*1024):d.update(b);size+=len(b)
  assert size==r['bytes'] and d.hexdigest()==r['sha256'] and m.mode==stat.S_IMODE(r['full_mode'])
seal={'utc':datetime.now(UTC).isoformat(),'verdict':finding['verdict'],'REVIEW':info(H/'REVIEW.md'),'DATA':info(H/'data-review.json'),'PACKAGE_DATA':info(H/'package-record-review.json'),'findings':info(H/'source-findings.json'),'manifest':info(H/'manifest.json'),'proof':info(H/'proof.tar.gz'),'indexed_regular_members':len(files),'proof_safe_regular_members':len(selection)+2,'proof_duplicate_bodies_omitted':len(omissions),'duplicate_bytes_omitted':sum(r['bytes'] for r in omissions),'own_closed_helpers':qa,'scope':'Originalf3 actual CI: three verification PASS; Ubuntu package success; Windows package FAILURE; no all-mainCI PASS, no later437/new29 qualification/nativeGUI/model/gate/release credit.'}
dump(H/'SEAL.json',seal);print(json.dumps(seal))
