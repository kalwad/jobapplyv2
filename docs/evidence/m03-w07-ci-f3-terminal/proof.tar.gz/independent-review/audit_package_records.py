"""Inert inner package proof/source joins; never opens or executes a native payload."""
from pathlib import Path,PurePosixPath
import hashlib,json,stat
H=Path(__file__).resolve().parent;A=H/'raw-collector/artifacts';mapping=json.loads((H/'retained/immutable-source-map.json').read_text());data=json.loads((H/'data-review.json').read_text());checks=[]
def ck(n,v):checks.append({'name':n,'pass':bool(v)});assert v,n
def load(p):return json.loads(p.read_bytes())
def sha(p):
 d=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):d.update(b)
 return d.hexdigest()
def safe(n):return bool(n and not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and '\\' not in n and PurePosixPath(n).as_posix()==n)
rows=[]
for aid,expected in (('12937691097','PACKAGE_PIPELINE_FUNCTION_RETURNED_GUI_UNOBSERVED'),('12938240486','PREPARATION_INCOMPLETE')):
 R=A/aid/'contents-attempt-1';manifest=load(R/'manifest.json');actual={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()};ck('selected artifact manifest exact inventory:'+aid,actual==set(manifest['files'])|{'manifest.json'})
 for n,r in manifest['files'].items():
  p=R/n;ck('inner retained body:'+aid+':'+n,safe(n) and p.is_file() and not p.is_symlink() and p.stat().st_size==r['bytes'] and sha(p)==r['sha256'])
 before=load(R/'worker/original-source-before.json');after=load(R/'worker/original-source-after.json');ck('worker original source endpoints:'+aid,before==after and before['head']==data['actual_tested_merge_commit'] and before['tree']==mapping['tree'] and set(before['files'])==set(mapping['files']))
 for n,r in before['files'].items():ck('worker source immutable body:'+aid+':'+n,r['bytes']==mapping['files'][n]['bytes'] and r['sha256']==mapping['files'][n]['sha256'])
 result=load(R/'worker/ci-result.json');ck('worker truthful scope:'+aid,result['status']==expected and result['original_source_bytes_and_modes_equal'] and result['original_source_clean'] and not result['gui_claim'] and not result['canonical_verification_waived'] and result['within_whole_cleanup_deadline'])
 rows.append({'artifact_id':aid,'manifest_files':len(manifest['files']),'source_files':len(before['files']),'worker_status':result['status'],'original_before_after_equal':True})
R=A/'12937890723/contents-attempt-1';export=load(R/'export.json');closure=load(R/'package-closure.json');ck('export precise no-GUI scope',export['scope']=='EXACT_EXISTING_INSPECTED_PACKAGE_EXPORT_NOT_GUI_EXECUTION' and not export['payload_executed'] and export['original_proof_preserved'] and export['expected_head']==data['actual_tested_merge_commit'] and export['build_git_binding']=={'head':data['actual_tested_merge_commit'],'tree':mapping['tree']})
ck('export exact source projection',set(export['shipping_source_projection'])==set(mapping['files']))
for n,d in export['shipping_source_projection'].items():ck('export immutable source body:'+n,d==mapping['files'][n]['sha256'])
for n,r in export['files'].items():
 p=R/n;ck('export retained member:'+n,safe(n) and p.is_file() and not p.is_symlink() and p.stat().st_size==r['bytes'] and sha(p)==r['sha256'] and stat.S_IMODE(p.stat().st_mode)==r['mode'])
ck('export package identity and unexecuted scope',sha(R/'package.deb')==sha(A/'12937691097/contents-attempt-1/packages/Desktop App_0.0.1_amd64.deb')=='6cd30c0c52ae59db39977aed2731ff8e9f7ba6c8a28571f84a9d83c95f163306' and (R/'package.deb').stat().st_size==85566554 and not closure['native_platform_certified'] and not closure['installed_package_evidence'] and not closure['windows_installer_produced'])
W=A/'12938240486/contents-attempt-1';command=load(W/'pipeline/10-tauri-package.result.json');ck('actual Windows command false success preserved',command['exit_code']==0 and not command['success'] and command['failure'] is None and command['cleanup_error'] is None and command['native_launch_failure'] is None and command['capture']['overflow'] is False and command['capture']['readers_closed'] and command['containment']['direct_exit']==0 and command['containment']['job_active_processes']==0 and command['containment']['all_job_members_closed'] and command['containment']['terminated_job'])
ck('actual compiler positive does not waive command failure','Built application at:' in (W/'pipeline/10-tauri-package.stderr').read_text() and load(W/'worker/pipeline.result.json')['returned'] is False)
result={'checks':len(checks),'all_pass':True,'worker_artifacts':rows,'linux_export_bytes':85566554,'linux_export_sha256':'6cd30c0c52ae59db39977aed2731ff8e9f7ba6c8a28571f84a9d83c95f163306','Windows_build_command_exit':0,'Windows_build_command_recorded_success':False,'source_cause_assigned':False,'scope':'Existing retained manifest/source/export and Windows failure-record consistency only. No new native/deb parsing/install/execution, GUI claim or model/platform qualification.'}
(H/'package-record-review.json').write_text(json.dumps({'result':result,'checks':checks},indent=2)+'\n');print(json.dumps(result))
