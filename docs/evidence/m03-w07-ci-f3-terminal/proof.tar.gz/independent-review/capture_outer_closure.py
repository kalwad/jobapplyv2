"""Capture the existing outer observer only after its recorded child closure."""
from pathlib import Path
import hashlib,json,stat
H=Path(__file__).resolve().parent
O=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/ci-f3a1c6f-root-observer')
assert (O/'receipt.json').is_file(), 'Actual outer closure required'
rows=[]
for name in ('executed-observer.py','started.json','receipt.json','stdout','stderr'):
 p=O/name;s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink();b=p.read_bytes()
 q=H/'retained/outer-observer'/name
 if q.exists():assert q.read_bytes()==b and q.lstat().st_mode==s.st_mode
 else:q.write_bytes(b);q.chmod(stat.S_IMODE(s.st_mode))
 assert p.read_bytes()==b and p.lstat().st_mode==s.st_mode
 rows.append({'path':str(q.relative_to(H)),'origin':str(p),'bytes':len(b),'full_mode':s.st_mode,'sha256':hashlib.sha256(b).hexdigest()})
(H/'outer-observer-closure-pins.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'closed_outer_records':len(rows),'body_mode_endpoints_equal':True}))
