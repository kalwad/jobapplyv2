from pathlib import Path
import hashlib,json,re,subprocess,tarfile
r=Path('/Users/tanishkalwad/jobapplyv2');out=Path('/tmp/japp-m03-w02-clean-verification-retry-20261018');review=Path('/tmp/japp-m03-w02-independent-security-dependency-review-20261018/full-data-review');d=r/'docs/evidence/m03-w02-service'
closure=json.loads((out/'closure.json').read_text());assert all(closure[k] for k in ('source_unchanged','all_executed_commands_pass','both_commands_executed'))
commands=json.loads((out/'commands.json').read_text());assert len(commands)==2 and all(c['exit_code']==0 for c in commands)
assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=r)==b''
before=json.loads((out/'before.json').read_text());head=before['head'];tree=before['tree'];assert head=='aa7e4e3bb92faf21e23f6bfe01f05d4dbf8c5044';assert tree=='4770ca1bf59d043c0a0ca8084a73ab878a65163d'
raw=(out/'verify.log').read_text();summary=raw.split('== verification summary ==')[-1];passing=re.findall(r'^([a-z0-9-]+)\s+ACTIVE\s+PASS\b',summary,re.M);assert len(passing)==20 and '1627 passed' in raw
findings=json.loads((review/'findings.json').read_text());assert findings.get('recommendation')=='PASS_SOURCE_BOUND_W02_FULL_DATA';assert not findings.get('blocking_findings',[])
inputs=[p for base in (out,review,Path("/tmp/japp-m03-w02-retry-precondition-rejected-20261018")) for p in sorted(base.rglob('*')) if p.is_file() and not p.is_symlink()];manifest=[]
with tarfile.open(d/'clean-verification-proof.tar.gz','w:gz') as t:
 for p in inputs:
  name=str(p.relative_to('/tmp'));data=p.read_bytes();manifest.append({'member':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});t.add(p,arcname=name,recursive=False)
data=(d/'clean-verification-proof.tar.gz').read_bytes();sha=hashlib.sha256(data).hexdigest();(d/'clean-verification-manifest.json').write_text(json.dumps({'sha256':sha,'bytes':len(data),'inputs':manifest},indent=2)+'\n');(d/'clean-verification-summary.json').write_text(json.dumps({'source_commit':head,'source_tree':tree,'commands':commands,'closure':closure,'active_suites':passing,'independent_findings_sha256':hashlib.sha256((review/'findings.json').read_bytes()).hexdigest(),'scope':'ordinary default W02 complete validation; no new Gate A target20 campaign, native client or platform package certification'},indent=2)+'\n')
p=r/'docs/traceability.json';x=json.loads(p.read_text())
for q in x['work_packages']:
 if q['id']=='M03-W02':assert q['current_state']=='IN_PROGRESS';q.update(current_state='VERIFIED',verified_revision='tree '+tree,current_evidence=[{'path':'docs/TEST_EVIDENCE.md','heading':'### M03-W02'}])
 elif q['id']=='M03-W03':assert q['current_state']=='NOT_STARTED';q.update(current_state='IN_PROGRESS')
p.write_text(json.dumps(x,indent=2)+'\n')
p=r/'docs/PROJECT_STATUS.md';s=p.read_text().replace('Repository revision: M03-W01 VERIFIED at dbdf3c7; M03-W02 IN_PROGRESS; M02 ACCEPTED / Gate A PASS','Repository revision: M03-W02 VERIFIED at '+head[:7]+'; M03-W03 IN_PROGRESS; M02 ACCEPTED / Gate A PASS').replace('Current work package: M03-W02','Current work package: M03-W03',1)
a=s.index('## Active work\n');b=s.index('\n## Milestone table',a);s=s[:a]+'''## Active work

- State: M03-W03 is the sole IN_PROGRESS package; 35/300 packages VERIFIED. M00/M01/M02 remain ACCEPTED; Gate A remains PASS. M03 remains IN_PROGRESS; release NOT_READY.
- Completed prerequisite: authenticated service skeleton M03-W02 VERIFIED at tree '''+tree+''' after actual strict doctor28/all20 ACTIVE PASS, exact1627 Python inventory and independent source/focused/wheel/full-data review. W01 accessible shell remains VERIFIED; initial baseline remains CAPTURED/NOT_APPROVED.
- Objective: real Tauri-owned random loopback port, fresh ephemeral credential/instance/generation, trusted native service executable, private readiness ACK, nonblocking diagnostics authority and bounded normal/forced lifecycle cleanup. Authenticated desktop API and restart are following packages.
- Execution: continue all eligible work without routine approval prompts under OD-035–037. Required measured evidence, independent reviews, numerical/safety limits and precise ADR-0006/0007 waivers remain binding. No native cross-platform certification is implied.
'''+s[b:]
s,n=re.subn(r'^(\| `M03-W02` \| )IN_PROGRESS \| — \| [^\n|]* \|',r'\g<1>VERIFIED | tree '+tree+' | docs/TEST_EVIDENCE.md § M03-W02 |',s,flags=re.M);assert n==1
s=s.replace('| `M03-W03` | NOT_STARTED |','| `M03-W03` | IN_PROGRESS |',1).replace('- Reason: M03-W02 is IN_PROGRESS after verified M03-W01. Continue implementation and validation without routine approval stops under OD-037 / ADR-0008.','- Reason: M03-W03 is IN_PROGRESS after verified M03-W02. Continue implementation and validation without routine approval stops under OD-037 / ADR-0008.');p.write_text(s)
p=r/'docs/TEST_EVIDENCE.md';s=p.read_text();entry=f'''### M03-W02 — Verified authenticated service; M03-W03 continuation (2026-10-18)

- Revision: tree {tree}, commit {head}. Strict pnpm run doctor28PASS and pnpm verify all20 ACTIVE PASS with both exits0 and exact clean source/HEAD/tree/tracked bytes unchanged. Commands/timings/raw results and independent source-bound full-data PASS are retained in docs/evidence/m03-w02-service/clean-verification-summary.json and clean-verification-proof.tar.gz SHA256{sha}/{len(data)}bytes/{len(manifest)}safe regular files, exhaustive adjacent manifest.
- Actual full counts:3937TS/15packages,256default browser,2controlled inspection+62contact,3visual and1627Python (1625common+same2POSIX). This ordinary default verification supplies no new accepted Gate A target20 campaign, production ATS, packaged platform/native client or final visual certification. Previous accepted95f5 evidence remains separate and immutable.
- Independent source22/22, focused/wheel18/18 and full-data reviews pass; every reviewed old lock pin/schema/test identity remains preserved. Real service APIs authenticate before routing, bind literal loopback only, use canonical payload/errors, disable all five ambient telemetry switches, and start/stop through bounded private pipes. Root canonical wheels also pass actual empty-cwd/environment import/ACK/authready/EOF proof. No database/model readiness is invented.
- Decision: /root records W02 VERIFIED under OD-037 / ADR-0008 only after the actual required results/reviews above. REQ-PLAT-003 remains SCAFFOLD_ONLY/NOT_YET_APPLICABLE with W04/native remainder explicit. W03 starts immediately; M03 and release remain unfinished. No routine owner approval prompt.

### M03-W03 — Native sidecar lifecycle start (2026-10-18)

- State: IN_PROGRESS after verified W01/W02 and accepted M00/M01/M02/Gate A PASS. No W03 or platform PASS is supplied by this start.
- Scope: actual Tauri builder/run lifecycle, trusted compile-bound service runtime, random loopback port and fresh private token/instance/generation, private readiness ACK before authority, finite cancellation/normal/forced cleanup, nonblocking native command-side authority inspection and safe diagnostics. Preserve all navigation/CSP/ACL and shared UI foundations.
- Acceptance: meaningful unit/negative/ownership tests, actual exact-root standalone and Tauri app actors with retained source/executed binaries/observers, independent review and clean full verification. Outside proposal/discovery evidence retains its failures and narrower artifact/timing scope; final exact-root proof is required. W04 authenticated client, W05 restart and W06–W10 platform packaging/certification remain their owning work.

''';s=s.replace('## Entries\n','## Entries\n\n'+entry,1);p.write_text(s)
p=r/'docs/KNOWN_ISSUES.md';s=p.read_text();needle='## M03-W01 corrected native boundary (2026-10-18)';assert needle in s
entry='''## M03-W02 corrected dependency privacy default (2026-10-18)

### KI-0102 — Framework telemetry defaults could observe sensitive synthetic input

- Severity: HIGH
- State: FIXED
- Discovered: 2026-10-18 during outside M03-W02 dependency/API review
- Affects: M03-W02; local service privacy boundary
- Description: FastAPI0.146.0 core telemetry defaults could acquire ambient providers and observe exception/validation input. The insecure proposal was never accepted or used with real user data.
- Reproduction: retained configuration RED observes an enabled switch before any sensitive capture assertion; later hostile-provider factory regression exercises actual construction, requests, validation and exception paths.
- Workaround: none used; no provider/SDK/exporter success is inferred.
- Resolution + evidence link: all five switches (tracing, metrics, logs, operation_spans, auto_configure) explicitly false; focused/socket/wheel/clean full tests and independent review PASS; docs/TEST_EVIDENCE.md § M03-W02 and docs/evidence/m03-w02-service.

''';assert '### KI-0102' not in s;p.write_text(s.replace(needle,entry+needle,1))
p=r/'docs/COMPATIBILITY_MATRIX.md';s=p.read_text();needle='## Initial desktop shell observation — 2026-10-18';assert needle in s
entry=f'''## Local service skeleton observation — 2026-10-18

M03-W02 is VERIFIED at tree {tree}; M03 remains IN_PROGRESS. Actual macOS arm64/Python3.12.13 executes authenticated versioned loopback health/readiness/version, canonical errors, private bootstrap/ACK, startup/collision/EOF negatives and an empty-environment/cwd canonical wheel-only lifecycle. Source-bound strict doctor28/full20-suite verification and independent reviews are retained in docs/evidence/m03-w02-service and docs/TEST_EVIDENCE.md § M03-W02. Windows/Linux runtime and packaged Tauri lifecycle, W04 native client, final cross-platform certification and production ATS support are not supplied by this scoped service observation. Accepted Gate A evidence remains separately evaluated95f5.

''';p.write_text(s.replace(needle,entry+needle,1))
print(json.dumps({'verified_commit':head,'tree':tree,'packsha':sha,'next':'M03-W03 IN_PROGRESS','verified_packages':35}))
