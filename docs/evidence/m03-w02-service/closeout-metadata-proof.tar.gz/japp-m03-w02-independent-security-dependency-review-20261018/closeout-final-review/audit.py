"""Read-only documentary/source/hash audit. Does not import or execute project code."""
import collections
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import tarfile

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
OUT = Path(__file__).parent
BASE = 'aa7e4e3bb92faf21e23f6bfe01f05d4dbf8c5044'
TREE = '4770ca1bf59d043c0a0ca8084a73ab878a65163d'
DOCS = {
    'docs/COMPATIBILITY_MATRIX.md', 'docs/KNOWN_ISSUES.md',
    'docs/PROJECT_STATUS.md', 'docs/REQUIREMENTS_TRACEABILITY.md',
    'docs/TEST_EVIDENCE.md', 'docs/traceability.json',
}
NEW = {'docs/evidence/m03-w02-service/clean-verification-' + s for s in
       ['manifest.json', 'proof.tar.gz', 'summary.json']}
checks = []
inputs = []

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def check(name, ok, detail):
    checks.append({'name': name, 'pass': bool(ok), 'detail': detail})
    assert ok, name

def preserve(path, relative):
    data = path.read_bytes()
    target = OUT / 'inputs' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    inputs.append({'path': str(path), 'retained_as': str(target.relative_to(OUT)),
                   'bytes': len(data), 'sha256': sha(data)})
    return data

head_before = git('rev-parse', 'HEAD').decode().strip()
tree_before = git('rev-parse', 'HEAD^{tree}').decode().strip()
status_before = git('status', '--porcelain=v1', '-z')
check('validated_identity', head_before == BASE and tree_before == TREE,
      {'head': head_before, 'tree': tree_before})
changed = set(git('diff', '--name-only', BASE).decode().splitlines())
untracked = set(git('ls-files', '--others', '--exclude-standard').decode().splitlines())
check('exact_documentary_delta', changed == DOCS and untracked == NEW,
      {'tracked_changed': sorted(changed), 'untracked': sorted(untracked)})

inventory = []
for row in git('ls-tree', '-r', '-z', BASE).split(b'\0'):
    if not row:
        continue
    meta, raw_path = row.split(b'\t', 1)
    mode, typ, oid = meta.decode().split()
    path = raw_path.decode()
    assert typ == 'blob'
    data = os.readlink(ROOT / path).encode() if mode == '120000' else (ROOT / path).read_bytes()
    actual_oid = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    inventory.append({'path': path, 'mode': mode, 'base_blob': oid,
                      'current_blob': actual_oid, 'current_sha256': sha(data),
                      'bytes': len(data), 'changed': actual_oid != oid})
tracked = set(git('ls-files', '-z').decode().rstrip('\0').split('\0'))
check('all_tracked_source_preserved', len(inventory) == 1768
      and tracked == {x['path'] for x in inventory}
      and {x['path'] for x in inventory if x['changed']} == DOCS,
      {'tracked': len(inventory), 'unchanged': len(inventory) - len(DOCS),
       'includes': 'all runtime, tests, validators, inventory, dependency locks, spec, ADRs, sealed Gate A and existing evidence'})
(OUT / 'tracked-source-comparison.json').write_text(json.dumps(inventory, indent=2) + '\n')
for path in sorted(DOCS | NEW):
    preserve(ROOT / path, 'root/' + path)

old_trace = json.loads(git('show', BASE + ':docs/traceability.json'))
trace = json.loads((ROOT / 'docs/traceability.json').read_text())
expected_trace = json.loads(json.dumps(old_trace))
by_id = {x['id']: x for x in expected_trace['work_packages']}
by_id['M03-W02']['current_state'] = 'VERIFIED'
by_id['M03-W02']['verified_revision'] = 'tree ' + TREE
by_id['M03-W02']['current_evidence'] = [{'path': 'docs/TEST_EVIDENCE.md', 'heading': '### M03-W02'}]
by_id['M03-W03']['current_state'] = 'IN_PROGRESS'
check('trace_exact_state_projection_only', trace == expected_trace,
      'Only W02 current_state/revision/evidence and W03 current_state change; all requirements/review/history/ownership/dependencies/gates unchanged.')
plat = next(x for x in trace['requirements'] if x['id'] == 'REQ-PLAT-003')
check('platform_requirement_remains_partial', plat['implementation_state'] == 'SCAFFOLD_ONLY'
      and plat['verification_state'] == 'NOT_YET_APPLICABLE'
      and 'M03-W04 native authenticated client' in plat['notes'], plat)
counts = collections.Counter(x['current_state'] for x in trace['work_packages'])
check('package_state_coherence', counts == {'VERIFIED': 35, 'IN_PROGRESS': 1, 'NOT_STARTED': 264}
      and next(x['id'] for x in trace['work_packages'] if x['current_state'] == 'IN_PROGRESS') == 'M03-W03', dict(counts))
status = (ROOT / 'docs/PROJECT_STATUS.md').read_text()
package_rows = re.findall(r'^\| `(M\d\d-W\d\d)` \| ([A-Z_]+) \| ([^|]+) \|', status, re.M)
check('status_matches_trace', len(package_rows) == 300
      and all(next(x for x in trace['work_packages'] if x['id'] == p)['current_state'] == state
              and next(x for x in trace['work_packages'] if x['id'] == p)['verified_revision'] == rev.strip()
              for p, state, rev in package_rows), 'All 300 package states/revisions agree.')
check('milestone_and_release_unfinished', 'Current work package: M03-W03' in status
      and 'Overall release gate: NOT_READY' in status
      and '| M03 | IN_PROGRESS | — |' in status
      and all('| ' + m + ' | ACCEPTED |' in status for m in ['M00', 'M01', 'M02'])
      and '| AUTOFILL_FEASIBILITY | PASS |' in status
      and 'initial baseline remains CAPTURED/NOT_APPROVED' in status,
      'M03 IP; release NOT_READY; accepted predecessors/Gate A and baseline scope retained.')

evidence_path = ROOT / 'docs/evidence/m03-w02-service'
manifest = json.loads((evidence_path / 'clean-verification-manifest.json').read_text())
archive = evidence_path / 'clean-verification-proof.tar.gz'
check('archive_identity', archive.stat().st_size == manifest['bytes'] == 887356
      and sha(archive.read_bytes()) == manifest['sha256'] == '931a922d4030921730e3dd38377cff161da6fb5c46a4d4680b4b932986801b5c',
      {'sha256': manifest['sha256'], 'bytes': manifest['bytes']})
archive_checks = []
with tarfile.open(archive, 'r:gz') as tf:
    members = tf.getmembers()
    recorded = {x['member']: x for x in manifest['inputs']}
    check('archive_safe_exhaustive_inventory', len(members) == len(recorded) == len(manifest['inputs']) == 34
          and set(x.name for x in members) == set(recorded)
          and all(x.isfile() and not PurePosixPath(x.name).is_absolute()
                  and '..' not in PurePosixPath(x.name).parts for x in members), '34 unique safe regular files, exact manifest.')
    for member in members:
        data = tf.extractfile(member).read()
        row = recorded[member.name]
        original = Path('/tmp') / member.name
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
        assert original.is_file() and original.read_bytes() == data
        archive_checks.append({'member': member.name, 'bytes': len(data), 'sha256': sha(data), 'original_bytes_match': True})
check('archive_every_member_matches_reviewed_raw_source', True, archive_checks)
summary = json.loads((evidence_path / 'clean-verification-summary.json').read_text())
run = Path('/tmp/japp-m03-w02-clean-verification-retry-20261018')
full = Path('/tmp/japp-m03-w02-independent-security-dependency-review-20261018/full-data-review')
full_findings = json.loads((full / 'findings.json').read_text())
check('summary_exact_actual_full_binding', summary['source_commit'] == BASE
      and summary['source_tree'] == TREE
      and summary['commands'] == json.loads((run / 'commands.json').read_text())
      and summary['closure'] == json.loads((run / 'closure.json').read_text())
      and summary['independent_findings_sha256'] == sha((full / 'findings.json').read_bytes())
      == 'b8281070fd646743cf6fb82d738d479fb3c71fe5a86c9b188b90a6e1e7d7bdda'
      and full_findings['recommendation'] == 'PASS_SOURCE_BOUND_W02_FULL_DATA'
      and len(summary['active_suites']) == 20
      and all(x['exit_code'] == 0 for x in summary['commands'])
      and all(summary['closure'][k] is True for k in ['source_unchanged', 'all_executed_commands_pass', 'both_commands_executed']),
      summary)
old_evidence = git('show', BASE + ':docs/TEST_EVIDENCE.md').decode()
new_evidence = (ROOT / 'docs/TEST_EVIDENCE.md').read_text()
anchor = '### M03-W02 — Full-run fixture failure retained and corrected (2026-10-18)'
check('historical_test_evidence_exact', new_evidence[new_evidence.index(anchor):] == old_evidence[old_evidence.index(anchor):],
      'Prior failed full, fixture repair, focused/wheel and earlier entries preserved byte-for-byte.')
check('scoped_closeout_claims', '1627Python (1625common+same2POSIX)' in new_evidence
      and '34safe regular files' in new_evidence and 'W03 and release remain unfinished' in new_evidence.replace('M03 and release', 'W03 and release')
      and 'No W03 or platform PASS is supplied by this start.' in new_evidence
      and 'Outside proposal/discovery evidence retains its failures' in new_evidence,
      'Actual full scope and future/root/native/platform remainders explicitly distinguished.')
old_issues = git('show', BASE + ':docs/KNOWN_ISSUES.md').decode()
issues = (ROOT / 'docs/KNOWN_ISSUES.md').read_text()
insert_start = issues.index('## M03-W02 corrected dependency privacy default (2026-10-18)')
insert_end = issues.index('## M03-W01 corrected native boundary (2026-10-18)', insert_start)
check('known_issue_history_and_causal_wording', issues[:insert_start] + issues[insert_end:] == old_issues
      and 'defaults could observe sensitive synthetic input' in issues
      and 'configuration RED observes an enabled switch before any sensitive capture assertion' in issues,
      'KI0103/old issues unchanged; KI0102 accurately describes could-observe/configuration RED and later regression scope.')

log = Path('/tmp/japp-m03-w02-closeout-metadata-green-20261018.log')
data = preserve(log, 'metadata/pytest.log')
terminal = data.decode()
check('actual_closed_metadata_terminal', 'collected 333 items' in terminal
      and '333 passed in 98.61s' in terminal and not re.search(r'\b(?:FAILED|ERROR)\b', terminal),
      {'modules': ['scripts/tests/test_validate_status.py', 'scripts/tests/test_traceability.py', 'scripts/tests/test_v14_migration.py'],
       'result': '333 PASS 98.61s', 'exit': 'Root reports tool-observed session12880 CLOSED exit0 at19:51:16; raw terminal independently inspected.'})
check('inspection_source_stable', git('rev-parse', 'HEAD').decode().strip() == head_before
      and git('rev-parse', 'HEAD^{tree}').decode().strip() == tree_before
      and git('status', '--porcelain=v1', '-z') == status_before
      and all((ROOT / x['path']).is_symlink() if x['mode'] == '120000' else sha((ROOT / x['path']).read_bytes()) == x['current_sha256'] for x in inventory),
      'HEAD/tree/status and all tracked bytes unchanged during this read-only review.')
findings = {
    'kind': 'independent_w02_closeout_final_documentary_source_preservation_review',
    'recommendation': 'CLEAR_SOURCE_BOUND_W02_CLOSEOUT_METADATA',
    'blocking_findings': [], 'validated_source_commit': BASE, 'validated_source_tree': TREE,
    'checks': checks, 'inputs': inputs,
    'scope': 'Six-document W02 closeout plus three proof files; actual 333 metadata terminal and root-observed exit0; no new runtime actors/tests executed by reviewer.',
    'limits': [
        'Full source validation applies to immutable aa7e/tree4770; closeout has fresh focused metadata validation, not a second whole full run.',
        'Status45, trace generation/check and diff PASS are root-reported closed checks; reviewer did not rerun them.',
        'W03-W10 native lifecycle/client/restart/package/platform acceptance and M03/release completion remain pending.',
    ],
}
(OUT / 'findings.json').write_text(json.dumps(findings, indent=2) + '\n')
(OUT / 'REVIEW.md').write_text(
    '# Independent W02 closeout review\n\n'
    'CLEAR_SOURCE_BOUND_W02_CLOSEOUT_METADATA. No blocking findings.\n\n'
    'All 1,768 tracked paths were compared to immutable aa7e4e3/tree4770ca1. Only six intended documents differ; runtime, tests, validators, inventory, locks, canonical specification, ADRs, sealed Gate A and prior evidence remain unchanged. Trace changes only W02 state/revision/evidence and W03 state; 35/300 VERIFIED, W03 sole IN_PROGRESS, M03 IN_PROGRESS and release NOT_READY. REQ-PLAT-003 remains partial.\n\n'
    'The 887,356-byte archive 931a922d… has 34 unique safe regular members, all exactly matching the exhaustive manifest and original raw sources. Summary binds actual closed doctor/full results and independent b8281070… PASS. Prior failed campaign and evidence remain intact. KI0102 now uses accurate could-observe/configuration-RED wording.\n\n'
    'Actual metadata terminal: 333 PASS in 98.61s; root reports tool-observed session12880 exit0. Static status/trace/diff checks are root-reported, not rerun by reviewer. This is documentary closeout with focused metadata proof after the clean full aa7e validation; no W03/native/platform or release completion claim.\n'
)
print(json.dumps({'recommendation': findings['recommendation'], 'checks': len(checks),
                  'inputs': len(inputs), 'findings_sha256': sha((OUT / 'findings.json').read_bytes()),
                  'review_sha256': sha((OUT / 'REVIEW.md').read_bytes())}, indent=2))
