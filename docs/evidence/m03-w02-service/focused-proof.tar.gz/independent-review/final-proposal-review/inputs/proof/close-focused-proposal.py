from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path.cwd()
paths=['pyproject.toml','uv.lock','packages/contracts/pyproject.toml','services/orchestrator/pyproject.toml','services/orchestrator/README.md']
paths += [str(p) for p in sorted((root/'services/orchestrator/src/orchestrator').glob('*.py'))]
paths += [str(p) for p in sorted((root/'services/orchestrator/tests').glob('*.py'))]
paths += [str(p) for p in sorted((root/'packages/contracts/schemas/service').glob('*.json'))]
paths += [str(p) for p in sorted((root/'packages/contracts/generated/python/src/japp_contracts/service').glob('*.py'))]
paths=sorted({str((root/p).relative_to(root)) if not Path(p).is_absolute() else str(Path(p).relative_to(root)) for p in paths})
source={path:hashlib.sha256((root/path).read_bytes()).hexdigest() for path in paths}
record={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source':source,'commands':[]}
(root/'proof/closed-source-manifest.json').write_text(json.dumps(record,indent=2)+'\n')
commands=[
 ('prettier-final',['/opt/homebrew/opt/node@24/bin/node','node_modules/prettier/bin/prettier.cjs','--check','services/orchestrator/README.md','packages/contracts/schemas/service/health.v1.schema.json','packages/contracts/schemas/service/ready.v1.schema.json','packages/contracts/schemas/service/version.v1.schema.json'],root,None),
 ('lock-final',['uv','lock','--check'],root,None),
 ('ruff-final',['uv','run','--locked','ruff','check','services/orchestrator/src','services/orchestrator/tests'],root,None),
 ('ruff-format-final',['uv','run','--locked','ruff','format','--check','services/orchestrator/src','services/orchestrator/tests'],root,None),
 ('mypy-final',['uv','run','--locked','mypy','services/orchestrator/src','services/orchestrator/tests'],root,None),
 ('collection-final',['uv','run','--locked','pytest','services/orchestrator/tests','--collect-only','-q'],root,None),
 ('focused-final',['uv','run','--locked','pytest','services/orchestrator/tests','-q'],root,None),
 ('contracts-wheel-build',['uv','build','--package','japp-contracts','--wheel','--out-dir',str(root/'proof/wheels')],root,None),
 ('orchestrator-wheel-build',['uv','build','--package','orchestrator','--wheel','--out-dir',str(root/'proof/wheels')],root,None),
 ('wheel-package-install',['uv','pip','install','--python',str(root/'proof/wheel-venv/bin/python'),'--reinstall','--no-deps',str(root/'proof/wheels/japp_contracts-0.0.1-py3-none-any.whl'),str(root/'proof/wheels/orchestrator-0.0.1-py3-none-any.whl')],root,None),
 ('wheel-only-runtime',[str(root/'proof/wheel-venv/bin/python'),str(root/'proof/wheel-only-runtime.py')],root/'proof/wheel-run-cwd',{}),
]
for name,argv,cwd,env in commands:
 log=root/'proof'/f'{name}.log'
 with log.open('wb') as output:
  completed=subprocess.run(argv,cwd=cwd,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=90)
 entry={'name':name,'argv':argv,'cwd':str(cwd),'clean_environment':env=={},'exit_code':completed.returncode,'log':str(log.relative_to(root)),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 record['commands'].append(entry)
 (root/'proof/closed-source-manifest.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({'command':name,'exit_code':completed.returncode}),flush=True)
 if completed.returncode:
  sys.exit(completed.returncode)
assert source=={path:hashlib.sha256((root/path).read_bytes()).hexdigest() for path in paths}
original=json.loads((root/'proof/original-generated-files.json').read_text())
for entry in original:
 assert hashlib.sha256((root/entry['path']).read_bytes()).hexdigest()==entry['sha256'],entry['path']
ids=[line for line in (root/'proof/collection-final.log').read_text().splitlines() if line.startswith('services/') and '::' in line]
old=[i for i in ids if i.startswith('services/orchestrator/tests/test_package.py::')]
new=[i for i in ids if i not in old]
assert len(ids)==95 and len(old)==1 and len(new)==94
(root/'proof/new-test-identities.json').write_text(json.dumps(new,indent=2)+'\n')
(root/'proof/all-service-test-identities.json').write_text(json.dumps(ids,indent=2)+'\n')
record['status']='PASS'
record['tests']={'collected':len(ids),'new':len(new),'preserved':old}
record['original_generated_files_preserved']=len(original)
record['source_unchanged_during_verification']=True
record['wheel_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'proof/wheels').glob('*.whl'))}
(root/'proof/closed-source-manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':'PASS','tests':record['tests'],'preserved_generated':len(original)}),flush=True)
