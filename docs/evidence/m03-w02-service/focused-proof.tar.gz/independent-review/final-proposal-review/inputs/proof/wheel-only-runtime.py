import importlib.metadata
import json
import os
from pathlib import Path
import queue
import secrets
import struct
import subprocess
import sys
import threading
from http.client import HTTPConnection

import orchestrator
import japp_contracts
from japp_contracts.common.envelope_v1 import CommonEnvelopeV1EnvelopedRecord
from japp_contracts.service.ready_v1 import ServiceReadyV1

root = Path(sys.prefix).resolve()
for package in (orchestrator, japp_contracts):
    assert Path(package.__file__).resolve().is_relative_to(root)
assert importlib.metadata.version("orchestrator") == "0.0.1"
assert importlib.metadata.version("japp-contracts") == "0.0.1"
assert "PYTHONPATH" not in os.environ

def read(stream, length):
    result = queue.Queue(maxsize=1)
    threading.Thread(target=lambda: result.put(stream.read(length)), daemon=True).start()
    value = result.get(timeout=8)
    assert len(value) == length
    return value

token = secrets.token_hex(32)
instance = "svc_00000000000000000000000001"
config = {"protocol":"JAPP_SERVICE_BOOTSTRAP_V1", "schema_version":"1.0.0", "bind_host":"127.0.0.1", "bind_port":0, "session_token":token, "instance_id":instance, "generation":9}
encoded = json.dumps(config).encode()
process = subprocess.Popen([sys.executable,"-m","orchestrator"], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env={})
try:
    process.stdin.write(struct.pack(">I",len(encoded))+encoded)
    process.stdin.flush()
    size = struct.unpack(">I",read(process.stdout,4))[0]
    assert 0 < size <= 4096
    ack = json.loads(read(process.stdout,size))
    assert ack["status"] == "READY" and ack["instance_id"] == instance and ack["generation"] == 9
    assert token not in json.dumps(ack)
    connection = HTTPConnection("127.0.0.1",ack["bind_port"],timeout=3)
    try:
        connection.request("GET","/api/v1/ready",headers={"Authorization":"Bearer "+token})
        response = connection.getresponse()
        assert response.status == 200
        envelope = CommonEnvelopeV1EnvelopedRecord.model_validate_json(response.read())
        record = ServiceReadyV1.model_validate(envelope.payload)
        assert record.status == "READY" and record.instance_id == instance and record.generation == 9
    finally:
        connection.close()
    process.stdin.close()
    assert process.wait(timeout=8) == 0
    assert process.stdout.read() == b""
    assert process.stderr.read() == b""
finally:
    if process.poll() is None:
        process.kill()
    process.wait(timeout=5)
    for stream in (process.stdin,process.stdout,process.stderr):
        stream.close()
print(json.dumps({"status":"PASS","interpreter":sys.executable,"orchestrator":orchestrator.__file__,"contracts":japp_contracts.__file__,"checks":["wheel-only imports outside checkout","distribution metadata","private ACK identity","authenticated canonical ready","EOF exit0","no extra stdout or stderr"]},indent=2))
