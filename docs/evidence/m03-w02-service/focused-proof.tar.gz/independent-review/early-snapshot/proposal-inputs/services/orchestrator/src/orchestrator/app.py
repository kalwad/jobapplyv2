"""Temporary unprotected in-process baseline for test-first boundary evidence."""

from collections.abc import Mapping

from fastapi import FastAPI


def create_app(configuration: Mapping[str, object], **kwargs: object) -> FastAPI:
    app = FastAPI()

    @app.get("/api/v1/health")
    def health() -> dict[str, str]:
        return {"status": "LIVE"}

    @app.get("/api/v1/ready")
    def ready() -> dict[str, str]:
        return {"status": "READY"}

    @app.get("/api/v1/version")
    def version() -> dict[str, str]:
        return {"service_version": "0.0.1"}

    return app
