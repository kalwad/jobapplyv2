from pathlib import Path
import hashlib,json,os,subprocess,sys,time
r=Path('/Users/tanishkalwad/jobapplyv2');d=Path(__file__).parent;sys.path.insert(0,str(r/'scripts'));import verify
relatives=tuple(sorted({str(p.relative_to(r)) for pattern in verify.PY_TEST_FILE_GLOBS for p in r.glob(pattern)}))
argv=verify._canonical_pytest_command(relatives,collect_only=True);env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@24/bin:'+env['PATH'];t=time.monotonic();p=subprocess.run(argv,cwd=r,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90);(d/'collection.log').write_bytes(p.stdout);assert p.returncode==0
ids,error=verify._parse_pytest_collection_output(p.stdout.decode(),relatives);assert error is None,error;assert ids is not None
old=json.loads((r/'scripts/python-test-inventory.v1.json').read_text());prior=set(old['common']['node_ids'])|set(old['posix_only_node_ids']);assert prior.issubset(ids)
new=sorted(set(ids)-prior);expected=json.loads(Path('/tmp/japp-m03-w02-service-proposal/proof/new-test-identities.json').read_text());assert new==sorted(expected),(len(new),len(expected));assert len(new)==94
common=sorted(set(ids)-set(old['posix_only_node_ids']));assert len(common)==1625 and len(ids)==1627
payload={**old,'common':{'count':len(common),'sha256':hashlib.sha256(('\n'.join(common)+'\n').encode()).hexdigest(),'node_ids':common}};(r/'scripts/python-test-inventory.v1.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
(d/'inventory-delta.json').write_text(json.dumps({'argv':list(argv),'cwd':str(r),'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-t,'collection_sha256':hashlib.sha256(p.stdout).hexdigest(),'preserved_common':len(old['common']['node_ids']),'same_posix_only':old['posix_only_node_ids'],'added_common':new,'actual_common_count':len(common),'actual_posix_count':len(ids),'exact_matches_reviewed_service_delta':True},indent=2)+'\n');print(json.dumps({'common':len(common),'posix':len(ids),'added':len(new),'all_original_ids_preserved':True}))
