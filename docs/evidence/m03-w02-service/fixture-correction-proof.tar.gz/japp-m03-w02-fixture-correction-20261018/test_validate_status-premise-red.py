"""Black-box tests for the v1.4-aware scripts/validate_status.py (M00-W11).

The validator is exercised exactly as production runs it (a subprocess with
``--repo``), against full temporary copies of the repository's project-memory
files. Positive cases prove the migrated repository passes; negative cases
prove every §12/§13.8-mandated rejection: invalid gate states, missing
platform packages/requirements, stale inventory, a second
canonical-looking specification, a missing Workday gate report, dropped
preserved revisions, gate-based readiness blocking for M03/M06/M21, and the
structural rules carried over from v1.2/v1.3 (enums, single IN_PROGRESS,
dependencies, completeness). M00-W11 adds exact migration/readiness checks,
the explicit M27-W13/W14/W12 graph, and fail-closed Gate D revision binding.
"""

from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import sys
from collections.abc import Callable, Iterator
from pathlib import Path

import pytest
import validate_status
from conftest import REPO_ROOT

VALIDATOR = REPO_ROOT / "scripts" / "validate_status.py"
GATES = (
    "AUTOFILL_FEASIBILITY",
    "RESUME_PAGEFIT_FEASIBILITY",
    "WORKDAY_GUIDED_PRE_SUBMIT",
    "CROSS_PLATFORM_CORE",
)
FAKE_TREE = "tree " + "0" * 40
OTHER_FAKE_TREE = "tree " + "1" * 40
GATE_D_EVIDENCE_REL = "docs/gates/evidence/SYNTHETIC_GATE_D_EVIDENCE.md"
FAKE_EVIDENCE_HASH = "sha256:" + "0" * 64
FAKE_REVIEWER = "clean-session fixture reviewer"
CORRECTIVE_BLOCKER_IDS = ("KI-0029", "KI-0030", "KI-0031")
CURRENT_M02_CORRECTIVE_ISSUE_IDS = (
    "KI-0039",
    "KI-0040",
    "KI-0041",
    "KI-0042",
    "KI-0043",
    "KI-0044",
    "KI-0045",
    "KI-0046",
    "KI-0047",
    "KI-0048",
    "KI-0049",
    "KI-0050",
    "KI-0051",
    "KI-0052",
    "KI-0053",
    "KI-0054",
    "KI-0055",
    "KI-0056",
    "KI-0057",
    "KI-0058",
    "KI-0059",
    "KI-0060",
    "KI-0061",
    "KI-0062",
)
CURRENT_M02_W14_CORRECTIVE_ISSUE_IDS = (
    "KI-0077",
    "KI-0078",
    "KI-0079",
    "KI-0080",
    "KI-0081",
    "KI-0082",
    "KI-0083",
    "KI-0084",
    "KI-0085",
    "KI-0086",
    "KI-0087",
    "KI-0088",
    "KI-0089",
    "KI-0090",
    "KI-0091",
    "KI-0092",
    "KI-0093",
    "KI-0094",
    "KI-0095",
    "KI-0096",
)
CURRENT_BLOCKER_LINES = [
    "- KI-0029 (HIGH, IN_PROGRESS) — governance contradiction",
    "- KI-0030 (HIGH, IN_PROGRESS) — semantic contradictions",
    "- KI-0031 (HIGH, IN_PROGRESS) — compatibility classification",
]
M02_W06_BLOCKER_LINES = [
    (
        "- KI-0055 (HIGH, IN_PROGRESS) — M02-W06 owner holdout verification lacked "
        "input-artifact preimage binding"
    ),
]


def run_validator(repo: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, str(VALIDATOR), "--repo", str(repo)],
        capture_output=True,
        text=True,
        check=False,
        timeout=120,
    )


@pytest.fixture
def repo_copy(tmp_path: Path) -> Iterator[Path]:
    """Full temporary copy of the project-memory surface of the real repo."""
    repo = tmp_path / "repo"
    repo.mkdir()
    try:
        shutil.copy2(REPO_ROOT / "CLAUDE.md", repo / "CLAUDE.md")
        shutil.copytree(REPO_ROOT / "docs", repo / "docs")
        platform_schemas = repo / "packages" / "contracts" / "schemas" / "platform"
        platform_schemas.mkdir(parents=True)
        for name in ("evidence-record", "certification-input"):
            shutil.copy2(
                REPO_ROOT
                / "packages"
                / "contracts"
                / "schemas"
                / "platform"
                / f"{name}.v2.schema.json",
                platform_schemas / f"{name}.v2.schema.json",
            )
        holdout_status = repo / "benchmarks" / "holdout-manifests"
        holdout_status.mkdir(parents=True)
        shutil.copy2(
            REPO_ROOT / holdout_status.relative_to(repo) / "status.v1.json",
            holdout_status / "status.v1.json",
        )
        yield repo
    finally:
        shutil.rmtree(repo)


def status_path(repo: Path) -> Path:
    return repo / "docs" / "PROJECT_STATUS.md"


def edit(path: Path, old: str, new: str, *, count: int = 0) -> None:
    text = path.read_text(encoding="utf-8")
    assert old in text, f"fixture edit target not found in {path.name}: {old!r}"
    path.write_text(text.replace(old, new, count or -1), encoding="utf-8")


def set_issue_state(repo: Path, issue_id: str, state: str) -> None:
    path = repo / "docs" / "KNOWN_ISSUES.md"
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(
        rf"(### {re.escape(issue_id)} —[^\n]+\n(?:.*\n)*?- State: )[A-Z_]+",
    )
    assert pattern.search(text), f"no known-issue section for {issue_id}"
    path.write_text(pattern.sub(rf"\g<1>{state}", text, count=1), encoding="utf-8")


def set_issue_severity(repo: Path, issue_id: str, severity: str) -> None:
    path = repo / "docs" / "KNOWN_ISSUES.md"
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(
        rf"(### {re.escape(issue_id)} —[^\n]+\n(?:\n)?- Severity: )[A-Z_]+",
    )
    assert pattern.search(text), f"no known-issue section for {issue_id}"
    path.write_text(pattern.sub(rf"\g<1>{severity}", text, count=1), encoding="utf-8")


def set_live_blockers(repo: Path, lines: list[str]) -> None:
    path = status_path(repo)
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(
        r"(## Known release blockers\n\n).*?(?=\n## )",
        flags=re.DOTALL,
    )
    assert pattern.search(text), "no live blocker section"
    replacement = r"\g<1>" + "\n".join(lines)
    path.write_text(pattern.sub(replacement, text, count=1), encoding="utf-8")


def resolve_corrective_issues(repo: Path) -> None:
    """Remove today's corrective blockers from historical future-state fixtures."""
    for issue_id in (
        *CORRECTIVE_BLOCKER_IDS,
        *CURRENT_M02_CORRECTIVE_ISSUE_IDS,
        *CURRENT_M02_W14_CORRECTIVE_ISSUE_IDS,
    ):
        set_issue_state(repo, issue_id, "FIXED")
    set_live_blockers(repo, ["- NONE"])


def resolve_w14_findings_before_historical_boundary(repo: Path) -> None:
    """Isolate historical fixtures from only the later W14 campaign findings."""
    for issue_id in CURRENT_M02_W14_CORRECTIVE_ISSUE_IDS:
        set_issue_state(repo, issue_id, "FIXED")
    text = status_path(repo).read_text(encoding="utf-8")
    section = re.search(
        r"## Known release blockers\n\n(.*?)(?=\n## )", text, flags=re.DOTALL
    )
    assert section is not None, "no live blocker section"
    retained = [
        line
        for line in section.group(1).splitlines()
        if line.strip()
        and not any(
            line.startswith(f"- {issue_id} (")
            for issue_id in CURRENT_M02_W14_CORRECTIVE_ISSUE_IDS
        )
    ]
    set_live_blockers(repo, retained or ["- NONE"])


def clear_in_progress(repo: Path) -> None:
    """Drop every IN_PROGRESS work-package row.

    The live repository always has at most one IN_PROGRESS package, but which
    one it is changes as milestones advance. A test whose premise is "no
    package is IN_PROGRESS" must therefore clear the state rather than name a
    package, or an inherited row diverts the validator to a different error
    (the KI-0014/KI-0015/KI-0017 class).
    """
    path = status_path(repo)
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(
        r"^(\| `M\d{2}-W\d{2}` \| )IN_PROGRESS( \|)", flags=re.MULTILINE
    )
    path.write_text(
        pattern.sub(r"\g<1>NOT_STARTED\g<2>", text),
        encoding="utf-8",
    )
    rewind_unstarted_ui_surfaces(repo)


def set_pkg_state(repo: Path, pid: str, state: str) -> None:
    path = status_path(repo)
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(rf"^(\| `{pid}` \| )[A-Z_]+( \|)", flags=re.MULTILINE)
    assert pattern.search(text), f"no work-package row for {pid}"
    path.write_text(pattern.sub(rf"\g<1>{state}\g<2>", text), encoding="utf-8")
    if state in {"NOT_STARTED", "READY"}:
        rewind_unstarted_ui_surfaces(repo)


def set_pkg_revision(repo: Path, pid: str, revision: str) -> None:
    path = status_path(repo)
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(
        rf"^(\| `{re.escape(pid)}` \| [A-Z_]+ \| )[^|]+(\|)",
        flags=re.MULTILINE,
    )
    assert pattern.search(text), f"no work-package row for {pid}"
    path.write_text(
        pattern.sub(rf"\g<1>{revision} \g<2>", text, count=1),
        encoding="utf-8",
    )


def set_ms_state(repo: Path, mid: str, state: str) -> None:
    path = status_path(repo)
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(rf"^(\| {mid} \| )[A-Z_]+( \|)", flags=re.MULTILINE)
    assert pattern.search(text), f"no milestone row for {mid}"
    path.write_text(pattern.sub(rf"\g<1>{state}\g<2>", text), encoding="utf-8")


def set_ms_revision(repo: Path, mid: str, revision: str) -> None:
    path = status_path(repo)
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(
        rf"^(\| {re.escape(mid)} \| [A-Z_]+ \| )[^|]+(\|)",
        flags=re.MULTILINE,
    )
    assert pattern.search(text), f"no milestone row for {mid}"
    path.write_text(
        pattern.sub(rf"\g<1>{revision} \g<2>", text, count=1),
        encoding="utf-8",
    )


def set_current_package(repo: Path, value: str) -> None:
    path = status_path(repo)
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(r"^Current work package: .*$", flags=re.MULTILINE)
    assert pattern.search(text)
    path.write_text(
        pattern.sub(f"Current work package: {value}", text, count=1),
        encoding="utf-8",
    )
    match = re.fullmatch(r"M\d{2}-W\d{2}", value)
    if match:
        set_current_milestone(repo, value[:3])


def set_current_milestone(repo: Path, value: str) -> None:
    path = status_path(repo)
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(r"^Current milestone: .*$", flags=re.MULTILINE)
    assert pattern.search(text)
    path.write_text(
        pattern.sub(f"Current milestone: {value}", text, count=1),
        encoding="utf-8",
    )


def set_next_ready(repo: Path, value: str) -> None:
    path = status_path(repo)
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(r"^- ID: .*$", flags=re.MULTILINE)
    assert pattern.search(text)
    path.write_text(pattern.sub(f"- ID: {value}", text, count=1), encoding="utf-8")
    match = re.fullmatch(r"`?(M\d{2}-W\d{2})`?", value)
    if match:
        set_current_milestone(repo, match.group(1)[:3])


def update_m02_w06_holdout_status(
    repo: Path, changes: dict[str, object | None]
) -> None:
    path = repo / "benchmarks" / "holdout-manifests" / "status.v1.json"
    payload = json.loads(path.read_text(encoding="utf-8"))
    assert isinstance(payload, dict)
    for key, value in changes.items():
        if value is None:
            payload.pop(key, None)
        else:
            payload[key] = value
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def prepare_m02_w06_pre_governance(repo: Path) -> None:
    """Build the valid pending fixture from either side of W06 governance."""
    for issue_id in ("KI-0058", "KI-0059", "KI-0060", "KI-0061", "KI-0062"):
        set_issue_state(repo, issue_id, "FIXED")
    for issue_id in ("KI-0055", "KI-0056", "KI-0057"):
        set_issue_state(repo, issue_id, "IN_PROGRESS")
    set_live_blockers(repo, M02_W06_BLOCKER_LINES)
    reset_downstream(repo, after_package="M02-W07", after_milestone="M02")
    path = status_path(repo)
    text = path.read_text(encoding="utf-8")
    replacements = {
        "M02-W06": (
            "| `M02-W06` | IN_PROGRESS | — | — | "
            "synthetic pre-governance lifecycle fixture |"
        ),
        "M02-W07": (
            "| `M02-W07` | NOT_STARTED | — | — | "
            "synthetic pre-governance lifecycle fixture |"
        ),
    }
    for package_id, replacement in replacements.items():
        pattern = re.compile(
            rf"^\| `{re.escape(package_id)}` \|[^\n]*$", flags=re.MULTILINE
        )
        assert pattern.search(text), f"no work-package row for {package_id}"
        text = pattern.sub(replacement, text, count=1)
    path.write_text(text, encoding="utf-8")
    set_current_package(repo, "M02-W06")
    set_next_ready(repo, "NONE")
    update_m02_w06_holdout_status(
        repo,
        {
            "m02_w06_package_verification_state": (
                "PENDING_FINAL_INDEPENDENT_VERIFICATION"
            )
        },
    )


def prepare_m02_w06_future_governance(repo: Path) -> None:
    resolve_corrective_issues(repo)
    reset_downstream(repo, after_package="M02-W07", after_milestone="M02")
    promote(repo, "M02-W06")
    set_pkg_state(repo, "M02-W06", "VERIFIED")
    set_pkg_state(repo, "M02-W07", "READY")
    set_current_package(repo, "NONE")
    set_next_ready(repo, "`M02-W07`")
    update_m02_w06_holdout_status(
        repo,
        {
            "m02_w06_package_verification_state": (
                "FINAL_INDEPENDENT_VERIFICATION_CLEAR"
            )
        },
    )


def activate_corrective_blockers(repo: Path) -> None:
    """Build a coherent reopened M01 fixture independent of live closeout state."""
    resolve_corrective_issues(repo)
    for issue_id in CORRECTIVE_BLOCKER_IDS:
        set_issue_state(repo, issue_id, "IN_PROGRESS")
    set_live_blockers(repo, CURRENT_BLOCKER_LINES)
    clear_in_progress(repo)
    reset_downstream(repo, after_package="M01-W07", after_milestone="M01")
    set_pkg_state(repo, "M01-W07", "IN_PROGRESS")
    set_pkg_revision(repo, "M01-W07", "—")
    set_pkg_state(repo, "M02-W01", "NOT_STARTED")
    set_ms_state(repo, "M01", "IN_PROGRESS")
    set_ms_revision(repo, "M01", "—")
    set_ms_state(repo, "M02", "NOT_STARTED")
    set_ms_revision(repo, "M02", "—")
    set_current_package(repo, "M01-W07")
    set_next_ready(repo, "NONE")


def pkg_rows(repo: Path) -> list[str]:
    ids: list[str] = []
    for line in status_path(repo).read_text(encoding="utf-8").splitlines():
        match = re.match(r"^\| `(M\d{2}-W\d{2})` \|", line)
        if match:
            ids.append(match.group(1))
    return ids


def promote(repo: Path, pid: str) -> None:
    """Mark a package done with a synthetic revision and evidence entry.

    M00's acceptance contract is intentionally stricter than later
    milestones: all eleven direct packages must remain exactly VERIFIED.
    """
    if pid in validate_status.PRESERVED_PACKAGE_ANCHORS:
        return
    path = status_path(repo)
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(rf"^\| `{pid}` \|[^\n]*$", flags=re.MULTILINE)
    assert pattern.search(text), f"no work-package row for {pid}"
    state = "VERIFIED" if pid.startswith("M00-") or pid == "M02-W06" else "ACCEPTED"
    row = (
        f"| `{pid}` | {state} | {FAKE_TREE} | "
        f"docs/TEST_EVIDENCE.md § {pid} | promoted fixture |"
    )
    path.write_text(pattern.sub(row, text, count=1), encoding="utf-8")
    evidence = repo / "docs" / "TEST_EVIDENCE.md"
    with evidence.open("a", encoding="utf-8") as handle:
        handle.write(f"\n### {pid} — promoted fixture (synthetic)\n")
    if pid == "M02-W06":
        update_m02_w06_holdout_status(
            repo,
            {
                "m02_w06_package_verification_state": (
                    "FINAL_INDEPENDENT_VERIFICATION_CLEAR"
                )
            },
        )


def promote_milestones(repo: Path, mids: list[str]) -> None:
    if any(int(mid[1:]) >= 1 for mid in mids):
        resolve_corrective_issues(repo)
    for pid in pkg_rows(repo):
        if pid[:3] in mids:
            promote(repo, pid)
    for mid in mids:
        set_ms_state(repo, mid, "ACCEPTED")


def set_status_gate_row(
    repo: Path,
    gate: str,
    state: str,
    *,
    filled: bool = False,
    revision: str = FAKE_TREE,
) -> None:
    path = status_path(repo)
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(rf"^\| {gate} \|[^\n]*$", flags=re.MULTILINE)
    assert pattern.search(text), f"no critical-gates row for {gate}"
    if filled:
        row = (
            f"| {gate} | {state} | {revision} | {FAKE_EVIDENCE_HASH} | "
            f"{FAKE_REVIEWER} | docs/gates/{gate}_GATE.md |"
        )
    else:
        row = f"| {gate} | {state} | — | — | — | docs/gates/{gate}_GATE.md |"
    path.write_text(pattern.sub(row, text, count=1), encoding="utf-8")


def set_ledger_gate_state(repo: Path, gate: str, state: str) -> None:
    path = repo / "docs" / "CRITICAL_GATES.md"
    text = path.read_text(encoding="utf-8")
    sections = text.split("\n## ")
    for index, section in enumerate(sections):
        if section.startswith(gate):
            sections[index] = re.sub(
                r"^- State: [A-Z_]+$",
                f"- State: {state}",
                section,
                count=1,
                flags=re.MULTILINE,
            )
            break
    else:
        pytest.fail(f"no CRITICAL_GATES.md section for {gate}")
    path.write_text("\n## ".join(sections), encoding="utf-8")


def set_fixture_gate_state(repo: Path, gate: str, state: str) -> None:
    """Establish all three gate-state records for an isolated test premise."""
    set_status_gate_row(repo, gate, state)
    set_ledger_gate_state(repo, gate, state)
    report = repo / "docs" / "gates" / f"{gate}_GATE.md"
    text = report.read_text(encoding="utf-8")
    assert re.search(r"^(- State: )[A-Z_]+", text, flags=re.MULTILINE), (
        f"no gate report state for {gate}"
    )
    # The report is append-only and the last state is authoritative. Keep the
    # copied actual history, then declare this fixture's synthetic boundary.
    report.write_text(
        text + f"\n## Synthetic fixture boundary\n\n- State: {state}\n",
        encoding="utf-8",
    )


def set_ledger_gate_pass_evidence(
    repo: Path, gate: str, *, revision: str = FAKE_TREE
) -> None:
    path = repo / "docs" / "CRITICAL_GATES.md"
    text = path.read_text(encoding="utf-8")
    sections = text.split("\n## ")
    replacements = {
        "State": "PASS",
        "Evaluated revision": revision,
        "Corpus/holdout hash": FAKE_EVIDENCE_HASH,
        "Independent reviewer": FAKE_REVIEWER,
        "Owner decision": "PASS",
        "Holdout result": "PASS",
    }
    for index, section_text in enumerate(sections):
        if not section_text.startswith(gate):
            continue
        updated_section = section_text
        for label, value in replacements.items():
            updated_section, count = re.subn(
                rf"^- {re.escape(label)}:.*$",
                f"- {label}: {value}",
                updated_section,
                count=1,
                flags=re.MULTILINE,
            )
            assert count == 1, f"{gate} ledger has no {label} field"
        lines = updated_section.splitlines()
        in_metric_table = False
        for line_index, line in enumerate(lines):
            if line == "### Metric table" or line.startswith("### Metric table "):
                in_metric_table = True
                continue
            if line.startswith("- Zero-tolerance failures observed:"):
                in_metric_table = False
                lines[line_index] = "- Zero-tolerance failures observed: 0"
                continue
            if not in_metric_table or not line.startswith("|"):
                continue
            cells = [cell.strip() for cell in line.strip("|").split("|")]
            if (
                len(cells) >= 3
                and cells[0] != "Dimension"
                and not set(cells[0]) <= {"-", ":"}
            ):
                cells[-1] = "PASS"
                lines[line_index] = "| " + " | ".join(cells) + " |"
        sections[index] = "\n".join(lines)
        break
    else:
        pytest.fail(f"no CRITICAL_GATES.md section for {gate}")
    path.write_text("\n## ".join(sections), encoding="utf-8")


def _write_gate_d_evidence(repo: Path) -> None:
    path = repo / GATE_D_EVIDENCE_REL
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        """# Synthetic Gate D evidence

## Gate D evidence bundle

Fixture-only bundle.

## macos-arm64 full-AI profile

Fixture-only profile evidence.

## windows-x64 full-AI profile

Fixture-only profile evidence.

## ubuntu-x64 full-AI profile

Fixture-only profile evidence.

## macos-arm64 native platform evidence

Fixture-only native evidence.

## windows-x64 native platform evidence

Fixture-only native evidence.

## ubuntu-x64 native platform evidence

Fixture-only native evidence.

## macos-arm64 native-messaging evidence

Fixture-only native-messaging evidence.

## windows-x64 native-messaging evidence

Fixture-only native-messaging evidence.

## ubuntu-x64 native-messaging evidence

Fixture-only native-messaging evidence.

## macos-arm64 packaging/update evidence

Fixture-only packaging/update evidence.

## windows-x64 packaging/update evidence

Fixture-only packaging/update evidence.

## ubuntu-x64 packaging/update evidence

Fixture-only packaging/update evidence.
""",
        encoding="utf-8",
    )


def pass_gate(repo: Path, gate: str, *, revision: str = FAKE_TREE) -> None:
    """Flip a gate to PASS coherently across status, ledger, and report."""
    set_status_gate_row(repo, gate, "PASS", filled=True, revision=revision)
    set_ledger_gate_pass_evidence(repo, gate, revision=revision)
    report = repo / "docs" / "gates" / f"{gate}_GATE.md"
    gate_d_bundle = ""
    if gate == "CROSS_PLATFORM_CORE":
        _write_gate_d_evidence(repo)
        gate_d_bundle = (
            f"Evidence bundle: {GATE_D_EVIDENCE_REL} § Gate D evidence bundle\n"
        )
    with report.open("a", encoding="utf-8") as handle:
        handle.write(
            "\n- State: PASS\n"
            f"- Evaluated revision: {revision}\n"
            f"- Corpus/holdout hash: {FAKE_EVIDENCE_HASH}\n"
            f"- Independent reviewer: {FAKE_REVIEWER}\n"
            "- Owner decision: PASS (synthetic fixture)\n"
            "- Holdout result: PASS (synthetic fixture)\n"
            f"{gate_d_bundle}"
        )


def _set_markdown_table_cell(
    path: Path, row_key: str, cell_index: int, value: str
) -> None:
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(rf"^\| `{re.escape(row_key)}` \|[^\n]*$", re.MULTILINE)
    match = pattern.search(text)
    assert match, f"no Markdown table row for {row_key}"
    cells = [cell.strip() for cell in match.group(0).strip("|").split("|")]
    assert len(cells) > cell_index
    cells[cell_index] = value
    replacement = "| " + " | ".join(cells) + " |"
    path.write_text(
        text[: match.start()] + replacement + text[match.end() :],
        encoding="utf-8",
    )


def accept_full_ai_profiles(repo: Path) -> None:
    _write_gate_d_evidence(repo)
    path = repo / "docs" / "platform" / "MODEL_RUNTIME_PROFILES.md"
    for platform in ("macos-arm64", "windows-x64", "ubuntu-x64"):
        _set_markdown_table_cell(path, platform, 1, "`CERTIFIED_FULL`")
        _set_markdown_table_cell(path, platform, 2, "`ACCEPTED`")
        _set_markdown_table_cell(
            path,
            platform,
            3,
            (f"{GATE_D_EVIDENCE_REL} § {platform} full-AI profile"),
        )
    matrix = repo / "docs" / "platform" / "CERTIFIED_MATRIX.md"
    for platform in ("macos-arm64", "windows-x64", "ubuntu-x64"):
        _set_markdown_table_cell(matrix, platform, 4, "`CERTIFIED_FULL`")
        _set_markdown_table_cell(
            matrix,
            platform,
            5,
            (f"{GATE_D_EVIDENCE_REL} § {platform} native platform evidence"),
        )
    support = repo / "docs" / "PLATFORM_SUPPORT.md"
    for platform in ("macos-arm64", "windows-x64", "ubuntu-x64"):
        _set_markdown_table_cell(support, platform, 5, "`CERTIFIED_FULL`")
        _set_markdown_table_cell(
            support,
            platform,
            6,
            f"{GATE_D_EVIDENCE_REL} § {platform} native platform evidence",
        )
    native_messaging = repo / "docs" / "platform" / "NATIVE_MESSAGING_MATRIX.md"
    for platform in ("macos-arm64", "windows-x64", "ubuntu-x64"):
        _set_markdown_table_cell(native_messaging, platform, 3, "`VERIFIED`")
        _set_markdown_table_cell(
            native_messaging,
            platform,
            4,
            f"{GATE_D_EVIDENCE_REL} § {platform} native-messaging evidence",
        )
    packaging = repo / "docs" / "platform" / "PACKAGING_UPDATE_MATRIX.md"
    for platform in ("macos-arm64", "windows-x64", "ubuntu-x64"):
        _set_markdown_table_cell(packaging, platform, 4, "`VERIFIED`")
        _set_markdown_table_cell(
            packaging,
            platform,
            5,
            f"{GATE_D_EVIDENCE_REL} § {platform} packaging/update evidence",
        )


def rewind_unstarted_ui_surfaces(repo: Path) -> None:
    """Rewind UI rows with their owners, retaining the complete copied history."""
    parsed = validate_status.parse_status(status_path(repo))
    states = {row[0]: row[1] for row in parsed.package_rows}
    migration_complete = states.get("M00-W11") in validate_status.DONE
    for surface, owners in validate_status.UI_SURFACE_OWNERS.items():
        if migration_complete and any(
            states.get(owner) in (validate_status.STARTED | {"BLOCKED"})
            for owner in owners
        ):
            continue
        familiarity = repo / "docs/UI_FAMILIARITY.md"
        for index, value in (
            (3, "`NOT_YET_APPLICABLE`"),
            (4, "—"),
            (5, "—"),
            (6, "—"),
            (7, "`NOT_APPROVED`"),
        ):
            _set_markdown_table_cell(familiarity, surface, index, value)
        baseline = repo / "docs/ui/OWNER_APPROVED_VISUAL_BASELINE.md"
        for index in range(2, 12):
            value = (
                "`NOT_YET_APPLICABLE`"
                if index == 2
                else "`NOT_APPROVED`"
                if index == 10
                else "—"
            )
            _set_markdown_table_cell(baseline, surface, index, value)


def reset_downstream(repo: Path, *, after_package: str, after_milestone: str) -> None:
    """Force every package and milestone past the boundary to NOT_STARTED.

    A boundary fixture must state its own complete premise. Packages and
    milestones after the boundary legitimately become READY, IN_PROGRESS, or
    VERIFIED as the project advances, and silently inheriting those rows
    changes what the boundary test actually asserts
    (the KI-0014/KI-0015/KI-0017/KI-0019 class). Identifiers are zero-padded,
    so ordinary string ordering is the exact package/milestone order.
    """
    path = status_path(repo)
    text = path.read_text(encoding="utf-8")

    def later_package(match: re.Match[str]) -> str:
        if match.group(1) <= after_package:
            return match.group(0)
        return f"| `{match.group(1)}` | NOT_STARTED{match.group(3)}"

    def later_milestone(match: re.Match[str]) -> str:
        if match.group(1) <= after_milestone:
            return match.group(0)
        return f"| {match.group(1)} | NOT_STARTED{match.group(3)}"

    text = re.sub(
        r"^\| `(M\d{2}-W\d{2})` \| ([A-Z_]+)( \|)",
        later_package,
        text,
        flags=re.MULTILINE,
    )
    text = re.sub(
        r"^\| (M\d{2}) \| ([A-Z_]+)( \|)",
        later_milestone,
        text,
        flags=re.MULTILINE,
    )
    path.write_text(text, encoding="utf-8")
    rewind_unstarted_ui_surfaces(repo)
    parsed = validate_status.parse_status(path)
    # Rewinding packages inside an accepted milestone also rewinds its
    # acceptance. Later readiness/acceptance mutations still run unchanged.
    boundary_state = dict(parsed.milestone_rows).get(after_milestone)
    boundary_packages = [
        row for row in parsed.package_rows if row[0].startswith(after_milestone + "-")
    ]
    if boundary_state in validate_status.DONE and any(
        row[1] not in validate_status.DONE for row in boundary_packages
    ):
        set_ms_state(repo, after_milestone, "IN_PROGRESS")
        set_ms_revision(repo, after_milestone, "—")
    # A historical boundary before W14 also predates Gate A evaluation.
    # Reset the fixture's ledger/report with its package rows; the live
    # repository and the validator's premature-gate rejection stay unchanged.
    if after_package < "M02-W14":
        set_fixture_gate_state(repo, "AUTOFILL_FEASIBILITY", "NOT_EVALUATED")
        resolve_w14_findings_before_historical_boundary(repo)
    elif after_package < "M02-W15":
        # W14 campaign findings remain live; W15 acceptance has not occurred.
        set_fixture_gate_state(repo, "AUTOFILL_FEASIBILITY", "IN_PROGRESS")


def prepare_m00_closeout(repo: Path, *, m01_ready: bool) -> None:
    """Create the accepted-M00-W11 boundary and optional exact next-ready state.

    The fixture establishes its own complete premise instead of inheriting
    live repository state. M01-W01…W06 are immutable verified anchors, and
    M01-W07 is the only package whose readiness changes at this boundary.
    """
    promote_milestones(repo, ["M00"])
    resolve_corrective_issues(repo)
    reset_downstream(repo, after_package="M01-W07", after_milestone="M01")
    set_current_package(repo, "NONE")
    set_current_milestone(repo, "M01")
    set_pkg_state(repo, "M01-W07", "READY" if m01_ready else "NOT_STARTED")
    set_ms_state(repo, "M01", "IN_PROGRESS")
    set_next_ready(repo, "`M01-W07`" if m01_ready else "NONE")


def prepare_gate_d_pass(repo: Path, *, gate_d_revision: str = FAKE_TREE) -> None:
    promote_milestones(repo, [f"M{number:02d}" for number in range(27)])
    for number in range(1, 12):
        promote(repo, f"M27-W{number:02d}")
    promote(repo, "M27-W13")
    promote(repo, "M27-W14")
    set_ms_state(repo, "M27", "IN_PROGRESS")
    set_pkg_state(repo, "M27-W12", "IN_PROGRESS")
    set_current_package(repo, "M27-W12")
    set_next_ready(repo, "NONE")
    for gate in GATES:
        pass_gate(
            repo,
            gate,
            revision=gate_d_revision if gate == "CROSS_PLATFORM_CORE" else FAKE_TREE,
        )
    accept_full_ai_profiles(repo)


def prepare_m28_ready(repo: Path, *, gate_d_revision: str = FAKE_TREE) -> None:
    prepare_gate_d_pass(repo, gate_d_revision=gate_d_revision)
    promote(repo, "M27-W12")
    set_ms_state(repo, "M27", "ACCEPTED")
    set_ms_revision(repo, "M27", FAKE_TREE)
    set_current_package(repo, "NONE")
    set_ms_state(repo, "M28", "READY")
    set_pkg_state(repo, "M28-W01", "READY")
    set_next_ready(repo, "`M28-W01`")


# ---------------------------------------------------------------- positive


def test_migrated_repository_passes() -> None:
    parsed = validate_status.parse_status(REPO_ROOT / "docs" / "PROJECT_STATUS.md")
    package_states = {cells[0]: cells[1] for cells in parsed.package_rows}
    holdout_status = json.loads(
        (REPO_ROOT / "benchmarks" / "holdout-manifests" / "status.v1.json").read_text(
            encoding="utf-8"
        )
    )
    w06_state = package_states["M02-W06"]
    w07_state = package_states["M02-W07"]
    verification_state = holdout_status["m02_w06_package_verification_state"]
    if w06_state == "IN_PROGRESS":
        assert (w07_state, verification_state) == (
            "NOT_STARTED",
            "PENDING_FINAL_INDEPENDENT_VERIFICATION",
        )
    else:
        assert w06_state == "VERIFIED"
        assert w07_state in validate_status.M02_W06_POST_GOVERNANCE_W07_STATES
        assert verification_state == "FINAL_INDEPENDENT_VERIFICATION_CLEAR"
    result = run_validator(REPO_ROOT)
    assert result.returncode == 0, result.stdout + result.stderr
    assert "PASS" in result.stdout


def test_m02_w06_verification_lifecycle_accepts_future_governance_state(
    repo_copy: Path,
) -> None:
    prepare_m02_w06_pre_governance(repo_copy)
    pre_governance = run_validator(repo_copy)
    assert pre_governance.returncode == 0, pre_governance.stdout + pre_governance.stderr
    prepare_m02_w06_future_governance(repo_copy)
    parsed = validate_status.parse_status(status_path(repo_copy))
    milestone_states = dict(parsed.milestone_rows)
    assert milestone_states["M02"] == "IN_PROGRESS"
    assert parsed.header["Overall release gate:"] == "NOT_READY"
    assert {cells[1] for cells in parsed.gate_rows} == {"NOT_EVALUATED"}
    result = run_validator(repo_copy)
    assert result.returncode == 0, result.stdout + result.stderr


@pytest.mark.parametrize(
    "case",
    [
        "verified-ready-pending",
        "in-progress-not-started-final-clear",
        "in-progress-ready-pending",
        "final-clear-owner-manifest-unavailable",
        "final-clear-owner-review-not-clear",
        "final-clear-tooling-correction-not-clear",
        "unknown-verification-state",
        "missing-verification-state",
    ],
)
def test_m02_w06_verification_lifecycle_rejects_invalid_state(
    repo_copy: Path, case: str
) -> None:
    if case in {
        "verified-ready-pending",
        "final-clear-owner-manifest-unavailable",
        "final-clear-owner-review-not-clear",
        "final-clear-tooling-correction-not-clear",
    }:
        prepare_m02_w06_future_governance(repo_copy)
    else:
        prepare_m02_w06_pre_governance(repo_copy)
    if case == "verified-ready-pending":
        update_m02_w06_holdout_status(
            repo_copy,
            {
                "m02_w06_package_verification_state": (
                    "PENDING_FINAL_INDEPENDENT_VERIFICATION"
                )
            },
        )
    elif case == "in-progress-not-started-final-clear":
        update_m02_w06_holdout_status(
            repo_copy,
            {
                "m02_w06_package_verification_state": (
                    "FINAL_INDEPENDENT_VERIFICATION_CLEAR"
                )
            },
        )
    elif case == "in-progress-ready-pending":
        set_pkg_state(repo_copy, "M02-W07", "READY")
    elif case == "final-clear-owner-manifest-unavailable":
        update_m02_w06_holdout_status(
            repo_copy,
            {"owner_manifest_state": "OWNER_HOLDOUT_MANIFEST_UNAVAILABLE"},
        )
    elif case == "final-clear-owner-review-not-clear":
        update_m02_w06_holdout_status(
            repo_copy,
            {"owner_holdout_review_state": "OWNER_HOLDOUT_V2_REVIEW_PENDING"},
        )
    elif case == "final-clear-tooling-correction-not-clear":
        update_m02_w06_holdout_status(
            repo_copy,
            {"correction_verification_state": "M02_W06_TOOLING_CORRECTION_PENDING"},
        )
    elif case == "unknown-verification-state":
        update_m02_w06_holdout_status(
            repo_copy,
            {"m02_w06_package_verification_state": "UNKNOWN"},
        )
    elif case == "missing-verification-state":
        update_m02_w06_holdout_status(
            repo_copy,
            {"m02_w06_package_verification_state": None},
        )
    else:
        pytest.fail(f"unhandled lifecycle case: {case}")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "M02-W06 package verification" in result.stdout


def test_owner_approved_hash_and_exact_v14_inventory() -> None:
    spec_path = REPO_ROOT / "docs" / "MASTER_IMPLEMENTATION_SPEC.md"
    assert hashlib.sha256(spec_path.read_bytes()).hexdigest() == (
        "3eba7bdfbbb1591b5ea54c31bc415fc0cbfd3c361d32005b328f27a12f3ac943"
    )
    spec = validate_status.parse_spec(spec_path)
    assert list(spec.milestones) == [f"M{number:02d}" for number in range(39)]
    assert len(spec.package_ids()) == len(set(spec.package_ids())) == 300
    assert len(spec.requirement_ids) == 193
    assert [pid for pid, _ in spec.milestones["M00"].packages] == [
        f"M00-W{number:02d}" for number in range(1, 12)
    ]


def test_owner_controlled_agent_and_staged_ai_policy_are_present() -> None:
    text = (REPO_ROOT / "docs" / "MASTER_IMPLEMENTATION_SPEC.md").read_text(
        encoding="utf-8"
    )
    assert "**Implementation-agent policy:** Owner-selected per package." in text
    assert "must not automatically route work between agents, model families" in text
    assert "does not block the resume/PageFit feasibility architecture or `M06`" in text
    assert (
        "Final acceptance of at least one `CERTIFIED_FULL` Windows profile "
        "and one `CERTIFIED_FULL` Ubuntu profile is deferred to `M27-W10`"
    ) in text
    assert "Implementation sessions use Claude Fable 5 Max" not in (
        REPO_ROOT / "CLAUDE.md"
    ).read_text(encoding="utf-8")


@pytest.mark.parametrize(
    ("family", "wrong_major"),
    [
        ("evidence-record", "v1"),
        ("evidence-record", "v999"),
        ("certification-input", "v1"),
        ("certification-input", "v999"),
    ],
)
def test_future_gate_d_schema_guidance_rejects_deprecated_or_missing_major(
    repo_copy: Path,
    family: str,
    wrong_major: str,
) -> None:
    ledger = repo_copy / "docs" / "CRITICAL_GATES.md"
    edit(
        ledger,
        f"urn:japp:schema:platform:{family}:v2",
        f"urn:japp:schema:platform:{family}:{wrong_major}",
        count=1,
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert f"platform:{family}:v2" in result.stdout
    assert "future Gate D guidance" in result.stdout


def test_gate_pass_unblocks_m03(repo_copy: Path) -> None:
    reset_downstream(repo_copy, after_package="M03-W01", after_milestone="M03")
    promote_milestones(repo_copy, ["M00", "M01", "M02"])
    set_current_package(repo_copy, "NONE")
    set_ms_state(repo_copy, "M03", "READY")
    set_pkg_state(repo_copy, "M03-W01", "READY")
    set_next_ready(repo_copy, "`M03-W01`")
    pass_gate(repo_copy, "AUTOFILL_FEASIBILITY")
    result = run_validator(repo_copy)
    assert result.returncode == 0, result.stdout + result.stderr


# ------------------------------------------ live blocker reconciliation


def test_former_accepted_status_with_stale_fixed_blockers_is_rejected(
    repo_copy: Path,
) -> None:
    resolve_corrective_issues(repo_copy)
    set_live_blockers(
        repo_copy,
        [
            "- KI-0024 (HIGH, IN_PROGRESS) — stale historical blocker",
            "- KI-0025 (HIGH, IN_PROGRESS) — stale historical blocker",
        ],
    )
    set_ms_state(repo_copy, "M01", "ACCEPTED")
    set_pkg_state(repo_copy, "M01-W07", "VERIFIED")
    set_ms_state(repo_copy, "M02", "IN_PROGRESS")
    set_pkg_state(repo_copy, "M02-W01", "READY")
    set_current_package(repo_copy, "NONE")
    set_next_ready(repo_copy, "M02-W01")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "KI-0024 resolves to HIGH/FIXED" in result.stdout
    assert "KI-0025 resolves to HIGH/FIXED" in result.stdout


def test_freeform_live_blocker_prose_is_rejected(repo_copy: Path) -> None:
    activate_corrective_blockers(repo_copy)
    set_live_blockers(
        repo_copy,
        [*CURRENT_BLOCKER_LINES, "- Milestones M01–M38 are unaccepted."],
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "live blocker line must use" in result.stdout


def test_blocking_issue_omitted_from_live_blockers_is_rejected(
    repo_copy: Path,
) -> None:
    activate_corrective_blockers(repo_copy)
    set_live_blockers(repo_copy, CURRENT_BLOCKER_LINES[:-1])
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "KI-0031 is HIGH/IN_PROGRESS" in result.stdout
    assert "missing from PROJECT_STATUS live blockers" in result.stdout


def test_omitted_blocker_still_enforces_affected_milestone_scope(
    repo_copy: Path,
) -> None:
    activate_corrective_blockers(repo_copy)
    set_live_blockers(repo_copy, CURRENT_BLOCKER_LINES[:-1])
    set_ms_state(repo_copy, "M01", "ACCEPTED")
    set_ms_revision(repo_copy, "M01", FAKE_TREE)
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "KI-0031 is HIGH/IN_PROGRESS" in result.stdout
    assert "KI-0031 blocks affected milestone M01" in result.stdout


def test_unknown_and_duplicate_live_blockers_are_rejected(repo_copy: Path) -> None:
    activate_corrective_blockers(repo_copy)
    set_live_blockers(
        repo_copy,
        [
            *CURRENT_BLOCKER_LINES,
            CURRENT_BLOCKER_LINES[0],
            "- KI-9999 (HIGH, OPEN) — unknown blocker",
        ],
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "repeats KI-0029" in result.stdout
    assert "KI-9999 is unknown" in result.stdout


def test_live_blocker_severity_or_state_mismatch_is_rejected(
    repo_copy: Path,
) -> None:
    activate_corrective_blockers(repo_copy)
    set_live_blockers(
        repo_copy,
        [
            "- KI-0029 (CRITICAL, OPEN) — mismatched duplicate fields",
            *CURRENT_BLOCKER_LINES[1:],
        ],
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "KI-0029 says CRITICAL/OPEN" in result.stdout
    assert "KNOWN_ISSUES says HIGH/IN_PROGRESS" in result.stdout


@pytest.mark.parametrize("state", ["FIXED", "DEFERRED", "WONT_FIX"])
def test_nonblocking_issue_state_cannot_remain_live(
    repo_copy: Path, state: str
) -> None:
    activate_corrective_blockers(repo_copy)
    set_issue_state(repo_copy, "KI-0029", state)
    set_live_blockers(repo_copy, CURRENT_BLOCKER_LINES)
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert f"KI-0029 resolves to HIGH/{state}, which is not blocking" in result.stdout


@pytest.mark.parametrize("severity", ["MEDIUM", "LOW"])
def test_nonblocking_issue_severity_cannot_be_live(
    repo_copy: Path, severity: str
) -> None:
    activate_corrective_blockers(repo_copy)
    set_issue_severity(repo_copy, "KI-0029", severity)
    set_live_blockers(
        repo_copy,
        [
            f"- KI-0029 ({severity}, IN_PROGRESS) — nonblocking severity",
            *CURRENT_BLOCKER_LINES[1:],
        ],
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert (
        f"KI-0029 resolves to {severity}/IN_PROGRESS, which is not blocking"
        in result.stdout
    )


@pytest.mark.parametrize(
    "lines",
    [
        [],
        ["- NONE", *CURRENT_BLOCKER_LINES],
        ["KI-0029 (HIGH, IN_PROGRESS) — missing bullet"],
    ],
)
def test_empty_mixed_or_malformed_live_blocker_section_is_rejected(
    repo_copy: Path, lines: list[str]
) -> None:
    activate_corrective_blockers(repo_copy)
    set_live_blockers(repo_copy, lines)
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "live blocker" in result.stdout


def test_blocker_cannot_coexist_with_affected_accepted_milestone(
    repo_copy: Path,
) -> None:
    activate_corrective_blockers(repo_copy)
    set_ms_state(repo_copy, "M01", "ACCEPTED")
    set_ms_revision(repo_copy, "M01", FAKE_TREE)
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "blocks affected milestone M01" in result.stdout
    assert "cannot remain ACCEPTED" in result.stdout


def test_blocker_requires_zero_ready_packages_and_next_none(repo_copy: Path) -> None:
    activate_corrective_blockers(repo_copy)
    set_pkg_state(repo_copy, "M02-W01", "READY")
    set_next_ready(repo_copy, "M02-W01")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "live CRITICAL/HIGH blockers require zero READY packages" in result.stdout
    assert "require Next READY package ID NONE" in result.stdout


def test_m00_may_remain_accepted_while_m01_blockers_are_live(
    repo_copy: Path,
) -> None:
    set_pkg_state(repo_copy, "M02-W02", "READY")
    activate_corrective_blockers(repo_copy)
    result = run_validator(repo_copy)
    assert result.returncode == 0, result.stdout + result.stderr


def test_fixed_ledger_and_none_sentinel_allow_later_readiness(
    repo_copy: Path,
) -> None:
    promote_milestones(repo_copy, ["M00", "M01"])
    set_pkg_state(repo_copy, "M02-W02", "READY")
    reset_downstream(repo_copy, after_package="M02-W01", after_milestone="M02")
    set_current_package(repo_copy, "NONE")
    set_ms_state(repo_copy, "M02", "IN_PROGRESS")
    set_pkg_state(repo_copy, "M02-W01", "READY")
    set_next_ready(repo_copy, "M02-W01")
    result = run_validator(repo_copy)
    assert result.returncode == 0, result.stdout + result.stderr


# ------------------------------------------------- structural rejections


def test_invalid_package_state_rejected(repo_copy: Path) -> None:
    set_pkg_state(repo_copy, "M03-W02", "NOT_STARTED")
    assert run_validator(repo_copy).returncode == 0
    edit(status_path(repo_copy), "| `M03-W02` | NOT_STARTED |", "| `M03-W02` | DONE |")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "M03-W02" in result.stdout


def test_skipped_dependency_rejected(repo_copy: Path) -> None:
    promote_milestones(repo_copy, ["M00"])
    clear_in_progress(repo_copy)
    set_pkg_state(repo_copy, "M00-W11", "NOT_STARTED")
    set_ms_state(repo_copy, "M00", "IN_PROGRESS")
    set_pkg_state(repo_copy, "M01-W07", "READY")
    set_current_package(repo_copy, "NONE")
    set_next_ready(repo_copy, "`M01-W07`")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "before M00-W11 is exactly VERIFIED" in result.stdout


def test_m01_w07_requires_m00_milestone_acceptance_not_only_done_packages(
    repo_copy: Path,
) -> None:
    promote_milestones(repo_copy, ["M00"])
    set_ms_state(repo_copy, "M00", "VERIFIED")
    set_current_package(repo_copy, "NONE")
    set_ms_state(repo_copy, "M01", "IN_PROGRESS")
    set_pkg_state(repo_copy, "M01-W07", "READY")
    set_next_ready(repo_copy, "`M01-W07`")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "milestone M00 is 'VERIFIED' (ACCEPTED required)" in result.stdout


def test_m01_w07_becomes_ready_after_valid_m00_acceptance(repo_copy: Path) -> None:
    prepare_m00_closeout(repo_copy, m01_ready=True)
    result = run_validator(repo_copy)
    assert result.returncode == 0, result.stdout + result.stderr


def test_valid_m00_closeout_makes_only_m01_w07_ready(repo_copy: Path) -> None:
    prepare_m00_closeout(repo_copy, m01_ready=True)
    parsed = validate_status.parse_status(status_path(repo_copy))
    ready = [cells[0] for cells in parsed.package_rows if cells[1] == "READY"]
    assert ready == ["M01-W07"]
    assert all(cells[1] == "NOT_EVALUATED" for cells in parsed.gate_rows)
    result = run_validator(repo_copy)
    assert result.returncode == 0, result.stdout + result.stderr


def test_completed_m00_w11_closeout_requires_m01_w07_ready(
    repo_copy: Path,
) -> None:
    prepare_m00_closeout(repo_copy, m01_ready=False)
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert (
        "completed M00-W11 closeout cannot leave M01-W07 NOT_STARTED" in result.stdout
    )


def test_post_m00_closeout_keeps_every_gate_not_evaluated(
    repo_copy: Path,
) -> None:
    prepare_m00_closeout(repo_copy, m01_ready=True)
    pass_gate(repo_copy, "AUTOFILL_FEASIBILITY")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "post-M00-W11 closeout boundary" in result.stdout
    assert "AUTOFILL_FEASIBILITY" in result.stdout


def test_m00_acceptance_requires_every_direct_package_exactly_verified(
    repo_copy: Path,
) -> None:
    prepare_m00_closeout(repo_copy, m01_ready=False)
    set_pkg_state(repo_copy, "M00-W09", "ACCEPTED")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "M00 cannot be ACCEPTED" in result.stdout
    assert "'M00-W09': 'ACCEPTED'" in result.stdout


def test_m01_w07_rejects_accepted_instead_of_verified_m00_w11(
    repo_copy: Path,
) -> None:
    prepare_m00_closeout(repo_copy, m01_ready=True)
    set_pkg_state(repo_copy, "M00-W11", "ACCEPTED")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "M00-W11" in result.stdout
    assert "exactly VERIFIED" in result.stdout


def test_next_ready_none_rejected_when_ready_row_exists(repo_copy: Path) -> None:
    prepare_m00_closeout(repo_copy, m01_ready=True)
    set_next_ready(repo_copy, "NONE")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "Next READY package is NONE but READY row(s) exist" in result.stdout


def test_named_next_ready_rejected_when_no_ready_row_exists(repo_copy: Path) -> None:
    prepare_m00_closeout(repo_copy, m01_ready=False)
    set_next_ready(repo_copy, "`M01-W07`")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "no work-package row is READY" in result.stdout


def test_current_work_package_must_be_exact_none_or_blocked_id(
    repo_copy: Path,
) -> None:
    # Establish the complete premise (no IN_PROGRESS row) regardless of the
    # live repository state.
    clear_in_progress(repo_copy)
    set_current_package(repo_copy, "garbage")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "must be NONE or a BLOCKED package" in result.stdout


def test_next_ready_none_must_be_exact(repo_copy: Path) -> None:
    prepare_m00_closeout(repo_copy, m01_ready=False)
    set_next_ready(repo_copy, "NONE nonsense")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "no work-package row is READY" in result.stdout


def test_current_milestone_must_match_exact_next_work(repo_copy: Path) -> None:
    prepare_m00_closeout(repo_copy, m01_ready=True)
    set_current_milestone(repo_copy, "M38")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "Current milestone" in result.stdout
    assert "expected 'M01'" in result.stdout


def test_overall_release_gate_must_remain_canonical_not_ready(
    repo_copy: Path,
) -> None:
    edit(
        status_path(repo_copy),
        "Overall release gate: NOT_READY",
        "Overall release gate: READY",
        count=1,
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "canonical current value must be NOT_READY" in result.stdout


def test_all_gates_remain_not_evaluated_while_m00_is_unfinished(
    repo_copy: Path,
) -> None:
    set_ms_state(repo_copy, "M00", "IN_PROGRESS")
    set_pkg_state(repo_copy, "M00-W11", "IN_PROGRESS")
    set_current_package(repo_copy, "M00-W11")
    set_ms_state(repo_copy, "M01", "IN_PROGRESS")
    set_pkg_state(repo_copy, "M01-W07", "NOT_STARTED")
    set_next_ready(repo_copy, "NONE")
    set_status_gate_row(repo_copy, "AUTOFILL_FEASIBILITY", "IN_PROGRESS")
    set_ledger_gate_state(repo_copy, "AUTOFILL_FEASIBILITY", "IN_PROGRESS")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "all four critical gates must remain NOT_EVALUATED" in result.stdout


def test_no_other_m01_package_becomes_prematurely_ready(repo_copy: Path) -> None:
    prepare_m00_closeout(repo_copy, m01_ready=True)
    set_pkg_state(repo_copy, "M02-W01", "READY")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "M01-W07 must be the only READY package" in result.stdout


def test_two_in_progress_rejected(repo_copy: Path) -> None:
    set_pkg_state(repo_copy, "M00-W11", "IN_PROGRESS")
    set_pkg_state(repo_copy, "M01-W07", "IN_PROGRESS")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "more than one work package IN_PROGRESS" in result.stdout


def test_missing_package_row_rejected(repo_copy: Path) -> None:
    path = status_path(repo_copy)
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(r"^\| `M38-W07` \|[^\n]*\n", flags=re.MULTILINE)
    assert pattern.search(text)
    path.write_text(pattern.sub("", text, count=1), encoding="utf-8")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "M38-W07" in result.stdout


def test_stale_v1_inventory_missing_workday_packages_rejected(
    repo_copy: Path,
) -> None:
    path = status_path(repo_copy)
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(r"^\| `M(?:19|20)-W\d{2}` \|[^\n]*\n", flags=re.MULTILINE)
    stripped, removed = pattern.subn("", text)
    assert removed == 22, f"expected 22 Workday rows, found {removed}"
    path.write_text(stripped, encoding="utf-8")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "M19-W01" in result.stdout


# ------------------------------------------------------ spec-side checks


def test_missing_workday_requirement_rejected(repo_copy: Path) -> None:
    spec = repo_copy / "docs" / "MASTER_IMPLEMENTATION_SPEC.md"
    text = spec.read_text(encoding="utf-8")
    pattern = re.compile(r"^- `REQ-WD-023`[^\n]*\n", flags=re.MULTILINE)
    assert pattern.search(text)
    spec.write_text(pattern.sub("", text, count=1), encoding="utf-8")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "expected 193" in result.stdout


def test_missing_milestone_section_rejected(repo_copy: Path) -> None:
    spec = repo_copy / "docs" / "MASTER_IMPLEMENTATION_SPEC.md"
    text = spec.read_text(encoding="utf-8")
    marker = "## M38 —"
    assert marker in text
    spec.write_text(text.split(marker)[0], encoding="utf-8")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "expected 39" in result.stdout


def test_second_canonical_spec_rejected(repo_copy: Path) -> None:
    canonical = repo_copy / "docs" / "MASTER_IMPLEMENTATION_SPEC.md"
    shutil.copy2(
        canonical,
        repo_copy / "docs" / "MASTER_IMPLEMENTATION_SPEC.v1.4.proposed.md",
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "MASTER_IMPLEMENTATION_SPEC.v1.4.proposed.md" in result.stdout


def test_final_tree_has_no_proposed_specification() -> None:
    assert not (
        REPO_ROOT / "docs" / "MASTER_IMPLEMENTATION_SPEC.v1.4.proposed.md"
    ).exists()


@pytest.mark.parametrize(
    "relative",
    [
        "docs/PLATFORM_SUPPORT.md",
        "docs/platform/CERTIFIED_MATRIX.md",
        "docs/platform/MODEL_RUNTIME_PROFILES.md",
        "docs/platform/NATIVE_MESSAGING_MATRIX.md",
        "docs/platform/PACKAGING_UPDATE_MATRIX.md",
    ],
)
def test_missing_platform_governance_file_rejected(
    repo_copy: Path, relative: str
) -> None:
    (repo_copy / relative).unlink()
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert relative in result.stdout


def test_renamed_canonical_lookalike_rejected(repo_copy: Path) -> None:
    lookalike = repo_copy / "docs" / "ARCHIVED_NOTES.md"
    lookalike.write_text(
        "# Old copy\n\n**Specification ID:** JAPP-MASTER-001\n",
        encoding="utf-8",
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "ARCHIVED_NOTES.md" in result.stdout


@pytest.mark.parametrize(
    ("relative", "old", "new", "message"),
    [
        (
            "docs/UI_FAMILIARITY.md",
            (
                "| `DESKTOP_SHELL` | Desktop shell and global navigation | "
                "`M03-W01`, `M03-W11` | `NOT_YET_APPLICABLE` |"
            ),
            (
                "| `DESKTOP_SHELL` | Desktop shell and global navigation | "
                "`M03-W01`, `M03-W11` | `OWNER_APPROVED` |"
            ),
            "UI familiarity surface DESKTOP_SHELL must remain NOT_YET_APPLICABLE",
        ),
        (
            "docs/ui/OWNER_APPROVED_VISUAL_BASELINE.md",
            "| `DESKTOP_SHELL` | `M03-W01`, `M03-W11` | `NOT_YET_APPLICABLE` | — |",
            "| `DESKTOP_SHELL` | `M03-W01`, `M03-W11` | `APPROVED` | fake.png |",
            "visual baseline surface DESKTOP_SHELL must remain NOT_YET_APPLICABLE",
        ),
        (
            "docs/ui/ANTI_BLOAT_CHECKLIST.md",
            (
                "| `AB-01` | No marketing hero treatment on authenticated "
                "product surfaces. | `NOT_EVALUATED` |"
            ),
            (
                "| `AB-01` | No marketing hero treatment on authenticated "
                "product surfaces. | `PASS` |"
            ),
            "anti-bloat rule AB-01 must have one NOT_EVALUATED row",
        ),
        (
            "docs/EXPERIMENTAL_AI_PROVIDERS.md",
            "`DISABLED_BY_DEFAULT` | `NOT_IMPLEMENTED`",
            "`ENABLED_EXPERIMENTAL` | `NOT_IMPLEMENTED`",
            "provider CHATGPT_ACCOUNT_OAUTH state drift",
        ),
    ],
)
def test_v14_governance_ledger_false_completion_rejected(
    repo_copy: Path, relative: str, old: str, new: str, message: str
) -> None:
    """Each ledger mutation must be rejected by its own exact diagnostic.

    A loose ``"v1.4" in stdout`` assertion would pass for any failure at all,
    because the validator's own ``ok:`` lines mention v1.4 and the provider
    boundary; the expected message is therefore pinned per case.
    """
    # These mutations target the migration scaffold, not a later evidenced capture.
    if relative == "docs/UI_FAMILIARITY.md":
        for index, value in (
            (3, "`NOT_YET_APPLICABLE`"),
            (4, "—"),
            (5, "—"),
            (6, "—"),
            (7, "`NOT_APPROVED`"),
        ):
            _set_markdown_table_cell(
                repo_copy / relative, "DESKTOP_SHELL", index, value
            )
    elif relative == "docs/ui/OWNER_APPROVED_VISUAL_BASELINE.md":
        _reset_migration_baseline(repo_copy)
    edit(repo_copy / relative, old, new, count=1)
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert f"ERROR: {message}" in result.stdout


@pytest.mark.parametrize(
    "relative",
    [
        "docs/UI_FAMILIARITY.md",
        "docs/ui/OWNER_APPROVED_VISUAL_BASELINE.md",
        "docs/ui/ANTI_BLOAT_CHECKLIST.md",
        "docs/EXPERIMENTAL_AI_PROVIDERS.md",
    ],
)
def test_empty_v14_governance_memory_rejected(repo_copy: Path, relative: str) -> None:
    (repo_copy / relative).write_text("", encoding="utf-8")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert f"missing or empty project-memory file: {relative}" in result.stdout


def test_missing_or_duplicate_familiarity_surface_rejected(
    repo_copy: Path,
) -> None:
    path = repo_copy / "docs/UI_FAMILIARITY.md"
    text = path.read_text(encoding="utf-8")
    row = next(
        line for line in text.splitlines() if line.startswith("| `DESKTOP_SHELL` |")
    )
    path.write_text(text.replace(f"{row}\n", "", 1), encoding="utf-8")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "UI familiarity surface DESKTOP_SHELL" in result.stdout

    path.write_text(text.replace(row, f"{row}\n{row}", 1), encoding="utf-8")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "UI familiarity surface DESKTOP_SHELL" in result.stdout


def _reset_migration_baseline(repo: Path) -> None:
    """Keep historical negative fixtures explicit after honest W01 captures land."""
    path = repo / "docs/ui/OWNER_APPROVED_VISUAL_BASELINE.md"
    for index in range(2, 11):
        value = (
            "`NOT_YET_APPLICABLE`"
            if index == 2
            else "`NOT_APPROVED`"
            if index == 10
            else "—"
        )
        _set_markdown_table_cell(path, "DESKTOP_SHELL", index, value)


@pytest.mark.parametrize(
    ("cell_index", "value", "message"),
    [
        (4, "sha256:" + "a" * 64, "invents capture metadata"),
        (10, "`APPROVED`", "falsely claims approval"),
    ],
)
def test_unapproved_visual_baseline_cannot_claim_artifact_or_decision(
    repo_copy: Path, cell_index: int, value: str, message: str
) -> None:
    _reset_migration_baseline(repo_copy)
    _set_markdown_table_cell(
        repo_copy / "docs/ui/OWNER_APPROVED_VISUAL_BASELINE.md",
        "DESKTOP_SHELL",
        cell_index,
        value,
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert message in result.stdout


def test_removed_anti_bloat_rule_rejected(repo_copy: Path) -> None:
    path = repo_copy / "docs/ui/ANTI_BLOAT_CHECKLIST.md"
    text = path.read_text(encoding="utf-8")
    row = next(line for line in text.splitlines() if line.startswith("| `AB-12` |"))
    path.write_text(text.replace(f"{row}\n", "", 1), encoding="utf-8")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "anti-bloat rule AB-12" in result.stdout


@pytest.mark.parametrize(
    ("provider_id", "cell_index", "value"),
    [
        ("CHATGPT_ACCOUNT_OAUTH", 3, "`IMPLEMENTED`"),
        ("CHATGPT_ACCOUNT_OAUTH", 4, "`PASS`"),
        ("CHATGPT_ACCOUNT_OAUTH", 5, "`ENABLED_EXPERIMENTAL`"),
        ("CHATGPT_ACCOUNT_OAUTH", 6, "`SUPPORTED`"),
        ("OLLAMA_LOCAL", 2, "`DISABLED_BY_DEFAULT`"),
    ],
)
def test_provider_registry_false_state_rejected(
    repo_copy: Path, provider_id: str, cell_index: int, value: str
) -> None:
    _set_markdown_table_cell(
        repo_copy / "docs/EXPERIMENTAL_AI_PROVIDERS.md",
        provider_id,
        cell_index,
        value,
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert f"provider {provider_id} state drift" in result.stdout


@pytest.mark.parametrize(
    ("old", "new", "message"),
    [
        (
            "There is no silent provider fallback.",
            "Silent provider fallback is allowed.",
            "There is no silent provider fallback.",
        ),
        (
            "`M27-W12` executes last",
            "`M27-W14` executes last",
            "M27-W12` executes last",
        ),
    ],
)
def test_provider_policy_weakening_rejected(
    repo_copy: Path, old: str, new: str, message: str
) -> None:
    edit(
        repo_copy / "docs/EXPERIMENTAL_AI_PROVIDERS.md",
        old,
        new,
        count=1,
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert message in result.stdout


def test_duplicate_requirement_definition_rejected(repo_copy: Path) -> None:
    spec = repo_copy / "docs" / "MASTER_IMPLEMENTATION_SPEC.md"
    text = spec.read_text(encoding="utf-8")
    definition = next(
        line for line in text.splitlines() if line.startswith("- `REQ-AI-018`:")
    )
    spec.write_text(
        text.replace(definition, f"{definition}\n{definition}", 1),
        encoding="utf-8",
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "194 requirement rows, 193 unique IDs" in result.stdout


# ------------------------------------------------------------ gate checks


def test_invalid_gate_state_rejected(repo_copy: Path) -> None:
    set_status_gate_row(repo_copy, "AUTOFILL_FEASIBILITY", "GREEN")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "invalid gate state" in result.stdout


def test_missing_workday_gate_row_rejected(repo_copy: Path) -> None:
    path = status_path(repo_copy)
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(
        r"^\| WORKDAY_GUIDED_PRE_SUBMIT \|[^\n]*\n", flags=re.MULTILINE
    )
    assert pattern.search(text)
    path.write_text(pattern.sub("", text, count=1), encoding="utf-8")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "WORKDAY_GUIDED_PRE_SUBMIT" in result.stdout


def test_missing_workday_gate_report_rejected(repo_copy: Path) -> None:
    (repo_copy / "docs" / "gates" / "WORKDAY_GUIDED_PRE_SUBMIT_GATE.md").unlink()
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "WORKDAY_GUIDED_PRE_SUBMIT_GATE.md" in result.stdout


def test_missing_cross_platform_gate_report_rejected(repo_copy: Path) -> None:
    (repo_copy / "docs" / "gates" / "CROSS_PLATFORM_CORE_GATE.md").unlink()
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "CROSS_PLATFORM_CORE_GATE.md" in result.stdout


def test_duplicate_cross_platform_gate_row_rejected(repo_copy: Path) -> None:
    path = status_path(repo_copy)
    text = path.read_text(encoding="utf-8")
    row = next(
        line for line in text.splitlines() if line.startswith("| CROSS_PLATFORM_CORE |")
    )
    path.write_text(text.replace(row, f"{row}\n{row}", 1), encoding="utf-8")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "duplicate critical-gates row: CROSS_PLATFORM_CORE" in result.stdout


def test_gate_report_cell_must_name_canonical_report(repo_copy: Path) -> None:
    edit(
        status_path(repo_copy),
        "docs/gates/CROSS_PLATFORM_CORE_GATE.md |",
        "docs/gates/WRONG.md |",
        count=1,
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "CROSS_PLATFORM_CORE report cell" in result.stdout


def test_report_state_must_agree_even_while_not_evaluated(
    repo_copy: Path,
) -> None:
    set_fixture_gate_state(repo_copy, "AUTOFILL_FEASIBILITY", "NOT_EVALUATED")
    report = repo_copy / "docs" / "gates" / "AUTOFILL_FEASIBILITY_GATE.md"
    edit(report, "- State: NOT_EVALUATED", "- State: PASS", count=1)
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "AUTOFILL_FEASIBILITY_GATE.md says 'PASS'" in result.stdout


def test_gate_cannot_start_before_its_evaluation_package(repo_copy: Path) -> None:
    prepare_m00_closeout(repo_copy, m01_ready=False)
    set_fixture_gate_state(repo_copy, "AUTOFILL_FEASIBILITY", "IN_PROGRESS")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "before evaluation package M02-W14 is started" in result.stdout


def test_missing_critical_gates_ledger_rejected(repo_copy: Path) -> None:
    (repo_copy / "docs" / "CRITICAL_GATES.md").unlink()
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "CRITICAL_GATES.md" in result.stdout


def test_gate_pass_without_evidence_fields_rejected(repo_copy: Path) -> None:
    set_status_gate_row(repo_copy, "AUTOFILL_FEASIBILITY", "PASS", filled=False)
    set_ledger_gate_state(repo_copy, "AUTOFILL_FEASIBILITY", "PASS")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "AUTOFILL_FEASIBILITY is PASS but" in result.stdout


def test_cross_platform_gate_pass_requires_full_ai_profiles(
    repo_copy: Path,
) -> None:
    pass_gate(repo_copy, "CROSS_PLATFORM_CORE")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "windows-x64 lacks CERTIFIED_FULL/ACCEPTED" in result.stdout
    assert "ubuntu-x64 lacks CERTIFIED_FULL/ACCEPTED" in result.stdout


def test_cross_platform_gate_pass_accepts_only_resolved_repository_evidence(
    repo_copy: Path,
) -> None:
    prepare_gate_d_pass(repo_copy)
    result = run_validator(repo_copy)
    assert result.returncode == 0, result.stdout + result.stderr


def test_cross_platform_gate_rejects_real_but_irrelevant_evidence_record(
    repo_copy: Path,
) -> None:
    prepare_gate_d_pass(repo_copy)
    gate_report = repo_copy / "docs" / "gates" / "CROSS_PLATFORM_CORE_GATE.md"
    edit(
        gate_report,
        f"{GATE_D_EVIDENCE_REL} § Gate D evidence bundle",
        "docs/TEST_EVIDENCE.md § M00-W01",
        count=1,
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "not scoped to the required Gate D evidence owner" in result.stdout


def test_cross_platform_gate_rejects_package_id_buried_in_unowned_heading(
    repo_copy: Path,
) -> None:
    prepare_gate_d_pass(repo_copy)
    evidence = repo_copy / "docs" / "TEST_EVIDENCE.md"
    with evidence.open("a", encoding="utf-8") as handle:
        handle.write("\n### Fake note mentioning M27-W12\n\nNot package evidence.\n")
    gate_report = repo_copy / "docs" / "gates" / "CROSS_PLATFORM_CORE_GATE.md"
    edit(
        gate_report,
        f"{GATE_D_EVIDENCE_REL} § Gate D evidence bundle",
        "docs/TEST_EVIDENCE.md § Fake note mentioning M27-W12",
        count=1,
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "not scoped to the required Gate D evidence owner" in result.stdout


@pytest.mark.parametrize(
    ("reference", "reason"),
    [
        ("https://example.invalid/gate-d", "must not be a URL"),
        ("/etc/hosts", "must be repository-relative"),
        (r"C:\Users\runner\evidence.md", "must be repository-relative"),
        ("../outside.md", "must not contain path traversal"),
        ("placeholder evidence", "is a placeholder"),
        ("docs/gates/DOES_NOT_EXIST.md", "does not resolve"),
        (
            "docs/MASTER_IMPLEMENTATION_SPEC.md",
            "is not an approved repository evidence record/file",
        ),
        (
            f"{GATE_D_EVIDENCE_REL} § nonexistent heading",
            "heading that does not exist",
        ),
    ],
)
def test_cross_platform_gate_rejects_unsafe_or_unresolved_bundle_reference(
    repo_copy: Path, reference: str, reason: str
) -> None:
    prepare_gate_d_pass(repo_copy)
    gate_report = repo_copy / "docs" / "gates" / "CROSS_PLATFORM_CORE_GATE.md"
    edit(
        gate_report,
        f"{GATE_D_EVIDENCE_REL} § Gate D evidence bundle",
        reference,
        count=1,
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "gate report Evidence bundle reference" in result.stdout
    assert reason in result.stdout


def test_cross_platform_gate_rejects_unresolved_profile_evidence(
    repo_copy: Path,
) -> None:
    prepare_gate_d_pass(repo_copy)
    profiles = repo_copy / "docs" / "platform" / "MODEL_RUNTIME_PROFILES.md"
    _set_markdown_table_cell(
        profiles,
        "windows-x64",
        3,
        f"{GATE_D_EVIDENCE_REL} § nonexistent Windows profile",
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "windows-x64 profile evidence reference" in result.stdout
    assert "heading that does not exist" in result.stdout


def test_cross_platform_gate_rejects_placeholder_platform_matrix_evidence(
    repo_copy: Path,
) -> None:
    prepare_gate_d_pass(repo_copy)
    matrix = repo_copy / "docs" / "platform" / "CERTIFIED_MATRIX.md"
    _set_markdown_table_cell(matrix, "ubuntu-x64", 5, "pending evidence")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "ubuntu-x64 platform-matrix evidence reference" in result.stdout
    assert "is a placeholder" in result.stdout


def test_cross_platform_gate_rejects_symlink_escape(repo_copy: Path) -> None:
    prepare_gate_d_pass(repo_copy)
    outside = repo_copy.parent / "outside-evidence.md"
    outside.write_text("# Outside\n", encoding="utf-8")
    link = repo_copy / "docs" / "gates" / "evidence" / "escaped.md"
    link.symlink_to(outside)
    gate_report = repo_copy / "docs" / "gates" / "CROSS_PLATFORM_CORE_GATE.md"
    edit(
        gate_report,
        f"{GATE_D_EVIDENCE_REL} § Gate D evidence bundle",
        "docs/gates/evidence/escaped.md",
        count=1,
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "resolves outside the repository" in result.stdout


def test_cross_platform_gate_rejects_duplicate_platform_rows(
    repo_copy: Path,
) -> None:
    prepare_gate_d_pass(repo_copy)
    matrix = repo_copy / "docs" / "platform" / "CERTIFIED_MATRIX.md"
    text = matrix.read_text(encoding="utf-8")
    row = next(
        line for line in text.splitlines() if line.startswith("| `windows-x64` |")
    )
    matrix.write_text(text.replace(row, f"{row}\n{row}", 1), encoding="utf-8")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "windows-x64 must have exactly one certified-platform matrix row" in (
        result.stdout
    )


def test_cross_platform_gate_requires_certified_full_matrix_state(
    repo_copy: Path,
) -> None:
    prepare_gate_d_pass(repo_copy)
    matrix = repo_copy / "docs" / "platform" / "CERTIFIED_MATRIX.md"
    _set_markdown_table_cell(matrix, "windows-x64", 4, "`NOT_YET_IMPLEMENTED`")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "windows-x64 certified-platform current product state" in result.stdout


@pytest.mark.parametrize(
    "case",
    [
        (
            "docs/PLATFORM_SUPPORT.md",
            "windows-x64",
            5,
            "`NOT_YET_IMPLEMENTED`",
            "windows-x64 platform-support state",
        ),
        (
            "docs/platform/NATIVE_MESSAGING_MATRIX.md",
            "windows-x64",
            3,
            "`NOT_YET_IMPLEMENTED`",
            "windows-x64 native-messaging state",
        ),
        (
            "docs/platform/PACKAGING_UPDATE_MATRIX.md",
            "windows-x64",
            4,
            "`NOT_YET_IMPLEMENTED`",
            "windows-x64 packaging/update state",
        ),
    ],
)
def test_cross_platform_gate_rejects_stale_support_registers(
    repo_copy: Path,
    case: tuple[str, str, int, str, str],
) -> None:
    relative_path, platform, state_index, replacement, message = case
    prepare_gate_d_pass(repo_copy)
    _set_markdown_table_cell(
        repo_copy / relative_path, platform, state_index, replacement
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert message in result.stdout


def test_cross_platform_gate_rejects_placeholder_measured_result(
    repo_copy: Path,
) -> None:
    prepare_gate_d_pass(repo_copy)
    ledger = repo_copy / "docs" / "CRITICAL_GATES.md"
    text = ledger.read_text(encoding="utf-8")
    section_start = text.index("\n## CROSS_PLATFORM_CORE\n")
    prefix, section = text[:section_start], text[section_start:]
    next_section = section.index("\n## RESUME_PAGEFIT_FEASIBILITY\n")
    gate_d_section, remainder = section[:next_section], section[next_section:]
    assert "| PASS |" in gate_d_section
    gate_d_section = gate_d_section.replace("| PASS |", "| — |", 1)
    section = gate_d_section + remainder
    ledger.write_text(prefix + section, encoding="utf-8")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "placeholder Gate D measured results" in result.stdout


def test_cross_platform_gate_requires_m27_w12_decision_owner(
    repo_copy: Path,
) -> None:
    prepare_gate_d_pass(repo_copy)
    set_pkg_state(repo_copy, "M27-W12", "NOT_STARTED")
    set_current_package(repo_copy, "NONE")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "before decision package M27-W12 is started" in result.stdout
    assert "independent Gate D decision owner" in result.stdout


@pytest.mark.parametrize(
    ("old", "new", "message"),
    [
        (
            "- Owner decision: PASS (synthetic fixture)",
            "- Owner decision: REJECTED",
            "owner decision is not PASS",
        ),
        (
            "- Holdout result: PASS (synthetic fixture)",
            "- Holdout result: FAILED",
            "holdout result is not a passing result",
        ),
        (
            "- State: PASS\n- Evaluated revision:",
            "- State: NOT_EVALUATED\n- Evaluated revision:",
            "gate report state is 'NOT_EVALUATED', not PASS",
        ),
    ],
)
def test_cross_platform_gate_rejects_contradictory_report_records(
    repo_copy: Path, old: str, new: str, message: str
) -> None:
    prepare_gate_d_pass(repo_copy)
    report = repo_copy / "docs" / "gates" / "CROSS_PLATFORM_CORE_GATE.md"
    edit(report, old, new, count=1)
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert message in result.stdout


def test_cross_platform_gate_rejects_ledger_evidence_disagreement(
    repo_copy: Path,
) -> None:
    prepare_gate_d_pass(repo_copy)
    ledger = repo_copy / "docs" / "CRITICAL_GATES.md"
    text = ledger.read_text(encoding="utf-8")
    section_start = text.index("\n## CROSS_PLATFORM_CORE\n")
    prefix, section = text[:section_start], text[section_start:]
    section = section.replace(
        f"- Evaluated revision: {FAKE_TREE}",
        f"- Evaluated revision: tree {'f' * 40}",
        1,
    )
    ledger.write_text(prefix + section, encoding="utf-8")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "critical-gate ledger evaluated revision" in result.stdout


def test_safe_evidence_resolver_requires_requested_heading(tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    evidence = repo / "docs" / "gates" / "evidence" / "EVIDENCE.md"
    evidence.parent.mkdir(parents=True)
    evidence.write_text(
        "# Evidence\n\n## Recorded result\n\nResolved fixture.\n",
        encoding="utf-8",
    )
    assert (
        validate_status._evidence_reference_error(
            repo, "docs/gates/evidence/EVIDENCE.md § Recorded result"
        )
        is None
    )
    assert (
        validate_status._evidence_reference_error(
            repo, "docs/gates/evidence/EVIDENCE.md#recorded-result"
        )
        is None
    )
    assert (
        validate_status._evidence_reference_error(
            repo, "[artifact](docs/gates/evidence/EVIDENCE.md)"
        )
        is None
    )
    error = validate_status._evidence_reference_error(
        repo, "docs/gates/evidence/EVIDENCE.md § Missing result"
    )
    assert error is not None
    assert "does not exist" in error


def test_gate_state_mismatch_between_files_rejected(repo_copy: Path) -> None:
    set_status_gate_row(repo_copy, "RESUME_PAGEFIT_FEASIBILITY", "IN_PROGRESS")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "mismatch" in result.stdout


def _edit_ledger_section(repo: Path, gate: str, edit_fn: Callable[[str], str]) -> None:
    path = repo / "docs" / "CRITICAL_GATES.md"
    sections = path.read_text(encoding="utf-8").split("\n## ")
    for index, section in enumerate(sections):
        if section.startswith(gate):
            sections[index] = edit_fn(section)
            break
    else:
        pytest.fail(f"no CRITICAL_GATES.md section for {gate}")
    path.write_text("\n## ".join(sections), encoding="utf-8")


def test_ledger_missing_state_line_rejected(repo_copy: Path) -> None:
    """M00-W05 audit finding: a gate section without its '- State:' line must fail."""
    _edit_ledger_section(
        repo_copy,
        "AUTOFILL_FEASIBILITY",
        lambda s: re.sub(r"^- State: [A-Z_]+\n", "", s, count=1, flags=re.MULTILINE),
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "no '- State:' line" in result.stdout
    assert "AUTOFILL_FEASIBILITY" in result.stdout


def test_ledger_duplicate_state_line_rejected(repo_copy: Path) -> None:
    _edit_ledger_section(
        repo_copy,
        "RESUME_PAGEFIT_FEASIBILITY",
        lambda s: re.sub(
            r"^(- State: [A-Z_]+\n)",
            r"\g<1>\g<1>",
            s,
            count=1,
            flags=re.MULTILINE,
        ),
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "exactly one required" in result.stdout
    assert "RESUME_PAGEFIT_FEASIBILITY" in result.stdout


def test_ledger_missing_gate_section_rejected(repo_copy: Path) -> None:
    """Removing a gate's whole ledger section must fail even though the gate
    name still appears in the summary table (name needles alone are not
    sufficient)."""
    path = repo_copy / "docs" / "CRITICAL_GATES.md"
    sections = path.read_text(encoding="utf-8").split("\n## ")
    kept = [s for s in sections if not s.startswith("WORKDAY_GUIDED_PRE_SUBMIT")]
    assert len(kept) == len(sections) - 1
    path.write_text("\n## ".join(kept), encoding="utf-8")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "missing the '## WORKDAY_GUIDED_PRE_SUBMIT' section" in result.stdout


def test_ledger_unknown_gate_section_rejected(repo_copy: Path) -> None:
    path = repo_copy / "docs" / "CRITICAL_GATES.md"
    with path.open("a", encoding="utf-8") as handle:
        handle.write("\n## TOTALLY_FAKE_GATE\n\n- State: PASS\n")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "TOTALLY_FAKE_GATE" in result.stdout
    assert "unknown gate-like section" in result.stdout


def test_ledger_invalid_state_value_rejected(repo_copy: Path) -> None:
    _edit_ledger_section(
        repo_copy,
        "WORKDAY_GUIDED_PRE_SUBMIT",
        lambda s: s.replace("- State: NOT_EVALUATED", "- State: GREENISH", 1),
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "GREENISH" in result.stdout


# -------------------------------------------- gate-based readiness blocking


def test_m03_blocked_without_autofill_gate(repo_copy: Path) -> None:
    promote_milestones(repo_copy, ["M00", "M01", "M02"])
    set_fixture_gate_state(repo_copy, "AUTOFILL_FEASIBILITY", "NOT_EVALUATED")
    set_current_package(repo_copy, "NONE")
    set_ms_state(repo_copy, "M03", "READY")
    set_pkg_state(repo_copy, "M03-W01", "READY")
    set_next_ready(repo_copy, "`M03-W01`")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "AUTOFILL_FEASIBILITY" in result.stdout
    assert "PASS required" in result.stdout
    assert "dependency milestone" not in result.stdout


def test_m03_requires_m02_accepted_even_when_autofill_gate_passes(
    repo_copy: Path,
) -> None:
    promote_milestones(repo_copy, ["M00", "M01", "M02"])
    set_ms_state(repo_copy, "M02", "VERIFIED")
    pass_gate(repo_copy, "AUTOFILL_FEASIBILITY")
    set_current_package(repo_copy, "NONE")
    set_ms_state(repo_copy, "M03", "READY")
    set_pkg_state(repo_copy, "M03-W01", "READY")
    set_next_ready(repo_copy, "`M03-W01`")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "milestone M02" in result.stdout
    assert "ACCEPTED required" in result.stdout


def test_m06_blocked_without_resume_pagefit_gate(repo_copy: Path) -> None:
    promote_milestones(repo_copy, ["M00", "M01", "M02", "M03", "M04", "M05"])
    pass_gate(repo_copy, "AUTOFILL_FEASIBILITY")
    set_ms_state(repo_copy, "M06", "READY")
    set_pkg_state(repo_copy, "M06-W01", "READY")
    set_next_ready(repo_copy, "`M06-W01`")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "RESUME_PAGEFIT_FEASIBILITY" in result.stdout
    assert "PASS required" in result.stdout


def test_m06_requires_m05_accepted_even_when_pagefit_gate_passes(
    repo_copy: Path,
) -> None:
    promote_milestones(repo_copy, ["M00", "M01", "M02", "M03", "M04", "M05"])
    set_ms_state(repo_copy, "M05", "VERIFIED")
    pass_gate(repo_copy, "AUTOFILL_FEASIBILITY")
    pass_gate(repo_copy, "RESUME_PAGEFIT_FEASIBILITY")
    set_current_package(repo_copy, "NONE")
    set_ms_state(repo_copy, "M06", "READY")
    set_pkg_state(repo_copy, "M06-W01", "READY")
    set_next_ready(repo_copy, "`M06-W01`")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "milestone M05" in result.stdout
    assert "ACCEPTED required" in result.stdout


def test_m06_is_not_blocked_by_missing_windows_ubuntu_full_ai(
    repo_copy: Path,
) -> None:
    promote_milestones(repo_copy, [f"M{number:02d}" for number in range(6)])
    pass_gate(repo_copy, "AUTOFILL_FEASIBILITY")
    pass_gate(repo_copy, "RESUME_PAGEFIT_FEASIBILITY")
    set_current_package(repo_copy, "NONE")
    set_ms_state(repo_copy, "M06", "READY")
    set_pkg_state(repo_copy, "M06-W01", "READY")
    set_next_ready(repo_copy, "`M06-W01`")
    result = run_validator(repo_copy)
    assert result.returncode == 0, result.stdout + result.stderr


def test_m28_blocked_without_cross_platform_gate(repo_copy: Path) -> None:
    promote_milestones(repo_copy, [f"M{number:02d}" for number in range(28)])
    for gate in GATES[:3]:
        pass_gate(repo_copy, gate)
    set_current_package(repo_copy, "NONE")
    set_ms_state(repo_copy, "M28", "READY")
    set_pkg_state(repo_copy, "M28-W01", "READY")
    set_next_ready(repo_copy, "`M28-W01`")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "CROSS_PLATFORM_CORE" in result.stdout
    assert "PASS required" in result.stdout


def test_m28_blocked_without_m27_acceptance_even_when_gate_d_passes(
    repo_copy: Path,
) -> None:
    promote_milestones(repo_copy, [f"M{number:02d}" for number in range(27)])
    for gate in GATES:
        pass_gate(repo_copy, gate)
    accept_full_ai_profiles(repo_copy)
    set_current_package(repo_copy, "NONE")
    set_ms_state(repo_copy, "M28", "READY")
    set_pkg_state(repo_copy, "M28-W01", "READY")
    set_next_ready(repo_copy, "`M28-W01`")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "milestone M27" in result.stdout
    assert "ACCEPTED required" in result.stdout


def test_m27_w12_waits_for_w13_and_w14(repo_copy: Path) -> None:
    promote_milestones(repo_copy, [f"M{number:02d}" for number in range(27)])
    for number in range(1, 12):
        promote(repo_copy, f"M27-W{number:02d}")
    set_ms_state(repo_copy, "M27", "IN_PROGRESS")
    set_current_package(repo_copy, "NONE")
    set_pkg_state(repo_copy, "M27-W12", "READY")
    set_next_ready(repo_copy, "`M27-W12`")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert (
        "M27-W12 is READY but direct package prerequisite M27-W13 is 'NOT_STARTED'"
    ) in result.stdout
    assert (
        "M27-W12 is READY but direct package prerequisite M27-W14 is 'NOT_STARTED'"
    ) in result.stdout


def test_m28_accepts_gate_d_bound_to_final_m27_tree(repo_copy: Path) -> None:
    prepare_m28_ready(repo_copy)
    result = run_validator(repo_copy)
    assert result.returncode == 0, result.stdout + result.stderr


def test_m28_rejects_stale_gate_d_revision(repo_copy: Path) -> None:
    prepare_m28_ready(repo_copy, gate_d_revision=OTHER_FAKE_TREE)
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert (
        "M28 requires Gate D evaluated revision to equal the final accepted "
        "M27/M27-W12 content tree"
    ) in result.stdout


def test_m21_blocked_without_workday_gate_and_accepted_m19_m20(
    repo_copy: Path,
) -> None:
    mids = [f"M{n:02d}" for n in range(21)]
    promote_milestones(repo_copy, mids)
    set_ms_state(repo_copy, "M19", "VERIFIED")
    set_ms_state(repo_copy, "M20", "VERIFIED")
    pass_gate(repo_copy, "AUTOFILL_FEASIBILITY")
    pass_gate(repo_copy, "RESUME_PAGEFIT_FEASIBILITY")
    set_ms_state(repo_copy, "M21", "READY")
    set_pkg_state(repo_copy, "M21-W01", "READY")
    set_next_ready(repo_copy, "`M21-W01`")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "WORKDAY_GUIDED_PRE_SUBMIT" in result.stdout
    assert "PASS required" in result.stdout
    assert "ACCEPTED required" in result.stdout


# ------------------------------------------------- evidence preservation


@pytest.mark.parametrize(
    "package_id", sorted(validate_status.PRESERVED_PACKAGE_ANCHORS)
)
def test_dropped_preserved_revision_rejected(repo_copy: Path, package_id: str) -> None:
    path = status_path(repo_copy)
    text = path.read_text(encoding="utf-8")
    match = re.search(
        rf"^\| `{package_id}` \| VERIFIED \| (tree [0-9a-f]{{40}})",
        text,
        flags=re.MULTILINE,
    )
    assert match, f"{package_id} row must carry its verified tree revision"
    path.write_text(
        text[: match.start(1)] + "—" + text[match.end(1) :],
        encoding="utf-8",
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert package_id in result.stdout


def test_missing_evidence_heading_rejected(repo_copy: Path) -> None:
    evidence = repo_copy / "docs" / "TEST_EVIDENCE.md"
    text = evidence.read_text(encoding="utf-8")
    heading = "### M00-W02"
    assert heading in text
    evidence.write_text(text.replace(heading, "### removed"), encoding="utf-8")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "M00-W02" in result.stdout


def test_milestone_acceptance_allows_verified_package_rows(repo_copy: Path) -> None:
    prepare_m00_closeout(repo_copy, m01_ready=True)
    parsed = validate_status.parse_status(status_path(repo_copy))
    m00_rows = [row for row in parsed.package_rows if row[0].startswith("M00-")]
    assert all(row[1] == "VERIFIED" for row in m00_rows)
    result = run_validator(repo_copy)
    assert result.returncode == 0, result.stdout + result.stderr


# The owner waiver changes one documentary prerequisite only. These fixtures
# retain ordinary gate decisions, reviewers, numerical/safety and native proof.
def write_owner_holdout_waiver(repo: Path, *, status: str = "ACCEPTED") -> None:
    path = repo / "docs/DECISIONS.md"
    text = path.read_text(encoding="utf-8")
    text = re.sub(
        r"^### ADR-0006\b[^\n]*\n.*?(?=^##(?:#)? |\Z)",
        "",
        text,
        flags=re.MULTILINE | re.DOTALL,
    )
    section = (
        "### ADR-0006 — Continuous execution and owner-controlled holdout waiver\n\n"
        f"- Status: {status}\n"
        "- Date proposed / date decided: 2026-10-16 / 2026-10-16\n"
        '- Owner approval: direct instructions in this chat: "ignore instructions '
        'relating to stopping after each W is reached and validated"; "you do not '
        'need owner controlled holdout"; "i want you to keep working till this '
        'entire project is finished". The owner identified the working GitHub '
        "repository as jobapplyv2.\n"
        "- Decision: execute successive eligible packages without per-W stopping. "
        "Remove owner-controlled hidden holdout as a completion prerequisite across "
        "this project. Use accessible GitHub sources where they provide actual "
        "inputs or legacy comparison components. Preserve original manifests and "
        "historical evidence; never relabel a waiver as execution or PASS.\n\n"
    )
    marker = "## ADR template"
    assert marker in text
    path.write_text(text.replace(marker, section + marker, 1), encoding="utf-8")


def set_fixture_holdout_record(
    repo: Path, gate: str, value: str | None, *, location: str
) -> None:
    path = repo / (
        "docs/CRITICAL_GATES.md"
        if location == "ledger"
        else f"docs/gates/{gate}_GATE.md"
    )
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(r"^(?:- )?Holdout result:.*$", flags=re.MULTILINE)
    replacement = "" if value is None else f"- Holdout result: {value}"
    if location == "ledger":
        sections = text.split("\n## ")
        for index, section in enumerate(sections):
            if section.splitlines()[0] == gate:
                assert pattern.search(section)
                sections[index] = pattern.sub(replacement, section)
                break
        else:
            pytest.fail(f"no ledger section for {gate}")
        text = "\n## ".join(sections)
    else:
        assert pattern.search(text)
        text = pattern.sub(replacement, text)
    path.write_text(text, encoding="utf-8")


def prepare_owner_holdout_waiver_gate(repo: Path) -> None:
    write_owner_holdout_waiver(repo)
    prepare_gate_d_pass(repo)
    for location in ("ledger", "report"):
        set_fixture_holdout_record(
            repo, "CROSS_PLATFORM_CORE", "WAIVED_BY_OWNER_ADR_0006", location=location
        )


def assert_holdout_waiver_refused(repo: Path) -> None:
    result = run_validator(repo)
    assert result.returncode == 1, result.stdout + result.stderr
    assert "holdout result is not a passing result" in result.stdout


def test_owner_holdout_waiver_accepts_exact_accepted_decision(repo_copy: Path) -> None:
    prepare_owner_holdout_waiver_gate(repo_copy)
    for gate in GATES:
        for location in ("ledger", "report"):
            set_fixture_holdout_record(
                repo_copy, gate, "WAIVED_BY_OWNER_ADR_0006", location=location
            )
    assert validate_status._owner_holdout_waived(repo_copy)
    result = run_validator(repo_copy)
    assert result.returncode == 0, result.stdout + result.stderr


def test_owner_holdout_waiver_rejects_proposed_decision(repo_copy: Path) -> None:
    prepare_owner_holdout_waiver_gate(repo_copy)
    write_owner_holdout_waiver(repo_copy, status="PROPOSED")
    assert not validate_status._owner_holdout_waived(repo_copy)
    assert_holdout_waiver_refused(repo_copy)


def test_owner_holdout_waiver_rejects_missing_decision(repo_copy: Path) -> None:
    prepare_owner_holdout_waiver_gate(repo_copy)
    path = repo_copy / "docs/DECISIONS.md"
    text = re.sub(
        r"^### ADR-0006\b[^\n]*\n.*?(?=^##(?:#)? |\Z)",
        "",
        path.read_text(encoding="utf-8"),
        flags=re.MULTILINE | re.DOTALL,
    )
    path.write_text(text, encoding="utf-8")
    assert not validate_status._owner_holdout_waived(repo_copy)
    assert_holdout_waiver_refused(repo_copy)


def test_owner_holdout_waiver_rejects_missing_owner_quote(repo_copy: Path) -> None:
    prepare_owner_holdout_waiver_gate(repo_copy)
    edit(
        repo_copy / "docs/DECISIONS.md",
        '"you do not need owner controlled holdout"',
        '"owner approval pending"',
        count=1,
    )
    assert not validate_status._owner_holdout_waived(repo_copy)
    assert_holdout_waiver_refused(repo_copy)


def test_owner_holdout_waiver_rejects_missing_waiver_scope(repo_copy: Path) -> None:
    prepare_owner_holdout_waiver_gate(repo_copy)
    edit(
        repo_copy / "docs/DECISIONS.md",
        "Remove owner-controlled hidden holdout as a completion prerequisite "
        "across this project.",
        "Retain owner-controlled hidden holdout as a completion prerequisite "
        "across this project.",
        count=1,
    )
    assert not validate_status._owner_holdout_waived(repo_copy)
    assert_holdout_waiver_refused(repo_copy)


def test_owner_holdout_waiver_rejects_ambiguous_decision(repo_copy: Path) -> None:
    prepare_owner_holdout_waiver_gate(repo_copy)
    path = repo_copy / "docs/DECISIONS.md"
    with path.open("a", encoding="utf-8") as handle:
        handle.write("\n### ADR-0006 — Another decision\n- Status: ACCEPTED\n")
    assert not validate_status._owner_holdout_waived(repo_copy)
    assert_holdout_waiver_refused(repo_copy)


def test_owner_holdout_waiver_rejects_fabricated_tokens(repo_copy: Path) -> None:
    prepare_owner_holdout_waiver_gate(repo_copy)
    for token in (
        "WAIVED_BY_OWNER",
        "WAIVED_BY_OWNER_ADR_0005",
        "waived_by_owner_adr_0006",
        "WAIVED_BY_OWNER_ADR_0006 fabricated execution",
        "PASS WAIVED_BY_OWNER_ADR_0006",
    ):
        for location in ("ledger", "report"):
            set_fixture_holdout_record(
                repo_copy, "CROSS_PLATFORM_CORE", token, location=location
            )
        assert_holdout_waiver_refused(repo_copy)


def test_owner_holdout_waiver_rejects_one_sided_records(repo_copy: Path) -> None:
    prepare_owner_holdout_waiver_gate(repo_copy)
    for waived_location in ("ledger", "report"):
        for location in ("ledger", "report"):
            set_fixture_holdout_record(
                repo_copy,
                "CROSS_PLATFORM_CORE",
                "WAIVED_BY_OWNER_ADR_0006" if location == waived_location else "PASS",
                location=location,
            )
        assert_holdout_waiver_refused(repo_copy)


def test_owner_holdout_waiver_rejects_ordinary_missing_results(repo_copy: Path) -> None:
    prepare_owner_holdout_waiver_gate(repo_copy)
    for value in ("pending", "UNAVAILABLE", "", None):
        for location in ("ledger", "report"):
            if value is None:
                # Restore a declared field before deliberately removing it.
                set_fixture_holdout_record(
                    repo_copy, "CROSS_PLATFORM_CORE", "pending", location=location
                )
            set_fixture_holdout_record(
                repo_copy, "CROSS_PLATFORM_CORE", value, location=location
            )
        assert_holdout_waiver_refused(repo_copy)


def test_owner_holdout_waiver_keeps_independent_review_required(
    repo_copy: Path,
) -> None:
    prepare_owner_holdout_waiver_gate(repo_copy)
    report = repo_copy / "docs/gates/CROSS_PLATFORM_CORE_GATE.md"
    text = re.sub(
        r"^- Independent reviewer:.*$",
        "- Independent reviewer: pending",
        report.read_text(encoding="utf-8"),
        flags=re.MULTILINE,
    )
    report.write_text(text, encoding="utf-8")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "independent reviewer" in result.stdout


def test_owner_holdout_waiver_keeps_owner_decision_required(repo_copy: Path) -> None:
    prepare_owner_holdout_waiver_gate(repo_copy)
    report = repo_copy / "docs/gates/CROSS_PLATFORM_CORE_GATE.md"
    text = re.sub(
        r"^- Owner decision:.*$",
        "- Owner decision: REJECTED",
        report.read_text(encoding="utf-8"),
        flags=re.MULTILINE,
    )
    report.write_text(text, encoding="utf-8")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "owner decision is not PASS" in result.stdout


def test_owner_holdout_waiver_keeps_native_evidence_required(repo_copy: Path) -> None:
    prepare_owner_holdout_waiver_gate(repo_copy)
    _set_markdown_table_cell(
        repo_copy / "docs/platform/MODEL_RUNTIME_PROFILES.md",
        "windows-x64",
        1,
        "`NOT_YET_IMPLEMENTED`",
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "windows-x64 lacks CERTIFIED_FULL/ACCEPTED" in result.stdout


def test_owner_holdout_waiver_keeps_zero_tolerance_required(repo_copy: Path) -> None:
    prepare_owner_holdout_waiver_gate(repo_copy)
    ledger = repo_copy / "docs/CRITICAL_GATES.md"
    sections = ledger.read_text(encoding="utf-8").split("\n## ")
    for index, section in enumerate(sections):
        if section.splitlines()[0] == "CROSS_PLATFORM_CORE":
            sections[index] = section.replace(
                "- Zero-tolerance failures observed: 0",
                "- Zero-tolerance failures observed: 1",
                1,
            )
            break
    ledger.write_text("\n## ".join(sections), encoding="utf-8")
    result = run_validator(repo_copy)
    assert result.returncode == 1
    assert "does not record zero Gate D zero-tolerance failures" in result.stdout


def test_historical_boundary_removes_only_later_w14_findings(repo_copy: Path) -> None:
    activate_corrective_blockers(repo_copy)
    for issue_id in CURRENT_M02_W14_CORRECTIVE_ISSUE_IDS:
        set_issue_state(repo_copy, issue_id, "IN_PROGRESS")
    set_live_blockers(
        repo_copy,
        [
            *CURRENT_BLOCKER_LINES,
            "- KI-0077 (HIGH, IN_PROGRESS) — synthetic later timing finding",
            "- KI-0078 (HIGH, IN_PROGRESS) — synthetic later locale finding",
            "- KI-0079 (HIGH, IN_PROGRESS) — synthetic later ownership finding",
            "- KI-0080 (HIGH, IN_PROGRESS) — synthetic later observation finding",
            "- KI-0081 (HIGH, IN_PROGRESS) — synthetic later option-binding finding",
            (
                "- KI-0082 (HIGH, IN_PROGRESS) — synthetic later "
                "topology-accounting finding"
            ),
            "- KI-0083 (HIGH, IN_PROGRESS) — synthetic later native-property finding",
            "- KI-0084 (HIGH, IN_PROGRESS) — synthetic later source finding",
            "- KI-0085 (HIGH, IN_PROGRESS) — synthetic later collision finding",
            "- KI-0086 (HIGH, IN_PROGRESS) — synthetic later freshness finding",
            "- KI-0087 (HIGH, IN_PROGRESS) — synthetic later fixture finding",
            "- KI-0088 (HIGH, IN_PROGRESS) — synthetic later observation finding",
            "- KI-0089 (HIGH, IN_PROGRESS) — synthetic later external evidence gap",
            "- KI-0090 (HIGH, IN_PROGRESS) — synthetic later Windows compiler finding",
            "- KI-0091 (HIGH, IN_PROGRESS) — synthetic later native validity finding",
            "- KI-0092 (HIGH, IN_PROGRESS) — synthetic later reporting finding",
            "- KI-0093 (HIGH, IN_PROGRESS) — synthetic later encoding finding",
            "- KI-0094 (HIGH, IN_PROGRESS) — synthetic later focus-value finding",
            "- KI-0095 (HIGH, IN_PROGRESS) — synthetic later fixture-capacity finding",
            "- KI-0096 (HIGH, IN_PROGRESS) — synthetic later metadata timing finding",
        ],
    )
    reset_downstream(repo_copy, after_package="M01-W07", after_milestone="M01")
    issues = validate_status.parse_known_issues(
        repo_copy / "docs/KNOWN_ISSUES.md", validate_status.Report()
    )
    for issue_id in CURRENT_M02_W14_CORRECTIVE_ISSUE_IDS:
        assert issues[issue_id].state == "FIXED"
    for issue_id in CORRECTIVE_BLOCKER_IDS:
        assert issues[issue_id].state == "IN_PROGRESS"
    result = run_validator(repo_copy)
    assert result.returncode == 0, result.stdout + result.stderr


def test_w14_boundary_preserves_current_campaign_findings(repo_copy: Path) -> None:
    for issue_id in CURRENT_M02_W14_CORRECTIVE_ISSUE_IDS:
        set_issue_state(repo_copy, issue_id, "IN_PROGRESS")
    set_live_blockers(
        repo_copy,
        [
            "- KI-0077 (HIGH, IN_PROGRESS) — synthetic current timing finding",
            "- KI-0078 (HIGH, IN_PROGRESS) — synthetic current locale finding",
            "- KI-0079 (HIGH, IN_PROGRESS) — synthetic current ownership finding",
            "- KI-0080 (HIGH, IN_PROGRESS) — synthetic current observation finding",
            "- KI-0081 (HIGH, IN_PROGRESS) — synthetic current option-binding finding",
            (
                "- KI-0082 (HIGH, IN_PROGRESS) — synthetic current "
                "topology-accounting finding"
            ),
            "- KI-0083 (HIGH, IN_PROGRESS) — synthetic current native-property finding",
            "- KI-0084 (HIGH, IN_PROGRESS) — synthetic current source finding",
            "- KI-0085 (HIGH, IN_PROGRESS) — synthetic current collision finding",
            "- KI-0086 (HIGH, IN_PROGRESS) — synthetic current freshness finding",
            "- KI-0087 (HIGH, IN_PROGRESS) — synthetic current fixture finding",
            "- KI-0088 (HIGH, IN_PROGRESS) — synthetic current observation finding",
            "- KI-0089 (HIGH, IN_PROGRESS) — synthetic current external evidence gap",
            "- KI-0090 (HIGH, IN_PROGRESS) — synthetic current Windows compiler issue",
            "- KI-0091 (HIGH, IN_PROGRESS) — synthetic current native validity issue",
            "- KI-0092 (HIGH, IN_PROGRESS) — synthetic current reporting issue",
            "- KI-0093 (HIGH, IN_PROGRESS) — synthetic current encoding issue",
            "- KI-0094 (HIGH, IN_PROGRESS) — synthetic current focus-value issue",
            "- KI-0095 (HIGH, IN_PROGRESS) — synthetic current fixture-capacity issue",
            "- KI-0096 (HIGH, IN_PROGRESS) — synthetic current metadata timing issue",
        ],
    )
    reset_downstream(repo_copy, after_package="M02-W14", after_milestone="M02")
    issues = validate_status.parse_known_issues(
        repo_copy / "docs/KNOWN_ISSUES.md", validate_status.Report()
    )
    for issue_id in CURRENT_M02_W14_CORRECTIVE_ISSUE_IDS:
        assert issues[issue_id].state == "IN_PROGRESS"
    status = status_path(repo_copy).read_text(encoding="utf-8")
    for issue_id in CURRENT_M02_W14_CORRECTIVE_ISSUE_IDS:
        assert f"- {issue_id} (HIGH, IN_PROGRESS)" in status


def _typed_waiver_pair(repo: Path) -> tuple[dict[str, object], dict[str, object]]:
    """Source authority is separate from the canonical typed gate verdict."""
    digest = validate_status._owner_holdout_waiver_digest(repo)
    assert digest is not None
    assessment: dict[str, object] = {
        "state": "WAIVED_BY_OWNER_ADR_0006",
        "execution_performed": False,
        "owner_waiver": {
            "adr_ref": "ADR-0006",
            "owner_decision_ref": "OD-035",
            "source_document_ref": "docs/DECISIONS.md",
            "source_record_digest": digest,
        },
    }
    identity: dict[str, object] = {
        "gate_id": "AUTOFILL_FEASIBILITY",
        "candidate_commit": "0" * 40,
        "candidate_tree": "1" * 40,
        "evidence_bundle_digest": FAKE_EVIDENCE_HASH,
        "holdout_assessment": assessment,
    }
    return (
        {**identity, "completeness_inventory": {"holdout_valid": False}},
        {**identity, "threshold_evidence_summary": {"holdout_valid": False}},
    )


def _typed_waiver_authority_problems(
    repo: Path,
    bundle: dict[str, object],
    decision: dict[str, object],
    ledger: str = "Holdout result: WAIVED_BY_OWNER_ADR_0006",
    report: str = "Holdout result: WAIVED_BY_OWNER_ADR_0006",
) -> list[str]:
    return validate_status.gate_holdout_authority_v2_problems(
        repo, bundle, decision, ledger, report
    )


@pytest.mark.parametrize("gate_id", GATES)
def test_gate_v2_waiver_binds_accepted_owner_record_all_gates(
    repo_copy: Path, gate_id: str
) -> None:
    bundle, decision = _typed_waiver_pair(repo_copy)
    bundle["gate_id"] = decision["gate_id"] = gate_id
    assert _typed_waiver_authority_problems(repo_copy, bundle, decision) == []
    assert bundle["completeness_inventory"] == {"holdout_valid": False}
    assert decision["threshold_evidence_summary"] == {"holdout_valid": False}


@pytest.mark.parametrize("state", ["PROPOSED", "REJECTED", "SUPERSEDED"])
def test_gate_v2_waiver_refuses_unaccepted_adr(repo_copy: Path, state: str) -> None:
    bundle, decision = _typed_waiver_pair(repo_copy)
    path = repo_copy / "docs/DECISIONS.md"
    text = path.read_text(encoding="utf-8")
    heading = validate_status.OWNER_HOLDOUT_WAIVER_HEADING
    prefix, section = text.split(heading, 1)
    path.write_text(
        prefix
        + heading
        + section.replace("- Status: ACCEPTED", f"- Status: {state}", 1),
        encoding="utf-8",
    )
    assert _typed_waiver_authority_problems(repo_copy, bundle, decision)


def test_gate_v2_waiver_refuses_missing_adr(repo_copy: Path) -> None:
    bundle, decision = _typed_waiver_pair(repo_copy)
    (repo_copy / "docs/DECISIONS.md").unlink()
    assert _typed_waiver_authority_problems(repo_copy, bundle, decision)


def test_gate_v2_waiver_refuses_fabricated_record_digest(repo_copy: Path) -> None:
    bundle, decision = _typed_waiver_pair(repo_copy)
    assessment = bundle["holdout_assessment"]
    assert isinstance(assessment, dict)
    assessment["owner_waiver"]["source_record_digest"] = FAKE_EVIDENCE_HASH
    assert _typed_waiver_authority_problems(repo_copy, bundle, decision)


def test_gate_v2_waiver_refuses_changed_own_record_preimage(repo_copy: Path) -> None:
    bundle, decision = _typed_waiver_pair(repo_copy)
    path = repo_copy / "docs/DECISIONS.md"
    text = path.read_text(encoding="utf-8")
    heading = validate_status.OWNER_HOLDOUT_WAIVER_HEADING
    path.write_text(
        text.replace(
            heading + "\n", heading + "\n\n- Additional accepted-record context.\n", 1
        ),
        encoding="utf-8",
    )
    assert validate_status._owner_holdout_waived(repo_copy)
    assert _typed_waiver_authority_problems(repo_copy, bundle, decision)


def test_gate_v2_waiver_ignores_unrelated_later_adr(repo_copy: Path) -> None:
    bundle, decision = _typed_waiver_pair(repo_copy)
    before = validate_status._owner_holdout_waiver_digest(repo_copy)
    path = repo_copy / "docs/DECISIONS.md"
    text = path.read_text(encoding="utf-8")
    path.write_text(
        text.replace(
            "## ADR template",
            "### ADR-9999 — Unrelated synthetic later decision\n\n"
            "- Status: PROPOSED\n\n## ADR template",
            1,
        ),
        encoding="utf-8",
    )
    assert validate_status._owner_holdout_waiver_digest(repo_copy) == before
    assert _typed_waiver_authority_problems(repo_copy, bundle, decision) == []


@pytest.mark.parametrize("change", ["missing", "duplicate", "proposed"])
def test_gate_v2_waiver_refuses_invalid_owner_decision_row(
    repo_copy: Path, change: str
) -> None:
    bundle, decision = _typed_waiver_pair(repo_copy)
    path = repo_copy / "docs/DECISIONS.md"
    row = validate_status.OWNER_HOLDOUT_WAIVER_OWNER_ROW
    replacement = (
        ""
        if change == "missing"
        else row + "\n" + row
        if change == "duplicate"
        else row.replace("| ACCEPTED |", "| PROPOSED |")
    )
    path.write_text(
        path.read_text(encoding="utf-8").replace(row, replacement, 1), encoding="utf-8"
    )
    assert _typed_waiver_authority_problems(repo_copy, bundle, decision)


@pytest.mark.parametrize(
    "key", ["gate_id", "candidate_commit", "candidate_tree", "evidence_bundle_digest"]
)
def test_gate_v2_waiver_refuses_unpaired_artifact_identity(
    repo_copy: Path, key: str
) -> None:
    bundle, decision = _typed_waiver_pair(repo_copy)
    decision[key] = "different"
    assert _typed_waiver_authority_problems(repo_copy, bundle, decision)


@pytest.mark.parametrize("side", ["bundle", "decision"])
def test_gate_v2_waiver_refuses_claimed_holdout_valid(
    repo_copy: Path, side: str
) -> None:
    bundle, decision = _typed_waiver_pair(repo_copy)
    if side == "bundle":
        bundle["completeness_inventory"] = {"holdout_valid": True}
    else:
        decision["threshold_evidence_summary"] = {"holdout_valid": True}
    assert _typed_waiver_authority_problems(repo_copy, bundle, decision)


@pytest.mark.parametrize("mutation", ["executed", "result-ref", "unknown-owner-ref"])
def test_gate_v2_waiver_refuses_execution_or_other_owner_authority(
    repo_copy: Path, mutation: str
) -> None:
    bundle, decision = _typed_waiver_pair(repo_copy)
    assessment = bundle["holdout_assessment"]
    assert isinstance(assessment, dict)
    if mutation == "executed":
        assessment["execution_performed"] = True
    elif mutation == "result-ref":
        assessment["execution_result_ref"] = "result_0123456789ABCDEFGHJKMNPQRS"
    else:
        assessment["owner_waiver"]["owner_decision_ref"] = "OD-036"
    assert _typed_waiver_authority_problems(repo_copy, bundle, decision)


@pytest.mark.parametrize("token", ["PENDING", "UNAVAILABLE", "WAIVED_BY_OWNER", "PASS"])
def test_gate_v2_waiver_refuses_unpaired_or_execution_tokens(
    repo_copy: Path, token: str
) -> None:
    bundle, decision = _typed_waiver_pair(repo_copy)
    assert _typed_waiver_authority_problems(
        repo_copy, bundle, decision, report=f"Holdout result: {token}"
    )


def test_gate_v2_waiver_refuses_mismatched_assessments(repo_copy: Path) -> None:
    bundle, decision = _typed_waiver_pair(repo_copy)
    decision["holdout_assessment"] = {
        "state": "NOT_EXECUTED",
        "execution_performed": False,
    }
    assert _typed_waiver_authority_problems(repo_copy, bundle, decision)


def test_gate_v2_waiver_cannot_relabel_both_records_as_execution_pass(
    repo_copy: Path,
) -> None:
    bundle, decision = _typed_waiver_pair(repo_copy)
    assert _typed_waiver_authority_problems(
        repo_copy,
        bundle,
        decision,
        ledger="Holdout result: PASS",
        report="Holdout result: PASS",
    )


# ADR-0007 changes only two explicitly named evidence-source prerequisites.
EVIDENCE_SCOPE_AUTHORITY_FIXTURE = {
    "heading": (
        "### ADR-0007 — Direct Simplify comparison and executed public-form "
        "evidence waiver"
    ),
    "owner_row": (
        "| OD-036 | Waive direct Simplify comparison and executed "
        "public-form evidence throughout the project; preserve all other "
        "completion, safety, measurement and review requirements. Continue "
        "until the project is finished and validated. | ACCEPTED | Owner "
        "message 2026-10-17; ADR-0007 |"
    ),
    "approval": (
        "- Owner approval: direct instruction in this chat on 2026-10-17: "
        '"Waive the Simplify comparison and public-form evidence '
        "requirements too. Keep going through all remaining milestones "
        'until the entire project is finished and validated."'
    ),
    "decision": (
        "- Decision: remove direct Simplify comparison and executed "
        "public-form evidence as completion prerequisites throughout this "
        "project. Record the affected requirements as WAIVED_BY_OWNER under "
        "OD-036 / ADR-0007; preserve actual historical outcomes and never "
        "relabel nonexecution as PASS. Continue successive eligible "
        "packages under ADR-0006 without per-W stopping. Numerical "
        "accuracy, safety and performance thresholds, controlled-corpus "
        "execution, native-platform proof, independent review, other "
        "comparison baselines, product capabilities, actual usability, "
        "accessibility, visual approval and all other non-comparison "
        "requirements remain binding. This decision grants no public ATS "
        "support, superiority claim or final gate verdict."
    ),
    "scope": (
        "- Waiver scope: DIRECT_SIMPLIFY_COMPARISON and "
        "EXECUTED_PUBLIC_FORM_EVIDENCE only, project-wide. Only the "
        "directly comparative Simplify component of a mixed requirement is "
        "waived; public-form evidence means execution-based validation on "
        "third-party public application forms, including public "
        "no-submit/dry-run requirements. Other components remain required. "
        "Public UI-reference observation, actual Simplify-experienced-user "
        "task studies, accessibility, visual approval and "
        "originality/non-affiliation requirements are not waived."
    ),
}

EVIDENCE_SCOPE_LABELS = {
    "DIRECT_SIMPLIFY_COMPARISON": "Simplify comparison result",
    "EXECUTED_PUBLIC_FORM_EVIDENCE": "Public-form evidence result",
}
EVIDENCE_SCOPE_WAIVER_RESULT = "WAIVED_BY_OWNER_ADR_0007"


def write_owner_evidence_scope_waiver(repo: Path, *, status: str = "ACCEPTED") -> None:
    path = repo / "docs/DECISIONS.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    text = path.read_text(encoding="utf-8") if path.is_file() else "# Decisions\n"
    text = re.sub(r"^\| OD-036 \|.*\n?", "", text, flags=re.MULTILINE)
    text = re.sub(
        r"^### ADR-0007\b[^\n]*\n.*?(?=^##(?:#)? |\Z)",
        "",
        text,
        flags=re.MULTILINE | re.DOTALL,
    )
    record = (
        EVIDENCE_SCOPE_AUTHORITY_FIXTURE["owner_row"]
        + "\n\n"
        + EVIDENCE_SCOPE_AUTHORITY_FIXTURE["heading"]
        + f"\n\n- Status: {status}\n"
        + "\n".join(
            EVIDENCE_SCOPE_AUTHORITY_FIXTURE[key]
            for key in ("approval", "decision", "scope")
        )
        + "\n"
    )
    path.write_text(text.rstrip("\n") + "\n\n" + record, encoding="utf-8")


def evidence_scope_records(
    *scopes: str, token: str = EVIDENCE_SCOPE_WAIVER_RESULT
) -> str:
    selected = scopes or tuple(EVIDENCE_SCOPE_LABELS)
    return "\n".join(f"- {EVIDENCE_SCOPE_LABELS[scope]}: {token}" for scope in selected)


def install_gate_evidence_scope_records(repo: Path, gate: str, value: str) -> None:
    pattern = r"^(?:- )?(?:Simplify comparison|Public-form evidence) result:.*\n?"
    ledger = repo / "docs/CRITICAL_GATES.md"
    sections = ledger.read_text(encoding="utf-8").split("\n## ")
    for index, section in enumerate(sections):
        if section.splitlines()[0] == gate:
            updated_section = re.sub(pattern, "", section, flags=re.MULTILINE)
            sections[index] = updated_section.rstrip("\n") + "\n" + value + "\n"
            break
    else:
        pytest.fail(f"missing gate fixture section: {gate}")
    ledger.write_text("\n## ".join(sections), encoding="utf-8")
    report = repo / f"docs/gates/{gate}_GATE.md"
    text = re.sub(pattern, "", report.read_text(encoding="utf-8"), flags=re.MULTILINE)
    report.write_text(text.rstrip("\n") + "\n" + value + "\n", encoding="utf-8")


def test_owner_evidence_waiver_claims_require_recorded_authority(
    repo_copy: Path,
) -> None:
    path = repo_copy / "docs/DECISIONS.md"
    text = re.sub(
        r"^### ADR-0007\b[^\n]*\n.*?(?=^##(?:#)? |\Z)",
        "",
        path.read_text(encoding="utf-8"),
        flags=re.MULTILINE | re.DOTALL,
    )
    text = re.sub(r"^\| OD-036 \|.*\n?", "", text, flags=re.MULTILINE)
    path.write_text(text, encoding="utf-8")
    install_gate_evidence_scope_records(
        repo_copy, "AUTOFILL_FEASIBILITY", evidence_scope_records()
    )
    result = run_validator(repo_copy)
    assert result.returncode == 1, result.stdout + result.stderr
    assert (
        "evidence-source waiver lacks exact accepted owner authority" in result.stdout
    )


def test_owner_evidence_waiver_cannot_substitute_native_metrics(tmp_path: Path) -> None:
    write_owner_evidence_scope_waiver(tmp_path)
    text = (
        "### Metric table\n"
        "| Dimension | Threshold | Measured |\n"
        "|---|---|---|\n"
        f"| Native startup | 1000ms | {EVIDENCE_SCOPE_WAIVER_RESULT} |\n"
        "- Zero-tolerance failures observed: 0\n"
    )
    assert validate_status._gate_d_metric_problems(text)


def test_owner_evidence_waiver_accepts_closed_paired_scopes(tmp_path: Path) -> None:
    write_owner_evidence_scope_waiver(tmp_path)
    for scope in EVIDENCE_SCOPE_LABELS:
        assert validate_status._owner_evidence_scope_waived(tmp_path, scope)
    records = evidence_scope_records("DIRECT_SIMPLIFY_COMPARISON")
    assert not validate_status._gate_evidence_scope_waiver_problems(
        tmp_path, records, records, gate="RESUME_PAGEFIT_FEASIBILITY"
    )
    records = evidence_scope_records()
    assert not validate_status._gate_evidence_scope_waiver_problems(
        tmp_path, records, records
    )
    for gate in ("AUTOFILL_FEASIBILITY", "WORKDAY_GUIDED_PRE_SUBMIT"):
        incomplete = evidence_scope_records("DIRECT_SIMPLIFY_COMPARISON")
        assert validate_status._gate_evidence_scope_waiver_problems(
            tmp_path, incomplete, incomplete, gate=gate
        )
    for scope in ("NATIVE_PLATFORM_PROOF", "INDEPENDENT_REVIEW", "SAFETY", "ALL"):
        assert not validate_status._owner_evidence_scope_waived(tmp_path, scope)


@pytest.mark.parametrize("status", ["PROPOSED", "REJECTED", "SUPERSEDED"])
def test_owner_evidence_waiver_refuses_unaccepted_record(
    tmp_path: Path, status: str
) -> None:
    write_owner_evidence_scope_waiver(tmp_path, status=status)
    records = evidence_scope_records()
    assert validate_status._gate_evidence_scope_waiver_problems(
        tmp_path, records, records
    )


@pytest.mark.parametrize(
    "part", ["owner_row", "heading", "approval", "decision", "scope", "status"]
)
def test_owner_evidence_waiver_refuses_missing_or_changed_authority(
    tmp_path: Path, part: str
) -> None:
    write_owner_evidence_scope_waiver(tmp_path)
    path = tmp_path / "docs/DECISIONS.md"
    old = (
        "- Status: ACCEPTED"
        if part == "status"
        else EVIDENCE_SCOPE_AUTHORITY_FIXTURE[part]
    )
    edit(path, old, "- removed or changed authority", count=1)
    records = evidence_scope_records()
    assert validate_status._gate_evidence_scope_waiver_problems(
        tmp_path, records, records
    )


@pytest.mark.parametrize(
    "part", ["owner_row", "heading", "approval", "decision", "scope"]
)
def test_owner_evidence_waiver_refuses_ambiguous_authority(
    tmp_path: Path, part: str
) -> None:
    write_owner_evidence_scope_waiver(tmp_path)
    path = tmp_path / "docs/DECISIONS.md"
    with path.open("a", encoding="utf-8") as handle:
        handle.write(EVIDENCE_SCOPE_AUTHORITY_FIXTURE[part] + "\n")
    records = evidence_scope_records()
    assert validate_status._gate_evidence_scope_waiver_problems(
        tmp_path, records, records
    )


@pytest.mark.parametrize(
    "token",
    [
        "WAIVED_BY_OWNER",
        "WAIVED_BY_OWNER_ADR_0006",
        "WAIVED_BY_OWNER_ADR_0008",
        "waived_by_owner_adr_0007",
        "PASS WAIVED_BY_OWNER_ADR_0007",
        "WAIVED_BY_OWNER_ADR_0007 executed",
        "PENDING",
        "UNAVAILABLE",
    ],
)
def test_owner_evidence_waiver_refuses_forged_or_unpaired_tokens(
    tmp_path: Path, token: str
) -> None:
    write_owner_evidence_scope_waiver(tmp_path)
    assert validate_status._gate_evidence_scope_waiver_problems(
        tmp_path, evidence_scope_records(), evidence_scope_records(token=token)
    )


def test_owner_evidence_waiver_refuses_missing_duplicate_and_expanded_fields(
    tmp_path: Path,
) -> None:
    write_owner_evidence_scope_waiver(tmp_path)
    records = evidence_scope_records()
    for bad in (
        "",
        evidence_scope_records("DIRECT_SIMPLIFY_COMPARISON"),
        records + "\n" + evidence_scope_records("DIRECT_SIMPLIFY_COMPARISON"),
        records + f"\n- Native platform proof result: {EVIDENCE_SCOPE_WAIVER_RESULT}",
    ):
        assert validate_status._gate_evidence_scope_waiver_problems(
            tmp_path, records, bad
        )


def test_owner_evidence_waiver_absence_never_claims_authority(tmp_path: Path) -> None:
    assert not validate_status._gate_evidence_scope_waiver_problems(
        tmp_path, "ordinary evidence pending", "ordinary evidence pending"
    )
    assert not validate_status._owner_evidence_scope_waived(
        tmp_path, "DIRECT_SIMPLIFY_COMPARISON"
    )


@pytest.mark.parametrize("source_state", ["missing", "directory", "invalid_utf8"])
def test_owner_evidence_waiver_refuses_unreadable_source(
    tmp_path: Path, source_state: str
) -> None:
    write_owner_evidence_scope_waiver(tmp_path)
    path = tmp_path / "docs/DECISIONS.md"
    path.unlink()
    if source_state == "directory":
        path.mkdir()
    elif source_state == "invalid_utf8":
        path.write_bytes(b"\xff")
    records = evidence_scope_records()
    assert validate_status._gate_evidence_scope_waiver_problems(
        tmp_path, records, records
    )


@pytest.mark.parametrize("link_component", ["docs", "DECISIONS.md"])
def test_owner_evidence_waiver_refuses_symlink_metadata(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, link_component: str
) -> None:
    write_owner_evidence_scope_waiver(tmp_path)
    original = Path.is_symlink

    def reported_link(path: Path) -> bool:
        return path.name == link_component or original(path)

    monkeypatch.setattr(Path, "is_symlink", reported_link)
    records = evidence_scope_records()
    assert validate_status._gate_evidence_scope_waiver_problems(
        tmp_path, records, records
    )


def test_owner_evidence_waiver_record_digest_is_local_and_holdout_unchanged(
    repo_copy: Path,
) -> None:
    before_holdout = validate_status._owner_holdout_waiver_digest(repo_copy)
    assert before_holdout
    write_owner_evidence_scope_waiver(repo_copy)
    before = validate_status._owner_evidence_scope_waiver_digest(repo_copy)
    assert before
    path = repo_copy / "docs/DECISIONS.md"
    with path.open("a", encoding="utf-8") as handle:
        handle.write("\n### ADR-9999 — Unrelated future record\n- Status: PROPOSED\n")
    assert validate_status._owner_evidence_scope_waiver_digest(repo_copy) == before
    assert validate_status._owner_holdout_waiver_digest(repo_copy) == before_holdout
    edit(path, EVIDENCE_SCOPE_AUTHORITY_FIXTURE["scope"], "- Waiver scope: ALL")
    assert validate_status._owner_evidence_scope_waiver_digest(repo_copy) is None


def test_owner_evidence_waiver_does_not_promote_current_gate(repo_copy: Path) -> None:
    write_owner_evidence_scope_waiver(repo_copy)
    install_gate_evidence_scope_records(
        repo_copy, "AUTOFILL_FEASIBILITY", evidence_scope_records()
    )
    before = status_path(repo_copy).read_bytes()
    result = run_validator(repo_copy)
    assert result.returncode == 0, result.stdout + result.stderr
    assert status_path(repo_copy).read_bytes() == before


@pytest.mark.parametrize("missing", ["reviewer", "owner", "native", "safety"])
def test_owner_evidence_waiver_preserves_other_gate_prerequisites(
    repo_copy: Path, missing: str
) -> None:
    prepare_owner_holdout_waiver_gate(repo_copy)
    write_owner_evidence_scope_waiver(repo_copy)
    for gate in ("AUTOFILL_FEASIBILITY", "WORKDAY_GUIDED_PRE_SUBMIT"):
        install_gate_evidence_scope_records(repo_copy, gate, evidence_scope_records())
    install_gate_evidence_scope_records(
        repo_copy,
        "RESUME_PAGEFIT_FEASIBILITY",
        evidence_scope_records("DIRECT_SIMPLIFY_COMPARISON"),
    )
    baseline = run_validator(repo_copy)
    assert baseline.returncode == 0, baseline.stdout + baseline.stderr
    report = repo_copy / "docs/gates/CROSS_PLATFORM_CORE_GATE.md"
    if missing == "reviewer":
        edit(
            report,
            f"- Independent reviewer: {FAKE_REVIEWER}",
            "- Independent reviewer: pending",
        )
    elif missing == "owner":
        edit(
            report,
            "- Owner decision: PASS (synthetic fixture)",
            "- Owner decision: REJECTED",
        )
    elif missing == "native":
        _set_markdown_table_cell(
            repo_copy / "docs/platform/MODEL_RUNTIME_PROFILES.md",
            "windows-x64",
            1,
            "`NOT_YET_IMPLEMENTED`",
        )
    else:
        ledger = repo_copy / "docs/CRITICAL_GATES.md"
        edit(
            ledger,
            "- Zero-tolerance failures observed: 0",
            "- Zero-tolerance failures observed: 1",
        )
    result = run_validator(repo_copy)
    assert result.returncode == 1, result.stdout + result.stderr
