from pathlib import Path
import datetime
import difflib
import hashlib
import json
import os
import shutil
import subprocess
import sys

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
REL = Path('e2e/extension/legacy-paired-options')
SRC = ROOT / REL
OUT = Path('/tmp/japp-w14-paired-revision8')
PROPOSAL = Path(sys.argv[1])
OLD = 'sha256:e5b9a8dd4163a6f3c9e61782ef808692ebf65da0997fdfdb486d77e671b50042'
sha = lambda b: 'sha256:' + hashlib.sha256(b).hexdigest()
js = lambda d: json.dumps(d, indent=2, ensure_ascii=False) + '\n'
canonical = lambda d: json.dumps(d, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()
names = ['campaign.lock.json', 'campaign.lock.sha256', 'predeclaration.json', 'source-bindings.json', 'playwright.config.ts', 'PREEXECUTION.md']
expected_changes = {'apps/extension/src/driver-engine.ts', 'apps/extension/src/drivers/text-like-drivers.ts'}
assert not OUT.exists(), 'fresh outside proposal required'
assert sha((SRC / 'campaign.lock.json').read_bytes()) == OLD
assert (SRC / 'campaign.lock.sha256').read_text() == OLD + '\n'
lock = json.loads((SRC / 'campaign.lock.json').read_text())
for item in lock['files']:
    assert sha((SRC / item['path']).read_bytes()) == item['sha256'], item['path']
bindings = json.loads((SRC / 'source-bindings.json').read_text())
decl = json.loads((SRC / 'predeclaration.json').read_text())
assert decl['preexecution_source_revision'] == 7
old_runtime = bindings['candidate_runtime_sources']
assert len(old_runtime) == 355
assert sha(canonical(old_runtime)) == bindings['candidate_runtime_inventory_digest'] == 'sha256:c3757409d0e43b12e517eae863e4985d8a509273dd45b86f59a5bfb8478cc89c'
changes = []
files = []
total_bytes = 0
for item in old_runtime:
    path = item['path']
    before = (ROOT / path).read_bytes()
    assert sha(before) == item['sha256'], path
    proposed = PROPOSAL / 'proposed' / path
    after = proposed.read_bytes() if path in expected_changes else before
    assert path not in expected_changes or after != before
    if before != after:
        changes.append({'path': path, 'before_sha256': sha(before), 'after_sha256': sha(after)})
    files.append({'path': path, 'sha256': sha(after)})
    total_bytes += len(after)
assert {item['path'] for item in changes} == expected_changes
inv = {'policy': bindings['candidate_runtime_inventory_policy'], 'files': files, 'digest': sha(canonical(files)), 'total_bytes': total_bytes}
frozen = {path: sha((SRC / path).read_bytes()) for path in ['paired-inputs.json', 'paired-oracles.json', 'legacy-projections.json']}
assert sha((ROOT / bindings['native_observer']['helper_path']).read_bytes()) == bindings['native_observer']['helper_sha256']
for item in bindings['legacy_sources']:
    assert sha((Path('/tmp/japp-legacy-cleanroom.ByLBQU') / item['path']).read_bytes()) == item['sha256'], item['path']
OUT.mkdir()
pre = OUT / 'source-preimages' / REL
pre.mkdir(parents=True)
for name in names:
    shutil.copyfile(SRC / name, pre / name)
proposed = OUT / 'proposed' / REL
shutil.copytree(SRC, proposed)
history = proposed / 'preexecution-history/revision-7'
history.mkdir()
for name in names:
    shutil.copyfile(pre / name, history / name)
now = datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00', 'Z')
decl.update({
    'preexecution_source_revision': 8,
    'preexecution_source_revision_reason': 'CURRENT_TEXT_DATE_FOCUS_VALUE_PRESERVATION_AFTER_ACTUAL_REVISION_7_CAMPAIGN',
    'preexecution_previous_campaign_lock_digest': OLD,
    'preexecution_runtime_review_record': 'SEPARATE_EXACT_SOURCE_AND_DECLARATION_REVIEW_REQUIRED_BEFORE_EXECUTION',
    'preexecution_no_paired_system_run_declared': True,
    'preexecution_rebind_prepared_at': now,
    'preexecution_runtime_inventory_correction': 'Revision7 actual candidate4/legacy4 results remain historical under locke5b9a8dd4163a6f3c9e61782ef808692ebf65da0997fdfdb486d77e671b50042. Revision8 binds the two-file text/date focus-value guard and narrowly scoped pre-write recovery correction. Both actors must execute afresh. No old outcome is rebound; inputs, oracles, projections, vendor sources, observer and actor/control assertions remain exact.',
    'candidate_runtime_inventory_policy': inv['policy'],
    'candidate_runtime_inventory_digest': inv['digest'],
    'candidate_runtime_inventory_count': len(files),
    'preexecution_prior_actual_campaign': {'source_revision': 7, 'campaign_lock_digest': OLD, 'candidate_cases_executed': 4, 'legacy_cases_executed': 4, 'evidence_directory': 'docs/evidence/m02-w14-revision7-actual', 'relationship': 'HISTORICAL_ACTUAL_RESULTS_NOT_REBOUND_OR_INHERITED_BY_REVISION_8'},
})
(proposed / 'predeclaration.json').write_text(js(decl))
config = (SRC / 'playwright.config.ts').read_text()
assert config.count('declaration.preexecution_source_revision !== 7') == 1
assert config.count('sha256:47b6fe33c9e68d8aed9815f2cd35887e289a0e93fbf27045a059e467d35fe6fb') == 1
config = config.replace('declaration.preexecution_source_revision !== 7', 'declaration.preexecution_source_revision !== 8').replace('sha256:47b6fe33c9e68d8aed9815f2cd35887e289a0e93fbf27045a059e467d35fe6fb', OLD)
(proposed / 'playwright.config.ts').write_text(config)
intro = f'''# Paired explicit-option pre-execution source revision 8

Revision8 declares fresh candidate4 and legacy4 executions after the reviewed text/date focus-value correction. Runtime binding is355files / `{inv['digest']}`. Actual revision7 results under `{OLD}` remain historical in `docs/evidence/m02-w14-revision7-actual`; no outcome or timing is inherited. No revision8 actor has run at authoring.

The exact six revision7 declaration/configuration/checklist files were preserved before refreshing metadata under `preexecution-history/revision-7/`. Candidate runtime changes are confined to `apps/extension/src/driver-engine.ts` and `apps/extension/src/drivers/text-like-drivers.ts`. Frozen inputs/oracles/projections, vendor sources, native observer, actor implementations, source/control assertions and prior history bytes remain exact.

The configuration now requires revision8 and the exact revision7 predecessor lock. Coordinator/worker fresh absolute outside-output checks remain unchanged. Parent commands strip TEST_WORKER_INDEX. Separate exact-byte independent review of this source/declaration is required before integration and new actor execution. The lock sidecar alone grants no review authority. The original revision3 authoring tool is historical and deliberately refuses later locks.

## Historical revision7 preparation record

'''
oldmd = (SRC / 'PREEXECUTION.md').read_text()
(proposed / 'PREEXECUTION.md').write_text(intro + oldmd.split('\n\n', 1)[1].replace('PARENT_REVIEWED_REVISION_7_SHA256_DIGEST', 'PARENT_REVIEWED_REVISION_8_SHA256_DIGEST'))
env = os.environ.copy()
env['PATH'] = '/opt/homebrew/opt/node@24/bin:' + env['PATH']
subprocess.run(['pnpm', 'exec', 'prettier', '--write', str(proposed / 'predeclaration.json'), str(proposed / 'playwright.config.ts'), str(proposed / 'PREEXECUTION.md')], cwd=ROOT, env=env, check=True)
bindings.update({'predeclaration_digest': sha((proposed / 'predeclaration.json').read_bytes()), 'candidate_runtime_sources': files, 'candidate_runtime_inventory_policy': inv['policy'], 'candidate_runtime_inventory_digest': inv['digest']})
(proposed / 'source-bindings.json').write_text(js(bindings))
subprocess.run(['pnpm', 'exec', 'prettier', '--write', str(proposed / 'source-bindings.json')], cwd=ROOT, env=env, check=True)
payload = [{'path': path.relative_to(proposed).as_posix(), 'sha256': sha(path.read_bytes())} for path in sorted(proposed.rglob('*')) if path.is_file() and path.relative_to(proposed).as_posix() not in ['campaign.lock.json', 'campaign.lock.sha256']]
lock.update({'status': 'FROZEN_BEFORE_EITHER_NEW_RUN_REVISION_8_CURRENT_FOCUS_VALUE_GUARD', 'files': payload})
(proposed / 'campaign.lock.json').write_text(js(lock))
newlock = sha((proposed / 'campaign.lock.json').read_bytes())
(proposed / 'campaign.lock.sha256').write_text(newlock + '\n')
changed = []
patch = []
for path in sorted(proposed.rglob('*')):
    assert not path.is_symlink()
    if not path.is_file():
        continue
    rel = path.relative_to(proposed)
    original = SRC / rel
    before = original.read_bytes() if original.exists() else b''
    after = path.read_bytes()
    if before == after:
        continue
    full = (REL / rel).as_posix()
    changed.append({'path': full, 'exists_before': original.exists(), 'before_sha256': sha(before) if original.exists() else None, 'after_sha256': sha(after), 'before_bytes': len(before), 'after_bytes': len(after)})
    patch.append(f'diff --git a/{full} b/{full}\n')
    if not original.exists():
        patch.append('new file mode 100644\n')
    patch.extend(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile='a/' + full if original.exists() else '/dev/null', tofile='b/' + full))
patch_bytes = ''.join(patch).encode()
(OUT / 'revision8-proposal.patch').write_bytes(patch_bytes)
manifest = {'format_version': 'W14_PAIRED_REVISION8_PREEXECUTION_PROPOSAL_1', 'authority': 'NONE', 'status': 'PROPOSED_OUTSIDE_ROOT_BEFORE_EITHER_REVISION_8_ACTOR_EXECUTION', 'prior_lock_digest': OLD, 'proposed_lock_digest': newlock, 'proposed_lock_payload_files': len(payload), 'candidate_runtime_inventory_digest': inv['digest'], 'candidate_runtime_inventory_count': len(files), 'runtime_file_changes': changes, 'frozen_data_unchanged': frozen, 'revision7_history_exact': names, 'native_observer_unchanged': bindings['native_observer']['helper_sha256'], 'legacy_sources_verified_unchanged': len(bindings['legacy_sources']), 'source_control_assertions_and_actor_code_changed': False, 'coordinator_worker_freshness_logic_unchanged': True, 'separate_read_only_review': 'PENDING', 'candidate_revision8_runs': 0, 'legacy_revision8_runs': 0, 'builds_started': 0, 'browsers_started': 0, 'patch_sha256': sha(patch_bytes), 'changed_files': changed}
(OUT / 'source-manifest.json').write_text(js(manifest))
(OUT / 'runtime-inventory.json').write_text(js(inv))
for name in names:
    assert (SRC / name).read_bytes() == (pre / name).read_bytes()
for item in lock['files']:
    assert sha((proposed / item['path']).read_bytes()) == item['sha256']
print(js({'output': str(OUT), 'patch_sha256': sha(patch_bytes), 'lock': newlock, 'runtime': inv['digest'], 'changed_files': len(changed), 'payload_files': len(payload), 'execution': 'NONE'}))
