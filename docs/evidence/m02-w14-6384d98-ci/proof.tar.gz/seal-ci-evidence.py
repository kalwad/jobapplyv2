"""Seal completed exact6384 CI evidence; pure outside file/archive operations."""
from pathlib import Path, PurePosixPath
import gzip, hashlib, io, json, stat, tarfile

SOURCE = Path(__file__).resolve().parent
DEST = Path('/tmp/japp-w14-6384d98-ci-retained')

def digest(b):
    return hashlib.sha256(b).hexdigest()

def data(v):
    return (json.dumps(v,indent=2)+'\n').encode()

run=json.loads((SOURCE/'final-run.raw.json').read_bytes())
summary=json.loads((SOURCE/'summary.json').read_bytes())
assert run['status']=='completed'
assert summary['full_three_platform_completion'] is (run['conclusion']=='success')
assert (SOURCE/'windows-final-job.raw.json').is_file()
assert (SOURCE/'windows-117526229288.raw.log').is_file()
assert (SOURCE/'REPORT.md').is_file()
assert not DEST.exists()
rows=[];payloads={}
for p in sorted(SOURCE.rglob('*')):
    if p.is_symlink():
        raise ValueError('Symlink source refused: '+str(p))
    if p.is_dir():
        continue
    if not stat.S_ISREG(p.stat().st_mode):
        raise ValueError('Special source refused: '+str(p))
    name=str(p.relative_to(SOURCE));safe=PurePosixPath(name)
    assert not safe.is_absolute() and '..' not in safe.parts
    b=p.read_bytes();payloads[name]=b;rows.append({'path':name,'source':str(p),'bytes':len(b),'sha256':digest(b)})
index=data({'scope':'Exact6384 completed native CI evidence; no product run or gate authority','files':rows})
assert 'retention-index.json' not in payloads
payloads['retention-index.json']=index
DEST.mkdir()
archive=DEST/'proof.tar.gz'
with archive.open('xb') as f:
    with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0,compresslevel=9) as gz:
        with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as t:
            for name,b in sorted(payloads.items()):
                ti=tarfile.TarInfo(name);ti.size=len(b);ti.mode=0o644;ti.mtime=0;ti.uid=ti.gid=0;ti.uname=ti.gname='';t.addfile(ti,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as t:
    ms=t.getmembers();assert [m.name for m in ms]==sorted(payloads)
    assert len(ms)==len(set(m.name for m in ms))
    for m in ms:
        assert m.isfile() and t.extractfile(m).read()==payloads[m.name]
for row in rows:
    b=Path(row['source']).read_bytes();assert len(b)==row['bytes'] and digest(b)==row['sha256']
newrows=[{'path':str(p.relative_to(SOURCE)),'source':str(p),'bytes':p.stat().st_size,'sha256':digest(p.read_bytes())} for p in sorted(SOURCE.rglob('*')) if p.is_file()]
assert newrows==rows
(DEST/'archive-index.json').write_bytes(index)
manifest={'terminal_ci_conclusion':run['conclusion'],'full_three_platform_success':summary['full_three_platform_completion'],'archive_path':'proof.tar.gz','archive_sha256':digest(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'regular_members':len(payloads),'source_files':len(rows),'all_archive_source_bytes_equal':True,'source_recapture_unchanged':True,'files':rows+[{'path':'retention-index.json','bytes':len(index),'sha256':digest(index),'generated':True}],'scope':'Exact head6384/tree d2c1 completed CI only; no later candidate certification or target20 replacement; no Gate A or formal W15 authority'}
(DEST/'retention-manifest.json').write_bytes(data(manifest))
print(json.dumps({k:manifest[k] for k in ['archive_path','archive_sha256','archive_bytes','regular_members','source_files','all_archive_source_bytes_equal']},indent=2))
