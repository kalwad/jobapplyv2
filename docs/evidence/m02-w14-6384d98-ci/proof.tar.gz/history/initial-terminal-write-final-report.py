"""Validate terminal retained APIs and write a source-scoped CI report."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
read=lambda n:json.loads((ROOT/n).read_bytes())
run=read('final-run.raw.json');jobs=read('final-jobs.raw.json');summary=read('summary.json');binding=read('recursive-tree-binding.json')
assert run['id']==39077040378 and run['head_sha']=='6384d98156ae198cd93d7b35d1bb28b501ed475e'
assert run['status']=='completed' and run['conclusion']=='success' and run['run_attempt']==1
assert run['event']=='pull_request' and summary['full_three_platform_completion'] is True
assert jobs['total_count']==len(jobs['jobs'])==3
byid={j['id']:j for j in jobs['jobs']};assert set(byid)=={117526229268,117526229109,117526229288}
proofs=[read(p+'-complete-proof.json') for p in ['ubuntu','macos','windows']]
for p in proofs:
    j=byid[p['job_id']]
    assert j['status']=='completed' and j['conclusion']=='success' and j['run_id']==run['id']
    assert j['completed_at']==p['completed_at']
    assert all(s['conclusion']=='success' for s in j['steps'] if s['number'] in [2,22,23,24])
assert binding['status']=='PASS' and binding['git_tree_objects_reconstructed_and_sha1_verified']==309
artifacts=read('final-artifacts.raw.json')
rows='\n'.join('| '+p['platform']+' | '+str(p['job_id'])+' | '+str(p['python']['count'])+' PASS, '+p['python']['duration']+' | '+p['completed_at']+' | '+str(p['performance']['W13_TARGET_P95']['p95_ms'])+' |' for p in proofs)
text=f'''# Exact 6384 native CI terminal evidence

[Run 39077040378]({run['html_url']}), attempt 1, completed **SUCCESS** on Ubuntu, macOS and Windows. Each platform passes the actual repository doctor, all 19 active verification suites and the final tracked-clean step.

Exact head `6384d98156ae198cd93d7b35d1bb28b501ed475e` and tested PR merge `52fcfc186251205180197b9b9f88fcb0b4acf534` share tree `d2c1fd5e50bbbd31a926cbf251d6140d11b9b9c4`. Every complete raw checkout log confirms that merge. Retained Git Data API objects bind its parents to main `4745149f4b5da7190b5b0c68753f8ec07bed572d` and exact head. All 309 Git tree objects reconstruct to their declared SHA-1 values over 1,560 tracked blobs; eight retrieved verification-source snapshots bind transitively to that tree and have verified Git blob SHA-1, size and SHA-256.

| Host | Job | Complete final Python summary | Completed UTC | Native128 one-sample ms |
|---|---|---|---|---|
{rows}

Collected Python IDs exactly match the committed capability inventory: 1,490 common tests on Windows and 1,492 on POSIX. The only difference is the declared FIFO/Unix-socket migration probes. No skipped cohort or arbitrary reduced denominator is accepted. Each full all-pass summary covers exact status239, contact11 and public-proof8 inventories; all corresponding node IDs and digests are retained. Both POSIX collected-ID digests are `9bae91b4c2d8db21309653a73c260c8fd865284e08a46e4d3664eee65bf03452`; the Windows/common digest is `ad67e0cea78c80f8e6a878dec5f60c1835362567e2032dfd79f58b6d4e729ab4`.

Every platform's fourteen unit package summaries sum to 3,859 TypeScript tests, including 2,524 contract-package units. The direct-compiler infrastructure's eight tests pass twice. Every log records 242 default-browser cases, two separate inspection cases and 62 controlled-contact cases passing. Actual repository doctor reports 27 PASS/zero WARN/zero FAIL/one NOT_YET_APPLICABLE. Visual remains genuinely NOT_YET_APPLICABLE. The 19 active suite rows and verification exit zero are retained separately from the final tracked-clean job/API success.

CI uses one native128 sample with zero settlement budget. Exact benchmark source applies the 1,500 ms target assertion only when sampleCount is 20 on darwin. macOS's observed single value of 1576.9142919999977 ms exceeds that numerical target and remains recorded; default functional CI does not replace or relabel the separately retained local target20 or contact200 full-settlement experiments. No threshold or wait is weakened here.

The terminal artifacts API reports {artifacts['total_count']} artifacts. The bundle retains the initial and final run/jobs/job APIs, timestamped progress snapshots, current-PR context, full three-platform raw job logs, source APIs/snapshots, committed inventory, Git head/merge/base/root/recursive-tree objects, pure data-derivation sources and actual command/stdout/stderr records. Current PR data is context only; its later state is never substituted for the tested immutable run head. Earlier partial derivation outputs remain retained. Original errors, if any, must remain visible in their command records.

This is native repository/toolchain CI at exact frozen6384 source. It does not cover subsequent closure bookkeeping, fixture-copy or cleanup corrections, a later final candidate, packaged platform certification, public ATS support, formal W15, Gate A approval or an owner decision. Prior local and historical comparison/native results keep separate source anchors. No cause is inferred for older stackless contact-environment failures from this success.

All collection operations were read-only CI/API requests and outside retained-data processing. No repository fetch, checkout write, product test/build/browser/actor, CI trigger/retry/cancellation or push was performed. Retention packaging checks exact source/member bytes and hashes without executing archived content.
'''
(ROOT/'REPORT.md').write_text(text)
print(json.dumps({'run_id':run['id'],'status':run['status'],'conclusion':run['conclusion'],'all_three_final_job_APIs_match_derived_proofs':True,'artifacts':artifacts['total_count'],'report':'REPORT.md'},indent=2))
