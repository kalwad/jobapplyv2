from pathlib import Path
import base64
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
HEAD = "1d490d1230b443c31fd4a9d8732064552affe149"
MERGE = "d8de57146b6ef183cf6229701e5089c904175ce9"
TREE = "ac98b18d71fffc6cc0ff7fc07ccd32ccda8133d9"
BASE = "4745149f4b5da7190b5b0c68753f8ec07bed572d"
RUN = 38984225730


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write(name, data):
    (ROOT / name).write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


run = read("final-run.raw.json")
pr = read("final-pr-1.raw.json")
jobs = read("final-jobs.raw.json")["jobs"]
head = read("head-git-commit.raw.json")
merge = read("merge-git-commit.raw.json")
tree = read("head-tree.raw.json")
assert run["id"] == RUN and run["head_sha"] == HEAD
assert run["status"] == "completed" and run["conclusion"] == "success"
assert run["run_attempt"] == 1 and run["event"] == "pull_request"
assert pr["number"] == 1 and pr["head"]["sha"] == HEAD
assert pr["merge_commit_sha"] == MERGE
assert head["sha"] == HEAD and merge["sha"] == MERGE
assert head["tree"]["sha"] == merge["tree"]["sha"] == tree["sha"] == TREE
assert [p["sha"] for p in merge["parents"]] == [BASE, HEAD]
assert read("merge-tree.raw.json")["tree"] == tree["tree"]
assert not tree.get("truncated", False)
tree_bytes = b"".join(
    entry["mode"].lstrip("0").encode() + b" " + entry["path"].encode()
    + b"\0" + bytes.fromhex(entry["sha"])
    for entry in tree["tree"]
)
assert hashlib.sha1(b"tree " + str(len(tree_bytes)).encode() + b"\0" + tree_bytes).hexdigest() == TREE
(ROOT / "root-tree.raw.git-object").write_bytes(tree_bytes)

source_files = []
for name in [
    "source-test_validate_status.api.raw.json",
    "source-test_w14_contact_controlled_proof.api.raw.json",
    "source-verify.api.raw.json",
    "source-infrastructure-actual.api.raw.json",
    "source-ci-workflow.api.raw.json",
    "source-benchmark.api.raw.json",
    "source-python-inventory.api.raw.json",
]:
    data = read(name)
    raw = base64.b64decode(data["content"])
    assert len(raw) == data["size"]
    assert hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest() == data["sha"]
    snapshot = "snapshot-" + data["path"].replace("/", "__")
    assert (ROOT / snapshot).read_bytes() == raw
    source_files.append({"path": data["path"], "head": HEAD, "git_blob": data["sha"],
                         "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
                         "api": name, "snapshot": snapshot})
write("source-files.json", source_files)

platforms = []
expected_jobs = {"ubuntu": 117251833953, "macos": 117251833960, "windows": 117251833793}
declared_inventory = read("snapshot-scripts__python-test-inventory.v1.json")
common_ids = declared_inventory["common"]["node_ids"]
posix_ids = declared_inventory["posix_only_node_ids"]
assert len(common_ids) == len(set(common_ids)) == declared_inventory["common"]["count"] == 1452
assert hashlib.sha256(("\n".join(common_ids) + "\n").encode()).hexdigest() == declared_inventory["common"]["sha256"]
assert posix_ids == [
    "scripts/tests/test_v14_migration.py::test_atomic_adoption_rejects_non_regular_source[fifo]",
    "scripts/tests/test_v14_migration.py::test_atomic_adoption_rejects_non_regular_source[socket]",
]
assert {j["id"] for j in jobs} == set(expected_jobs.values())
for platform, job_id in expected_jobs.items():
    job = next(j for j in jobs if j["id"] == job_id)
    assert job["run_id"] == RUN and job["status"] == "completed" and job["conclusion"] == "success"
    assert read(platform + "-final-job.raw.json")["id"] == job_id
    steps = {s["number"]: s for s in job["steps"]}
    assert all(steps[n]["conclusion"] == "success" for n in [22, 23, 24])
    filename = f"{platform}-{job_id}.raw.log"
    raw = (ROOT / filename).read_bytes()
    text = re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", raw.decode("utf-8", errors="replace"))
    lines = [re.sub(r"^\d{4}-\d\d-\d\dT[^ ]+Z ", "", line) for line in text.splitlines()]
    checkout = next(i for i, line in enumerate(lines) if " log -1 --format=%H" in line)
    assert lines[checkout + 1].strip() == MERGE
    collection_start = next(i for i, line in enumerate(lines) if line.startswith("$ uv run pytest ") and "--collect-only" in line)
    execution_start = next(i for i, line in enumerate(lines[collection_start + 1:], collection_start + 1)
                           if line.startswith("$ uv run pytest ") and "--collect-only" not in line)
    nodes = [line for line in lines[collection_start:execution_start]
             if re.match(r"^(?:scripts/tests|services/orchestrator/tests)/.+\.py::", line)]
    status_nodes = [n for n in nodes if n.startswith("scripts/tests/test_validate_status.py::")]
    contact_nodes = [n for n in nodes if n.startswith("scripts/tests/test_w14_contact_controlled_proof.py::")]
    assert len(status_nodes) == len(set(status_nodes)) == 201
    assert len(contact_nodes) == len(set(contact_nodes)) == 11
    assert "scripts/tests/test_w14_contact_controlled_proof.py::test_w14_contact_child_environment_is_narrow_and_parent_flags_do_not_mutate" in contact_nodes
    expected_python = 1452 if platform == "windows" else 1454
    assert len(nodes) == len(set(nodes)) == expected_python
    expected_ids = sorted(common_ids if platform == "windows" else common_ids + posix_ids)
    assert sorted(nodes) == expected_ids
    collection_sha256 = hashlib.sha256(("\n".join(sorted(nodes)) + "\n").encode()).hexdigest()
    python_summaries = [(i + 1, re.fullmatch(r"=+ (\d+) passed in (.*?) =+", line))
                        for i, line in enumerate(lines) if re.fullmatch(r"=+ (\d+) passed in (.*?) =+", line)]
    assert len(python_summaries) == 1
    python_line, python_match = python_summaries[0]
    assert int(python_match.group(1)) == expected_python
    active = [m.groups() for line in lines if (m := re.fullmatch(r"([\w-]+)\s+ACTIVE\s+(PASS|FAIL)\s*", line))]
    assert len(active) == 19 and len({name for name, result in active}) == 19
    assert all(result == "PASS" for name, result in active)
    browser = [{"line": i + 1, "text": line.strip()} for i, line in enumerate(lines)
               if re.fullmatch(r"\s*\d+ passed \(.*\)", line)]
    assert [int(row["text"].split()[0]) for row in browser] == [242, 2, 62]
    infrastructure = [{"line": i + 1, "text": line} for i, line in enumerate(lines)
                      if "infrastructure.test.ts (8 tests)" in line]
    assert len(infrastructure) == 2
    contracts = [{"line": i + 1, "text": line} for i, line in enumerate(lines) if re.fullmatch(r"\s*Tests\s+2524 passed \(2524\)", line)]
    assert len(contracts) == 1
    performance = {label: json.loads(line.split(" ", 1)[1]) for line in lines
                   if line.startswith(("W13_TARGET_P95 ", "W13_SCALING "))
                   for label in [line.split(" ", 1)[0]]}
    assert performance["W13_TARGET_P95"]["samples"] == 1
    proof = {"platform": platform, "job_id": job_id, "job_name": job["name"],
             "status": "completed", "conclusion": "success", "started_at": job["started_at"],
             "completed_at": job["completed_at"], "raw_log": {"path": filename, "bytes": len(raw),
             "sha256": hashlib.sha256(raw).hexdigest()}, "tested_merge": MERGE,
             "python": {"count": expected_python, "duration": python_match.group(2), "summary_line": python_line,
                        "outcome": "PASS, complete final all-pass summary",
                        "exact_declared_capability_inventory_match": True,
                        "collected_nodeids_sha256": collection_sha256,
                        "declared_common_count": 1452,
                        "declared_common_sha256": declared_inventory["common"]["sha256"],
                        "posix_only_nodeids": posix_ids if platform != "windows" else []},
             "status_cohort": {"count": 201, "outcome": "PASS, exact collected inventory covered by final all-pass summary", "nodeids": status_nodes},
             "contact_cohort": {"count": 11, "outcome": "PASS, exact collected inventory covered by final all-pass summary", "nodeids": contact_nodes},
             "active_suites": [{"name": name, "outcome": result} for name, result in active],
             "playwright_summaries": browser, "infrastructure_eight": infrastructure,
             "contracts_2524": contracts, "performance": performance,
             "doctor_and_aggregate_and_tracked_clean": "PASS"}
    write(platform + "-complete-proof.json", proof)
    platforms.append({k: v for k, v in proof.items() if k not in ["status_cohort", "contact_cohort", "performance"]} |
                     {"status_cohort": {"count": 201, "outcome": "PASS"}, "contact_cohort": {"count": 11, "outcome": "PASS"},
                      "native128_performance": performance["W13_TARGET_P95"]})

summary = {"repository": "kalwad/jobapplyv2", "pull_request": 1, "run_id": RUN,
           "run_url": run["html_url"], "run_attempt": 1, "status": "completed", "conclusion": "success",
           "head": HEAD, "tested_merge": MERGE, "tested_tree": TREE, "merge_parents": [BASE, HEAD],
           "head_tree_equals_tested_merge_tree": True, "created_at": run["created_at"], "updated_at": run["updated_at"],
           "platforms": platforms, "artifact_count": read("final-artifacts.raw.json")["total_count"],
           "scope": ["Exact 1d490d source and matching PR merge tree only.",
                     "Native Windows full pytest summary confirms all 1452 tests, status 201 and contact 11, including the previously stackless contact-environment case.",
                     "Native Windows direct-compiler infrastructure 8 passes twice; full contracts 2524 passes.",
                     "CI native128 measurement uses one sample on each platform; it does not satisfy or replace the separate 20-sample target campaign.",
                     "The exact benchmark source applies its 1500ms target assertion only for sampleCount===20 on darwin; macOS single-sample CI measured 1662.4582919999993ms and still passed its default functional scope.",
                     "No causal explanation is asserted for the prior stackless contact-environment failure.",
                     "No later local optimization is covered by this CI run."]}
write("summary.json", summary)
write("source-binding.json", {"head": HEAD, "tested_merge": MERGE, "tree": TREE,
                              "merge_parents": [BASE, HEAD], "checkout_confirmed_in_all_three_raw_logs": True,
                              "root_tree_git_object_sha1_verified": True, "source_blob_sha1_verified": True,
                              "raw_git_commit_metadata": ["head-git-commit.raw.json", "merge-git-commit.raw.json", "base-git-commit.raw.json"],
                              "raw_git_tree_metadata": ["head-tree.raw.json", "merge-tree.raw.json"],
                              "commit_raw_preimages": "GitHub Git Data API metadata retained; no complete repository checkout is included."})
print(json.dumps({"run": RUN, "head": HEAD, "merge": MERGE, "tree": TREE,
                  "outcome": "all three platforms PASS", "python": {p["platform"]: p["python"] for p in platforms}}, indent=2))
