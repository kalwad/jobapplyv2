"""Reconstruct retained Git tree object hashes; no project execution."""
from pathlib import Path, PurePosixPath
import hashlib, json
ROOT=Path(__file__).resolve().parent
t=json.loads((ROOT/'recursive-tree.raw.json').read_bytes())
assert not t['truncated']
expected={'':t['sha']};groups={};blobs={}
for e in t['tree']:
    path=PurePosixPath(e['path']);parent=str(path.parent)
    if parent=='.':parent=''
    groups.setdefault(parent,[]).append(e)
    if e['type']=='tree':expected[e['path']]=e['sha']
    elif e['type']=='blob':blobs[e['path']]=e
checks=[]
for dirname,sha in sorted(expected.items()):
    entries=sorted(groups.get(dirname,[]),key=lambda e:PurePosixPath(e['path']).name.encode()+(b'/' if e['type']=='tree' else b''))
    raw=b''.join(e['mode'].lstrip('0').encode()+b' '+PurePosixPath(e['path']).name.encode()+b'\0'+bytes.fromhex(e['sha']) for e in entries)
    actual=hashlib.sha1(b'tree '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    assert actual==sha,(dirname,actual,sha)
    checks.append({'path':dirname or '<root>','git_tree_sha1':sha,'immediate_entries':len(entries),'git_object_bytes':len(raw)})
sources=json.loads((ROOT/'source-files.json').read_bytes())
assert len(sources)==8
assert all(blobs[s['path']]['sha']==s['git_blob'] for s in sources)
assert len(blobs)==1560
result={'status':'PASS','head_tree':t['sha'],'recursive_entries':len(t['tree']),'tracked_blobs':len(blobs),'git_tree_objects_reconstructed_and_sha1_verified':len(checks),'eight_exact_source_blobs_bound_to_transitive_head_tree':True,'tree_checks':checks,'scope':'Pure retained API object reconstruction; no checkout/source-root mutation or product command'}
(ROOT/'recursive-tree-binding.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='tree_checks'},indent=2))
