"""Derive native CI observations from retained API/log bytes only."""
from pathlib import Path
import base64
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
HEAD = '6384d98156ae198cd93d7b35d1bb28b501ed475e'
MERGE = '52fcfc186251205180197b9b9f88fcb0b4acf534'
TREE = 'd2c1fd5e50bbbd31a926cbf251d6140d11b9b9c4'
BASE = '4745149f4b5da7190b5b0c68753f8ec07bed572d'
RUN = 39077040378
JOBS = {'ubuntu':117526229268, 'macos':117526229109, 'windows':117526229288}

def read(name):
    return json.loads((ROOT / name).read_bytes())

def write(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')

def digest(data):
    return hashlib.sha256(data).hexdigest()

run = read('initial-run.raw.json')
assert run['id'] == RUN and run['head_sha'] == HEAD
assert run['run_attempt'] == 1 and run['event'] == 'pull_request'
assert run['pull_requests'][0]['head']['sha'] == HEAD
assert run['pull_requests'][0]['base']['sha'] == BASE
head, merge, tree = read('head-git-commit.raw.json'), read('merge-git-commit.raw.json'), read('head-tree.raw.json')
assert head['sha'] == HEAD and merge['sha'] == MERGE
assert head['tree']['sha'] == merge['tree']['sha'] == tree['sha'] == TREE
assert [p['sha'] for p in merge['parents']] == [BASE, HEAD]
assert read('merge-tree.raw.json')['tree'] == tree['tree']
assert not tree.get('truncated',False)
raw_tree = b''.join(e['mode'].lstrip('0').encode()+b' '+e['path'].encode()+b'\0'+bytes.fromhex(e['sha']) for e in tree['tree'])
assert hashlib.sha1(b'tree '+str(len(raw_tree)).encode()+b'\0'+raw_tree).hexdigest() == TREE
(ROOT/'root-tree.raw.git-object').write_bytes(raw_tree)
sources=[]
for file in sorted(ROOT.glob('source-*.api.raw.json')):
    data=read(file.name)
    raw=base64.b64decode(data['content'])
    assert len(raw)==data['size']
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==data['sha']
    snapshot='snapshot-'+data['path'].replace('/','__')
    assert (ROOT/snapshot).read_bytes()==raw
    sources.append({'path':data['path'],'git_blob':data['sha'],'bytes':len(raw),'sha256':digest(raw),'api':file.name,'snapshot':snapshot,'head':HEAD})
assert len(sources)==8
write('source-files.json',sources)
inventory=read('snapshot-scripts__python-test-inventory.v1.json')
common=inventory['common']['node_ids']; posix=inventory['posix_only_node_ids']
assert len(common)==len(set(common))==inventory['common']['count']==1490
assert digest(('\n'.join(common)+'\n').encode())==inventory['common']['sha256']
assert posix==['scripts/tests/test_v14_migration.py::test_atomic_adoption_rejects_non_regular_source[fifo]','scripts/tests/test_v14_migration.py::test_atomic_adoption_rejects_non_regular_source[socket]']
platforms=[]
for platform,job_id in JOBS.items():
    if not (ROOT/(platform+'-final-job.raw.json')).exists():
        continue
    job=read(platform+'-final-job.raw.json')
    assert job['id']==job_id and job['run_id']==RUN
    assert job['status']=='completed' and job['conclusion']=='success'
    steps={s['number']:s for s in job['steps']}
    assert all(steps[n]['conclusion']=='success' for n in [2,22,23,24])
    logfile=f'{platform}-{job_id}.raw.log'; raw=(ROOT/logfile).read_bytes()
    text=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',raw.decode(errors='replace'))
    lines=[re.sub(r'^\d{4}-\d\d-\d\dT[^ ]+Z ','',line) for line in text.splitlines()]
    checkout=next(i for i,l in enumerate(lines) if ' log -1 --format=%H' in l)
    assert lines[checkout+1].strip()==MERGE
    collection=next(i for i,l in enumerate(lines) if l.startswith('$ uv run pytest ') and '--collect-only' in l)
    execution=next(i for i,l in enumerate(lines) if i>collection and l.startswith('$ uv run pytest ') and '--collect-only' not in l)
    ids=[l for l in lines[collection:execution] if re.match(r'^(?:scripts/tests|services/orchestrator/tests)/.+\.py::',l)]
    expected=sorted(common if platform=='windows' else common+posix)
    assert len(ids)==len(set(ids))==len(expected) and sorted(ids)==expected
    cohorts={}
    for label,prefix,count in [('status','test_validate_status.py',239),('contact','test_w14_contact_controlled_proof.py',11),('public','test_w14_public_controlled_proof.py',8)]:
        cohort=[n for n in ids if n.startswith('scripts/tests/'+prefix+'::')]
        assert len(cohort)==len(set(cohort))==count
        cohorts[label]={'count':count,'node_ids':cohort,'outcome':'Covered by exact collection and final all-pass Python summary'}
    py=[(i+1,re.fullmatch(r'=+ (\d+) passed in (.*?) =+',l)) for i,l in enumerate(lines) if re.fullmatch(r'=+ (\d+) passed in (.*?) =+',l)]
    assert len(py)==1 and int(py[0][1].group(1))==len(expected)
    active=[m.groups() for l in lines if (m:=re.fullmatch(r'([\w-]+)\s+ACTIVE\s+(PASS|FAIL)\s*',l))]
    assert len(active)==len({n for n,s in active})==19 and all(s=='PASS' for n,s in active)
    unit_start=next(i for i,l in enumerate(lines) if l=='$ pnpm exec turbo run test --force -- --reporter=default')
    unit_end=next(i for i,l in enumerate(lines) if i>unit_start and l=='$ pnpm generate:contracts --check')
    units=[int(m.group(1)) for l in lines[unit_start:unit_end] if (m:=re.fullmatch(r'\s*Tests\s+(\d+) passed \(\d+\)\s*',l))]
    assert sum(units)==3859
    browser=[{'line':i+1,'text':l.strip()} for i,l in enumerate(lines) if re.fullmatch(r'\s*\d+ passed \(.*\)',l)]
    assert [int(v['text'].split()[0]) for v in browser]==[242,2,62]
    infrastructure=[{'line':i+1,'text':l} for i,l in enumerate(lines) if 'infrastructure.test.ts (8 tests)' in l]
    assert len(infrastructure)==2
    perf={l.split(' ',1)[0]:json.loads(l.split(' ',1)[1]) for l in lines if l.startswith(('W13_TARGET_P95 ','W13_SCALING '))}
    assert perf['W13_TARGET_P95']['samples']==1 and perf['W13_TARGET_P95']['settle_budget_ms']==0
    assert 'summary: 27 pass, 0 warning, 0 fail, 1 not-yet-applicable' in lines
    assert 'verification exit code: 0' in lines
    assert any('if ($porcelain)' in l and 'verification left tracked changes' in l for l in lines)
    proof={'platform':platform,'job_id':job_id,'job_name':job['name'],'status':'completed','conclusion':'success','started_at':job['started_at'],'completed_at':job['completed_at'],'raw_log':{'path':logfile,'bytes':len(raw),'sha256':digest(raw)},'tested_merge':MERGE,'tested_tree':TREE,'python':{'count':len(ids),'duration':py[0][1].group(2),'summary_line':py[0][0],'exact_declared_inventory_match':True,'nodeids_sha256':digest(('\n'.join(sorted(ids))+'\n').encode()),'common_count':1490,'posix_only':posix if platform!='windows' else []},'cohorts':cohorts,'typescript':{'total':sum(units),'unit_package_counts':units},'active_suites':[{'name':n,'outcome':s} for n,s in active],'playwright_summaries':browser,'infrastructure_eight':infrastructure,'performance':perf,'doctor':{'pass':27,'warn':0,'fail':0,'not_yet_applicable':1},'tracked_clean_step':'SUCCESS; job API and actual guard retained','scope':'Exact frozen6384 CI; one native128 sample, no target20 or final candidate claim'}
    write(platform+'-complete-proof.json',proof);platforms.append(proof)
summary={'run_id':RUN,'run_url':run['html_url'],'head':HEAD,'tested_merge':MERGE,'tested_tree':TREE,'source_binding':'Exact head and tested merge trees equal; Git root-tree SHA1 and eight source blob SHA1 values verified','platforms_completed_and_verified':[{'platform':p['platform'],'python':p['python']['count'],'duration':p['python']['duration'],'job_id':p['job_id'],'native128_one_sample_ms':p['performance']['W13_TARGET_P95']['p95_ms']} for p in platforms],'full_three_platform_completion':len(platforms)==3,'formal_W15_or_Gate_A_or_packaged_platform_certification':'NONE','errors_or_missing_proofs_must_not_be_relabeled_as_success':True}
write('summary.json',summary)
write('source-binding.json',{'head':HEAD,'merge':MERGE,'tree':TREE,'parents':[BASE,HEAD],'root_tree_git_object_sha1_verified':True,'eight_source_blob_sha1_and_size_verified':True,'checkout_confirmed_in_completed_platform_raw_logs':[p['platform'] for p in platforms],'CI_native128_samples':1,'source_does_not_cover_later_root_bookkeeping_or_cleanup_corrections':True})
print(json.dumps(summary,indent=2))
