# W06 current local full evidence review: EVIDENCE_CONSISTENT_ACTUAL_FAILURE

Independent reconciliation: 47/47 checks passed against `e0a501b4979d5e76bf68859fe8c514a17c3c5b7e` / tree `bbf94e791c7d5ad038dded4b0683f4cc57f57b83`.

This report audits retained local data. It does not decide milestone acceptance, establish a new GUI execution, or validate native hosted platforms. Default benchmark observations are not a fresh 20-sample Gate A experiment.

The producer records the complete curated outer environment. It does not serialize every nested child environment or provide a whole dependency/cache/upfront native test-binary image. Its command-owned new-session groups have explicit termination/reaping receipts; escaped descendants remain unobserved. Version probes still use bounded direct subprocess calls.

Tool probe scope is literal: the Python-version probe hashes the resolved `uv` launcher, and pnpm/Node launcher hashes do not authenticate every nested executable. All historical source comparisons use immutable pinned Git objects, not a later mutable checkout.

## Failed checks

None.

## Raw-derived observations

Repository doctor: `pnpm run doctor`, exit 0, 7.334103417s; 28 ordinary PASS, no warnings/failures/N/A. It completed before aggregate start.

Aggregate: `pnpm verify`, exit 1, 798.600599708s; exact 20 ACTIVE summaries:18 PASS,Python/integrity FAIL before pytest. Verify log: 502500 bytes, SHA-256 `2806a232fd018453f3d48cd3c944846ec2dd4b680594c11b0235582b52414ed7`.

TypeScript unit summaries total 4006 ordinary passes. Python static source-policy preflight refused before any pytest collection/execution; declared inventory1799common/1801POSIX is not an execution result. All 15 registered Rust-stage commands occur in order; three desktop modes pass the same [232, 232, 232] cohort with zero failed/ignored/measured/filtered cases.

Browser ordinary pass summaries by execution: `{'default': ['262'], 'controlled_inspection': ['2'], 'controlled_contact': ['62'], 'visual': ['3']}`. The default execution may already include visual cases; these are execution counts, not a claim of distinct cases across commands.

Printed timing scopes: default native128 1-sample / 0ms-settle value 842.6027920000015ms; separate 200 different W12 page observations with 75ms settlement / 20ms rerender have printed p95 870.1540000000095ms. These are log-record observations, without a fresh independent contact raw replay or 20-sample performance claim.

All 1951 tracked-file path/size/SHA-256 rows match both snapshots and independently authenticated immutable Git blobs. The unchanged runtime payload has 40 files / 29902565 bytes; closed producer before/after snapshots record equal bytes/modes (no live physical reread), manifest `c9049a3f63572c0de9b114700e9326bebc0518166840133cce9548565c58de1d` and main `fc2293a3d6425093c03ada543249ccdc2050038613cf984b3983aada18032c7c`.

Historical W04 auditor preparation retains its initial 41/42 collection-summary observer correction; the whole-line anchored expression is preserved here. That historical result is not a W06 attempt or outcome. All W06 checks in this report derive from its own closed records; no earlier W04/W05 execution credit is inherited. The canonical native cohort is232 per mode; the earlier183 focus and outside187 derivative remain separate; the separate outside selected four-case recovery derivative keeps its own execution identity.

See `findings.json`, `immutable-git-blob-closure.json`, and `native-mode-cases.json` (no Python collection file exists because collection never ran) for exact identities, raw-derived counts, and case joins. All failed checker attempts must remain historical if a later parser correction is required.
