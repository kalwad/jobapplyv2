# macOS fixture policy correction: independent source review

CLEAR8/8 in source scope. Before bytes match immutable e0a501b (`91936dac3b98d0debe3373a92bd0e1521b7188301976e6ecb3fb244e905938e2`); after `6b3517d9c56680d7321f88bd0216548371d8a71407feabbf0c19507ec1532388`. Original static-policy exit1 is retained.

The narrow change removes current-module monkeypatching. The one existing case injects the inspector callable through the owned helper with native execute bits disabled; ordinary callers keep the default. Device/inode/size/mtime, regular/no-link checks and synthetic0700 projection remain. All36 assertions and every test name/argument/decorator are unchanged; every other module statement/function is exact.

The first observer attempt used an incorrect AST-prefix slice and failed before producing a verdict; its baseline record/error are retained separately. The corrected three-statement comparison confirms both original owned-identity guards remain. No source change or product rerun occurred.

No subject/test import, test/verifier/native/browser execution, root write or Git mutation occurred. Corrected policy, affected cases, Python/integrity and future full outcomes are not inferred. The old actual full18PASS2FAIL remains historical.
