"""Finite evidence retention only. Never imports/executes any selected source."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import os
import stat
import tarfile

OUT=Path('/tmp/japp-m03-w06-collection-correction-retained-20261019')
if OUT.exists(): raise RuntimeError('Fresh finite packet directory required')
OUT.mkdir()
MEMBERS=OUT/'members';MEMBERS.mkdir()
selected={};copies=[];omitted=[]

def sha(data): return hashlib.sha256(data).hexdigest()
def safe(name):
    p=PurePosixPath(name)
    return not p.is_absolute() and name==p.as_posix() and '..' not in p.parts and all(part not in ('','.') for part in p.parts)
def add(path,label):
    path=Path(path);name='members/'+label
    if not safe(name) or name in selected: raise RuntimeError('Unsafe/duplicate member '+name)
    meta=path.lstat()
    if not stat.S_ISREG(meta.st_mode) or meta.st_size>2*1024*1024: raise RuntimeError('Unexpected nonfinite payload '+str(path))
    data=path.read_bytes();after=path.lstat()
    identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_mode)
    if identity(meta)!=identity(after) or len(data)!=meta.st_size: raise RuntimeError('Source changed')
    dest=OUT/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    row={'bytes':len(data),'sha256':sha(data)}
    selected[name]=row;copies.append({'source':str(path),'member':name,**row,'source_mode':oct(stat.S_IMODE(meta.st_mode))})
def tree(root,label):
    root=Path(root)
    for p in sorted(root.rglob('*')):
        if p.is_symlink(): raise RuntimeError('Link in finite source '+str(p))
        if p.is_file(): add(p,label+'/'+p.relative_to(root).as_posix())
def flat(root,label,allowed=None):
    root=Path(root)
    for p in sorted(root.iterdir()):
        if p.is_file() and (allowed is None or p.suffix in allowed):add(p,label+'/'+p.name)
def generated(name,value):
    data=(value if isinstance(value,str) else json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
    member='members/'+name
    if not safe(member) or member in selected:raise RuntimeError('Duplicate generated member')
    dest=OUT/member;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    selected[member]={'bytes':len(data),'sha256':sha(data)}


R=Path('/Users/tanishkalwad/jobapplyv2')
full=Path('/tmp/japp-m03-w06-clean-root-verification-v2-20261019')
focused=Path('/tmp/japp-m03-w06-collection-fixture-checks-20261019')
fc=json.loads((full/'closure.json').read_text());cc=json.loads((focused/'closure.json').read_text())
if not(fc['source_unchanged'] and fc['runtime40_unchanged'] and not fc['all_executed_commands_exit0']):raise RuntimeError('Actual failed full required')
if not all(cc[k] for k in ['source_unchanged','runtime40_unchanged','all6_commands_executed','all_executed_commands_exit0']):raise RuntimeError('Actual corrected focus required')
for label,root in [('full/preflight-v1','/tmp/japp-m03-w06-clean-root-verification-v1-20261019'),('full/actual-failed-v2',full),('full/independent-review','/tmp/japp-m03-w06-failed-full-independent-audit-20261019'),('full/independent-auditor','/tmp/japp-m03-w06-failed-full-audit-preparation-20261019'),('correction/red-and-source','/tmp/japp-m03-w06-collection-fixture-correction-20261019'),('correction/actual-focused',focused),('correction/data-review','/tmp/japp-m03-w06-fixture-focus-independent-data-review-20261019')]:tree(root,label)
for root in sorted(Path('/tmp').glob('japp-m03-w06-collection-fixture-independent-review-20261019*')):tree(root,'correction/source-review-history/'+root.name)
for name in ['japp-m03-w06-clean-root-verification-v1-20261019.outer.log','japp-m03-w06-clean-root-verification-v2-20261019.outer.log','japp-m03-w06-clean-root-verify-20261019.py','japp-m03-w06-collection-fixture-checks-20261019.py','japp-m03-w06-collection-fixture-checks-20261019.outer.log']:
 add(Path('/tmp')/name,'outer/'+name)
add(R/'scripts/tests/test_macos_package.py','correction/test_macos_package.after.py')
source_report=Path('/tmp/japp-m03-w06-collection-fixture-independent-review-20261019-correction-1/REVIEW.md')
data_report=Path('/tmp/japp-m03-w06-fixture-focus-independent-data-review-20261019/REVIEW.md')
failed_report=Path('/tmp/japp-m03-w06-failed-full-independent-audit-20261019/REVIEW.md')
expected={source_report:'1290b578f529a20e3b55c7be5c077d87909d86a433d944e07eb8128c126153fb',data_report:'d4fd1ffeb12f486e6e2ecc608e3631ce30c5cb7a656e0d388f49dcaaec872072',failed_report:'f11908130384d6614a12d34b1f45841f13fb14872148e07eb22aeb5c4a98f09c'}
for p,h in expected.items():
 if sha(p.read_bytes())!=h:raise RuntimeError('Review drift')
summary={'scope':'W06 IN_PROGRESS correction; not full20 or package acceptance',
 'failed_full':{'head':'e0a501b4979d5e76bf68859fe8c514a17c3c5b7e','tree':'bbf94e791c7d5ad038dded4b0683f4cc57f57b83','source_files':1951,'doctor_pass':28,'doctor_exit':0,'verify_exit':1,'verify_seconds':798.6005997079774,'suites_passed':18,'suites_failed':['python','integrity'],'python_collection_or_execution':False,'reason':'existing test passed its current module to an unmodeled monkeypatch call; unchanged static collection policy refused','typescript_unit_pass':4006,'native_each_mode':[232,232,232],'browser_batches':[262,2,62,3],'source_and_runtime_unchanged':True,'owned_groups':'GONE; leaders reaped; no cleanup signals; outside descendants UNOBSERVED'},
 'correction':{'source_change':'One existing fixture file only; removes module-namespace monkeypatch, explicit test helper keyword preserves owned-file checks and synthetic mode behavior','production_and_verifier_unchanged':True,'all19_test_names_args_decorators_and36_assertions_preserved':True,'static_red_exit':1,'focused_command_count':6,'all_focused_exit0':True,'affected_pytest_pass':30,'affected_pytest_seconds':0.11,'canonical_collected':1801,'common_ids':1799,'posix_only_ids':2,'canonical_pytest_pass':1801,'canonical_pytest_seconds':377.98,'python_and_integrity_seconds':386.1147076669731,'python_and_integrity_suites':'ACTIVE PASS','source1951_and_runtime40_unchanged':True,'owned_groups':'GONE; leaders reaped; no signals; outside descendants UNOBSERVED'},
 'reviews':{'failed_full':{'checks':47,'verdict':'EVIDENCE_CONSISTENT_ACTUAL_FAILURE','sha256':expected[failed_report]},'fixture_source':{'checks':8,'verdict':'CLEAR_SOURCE','sha256':expected[source_report]},'focused_actual_data':{'checks':12,'verdict':'CLEAR_DATA','sha256':expected[data_report]}},
 'history':'V1 wrong-head preflight refused before doctor/verify; v2 failed full and static RED retained; no prior failure relabeled. Original source-review helper-prefix observation error retained separately.',
 'remaining':['Fresh clean full20 after correction/integration','Native window/LaunchServices/Close/Quit/Ready UI','Current macOS positive packaged Engine experiment','Actual foreign packaging/platform acceptance','W06/M03 acceptance/release'],
 'progress':{'verified':38,'total':300,'sole_in_progress':'M03-W06','M03':'IN_PROGRESS','release':'NOT_READY'}}
readme="# W06 collection fixture correction — IN_PROGRESS\n\nThe first clean e0a501b full run is retained as FAIL: doctor28 PASS,18 suites PASS, Python and integrity refused the macOS test's current-module monkeypatch during static policy preflight. No Python collection or execution occurred in that full. Source1951 and runtime40 remained unchanged; native232 in each of three modes, TypeScript4006 and browser262+2+62+3 passed. Different closed-data reconciliation found47 consistent checks and preserves the failed product verdict.\n\nThe repair changes one existing test fixture, preserving all19 test names/arguments/decorators,36 assertions and owned-file identity/regular/no-link checks. Production source, verifier policy, inventory and test IDs are unchanged. Actual RED1 precedes the repair. All six focused commands then pass: static policy, Ruff, format, mypy, affected30 tests, and mandatory Python/integrity. Actual collection is1801 unique IDs (1799 common +2 POSIX); all1801 pass in377.98s with no skipped tests. Independent source8 and actual-data12 reviews clear that scope.\n\nThe packet preserves original wrong-head preflight, failed full, static RED, observer correction history and all selected focused raw records. Archive payloads are safe unique regular files with exhaustive hashes and source-byte readback. It contains no physical native/tool/runtime/cache images. This does not establish a fresh clean all20 result, GUI/LaunchServices, foreign package certification, W06 verification, M03 acceptance or release readiness. Progress remains38/300 VERIFIED and W06 the sole IN_PROGRESS package.\n"
generated('summary.json',summary);generated('README.md',readme)
add(Path(__file__),'retention-builder.py')
generated('source-copies.json',{'scope':'Selected exact copies; generated files explicitly derived, not raw execution','files':copies})
generated('members.json',{'scope':'Exhaustive members excluding only this self member; outer includes it','files':dict(selected)})
archive=OUT/'proof.tar.gz'
with archive.open('wb') as f,gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
    for name,row in sorted(selected.items()):
        data=(OUT/name).read_bytes()
        if sha(data)!=row['sha256'] or len(data)!=row['bytes']:raise RuntimeError('Staged drift')
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
        tar.addfile(info,io.BytesIO(data))
seen={}
with tarfile.open(archive,'r:gz') as tar:
    for member in tar.getmembers():
        if not safe(member.name) or not member.isfile() or member.name in seen:raise RuntimeError('Unsafe archive')
        data=tar.extractfile(member).read();seen[member.name]={'bytes':len(data),'sha256':sha(data)}
if seen!=selected:raise RuntimeError('Archive member closure failed')
embedded=json.loads((OUT/'members/members.json').read_text())['files']
if embedded!={k:v for k,v in selected.items() if k!='members/members.json'}:raise RuntimeError('Embedded closure failed')
for row in copies:
    data=Path(row['source']).read_bytes()
    if len(data)!=row['bytes'] or sha(data)!=row['sha256']:raise RuntimeError('Original source drift')
archive_binding={'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())}
manifest={'archive':archive_binding,'files':selected,'safe_regular_members':len(selected),'payload_bytes':sum(r['bytes'] for r in selected.values()),'scope':'Finite W06 collection correction, actual failed full preserved; no full20 or milestone acceptance'}
(OUT/'retention-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
(OUT/'README.md').write_text(readme)
(OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
(OUT/'artifact.json').write_text(json.dumps({'scope':'DERIVED evidence descriptor, not execution/Gate verdict','archive':archive_binding,'members':len(selected),'payload_bytes':manifest['payload_bytes'],'status':'W06_IN_PROGRESS','physical_images_in_archive':False,'whole_current20':'NOT_ESTABLISHED_AFTER_CORRECTION'},indent=2)+'\n')
print(json.dumps({'output':str(OUT),'archive':archive_binding,'members':len(selected),'payload_bytes':manifest['payload_bytes'],'original_copies':len(copies),'readback':'EXHAUSTIVE_SAFE_REGULAR_SOURCE_EQUAL'}))
