from pathlib import Path
import subprocess,os,hashlib,json,stat,time,signal
R=Path('/Users/tanishkalwad/jobapplyv2');E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');Q=E/'m03-w06-closeout-registration/record-tests';Q.mkdir(exist_ok=False)
files=[R/x.decode()for x in subprocess.check_output(['git','ls-files','-z'],cwd=R).split(b'\0')if x]
def snap():return{str(p.relative_to(R)):{'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in files}
before=snap();argv=['uv','run','--no-sync','--offline','pytest','scripts/tests/test_validate_status.py','scripts/tests/test_traceability.py','scripts/tests/test_ui_governance_progress.py','-q','--basetemp',str(Q/'pytest-tmp')];env=dict(os.environ);env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0',TMPDIR=str(Q));start=time.monotonic();signals=[]
with(Q/'pytest.stdout').open('wb')as out,(Q/'pytest.stderr').open('wb')as err:
 child=subprocess.Popen(argv,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
 try:code=child.wait(timeout=50)
 except subprocess.TimeoutExpired:
  if child.poll()is None:os.killpg(child.pid,signal.SIGKILL);signals.append('SIGKILL')
  code=child.wait(timeout=3)
try:os.killpg(child.pid,0);group='PRESENT'
except ProcessLookupError:group='ABSENT'
after=snap();result={'argv':argv,'seconds':time.monotonic()-start,'exit_code':code,'direct_child_reaped':child.returncode is not None,'observed_group':group,'cleanup_signals':signals,'source_files':len(files),'before':before,'after':after,'full_modes_bytes_unchanged':before==after,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)};(Q/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in('before','after')}));print((Q/'pytest.stdout').read_text()[-2200:]);raise SystemExit(0 if code==0 and group=='ABSENT'and not signals and before==after else 1)
