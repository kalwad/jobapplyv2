# Public structural inventory

Read-only anonymous Chromium inspection on 2026-10-16. No extension fill, competitor comparison, input, credential, consent or submit action. Twenty blank forms and ten Workday method-choice boundaries; these are structural observations only.

| ATS | Employer | Current title | Visible controls | Boundary | Source |
|---|---|---|---:|---|---|
| WORKDAY | Salesforce | Keynote Production Associate Manager | 0 | APPLICATION_METHOD_CHOICE_NOT_ACTIVATED | https://salesforce.wd12.myworkdayjobs.com/en-US/external_career_site/job/Illinois---Chicago/Keynote-Production-Associate-Manager_JR363084/apply |
| WORKDAY | Intel | Yield Product Development Engineer | 0 | APPLICATION_METHOD_CHOICE_NOT_ACTIVATED | https://intel.wd1.myworkdayjobs.com/en-US/External/job/US-Oregon-Hillsboro/Yield-Product-Development-Engineer_JR0288027/apply |
| WORKDAY | Broadridge | C#/.Net Developer with Automation Skills (CONTRACT) ON-SITE | 0 | APPLICATION_METHOD_CHOICE_NOT_ACTIVATED | https://broadridge.wd5.myworkdayjobs.com/en-US/Careers/job/Newark-NJ/C--Net-Developer-with-Automation-Skills--CONTRACT--REMOTE_JR1085850/apply |
| WORKDAY | FactSet | Legal Counsel- Data Privacy & Technology | 0 | APPLICATION_METHOD_CHOICE_NOT_ACTIVATED | https://factset.wd108.myworkdayjobs.com/en-US/FactSetCareers/job/London-GBR/Legal-Counsel--Data-Privacy---Technology_R33395-1/apply |
| WORKDAY | Allegion | DevOps Engineer | 0 | APPLICATION_METHOD_CHOICE_NOT_ACTIVATED | https://allegion.wd5.myworkdayjobs.com/en-US/careers/job/Carmel-IN/DevOps-Engineer_JR37668/apply |
| WORKDAY | Duke Energy | Associate Stakeholder Engagement Manager / Stakeholder Engagement Manager | 0 | APPLICATION_METHOD_CHOICE_NOT_ACTIVATED | https://dukeenergy.wd1.myworkdayjobs.com/en-US/search/job/St-Petersburg-FL/Associate-Stakeholder-Engagement-Manager---Stakeholder-Engagement-Manager_R42040/apply |
| WORKDAY | CoStar | Product Intern - Richmond, VA (Summer 2027) | 0 | APPLICATION_METHOD_CHOICE_NOT_ACTIVATED | https://costar.wd1.myworkdayjobs.com/en-US/Costar_Campus/job/US-VA-Richmond---CoStar-Tower/Product-Intern---Richmond--VA--Summer-2027-_R39900/apply |
| WORKDAY | Medtronic | Credit Services Representative (Collections/Mid-shift) | 0 | APPLICATION_METHOD_CHOICE_NOT_ACTIVATED | https://medtronic.wd1.myworkdayjobs.com/en-US/MedtronicCareers/job/Taguig-City-National-Capital-Region-Philippines/Credit-Services-Representative--Collections-Mid-shift-_R76693-1/apply |
| WORKDAY | Workday | Principal, Partner Sales Executive - Accenture | 0 | APPLICATION_METHOD_CHOICE_NOT_ACTIVATED | https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/USA-IL-Chicago/Principal--Partner-Sales-Executive---GSI_JR-0110686/apply |
| WORKDAY | Boeing | IT Systems Administrator – Millennium Space Systems | 0 | APPLICATION_METHOD_CHOICE_NOT_ACTIVATED | https://boeing.wd1.myworkdayjobs.com/en-US/external_subsidiary/job/USA---El-Segundo-CA/IT-Systems-Administrator---Millennium-Space-Systems_JR2026525275/apply |
| GREENHOUSE | NetDocuments | Job Application for Prinicipal Software Engineer at NetDocuments | 17 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://job-boards.greenhouse.io/netdocuments/jobs/5440437008 |
| GREENHOUSE | Moloco | Job Application for Expression of Interest(채용관심등록): Software Engineer - Korea at Moloco | 19 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://job-boards.greenhouse.io/moloco/jobs/7711666003 |
| GREENHOUSE | Cloudflare | Job Application for Software Engineer, Workers Deploy & Config at Cloudflare | 20 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://job-boards.greenhouse.io/cloudflare/jobs/7377424 |
| GREENHOUSE | Y Soft | Job Application for Medior Program Agilist - part-time at Y Soft | 12 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://job-boards.greenhouse.io/ysoftcorporation/jobs/7979050003 |
| GREENHOUSE | Affirm | Job Application for Financial Model Risk Management Lead at Affirm | 23 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://job-boards.greenhouse.io/affirm/jobs/7815948003 |
| GREENHOUSE | Appian | Job Application for Demo Engineer / Presales Solutions Consulting at Appian Corporation | 18 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://job-boards.greenhouse.io/appian/jobs/8047813 |
| GREENHOUSE | Canonical | Job Application for Python and Kubernetes Software Engineer - Data, AI/ML & Analytics at Canonical - Jobs | 26 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://job-boards.greenhouse.io/canonicaljobs/jobs/6626809 |
| GREENHOUSE | Cognitiv | Job Application for Senior Site Reliability Engineer, AWS/Datacenter Hybrid at Cognitiv | 21 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://job-boards.greenhouse.io/cognitiv/jobs/4385687009 |
| LEVER | Right Side Up | Right Side Up - General Freelance Application | 9 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://jobs.lever.co/rightsideup/993a91a8-752e-451c-8a2d-0f63049b0b9a/apply |
| LEVER | Palantir | Palantir Technologies - Software Engineer, New Grad | 101 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://jobs.lever.co/palantir/c34b424e-caf2-455a-b104-ae1096ccca29/apply |
| LEVER | 360Learning | 360Learning - Software Engineer | 32 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://jobs.lever.co/360learning/66e3841f-f92b-42f5-a4d3-c4290010e2d5/apply |
| LEVER | Windfall | Windfall - Software Engineer - Backend (Varying Levels) | 29 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://jobs.lever.co/windfalldata/cc81b2c3-e504-4acf-9870-bcf5dc6b4b23/apply |
| LEVER | 360Learning | 360Learning - Spontaneous Application | 31 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://jobs.lever.co/360learning/9d22544a-645e-4065-8066-a9c2df4cc90b/apply |
| LEVER | Palantir | Palantir Technologies - Forward Deployed Software Engineer | 60 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://jobs.lever.co/palantir/5168e8fd-fec1-4fea-b7a1-81bdaea65850/apply |
| LEVER | Palantir | Palantir Technologies - Forward Deployed Reliability Engineer | 57 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://jobs.lever.co/palantir/689e6869-01bc-40f1-b580-adb33a020065/apply |
| LEVER | Windfall | Windfall - Solutions Consultant | 28 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://jobs.lever.co/windfalldata/6e838fc4-565a-45cc-b00c-bf6c8668035e/apply |
| ASHBY | Ramp | Software Engineer, Production Engineering @ Ramp | 9 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://jobs.ashbyhq.com/Ramp/be496b52-cfbf-494e-b862-61fb4a188b24/application |
| ASHBY | Ramp | Software Engineer, Backend, Growth @ Ramp | 11 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://jobs.ashbyhq.com/ramp/428f41e2-48e8-409d-b5e3-8053f7fc7a27/application |
| ASHBY | Linear | Developer Relations @ Linear | 10 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://jobs.ashbyhq.com/Linear/1d652292-04d9-405c-8101-578efd020e94/application |
| ASHBY | Linear | Analytics Engineer @ Linear | 11 | BLANK_PUBLIC_APPLICATION_FORM_NOT_INTERACTED | https://jobs.ashbyhq.com/linear/f272fc4a-91a7-4dcf-9cb5-3600ebaf14e1/application |

All 54 original/supplemental page observations and current source commitments are retained. Gate A fill/scoring/comparison evidence remains unexecuted.
