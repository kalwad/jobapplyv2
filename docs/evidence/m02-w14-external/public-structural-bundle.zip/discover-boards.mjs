import {chromium} from '/Users/tanishkalwad/jobapplyv2/node_modules/@playwright/test/index.mjs';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const root='/tmp/japp-public-structure.BfXv1t';
const original=JSON.parse(readFileSync(root+'/inventory.json','utf8'));
const inputs=original.rows.filter(r=>(r.ats==='WORKDAY'&&!r.snapshot?.entry_links.some(l=>/^apply/i.test(l.label)))||(r.ats==='GREENHOUSE'&&['Y Soft','Affirm'].includes(r.employer))).map(r=>({...r,board_url:r.ats==='WORKDAY'?r.url.split('/job/')[0]:r.final_url}));
const browser=await chromium.launch({channel:'chromium'});const rows=[];
try{
 for(const r of inputs){const context=await browser.newContext();const p=await context.newPage();let status=null,error=null;
 try{status=(await p.goto(r.board_url,{waitUntil:'domcontentloaded',timeout:25000}))?.status()??null;await p.waitForTimeout(2500);await p.locator('a[href*="/job/"]').first().waitFor({state:'visible',timeout:5000}).catch(()=>{});}catch(e){error={name:e.name,message:String(e.message).split('\n')[0]};}
 const links=await p.locator('a[href]').evaluateAll(nodes=>nodes.filter(n=>{const b=n.getBoundingClientRect();return b.width>0&&b.height>0&&/\/jobs?\//.test(n.href);}).map(n=>({title:n.textContent.replace(/\s+/g,' ').trim().slice(0,180),url:n.href.split('?')[0].split('#')[0]}))).catch(()=>[]);
 const unique=[...new Map(links.map(l=>[l.url,l])).values()];rows.push({parent_id:r.id,ats:r.ats,employer:r.employer,board_url:r.board_url,final_url:p.url().split('?')[0],observed_at:new Date().toISOString(),http_status:status,error,visible_job_links:unique.slice(0,12),selected:unique[0]??null});console.log(JSON.stringify({employer:r.employer,links:unique.length,selected:unique[0]?.title??null}));await context.close();}
 const bytes=JSON.stringify({mode:'READ_ONLY_VISIBLE_BOARD_LINK_DISCOVERY',browser_version:browser.version(),rows},null,2)+'\n';writeFileSync(root+'/board-discovery.json',bytes);console.log('sha256:'+createHash('sha256').update(bytes).digest('hex'));
}finally{await browser.close();}
