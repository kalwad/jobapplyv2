import { chromium } from '/Users/tanishkalwad/jobapplyv2/node_modules/@playwright/test/index.mjs';
import { readFileSync, writeFileSync, appendFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

const root='/tmp/japp-public-structure.BfXv1t';
const candidates=JSON.parse(readFileSync(root+'/gh-final-candidates.json','utf8'));
const digest=data=>'sha256:'+createHash('sha256').update(data).digest('hex');
const cleanUrl=url=>{try{const u=new URL(url);return u.origin+u.pathname;}catch{return 'UNAVAILABLE';}};
const browser=await chromium.launch({channel:'chromium'});
const started_at=new Date().toISOString();
const rows=[];
const browser_version=browser.version();
try{
 for(let i=0;i<candidates.length;i++){
  const c=candidates[i];
  const context=await browser.newContext({viewport:{width:1280,height:900}});
  const page=await context.newPage();
  const observed_at=new Date().toISOString();
  const network_methods={};
  context.on('request',req=>{network_methods[req.method()]=(network_methods[req.method()]??0)+1;});
  let error=null;let status=null;let navigation_provenance=null;
  try{
   const response=await page.goto(c.url,{waitUntil:'domcontentloaded',timeout:25000});
   status=response?.status()??null;
   await page.waitForTimeout(1800);
   await page.waitForFunction(()=>document.body?.innerText.length>120,{timeout:5000}).catch(()=>{});
   if(c.follow_application_link){
    const links=await page.locator('a[href]').evaluateAll(nodes=>nodes.filter(n=>/^apply/i.test(n.textContent.trim())&&/\/apply$|\/application$/.test(new URL(n.href).pathname)).map(n=>({label:n.textContent.trim(),url:n.href.split('?')[0].split('#')[0]})));
    const selected=links.find(l=>new URL(l.url).host===new URL(page.url()).host);
    if(selected){navigation_provenance={detail_url:cleanUrl(page.url()),detail_title:await page.title(),observed_link:selected};status=(await page.goto(selected.url,{waitUntil:'domcontentloaded',timeout:25000}))?.status()??null;await page.waitForTimeout(1800);}
   }
  }catch(e){error={name:e.name,message:String(e.message).split('\n')[0]};}
  let snapshot=null;
  try{
   snapshot=await page.evaluate(()=>{
    const visible=e=>{const s=getComputedStyle(e);const r=e.getBoundingClientRect();return s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0&&!e.closest('[hidden],[aria-hidden="true"]');};
    const text=e=>(e?.textContent??'').replace(/\s+/g,' ').trim().slice(0,180);
    const label=e=>{
     if(e.labels?.length)return [...e.labels].map(text).join(' ').slice(0,180);
     const aria=e.getAttribute('aria-label');if(aria)return aria.slice(0,180);
     const ids=e.getAttribute('aria-labelledby');if(ids)return ids.split(/\s+/).map(id=>text(document.getElementById(id))).join(' ').slice(0,180);
     return (e.getAttribute('placeholder')??'').slice(0,180);
    };
    const controls=[...document.querySelectorAll('input,textarea,select,[role="combobox"],[role="listbox"]')].map(e=>({tag:e.tagName,role:e.getAttribute('role'),type:e.tagName==='INPUT'?e.type:null,visible:visible(e),required:e.required===true||e.getAttribute('aria-required')==='true',disabled:e.disabled===true||e.getAttribute('aria-disabled')==='true',label:label(e),autocomplete:e.getAttribute('autocomplete'),option_count:e.tagName==='SELECT'?e.options.length:null}));
    const buttons=[...document.querySelectorAll('button,[role="button"],input[type="submit"]')].filter(visible).map(e=>({tag:e.tagName,type:e.getAttribute('type'),label:text(e)||e.getAttribute('aria-label')||e.getAttribute('value')||''}));
    const entry_links=[...document.querySelectorAll('a[href]')].filter(e=>visible(e)&&/^(apply|application|apply now|apply for this job|sign in|create account)(\s|$)/i.test(text(e))).map(e=>({label:text(e),href:e.href}));
    return {title:document.title,headings:[...document.querySelectorAll('h1,h2')].filter(visible).map(text).slice(0,15),controls,buttons,entry_links,frame_hosts:[...document.querySelectorAll('iframe[src]')].map(e=>{try{return new URL(e.src).host;}catch{return 'UNKNOWN';}}),body_text:document.body?.innerText??'',form_count:document.forms.length};
   });
  }catch(e){if(!error)error={name:e.name,message:String(e.message).split('\n')[0]};}
  let availability='NAVIGATION_ERROR';
  if(snapshot){
   const body=snapshot.body_text;
   const title=snapshot.title;
   const hasPassword=snapshot.controls.some(x=>x.visible&&x.type==='password');
   const formLike=snapshot.controls.filter(x=>x.visible&&!['hidden','submit','button'].includes(x.type)).length>=4&&snapshot.controls.some(x=>x.visible&&(x.type==='email'||/email/i.test(x.label)));
   if(status===403||status===401)availability='ACCESS_DENIED';
   else if(status===404||/job (?:is no longer|not found)|position (?:is no longer|has been filled)|no longer accepting applications|not accepting applications|this job has been closed/i.test(body))availability='UNAVAILABLE_OR_CLOSED';
   else if(/access denied|verify you are human|checking your browser|just a moment|security verification/i.test(title)||(/access denied/i.test(body)&&body.length<1000))availability='ACCESS_OR_CHALLENGE_BOUNDARY';
   else if(hasPassword)availability='AUTHENTICATION_BOUNDARY';
   else if(formLike)availability='VISIBLE_APPLICATION_CONTROLS';
   else if(body.length>300)availability='PUBLIC_DETAIL_OR_BOARD_ONLY';
   else if(!error)availability='EMPTY_OR_UNSETTLED_PUBLIC_PAGE';
   snapshot.body_text_digest=digest(body);
   snapshot.body_text_length=body.length;
   snapshot.boundary_flags={password_control_visible:hasPassword,captcha_frame_present:snapshot.frame_hosts.some(x=>/captcha/i.test(x)),sign_in_link_visible:snapshot.entry_links.some(x=>/^sign in/i.test(x.label)),closed_job_notice:/job (?:is no longer|not found)|position (?:is no longer|has been filled)|no longer accepting applications|not accepting applications|this job has been closed/i.test(body)};
   delete snapshot.body_text;
   snapshot.entry_links=snapshot.entry_links.map(x=>({label:x.label,url:cleanUrl(x.href),full_url_digest:digest(x.href)}));
  }
  const row={id:`PUBLIC-GH-FINAL-${String(i+1).padStart(2,'0')}`,...c,observed_at,final_url:cleanUrl(page.url()),http_status:status,availability,error,navigation_provenance,network_methods,snapshot,action_authority:'READ_ONLY_NAVIGATION_AND_DOM_OBSERVATION',field_input_performed:false,submit_control_activated:false,authentication_performed:false,extension_fill_executed:false,competitor_comparison_executed:false};
  rows.push(row);
  appendFileSync(root+'/rows-gh-final.jsonl',JSON.stringify(row)+'\n');
  console.log(JSON.stringify({row:i+1,ats:c.ats,employer:c.employer,status,availability,visible_controls:snapshot?.controls.filter(x=>x.visible).length??0,error:error?.name??null}));
  await context.close();
 }
 const summary={format_version:'M02_W14_PUBLIC_STRUCTURAL_INVENTORY_1',authority:'NONE',mode:'READ_ONLY_PUBLIC_STRUCTURAL_INSPECTION',started_at,ended_at:new Date().toISOString(),client_date:'2026-10-16',client_timezone:'America/Detroit',browser_version,inspector_digest:digest(readFileSync(root+'/inspect-gh-final.mjs')),candidate_digest:digest(readFileSync(root+'/gh-final-candidates.json')),discovery_digest:digest(readFileSync(root+'/discovery-final.json')),limitations:['No extension fill, benchmark scoring, competitor operation, form input, application submission, authenticated access or security bypass occurred.','Only fresh anonymous page navigation and DOM reads were executed; normal website background network requests may include read-only POST operations.','Public detail pages and access boundaries do not count as successful application-form autofill validation.','Search discovery is not current availability proof; each browser result records its own observed state.','No form values, page source, private content or full job descriptions are retained.'],rows};
 const bytes=JSON.stringify(summary,null,2)+'\n';writeFileSync(root+'/inventory-gh-final.json',bytes);writeFileSync(root+'/inventory-gh-final.digest.txt',digest(bytes)+'\n');
 console.log(JSON.stringify({inventory:root+'/inventory-gh-final.json',digest:digest(bytes),rows:rows.length,browser_version}));
}finally{await browser.close();}
