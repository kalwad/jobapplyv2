"""Preserve the failed full run; correct only operation-list terminal ordering."""
from pathlib import Path
import ast,datetime,difflib,hashlib,json,os,signal,subprocess,time

E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
R=Path('/Users/tanishkalwad/jobapplyv2')
OUT=E/'m03-gnome-terminal-order-preparation/v1'
P=OUT/'proposal'
PY=str(R/'.venv/bin/python')
TARGET='scripts/linux_gnome/ubuntu_gnome_guest.py'
TEST='scripts/tests/test_ubuntu_gnome_boundaries.py'
OUT.mkdir(parents=True,exist_ok=False)

def sha(body):return hashlib.sha256(body).hexdigest()
def put(path,body):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:stream.write(body)
def dump(path,value):put(path,(json.dumps(value,indent=2)+'\n').encode())

def run(name,argv,expected=0,cap=60):
    begin=time.monotonic();utc=datetime.datetime.now(datetime.timezone.utc).isoformat();signals=[]
    env={'PATH':'/opt/homebrew/opt/node@24/bin:/Users/tanishkalwad/.local/bin:/opt/homebrew/bin:/usr/bin:/bin',
        'PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1',
        'MYPYPATH':str(P/'scripts/linux_gnome')+':'+str(P/'scripts')}
    with (OUT/(name+'.stdout')).open('xb') as stdout,(OUT/(name+'.stderr')).open('xb') as stderr:
        child=subprocess.Popen(argv,cwd=P,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
        try:code=child.wait(timeout=cap)
        except subprocess.TimeoutExpired:
            if child.poll() is None:os.killpg(child.pid,signal.SIGKILL);signals.append('SIGKILL-owned-group-timeout')
            code=child.wait(timeout=3)
    try:os.killpg(child.pid,0);group='PRESENT'
    except ProcessLookupError:group='ABSENT'
    row={'argv':argv,'start_utc':utc,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':time.monotonic()-begin,
        'pid':child.pid,'pgid':child.pid,'exit_code':code,'expected_exit':expected,'reaped':True,'group':group,'signals':signals,
        'stdout_sha256':sha((OUT/(name+'.stdout')).read_bytes()),'stderr_sha256':sha((OUT/(name+'.stderr')).read_bytes())}
    dump(OUT/(name+'.receipt.json'),row)
    assert code==expected and not signals and group=='ABSENT',row

put(OUT/'executed-source.py',Path(__file__).read_bytes())
source_map=json.loads((E/'clean-full-374b6fe-independent-review/v1/immutable-git-source-sha256.json').read_text())['files']
inputs={}
for name,row in source_map.items():
    if name.startswith('scripts/') and name.endswith('.py') and not name.startswith('scripts/tests/') or name==TEST:
        body=(R/name).read_bytes();assert sha(body)==row['sha256']
        put(P/name,body);inputs[name]={'bytes':len(body),'sha256':sha(body)}
put(OUT/'pytest.ini',b'[pytest]\naddopts = -ra --strict-markers --strict-config\nfilterwarnings = error\npythonpath = proposal/scripts proposal/scripts/linux_gnome\n')
pytest=[PY,'-I','-B','-m','pytest','-c',str(OUT/'pytest.ini'),'--rootdir',str(P),'--confcutdir',str(P),'--disable-plugin-autoload',str(P/TEST)]
before=(P/TARGET).read_bytes()
put(OUT/'guest.before.py',before)
run('01-original-old-tests',pytest,expected=1)
assert b'assert guest.OPERATIONS[-1] == "finish"' in (OUT/'01-original-old-tests.stdout').read_bytes()
needle=b'OPERATIONS += SHELL_OPERATIONS'
assert before.count(needle)==1
after=before.replace(needle,b'OPERATIONS = OPERATIONS[:-1] + SHELL_OPERATIONS + OPERATIONS[-1:]')
(P/TARGET).write_bytes(after)
put(OUT/'guest.after.py',after)
put(OUT/'delta.patch',''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='before/'+TARGET,tofile='after/'+TARGET)).encode())
old_tree=ast.parse(before);new_tree=ast.parse(after)
old_functions={node.name:ast.dump(node,include_attributes=False) for node in old_tree.body if isinstance(node,(ast.FunctionDef,ast.ClassDef))}
new_functions={node.name:ast.dump(node,include_attributes=False) for node in new_tree.body if isinstance(node,(ast.FunctionDef,ast.ClassDef))}
assert old_functions==new_functions
run('02-corrected-old-tests',pytest)
run('03-ruff',[PY,'-I','-B','-m','ruff','check','--config',str(R/'pyproject.toml'),str(P/TARGET)])
run('04-format',[PY,'-I','-B','-m','ruff','format','--check','--config',str(R/'pyproject.toml'),str(P/TARGET)])
run('05-mypy',[PY,'-I','-B','-m','mypy','--strict','--platform','linux','--cache-dir',str(OUT/'mypy-cache'),str(P/TARGET)])
assert (P/TEST).read_bytes()==(R/TEST).read_bytes()
assert (R/TARGET).read_bytes()==before
dump(OUT/'SOURCE.json',{'canonical_reference':'374b6fe484b5dd82c4a7fa1d751a77369ec79431','target':TARGET,
    'before_sha256':sha(before),'after_sha256':sha(after),'inherited_test_sha256':sha((P/TEST).read_bytes()),
    'all_functions_and_classes_AST_exact':True,'inputs':inputs,
    'scope':'Single operation-list composition assignment; original cleanup terminal remains last while all old/new operation membership and relative order are preserved. No guest/native/network actor or canonical writes.'})
print(json.dumps({'proposal':str(OUT),'target':TARGET,'before':sha(before),'after':sha(after),'old_test_bytes_unchanged':True}))
