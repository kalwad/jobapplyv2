from pathlib import Path, PurePosixPath
import gzip,hashlib,io,json,stat,tarfile
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
P=E/'m03-gnome-terminal-order-preparation/v1'
R=Path('/Users/tanishkalwad/jobapplyv2')

def meta(path):
    s=path.lstat();assert stat.S_ISREG(s.st_mode)
    return {'bytes':s.st_size,'full_mode':s.st_mode,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
def dump(name,value):
    with (P/name).open('x') as output:output.write(json.dumps(value,indent=2)+'\n')

assert not any((P/name).exists() for name in ('HANDOFF.json','manifest.json','proof.tar.gz','SEAL.json'))
(P/'seal-executed-source.py').write_bytes(Path(__file__).read_bytes())
config=(R/'pyproject.toml').read_bytes()
mapping=json.loads((E/'clean-full-374b6fe-independent-review/v1/immutable-git-source-sha256.json').read_text())
assert hashlib.sha256(config).hexdigest()==mapping['files']['pyproject.toml']['sha256']
(P/'canonical-pyproject.toml').write_bytes(config)
before=(P/'01-original-old-tests.stdout').read_text();after=(P/'02-corrected-old-tests.stdout').read_text()
assert '1 failed, 35 passed in 0.46s' in before and '36 passed in 0.33s' in after
receipts=[json.loads(p.read_text()) for p in sorted(P.glob('*.receipt.json'))]
assert len(receipts)==5 and [r['exit_code'] for r in receipts]==[1,0,0,0,0]
assert all(r['reaped'] and r['group']=='ABSENT' and not r['signals'] for r in receipts)
dump('HANDOFF.json',{'source':meta(P/'SOURCE.json'),'target':'scripts/linux_gnome/ubuntu_gnome_guest.py',
    'after_sha256':'3f652bd9737bbe35e0d3398edc64e2cf3d9d4d75b1d65ec8852a5a1e2aa9a360',
    'actual_old_suite_red':'1failed35passed0.46s','actual_corrected_old_suite':'36passed0.33s',
    'strict':'Ruff/format/Mypy-linux1PASS','child_closure':'5reaped/groupsABSENT/no signals/timeouts',
    'canonical_config_observed_after_commands':meta(P/'canonical-pyproject.toml'),
    'scope':'Outside source/QA only. Full374 remains1FAIL2787PASS,19ACTIVEPASS/PythonFAIL. No native/guest/UI/VM/network/canonical execution or acceptance.'})
files=[]
for p in sorted(P.rglob('*')):
    if any(part in {'mypy-cache','.ruff_cache','.pytest_cache','__pycache__'} for part in p.relative_to(P).parts):continue
    if p.is_dir():continue
    files.append({'path':p.relative_to(P).as_posix(),**meta(p)})
dump('manifest.json',{'files':files,'omitted':'Only disposable Mypy/Ruff/Pytest/bytecode caches; all selected source/config/rawQA retained.'})
expected=files+[{'path':'manifest.json',**meta(P/'manifest.json')}]
with (P/'proof.tar.gz').open('xb') as output,gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as archive:
    for row in expected:
        name=row['path'];path=PurePosixPath(name);assert not path.is_absolute() and '..' not in path.parts
        body=(P/name).read_bytes();info=tarfile.TarInfo(name);info.type=tarfile.REGTYPE;info.mode=row['full_mode']&0o7777;info.size=len(body);info.mtime=0
        archive.addfile(info,io.BytesIO(body))
with tarfile.open(P/'proof.tar.gz','r:gz') as archive:
    members=archive.getmembers();assert len(members)==len({m.name for m in members})==len(expected)
    for member in members:
        assert member.isfile() and archive.extractfile(member).read()==(P/member.name).read_bytes()
        assert stat.S_IFREG|member.mode==(P/member.name).stat().st_mode
dump('SEAL.json',{'source':meta(P/'SOURCE.json'),'handoff':meta(P/'HANDOFF.json'),'manifest':meta(P/'manifest.json'),'proof':meta(P/'proof.tar.gz'),'safe_regular_members':len(expected)})
print((P/'SEAL.json').read_text())
