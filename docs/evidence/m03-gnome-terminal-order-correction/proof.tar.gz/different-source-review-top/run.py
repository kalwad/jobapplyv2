"""Bounded own inert-test process, never a native guest/runtime actor."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time
BASE=Path(__file__).resolve().parent
def snapshot():
 return {str(p.relative_to(BASE)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'full_mode':p.stat().st_mode} for d in ['copy','tests'] for p in sorted((BASE/d).rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
out=BASE/'qa'/'pure';out.mkdir();before=snapshot();(out/'before.json').write_text(json.dumps(before,indent=2)+'\n')
env={'PATH':'/usr/bin:/bin','HOME':str(out),'TMPDIR':str(out),'PYTHONDONTWRITEBYTECODE':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1'}
argv=[sys.executable,'-I','-B','-m','pytest','--disable-plugin-autoload','-c',str(BASE/'pytest.ini'),'--rootdir',str(BASE),'--confcutdir',str(BASE),'--basetemp',str(out/'tmp'),str(BASE/'copy/scripts/tests/test_ubuntu_gnome_boundaries.py'),str(BASE/'tests'),'-q']
start=time.monotonic();child=None;signals=[]
with (out/'stdout').open('wb') as stdout,(out/'stderr').open('wb') as stderr:
 try:
  child=subprocess.Popen(argv,cwd=BASE,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True);child.wait(timeout=60)
 finally:
  if child is not None and child.poll() is None:os.killpg(child.pid,signal.SIGKILL);signals.append('SIGKILL owned live QA');child.wait(timeout=3)
try:os.killpg(child.pid,0);absent=False
except ProcessLookupError:absent=True
after=snapshot();(out/'after.json').write_text(json.dumps(after,indent=2)+'\n')
r={'argv':argv,'exit_code':child.returncode,'seconds':time.monotonic()-start,'reaped':child.returncode is not None,'group_absent':absent,'signals':signals,'endpoints_equal':before==after,'scope':'own copied pure checks with mock handlers/socket/native backend only'}
(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
