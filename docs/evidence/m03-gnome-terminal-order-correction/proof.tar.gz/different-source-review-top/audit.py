"""Finite correction source/data joins only, no guest/native execution."""
from pathlib import Path
import ast,hashlib,json,stat,tarfile

BASE=Path(__file__).resolve().parent
SUBJECT=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/m03-gnome-terminal-order-preparation/v1')
ROOT=Path('/Users/tanishkalwad/jobapplyv2')
checks=[]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def check(name,value):
 checks.append({'name':name,'passed':value})
 if not value:raise AssertionError(name)
def bind(path,row,name):check(name,path.is_file() and path.stat().st_size==row['bytes'] and path.stat().st_mode==row['full_mode'] and sha(path)==row['sha256'])
source=json.loads((SUBJECT/'SOURCE.json').read_text());seal=json.loads((SUBJECT/'SEAL.json').read_text())
for key,name in [('source','SOURCE.json'),('handoff','HANDOFF.json'),('manifest','manifest.json'),('proof','proof.tar.gz')]:bind(SUBJECT/name,seal[key],'seal '+name)
check('supplied source',seal['source']['sha256']=='dca9577db6a8cf2acbb13eb0e28562a68a2a443833a5e141d3b8587658d6921c')
check('supplied handoff',seal['handoff']['sha256']=='baa4cb40d9a53eb35d5ed8647edf5838131e87c3f8b1554ad536ec0482c42361')
manifest=json.loads((SUBJECT/'manifest.json').read_text());rows={r['path']:r for r in manifest['files']}
for name,row in rows.items():bind(SUBJECT/name,row,'retained '+name)
seen=set()
with tarfile.open(SUBJECT/'proof.tar.gz','r:gz') as archive:
 for member in archive:
  check('safe archive '+member.name,member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts and member.name not in seen);seen.add(member.name)
  row=rows.get(member.name,seal['manifest'] if member.name=='manifest.json' else None);check('known archive '+member.name,row is not None)
  body=archive.extractfile(member).read();check('archive body/mode '+member.name,hashlib.sha256(body).hexdigest()==row['sha256'] and len(body)==row['bytes'] and (stat.S_IFREG|member.mode)==row['full_mode'])
check('exact65 regular members',len(seen)==65 and seen==set(rows)|{'manifest.json'})
before=(SUBJECT/'guest.before.py').read_bytes();after=(SUBJECT/'guest.after.py').read_bytes()
check('one exact assignment replacement',before.count(b'OPERATIONS += SHELL_OPERATIONS')==1 and after==before.replace(b'OPERATIONS += SHELL_OPERATIONS',b'OPERATIONS = OPERATIONS[:-1] + SHELL_OPERATIONS + OPERATIONS[-1:]'))
check('original source pin',hashlib.sha256(before).hexdigest()==source['before_sha256'])
check('corrected source pin',hashlib.sha256(after).hexdigest()==source['after_sha256'])
def bodies(body):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(body).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
check('every function/class exact AST',bodies(before)==bodies(after))
for name,row in source['inputs'].items():
 check('exact canonical finite preimage '+name,sha(ROOT/name)==row['sha256'] and (ROOT/name).stat().st_size==row['bytes'])
 expected=source['after_sha256'] if name==source['target'] else row['sha256']
 check('proposal component '+name,sha(SUBJECT/'proposal'/name)==expected)
 check('own copy component '+name,sha(BASE/'copy'/name)==expected and (BASE/'copy'/name).stat().st_mode==(SUBJECT/'proposal'/name).stat().st_mode)
check('inherited full test bytes exact',sha(BASE/'copy/scripts/tests/test_ubuntu_gnome_boundaries.py')==source['inherited_test_sha256'])
check('target mode retained', (ROOT/source['target']).stat().st_mode==(SUBJECT/'proposal'/source['target']).stat().st_mode)
check('frozen shell helper',sha(BASE/'copy/scripts/linux_gnome/ubuntu_gnome_shell.py')=='c07ca3ecab5d9f7e65960077115d8131d0f017fb94f50353c9ed1b1fc06fdda3')
for label,expected in [('01-original-old-tests',1),('02-corrected-old-tests',0),('03-ruff',0),('04-format',0),('05-mypy',0)]:
 r=json.loads((SUBJECT/(label+'.receipt.json')).read_text())
 check('actual QA result '+label,r['exit_code']==expected and r['expected_exit']==expected)
 check('actual QA custody '+label,r['reaped'] and r['group']=='ABSENT' and not r['signals'])
 for stream in ['stdout','stderr']:check('actual raw '+label+' '+stream,sha(SUBJECT/(label+'.'+stream))==r[stream+'_sha256'])
check('original actual RED', '1 failed, 35 passed' in (SUBJECT/'01-original-old-tests.stdout').read_text())
check('corrected actual36','36 passed' in (SUBJECT/'02-corrected-old-tests.stdout').read_text())
check('own actual98','98 passed' in (BASE/'qa/pure/stdout').read_text())
r=json.loads((BASE/'qa/pure/receipt.json').read_text());check('own pure child closed',r['exit_code']==0 and r['reaped'] and r['group_absent'] and not r['signals'] and r['endpoints_equal'])
handoff=json.loads((SUBJECT/'HANDOFF.json').read_text());bind(SUBJECT/'canonical-pyproject.toml',handoff['canonical_config_observed_after_commands'],'actual strict config snapshot')
check('current finite strict config same',(ROOT/'pyproject.toml').read_bytes()==(SUBJECT/'canonical-pyproject.toml').read_bytes())
result={'scope':'different author of one-assignment correction only; earlier composition authorship disclosed','passed':len(checks),'failed':0,'checks':checks,'own_pure_tests':98,'original_unchanged_tests':36,'new_inert_controls':62,'full374_status':'19ACTIVEPASS/PythonFAIL,1FAIL2787PASS retained unchanged','no_native_or_guest_claim':True}
(BASE/'data-review.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({'passed':len(checks),'failed':0}))
