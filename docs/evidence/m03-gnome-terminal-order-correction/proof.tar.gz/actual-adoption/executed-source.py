"""Guarded one-file adoption and one known owned cache regeneration."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,py_compile,stat,subprocess,sys

E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
R=Path('/Users/tanishkalwad/jobapplyv2')
O=E/'m03-gnome-terminal-order-canonical-adoption/v1'
P=E/'m03-gnome-terminal-order-preparation/v1'
V=E/'m03-gnome-terminal-order-independent-review/v1'
NAME='scripts/linux_gnome/ubuntu_gnome_guest.py'
S='374b6fe484b5dd82c4a7fa1d751a77369ec79431'

def row(path):
    info=path.lstat();assert stat.S_ISREG(info.st_mode) and not path.is_symlink()
    body=path.read_bytes();return {'bytes':len(body),'full_mode':info.st_mode,'sha256':hashlib.sha256(body).hexdigest()}
def git(*args):return subprocess.check_output(['git','--no-optional-locks',*args],cwd=R,timeout=20).decode().strip()
def tree(path):return {p.relative_to(path).as_posix():row(p) for p in sorted(path.rglob('*')) if p.is_file()}
def snap():
    names=subprocess.check_output(['git','--no-optional-locks','ls-files','--cached','--others','--exclude-standard','-z'],cwd=R,timeout=20).split(b'\0')
    return {'source':{os.fsdecode(name):row(R/os.fsdecode(name)) for name in names if name},
        'runtime':tree(R/'apps/desktop/src-tauri/runtime-payload'),'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain','--untracked-files=all')}
def dump(name,value):
    with (O/name).open('x') as output:output.write(json.dumps(value,indent=2)+'\n')

assert hashlib.sha256((V/'REVIEW.md').read_bytes()).hexdigest()=='7315b91e0cff4a6d7d9bd4bb7bf98e35bf7c4ab1ecf7b1c78b16743da6581333'
assert hashlib.sha256((P/'SOURCE.json').read_bytes()).hexdigest()=='dca9577db6a8cf2acbb13eb0e28562a68a2a443833a5e141d3b8587658d6921c'
assert hashlib.sha256((E/'clean-full-374b6fe-independent-review/v1/REVIEW.md').read_bytes()).hexdigest()=='9be67b212180403bdb66cb51cec2065e8ed8a95c794b6af655945b3c06f82a31'
O.mkdir(parents=True,exist_ok=False)
(O/'executed-source.py').write_bytes(Path(__file__).read_bytes())
before=snap();assert before['head']==S and before['status']=='' and len(before['source'])==2338 and len(before['runtime'])==40
assert before['source'][NAME]['sha256']=='51793e80a95a990d9d26c175045891ed901952f3263d192007278d164f75476b'
dump('before.json',before)
sys.path.insert(0,str(R/'scripts'))
spec=importlib.util.spec_from_file_location('portability_adoption_observer',R/'scripts/check_portability.py')
assert spec is not None and spec.loader is not None
checker=importlib.util.module_from_spec(spec);sys.modules[spec.name]=checker;spec.loader.exec_module(checker)
directory=R/'scripts/linux_gnome'
checker._check_linux_bytecode(directory)
cache=directory/'__pycache__/ubuntu_gnome_guest.cpython-312.pyc'
cache_before=tree(directory/'__pycache__')
old=cache.read_bytes();(O/'owned-cache.before.pyc').write_bytes(old)
afterimage=(P/'guest.after.py').read_bytes()
assert hashlib.sha256(afterimage).hexdigest()=='3f652bd9737bbe35e0d3398edc64e2cf3d9d4d75b1d65ec8852a5a1e2aa9a360'
(O/'guest.before.py').write_bytes((R/NAME).read_bytes())
(O/'guest.after.py').write_bytes(afterimage)
mode=stat.S_IMODE((R/NAME).stat().st_mode)
(R/NAME).write_bytes(afterimage);(R/NAME).chmod(mode)
py_compile.compile(str(R/NAME),cfile=str(cache),dfile=str(R/NAME),doraise=True,optimize=0,invalidation_mode=py_compile.PycInvalidationMode.TIMESTAMP)
checker._check_linux_bytecode(directory)
cache_after=tree(directory/'__pycache__')
assert set(cache_before)==set(cache_after)
changed=[name for name in cache_before if cache_before[name]!=cache_after[name]]
assert changed==['ubuntu_gnome_guest.cpython-312.pyc']
for name in cache_before:
    if name not in changed:assert cache_before[name]==cache_after[name]
header=importlib.util.MAGIC_NUMBER+(0).to_bytes(4,'little')+(int((R/NAME).stat().st_mtime)&0xffffffff).to_bytes(4,'little')+(len(afterimage)&0xffffffff).to_bytes(4,'little')
assert cache.read_bytes()[:16]==header and old[:16]!=header
after=snap()
assert set(before['source'])==set(after['source'])
assert [name for name in before['source'] if before['source'][name]!=after['source'][name]]==[NAME]
assert before['runtime']==after['runtime'] and before['head']==after['head'] and before['tree']==after['tree']
assert after['status']=='M '+NAME
dump('after.json',after)
dump('cache.json',{'before':cache_before,'after':cache_after,'manual_regeneration':changed,'known_old_cache_retained':row(O/'owned-cache.before.pyc'),'old_header_refused_against_new_source':True,
    'policy':'Standard py_compile timestamp/optimize0/exact absolute dfile; strict existing inert checker before and after. No untrusted marshal.loads, unknown cache/source execution or deletion.'})
dump('closure.json',{'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selected_source_delta':[NAME],'unselected2337_sources_and_runtime40_bytes_fullmodes_unchanged':True,
    'head_tree_unchanged':True,'manual_owned_cache_replacements':1,'root_tool_body_exit_record':'Tool exit is observed separately; no independently retained outer-interpreter Popen custody is claimed.',
    'scope':'Adoption/cache only; original full374 remains failed. No product/native/VM/UI/model activation or formal acceptance.'})
print((O/'closure.json').read_text())
