"""Different retained-data review only: no subject imports/compile/native calls."""
from pathlib import Path
import hashlib,json,stat

BASE=Path(__file__).resolve().parent
ROOT=Path('/Users/tanishkalwad/jobapplyv2')
TARGET='scripts/linux_gnome/ubuntu_gnome_guest.py'
COMMIT='374b6fe484b5dd82c4a7fa1d751a77369ec79431'
TREE='a77820bb5430ec8bebcfb17c8010b0764011fabe'
def read(name):return json.loads((BASE/name).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
checks=[]
def check(name,value):
 checks.append({'name':name,'passed':value})
 if not value:raise AssertionError(name)
def full(row):return {'bytes':row['bytes'],'full_mode':row.get('full_mode',stat.S_IFREG|row.get('mode',0)),'sha256':row['sha256']}
a,b=read('adoption/before.json'),read('adoption/after.json')
c,d=read('focus/before.json'),read('focus/after.json')
immutable=read('references/full374-immutable-git-source-sha256.json')
physical=read('references/full374-final-source-runtime.json')
check('2338 source inventory',len(a['source'])==2338 and set(a['source'])==set(b['source'])==set(c['source'])==set(d['source'])==set(immutable['files']))
check('40 runtime inventory',len(a['runtime'])==40 and set(a['runtime'])==set(b['runtime'])==set(c['runtime'])==set(d['runtime']))
check('only selected source changed',[n for n in a['source'] if a['source'][n]!=b['source'][n]]==[TARGET])
for name,row in a['source'].items():
 old=immutable['files'][name]
 expected=b['source'][name]
 check('source full-chain '+name,
  row['sha256']==old['sha256'] and row['bytes']==old['bytes']
  and bool(row['full_mode']&0o111)==(old['git_mode']=='100755')
  and row==physical['source'][name]
  and (name==TARGET or expected==row)
  and full(c['source'][name])==expected==full(d['source'][name]))
for name,row in a['runtime'].items():
 check('runtime full-chain '+name,row==b['runtime'][name]==physical['runtime']['apps/desktop/src-tauri/runtime-payload/'+name]==full(c['runtime'][name])==full(d['runtime'][name]))
for label,snapshot in [('adoption-before',a),('adoption-after',b),('focus-before',c),('focus-after',d)]:
 check(label+' HEAD/tree',snapshot['head']==COMMIT and snapshot['tree']==TREE)
 check(label+' status',snapshot['status']==('' if label=='adoption-before' else 'M '+TARGET))
check('adoption focus exact context join',all(full(c[k][n])==v for k in ['source','runtime'] for n,v in b[k].items()))
check('beforebody reviewed source',sha(BASE/'adoption/guest.before.py')=='51793e80a95a990d9d26c175045891ed901952f3263d192007278d164f75476b')
check('afterbody reviewed source',sha(BASE/'adoption/guest.after.py')=='3f652bd9737bbe35e0d3398edc64e2cf3d9d4d75b1d65ec8852a5a1e2aa9a360'==b['source'][TARGET]['sha256'])
check('prior correction CLEAR pin',sha(BASE/'references/proposal-REVIEW.md')=='7315b91e0cff4a6d7d9bd4bb7bf98e35bf7c4ab1ecf7b1c78b16743da6581333')
check('prior full failure review pin',sha(BASE/'references/full374-REVIEW.md')=='9be67b212180403bdb66cb51cec2065e8ed8a95c794b6af655945b3c06f82a31')
check('target full mode retained',a['source'][TARGET]['full_mode']==b['source'][TARGET]['full_mode'])

cache=read('adoption/cache.json');old,new=cache['before'],cache['after']
check('finite cache inventory unchanged',len(old)==len(new)==14 and set(old)==set(new))
check('only known guest cache changed',[n for n in old if old[n]!=new[n]]==cache['manual_regeneration']==['ubuntu_gnome_guest.cpython-312.pyc'])
for name,row in old.items():
 path=ROOT/'scripts/linux_gnome/__pycache__'/name
 check('current known cache '+name,not path.is_symlink() and path.stat().st_mode==new[name]['full_mode'] and path.stat().st_size==new[name]['bytes'] and sha(path)==new[name]['sha256'] and (name=='ubuntu_gnome_guest.cpython-312.pyc' or row==new[name]))
raw=(BASE/'adoption/owned-cache.before.pyc').read_bytes();after=(BASE/'references/known-owned-guest.after.pyc.bin').read_bytes()
check('old cache exact retained',hashlib.sha256(raw).hexdigest()==cache['known_old_cache_retained']['sha256']==old['ubuntu_gnome_guest.cpython-312.pyc']['sha256'])
check('after cache exact read',hashlib.sha256(after).hexdigest()==new['ubuntu_gnome_guest.cpython-312.pyc']['sha256'])
check('timestamp flags0 same magic',raw[:4]==after[:4] and raw[4:8]==after[4:8]==b'\0'*4)
check('old header rejected new size',int.from_bytes(raw[12:16],'little')==a['source'][TARGET]['bytes'] and int.from_bytes(after[12:16],'little')==b['source'][TARGET]['bytes'] and raw[:16]!=after[:16])
check('known current header mtime',int.from_bytes(after[8:12],'little')==(int((ROOT/TARGET).stat().st_mtime)&0xffffffff))
adopter=(BASE/'adoption/executed-source.py').read_text()
check('standard compile explicit identity',all(x in adopter for x in ['checker._check_linux_bytecode(directory)','optimize=0','dfile=str(R/NAME)','py_compile.PycInvalidationMode.TIMESTAMP']) and adopter.count('checker._check_linux_bytecode(directory)')==2)
checker=(BASE/'references/check_portability.py').read_text()
check('unchanged inert checker source pin',sha(BASE/'references/check_portability.py')==a['source']['scripts/check_portability.py']['sha256']==b['source']['scripts/check_portability.py']['sha256'])
check('checker safe reader no marshal loads','marshal.loads' not in checker and 'def _marshal312_signature' in checker and 'expected = marshal.dumps(compiled)' in checker)

records=read('focus/results.json')
check('all10 names exact',[r['name'] for r in records]==['ruff','format','mypy-linux','mypy-win32','prettier','focused-python','collection','portability','integrity','diff-check'])
for r in records:
 check('actual closed0 '+r['name'],r['exit_code']==0 and r['reaped'] and r['group']=='ABSENT' and not r['signals'] and not r['timeout'] and r['pid']==r['pgid'])
 check('actual raw file '+r['name'],(BASE/'focus'/(r['name']+'.log')).is_file())
focused=(BASE/'focus/focused-python.log').read_text();collection=(BASE/'focus/collection.log').read_text()
check('actual564 PASS','564 passed in 6.54s' in focused)
check('actual2788 collection','2788 tests collected in 0.37s' in collection)
check('Linux37 strict','Success: no issues found in 37 source files' in (BASE/'focus/mypy-linux.log').read_text())
check('Win32 selected14 strict','Success: no issues found in 14 source files' in (BASE/'focus/mypy-win32.log').read_text())
check('all6 GNOME test files selected',set(['scripts/tests/test_linux_gnome_isolation.py','scripts/tests/test_ubuntu_gnome_signed_indexes.py','scripts/tests/test_ubuntu_gnome_boundaries.py','scripts/tests/test_ubuntu_gnome_request.py','scripts/tests/test_ubuntu_gnome_review_regressions.py','scripts/tests/test_ubuntu_gnome_source_binding.py']).issubset(next(r for r in records if r['name']=='focused-python')['argv']))
inventory=read('references/python-test-inventory.v1.json');prior_inventory=read('references/full374-immutable-python-test-inventory.v1.json')
check('catalog exact old body',inventory==prior_inventory and sha(BASE/'references/python-test-inventory.v1.json')==a['source']['scripts/python-test-inventory.v1.json']['sha256']==b['source']['scripts/python-test-inventory.v1.json']['sha256'])
common=inventory['common']['node_ids'];posix=inventory['posix_only_node_ids']
ids=[line for line in collection.splitlines() if line.startswith(('scripts/','services/')) and '::' in line]
check('catalog common normalized hash',len(common)==inventory['common']['count']==2786 and hashlib.sha256(('\n'.join(common)+'\n').encode()).hexdigest()==inventory['common']['sha256'])
check('actual IDs exactly old common+2',len(ids)==len(set(ids))==2788 and set(ids)==set(common)|set(posix) and len(posix)==2 and set(common).isdisjoint(posix))
check('old boundary test body exact',a['source']['scripts/tests/test_ubuntu_gnome_boundaries.py']==b['source']['scripts/tests/test_ubuntu_gnome_boundaries.py'] and a['source']['scripts/tests/test_ubuntu_gnome_boundaries.py']['sha256']=='1913677a873388af222ddbbccaec3b7c82c46aace48fc36394736e11ccaa1f36')
check('integrity actual pass','integrity      ACTIVE               PASS' in (BASE/'focus/integrity.log').read_text() and 'verification exit code: 0' in (BASE/'focus/integrity.log').read_text())
check('full focus endpoints equal',c==d)
result={'scope':'different retained actual adoption/focus data review only','passed':len(checks),'failed':0,'checks':checks,'native_subject_reexecution':False,'source_cache_loaded_or_executed':False,'outer_adoption_custody_claim':'root observed tool0; no independent Popen custody','full374_status':'previous full remains failed; no new full or CI success inferred'}
(BASE/'data-review.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({'passed':len(checks),'failed':0}))
