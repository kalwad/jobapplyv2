from pathlib import Path
import hashlib,json,stat,tarfile
P=Path(__file__).resolve().parent
E=P.parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def row(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink()
 return {'bytes':s.st_size,'full_mode':s.st_mode,'sha256':sha(p)}
def write(name,data):(P/name).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
origins={}
for local,original in [('adoption','m03-gnome-terminal-order-canonical-adoption/v1'),('focus','gnome-terminal-order-canonical-focus-v1')]:
 for q in sorted((P/local).iterdir()):
  assert row(q)==row(E/original/q.name),(q,original)
  origins[str(q.relative_to(P))]={'original':str(E/original/q.name),**row(q)}
write('origin-joins.json',{'passed':len(origins),'files':origins})
excluded={'SOURCE.json','manifest.json','SEAL.json','proof.tar.gz'}
files={str(q.relative_to(P)):row(q) for q in sorted(P.rglob('*')) if q.is_file() and q.name not in excluded}
write('SOURCE.json',{'verdict':'CLEAR_SCOPED_ACTUAL_ADOPTION_AND_FOCUSED_CHECKS','scope':'different retained data; subject not executed','files':files,'members_preserve_physical_full_modes':True})
paths=sorted(files)+['SOURCE.json']
with tarfile.open(P/'proof.tar.gz','w:gz',format=tarfile.PAX_FORMAT) as t:
 for name in paths:t.add(P/name,arcname=name,recursive=False)
with tarfile.open(P/'proof.tar.gz','r:gz') as t:
 members=t.getmembers();assert len(members)==len(paths)==len(set(m.name for m in members))
 for m in members:
  assert m.isreg() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  r=row(P/m.name);assert m.size==r['bytes'] and (stat.S_IFREG|m.mode)==r['full_mode']
  assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==r['sha256']
write('manifest.json',{'verdict':'CLEAR_SCOPED_ACTUAL_ADOPTION_AND_FOCUSED_CHECKS','source':row(P/'SOURCE.json'),'review':row(P/'REVIEW.md'),'data':row(P/'data-review.json'),'proof':row(P/'proof.tar.gz'),'regular_members':len(paths),'archive_member_bytes_sha256_full_modes_verified':True,'original_full374_remains_failed':True})
seal={'verdict':'CLEAR_SCOPED_ACTUAL_ADOPTION_AND_FOCUSED_CHECKS','review':row(P/'REVIEW.md'),'source':row(P/'SOURCE.json'),'data':row(P/'data-review.json'),'manifest':row(P/'manifest.json'),'proof':row(P/'proof.tar.gz'),'regular_members':len(paths)}
write('SEAL.json',seal);print(json.dumps(seal,indent=2))
