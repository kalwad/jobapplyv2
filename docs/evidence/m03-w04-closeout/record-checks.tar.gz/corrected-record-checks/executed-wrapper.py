from pathlib import Path
import datetime,hashlib,json,os,subprocess,time,shutil
R=Path('/Users/tanishkalwad/jobapplyv2');B=Path('/tmp/japp-m03-w04-closeout-record-checks-v2-20261019');B.mkdir(exist_ok=False)
def write(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
env={k:os.environ[k] for k in ['HOME','USER','LOGNAME','TMPDIR','LANG','LC_ALL','CARGO_HOME','RUSTUP_HOME'] if k in os.environ};env.update(PATH='/opt/homebrew/opt/node@24/bin:'+os.environ['PATH'],UV_OFFLINE='true',CARGO_NET_OFFLINE='true',COREPACK_ENABLE_NETWORK='0',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_SYSTEM='/dev/null')
def snapshot():
 names=set()
 for argv in [['git','ls-files','-z'],['git','ls-files','--others','--exclude-standard','-z']]:names.update(x for x in subprocess.check_output(argv,cwd=R,env=env).decode().split('\0') if x)
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,env=env,text=True).strip(),'files':{n:{'bytes':(R/n).stat().st_size,'sha256':sha(R/n)} for n in sorted(names)}}
before=snapshot();write('source-before.json',before);shutil.copy2(__file__,B/'executed-wrapper.py')
commands=[('ruff',['uv','run','ruff','check','scripts/traceability.py','scripts/tests/test_traceability.py']),('ruff-format',['uv','run','ruff','format','--check','scripts/traceability.py','scripts/tests/test_traceability.py']),('mypy',['uv','run','mypy','--config-file','pyproject.toml','scripts/traceability.py','scripts/tests/test_traceability.py']),('metadata-tests',['uv','run','pytest','scripts/tests/test_validate_status.py','scripts/tests/test_traceability.py','-q']),('status',['python3','scripts/validate_status.py']),('traceability',['python3','scripts/traceability.py','check']),('diff-check',['git','diff','--check'])]
rows=[]
for label,argv in commands:
 tool=Path(shutil.which(argv[0],path=env['PATH'])).resolve();rec={'label':label,'argv':argv,'cwd':str(R),'environment':dict(env),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tool':str(tool),'tool_sha256':sha(tool),'timeout_seconds':600};write(label+'-upfront.json',rec);print('RUN '+label,flush=True);began=time.monotonic()
 with (B/(label+'.stdout')).open('wb') as out,(B/(label+'.stderr')).open('wb') as err:
  try:p=subprocess.run(argv,cwd=R,env=env,stdout=out,stderr=err,timeout=600,check=False);code=p.returncode
  except subprocess.TimeoutExpired:code=124
 rec.update(exit_code=code,elapsed_seconds=time.monotonic()-began,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout_sha256=sha(B/(label+'.stdout')),stderr_sha256=sha(B/(label+'.stderr')));write(label+'-result.json',rec);rows.append(rec);print(json.dumps({'label':label,'exit_code':code,'seconds':rec['elapsed_seconds']}),flush=True)
 if code:break
after=snapshot();write('source-after.json',after);write('closure.json',{'source_unchanged':before==after,'all_seven_commands_executed':len(rows)==7,'all_executed_exit0':all(r['exit_code']==0 for r in rows),'records':rows,'note':'Metadata checks only; earlier actual2a327 cleanfull remains evaluatedproductsource; no new nativeactors/platform/GUIcredit'})
raise SystemExit(0 if before==after and len(rows)==7 and all(r['exit_code']==0 for r in rows) else 1)
