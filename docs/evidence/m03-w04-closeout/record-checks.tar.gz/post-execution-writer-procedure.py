"""Future guarded W04 records; invoke only after actual closed full and separate data review."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import shutil
import subprocess
import tarfile

R = Path('/Users/tanishkalwad/jobapplyv2')
F = Path('/tmp/japp-m03-w04-clean-root-verification-v1-20261019')
P = Path('/tmp/japp-m03-w04-requirement-projection-plan-20261019/proposal.json')
HEAD = '2a327c6210bfb7236f3d8a572a3a62e9b7e13d63'
TREE = '4ce9cf0c1f5515252a029584f820ea674a66e05e'
ap = argparse.ArgumentParser()
ap.add_argument('--full-pack', type=Path, required=True)
ap.add_argument('--full-pack-sha256', required=True)
ap.add_argument('--data-review', type=Path, required=True)
ap.add_argument('--data-review-sha256', required=True)
a = ap.parse_args()

def sha(p):
    return hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()

def read(p):
    return json.loads(p.read_text())

def write(p, value):
    p.write_text(json.dumps(value, indent=2, ensure_ascii=True) + '\n')

def git(*argv):
    return subprocess.check_output(['git', *argv], cwd=R, text=True)

assert git('rev-parse', 'HEAD').strip() == HEAD
assert not git('status', '--porcelain=v1', '--untracked-files=all')
assert sha(R / 'docs/MASTER_IMPLEMENTATION_SPEC.md') == '3eba7bdfbbb1591b5ea54c31bc415fc0cbfd3c361d32005b328f27a12f3ac943'
closed = read(F / 'closure.json')
assert all(closed[k] is True for k in ['source_unchanged', 'runtime40_unchanged', 'both_commands_executed', 'all_executed_commands_exit0'])
before = read(F / 'before.json')
assert before == read(F / 'after.json')
assert before['head'] == HEAD and before['tree'] == TREE and len(before['files']) == 1886 and not before['status']
assert read(F / 'doctor-result.json')['exit_code'] == read(F / 'verify-result.json')['exit_code'] == 0
raw = (F / 'verify.log').read_text()
assert len(re.findall(r'^[a-z0-9-]+\s+ACTIVE\s+PASS\s*$', raw, re.M)) == 20
assert len(re.findall(r'^test result: ok\. 138 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', raw, re.M)) == 3
assert '1679 passed' in raw
assert sha(a.full_pack) == a.full_pack_sha256
assert a.data_review.is_dir() and sha(a.data_review / 'REVIEW.md') == a.data_review_sha256
# Root separately inspects the report before supplying its exact immutable SHA.
assert 'PASS' in (a.data_review / 'REVIEW.md').read_text()
proposal = read(P)
x = read(R / 'docs/traceability.json')
req = next(v for v in x['requirements'] if v['id'] == 'REQ-PLAT-003')
assert req == proposal['before']
assert x['review']['v1_4_requirements_mapping_sha256'] == proposal['old_v1_4_requirements_mapping_sha256']
E = R / 'docs/evidence/m03-w04-closeout'
assert not E.exists()
E.mkdir()
shutil.copy2(a.full_pack, E / 'clean-full-and-review.tar.gz')
q = Path('/tmp/japp-m03-w04-requirement-projection-independent-review-20261019')
assert sha(q / 'findings.json') == 'c74acd6fa28ad304e7d18c3eea2380a0701e83a5235c04f7bbda0977fff69549'
with tarfile.open(E / 'requirement-projection-review.tar.gz', 'w:gz') as tar:
    tar.add(P, arcname='proposal.json')
    for file in sorted(q.iterdir()):
        assert file.is_file() and not file.is_symlink()
        tar.add(file, arcname='independent-review/' + file.name)
write(E / 'decision.json', {'work_package':'M03-W04', 'decision':'VERIFIED', 'decision_maker':'/root', 'authority':'OD-037 / ADR-0008', 'manual_owner_click':False, 'evaluated_commit':HEAD, 'evaluated_tree':TREE, 'full_result':'doctor28/all20 ACTIVE PASS, source1886/runtime40 unchanged', 'counts':{'Python':1679,'TypeScript':4006,'native_each_three_modes':138,'main_browser':262,'controlled_research':2,'controlled_contact':62,'visual':3}, 'data_review_sha256':a.data_review_sha256, 'next_package':'M03-W05', 'KI0108':'IN_PROGRESS pending actual Windows revalidation', 'new_gui_or_hosted_pass':False, 'milestone_accepted':False, 'release_ready':False})
(E / 'README.md').write_text('''# M03-W04 scoped closeout

Actual clean canonical source: commit `2a327c6210bfb7236f3d8a572a3a62e9b7e13d63`, tree `4ce9cf0c1f5515252a029584f820ea674a66e05e`, 1,886 tracked files. The retained exact full packet and independent data review support the delegated W04 package decision. Prior focused/source/app-build/actual-owner HTTP proofs remain in `../m03-w04-authenticated-client`; browser cleanup evidence remains in `../m03-w04-browser-cleanup`. No original failed aggregate, source identity, environment erratum, narrower execution or absent artifact is rewritten.

This records no new Wry launch, packaged platform matrix, hosted CI PASS, native Windows/Ubuntu product certification, M03 acceptance or release readiness. Actual new three-platform CI run39194489970 has its own immutable source and eventual result. KI0108 remains IN_PROGRESS until the required actual Windows revalidation. The REQ-PLAT-003 update records client evidence while retaining partial states and later platform obligations. Applicable record checks and separate metadata review follow before commit.
''')
write(E / 'artifacts.json', {p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(E.iterdir()) if p.is_file()})
# Exact narrowly reviewed requirement projection; all other requirements stay untouched.
req.clear(); req.update(proposal['after'])
x['review']['v1_4_requirements_mapping_sha256'] = proposal['proposed_v1_4_requirements_mapping_sha256']
for row in x['work_packages']:
    if row['id'] == 'M03-W04':
        assert row['current_state'] == 'IN_PROGRESS'
        row.update(current_state='VERIFIED', verified_revision='tree ' + TREE, current_evidence=[{'path':'docs/TEST_EVIDENCE.md','heading':'### M03-W04'}])
    elif row['id'] == 'M03-W05':
        assert row['current_state'] == 'NOT_STARTED'; row['current_state'] = 'IN_PROGRESS'
write(R / 'docs/traceability.json', x)
s = (R / 'scripts/traceability.py').read_text()
old = 'FINAL_V1_4_REQUIREMENT_MAPPING_SHA256 = (\n    "' + proposal['old_v1_4_requirements_mapping_sha256'] + '"\n)'
new = '# M03-W04 adds the authenticated-client evidence portion of REQ-PLAT-003;\n# partial states and remaining native platform obligations stay unchanged.\n# Previous reviewed projection: ' + proposal['old_v1_4_requirements_mapping_sha256'] + '\nFINAL_V1_4_REQUIREMENT_MAPPING_SHA256 = (\n    "' + proposal['proposed_v1_4_requirements_mapping_sha256'] + '"\n)'
assert s.count(old) == 1
(R / 'scripts/traceability.py').write_text(s.replace(old,new,1))
s = (R / 'scripts/tests/test_traceability.py').read_text()
marker = '        ):\n            source = REPO_ROOT / relative_path'
assert s.count(marker) == 1
anchors = list(proposal['added_anchor_bindings'])
assert len(anchors) == 8
addition = '            # M03-W04 authenticated-client evidence anchors.\n' + ''.join('            "' + k + '",\n' for k in anchors)
(R / 'scripts/tests/test_traceability.py').write_text(s.replace(marker,addition+marker,1))
s = (R / 'docs/PROJECT_STATUS.md').read_text()
s = s.replace('Repository revision: M03-W03 VERIFIED at6d3a6b8/tree34fcf85; M03-W04 IN_PROGRESS; M02 ACCEPTED / Gate A PASS','Repository revision: M03-W04 VERIFIED at2a327c6/tree4ce9cf0; M03-W05 IN_PROGRESS; M02 ACCEPTED / Gate A PASS',1)
s = s.replace('Current work package: M03-W04','Current work package: M03-W05',1)
start=s.index('## Active work\n');end=s.index('## Milestone table\n',start)
s=s[:start]+'''## Active work

- State: M03-W05 is the sole IN_PROGRESS package; 37/300 packages VERIFIED. M00/M01/M02 remain ACCEPTED; Gate A remains PASS. M03 remains IN_PROGRESS; release NOT_READY.
- Completed prerequisite: M03-W04 VERIFIED at2a327c6/tree4ce9cf0 after clean doctor28/all20 ACTIVE PASS, Python1,679, TypeScript4,006, native138 in each of three modes and browser262+2+62+3, with unchanged1,886 source files/runtime40 and independent source/data reviews.
- Objective: bounded crash recovery through the retained service owner, preserving native authority, diagnostics and UI state where available. Reviewed implementation and current component evidence are prepared outside root; actual recovery proof and canonical adoption/validation continue.
- Execution: continue all eligible work without routine approval prompts under OD-035–037. Required measured evidence, independent reviews, numerical/safety limits and precise ADR-0006/0007 waivers remain binding.
- Hosted run39188122249 remains Ubuntu/macOS20PASS and Windows19PASS/browser-cleanupFAIL; its standalone Windows tracked-change step is SKIPPED. Correction source/local proof and current canonical browsers pass, while KI0108 remains IN_PROGRESS pending actual new Windows revalidation. Run39194489970 has a separate immutable2a327 source and eventual outcome; no pending result is called PASS.
- W04 scope/evidence: docs/evidence/m03-w04-closeout and docs/TEST_EVIDENCE.md. Actual private-owner HTTP and browser tests retain their exact source and execution limits; no new Wry GUI, native Windows11/Ubuntu GNOME package, M03 acceptance or release readiness is asserted.

'''+s[end:]
s=s.replace('| `M03-W04` | IN_PROGRESS | — | — | Implement authenticated API client |','| `M03-W04` | VERIFIED | tree '+TREE+' | docs/TEST_EVIDENCE.md § M03-W04 | Implement authenticated API client |',1)
s=s.replace('| `M03-W05` | NOT_STARTED | — | — | Add crash/restart behavior |','| `M03-W05` | IN_PROGRESS | — | — | Add crash/restart behavior |',1)
s=s.replace('Reason: M03-W04 is IN_PROGRESS after verified M03-W03.','Reason: M03-W05 is IN_PROGRESS after verified M03-W04.',1)
(R / 'docs/PROJECT_STATUS.md').write_text(s)
subprocess.run(['python3','scripts/validate_status.py'],cwd=R,check=True)
# Evidence prose is inserted by root from the actually inspected full/review after this draft executes.
print(json.dumps({'records_applied':True,'state':'37 VERIFIED / W05 IN_PROGRESS','metadata_checks_generation_and_final_review':'REQUIRED_BEFORE_COMMIT'}))
