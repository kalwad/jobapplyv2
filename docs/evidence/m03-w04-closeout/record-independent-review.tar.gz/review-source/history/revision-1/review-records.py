"""Bounded read-only W04 closeout metadata integration review; no product imports."""
from pathlib import Path, PurePosixPath
import ast
import copy
import hashlib
import json
import re
import subprocess
import tarfile

R=Path('/Users/tanishkalwad/jobapplyv2')
BASE='2a327c6210bfb7236f3d8a572a3a62e9b7e13d63'
TREE='4ce9cf0c1f5515252a029584f820ea674a66e05e'
P=Path('/tmp/japp-m03-w04-requirement-projection-plan-20261019/proposal.json')
Q=Path('/tmp/japp-m03-w04-requirement-projection-independent-review-20261019')
E=R/'docs/evidence/m03-w04-closeout'
OUT=Path('/tmp/japp-m03-w04-closeout-independent-review-20261019')
assert not OUT.exists();OUT.mkdir()
checks=[]
def check(name,ok,evidence=None):checks.append({'id':name,'pass':bool(ok),'evidence':evidence})
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
def old(path):return git('show',BASE+':'+path)
def ident(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(name,value):(OUT/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def ast_dump(v):return ast.dump(v,include_attributes=False)

allowed={'docs/PROJECT_STATUS.md','docs/TEST_EVIDENCE.md','docs/traceability.json','docs/REQUIREMENTS_TRACEABILITY.md','scripts/traceability.py','scripts/tests/test_traceability.py'}
newpaths={'docs/evidence/m03-w04-closeout/'+n for n in ['README.md','artifacts.json','clean-full-and-review.tar.gz','decision.json','full-retention-manifest.json','requirement-projection-review.tar.gz']}
changed=set(git('diff','--name-only',BASE).decode().splitlines())
untracked=set(git('ls-files','--others','--exclude-standard').decode().splitlines())
check('exact_six_record_paths_six_new_proofs',changed==allowed and untracked==newpaths,{'tracked_delta':sorted(changed),'new_paths':sorted(untracked)})
check('unchanged_evaluated_HEAD_tree',git('rev-parse','HEAD').decode().strip()==BASE and git('rev-parse',BASE+'^{tree}').decode().strip()==TREE)
root_bindings={n:ident((R/n).read_bytes()) for n in sorted(allowed|newpaths)}
protected=['CLAUDE.md','docs/MASTER_IMPLEMENTATION_SPEC.md','docs/DECISIONS.md','docs/CRITICAL_GATES.md','docs/gates/AUTOFILL_FEASIBILITY_GATE.md','docs/KNOWN_ISSUES.md','docs/PLATFORM_SUPPORT.md','scripts/verification-suites.json','scripts/python-test-inventory.v1.json']
check('master_CLAUDE_ADRs_gates_knownissues_registry_inventory_unchanged',all((R/n).read_bytes()==old(n) for n in protected),{n:ident((R/n).read_bytes()) for n in protected})
check('master_exact_owner_approved_bytes',ident((R/'docs/MASTER_IMPLEMENTATION_SPEC.md').read_bytes())['sha256']=='3eba7bdfbbb1591b5ea54c31bc415fc0cbfd3c361d32005b328f27a12f3ac943')

proposal=json.loads(P.read_text()); a=json.loads(old('docs/traceability.json'));b=json.loads((R/'docs/traceability.json').read_text())
oldr={row['id']:row for row in a['requirements']};newr={row['id']:row for row in b['requirements']}
oldp={row['id']:row for row in a['work_packages']};newp={row['id']:row for row in b['work_packages']}
check('requirement193_and_package300_identity_order',len(oldr)==len(newr)==193 and len(oldp)==len(newp)==300 and [x['id'] for x in a['requirements']]==[x['id'] for x in b['requirements']] and [x['id'] for x in a['work_packages']]==[x['id'] for x in b['work_packages']])
check('only_PLAT003_exact_approved_projection',oldr['REQ-PLAT-003']==proposal['before'] and newr['REQ-PLAT-003']==proposal['after'] and all(oldr[k]==newr[k] for k in oldr if k!='REQ-PLAT-003'))
check('PLAT003_partial_states_ownership_gateeffects_preserved',all(oldr['REQ-PLAT-003'][k]==newr['REQ-PLAT-003'][k] for k in ['id','text','family','owning_packages','planned_components','automated_test_layers','manual_evidence','gate_effects','implementation_state','verification_state','mapping_review_state']) and newr['REQ-PLAT-003']['implementation_state']=='SCAFFOLD_ONLY' and newr['REQ-PLAT-003']['verification_state']=='NOT_YET_APPLICABLE')
expected=copy.deepcopy(a)
expected['requirements']=[proposal['after'] if x['id']=='REQ-PLAT-003' else x for x in expected['requirements']]
expected['review']['v1_4_requirements_mapping_sha256']=proposal['proposed_v1_4_requirements_mapping_sha256']
for row in expected['work_packages']:
 if row['id']=='M03-W04':row.update(current_state='VERIFIED',verified_revision='tree '+TREE,current_evidence=[{'path':'docs/TEST_EVIDENCE.md','heading':'### M03-W04'}])
 elif row['id']=='M03-W05':row['current_state']='IN_PROGRESS'
check('entire_metadata_exact_narrow_expected_change',b==expected)
check('all_other298_packages_and_all_dependencies_proofplans_preserved',all(oldp[k]==newp[k] for k in oldp if k not in {'M03-W04','M03-W05'}) and all({k:v for k,v in oldp[n].items() if k not in {'current_state','verified_revision','current_evidence'}}=={k:v for k,v in newp[n].items() if k not in {'current_state','verified_revision','current_evidence'}} for n in oldp))
fields=['id','owning_packages','planned_components','automated_test_layers','manual_evidence','gate_effects','mapping_review_state','implementation_state','verification_state','completed_code_paths','completed_test_paths','current_evidence','notes']
def mapping_hash(rows):return hashlib.sha256(json.dumps([[x.get(k) for k in fields] for x in rows],ensure_ascii=False,separators=(',',':'),sort_keys=True).encode()).hexdigest()
check('independent_13field_mapping_digest',mapping_hash(a['requirements'])==proposal['old_v1_4_requirements_mapping_sha256'] and mapping_hash(b['requirements'])==proposal['proposed_v1_4_requirements_mapping_sha256']=='84b732542d4ea614a5e0f3e840c306c4cfd19d87323d25014d784aaf65bef219')
check('exact8_actual_anchor_source_bindings',len(proposal['added_anchor_bindings'])==8 and all(ident((R/n).read_bytes())==row and (R/n).read_bytes()==old(n) for n,row in proposal['added_anchor_bindings'].items()))
check('37_verified_W05_only_IP',sum(x['current_state']=='VERIFIED' for x in b['work_packages'])==37 and [x['id'] for x in b['work_packages'] if x['current_state']=='IN_PROGRESS']==['M03-W05'])

old_test=ast.parse(old('scripts/tests/test_traceability.py'));new_test=ast.parse((R/'scripts/tests/test_traceability.py').read_text());restored=copy.deepcopy(new_test)
fixture=next(x for x in restored.body if isinstance(x,ast.FunctionDef) and x.name=='trace_repo')
anchor_set=set(proposal['added_anchor_bindings']);removed=[]
for node in ast.walk(fixture):
 if isinstance(node,ast.For) and isinstance(node.iter,ast.Tuple):
  kept=[]
  for item in node.iter.elts:
   if isinstance(item,ast.Constant) and isinstance(item.value,str) and item.value in anchor_set:removed.append(item.value)
   else:kept.append(item)
  node.iter.elts=kept
check('test_whole_AST_restored_by_only8_fixture_strings',set(removed)==anchor_set and len(removed)==8 and ast_dump(restored)==ast_dump(old_test))
def assertions(t):return [ast_dump(x) for x in ast.walk(t) if isinstance(x,ast.Assert)]
def tests(t):return [ast_dump(x) for x in ast.walk(t) if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef)) and x.name.startswith('test_')]
check('all158_assertions_and52_test_functions_exact',len(assertions(old_test))==158 and assertions(old_test)==assertions(new_test) and len(tests(old_test))==52 and tests(old_test)==tests(new_test))
old_script=ast.parse(old('scripts/traceability.py'));new_script=ast.parse((R/'scripts/traceability.py').read_text());restore_script=copy.deepcopy(new_script)
assignments=[]
for n in restore_script.body:
 if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='FINAL_V1_4_REQUIREMENT_MAPPING_SHA256' for t in n.targets):
  assignments.append(n);n.value=ast.Constant(proposal['old_v1_4_requirements_mapping_sha256'])
check('traceability_whole_AST_only_current_hash_changed',len(assignments)==1 and ast_dump(restore_script)==ast_dump(old_script))
check('old_current_hash_retained_in_history_comment',proposal['old_v1_4_requirements_mapping_sha256'] in (R/'scripts/traceability.py').read_text())

def restore_lines(current,previous,predicate):
 oldlines={predicate(x):x for x in previous.splitlines() if predicate(x)}
 return '\n'.join(oldlines.get(predicate(x),x) for x in current.splitlines())+'\n'
old_status=old('docs/PROJECT_STATUS.md').decode();new_status=(R/'docs/PROJECT_STATUS.md').read_text()
prior_active=old_status[old_status.index('## Active work\n'):old_status.index('## Milestone table\n')]
current_active=new_status[new_status.index('## Active work\n'):new_status.index('## Milestone table\n')]
normalized=new_status.replace(current_active,prior_active,1)
def key(line):
 if line.startswith('Repository revision:'):return 'revision'
 if line.startswith('Current work package:'):return 'package'
 if line.startswith('| `M03-W04` |'):return 'W04'
 if line.startswith('| `M03-W05` |'):return 'W05'
 if line.startswith('- Reason: M03-W0') and 'Continue implementation and validation' in line:return 'reason'
 return None
normalized=restore_lines(normalized,old_status,key)
check('status_only_reviewed_current_work_and_W04_W05_changes',normalized==old_status)
check('status_retains_M03_IP_release_notready_native_pending','Current milestone: M03' in new_status and 'Overall release gate: NOT_READY' in new_status and 'KI0108 remains IN_PROGRESS' in new_status and 'no pending result is called PASS' in new_status and 'no new Wry GUI' in new_status)
old_evidence=old('docs/TEST_EVIDENCE.md').decode();new_evidence=(R/'docs/TEST_EVIDENCE.md').read_text()
heading='### M03-W04 — Verified authenticated API client; W05 begins (2026-10-19UTC)'
start=new_evidence.index(heading);end=new_evidence.index('\n### ',start+len(heading))+1
entry=new_evidence[start:end]
check('evidence_only_new_scoped_W04_entry_all_history_unchanged',new_evidence[:start]+new_evidence[end:]==old_evidence)
check('entry_actual_source_counts_review_and_limits',all(x in entry for x in [BASE,TREE,'1,886','4,006','1,679PASS in371.89s','138-case cohort','262 default,2 controlled inspection,62 controlled contact and3 separate visual','938fc28975d2ef42e4c8b976735b5ef83ca50c2e80a0229bcc6c87f223caf321','original41/42','outer subprocess timeouts','no fresh20-sample Gate A','no completion credit here','SCAFFOLD_ONLY / NOT_YET_APPLICABLE']))
old_view=old('docs/REQUIREMENTS_TRACEABILITY.md').decode();new_view=(R/'docs/REQUIREMENTS_TRACEABILITY.md').read_text()
norm_view=new_view.replace(proposal['proposed_v1_4_requirements_mapping_sha256'],proposal['old_v1_4_requirements_mapping_sha256'],1).replace('- Current package: `M03-W05`','- Current package: `M03-W04`',1)
def vkey(line):
 for n in ['REQ-PLAT-003','M03-W04','M03-W05']:
  if line.startswith('| '+n+' |'):return n
 return None
norm_view=restore_lines(norm_view,old_view,vkey)
check('generated_view_only_hash_current_and_three_rows',norm_view==old_view)

art=json.loads((E/'artifacts.json').read_text())
check('six_proof_paths_exhaustive_artifact_index',set(art)=={p.name for p in E.iterdir()}-{'artifacts.json'} and all(ident((E/n).read_bytes())==row for n,row in art.items()))
decision=json.loads((E/'decision.json').read_text())
check('delegated_decision_exact_actual_source_counts_no_promotion',decision=={'work_package':'M03-W04','decision':'VERIFIED','decision_maker':'/root','authority':'OD-037 / ADR-0008','manual_owner_click':False,'evaluated_commit':BASE,'evaluated_tree':TREE,'full_result':'doctor28/all20 ACTIVE PASS, source1886/runtime40 unchanged','counts':{'Python':1679,'TypeScript':4006,'native_each_three_modes':138,'main_browser':262,'controlled_research':2,'controlled_contact':62,'visual':3},'data_review_sha256':'938fc28975d2ef42e4c8b976735b5ef83ca50c2e80a0229bcc6c87f223caf321','next_package':'M03-W05','KI0108':'IN_PROGRESS pending actual Windows revalidation','new_gui_or_hosted_pass':False,'milestone_accepted':False,'release_ready':False})
ret=json.loads((E/'full-retention-manifest.json').read_text())
check('exact_original_full_archive_and_retention_copy',ident((E/'clean-full-and-review.tar.gz').read_bytes())=={'bytes':685911,'sha256':'310049825bbd8b3624e2ae5eb44b93abcfce8a26948ed4a5db96d2310fb7d661'} and ident((E/'full-retention-manifest.json').read_bytes())=={'bytes':7989,'sha256':'7c2d10d8eb278750cb35c0d737b68fe3c8c171d6ed694b4325c8959eb8736dad'})
def archive_members(path):
 with tarfile.open(path,'r:gz') as t:
  ms=t.getmembers();names=[m.name for m in ms]
  assert len(names)==len(set(names))
  assert all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in ms)
  return {m.name:t.extractfile(m).read() for m in ms}
full=archive_members(E/'clean-full-and-review.tar.gz')
check('full_all44_safe_regular_exhaustive_outer_hashes',len(full)==ret['regular_members']==44 and {n:ident(v) for n,v in full.items()}=={row['path']:{k:row[k] for k in ['bytes','sha256']} for row in ret['files']})
inner=json.loads(full[ret['embedded_inventory']])
check('full_embedded_self_excluded_index_exact',inner['self_excluded']==ret['embedded_inventory'] and {n:ident(v) for n,v in full.items() if n!=ret['embedded_inventory']}=={row['path']:{k:row[k] for k in ['bytes','sha256']} for row in inner['files']})
check('full_actual48_and_initial41_parser_history_exact',ident(full['audit-final/REVIEW.md'])['sha256']==decision['data_review_sha256'] and json.loads(full['audit-final/findings.json'])['passed']==48 and json.loads(full['audit-final/findings.json'])['total']==48 and json.loads(full['audit-attempt-1/findings.json'])['passed']==41 and json.loads(full['audit-attempt-1/findings.json'])['total']==42)
proj=archive_members(E/'requirement-projection-review.tar.gz')
expected_proj={'proposal.json':P.read_bytes(),**{'independent-review/'+p.name:p.read_bytes() for p in Q.iterdir() if p.is_file()}}
check('projection_all4_safe_exact_approved_original_bytes',len(proj)==4 and proj==expected_proj and ident(proj['independent-review/findings.json'])['sha256']=='c74acd6fa28ad304e7d18c3eea2380a0701e83a5235c04f7bbda0977fff69549' and ident(proj['proposal.json'])['sha256']=='eb6ca9657c873e6c8b13cacbe169354d1d912e94a7d23edb42d3fdda89dfcd7f')
check('README_scope_pending_without_new_GUI_CI_milestone',(E/'README.md').read_text().count('KI0108 remains IN_PROGRESS')==1 and 'no new Wry launch' in (E/'README.md').read_text() and 'separate immutable source and eventual result' in (E/'README.md').read_text())

write('bindings.json',{'base':BASE,'tree':TREE,'root_afterimages':root_bindings,'approved_projection':ident(P.read_bytes()),'full_archive_member_count':len(full),'projection_archive_member_count':len(proj)})
result={'decision':'CLEAR' if all(x['pass'] for x in checks) else 'FINDINGS','scope':'STATIC_W04_SCOPED_RECORD_INTEGRATION_BEFORE_METADATA_CHECK_CLOSURE','checks':checks,'passed':sum(x['pass'] for x in checks),'total':len(checks),'metadata_retry_outcome':'PENDING_NOT_READ','product_commands_actors_compilers_rootwrites':False,'milestone_or_platform_authority':'NONE','source':ident(Path(__file__).read_bytes())}
write('findings.json',result)
lines=[f"# W04 scoped record integration: {result['decision']}",'',f"{result['passed']}/{result['total']} bounded static/data-binding checks pass against immutable `{BASE}` / `{TREE}`.",'','Exactly six record/test-harness paths and six new finite proof files differ. No runtime/product, other historical evidence, canonical spec, CLAUDE, ADR, gate, known issue, registry or Python-inventory bytes change. Only the reviewed REQ-PLAT-003 evidence projection changes among193 requirements; its partial states/ownership/gate effects remain. All300 dependency/proof-plan mappings remain exact. W04 becomes VERIFIED and W05 the sole IN_PROGRESS package (37VERIFIED); M03/release/platform obligations remain open.','','The traceability module AST differs solely in the current reviewed mapping hash. Removing exactly eight copied real-anchor strings restores the whole test-module AST: all158 assertions and52 test functions remain byte-structure identical. The comment line wrap that corrected the root Ruff E501 failure has no AST effect.','','Both retained new archives are safe regular member sets with exact original bytes. The full44-member archive310049.../original outer manifest and independent final48PASS/initial41-of42 history are unchanged; the four-member requirement-projection archive matches the independently approved originals. Counts/source/runtime/benchmark scopes and delegated authority match actual reviewed evidence. No pending native CI, GUI observation, W05 recovery execution or milestone acceptance is credited.','','The seven-command metadata retry remains active/pending at this review snapshot. Its actual outcome and any later receipt appendix require a bounded additive data review after closure; no result is inferred from the writer or command plan.','']
failed=[c for c in checks if not c['pass']]
if failed:lines.extend([json.dumps(x,ensure_ascii=False) for x in failed])
(OUT/'REVIEW.md').write_text('\n'.join(lines))
write('review-member-manifest.json',{'self_excluded':'review-member-manifest.json','files':{p.name:ident(p.read_bytes()) for p in OUT.iterdir() if p.is_file()}})
print(json.dumps({'decision':result['decision'],'passed':result['passed'],'total':result['total'],'output':str(OUT),'review':ident((OUT/'REVIEW.md').read_bytes())}))
raise SystemExit(0 if result['decision']=='CLEAR' else 1)
