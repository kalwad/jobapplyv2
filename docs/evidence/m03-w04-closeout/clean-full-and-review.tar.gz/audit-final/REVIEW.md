# W04 current local full evidence review: PASS

Independent reconciliation: 48/48 checks passed against `2a327c6210bfb7236f3d8a572a3a62e9b7e13d63` / tree `4ce9cf0c1f5515252a029584f820ea674a66e05e`.

This report audits retained local data. It does not decide milestone acceptance, establish a new GUI execution, or validate native hosted platforms. Default benchmark observations are not a fresh 20-sample Gate A experiment.

The producer records the complete curated outer environment. It does not serialize every nested child environment or provide a whole dependency/cache/upfront native test-binary image. Its direct `subprocess.run` timeouts do not prove containment of all descendants.

Tool probe scope is literal: the Python-version probe hashes the resolved `uv` launcher, and pnpm/Node launcher hashes do not authenticate every nested executable. All historical source comparisons use immutable pinned Git objects, not a later mutable checkout.

## Failed checks

None.

## Raw-derived observations

Repository doctor: `pnpm run doctor`, exit 0, 6.402882292s; 28 ordinary PASS, no warnings/failures/N/A. It completed before aggregate start.

Aggregate: `pnpm verify`, exit 0, 1150.614542084s; exact 20 ACTIVE/PASS summary. Verify log: 678970 bytes, SHA-256 `8b714d14d8110184db7495379d9764ff67fc49fbfde81a0d112b8b866e5f01e5`.

TypeScript unit summaries total 4006 ordinary passes. Python: 1679 exact collected POSIX IDs, comprising 1677 common IDs plus the declared FIFO/socket pair; actual summary `[('1679', '371.89')]` with no skip/deselection. All 15 registered Rust-stage commands occur in order; each of three desktop feature modes passes the same [138, 138, 138] case cohort with zero failed/ignored/measured/filtered cases. This is three executions of the same 138-case cohort.

Browser ordinary pass summaries by execution: `{'default': ['262'], 'controlled_inspection': ['2'], 'controlled_contact': ['62'], 'visual': ['3']}`. The default execution may already include visual cases; these are execution counts, not a claim of distinct cases across commands.

Printed timing scopes: default native128 1-sample / 0ms-settle value 830.5479999999989ms; separate 200 different W12 page observations with 75ms settlement / 20ms rerender have printed p95 869.9691250000033ms. These are log-record observations, without a fresh independent contact raw replay or 20-sample performance claim.

All 1886 tracked-file path/size/SHA-256 rows match both snapshots and independently authenticated immutable Git blobs. The unchanged runtime payload has 40 files / 29902573 bytes; closed physical read-back confirms the same bytes/modes, manifest `d274dcc7194722a4ec1549043543225d63bf48e5c6c8e55f4049eee4b5ceeea0` and main `fc2293a3d6425093c03ada543249ccdc2050038613cf984b3983aada18032c7c`.

The first actual audit's 41/42 packet is preserved separately. Its only failed check was an unanchored collection-summary pattern matching two quoted sample summaries in collected node IDs. The final checker anchors the summary line; exact 1679 IDs and the real execution already passed initially. No product rerun or evidence rewrite occurred.

See `findings.json`, `immutable-git-blob-closure.json`, `python-collected-node-ids.json`, and `native-mode-cases.json` for exact identities, raw-derived counts, and case joins. All failed checker attempts must remain historical if a later parser correction is required.
