"""Package only finite original W04 full records and the completed independent audit."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import tarfile

RAW = Path('/tmp/japp-m03-w04-clean-root-verification-v1-20261019')
PREP = Path('/tmp/japp-m03-w04-full-audit-preparation-20261019')
FIRST = Path('/tmp/japp-m03-w04-full-independent-audit-20261019')
FINAL = Path('/tmp/japp-m03-w04-full-independent-audit-20261019-correction-2')
OUT = Path('/tmp/japp-m03-w04-full-reviewed-retained-20261019')

def ident(data):
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def encoded(value):
    return (json.dumps(value,indent=2,sort_keys=True)+'\n').encode()

assert not OUT.exists()
assert json.loads((FIRST/'findings.json').read_text())['passed']==41
f=json.loads((FINAL/'findings.json').read_text())
assert f['decision']=='PASS' and f['passed']==f['total']==48
assert ident((FINAL/'REVIEW.md').read_bytes())['sha256']=='938fc28975d2ef42e4c8b976735b5ef83ca50c2e80a0229bcc6c87f223caf321'
members={}
origins={}

def add(name,path):
    assert not path.is_symlink() and path.is_file()
    p=PurePosixPath(name)
    assert not p.is_absolute() and '..' not in p.parts and name not in members
    data=path.read_bytes()
    assert ident(data)=={'bytes':path.stat().st_size,'sha256':hashlib.file_digest(path.open('rb'),'sha256').hexdigest()}
    members[name]=data
    origins[name]={'original_path':str(path),**ident(data)}

for prefix,directory in [('raw',RAW),('audit-preparation',PREP),('audit-attempt-1',FIRST),('audit-final',FINAL)]:
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():add(prefix+'/'+path.relative_to(directory).as_posix(),path)
add('raw-external/producer-wrapper.py',Path('/tmp/japp-m03-w04-clean-root-verify-20261019.py'))
add('raw-external/closed-outer.log',RAW.with_name(RAW.name+'.outer.log'))
add('retention-builder.py',Path(__file__))
# Check every declared finite original input against the actual final auditor row.
for name,row in f['closed_producer_input_identities'].items():
    archive_name='raw-external/producer-wrapper.py' if name=='EXTERNAL/executed-source-wrapper.py' else 'raw-external/closed-outer.log' if name=='EXTERNAL/outer.log' else 'raw/'+name
    assert ident(members[archive_name])==row
index='retained-members.json'
members[index]=encoded({'self_excluded':index,'files':[{'path':n,**ident(b)} for n,b in sorted(members.items())],'origins':origins,'authority':'NONE','scope':'Historical current-root2a327 W04 local doctor/full data; first audit parser false negative retained; final48/48. No new GUI/native hosted-platform/milestone acceptance or product rerun.'})
OUT.mkdir()
archive=OUT/'proof.tar.gz'
with archive.open('xb') as stream:
    with gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT) as tar:
            for name,data in sorted(members.items()):
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
                tar.addfile(info,io.BytesIO(data))
# Verify all actual members, exhaustive declared rows and self-excluded index.
with tarfile.open(archive,'r:gz') as tar:
    actual=tar.getmembers()
    assert len(actual)==len(members)==len({m.name for m in actual})
    for member in actual:
        assert member.isfile() and not PurePosixPath(member.name).is_absolute() and '..' not in PurePosixPath(member.name).parts
        assert tar.extractfile(member).read()==members[member.name]
rows=[{'path':n,**ident(b)} for n,b in sorted(members.items())]
outer={'archive_path':archive.name,'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.file_digest(archive.open('rb'),'sha256').hexdigest(),'regular_members':len(rows),'payload_bytes':sum(row['bytes'] for row in rows),'embedded_inventory':index,'files':rows,'authority':'NONE','scope':'Current-root W04 local canonical doctor28/all20ACTIVEPASS, TS4006, Python1679, browser262+2+62+3, same138nativecases per3modes. Immutable1886source/runtime40 closure. No new GUI/nativeCI/20-sampleGateA/milestone decision. First parser false negative and derived-argv correction preserved; no product rerun.'}
(OUT/'retention-manifest.json').write_bytes(encoded(outer))
(OUT/'summary.json').write_bytes(encoded({'archive_sha256':outer['archive_sha256'],'archive_bytes':outer['archive_bytes'],'regular_members':len(rows),'payload_bytes':outer['payload_bytes'],'actual_review':{'path':str(FINAL/'REVIEW.md'),**ident((FINAL/'REVIEW.md').read_bytes()),'checks_passed':48,'checks_total':48},'evaluated_commit':f['head'],'evaluated_tree':f['tree'],'scope':outer['scope'],'originals':origins,'builder_executed_product_actions':False}))
(OUT/'README.md').write_text('Finite retained current-root W04 doctor/full records and independent data review. Final48/48; first41/42 collection-parser false negative is historical. Every original payload byte is preserved, with exhaustive outer and embedded member identities. No product actors were repeated. The canonical full provides scoped local package evidence; it does not establish new GUI/hosted-native-platform/milestone acceptance or a fresh20-sample GateA run.\n')
print(json.dumps({k:outer[k] for k in ['archive_path','archive_bytes','archive_sha256','regular_members','payload_bytes']}))
