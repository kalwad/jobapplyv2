# W04 current local full evidence review: FAIL

Independent reconciliation: 41/42 checks passed against `2a327c6210bfb7236f3d8a572a3a62e9b7e13d63` / tree `4ce9cf0c1f5515252a029584f820ea674a66e05e`.

This report audits retained local data. It does not decide milestone acceptance, establish a new GUI execution, or validate native hosted platforms. Default benchmark observations are not a fresh 20-sample Gate A experiment.

The producer records the complete curated outer environment. It does not serialize every nested child environment or provide a whole dependency/cache/upfront native test-binary image. Its direct `subprocess.run` timeouts do not prove containment of all descendants.

Tool probe scope is literal: the Python-version probe hashes the resolved `uv` launcher, and pnpm/Node launcher hashes do not authenticate every nested executable. All historical source comparisons use immutable pinned Git objects, not a later mutable checkout.

## Failed checks

- `python_collection1679_summary`: [["2", "0.01"], ["2", "0.01"], ["1679", "0.36"]]

See `findings.json`, `immutable-git-blob-closure.json`, `python-collected-node-ids.json`, and `native-mode-cases.json` for exact identities, raw-derived counts, and case joins. All failed checker attempts must remain historical if a later parser correction is required.
