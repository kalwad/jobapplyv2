//! Outside-only actual W05 recovery proof. Not a shipping lifecycle API or Wry test.
use super::*;
use crate::{
    api_client::{
        Failure,
        canonical::Catalog,
        client::{Cancellation, Client, Policy as ClientPolicy},
        tests::canonical_documents,
    },
    diagnostics::create_engine,
    service::{NativeSession, ServiceIdentity},
};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{
    cell::{Cell, RefCell},
    fs::OpenOptions,
    io::Write,
    net::{Ipv4Addr, TcpListener},
    path::PathBuf,
    sync::atomic::{AtomicU64, AtomicUsize},
    time::{Instant, SystemTime, UNIX_EPOCH},
};

const BOUND: Duration = Duration::from_secs(2);
const CASE_CAP: Duration = Duration::from_secs(45);

#[derive(Clone)]
struct Receipt {
    sequence: usize,
    pid: u32,
    identity: ServiceIdentity,
    elapsed: Duration,
}
struct Book {
    started: Instant,
    count: AtomicUsize,
    lost: AtomicUsize,
    stop: AtomicBool,
    sender: std::sync::mpsc::SyncSender<Receipt>,
    receipts: Mutex<Vec<Receipt>>,
}
struct ReceiptState {
    book: Arc<Book>,
    attempt: Option<ServiceIdentity>,
}
thread_local! {
    static RECEIPT: RefCell<Option<ReceiptState>> = const { RefCell::new(None) };
    static BORROW_LOSS: Cell<usize> = const { Cell::new(0) };
}
struct ReceiptGuard {
    book: Arc<Book>,
    observer: Option<std::thread::JoinHandle<()>>,
}
impl ReceiptGuard {
    fn install(name: &'static str) -> Self {
        let (sender, receiver) = std::sync::mpsc::sync_channel::<Receipt>(32);
        let book = Arc::new(Book {
            started: Instant::now(),
            count: AtomicUsize::new(0),
            lost: AtomicUsize::new(0),
            stop: AtomicBool::new(false),
            sender,
            receipts: Mutex::new(Vec::new()),
        });
        let observed = Arc::clone(&book);
        let observer = std::thread::spawn(move || {
            loop {
                match receiver.recv_timeout(Duration::from_millis(20)) {
                    Ok(receipt) => {
                        event(
                            name,
                            "native_spawn",
                            json!({"sequence":receipt.sequence,"pid":receipt.pid,"port":receipt.identity.bind_port,"generation":receipt.identity.generation,"elapsed_ns":receipt.elapsed.as_nanos()}),
                        );
                        observed.receipts.lock().unwrap().push(receipt);
                    }
                    Err(std::sync::mpsc::RecvTimeoutError::Timeout) => {
                        if observed.stop.load(Ordering::Acquire) {
                            break;
                        }
                    }
                    Err(std::sync::mpsc::RecvTimeoutError::Disconnected) => break,
                }
            }
        });
        RECEIPT.with(|slot| {
            assert!(slot.borrow().is_none());
            *slot.borrow_mut() = Some(ReceiptState {
                book: Arc::clone(&book),
                attempt: None,
            });
        });
        BORROW_LOSS.set(0);
        Self {
            book,
            observer: Some(observer),
        }
    }
    fn all(&self) -> Vec<Receipt> {
        let began = Instant::now();
        loop {
            assert_eq!(BORROW_LOSS.get(), 0, "native receipt hook reentered");
            assert_eq!(
                self.book.lost.load(Ordering::Acquire),
                0,
                "lost native receipt"
            );
            let receipts = self.book.receipts.lock().unwrap().clone();
            if receipts.len() == self.book.count.load(Ordering::Acquire) {
                return receipts;
            }
            assert!(began.elapsed() < BOUND, "spawn observer did not drain");
            std::thread::sleep(Duration::from_millis(1));
        }
    }
}
impl Drop for ReceiptGuard {
    fn drop(&mut self) {
        RECEIPT.with(|slot| *slot.borrow_mut() = None);
        self.book.stop.store(true, Ordering::Release);
        if let Some(observer) = self.observer.take() {
            observer.join().unwrap();
        }
    }
}
// These hooks observe only. Neither hook waits, signals, performs I/O or changes ownership.
pub(crate) fn spawn_attempt(identity: &ServiceIdentity) {
    RECEIPT.with(|slot| match slot.try_borrow_mut() {
        Ok(mut slot) => {
            if let Some(state) = slot.as_mut() {
                state.attempt = Some(identity.clone());
            }
        }
        Err(_) => BORROW_LOSS.set(BORROW_LOSS.get() + 1),
    });
}
pub(crate) fn spawned(pid: u32) {
    RECEIPT.with(|slot| {
        let Ok(mut slot) = slot.try_borrow_mut() else {
            BORROW_LOSS.set(BORROW_LOSS.get() + 1);
            return;
        };
        if let Some(state) = slot.as_mut() {
            let sequence = state.book.count.fetch_add(1, Ordering::AcqRel) + 1;
            if let Some(identity) = state.attempt.take() {
                let receipt = Receipt {
                    sequence,
                    pid,
                    identity,
                    elapsed: state.book.started.elapsed(),
                };
                if state.book.sender.try_send(receipt).is_err() {
                    state.book.lost.fetch_add(1, Ordering::AcqRel);
                }
            } else {
                state.book.lost.fetch_add(1, Ordering::AcqRel);
            }
        }
    });
}

fn event(case: &str, kind: &str, details: Value) {
    let path = std::env::var_os("JAPP_W05_LEDGER").expect("collector-owned ledger required");
    let nonce = std::env::var("JAPP_W05_NONCE").expect("collector nonce required");
    let mut file = OpenOptions::new().append(true).open(path).unwrap();
    let record = json!({
        "case":case,"event":kind,"nonce":nonce,"harness_pid":std::process::id(),
        "unix_ms":SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis(),
        "details":details,
    });
    let mut bytes = serde_json::to_vec(&record).unwrap();
    bytes.push(b'\n');
    file.write_all(&bytes).unwrap();
    file.flush().unwrap();
}
fn runtime() -> tokio::runtime::Runtime {
    tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .unwrap()
}
fn entrypoint(fault: bool) -> PathBuf {
    let key = if fault {
        "JAPP_W05_FAULT_RUNTIME"
    } else {
        "JAPP_W05_RUNTIME"
    };
    let path = PathBuf::from(std::env::var_os(key).expect("collector runtime required"));
    assert!(path.is_absolute());
    path
}
fn approved_hash() -> [u8; 32] {
    let text = std::env::var("JAPP_W05_RUNTIME_SHA256").unwrap();
    assert_eq!(text.len(), 64);
    let mut hash = [0_u8; 32];
    for (index, byte) in hash.iter_mut().enumerate() {
        *byte = u8::from_str_radix(&text[index * 2..index * 2 + 2], 16).unwrap();
    }
    hash
}
fn absent(pid: u32) {
    let pid = i32::try_from(pid).unwrap();
    for target in [pid, -pid] {
        // Read-only signal 0. No stale numeric child/group identity is ever signalled.
        assert_eq!(unsafe { libc::kill(target, 0) }, -1);
        assert_eq!(
            std::io::Error::last_os_error().raw_os_error(),
            Some(libc::ESRCH)
        );
    }
}
#[derive(Clone)]
struct Generation {
    identity: ServiceIdentity,
    pid: u32,
    native: NativeSession,
}
struct Retired {
    generation: Generation,
    listener: TcpListener,
}
struct Case {
    name: &'static str,
    began: Instant,
    receipts: ReceiptGuard,
    owner: ManagedService,
    engine: Arc<crate::diagnostics::core::engine::Engine>,
    requests: AtomicU64,
    active: Option<Generation>,
    retired: Vec<Retired>,
    clock_id: usize,
    clean: bool,
}
impl ManagedService {
    fn proof_start_initial(&self) -> Result<ServiceIdentity, RecoveryFailure> {
        self.update_background_phase(RecoveryState::Starting);
        let (result, state) = {
            let mut owner = self.supervisor.lock().unwrap();
            let result = owner.start_initial();
            (result, owner.snapshot().state)
        };
        self.update_background_phase(state);
        result
    }
    fn proof_poll(&self) -> Result<super::super::restart::Snapshot, RecoveryFailure> {
        let (result, state) = {
            let mut owner = self.supervisor.lock().unwrap();
            let result = owner.poll();
            (result, owner.snapshot().state)
        };
        self.update_background_phase(state);
        result
    }
    fn proof_begin_stop(&self) -> bool {
        let began = self.gate.begin();
        self.diagnostic
            .store(RecoveryState::Stopping as u8, Ordering::Release);
        began
    }
    fn proof_stop(&self) -> Result<(), RecoveryFailure> {
        self.proof_begin_stop();
        let result = self.supervisor.lock().unwrap().shutdown();
        self.gate.finish(result.is_ok());
        self.diagnostic.store(
            if result.is_ok() {
                RecoveryState::Stopped
            } else {
                RecoveryState::CleanupFailed
            } as u8,
            Ordering::Release,
        );
        result
    }
}
impl Case {
    fn new(name: &'static str, fault: bool) -> Self {
        event(
            name,
            "case_start",
            json!({"headless_actual_owner":true,"wry_background":false}),
        );
        let receipts = ReceiptGuard::install(name);
        let owner = ManagedService::new(
            ConfiguredRuntime::approved(entrypoint(fault), approved_hash()).unwrap(),
        )
        .unwrap();
        let clock_id = owner
            .supervisor
            .lock()
            .unwrap()
            .proof_observation()
            .clock_id;
        let engine = create_engine(owner.clone()).unwrap();
        Self {
            name,
            began: Instant::now(),
            receipts,
            owner,
            engine,
            requests: AtomicU64::new(0),
            active: None,
            retired: Vec::new(),
            clock_id,
            clean: false,
        }
    }
    fn bound(&self) {
        assert!(self.began.elapsed() < CASE_CAP, "45s actual case deadline");
    }
    fn invariants(&self) {
        let owner = self.owner.supervisor.lock().unwrap();
        let observation = owner.proof_observation();
        assert!(observation.clock_shared);
        assert_eq!(observation.clock_id, self.clock_id);
        assert_eq!(observation.policy.automatic_relaunch_limit, 2);
        assert_eq!(
            observation.policy.backoffs,
            [Duration::from_millis(250), Duration::from_secs(1)]
        );
        assert_eq!(observation.policy.cycle_budget, Duration::from_secs(24));
        assert_eq!(
            observation.policy.cleanup_reserve,
            Duration::from_millis(6050)
        );
        assert!(Arc::ptr_eq(&self.owner.cancellation, &owner.quit_handle()));
        assert!(Arc::ptr_eq(
            &self.owner.authority,
            &owner.authority_handle()
        ));
        self.bound();
    }
    fn read_state(&self, expected: &str) {
        let request = self.requests.fetch_add(1, Ordering::AcqRel) + 1;
        let record = runtime().block_on(async {
            tokio::time::timeout(
                Duration::from_secs(5),
                self.engine.read(
                    "main",
                    "tauri://localhost/index.html",
                    false,
                    &json!({"request_id":format!("req_{request:026}")}),
                ),
            )
            .await
            .unwrap()
            .unwrap()
        });
        assert_eq!(record["payload"]["state"], expected);
        let mut keys: Vec<_> = record["payload"]
            .as_object()
            .unwrap()
            .keys()
            .map(String::as_str)
            .collect();
        keys.sort_unstable();
        if expected == "READY" {
            assert_eq!(
                keys,
                ["api_version", "request_id", "service_version", "state"]
            );
            assert_eq!(record["payload"]["service_version"], "0.0.1");
            assert_eq!(record["payload"]["api_version"], "1.0.0");
        } else {
            assert_eq!(keys, ["request_id", "state"]);
        }
        let serialized = record.to_string();
        for forbidden in [
            "bind_port",
            "instance_id",
            "generation",
            "authorization",
            "127.0.0.1",
        ] {
            assert!(!serialized.contains(forbidden));
        }
        event(
            self.name,
            "diagnostics",
            json!({"state":expected,"record":record}),
        );
        self.bound();
    }
    fn accepted_running(&mut self) {
        self.invariants();
        let observation = self.owner.supervisor.lock().unwrap().proof_observation();
        assert!(observation.alive.unwrap());
        let native = self.owner.client_session().unwrap();
        let second = self.owner.client_session().unwrap();
        assert!(Arc::ptr_eq(&native.session, &second.session));
        assert!(Arc::ptr_eq(&native.valid, &second.valid));
        assert!(native.valid.load(Ordering::Acquire));
        let identity = observation.identity.unwrap();
        let pid = observation.pid.unwrap();
        for old in &self.retired {
            assert!(identity.generation > old.generation.identity.generation);
            assert_ne!(identity.instance_id, old.generation.identity.instance_id);
            assert!(!Arc::ptr_eq(
                &native.session,
                &old.generation.native.session
            ));
            assert!(!Arc::ptr_eq(&native.valid, &old.generation.native.valid));
            assert!(native.authority_epoch > old.generation.native.authority_epoch);
            assert!(!old.generation.native.valid.load(Ordering::Acquire));
        }
        assert_eq!(self.owner.diagnostic(), RecoveryState::Running);
        let receipts = self.receipts.all();
        let matching: Vec<_> = receipts
            .iter()
            .filter(|x| x.pid == pid && x.identity == identity)
            .collect();
        assert_eq!(matching.len(), 1);
        event(
            self.name,
            "ack_live_running",
            json!({"pid":pid,"generation":identity.generation,"port":identity.bind_port,"epoch":native.authority_epoch,"same_clock_flag_hub":true}),
        );
        self.active = Some(Generation {
            identity,
            pid,
            native,
        });
        self.read_state("READY");
    }
    fn start(&mut self) {
        self.owner.proof_start_initial().unwrap();
        self.accepted_running();
        assert!((1..=3).contains(&self.receipts.all().len()));
    }
    fn stale(&self, retired: &Retired) {
        let result = runtime().block_on(async {
            tokio::time::timeout(
                BOUND,
                Client::connect(
                    Arc::clone(&retired.generation.native.session),
                    Arc::new(Catalog::new(canonical_documents()).unwrap()),
                    "corr_00000000000000000000000001",
                    Cancellation::new(),
                    ClientPolicy::new(BOUND).unwrap(),
                ),
            )
            .await
            .unwrap()
        });
        assert!(matches!(result, Err(Failure::Disconnected)));
        let began = Instant::now();
        while began.elapsed() < Duration::from_millis(100) {
            match retired.listener.accept() {
                Err(error) if error.kind() == std::io::ErrorKind::WouldBlock => {
                    std::thread::sleep(Duration::from_millis(2))
                }
                _ => panic!("old Session connected or listener observation failed"),
            }
        }
    }
    fn lose(&mut self, terminal: bool) {
        let generation = self.active.take().unwrap();
        self.owner
            .supervisor
            .lock()
            .unwrap()
            .proof_terminate_owned()
            .unwrap();
        let began = Instant::now();
        while self
            .owner
            .supervisor
            .lock()
            .unwrap()
            .proof_observation()
            .alive
            .unwrap()
        {
            assert!(began.elapsed() < BOUND);
            std::thread::sleep(Duration::from_millis(5));
        }
        self.read_state("UNAVAILABLE"); // Actual OwnerSource observes loss; cleanup is still pending.
        assert!(!generation.native.valid.load(Ordering::Acquire));
        assert!(self.owner.authority_epoch() > generation.native.authority_epoch);
        let before = self.owner.supervisor.lock().unwrap().proof_observation();
        assert!(before.child_present);
        assert_eq!(before.first_cause, Some(SupervisorError::ChildExited));
        assert_eq!(
            self.owner.proof_poll().unwrap().state,
            RecoveryState::Recovering
        );
        self.read_state("STARTING");
        let after = self.owner.proof_poll().unwrap();
        assert_eq!(
            after.state,
            if terminal {
                RecoveryState::Failed
            } else {
                RecoveryState::Backoff
            }
        );
        let observation = self.owner.supervisor.lock().unwrap().proof_observation();
        assert!(!observation.child_present);
        assert_eq!(observation.first_cause, Some(SupervisorError::ChildExited));
        absent(generation.pid);
        let listener =
            TcpListener::bind((Ipv4Addr::LOCALHOST, generation.identity.bind_port)).unwrap();
        listener.set_nonblocking(true).unwrap();
        event(
            self.name,
            "generation_cleaned",
            json!({"pid":generation.pid,"port":generation.identity.bind_port,"generation":generation.identity.generation,"first_cause":"ChildExited","reader_reaped_by_real_owner":true,"group_absent":true,"rebound":true}),
        );
        self.retired.push(Retired {
            generation,
            listener,
        });
        self.invariants();
    }
    fn relaunch(&mut self, expected_attempt: u8, backoff: Duration) {
        let before = self.owner.supervisor.lock().unwrap().proof_observation();
        let (until, deadline) = before.backoff.unwrap();
        assert!(until >= before.now);
        assert!(until.saturating_sub(before.now) <= backoff);
        assert!(
            before.now + Duration::from_millis(100) < until,
            "PRECONDITION_FAILED: missed early Backoff observation"
        );
        let count = self.receipts.all().len();
        let early = self.owner.proof_poll().unwrap();
        assert_eq!(early.state, RecoveryState::Backoff);
        assert_eq!(self.receipts.all().len(), count);
        assert_eq!(early.automatic_relaunches, expected_attempt);
        self.read_state("STARTING");
        event(
            self.name,
            "early_backoff_no_spawn",
            json!({"attempt":expected_attempt,"policy_ms":backoff.as_millis(),"now_ns":before.now.as_nanos(),"until_ns":until.as_nanos(),"deadline_ns":deadline.as_nanos(),"spawn_count":count}),
        );
        self.stale(self.retired.last().unwrap());
        while self
            .owner
            .supervisor
            .lock()
            .unwrap()
            .proof_observation()
            .now
            < until + Duration::from_millis(5)
        {
            self.bound();
            std::thread::sleep(Duration::from_millis(5));
        }
        assert_eq!(
            self.owner.proof_poll().unwrap().state,
            RecoveryState::Running
        );
        let spawned = self.receipts.all().len() - count;
        assert!(
            (1..=3).contains(&spawned),
            "all bind attempts must remain observable"
        );
        self.accepted_running();
    }
    fn finish(&mut self) {
        self.owner.proof_stop().unwrap();
        assert!(self.owner.allow_exit());
        assert!(
            !self
                .owner
                .supervisor
                .lock()
                .unwrap()
                .proof_observation()
                .child_present
        );
        if let Some(generation) = self.active.take() {
            absent(generation.pid);
            let listener =
                TcpListener::bind((Ipv4Addr::LOCALHOST, generation.identity.bind_port)).unwrap();
            listener.set_nonblocking(true).unwrap();
            self.retired.push(Retired {
                generation,
                listener,
            });
        }
        let receipts = self.receipts.all();
        for receipt in &receipts {
            absent(receipt.pid);
            event(
                self.name,
                "spawn_receipt",
                json!({"sequence":receipt.sequence,"pid":receipt.pid,"port":receipt.identity.bind_port,"generation":receipt.identity.generation,"elapsed_ns":receipt.elapsed.as_nanos(),"gone_after_owned_cleanup":true}),
            );
        }
        for retired in &self.retired {
            self.stale(retired);
        }
        self.invariants();
        self.read_state("STOPPED");
        event(
            self.name,
            "cleanup_verified",
            json!({"actual_spawns":receipts.len(),"lost_receipts":0,"all_observed_pids_groups_absent":true,"acknowledged_ports_rebound":self.retired.len(),"owned_slot_released":true}),
        );
        self.clean = true;
        event(
            self.name,
            "case_pass",
            json!({"elapsed_ms":self.began.elapsed().as_millis()}),
        );
    }
}
impl Drop for Case {
    fn drop(&mut self) {
        if !self.clean {
            let result = self.owner.proof_stop();
            // Not a PASS. Preserve the original assertion failure and best-effort cleanup result.
            event(
                self.name,
                "unwind_cleanup",
                json!({"result":format!("{result:?}")}),
            );
        }
    }
}
struct HeldOwner {
    release: Option<std::sync::mpsc::SyncSender<()>>,
    worker: Option<std::thread::JoinHandle<()>>,
    timed_out: Arc<AtomicBool>,
}
impl HeldOwner {
    fn new(owner: ManagedService) -> Self {
        let (entered, ready) = std::sync::mpsc::sync_channel(1);
        let (release, wait) = std::sync::mpsc::sync_channel(1);
        let timed_out = Arc::new(AtomicBool::new(false));
        let timed_out_worker = Arc::clone(&timed_out);
        let worker = std::thread::spawn(move || {
            let _guard = owner.supervisor.lock().unwrap();
            entered.send(()).unwrap();
            if matches!(
                wait.recv_timeout(BOUND),
                Err(std::sync::mpsc::RecvTimeoutError::Timeout)
            ) {
                timed_out_worker.store(true, Ordering::Release);
            }
        });
        ready.recv_timeout(BOUND).unwrap();
        Self {
            release: Some(release),
            worker: Some(worker),
            timed_out,
        }
    }
}
impl Drop for HeldOwner {
    fn drop(&mut self) {
        if let Some(release) = self.release.take() {
            let _ = release.try_send(());
        }
        if let Some(worker) = self.worker.take() {
            worker.join().unwrap();
        }
    }
}
struct MissingRuntime {
    original: PathBuf,
    hidden: PathBuf,
}
impl MissingRuntime {
    fn new(name: &str) -> Self {
        let original = entrypoint(true);
        let root = PathBuf::from(std::env::var_os("JAPP_W05_FAULT_ROOT").unwrap())
            .canonicalize()
            .unwrap();
        assert!(original.canonicalize().unwrap().starts_with(&root));
        assert_ne!(
            original.canonicalize().unwrap(),
            entrypoint(false).canonicalize().unwrap()
        );
        assert_eq!(
            <[u8; 32]>::from(Sha256::digest(std::fs::read(&original).unwrap())),
            approved_hash()
        );
        let hidden = original.with_extension("w05-unavailable");
        assert!(!hidden.exists());
        std::fs::rename(&original, &hidden).unwrap();
        event(
            name,
            "owned_runtime_hidden",
            json!({"source":original,"hidden":hidden,"source_absent":!original.exists(),"donor_mutated":false}),
        );
        Self { original, hidden }
    }
}
impl Drop for MissingRuntime {
    fn drop(&mut self) {
        std::fs::rename(&self.hidden, &self.original).unwrap();
        assert_eq!(
            <[u8; 32]>::from(Sha256::digest(std::fs::read(&self.original).unwrap())),
            approved_hash()
        );
    }
}

#[test]
fn actual_owned_deaths_relaunch_twice_then_stop_without_orphans() {
    let mut case = Case::new("two_replacements_then_terminal", false);
    case.start();
    for (attempt, wait) in [(1, Duration::from_millis(250)), (2, Duration::from_secs(1))] {
        case.lose(false);
        case.relaunch(attempt, wait);
    }
    case.lose(true);
    let count = case.receipts.all().len();
    for _ in 0..12 {
        let snapshot = case.owner.proof_poll().unwrap();
        assert_eq!(snapshot.state, RecoveryState::Failed);
        assert_eq!(
            snapshot.reason,
            Some(super::super::restart::LossReason::BudgetExhausted)
        );
        assert_eq!(snapshot.automatic_relaunches, 2);
        std::thread::sleep(Duration::from_millis(100));
    }
    assert_eq!(case.receipts.all().len(), count);
    case.read_state("FAILED");
    case.finish();
}
#[test]
fn actual_quit_during_backoff_closes_same_authority_and_never_restarts() {
    let mut case = Case::new("quit_during_backoff", false);
    case.start();
    let initial_spawns = case.receipts.all().len();
    case.lose(false);
    let epoch = case.owner.authority_epoch();
    let held = HeldOwner::new(case.owner.clone());
    let began = Instant::now();
    assert!(case.owner.proof_begin_stop());
    assert!(began.elapsed() < Duration::from_millis(100));
    assert!(case.owner.cancellation.load(Ordering::Acquire));
    assert!(case.owner.authority_epoch() > epoch);
    case.read_state("STOPPING");
    assert!(
        !held.timed_out.load(Ordering::Acquire),
        "PRECONDITION_FAILED: owner barrier expired"
    );
    event(
        case.name,
        "quit_before_busy_owner",
        json!({"elapsed_ns":began.elapsed().as_nanos(),"epoch_before":epoch,"epoch_after":case.owner.authority_epoch(),"permanent_flag_closed":true,"barrier_expired":false}),
    );
    drop(held);
    case.owner.proof_stop().unwrap();
    std::thread::sleep(Duration::from_millis(1100));
    assert_eq!(
        case.owner.proof_poll().unwrap().state,
        RecoveryState::Stopped
    );
    assert_eq!(
        case.owner.proof_start_initial(),
        Err(RecoveryFailure::Supervisor(SupervisorError::AlreadyRunning))
    );
    assert_eq!(case.receipts.all().len(), initial_spawns);
    assert!(case.owner.cancellation.load(Ordering::Acquire));
    case.finish();
}
#[test]
fn actual_monotonic_cycle_deadline_refuses_delayed_backoff_replacement() {
    let mut case = Case::new("real_clock_delayed_driver_deadline", false);
    case.start();
    let initial_spawns = case.receipts.all().len();
    case.lose(false);
    let before = case.owner.supervisor.lock().unwrap().proof_observation();
    let (_, deadline) = before.backoff.unwrap();
    while case
        .owner
        .supervisor
        .lock()
        .unwrap()
        .proof_observation()
        .now
        < deadline + Duration::from_millis(5)
    {
        case.bound();
        std::thread::sleep(Duration::from_millis(50));
    }
    let after = case.owner.proof_poll().unwrap();
    assert_eq!(after.state, RecoveryState::Failed);
    assert_eq!(
        after.reason,
        Some(super::super::restart::LossReason::DeadlineExpired)
    );
    assert_eq!(case.receipts.all().len(), initial_spawns);
    event(
        case.name,
        "real_deadline_fence",
        json!({"deadline_ns":deadline.as_nanos(),"now_ns":case.owner.supervisor.lock().unwrap().proof_observation().now.as_nanos(),"policy_cycle_ms":24000,"delayed_driver_not_stalled_startup":true}),
    );
    case.read_state("FAILED");
    case.finish();
}
#[test]
fn actual_missing_runtime_replacement_fails_once_without_hidden_loop() {
    let mut case = Case::new("missing_owned_runtime_replacement", true);
    case.start();
    let initial_spawns = case.receipts.all().len();
    case.lose(false);
    let missing = MissingRuntime::new(case.name);
    let before = case.owner.supervisor.lock().unwrap().proof_observation();
    let (until, _) = before.backoff.unwrap();
    while case
        .owner
        .supervisor
        .lock()
        .unwrap()
        .proof_observation()
        .now
        < until + Duration::from_millis(5)
    {
        case.bound();
        std::thread::sleep(Duration::from_millis(5));
    }
    let snapshot = case.owner.proof_poll().unwrap();
    assert_eq!(snapshot.state, RecoveryState::Failed);
    assert_eq!(
        snapshot.reason,
        Some(super::super::restart::LossReason::StartupFailed)
    );
    assert_eq!(
        case.owner
            .supervisor
            .lock()
            .unwrap()
            .proof_observation()
            .first_cause,
        Some(SupervisorError::InvalidRuntime)
    );
    assert_eq!(case.receipts.all().len(), initial_spawns);
    for _ in 0..12 {
        assert_eq!(
            case.owner.proof_poll().unwrap().state,
            RecoveryState::Failed
        );
        std::thread::sleep(Duration::from_millis(100));
    }
    assert_eq!(case.receipts.all().len(), initial_spawns);
    case.read_state("FAILED");
    drop(missing);
    event(
        case.name,
        "owned_runtime_restored",
        json!({"entrypoint_hash_matches":true,"donor_mutated":false}),
    );
    case.finish();
}
