"""Seal only this small source review packet and raw setup control/log copies."""
from pathlib import Path
import ast,hashlib,json,shutil
P=Path(__file__).resolve().parent
R=Path('/tmp/japp-m03-w05-actual-recovery-execution-v2-20261019')
def bind(path):
 raw=path.read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
for name in ['collect.py','prepare-postformat.py','seal-postformat.py']:ast.parse((P/name).read_text())
for path in sorted(R.iterdir()):
 if path.is_file() and path.suffix in {'.json','.py'}:
  target=P/'setup-evidence'/path.name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
for path in sorted((R/'commands').rglob('*')):
 if path.is_file():
  target=P/'setup-evidence/commands'/path.relative_to(R/'commands');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
old=Path('/tmp/japp-m03-w05-actual-recovery-execution-20261019')
for leaf in ['setup-format.initial.py','setup-preparation-failure.json']:
 target=P/'setup-evidence/initial-preparation'/leaf;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old/leaf,target)
files={}
for path in sorted(P.rglob('*')):
 assert not path.is_symlink()
 if path.is_file() and path!=P/'retention-manifest.json':files[path.relative_to(P).as_posix()]=bind(path)
(P/'retention-manifest.json').write_text(json.dumps({'scope':'POSTFORMAT_SOURCE_ONLY_NO_COMPILE_OR_ACTOR','excludes_itself':True,'regular_members':len(files),'payload_bytes':sum(row['bytes']for row in files.values()),'files':files},indent=2,sort_keys=True)+'\n')
print(json.dumps({'members_excluding_manifest':len(files),'retention':bind(P/'retention-manifest.json'),'handoff':bind(P/'HANDOFF.md')},sort_keys=True))
