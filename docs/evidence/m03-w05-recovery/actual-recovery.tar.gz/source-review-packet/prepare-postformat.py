"""Build an immutable small post-rustfmt source review packet, no product import."""
from pathlib import Path
import ast,difflib,hashlib,json,re,shutil

OUT=Path(__file__).resolve().parent
OLD=Path('/tmp/japp-m03-w05-actual-recovery-harness-20261019')
RUN=Path('/tmp/japp-m03-w05-actual-recovery-execution-v2-20261019')
SOURCE=RUN/'source'
BASE=Path('/tmp/japp-m03-w05-current-source-join-20261019/source')
def binding(path):
 raw=Path(path).read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def put(name,value):
 path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True);assert not path.exists(),path
 path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def bodies(text):
 tokens=re.compile(r'//[^\n]*|/\*.*?\*/|(?:br|r)(?P<hashes>\#*)".*?"(?P=hashes)|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])\'|[{}]',re.S)
 tests=re.compile(r'#\[(?:tokio::)?test(?:\([^]]*\))?\]\s*(?:#\[[^]]*\]\s*)*(?:async\s+)?fn\s+(\w+)\s*\(')
 result={}
 for match in tests.finditer(text):
  begin=text.index('{',match.end());depth=0
  for token in tokens.finditer(text,begin):
   if token.group()=='{':depth+=1
   elif token.group()=='}':
    depth-=1
    if depth==0:result[match[1]]=text[begin:token.end()];break
  else:raise AssertionError('unclosed lexical body')
 return result
def normalized(text):
 regex=re.compile(r'(?P<comment>//[^\n]*|/\*.*?\*/)|(?P<literal>(?:br|r)(?P<hashes>\#*)".*?"(?P=hashes)|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])\')|(?P<word>[A-Za-z_][A-Za-z_0-9]*|[0-9]+)|(?P<other>[^\s])',re.S)
 return [m.group()for m in regex.finditer(text)if m.lastgroup!='comment'and m.group()!=',']
base=json.loads((OLD/'inputs/shipping-manifest.json').read_text())
old_overlay=json.loads((OLD/'overlay-manifest.json').read_text())
before=json.loads((OLD/'logical-after-manifest.json').read_text())
after=json.loads((RUN/'owned-postformat-logical.json').read_text())
closed=json.loads((RUN/'setup-format-closed.json').read_text())
assert closed['format_only'] and closed['compiler_tests_runtimeactors'] is False
assert len(after)==1851 and {r:v for r,v in before.items()if r not in old_overlay}=={r:v for r,v in after.items()if r not in old_overlay}
overlay={};strips={};normal={};formatdiff='';patch=''
for rel in old_overlay:
 current=SOURCE/rel;assert binding(current)==after[rel]
 target=OUT/'overlay'/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(current,target)
 overlay[rel]=binding(current)
 original=(OLD/'overlay'/rel).read_text();formatted=current.read_text()
 left=normalized(original);right=normalized(formatted)
 changes=[{'op':op,'before':left[i:j],'after':right[k:l],'before_context':left[max(0,i-5):min(len(left),j+5)],'after_context':right[max(0,k-5):min(len(right),l+5)]}for op,i,j,k,l in difflib.SequenceMatcher(a=left,b=right).get_opcodes()if op!='equal']
 if changes:
  assert rel.endswith('/proof/actual_recovery.rs')
  assert [(x['op'],x['before'],x['after'])for x in changes]==[('insert',[],['{']),('insert',[],['}']),('delete',['{'],[]),('delete',['}'],[]),('insert',[],['{']),('insert',[],['}'])]
  assert changes[0]['before_context']==['spawn','(','move','|','|','loop','{','match','receiver','.']
  assert changes[2]['before_context']==['with','(','|','slot','|','{','match','slot','.','try_borrow_mut','(']
  assert changes[4]['before_context']==[':',':','WouldBlock','=','>','std',':',':','thread',':']
 normal[rel]={'token_stream_equal_ignoring_comments_whitespace_and_comma_punctuation':not changes,'explicit_helper_only_rustfmt_block_braces':changes,'original':binding(OLD/'overlay'/rel),'formatted':binding(current)}
 formatdiff+=''.join(difflib.unified_diff(original.splitlines(True),formatted.splitlines(True),fromfile='preformat/'+rel,tofile='postformat/'+rel))
 if rel in base:
  stripped=re.sub(r'^[ \t]*// W05-ACTUAL-PROOF BEGIN ([\w-]+)\n.*?^[ \t]*// W05-ACTUAL-PROOF END \1\n','',formatted,flags=re.M|re.S)
  assert stripped.encode()==(BASE/rel).read_bytes(),rel
  strips[rel]={'bytes':len(stripped.encode()),'sha256':hashlib.sha256(stripped.encode()).hexdigest()}
  old=(BASE/rel).read_text().splitlines(True)
 else:old=[]
 patch+=''.join(difflib.unified_diff(old,formatted.splitlines(True),fromfile='a/'+rel if old else '/dev/null',tofile='b/'+rel))
assert len(strips)==4 and all(strips[r]==base[r]for r in strips)
rows=json.loads(Path('/tmp/japp-m03-w05-current-source-join-plan-20261019/planned-test-inventory.json').read_text())['bodies'];preserved=[]
for row in rows:
 text=(SOURCE/row['path']).read_text();body=bodies(text)[row['function']]
 digest=hashlib.sha256(body.encode()).hexdigest();assert digest==row['body_sha256']
 preserved.append({'identity':row['identity'],'path':row['path'],'function':row['function'],'body_sha256':digest,'unchanged':True})
newrel='apps/desktop/src-tauri/src/service/proof/actual_recovery.rs'
oldnew=bodies((OLD/'overlay'/newrel).read_text());new=bodies((SOURCE/newrel).read_text())
assert len(new)==4 and set(new)==set(oldnew)
assert all(normalized(new[name])==normalized(oldnew[name])for name in new)
for name in ['collect.py','expected187.json','config.example.json','release.example.json','independent-review.example.json']:
 shutil.copy2(OLD/name,OUT/name)
(OUT/'inputs').mkdir();shutil.copy2(OLD/'inputs/shipping-manifest.json',OUT/'inputs/shipping-manifest.json')
put('logical-after-manifest.json',after);put('overlay-manifest.json',overlay)
put('removal-projection.json',{'shipping1850':binding(OLD/'inputs/shipping-manifest.json'),'proof1851':True,'four_stripped_postformat_files':strips,'removed_new_test_module':newrel,'other1846_unchanged':True,'result_exact1850':True})
put('test-body-preservation.json',{'method':'lexical balanced-body hashes, NOT Rust AST/compiler','old183':preserved,'new4_normalized_tokens_equal':True,'new4_body_hashes':{name:hashlib.sha256(body.encode()).hexdigest()for name,body in new.items()}})
put('format-mechanical-checks.json',normal)
(OUT/'test-only.patch').write_text(patch);(OUT/'format-only.diff').write_text(formatdiff)
put('preformat-packet-binding.json',{'path':str(OLD),'retention':binding(OLD/'retention-manifest.json'),'collector':binding(OLD/'collect.py'),'patch':binding(OLD/'test-only.patch'),'peer':binding(Path('/tmp/japp-m03-w05-actual-recovery-source-independent-review-20261019/independent-review.json')),'unchanged_retained_original':True})
put('setup-format-bindings.json',{'run_directory':str(RUN),'closed':binding(RUN/'setup-format-closed.json'),'source':binding(RUN/'setup-format.py'),'format_upfront':binding(RUN/'commands/06-actual-rustfmt/upfront.json'),'format_result':binding(RUN/'commands/06-actual-rustfmt/result.json'),'format_stdout':binding(RUN/'commands/06-actual-rustfmt/stdout'),'format_stderr':binding(RUN/'commands/06-actual-rustfmt/stderr'),'initial_preparation_issue':binding(Path('/tmp/japp-m03-w05-actual-recovery-execution-20261019/setup-preparation-failure.json')),'no_Cargo_compile_tests_actors':True})
ast.parse((OUT/'collect.py').read_text());ast.parse(Path(__file__).read_text())
print(json.dumps({'scope':'POSTFORMAT_SOURCE_ONLY','logical':binding(OUT/'logical-after-manifest.json'),'overlay':binding(OUT/'overlay-manifest.json'),'collector':binding(OUT/'collect.py'),'patch':binding(OUT/'test-only.patch'),'old_bodies':len(preserved),'new_tests':len(new),'strip1850':True},sort_keys=True))
