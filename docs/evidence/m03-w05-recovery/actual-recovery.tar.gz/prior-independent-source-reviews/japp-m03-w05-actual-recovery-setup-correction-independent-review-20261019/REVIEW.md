# Narrow187 collector/setup correction review

CLEAR for collector736ffe only, with unchanged logical060c/1851 and overlay55b1/fivepaths. The diff adds exactly four Tauri generated output paths. Every other unlisted source/config/bytecode path remains rejected. Each command retains raw before/end generated files and size/SHA/mode or ABSENT; observation errors fail. Source-neutrality scope explicitly covers logical inputs/separately bound auxiliary trees, not unchanged generated outputs. All other constructor/release/compile/catalog/actor/statics guards remain AST-exact to prior65 peer.

Actual122 quarantined files retain exact bytes/modes and are absent from owned source:118 bytecode+fourgenerated outputs. Original constructor refusal occurred before output/tool dispatch and remains setup failure, not product RED. Rust fivepostimages/logical/overlay/tests/policy are byte-exact to prior reviewed source; this review avoids redundant Rust semantics replay. Pending config matches its closed copy and still needs actual peerSHA/status/root release rebind.

Read/hash/AST review only; no compiler, statics, collector import, actor, cache or root mutation. Positive peer is source-only and grants no execution or package acceptance.
