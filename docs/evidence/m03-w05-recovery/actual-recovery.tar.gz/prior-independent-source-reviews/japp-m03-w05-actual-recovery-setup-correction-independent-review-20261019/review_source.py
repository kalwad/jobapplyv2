"""Read/hash/AST only: narrow collector generated-output/setup correction."""
import ast,hashlib,json,re,stat
from datetime import datetime,timezone
from pathlib import Path,PurePosixPath
B=Path(__file__).resolve().parent
P=Path('/tmp/japp-m03-w05-actual-recovery-postformat-v2-20261019')
OLD=Path('/tmp/japp-m03-w05-actual-recovery-postformat-20261019')
OWN=Path('/tmp/japp-m03-w05-actual-recovery-execution-v2-20261019')
PREV=Path('/tmp/japp-m03-w05-actual-recovery-postformat-independent-review-20261019')
checks=[];bindings={}
def read(p):
 assert p.is_file() and not p.is_symlink(),p
 data=p.read_bytes();bindings[str(p)]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};return data
def digest(p):return hashlib.sha256(read(p)).hexdigest()
def load(p):return json.loads(read(p))
def check(name,ok,detail=None):checks.append({'name':name,'pass':bool(ok),'detail':detail});assert ok,name
def dump(n):return ast.dump(n,include_attributes=False)
def put(name,v):(B/name).write_text(json.dumps(v,indent=2)+'\n')
check('prior65_actual_positive_unchanged',digest(PREV/'independent-review.json')=='304efbfdcdd78331f47531d861a071f2dc98561d8a561e95fb63fa78e533d6de' and load(PREV/'findings.json')['checks_passed']==65)
check('newcollector_pin',digest(P/'collect.py')=='736ffe4c9848b6a382d73816daaf976cb3643adb0559a5b988335251e7db7dbd')
for n in ['logical-after-manifest.json','overlay-manifest.json','expected187.json','test-only.patch','test-body-preservation.json']:
 check('unchanged_reviewed_Rust_identity:'+n,read(P/n)==read(OLD/n))
logical=load(P/'logical-after-manifest.json');overlay=load(P/'overlay-manifest.json')
for n,v in overlay.items():
 data=read(P/'overlay'/n)
 check('actual5Rust_still_exact:'+n,data==read(OLD/'overlay'/n)==read(OWN/'source'/n) and {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}==v)
old=ast.parse(read(OLD/'collect.py'));new=ast.parse(read(P/'collect.py'));oldnodes={n.name:n for n in old.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};newnodes={n.name:n for n in new.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
check('no_new_global_functions_classes',set(oldnodes)==set(newnodes))
check('all_other_global_function_AST_exact',all(dump(n)==dump(newnodes[k]) for k,n in oldnodes.items() if k!='Collector'))
a={n.name:n for n in oldnodes['Collector'].body if isinstance(n,ast.FunctionDef)};c={n.name:n for n in newnodes['Collector'].body if isinstance(n,ast.FunctionDef)}
check('exact_three_method_scope',set(c)-set(a)=={'generated_snapshot'} and {k for k in a if dump(a[k])!=dump(c[k])}=={'source_snapshot','command'})
check('release_catalog_statics_actors_guards_unchanged',all(dump(a[n])==dump(c[n]) for n in ['__init__','runtime_snapshot','compile','actors','statics']))
text=read(P/'collect.py').decode();oldtext=read(OLD/'collect.py').decode();expected4=tuple('apps/desktop/src-tauri/gen/schemas/'+n for n in ['capabilities.json','acl-manifests.json','macOS-schema.json','desktop-schema.json'])
assignment=next(n for n in new.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='GENERATED_OUTPUTS' for t in n.targets))
check('fixed4_generated_output_literals_only',ast.literal_eval(assignment.value.args[0].generators[0].iter)==tuple(n.rsplit('/',1)[1] for n in expected4) and 'apps/desktop/src-tauri/gen/schemas/' in ast.get_source_segment(text,assignment))
check('no_broad_gen_config_or_pyc_exemption',"if rel in GENERATED_OUTPUTS: continue" in text and "assert rel in self.logical, 'unexpected source/config file: '+rel" in text and "assert seen==set(self.logical)" in text and 'if rel.endswith' not in ast.get_source_segment(text,c['source_snapshot']) and '__pycache__' not in ast.get_source_segment(text,c['source_snapshot']))
generated=ast.get_source_segment(text,c['generated_snapshot'])
check('before_after_raw_bytes_size_hash_mode_or_absent',all(x in generated for x in ["for rel in GENERATED_OUTPUTS:","assert not path.is_symlink()","{'state':'ABSENT'}","'state':'PRESENT',**hash_file(path)","'mode':oct(path.stat().st_mode & 0o7777)","shutil.copy2(path,retained)","assert hash_file(retained)","assert oct(retained.stat().st_mode & 0o7777)==row['mode']"]))
command=ast.get_source_segment(text,c['command'])
check('command_immutable_before_end_observation_refs',all(x in command for x in ["generated=self.generated_snapshot(folder/'generated-before-files')","write(folder/'generated-before.json',generated)","'generated_outputs_before':hash_file(folder/'generated-before.json')","generated_after=self.generated_snapshot(folder/'generated-after-files')","result['generated_outputs_after']=hash_file(folder/'generated-after.json')","result['generated_outputs_equal']=generated_after==generated"]))
check('generated_observation_error_fails_not_fake_source_neutrality',"result['failure']=result['failure'] or 'generated output observation unavailable'" in command and "assert result['failure'] is None" in command and "1851 logical input files; three separately bound auxiliary trees; exact four generated Tauri outputs observed separately" in command)
check('real_command_before_after_copies_env_preserved',"env=dict(self.env); env.update(extra or {})" in command and "'environment':dict(env)" in command and 'generated_outputs_equal' in command)
setup=P/'setup-correction';inventory=load(setup/'setup-unlisted-source-inventory.json')['unlisted'];modes=load(setup/'quarantine-mode-map.json');closed=load(setup/'setup-artifacts-quarantine-closed.json')
check('exact122_quarantine_inventory_118pyc4outputs',len(inventory)==len(modes)==len(closed['moved'])==122 and len([x for x in inventory if x['path'].endswith('.cpython-312.pyc')])==118 and {x['path'] for x in inventory if not x['path'].endswith('.cpython-312.pyc')}==set(expected4))
check('quarantine_retains_exact_complete_prior_inventory',closed['moved']==inventory and closed['logical1851_unchanged'] is True and closed['cargo_compiler_actor_invocations']==0 and closed['inventory_sha256']==digest(setup/'setup-unlisted-source-inventory.json'))
index={x['path']:x for x in inventory}
for row in modes:
 n=row['path'];q=Path(row['quarantine']);path=OWN/'source'/n
 assert q.resolve().is_relative_to((OWN/'quarantine-donor-artifacts').resolve()) and n not in logical and not path.exists(),n
 data=read(q)
 assert len(data)==row['bytes']==index[n]['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']==index[n]['sha256'] and oct(stat.S_IMODE(q.stat().st_mode))==row['mode'],n
check('all122_actual_quarantined_bytes_modes_and_source_absence',True,'Read-only hash/mode inspection of owned quarantined files only; no moves/cache mutations by reviewer.')
launch=setup/'launch-compile-v1';result=load(launch/'result.json');error=read(launch/'stderr').decode()
check('initial_refusal_honestly_retained_not_compilerRED',result['exit_code']==1 and 'unexpected source/config file:' in error and 'case_v1.cpython-312.pyc' in error and error.index('self.source_snapshot(); self.runtime_snapshot()')<error.index('AssertionError:') and text.index('self.source_snapshot(); self.runtime_snapshot()')<text.index('self.output.mkdir(parents=True)'))
config=load(P/'config-compile-v2.pending-review.json');actual=OWN/'config-compile-v2.pending-review.json'
check('pendingconfig_exact_nonrunnable_peer_missing',read(actual)==read(P/'config-compile-v2.pending-review.json') and config['status']=='PENDING_SETUP_CORRECTION_PEER_REBIND' and config['independent_review_sha256'] is None and config['compiled_catalog_sha256'] is None and Path(config['independent_review_path']).resolve()==(B/'independent-review.json').resolve())
check('pending_config_owned_stage_paths',Path(config['source_dir']).resolve()==(OWN/'source').resolve() and Path(config['output_dir']).resolve()==(OWN/'evidence-compile-v2').resolve() and config['environment']['CARGO_BUILD_JOBS']=='2' and config['environment']['CARGO_NET_OFFLINE']=='true' and config['actor_modes']==['default'])
ret=load(P/'retention-manifest.json')['files'];check('finite82_manifest_pin',digest(P/'retention-manifest.json')=='72b2e19c930606344ea396c234ef16c363a138956001428ac50b51f7a7f84eee' and len(ret)==82)
for n,v in ret.items():
 rel=PurePosixPath(n);assert not rel.is_absolute() and not any(x in ['.','..'] for x in rel.parts)
 data=read(P/n);assert {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}==v,n
check('all82_finite_payloads_exact',True)
peer={'decision':'CLEAR','scope':'W05_TEST_ONLY_HARNESS_SOURCE','reviewer':'/root/final_runtime_review','collector_sha256':digest(P/'collect.py'),'logical_manifest_sha256':digest(P/'logical-after-manifest.json'),'overlay_manifest_sha256':digest(P/'overlay-manifest.json'),'source_only':True,'execution_release':False}
put('independent-review.json',peer)
report={'decision':'CLEAR','scope':'NARROW_COLLECTOR_SETUP_CORRECTION_SOURCE_ONLY','reviewer':'/root/final_runtime_review','completed_utc':datetime.now(timezone.utc).isoformat(),'checks_passed':len(checks),'checks_total':len(checks),'checks':checks,'findings':[],'peer':peer,'pending_config':{'path':str(actual),'sha256':digest(actual),'state':'Pending peerSHA/status rebind; not current runnable release'},'limits':['Reuses unchanged Rust/harness65 peer semantics; does not replay broad design/183 bodies.','No compiler/list/statics/test/native actor/provider import/cache/root writes by reviewer.','Generated output before/after values are observations, not input immutability or future success.','Original preflight refusal/quarantine are setup history, not product RED or187 execution.','Root release and exact final config binding still required before tools.']}
put('findings.json',report);put('input-bindings.json',bindings)
(B/'REVIEW.md').write_text('''# Narrow187 collector/setup correction review\n\nCLEAR for collector736ffe only, with unchanged logical060c/1851 and overlay55b1/fivepaths. The diff adds exactly four Tauri generated output paths. Every other unlisted source/config/bytecode path remains rejected. Each command retains raw before/end generated files and size/SHA/mode or ABSENT; observation errors fail. Source-neutrality scope explicitly covers logical inputs/separately bound auxiliary trees, not unchanged generated outputs. All other constructor/release/compile/catalog/actor/statics guards remain AST-exact to prior65 peer.\n\nActual122 quarantined files retain exact bytes/modes and are absent from owned source:118 bytecode+fourgenerated outputs. Original constructor refusal occurred before output/tool dispatch and remains setup failure, not product RED. Rust fivepostimages/logical/overlay/tests/policy are byte-exact to prior reviewed source; this review avoids redundant Rust semantics replay. Pending config matches its closed copy and still needs actual peerSHA/status/root release rebind.\n\nRead/hash/AST review only; no compiler, statics, collector import, actor, cache or root mutation. Positive peer is source-only and grants no execution or package acceptance.\n''')
print(json.dumps({'decision':'CLEAR','checks':len(checks),'peer_sha256':digest(B/'independent-review.json'),'findings_sha256':digest(B/'findings.json'),'review_sha256':digest(B/'REVIEW.md')},indent=2))
