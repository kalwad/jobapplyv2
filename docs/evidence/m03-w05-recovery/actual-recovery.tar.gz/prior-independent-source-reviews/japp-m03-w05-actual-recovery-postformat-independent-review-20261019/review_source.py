"""Bounded independent postformat source inspection; no collector/helper import or actors."""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import ast,difflib,hashlib,json,re,shutil
P=Path('/tmp/japp-m03-w05-actual-recovery-postformat-20261019')
OLD=Path('/tmp/japp-m03-w05-actual-recovery-harness-20261019')
BASE=Path('/tmp/japp-m03-w05-current-source-join-20261019/source')
OWN=Path('/tmp/japp-m03-w05-actual-recovery-execution-v2-20261019/source')
PRIOR=Path('/tmp/japp-m03-w05-actual-recovery-source-independent-review-20261019')
B=Path(__file__).resolve().parent
checks=[];bindings={}
def read(p):
 assert p.is_file() and not p.is_symlink(),p
 data=p.read_bytes();bindings[str(p)]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};return data
def sha(p):return hashlib.sha256(read(p)).hexdigest()
def load(p):return json.loads(read(p))
def ck(name,ok,detail=None):checks.append({'name':name,'pass':bool(ok),'detail':detail});assert ok,name
shipping=load(P/'inputs/shipping-manifest.json');logical=load(P/'logical-after-manifest.json');overlay=load(P/'overlay-manifest.json');prior=load(PRIOR/'findings.json')
ck('prior_different_author_source44_CLEAR',prior['decision']=='CLEAR' and prior['checks_passed']==prior['checks_total']==44 and prior['reviewer']=='/root/fresh_evidence_audit')
ck('exact_postformat_pins',sha(P/'logical-after-manifest.json')=='060c2fd8e143b33560e101ac090b0a96c4a545048caa3224b05196cbd27d59f0' and sha(P/'overlay-manifest.json')=='55b10359c2bad1b76381852d5f38f61cb800b8d5d29a37ed01c3c2b08dbe2069' and sha(P/'retention-manifest.json')=='9eedaea7c15e3e241892cfbf51622cb22ef909fffdacefe3c712fe410302195b')
new='apps/desktop/src-tauri/src/service/proof/actual_recovery.rs'
ck('exact1850_base_1851_derivative_fiveoverlay',sha(P/'inputs/shipping-manifest.json')=='ee091e710086c6149d019c9ac58aed68f6b8b8dedee31b572dfabedba36f4f47' and len(shipping)==1850 and len(logical)==1851 and len(overlay)==5 and logical=={**shipping,**overlay} and set(logical)-set(shipping)=={new})
ck('nonoverlay1846_manifest_exact',len(set(shipping)-set(overlay))==1846 and all(logical[n]==v for n,v in shipping.items() if n not in overlay),'Inherited full source identity in closed author maps; reviewer reads actual5 overlay plus183body files, not every1846 source file/cache.')
for n,v in overlay.items():
 a=read(P/'overlay'/n);actual=read(OWN/n)
 ck('actual_owned_and_packet_overlay:'+n,a==actual and {'bytes':len(a),'sha256':hashlib.sha256(a).hexdigest()}==v)
 if n!=new:
  stripped=re.sub(rb'^[ \t]*// W05-ACTUAL-PROOF BEGIN ([\w-]+)\n.*?^[ \t]*// W05-ACTUAL-PROOF END \1\n',b'',a,flags=re.M|re.S);base=read(BASE/n)
  ck('strip_exact_shipping:'+n,stripped==base and {'bytes':len(base),'sha256':hashlib.sha256(base).hexdigest()}==shipping[n])
  blocks=re.findall(rb'// W05-ACTUAL-PROOF BEGIN [\w-]+\n(.*?)// W05-ACTUAL-PROOF END [\w-]+\n',a,re.S)
  ck('cfg_test_unix_islands:'+n,bool(blocks) and all(b'#[cfg(all(test, unix))]' in x for x in blocks))
lex=re.compile(r'//[^\n]*|/\*.*?\*/|(?:br|r)(?P<h>\#*)".*?"(?P=h)|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])\'|[A-Za-z_][A-Za-z_0-9]*|[0-9]+|[^\s]',re.S)
testpat=re.compile(r'#\[(?:tokio::)?test(?:\([^]]*\))?\]\s*(?:#\[[^]]*\]\s*)*(?:async\s+)?fn\s+(\w+)\s*\(')
def bodies(s):
 out={}
 for m in testpat.finditer(s):
  start=s.index('{',m.end());depth=0
  for token in lex.finditer(s,start):
   if token.group()=='{':depth+=1
   elif token.group()=='}':
    depth-=1
    if not depth:out[m[1]]=s[start:token.end()];break
  else:raise AssertionError('unbalanced source body')
 return out
def tokens(s,commas=False):return [m.group() for m in lex.finditer(s) if not m.group().startswith(('//','/*')) and (commas or m.group()!=',')]
bodymap=load(P/'test-body-preservation.json');cache={};drift=[]
for row in bodymap['old183']:
 n=row['path']
 if n not in cache:
  before=read(BASE/n);after=read(OWN/n)
  ck('actual_body_source_file:'+n,{'bytes':len(after),'sha256':hashlib.sha256(after).hexdigest()}==logical[n])
  cache[n]=(bodies(before.decode()),bodies(after.decode()))
 old,actual=cache[n];expected=row['body_sha256']
 if old[row['function']]!=actual[row['function']] or hashlib.sha256(actual[row['function']].encode()).hexdigest()!=expected:drift.append(row['identity'])
ck('all183_existing_bodies_byte_exact',len(bodymap['old183'])==183 and not drift,{'source_files':len(cache),'drift':drift,'method':'Lexical balanced-body only, not Rust AST/compiler'})
before=read(OLD/'overlay'/new).decode();after=read(P/'overlay'/new).decode();old4=bodies(before);new4=bodies(after)
ck('exact_four_case_names',set(old4)==set(new4)==set(bodymap['new4_body_hashes']) and len(new4)==4)
for name,body in new4.items():
 ck('four_case_noncomma_tokens_exact:'+name,tokens(old4[name])==tokens(body))
 ck('four_case_body_binding:'+name,hashlib.sha256(body.encode()).hexdigest()==bodymap['new4_body_hashes'][name])
 # All changed punctuation inside test bodies must be commas only; preserve every assertion/string/number/operator/brace.
 a,b=tokens(old4[name],True),tokens(body,True);diff=[(op,a[i:j],b[k:l]) for op,i,j,k,l in difflib.SequenceMatcher(a=a,b=b,autojunk=False).get_opcodes() if op!='equal']
 ck('four_case_only_comma_format_changes:'+name,all(all(x==',' for x in xold+xnew) for _,xold,xnew in diff),{'comma_edits':len(diff),'assert_macro_tokens_before':sum(x.startswith('assert') for x in a),'after':sum(x.startswith('assert') for x in b)})
brace_changes=[]
for n in overlay:
 a=tokens(read(OLD/'overlay'/n).decode());b=tokens(read(P/'overlay'/n).decode())
 diff=[{'op':op,'before':a[i:j],'after':b[k:l],'before_context':a[max(0,i-5):j+5],'after_context':b[max(0,k-5):l+5]} for op,i,j,k,l in difflib.SequenceMatcher(a=a,b=b,autojunk=False).get_opcodes() if op!='equal']
 if n==new:brace_changes=diff
 else:ck('only_whitespace_comma_formatter_delta:'+n,not diff)
ck('exact_three_helper_block_pairs_only',[(x['op'],x['before'],x['after']) for x in brace_changes]==[('insert',[],['{']),('insert',[],['}']),('delete',['{'],[]),('delete',['}'],[]),('insert',[],['{']),('insert',[],['}'])],brace_changes)
ck('helper_pair_contexts_only',all('assert' not in ''.join(x['before_context']+x['after_context']) for x in brace_changes) and 'move || {\n            loop {' in after and 'RECEIPT.with(|slot| match slot.try_borrow_mut()' in after and 'WouldBlock => {\n                    std::thread::sleep(Duration::from_millis(2))\n                }' in after,'Manual source review: observer closure tail-loop wrapping; receipt closure match wrapping removed; unit sleep match arm wrapped. No assertion, call, literal, policy or control-flow token changes.')
ck('same_declared187_inventory',load(P/'expected187.json')==load(OLD/'expected187.json') and len(load(P/'expected187.json'))==187)
ck('exact_unchanged_collector_and_templates',sha(P/'collect.py')==prior['collector_sha256']=='da845d9d91e4aa2b190ef827e0e795c9b0a142f8267c981b748dc137142e6df5' and all(read(P/n)==read(OLD/n) for n in ['config.example.json','release.example.json','independent-review.example.json']))
ast.parse(read(P/'collect.py'));ck('collector_syntax_only',True,'Parsed only; no import/invocation.')
f=P/'setup-evidence/commands/06-actual-rustfmt';up=load(f/'upfront.json');res=load(f/'result.json')
ck('one_actual_exact_rustfmt_only',up['argv'][:5]==['/Users/tanishkalwad/.rustup/toolchains/1.97.1-aarch64-apple-darwin/bin/rustfmt','--edition','2024','--config','skip_children=true'] and up['argv'][5:]==[str((OWN/n).resolve()) for n in overlay] and res['exit_code']==0 and res['tool_after']=={k:up['tool'][k] for k in ['bytes','sha256']} and read(f/'stdout')==read(f/'stderr')==b'')
ret=load(P/'retention-manifest.json')['files'];ck('finite69_payload_paths_safe',len(ret)==69 and all(not PurePosixPath(n).is_absolute() and not any(x in ['.','..'] for x in PurePosixPath(n).parts) and '\\' not in n for n in ret))
for n,v in ret.items():data=read(P/n);assert {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}==v,n
ck('all69_finite_payloads_hash_exact',True)
report={'scope':'W05_TEST_ONLY_HARNESS_SOURCE_POSTFORMAT','decision':'CLEAR','reviewer':'/root/final_runtime_review','completed_utc':datetime.now(timezone.utc).isoformat(),'collector_sha256':sha(P/'collect.py'),'logical_manifest_sha256':sha(P/'logical-after-manifest.json'),'overlay_manifest_sha256':sha(P/'overlay-manifest.json'),'patch_sha256':sha(P/'test-only.patch'),'checks_total':len(checks),'checks_passed':sum(x['pass'] for x in checks),'checks':checks,'findings':[],'limits':['Bounded mechanical review over prior44CLEAR; not a new broad harness design approval.','Actual5 overlay+183body source reads and finite69 retained inputs;1846 remaining files inherit closed source maps and were not all independently rehashed.','Lexical normalized/body checks and actual rustfmt receipt are not Rust AST/type/compiler evidence.','No compiler/list/test/actor/cache write/root write;187 and four actual PASS unclaimed.','Any later compiler source repair requires new exact peer binding; root alone releases compilation/actors.']}
(B/'findings.json').write_text(json.dumps(report,indent=2)+'\n')
peer={'decision':'CLEAR','scope':'W05_TEST_ONLY_HARNESS_SOURCE','reviewer':'/root/final_runtime_review','collector_sha256':report['collector_sha256'],'logical_manifest_sha256':report['logical_manifest_sha256'],'overlay_manifest_sha256':report['overlay_manifest_sha256'],'source_only':True,'execution_release':False}
(B/'independent-review.json').write_text(json.dumps(peer,indent=2)+'\n')
(B/'input-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n');shutil.copyfile(P/'collect.py',B/'reviewed-collector.py')
(B/'REVIEW.md').write_text('''# Bounded postformat peer source review\n\nCLEAR for exact postformat collector da845d, logical060c2f/1851 and overlay55b103/fivepaths only. Actual owned fivepostimages match the finite packet. Removing the four cfg(test,unix) marker islands and the one new module restores exact shipping1850 ee091e. All183 old body hashes are byte-exact. All four new cases preserve every noncomma token, assertion, literal, operator and brace. Whole-module differences are formatting plus three manually inspected helper block pairs: observer closure loop wrapper, receipt closure match wrapper removal, and unit sleep match-arm wrapper. No policy, deadline, assertion or ownership behavior changes.\n\nThe collector/templates and expected187 set remain byte-exact to the different-reviewer prior44CLEAR. Actual pinned rustfmt ran once on exactly five owned files with edition2024/skip_children, exit0 and empty output; no compiler or actor followed. All69 retained payload hashes match. Preparation-only datetime/checker failures remain honest history, not product RED.\n\nThis review writes only its own records. It reads the actual overlay/body files and finite packet, inherits remaining1846 source-map equality rather than rehashing every source/cache, and claims no Rust AST/compiler,187 execution, GUI/package/gate acceptance or root execution release. Future mechanical compiler edits require fresh exact review.\n''')
print(json.dumps({'decision':'CLEAR','checks':len(checks),'peer_sha256':sha(B/'independent-review.json'),'findings_sha256':sha(B/'findings.json'),'review_sha256':sha(B/'REVIEW.md')},indent=2))
