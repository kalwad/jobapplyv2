"""UNEXECUTED outside W05 collector. Requires root phase release and separate peer review.

No installer, network fetch, GUI, package builder, CI action or source mutator exists here.
Source/dependencies/runtime copies must be separately prepared after root's timing hold.
"""
import argparse
import datetime
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPOSITORY = Path('/Users/tanishkalwad/jobapplyv2').resolve()
BASE = Path('/tmp/japp-m03-w05-current-source-join-20261019/source').resolve()
EXPECTED_BASE = 'ee091e710086c6149d019c9ac58aed68f6b8b8dedee31b572dfabedba36f4f47'
APP = 'apps/desktop/src-tauri/Cargo.toml'
MODES = {'default':[], 'all-features':['--all-features'], 'sdk-custom':['--features','tauri/custom-protocol']}
PREFIX = 'service::tauri_lifecycle::actual_recovery_tests::'
CASES = {
    PREFIX+'actual_owned_deaths_relaunch_twice_then_stop_without_orphans':('two_replacements_then_terminal',3),
    PREFIX+'actual_quit_during_backoff_closes_same_authority_and_never_restarts':('quit_during_backoff',1),
    PREFIX+'actual_monotonic_cycle_deadline_refuses_delayed_backoff_replacement':('real_clock_delayed_driver_deadline',1),
    PREFIX+'actual_missing_runtime_replacement_fails_once_without_hidden_loop':('missing_owned_runtime_replacement',1),
}

def utc(): return datetime.datetime.now(datetime.UTC).isoformat()
def load(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def hash_file(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1024*1024): digest.update(block)
    return {'bytes':path.stat().st_size, 'sha256':digest.hexdigest()}
def write(path, value):
    path = Path(path)
    assert not path.exists(), path
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def outside(path):
    path = Path(path).resolve()
    assert not path.is_relative_to(REPOSITORY) and not path.is_relative_to(BASE), path
    return path
def inventory(root):
    root = Path(root)
    result = {}
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_file(): result[path.relative_to(root).as_posix()] = hash_file(path)
    return result
def auxiliary_inventory(root):
    root=Path(root); result={}
    for path in sorted(root.rglob('*')):
        rel=path.relative_to(root).as_posix()
        if path.is_symlink():
            resolved=path.resolve()
            assert resolved.is_file() and not resolved.is_relative_to(REPOSITORY)
            result[rel]={'symlink':os.readlink(path),'resolved':str(resolved),'resolved_image':hash_file(resolved)}
        elif path.is_file(): result[rel]=hash_file(path)
    return result
def named_inventory(root, manifest):
    root = Path(root)
    result = {}
    for rel, expected in manifest.items():
        assert not Path(rel).is_absolute() and '..' not in Path(rel).parts
        path = root/rel
        assert path.resolve().is_relative_to(root.resolve())
        actual = hash_file(path)
        assert actual == expected, rel
        result[rel] = actual
    return result
def group_present(pgid):
    try: os.killpg(pgid,0); return True
    except ProcessLookupError: return False
    except PermissionError: return True
def observed_file(path):
    try: return hash_file(path)
    except BaseException as error: return {'error':f'{type(error).__name__}: {error}'}
def services_after(ledger,wait):
    # Only read-only signal0 on the exact observed service IDs; never terminate them.
    try:
        rows=[json.loads(line) for line in Path(ledger).read_text().splitlines()]
        pids=sorted({row['details']['pid'] for row in rows if row['event']=='native_spawn'})
    except BaseException as error: return {'error':str(error),'all_absent':False}
    deadline=time.monotonic()+wait
    while True:
        observed=[]
        for pid in pids:
            for target in [pid,-pid]:
                try: os.kill(target,0); state='PRESENT'
                except ProcessLookupError: state='ABSENT'
                except PermissionError: state='PERMISSION_DENIED'
                observed.append({'target':target,'state':state})
        if all(row['state']=='ABSENT' for row in observed) or time.monotonic()>=deadline: break
        time.sleep(.05)
    return {'observations':observed,'all_absent':bool(pids) and all(row['state']=='ABSENT' for row in observed),'actual_receipt_pids':pids,'signals_sent':False,'unregistered_OS_descendants':'UNOBSERVED','empty_receipt_scope':'UNKNOWN, not all-child cleanup proof'}
def stop_owned(child):
    # Only this Popen-created session/process group. Never signal a recorded service PID.
    records=[]
    for sig,seconds in [(signal.SIGTERM,10),(signal.SIGKILL,5)]:
        child.poll()
        if not group_present(child.pid): break
        try: os.killpg(child.pid,sig)
        except ProcessLookupError: break
        records.append({'signal':sig.name,'utc':utc()})
        deadline=time.monotonic()+seconds
        while group_present(child.pid) and time.monotonic()<deadline:
            child.poll(); time.sleep(.05)
    child.poll()
    return {'signals':records,'owned_group':'STILL_PRESENT' if group_present(child.pid) else 'GONE', 'direct_child_returncode':child.returncode, 'unregistered_OS_descendants':'UNOBSERVED'}

class Collector:
    def __init__(self,config_path,release_path,stage):
        # All validation above mkdir/tool/process actions. No claim of human authorization
        # arises from the Python code; root supplies the explicit immutable release.
        self.stage=stage; self.config_path=outside(config_path); self.release_path=outside(release_path)
        self.config=load(self.config_path); release=load(self.release_path)
        peer_path=outside(self.config['independent_review_path']); peer=load(peer_path)
        logical_path=HERE/'logical-after-manifest.json'; overlay_path=HERE/'overlay-manifest.json'
        assert release['decision']=='ROOT_RELEASED_OUTSIDE_W05_PHASE' and release['stage']==stage
        assert release['performance_hold_cleared'] is True
        assert release['collector_sha256']==hash_file(__file__)['sha256']
        assert release['logical_manifest_sha256']==hash_file(logical_path)['sha256']
        assert release['config_sha256']==hash_file(self.config_path)['sha256']
        assert peer['decision']=='CLEAR' and peer['scope']=='W05_TEST_ONLY_HARNESS_SOURCE'
        reviewer=peer['reviewer']
        assert isinstance(reviewer,str) and re.fullmatch(r'/root(?:/[a-z][a-z0-9_]*)+',reviewer)
        author='/root/fresh_safety_review'
        assert reviewer!=author and not reviewer.startswith(author+'/')
        assert peer['collector_sha256']==hash_file(__file__)['sha256']
        assert peer['logical_manifest_sha256']==hash_file(logical_path)['sha256']
        assert peer['overlay_manifest_sha256']==hash_file(overlay_path)['sha256']
        self.source=outside(self.config['source_dir']); self.output=outside(self.config['output_dir'])
        self.runtime=outside(self.config['runtime_dir']); self.fault=outside(self.config['fault_runtime_dir'])
        self.target=outside(self.config['cargo_target_dir'])
        assert self.runtime!=self.fault and not self.runtime.is_relative_to(self.fault) and not self.fault.is_relative_to(self.runtime)
        assert not self.output.is_relative_to(self.source) and not self.source.is_relative_to(self.output)
        owned=[self.source,self.output,self.runtime,self.fault,self.target]
        assert all(not left.is_relative_to(right) and not right.is_relative_to(left) for index,left in enumerate(owned) for right in owned[index+1:])
        self.logical=load(logical_path); self.expected=load(HERE/'expected187.json')
        assert len(self.logical)==1851 and len(set(self.expected))==187
        self.env=dict(self.config['environment'])
        assert all(isinstance(k,str) and isinstance(v,str) for k,v in self.env.items())
        assert self.env['CARGO_NET_OFFLINE']=='true' and self.env['CARGO_BUILD_JOBS']=='2'
        assert Path(self.env['CARGO_TARGET_DIR']).resolve()==self.target
        assert self.env.get('RUST_TEST_THREADS') is None
        for key in ['CARGO_HOME','RUSTUP_HOME','TMPDIR','TEMP','TMP']: outside(self.env[key])
        self.tools={name:outside(row['path']) for name,row in self.config['tool_images'].items()}
        assert set(self.tools)=={'cargo','rustc'}
        for name,path in self.tools.items(): assert hash_file(path)=={k:v for k,v in self.config['tool_images'][name].items() if k!='path'}
        assert Path(self.env['RUSTC']).resolve()==self.tools['rustc']
        # No inherited wrappers/flags can silently alter this approved environment.
        for key in ['RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']:
            assert not self.env.get(key)
        assert hash_file(HERE/'inputs/shipping-manifest.json')['sha256']==EXPECTED_BASE
        applicability=outside(self.config['runtime_applicability_path'])
        assert hash_file(applicability)['sha256']==self.config['runtime_applicability_sha256']
        self.applicability=load(applicability)
        assert len(self.applicability['source_inputs'])==135 and len(self.applicability['runtime'])==40
        assert not self.applicability['new_Python_build_or_actor_credit']
        assert self.applicability['runtime']['manifest.json']['sha256']=='d274dcc7194722a4ec1549043543225d63bf48e5c6c8e55f4049eee4b5ceeea0'
        auxiliary=self.config['auxiliary_directories']
        expected_aux={'frontend_dist':self.source/'apps/desktop/dist','compile_runtime_payload':self.source/'apps/desktop/src-tauri/runtime-payload','python_environment':self.source/'.venv'}
        assert set(auxiliary)==set(expected_aux)
        self.auxiliary={}
        for role,row in auxiliary.items():
            root=outside(row['root']); manifest=outside(row['manifest_path'])
            assert root==expected_aux[role] and hash_file(manifest)['sha256']==row['manifest_sha256']
            self.auxiliary[role]=(root,load(manifest))
        self.source_snapshot(); self.runtime_snapshot()
        assert not self.output.exists(), self.output
        self.output.mkdir(parents=True)
        write(self.output/'release-inputs.json',{'config':hash_file(self.config_path),'release':hash_file(self.release_path),'independent_review':hash_file(peer_path),'collector':hash_file(__file__),'environment':dict(self.env),'scope':'Outside derivative187; only selected4 actor executions; no Wry/background/package claim'})

    def source_snapshot(self):
        # Reject unlisted source/config inputs, not merely changes to known files.
        # Only the three separately closed auxiliary trees are pruned here; their
        # exact contents/links/images are checked by runtime_snapshot below.
        auxiliary={root for root,_expected in self.auxiliary.values()}
        seen=set()
        for current,dirs,files in os.walk(self.source,followlinks=False):
            current=Path(current)
            for leaf in list(dirs):
                path=current/leaf
                if path in auxiliary:
                    assert not path.is_symlink(), path
                    dirs.remove(leaf)
                    # Auxiliary roots may contain tracked leaves such as the
                    # runtime-payload/.gitignore. Credit only those known names;
                    # named_inventory still authenticates every such file below.
                    seen.update(rel for rel in self.logical if (self.source/rel).is_relative_to(path))
                else: assert not path.is_symlink(), path
            for leaf in files:
                path=current/leaf
                assert not path.is_symlink(), path
                rel=path.relative_to(self.source).as_posix()
                assert rel in self.logical, 'unexpected source/config file: '+rel
                seen.add(rel)
        assert seen==set(self.logical), 'missing/unlisted physical source file'
        return named_inventory(self.source,self.logical)
    def runtime_snapshot(self):
        named_inventory(self.source,self.applicability['source_inputs'])
        for root in [self.runtime,self.fault]: assert inventory(root)==self.applicability['runtime']
        provenance={}
        assert set(self.config['wheel_paths'])==set(self.applicability['wheels'])
        for name,row in self.applicability['wheels'].items():
            path=outside(self.config['wheel_paths'][name]);actual=hash_file(path)
            assert actual=={key:row[key] for key in ['bytes','sha256']}
            provenance[name]={'path':str(path),**actual}
        assert set(self.config['requirement_paths'])==set(self.applicability['additional_requirements'])
        for name,row in self.applicability['additional_requirements'].items():
            path=outside(self.config['requirement_paths'][name]);actual=hash_file(path)
            assert actual=={key:row['retained_build_input'][key] for key in ['bytes','sha256']}
            provenance[name]={'path':str(path),**actual}
        # No new Python build credit; these are exact reused inputs and actual runtime.
        auxiliary={}
        for role,(root,expected) in self.auxiliary.items():
            actual=auxiliary_inventory(root);assert actual==expected, role
            auxiliary[role]=actual
        return {'runtime':inventory(self.runtime),'fault_runtime':inventory(self.fault),'compile_auxiliary':auxiliary,'reused_wheel_requirement_provenance':provenance}
    def command(self,label,argv,timeout,extra=None,actor=False):
        folder=self.output/label; folder.mkdir()
        env=dict(self.env); env.update(extra or {})
        source=self.source_snapshot(); runtime=self.runtime_snapshot()
        tool=hash_file(argv[0]); write(folder/'source-before.json',source); write(folder/'runtime-before.json',runtime)
        chain={name:hash_file(path) for name,path in self.tools.items()}
        upfront={'argv':list(argv),'cwd':str(self.source),'environment':dict(env),'timeout_seconds':timeout,'started_at':utc(),'tool_image':str(Path(argv[0]).resolve()),'tool_before':tool,'toolchain_before':chain,'collector':hash_file(__file__),'source_before':hash_file(folder/'source-before.json'),'runtime_before':hash_file(folder/'runtime-before.json'),'actor':actor}
        write(folder/'upfront.json',upfront); began=time.monotonic(); cleanup=None; child=None; failure=None
        try:
            with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:
                child=subprocess.Popen(argv,cwd=self.source,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
                write(folder/'owned-process.json',{'pid':child.pid,'pgid':child.pid,'new_session':True,'argv':list(argv),'started_at':utc()})
                deadline=began+timeout
                while child.poll() is None and time.monotonic()<deadline: time.sleep(.05)
                if child.poll() is None:
                    cleanup=stop_owned(child); failure='whole invocation timeout; never a PASS'
                else:
                    cleanup={'owned_group':'STILL_PRESENT' if group_present(child.pid) else 'GONE','direct_child_returncode':child.returncode,'unregistered_OS_descendants':'UNOBSERVED'}
                    if cleanup['owned_group']!='GONE':
                        cleanup=stop_owned(child); failure='owned group remains after direct child exit'
                if child.returncode!=0: failure=failure or 'nonzero child exit'
        except BaseException as error:
            failure=f'{type(error).__name__}: {error}'
            if child is not None: cleanup=stop_owned(child)
        finally:
            result={'ended_at':utc(),'elapsed_seconds':time.monotonic()-began,'exit_code':None if child is None else child.returncode,'failure':failure,'cleanup':cleanup,'tool_after':observed_file(argv[0]),'stdout':observed_file(folder/'stdout'),'stderr':observed_file(folder/'stderr')}
            result['toolchain_after']={name:observed_file(path) for name,path in self.tools.items()}
            result['collector_after']=observed_file(__file__)
            if actor:
                result['service_read_only_observation']=services_after(env['JAPP_W05_LEDGER'],8 if failure else 0)
            for name,reader in [('source',self.source_snapshot),('runtime',self.runtime_snapshot)]:
                try:
                    after=reader();write(folder/f'{name}-after.json',after);result[name+'_unchanged']=after==({'source':source,'runtime':runtime}[name])
                except BaseException as error: result[name+'_unchanged']=False;result[name+'_error']=str(error)
            if result['tool_after']!=tool or result['toolchain_after']!=chain or result['collector_after']!=upfront['collector']:
                result['failure']=result['failure'] or 'tool/collector image binding changed'
            if not result['source_unchanged'] or not result['runtime_unchanged']:
                result['failure']=result['failure'] or 'source/runtime/auxiliary binding changed or unavailable'
            if actor and not result['service_read_only_observation']['all_absent']:
                result['failure']=result['failure'] or 'registered service absence unproven'
            write(folder/'result.json',result)
        assert result['failure'] is None, label
        if actor: assert result['service_read_only_observation']['all_absent'], label
        return folder

    def compile(self):
        for name,argv in [('cargo-version',[str(self.tools['cargo']),'--version']),('rustc-version',[str(self.tools['rustc']),'-Vv'])]: self.command(name,argv,30)
        catalogs={}
        for mode,features in MODES.items():
            folder=self.command(mode+'-compile',[str(self.tools['cargo']),'test','--offline','--locked','--manifest-path',APP,*features,'--no-run','--message-format=json'],600)
            artifacts=[]
            for line in (folder/'stdout').read_text().splitlines():
                item=json.loads(line)
                if item.get('reason')=='compiler-artifact' and item.get('executable') and item.get('profile',{}).get('test'):
                    assert Path(item['manifest_path']).resolve()==(self.source/APP).resolve()
                    original=outside(item['executable']); retained=self.output/(mode+'-binary-'+str(len(artifacts)))
                    before=hash_file(original);shutil.copy2(original,retained);retained.chmod(0o555)
                    assert hash_file(retained)==before
                    artifacts.append({'original':str(original),'retained':str(retained),'image':before,'compiler_artifact':item})
            assert len(artifacts)==2
            write(self.output/(mode+'-artifacts-upfront.json'),artifacts)
            ids=[]
            for index,artifact in enumerate(artifacts):
                result=self.command(f'{mode}-{index}-list',[artifact['retained'],'--list'],60)
                found=[line[:-6] for line in (result/'stdout').read_text().splitlines() if line.endswith(': test')]
                ids.extend(found)
                if artifact['compiler_artifact']['target']['kind']==['lib']: assert sorted(found)==self.expected
                else: assert found==[]
            assert len(ids)==len(set(ids))==187 and sorted(ids)==self.expected
            catalogs[mode]={'artifacts':artifacts,'ids':sorted(ids)}
        write(self.output/'compiled187.json',{'scope':'COLLECTION_ONLY_NOT_EXECUTION','logical_manifest':hash_file(HERE/'logical-after-manifest.json'),'catalogs':catalogs})

    def actors(self):
        compiled=outside(self.config['compiled_catalog_path'])
        assert hash_file(compiled)['sha256']==self.config['compiled_catalog_sha256']
        catalogs=load(compiled)
        assert set(catalogs)=={'scope','logical_manifest','catalogs'}
        assert catalogs['scope']=='COLLECTION_ONLY_NOT_EXECUTION'
        assert catalogs['logical_manifest']==hash_file(HERE/'logical-after-manifest.json')
        assert set(catalogs['catalogs'])==set(MODES)
        for mode,catalog in catalogs['catalogs'].items():
            assert set(catalog)=={'artifacts','ids'}
            assert len(catalog['ids'])==len(set(catalog['ids']))==187 and catalog['ids']==self.expected
            artifacts=catalog['artifacts'];assert len(artifacts)==2
            kinds=[row['compiler_artifact']['target']['kind'] for row in artifacts]
            assert kinds.count(['lib'])==1 and kinds.count(['bin'])==1
            for artifact in artifacts:
                item=artifact['compiler_artifact']
                assert item['reason']=='compiler-artifact' and item['profile']['test'] is True
                assert Path(item['manifest_path']).resolve()==(self.source/APP).resolve()
                assert hash_file(outside(artifact['retained']))==artifact['image']
        modes=self.config['actor_modes'];assert modes and len(modes)==len(set(modes)) and set(modes)<=set(MODES)
        for mode in modes:
            start=time.monotonic(); catalog=catalogs['catalogs'][mode]
            assert catalog['ids']==self.expected
            artifact=next(row for row in catalog['artifacts'] if row['compiler_artifact']['target']['kind']==['lib'])
            binary=outside(artifact['retained']);assert hash_file(binary)==artifact['image']
            for index,(identity,(name,acks)) in enumerate(CASES.items()):
                assert time.monotonic()-start<180, 'four-case mode deadline'
                ledger=self.output/f'{mode}-{index}-ledger.jsonl';ledger.touch(exist_ok=False)
                nonce=os.urandom(16).hex()
                env={'JAPP_W05_LEDGER':str(ledger),'JAPP_W05_NONCE':nonce,'JAPP_W05_RUNTIME':str(self.runtime/'japp-orchestrator/japp-orchestrator'),'JAPP_W05_FAULT_RUNTIME':str(self.fault/'japp-orchestrator/japp-orchestrator'),'JAPP_W05_FAULT_ROOT':str(self.fault),'JAPP_W05_RUNTIME_SHA256':'fc2293a3d6425093c03ada543249ccdc2050038613cf984b3983aada18032c7c'}
                folder=self.command(f'{mode}-{index}-selected-actor',[str(binary),'--exact',identity,'--nocapture','--test-threads=1'],min(55,180-(time.monotonic()-start)),env,actor=True)
                actual=re.findall(r'^test (.+) \.\.\. ok$',(folder/'stdout').read_text(),re.M)
                assert actual==[identity], actual
                events=[json.loads(line) for line in ledger.read_text().splitlines()]
                assert events and all(x['nonce']==nonce and x['case']==name for x in events)
                kinds=[x['event'] for x in events]
                assert kinds.count('case_start')==kinds.count('case_pass')==kinds.count('cleanup_verified')==1
                assert 'unwind_cleanup' not in kinds and kinds.count('ack_live_running')==acks
                spawned=[x['details'] for x in events if x['event']=='native_spawn']
                cleanup=next(x['details'] for x in events if x['event']=='cleanup_verified')
                assert [x['sequence'] for x in spawned]==list(range(1,len(spawned)+1))
                assert cleanup['actual_spawns']==len(spawned) and cleanup['lost_receipts']==0
                assert cleanup['all_observed_pids_groups_absent'] and cleanup['owned_slot_released']
                assert hash_file(binary)==artifact['image']
            assert time.monotonic()-start<180
        write(self.output/'selected-actors-closure.json',{'modes':modes,'actual_cases_per_mode':4,'collection_per_mode':187,'existing183_not_executed_by_this_stage':True,'same_runtime_source_bound':True,'unregistered_OS_descendants':'UNOBSERVED','scope':'headless same owner, no Wry/background/GUI/package acceptance'})

    def statics(self):
        for mode,features in MODES.items(): self.command('clippy-'+mode,[str(self.tools['cargo']),'clippy','--offline','--locked','--manifest-path',APP,'--all-targets',*features,'--','-D','warnings'],600)
        self.command('rustfmt-check',[str(self.tools['cargo']),'fmt','--manifest-path',APP,'--check'],60)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--config',required=True);parser.add_argument('--release',required=True)
    parser.add_argument('--stage',choices=['compile','actors','statics'],required=True)
    args=parser.parse_args();collector=Collector(args.config,args.release,args.stage)
    getattr(collector,args.stage)()

if __name__=='__main__': main()
