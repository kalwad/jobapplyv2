"""Outer receipt only; reviewed collector owns product fences and deadlines."""
import datetime
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
COLLECTOR = Path('/tmp/japp-m03-w05-actual-recovery-postformat-20261019/collect.py')

def image(path):
    path = Path(path).resolve()
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def write(path, value):
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')

label, stage, config_name, release_name = sys.argv[1:]
assert '/' not in label
folder = BASE / ('launch-' + label)
folder.mkdir()
argv = [sys.executable, str(COLLECTOR), '--config', str(BASE / config_name),
        '--release', str(BASE / release_name), '--stage', stage]
upfront = {'argv': argv, 'cwd': str(BASE), 'environment': dict(os.environ),
           'started_at': datetime.datetime.now(datetime.UTC).isoformat(),
           'python': image(sys.executable), 'launcher': image(__file__),
           'collector': image(COLLECTOR), 'config': image(BASE / config_name),
           'release': image(BASE / release_name),
           'scope': 'Outer Python launcher; product argv/env and owned cleanup are recorded by collector'}
write(folder / 'upfront.json', upfront)
code = None
failure = None
try:
    with (folder / 'stdout').open('xb') as stdout, (folder / 'stderr').open('xb') as stderr:
        child = subprocess.Popen(argv, cwd=BASE, env=dict(os.environ), stdout=stdout, stderr=stderr)
        write(folder / 'child.json', {'pid': child.pid, 'argv': argv})
        code = child.wait()
except BaseException as error:
    failure = {'type': type(error).__name__, 'message': str(error)}
finally:
    write(folder / 'result.json', {'ended_at': datetime.datetime.now(datetime.UTC).isoformat(),
          'exit_code': code, 'failure': failure, 'python_after': image(sys.executable),
          'launcher_after': image(__file__), 'collector_after': image(COLLECTOR),
          'stdout': image(folder / 'stdout'), 'stderr': image(folder / 'stderr')})
print(json.dumps({'label': label, 'exit_code': code, 'failure': failure}), flush=True)
sys.exit(code if code is not None else 1)
