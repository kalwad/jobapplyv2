"""Post-terminal author data receipt and finite archive; never invokes product code."""
import datetime
import hashlib
import json
import os
import shutil
import tarfile
from pathlib import Path

RUN = Path(__file__).resolve().parent
PACKET = Path('/tmp/japp-m03-w05-actual-recovery-postformat-v2-20261019')
OUT = Path('/tmp/japp-m03-w05-actual-recovery-execution-20261019-retained')
MODES = ('default', 'all-features', 'sdk-custom')

def load(path): return json.loads(path.read_text())
def image(path):
    assert path.is_file() and not path.is_symlink(), path
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1024 * 1024): digest.update(block)
    return {'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}
def write(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')

assert not OUT.exists()
launches = ('compile-v2', 'statics-v1', 'actors-default-v1', 'actors-features-v1')
for name in launches:
    result = load(RUN / ('launch-' + name) / 'result.json')
    assert result['exit_code'] == 0 and result['failure'] is None, name
catalog = load(RUN / 'evidence-compile-v2/compiled187.json')
assert set(catalog['catalogs']) == set(MODES)
binary_rows = []
for mode in MODES:
    row = catalog['catalogs'][mode]
    assert len(row['ids']) == len(set(row['ids'])) == 187
    for item in row['artifacts']:
        path = Path(item['retained'])
        assert image(path) == item['image'] and path.stat().st_mode & 0o777 == 0o555
        binary_rows.append({'mode': mode, 'path': str(path), **item['image'],
                            'mode_octal': oct(path.stat().st_mode & 0o7777),
                            'compiler_artifact': item['compiler_artifact']})
assert len(binary_rows) == 6

commands = []
stages = ('evidence-compile-v2', 'evidence-statics-v1',
          'evidence-actors-default-v1', 'evidence-actors-features-v1')
for stage in stages:
    for path in sorted((RUN / stage).glob('*/result.json')):
        result = load(path); upfront = load(path.parent / 'upfront.json')
        assert result['exit_code'] == 0 and result['failure'] is None
        assert result['source_unchanged'] and result['runtime_unchanged']
        assert result['cleanup']['owned_group'] == 'GONE'
        assert result['tool_after'] == upfront['tool_before']
        assert result['toolchain_after'] == upfront['toolchain_before']
        assert result['collector_after'] == upfront['collector']
        if upfront['actor']:
            assert result['service_read_only_observation']['all_absent']
        commands.append({'path': path.relative_to(RUN).as_posix(), **image(path),
                         'actor': upfront['actor'], 'started_at': upfront['started_at'],
                         'ended_at': result['ended_at']})
assert len(commands) == 27 and sum(row['actor'] for row in commands) == 12
cases = []
for stage in stages[2:]:
    for ledger in sorted((RUN / stage).glob('*-ledger.jsonl')):
        events = [json.loads(line) for line in ledger.read_text().splitlines()]
        kinds = [row['event'] for row in events]
        assert all(kinds.count(name) == 1 for name in ('case_start', 'case_pass', 'cleanup_verified'))
        assert 'unwind_cleanup' not in kinds
        clean = next(row['details'] for row in events if row['event'] == 'cleanup_verified')
        spawned = [row['details'] for row in events if row['event'] == 'native_spawn']
        assert clean['actual_spawns'] == len(spawned) and clean['lost_receipts'] == 0
        assert clean['all_observed_pids_groups_absent'] and clean['owned_slot_released']
        cases.append({'ledger': ledger.relative_to(RUN).as_posix(), **image(ledger),
                      'case': events[0]['case'], 'case_pass': events[-1]['details'],
                      'actual_native_spawns': spawned, 'cleanup': clean,
                      'ack_live_running': kinds.count('ack_live_running'),
                      'fault_runtime_restored': any(row['event'] == 'owned_runtime_restored' and row['details']['entrypoint_hash_matches'] for row in events)})
assert len(cases) == 12

logical = load(PACKET / 'logical-after-manifest.json')
assert len(logical) == 1851
for rel, expected in logical.items(): assert image(RUN / 'source' / rel) == expected, rel
app = load(RUN / 'provenance/runtime-applicability.json')
runtime_final = {}
for name in ('current-runtime', 'fault-runtime'):
    root = RUN / name
    actual = {p.relative_to(root).as_posix(): image(p) for p in sorted(root.rglob('*')) if p.is_file()}
    assert actual == app['runtime']
    runtime_final[name] = actual
source_digest = image(PACKET / 'logical-after-manifest.json')

OUT.mkdir()
payload = OUT / 'members'; payload.mkdir()
originals = {}
def copy(source, relative):
    assert not Path(relative).is_absolute() and '..' not in Path(relative).parts
    assert relative not in originals
    dest = payload / relative; dest.parent.mkdir(parents=True, exist_ok=True)
    before = image(source); shutil.copy2(source, dest); assert image(dest) == before
    originals[relative] = {'original': str(source.resolve()), **before}
def tree(source, prefix, omit=None):
    for path in sorted(source.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_file() and not (omit and omit(path)):
            copy(path, prefix + '/' + path.relative_to(source).as_posix())

tree(PACKET, 'source-review-packet')
for stage in stages:
    tree(RUN / stage, 'execution/' + stage,
         lambda path: path.parent == RUN / stage and '-binary-' in path.name)
for folder in sorted(RUN.glob('launch-*')):
    if folder.is_dir(): tree(folder, 'execution/' + folder.name)
tree(RUN / 'commands', 'setup/commands')
tree(RUN / 'provenance', 'setup/provenance')
for path in sorted(RUN.iterdir()):
    if path.is_file() and path.suffix in ('.json', '.py'):
        copy(path, 'execution-control/' + path.name)
initial = Path('/tmp/japp-m03-w05-actual-recovery-execution-20261019')
for path in sorted(initial.iterdir()):
    if path.is_file(): copy(path, 'initial-setup-refusal/' + path.name)
for rel in ('capabilities.json', 'acl-manifests.json', 'macOS-schema.json', 'desktop-schema.json'):
    path = RUN / 'quarantine-donor-artifacts/apps/desktop/src-tauri/gen/schemas' / rel
    copy(path, 'quarantined-generated-before/' + rel)
for name in ('japp-m03-w05-actual-recovery-postformat-independent-review-20261019',
             'japp-m03-w05-actual-recovery-setup-correction-independent-review-20261019',
             'japp-m03-w05-actual-recovery-setup-config-binding-review-20261019'):
    tree(Path('/tmp') / name, 'prior-independent-source-reviews/' + name)

write(payload / 'binary-images.json', {'physical_bytes_in_archive': False,
      'scope': 'Six retained images stay immutable at the exact paths below; this archive contains image bindings, not their executable bytes', 'files': binary_rows})
write(payload / 'runtime-final.json', runtime_final)
write(payload / 'summary.derived.json', {
    'status': 'AUTHOR_DERIVED_CLOSED_PASS_PENDING_INDEPENDENT_DATA_AUDIT',
    'closed_at': datetime.datetime.now(datetime.UTC).isoformat(),
    'source': {'base_1850_manifest': 'ee091e710086c6149d019c9ac58aed68f6b8b8dedee31b572dfabedba36f4f47', 'logical1851': source_digest,
               'overlay_manifest': image(PACKET / 'overlay-manifest.json'), 'collector': image(PACKET / 'collect.py')},
    'collection': {'modes': list(MODES), 'each_unique_ids': 187, 'retained_images': 6, 'not_execution': True},
    'statics': 'Three strict Clippy modes and cargo fmt --check, all exit0',
    'selected_execution': {'each_mode': 4, 'total': 12, 'existing183_not_executed_in_this_stage': True,
                           'native_spawn_receipts_total': sum(len(row['actual_native_spawns']) for row in cases), 'cases': cases},
    'commands': commands,
    'cleanup': 'All registered actual service PID/groups absent; acknowledged ports rebound; owned slots released; fault runtime restored; owned harness groups GONE',
    'unregistered_OS_descendants': 'UNOBSERVED',
    'limits': ['Headless actual private ManagedService/RestartOwner/Supervisor and real service process',
               'No Wry start_background/AppHandle/GUI actor', '24s test delays driving the real clock; not a stalled-startup or late-ACK test',
               'No editable unsaved-form recovery claim', 'No root/full/CI/platform/packaging/M03 completion credit',
               'Source equality is1851 logical inputs plus three separately bound auxiliaries; exact four generated outputs recorded separately',
               'Six binaries/runtime payload/venv/cache/full source and118 quarantined bytecode images remain outside this finite archive at retained paths; bindings and applicable raw maps are included'],
    'preparation_history': [
        'Initial systemPython3.9 setup wrapper refused datetime.UTC before first copy; exact initial source/receipt retained',
        'First collector launch refused unlisted copied bytecode before output/tool creation; exact raw launch receipts retained',
        'Inventory helper conservatively refused mixed122 types before moving anything; this is a derived transcript fact, not newly fabricated raw stdout',
        'Parent-authorized quarantine moved exactly118pyc+4generated schema outputs; no1851 logical input change',
        'Different reviewer cleared bounded collector correction and final bindings before corrected compile',
        'A statics-preparation Python path typo exited127 before product invocation; exact derived incident retained'],
    'product_actor_retries': 0, 'root_mutations': 0, 'original_copies': originals})

members = {path.relative_to(payload).as_posix(): image(path) for path in sorted(payload.rglob('*')) if path.is_file()}
write(payload / 'members.json', {'scope': 'Exact regular payload inventory, excludes this index itself', 'files': members})
members['members.json'] = image(payload / 'members.json')
archive = OUT / 'proof.tar.gz'
with tarfile.open(archive, 'w:gz') as bundle:
    for rel in sorted(members): bundle.add(payload / rel, arcname=rel, recursive=False)
seen = {}
with tarfile.open(archive, 'r:gz') as bundle:
    for item in bundle:
        assert item.isfile() and item.name not in seen and not Path(item.name).is_absolute() and '..' not in Path(item.name).parts
        raw = bundle.extractfile(item).read()
        actual = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
        assert actual == members[item.name]
        seen[item.name] = actual
assert seen == members
write(OUT / 'retention-manifest.json', {'archive': image(archive), 'safe_regular_members': len(members),
      'payload_bytes': sum(row['bytes'] for row in members.values()), 'files': members,
      'scope': 'Author-packaged finite raw/data proof; executable/runtime images omitted explicitly; independent actual-data audit still required'})
print(json.dumps({'archive': image(archive), 'members': len(members),
                  'manifest': image(OUT / 'retention-manifest.json'), 'raw_command_results': len(commands),
                  'selected_actor_cases': len(cases), 'native_spawns': sum(len(row['actual_native_spawns']) for row in cases)}))
