"""Released setup-only exact input copies/maps. No imports of product/test/provider."""
from pathlib import Path
import hashlib,json,os,subprocess,time,datetime
B=Path(__file__).resolve().parent
P=Path('/tmp/japp-m03-w05-actual-recovery-postformat-20261019')
A=Path('/tmp/japp-m03-w04-current-app-build-preparation-20261019/runtime-applicability.json')
S=B/'source'
def bind(path):
 path=Path(path);digest=hashlib.sha256()
 with path.open('rb')as stream:
  while block:=stream.read(1024*1024):digest.update(block)
 return {'bytes':path.stat().st_size,'sha256':digest.hexdigest()}
def write(path,value):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);assert not path.exists(),path
 path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def tree(root):
 result={}
 for path in sorted(root.rglob('*')):
  name=path.relative_to(root).as_posix()
  if path.is_symlink():
   resolved=path.resolve();assert resolved.is_file()
   result[name]={'symlink':os.readlink(path),'resolved':str(resolved),'resolved_image':bind(resolved)}
  elif path.is_file():result[name]=bind(path)
 return result
env=dict(json.loads((B/'format-inputs-upfront.json').read_text())['environment'])
data=json.loads(A.read_text());assert len(data['source_inputs'])==135 and len(data['runtime'])==40
assert {rel:bind(S/rel)for rel in data['source_inputs']}==data['source_inputs']
assert tree(B/'current-runtime')==tree(B/'fault-runtime')==tree(S/'apps/desktop/src-tauri/runtime-payload')==data['runtime']
write(B/'setup-135-runtime40-verified.json',{'source135':data['source_inputs'],'runtime40':data['runtime'],'actor_and_fault_and_compile_runtime_equal':True,'new_Python_build':False,'source':str(S),'metadata_origin':str(A),'metadata_image':bind(A)})
paths={};(B/'provenance/wheels').mkdir(parents=True)
cp=Path('/bin/cp');assert cp.is_file()
for name,row in data['wheels'].items():paths[name]=(Path(row['resolved']),B/'provenance/wheels'/name,row)
for name,row in data['additional_requirements'].items():paths[name]=(Path(row['retained_build_input']['resolved']),B/'provenance'/(name+'.txt'),row['retained_build_input'])
for name,(original,target,row)in paths.items():
 assert bind(original)=={k:row[k]for k in ['bytes','sha256']}
 argv=[str(cp),'-c',str(original),str(target)]
 record={'argv':argv,'cwd':str(B),'environment':dict(env),'tool_before':bind(cp),'source_before':bind(original),'wrapper':bind(__file__),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 write(B/'provenance'/('copy-'+name+'-upfront.json'),record)
 done=subprocess.run(argv,cwd=B,env=dict(env),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
 (B/'provenance'/('copy-'+name+'.stdout')).write_bytes(done.stdout);(B/'provenance'/('copy-'+name+'.stderr')).write_bytes(done.stderr)
 write(B/'provenance'/('copy-'+name+'-result.json'),{'exit_code':done.returncode,'target':bind(target),'source_after':bind(original),'tool_after':bind(cp)})
 assert done.returncode==0 and bind(target)==bind(original)==record['source_before']and bind(cp)==record['tool_before']
(B/'provenance/runtime-applicability.json').write_bytes(A.read_bytes())
aux={}
for role,root in {'frontend_dist':S/'apps/desktop/dist','compile_runtime_payload':S/'apps/desktop/src-tauri/runtime-payload','python_environment':S/'.venv'}.items():
 manifest=B/'provenance'/(role+'-manifest.json');write(manifest,tree(root))
 aux[role]={'root':str(root),'manifest_path':str(manifest),'manifest_sha256':bind(manifest)['sha256']}
rust=Path('/Users/tanishkalwad/.rustup/toolchains/1.97.1-aarch64-apple-darwin/bin')
config={'status':'PREPARED_NOT_INVOKED_WAIT_ROOT_COMPILE_RELEASE','independent_review_path':'/tmp/japp-m03-w05-actual-recovery-postformat-independent-review-20261019/independent-review.json','source_dir':str(S),'output_dir':str(B/'evidence-compile-v1'),'runtime_dir':str(B/'current-runtime'),'fault_runtime_dir':str(B/'fault-runtime'),'cargo_target_dir':str(B/'cargo-target'),'environment':dict(env),'tool_images':{name:{'path':str(rust/name),**bind(rust/name)}for name in ['cargo','rustc']},'runtime_applicability_path':str(B/'provenance/runtime-applicability.json'),'runtime_applicability_sha256':bind(A)['sha256'],'wheel_paths':{name:str(target)for name,(original,target,row)in paths.items()if name in data['wheels']},'requirement_paths':{name:str(target)for name,(original,target,row)in paths.items()if name in data['additional_requirements']},'auxiliary_directories':aux,'compiled_catalog_path':str(B/'evidence-compile-v1/compiled187.json'),'compiled_catalog_sha256':None,'actor_modes':['default']}
write(B/'config-compile.pending-review.json',config)
write(B/'setup-inputs-closed.json',{'closed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'setup_only':True,'source1851_manifest':bind(P/'logical-after-manifest.json'),'overlay5':bind(P/'overlay-manifest.json'),'collector':bind(P/'collect.py'),'config':bind(B/'config-compile.pending-review.json'),'135_runtime40_actual_verified':True,'two_wheels_two_requirements_COW_exact':True,'compiler_actor_test_imports':False,'peer_path_pending_until_peer_supplies_actual_record':True})
print(json.dumps({'setup_closed':bind(B/'setup-inputs-closed.json'),'pending_config':bind(B/'config-compile.pending-review.json')},sort_keys=True))
