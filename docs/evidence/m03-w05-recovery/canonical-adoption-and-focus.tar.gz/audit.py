import datetime as dt,hashlib,json,pathlib,re,subprocess,os
OUT=pathlib.Path('/tmp/japp-m03-w05-adoption-independent-review-20261019');REPO=pathlib.Path('/Users/tanishkalwad/jobapplyv2')
def load(name):return json.loads((OUT/name).read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()
def save(name,value):
 p=OUT/name;assert not p.exists();p.write_text(json.dumps(value,indent=2)+'\n')
def small(row):return {k:row[k] for k in ['bytes','sha256']}
adoption=load('receipts/adoption.json');before=load('receipts/source-before.json');after=load('receipts/source-after.json');source=load('reviewed-source/source-manifest.json');binding=load('input-provenance.json')
assert len(before['files'])==1894 and len(after['files'])==1895 and before['head']==after['head']==adoption['root_base_head']=='5b9396c0d9487738da66eb3f80b9c676c357e727'
assert before['tree']==after['tree']==adoption['root_base_tree']=='4aafa97e5a7f03f8e4fa3de9f264af5ceed907d1'
changed={n for n in set(before['files'])|set(after['files']) if before['files'].get(n)!=after['files'].get(n)};assert changed==set(adoption['exact_changed_nine']) and len(changed)==9
others=set(before['files'])-changed;assert len(others)==1886 and all(before['files'][n]==after['files'][n] for n in others)
for row in binding['actual_nine']:
 name=row['path'];raw=(OUT/'actual-nine'/name).read_bytes();assert {'bytes':len(raw),'sha256':sha(raw)}==small(after['files'][name])==source[name]
 if row['new_file']:assert name not in before['files']
 else:
  raw=(OUT/'base-nine'/name).read_bytes();assert {'bytes':len(raw),'sha256':sha(raw)}==small(before['files'][name])
focused_before=load('focused/source-before.json');focused_after=load('focused/source-after.json');assert len(focused_before)==1895 and focused_before==focused_after
assert {n:small(v) for n,v in after['files'].items()}==focused_before
reuse=load('receipts/runtime135-and-staged40-unchanged.json');assert len(reuse['source_inputs'])==135 and len(reuse['runtime'])==40
for name,entry in reuse['source_inputs'].items():assert small(before['files'][name])==small(after['files'][name])==entry==source[name]
assert load('focused/runtime-before.json')==load('focused/runtime-after.json')==reuse['runtime']
result=load('focused/result.json');upfront=load('focused/upfront.json');closure=load('focused/closure.json')
assert all(result[k]==v for k,v in upfront.items()) and result['exit_code']==closure['exit_code']==0
assert result['argv']==['pnpm','verify','--suite','rust'] and 'RUST_TEST_THREADS' not in result['environment'] and result['environment']['CARGO_BUILD_JOBS']=='2'
log_raw=(OUT/'focused/rust.log').read_bytes();assert len(log_raw)==result['log_bytes'] and sha(log_raw)==result['log_sha256']
assert sha((OUT/'focused/executed-wrapper.py').read_bytes())==result['wrapper_sha256']
entries={}
for item in (OUT/'git/immutable-base-tree.stdout').read_bytes().split(b'\0'):
 if item:
  meta,name=item.split(b'\t');mode,kind,oid=meta.decode().split();entries[name.decode()]=oid
argv=['git','cat-file','blob',entries['scripts/verification-suites.json']];p=subprocess.run(argv,cwd=REPO,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'},stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
assert p.returncode==0;(OUT/'git/registry.stdout').write_bytes(p.stdout);(OUT/'git/registry.stderr').write_bytes(p.stderr)
save('git/registry.json',{'argv':argv,'cwd':str(REPO),'exit_code':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr),'scope':'Immutable base registry Git object only; no other live working path read.'})
assert {'bytes':len(p.stdout),'sha256':sha(p.stdout)}==small(before['files']['scripts/verification-suites.json'])
registry=json.loads(p.stdout);commands=next(s['commands'] for s in registry['suites'] if s['id']=='rust');assert len(commands)==15
log=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',log_raw.decode());headers=re.findall(r'^\$ (.+)$',log,re.M);expected=[' '.join(c) for c in commands]
assert [h for h in headers if h in expected]==expected and 'rust           ACTIVE               PASS' in log and 'verification exit code: 0' in log
native=[c for c in commands if c[:2]==['cargo','test'] and 'apps/desktop/src-tauri/Cargo.toml' in c];assert len(native)==3
preservation=load('reviewed-source/test-body-preservation.json');ids=preservation['expected_native_ids'];assert len(ids)==len(set(ids))==183
observed=[]
for command in native:
 marker='$ '+' '.join(command);start=log.index(marker+'\n')+len(marker);end=log.find('\n$ ',start);end=len(log) if end<0 else end;block=log[start:end]
 names=re.findall(r'^test (\S+) \.\.\. ok$',block,re.M);counts=re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',block,re.M)
 assert sorted(names)==sorted(ids) and [tuple(int(v) for v in row) for row in counts]==[(183,0,0,0,0),(0,0,0,0,0),(0,0,0,0,0)]
 observed.append({'argv':command,'passed':183,'main_and_doc_passed':0,'zero_failed_ignored_measured_filtered':True,'ordinary_parallel':'No test-thread override in actual argv or controlled environment.'})
assert all(preservation[k] for k in ['actual183_bodies_equal_approved_inventory','all180_reviewed_bodies_preserved','old176_and_review4_preserved','currentHTTP3_preserved','current_shared134_exact'])
assert len(preservation['one_already_reviewed_strengthening'])==1 and preservation['method'].startswith('Retained lexical balanced-body map')
policy=(OUT/'actual-nine/apps/desktop/src-tauri/src/service/restart.rs').read_text();tauri=(OUT/'actual-nine/apps/desktop/src-tauri/src/service/tauri_lifecycle.rs').read_text();owner=(OUT/'actual-nine/apps/desktop/src-tauri/src/diagnostics/owner.rs').read_text()
assert 'automatic_relaunch_limit: 2' in policy and 'cycle_budget: Duration::from_secs(24)' in policy and 'backoffs: [Duration::from_millis(250), Duration::from_secs(1)]' in policy
assert 'type NativeSupervisor = RestartOwner<ConfiguredRuntime, MonotonicClock>' in tauri and '.compare_exchange(false, true, Ordering::AcqRel, Ordering::Acquire)' in tauri
assert 'self.0.client_session()' in owner and 'Arc::new(OwnerSource(owner))' in owner
report={'result':'CLEAR_FOR_EXACT_NINE_PATH_ADOPTION_AND_CLOSED_FOCUSED_RUST_ONLY','immutable_base_head':adoption['root_base_head'],'immutable_base_tree':adoption['root_base_tree'],'actual_authorized_root_paths_read':9,'actual_postimages_match_reviewed_1850_ee091':True,'recorded_source_before_paths':1894,'recorded_source_after_paths':1895,'other1886_recorded_entries_unchanged':True,'one_added_file':'apps/desktop/src-tauri/src/service/restart.rs','eight_modified_files':8,'source_policies_registry_contracts_and_bounds_outside_nine_changed':False,'test_body_preservation':{'method':preservation['method'],'reviewed180_and_HTTP3_apply_to_identical_actual_nine_bytes':True,'current_W04_137_exact_plus_one_reviewed_strengthening':True},'closed_focused_verification':{'argv':result['argv'],'exit_code':0,'elapsed_seconds':result['elapsed_seconds'],'source1895_before_after_equal':True,'runtime40_before_after_equal':True,'registry_commands_exact':15,'native_modes':observed,'final_native_build_and_Rust_suite_PASS':True,'whole20_PASS_claim':False},'shipping_authority_scope':'Single existing ManagedService owns one RestartOwner<ConfiguredRuntime,MonotonicClock>; worker claim coalesces startup/observation/recovery/cleanup. Diagnostics use the same owner client_session and exact authority epoch/Arc; no separate restart owner added to action code. Reviewed two lifetime relaunches,250ms/1s backoffs,24s cycle and cleanup reserve checks remain exact ee091 source.','limits':['Read only nine authorized root working paths plus immutable base objects; no whole-root neutrality or ongoing root freeze.','Recorded other1886 and135 Python preservation is data-map equality, not a new live scan of those root paths.','Real four-case recovery actor proof remains a separate prerequisite; no real187/GUI/CI/W05 VERIFIED or milestone acceptance credit.','Integration order explicitly permits implementation and focused checks first while retaining real-four, independent review and current clean full before W05 verification.','Existing98e/35f/663e semantic review is not replaced or relabeled by this bounded adoption/source/data review.']}
save('review.json',report);print(json.dumps({k:v for k,v in report.items() if k not in ['limits','shipping_authority_scope']},indent=2))
