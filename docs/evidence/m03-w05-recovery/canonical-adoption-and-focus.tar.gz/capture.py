import datetime as dt,hashlib,json,os,pathlib,subprocess,time
OUT=pathlib.Path('/tmp/japp-m03-w05-adoption-independent-review-20261019');ROOT=pathlib.Path('/Users/tanishkalwad/jobapplyv2');A=pathlib.Path('/tmp/japp-m03-w05-canonical-adoption-20261019');JOIN=pathlib.Path('/tmp/japp-m03-w05-current-source-join-20261019')
BASE='5b9396c0d9487738da66eb3f80b9c676c357e727'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,b):p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b)
def save(name,obj):write(OUT/name,(json.dumps(obj,indent=2)+'\n').encode())
def read(p):
 before=p.stat();b=p.read_bytes();after=p.stat();assert (before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns)
 return b
def git(args,label):
 argv=['git',*args];env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'};started=dt.datetime.now(dt.timezone.utc).isoformat();p=subprocess.run(argv,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
 write(OUT/'git'/(label+'.stdout'),p.stdout);write(OUT/'git'/(label+'.stderr'),p.stderr);save('git/'+label+'.json',{'argv':argv,'cwd':str(ROOT),'started_utc':started,'exit_code':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr),'scope':'Explicit immutable base Git object only; no status/current-HEAD scan, index mutation or source write.'});assert p.returncode==0
 return p.stdout
files=[]
for name in ['adoption.json','checked-nine-preimages.json','integration-order.json','runtime135-and-staged40-unchanged.json','source-before.json','source-after.json']:
 b=read(A/name);write(OUT/'receipts'/name,b);files.append({'original':str(A/name),'retained':'receipts/'+name,'bytes':len(b),'sha256':sha(b)})
for p in sorted((A/'focused').iterdir()):
 assert p.is_file() and not p.is_symlink();b=read(p);write(OUT/'focused'/p.name,b);files.append({'original':str(p),'retained':'focused/'+p.name,'bytes':len(b),'sha256':sha(b)})
for name in ['source-manifest.json','test-body-preservation.json','canonical-adoption-projection.json','SOURCE_REPORT.json']:
 b=read(JOIN/name);write(OUT/'reviewed-source'/name,b);files.append({'original':str(JOIN/name),'retained':'reviewed-source/'+name,'bytes':len(b),'sha256':sha(b)})
base=git(['cat-file','-p',BASE],'immutable-base-commit').decode();assert base.startswith('tree 4aafa97e5a7f03f8e4fa3de9f264af5ceed907d1\n')
tree=git(['ls-tree','-rz','--full-tree',BASE],'immutable-base-tree');entries={}
for item in tree.split(b'\0'):
 if not item:continue
 meta,name=item.split(b'\t');mode,kind,oid=meta.decode().split();assert kind=='blob';entries[name.decode()]={'mode':mode,'blob':oid}
assert len(entries)==1894
adoption=json.loads((OUT/'receipts/adoption.json').read_bytes());source=json.loads((OUT/'reviewed-source/source-manifest.json').read_bytes());assert len(source)==1850
rows=[]
for i,row in enumerate(json.loads((OUT/'receipts/checked-nine-preimages.json').read_bytes()),1):
 name=row['path'];actual=read(ROOT/name);assert {'bytes':len(actual),'sha256':sha(actual)}==row['postimage']==source[name]
 assert read(JOIN/'source'/name)==actual
 write(OUT/'actual-nine'/name,actual)
 if row['required_preimage'] is None:assert name not in entries;pre=None
 else:
  pre=git(['cat-file','blob',entries[name]['blob']],f'preimage-{i:02d}')
  assert {'bytes':len(pre),'sha256':sha(pre)}==row['canonical_observed_preimage']==row['required_preimage']
  write(OUT/'base-nine'/name,pre)
 rows.append({'path':name,'actual_bytes':len(actual),'actual_sha256':sha(actual),'base_blob':entries.get(name),'new_file':pre is None})
assert len(rows)==9 and set(r['path'] for r in rows)==set(adoption['exact_changed_nine'])
save('input-provenance.json',{'files':files,'actual_nine':rows,'scope':'Nine explicitly authorized current root paths plus immutable5b base objects and closed outside receipts. No whole-root working-tree hash/status/HEAD stability claim; remoteCI binding remains independent.'})
print(json.dumps({'actual_nine_match_reviewed1850':True,'base1894_metadata_entries':len(entries),'closed_focused_files':len(list((A/'focused').iterdir())),'no_root_writes_or_other_root_working_paths_read':True},indent=2))
