import datetime as dt,gzip,hashlib,io,json,os,pathlib,stat,tarfile
ROOT=pathlib.Path('/tmp/japp-m03-w05-adoption-independent-review-20261019');OUT=pathlib.Path(str(ROOT)+'-retained')
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):
 before=p.lstat();assert stat.S_ISREG(before.st_mode);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  chunks=[]
  while True:
   b=os.read(fd,1048576)
   if not b:break
   chunks.append(b)
  after=os.fstat(fd)
 finally:os.close(fd)
 last=p.lstat();key=lambda s:(s.st_ino,s.st_dev,s.st_size,s.st_mtime_ns,s.st_ctime_ns);assert key(before)==key(after)==key(last)
 return b''.join(chunks)
assert json.loads(read(ROOT/'review.json'))['result']=='CLEAR_FOR_EXACT_NINE_PATH_ADOPTION_AND_CLOSED_FOCUSED_RUST_ONLY'
rows=[]
for p in sorted(ROOT.rglob('*')):
 assert not p.is_symlink()
 if not p.is_file():continue
 name=p.relative_to(ROOT).as_posix()
 if '__pycache__' in pathlib.PurePosixPath(name).parts or name=='evidence-inputs.json':continue
 raw=read(p);rows.append({'path':name,'bytes':len(raw),'sha256':sha(raw)})
manifest={'files':rows,'file_count':len(rows),'scope':'Exact nine authorized current root postimages/immutable5b base preimages/closed focused183x3 default parallel Rust data and bounded adoption review. No whole-root scan/freeze, real187, GUI, hostedCI/full20/W05VERIFIED or milestone credit.'}
mb=(json.dumps(manifest,indent=2)+'\n').encode();target=ROOT/'evidence-inputs.json';assert not target.exists();target.write_bytes(mb)
entries=rows+[{'path':'evidence-inputs.json','bytes':len(mb),'sha256':sha(mb)}];assert not OUT.exists();OUT.mkdir();archive=OUT/'proof.tar.gz'
with archive.open('wb') as f:
 with gzip.GzipFile(fileobj=f,filename='',mode='wb',mtime=0,compresslevel=6) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for row in entries:
    raw=read(ROOT/row['path']);assert len(raw)==row['bytes'] and sha(raw)==row['sha256'];info=tarfile.TarInfo(row['path']);info.size=len(raw);info.mode=0o644;info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;tar.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(entries)==len({m.name for m in members})
 for member,row in zip(members,entries):
  assert member.isfile() and member.name==row['path'];raw=tar.extractfile(member).read();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
for row in entries:
 raw=read(ROOT/row['path']);assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
raw=read(archive);value={'archive':'proof.tar.gz','bytes':len(raw),'sha256':sha(raw),'regular_members':len(entries),'input_manifest_sha256':sha(mb),'created_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'result':'CLEAR_FOR_EXACT_NINE_PATH_ADOPTION_AND_CLOSED_FOCUSED_RUST_ONLY','scope':manifest['scope']}
(OUT/'manifest.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value,indent=2))
