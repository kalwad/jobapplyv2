"""Independent correction closure: read/hash/lexical/data only, no subject execution."""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import hashlib,json,re,subprocess,tarfile
B=Path('/tmp/japp-m03-w05-current-owner-review-correction-20261019')
F=Path('/tmp/japp-m03-w05-current-owner-recovery-preparation-20261019')
V=Path('/tmp/japp-m03-w05-independent-current-owner-recovery-review-20261019')
S=B/'source';R=Path('/Users/tanishkalwad/jobapplyv2');O=Path(__file__).resolve().parent
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1048576),b''):h.update(c)
 return h.hexdigest()
def load(p):return json.loads(p.read_text())
def safe(n):
 p=PurePosixPath(n);assert n and not p.is_absolute() and '..' not in p.parts and str(p)==n,n
 return n
def verify(p,row):assert p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],p
def state():return {n:subprocess.check_output(['git',*args],cwd=R).decode().strip() for n,args in [('head',['rev-parse','HEAD']),('tree',['rev-parse','HEAD^{tree}']),('status',['status','--porcelain=v1','--untracked-files=all'])]}
root_before=state();checks=[]
def clear(name,detail):checks.append({'check':name,'status':'CLEAR','detail':detail})
pins={'HANDOFF.md':'518483e24382b6e5d50f22edf4766faa617f057f02577d8307dfcb962cdbce21','source-manifest.json':'98e25bfeef7c85890e84b54938eed476818702cd52b85d81ac83081df80e7eb5','review-correction.patch':'f41aaa6e80ec776792196a73ad0d370f6199ace0b1cc93a110a13d1cc392c20b','retention-manifest.json':'63b80481d86939c73fc564e9837c0305666aa9926edbe84142993cda9c424935','correction-delta.tar.gz':'2141d6784c1844253c35d2ee7e4adc19d01fe89fe2dd50d752b8be55b8c1d593','preservation.json':'cc36bf0be4f3151c8eacc5887628916cf6af921df6b7863960d09b81bc643da6'}
for n,h in pins.items():assert sha(B/n)==h,n
ret=load(B/'retention-manifest.json');assert ret['file_count']==len(ret['files'])==1936
assert len({r['path'] for r in ret['files']})==1936
for row in ret['files']:verify(B/safe(row['path']),row)
assert sha(F/'source-manifest.json')=='3a0ffaf3d47d69b3e6bb201b687e7d15a1ea7a153f4f63aa3127c0565e983787'
assert sha(F/'retention-manifest.json')=='2b255bc55e63eaf18568f331571addf2f9a7a060e22f6be2d109f6753ca3fff1'
oldret=load(F/'retention-manifest.json')['files'];assert len(oldret)==1992
for row in oldret:verify(F/safe(row['path']),row)
bind=load(B/'input-binding.json')
for n,h in bind['review_pins'].items():assert sha(V/n)==h,n
rows=load(B/'source-manifest.json');base=load(F/'source-manifest.json');assert len(rows)==len(base)==1848 and set(rows)==set(base)
for n,row in rows.items():verify(S/safe(n),row)
for n,row in base.items():verify(F/'source'/n,row)
clear('current_and_immutable_evidence',{'new_retained_files':1936,'original_retained_files':1992,'source_files_each':1848,'original_review_pins_exact':True,'pins':pins})

changed={n for n in rows if rows[n]!=base[n]};expected={'apps/desktop/src-tauri/src/service/'+n for n in ['authority_hub.rs','restart.rs','tauri_lifecycle.rs']}
assert changed==expected
delta=load(B/'delta-manifest.json');assert {r['path'] for r in delta['files']}==changed
for r in delta['files']:assert r['before']==base[r['path']] and r['after']==rows[r['path']];verify(B/'preimages'/r['path'],r['before']);verify(B/'delta'/r['path'],r['after'])
lines=(B/'review-correction.patch').read_text().splitlines(keepends=True);i=0;reconstructed={}
while i<len(lines):
 m=re.fullmatch(r'diff --git a/(.+) b/(.+)\n',lines[i]);assert m and m[1]==m[2];n=safe(m[1]);i+=1
 assert lines[i]=='--- a/'+n+'\n' and lines[i+1]=='+++ b/'+n+'\n';i+=2
 old=(F/'source'/n).read_text().splitlines(keepends=True);cursor=0;new=[]
 while i<len(lines) and not lines[i].startswith('diff --git '):
  h=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n',lines[i]);assert h
  cnt=int(h[2] or 1);start=int(h[1])-(1 if cnt else 0);assert start>=cursor;new.extend(old[cursor:start]);cursor=start;i+=1;oldcnt=newcnt=0
  while i<len(lines) and not lines[i].startswith(('@@ ','diff --git ')):
   l=lines[i];assert l[0] in ' +-'
   if l[0] in ' -':assert old[cursor]==l[1:];cursor+=1;oldcnt+=1
   if l[0] in ' +':new.append(l[1:]);newcnt+=1
   i+=1
  assert oldcnt==cnt and newcnt==int(h[4] or 1)
 new.extend(old[cursor:]);reconstructed[n]=''.join(new).encode()
assert set(reconstructed)==changed
for n,data in reconstructed.items():assert data==(S/n).read_bytes()
with tarfile.open(B/'correction-delta.tar.gz','r:gz') as tf:
 members=tf.getmembers();assert len(members)==len({m.name for m in members})
 for m in members:
  safe(m.name);assert m.isfile() and not m.issym() and not m.islnk()
  p=S/m.name[7:] if m.name.startswith('source/') else B/m.name
  assert tf.extractfile(m).read()==p.read_bytes(),m.name
clear('minimal_patch_and_archive',{'modified_files':3,'added_or_deleted':0,'other_paths_exact':1845,'safe_archive_members':len(members)})

tok=re.compile(r'//[^\n]*|/\*.*?\*/|(?:br|r)(?P<h>\#*)".*?"(?P=h)|b?"(?:\\.|[^"\\])*"|b?\'(?:\\.|[^\'\\])\'|[{}]',re.S)
def endbrace(text,start):
 depth=0
 for m in tok.finditer(text,start):
  if m.group()=='{':depth+=1
  elif m.group()=='}':
   depth-=1
   if depth==0:return m.end()
 raise AssertionError('Unclosed body')
def bodies(raw):
 text=raw.decode();out={}
 for m in re.finditer(r'#\[(?:test|tokio::test(?:\([^\n]*\))?)\]\s*(?:async\s+)?fn\s+(\w+)\s*\(',text):
  start=text.index('{',m.end());assert m[1] not in out;out[m[1]]=text[start:endbrace(text,start)]
 return out
def function(text,name):
 m=re.search(r'\bfn '+name+r'\b',text);assert m;start=text.index('{',m.end());return text[start:endbrace(text,start)]
pres=load(B/'preservation.json');count=0
for n in base:
 if not n.startswith('apps/desktop/src-tauri/') or not n.endswith('.rs'):continue
 old=bodies((F/'source'/n).read_bytes());new=bodies((S/n).read_bytes())
 for name,body in old.items():assert new.get(name)==body,(n,name);count+=1
assert count==176
redcount=0
for filename in ['authority_hub.rs','restart.rs','tauri_lifecycle.rs']:
 red=bodies((B/'red-02'/filename).read_bytes());green=bodies((S/'apps/desktop/src-tauri/src/service'/filename).read_bytes())
 for name,body in red.items():
  if name in pres['new4_RED_test_bodies_byte_exact']:assert green.get(name)==body,name;redcount+=1
assert redcount==4
oldrestart=(F/'source/apps/desktop/src-tauri/src/service/restart.rs').read_text();newrestart=(S/'apps/desktop/src-tauri/src/service/restart.rs').read_text()
assert oldrestart.split('#[cfg(test)]')[0]==newrestart.split('#[cfg(test)]')[0]
tauriold=(F/'source/apps/desktop/src-tauri/src/service/tauri_lifecycle.rs').read_text();taurinew=(S/'apps/desktop/src-tauri/src/service/tauri_lifecycle.rs').read_text()
for name in ['spawn_claimed_worker','try_owner','request_shutdown','publish_background','claim_worker','diagnostic','start_background','allow_exit','on_exit_requested']:
 assert function(tauriold,name)==function(taurinew,name),name
oldhub=(F/'source/apps/desktop/src-tauri/src/service/authority_hub.rs').read_text();newhub=(S/'apps/desktop/src-tauri/src/service/authority_hub.rs').read_text()
for name in ['advance_epoch','close','publish','publish_with_hook','current_epoch','cancellation_handle']:
 assert function(oldhub,name)==function(newhub,name),name
withdraw=function(newhub,'withdraw_current_with_hook')
assert withdraw.index('current.store(false, Ordering::Release)')<withdraw.index('self.current.store(None)')<withdraw.index('after_remove()')<withdraw.index('self.advance_epoch()')
assert function(newhub,'withdraw_current').strip()=='{\n        self.withdraw_current_with_hook(|| {});\n    }'
clear('preservation_and_shipping_helper_scope',{'all_old_test_bodies_exact':176,'new_RED_to_GREEN_bodies_exact':4,'actual_restart_production_and_numeric_bounds_exact':True,'actual_worker_and_command_boundary_exact':True,'close_publication_permanent_cancel_epoch_overflow_methods_exact':True,'new_order':'invalidate reachable issued flag, remove slot, hook, checked epoch'})

records=[]
for p in sorted((B/'checks').iterdir()):
 r=load(p/'receipt.json');a=load(p/'source-before.json');z=load(p/'source-after.json')
 assert sha(p/'output.log')==r['log_sha256'] and r['source_unchanged'] and a==z
 assert r['executable_sha256_before']==r['executable_sha256_after'] and r['root_writes'] is False and r['actors'] is False
 assert r['cwd']==str(S.resolve()) and r['logical_source_files']==1848
 assert datetime.fromisoformat(r['ended_utc'])>=datetime.fromisoformat(r['started_utc']) and r['elapsed_seconds']>=0
 if int(p.name[:2])>=3:assert a==rows and r['exit_code']==0,p.name
 records.append({'label':p.name,'exit_code':r['exit_code'],'argv':r['argv'],'source_manifest_sha256':sha(p/'source-before.json')})
assert len(records)==10
red=(B/'checks/02-review-counterproof-red/output.log').read_text();green=(B/'checks/04-review-counterproof-green/output.log').read_text()
assert '1 passed; 3 failed; 0 ignored; 0 measured; 176 filtered out' in red
assert '4 passed; 0 failed; 0 ignored; 0 measured; 176 filtered out' in green
rednames=set(re.findall(r'^test (\S+) \.\.\.',red,re.M));greennames=set(re.findall(r'^test (\S+) \.\.\. ok$',green,re.M));assert len(rednames)==4 and rednames==greennames
lists=[]
for label in ['03-corrected-default-collection','05-corrected-allfeatures-collection','06-corrected-sdk-collection']:
 names=[x[:-6] for x in (B/'checks'/label/'output.log').read_text().splitlines() if x.endswith(': test')];assert len(names)==len(set(names))==180;lists.append(names)
assert lists[0]==lists[1]==lists[2]
ids=load(B/'test-identities.json');assert len(ids['base176'])==176 and set(ids['base176'])<=set(lists[0])
oldactors=load(F/'test-identities.json')['compile_list_only16'];assert len(oldactors)==16
pure=B/'checks/07-corrected-pure';raw=(pure/'output.log').read_text();passed=re.findall(r'^test (\S+) \.\.\. ok$',raw,re.M)
assert len(passed)==len(set(passed))==164 and set(passed)==set(lists[0])-set(oldactors)
r=load(pure/'receipt.json');assert r['argv'][1]=='--exact' and set(r['argv'][2:-1])==set(passed) and r['argv'][-1]=='--test-threads=4'
assert '164 passed; 0 failed; 0 ignored; 0 measured; 16 filtered out' in raw
assert sha(B/'evidence/green-native-test-binary')==r['executable_sha256_before']=='f0736252a4a0c09bf63dac9129f9ca0da8290ee06ad180ceb379f847ab10a599'
clear('actual_retained_counterproof_and_check_data',{'receipts':10,'meaningful_RED':{'pass':1,'fail':3},'same_four_GREEN':4,'final_pure_mock_PASS':164,'compiled_listed_each_mode':180,'real_actor_cases_not_executed':16,'strict_clippy_rustfmt_patch_zero':True})

for n,h in pins.items():assert sha(B/n)==h
for n,row in rows.items():verify(S/n,row)
root_after=state();assert root_before==root_after
report={'verdict':'PASS_W05_REVIEW_FINDINGS_CLOSED_SOURCE_DATA_ONLY','reviewer':'/root/m03_w04_owner_bridge_review','author':'/root/m03_verification_wiring','subject_execution':False,'subject_imports':False,'root_writes':False,'reviewed_utc':datetime.now(timezone.utc).isoformat(),'input_pins':pins,'checks':checks,'receipts':records,'blocking_findings':[],'nonblocking_findings':[],'closed_findings':[{'id':'W05-PHASE-001','status':'CLOSED','reason':'Actual free helper permits only justified Starting/Backoff to Running; actual poll-observed fake owner and ManagedService counterproofs fail before fix and pass unchanged after. All old stop/cancel/failure gates preserved.'},{'id':'W05-REVOKE-002','status':'CLOSED','reason':'Issued flag is invalidated while still reachable before release of hub slot. Deterministic same-helper post-removal close observes false before owner resumes. Single publisher/withdrawer serialization, original close/publish fences and checked epochs preserved.'}],'root_observation_before':root_before,'root_observation_after':root_after,'pending':['Root adoption and complete root verification','Real packaged crash/restart/cancellation/owned-cleanup execution','Authenticated native GUI and unsaved renderer-state proof','Windows/MSVC, Ubuntu and Mac platform CI/lifecycle evidence','W05 and later milestone acceptance']}
(O/'findings.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'verdict':report['verdict'],'closed_findings':['W05-PHASE-001','W05-REVOKE-002'],'checks':len(checks),'new_retained_files':1936,'original_retained_files':1992,'source_files':1848,'pure_passes':164,'listed_each_mode':180,'findings_sha256':sha(O/'findings.json')},indent=2))
