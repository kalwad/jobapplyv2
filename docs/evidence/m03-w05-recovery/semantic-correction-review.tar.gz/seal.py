"""Seal this independent correction closure, without subject execution."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
O=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(O/'findings.json')=='35fdbcaf0d6b15557e7cf6edf13256fad3a4421d9473c88d8a5236f79cd7956f'
assert not (O/'audit.stderr').read_bytes()
r=json.loads((O/'audit.stdout').read_text());assert r['verdict']=='PASS_W05_REVIEW_FINDINGS_CLOSED_SOURCE_DATA_ONLY'
observation={'observed_tool_exit_code':0,'source_of_exit_observation':'Completed tools.exec_command session 34083 returned exit_code 0','stdout':'audit.stdout','stderr':'audit.stderr','original_streams_redirected':True,'subject_execution':False}
(O/'checker-observation.json').write_text(json.dumps(observation,indent=2)+'\n')
rows=[]
for p in sorted(O.iterdir()):
 if p.is_file() and p.name!='retention-manifest.json':rows.append({'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)})
m={'kind':'INDEPENDENT_W05_PHASE001_REVOKE002_CORRECTION_CLOSURE','verdict':r['verdict'],'closed_findings':['W05-PHASE-001','W05-REVOKE-002'],'reviewer':'/root/m03_w04_owner_bridge_review','sealed_utc':datetime.now(timezone.utc).isoformat(),'subject_execution':False,'root_writes':False,'subject_source_sha256':'98e25bfeef7c85890e84b54938eed476818702cd52b85d81ac83081df80e7eb5','subject_retention_sha256':'63b80481d86939c73fc564e9837c0305666aa9926edbe84142993cda9c424935','files':rows}
(O/'retention-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
for n in ['findings.json','REVIEW.md','retention-manifest.json']:print(n,sha(O/n))
