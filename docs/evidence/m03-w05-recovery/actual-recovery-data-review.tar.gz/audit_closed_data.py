"""Closed native evidence read/hash/JSON audit. No imports/invocation of product tools."""
import hashlib,json,re,stat,tarfile
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
B=Path(__file__).resolve().parent
R=Path('/tmp/japp-m03-w05-actual-recovery-execution-20261019-retained')
M=R/'members'
OWN=Path('/tmp/japp-m03-w05-actual-recovery-execution-v2-20261019')
bindings={};observed={}
def read(p):
 p=Path(p);assert p.is_file() and not p.is_symlink(),p
 data=p.read_bytes();bindings[str(p)]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};return data
def info(p):
 data=read(p);return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def sha(p):return info(p)['sha256']
def load(p):return json.loads(read(p))
def put(n,v):(B/n).write_text(json.dumps(v,indent=2)+'\n')
def match(p,row):assert info(p)=={k:row[k] for k in ['bytes','sha256']},str(p)
outer=load(R/'retention-manifest.json');members=outer['files']
assert sha(R/'proof.tar.gz')==outer['archive']['sha256']=='af789d21466b2411b0d7190c8a98ebec0546b7cc4388043dec4e52b724345cf7'
assert info(R/'proof.tar.gz')['bytes']==18222376 and sha(R/'retention-manifest.json')=='6ab0c898d6590f5209856dcec6a71f33d62e46f21f27f46c34d7fcf0d4c10107'
with tarfile.open(R/'proof.tar.gz','r:gz') as t:
 seen=set()
 for x in t.getmembers():
  name=x.name;p=PurePosixPath(name)
  assert x.isfile() and not p.is_absolute() and '\\' not in name and not any(z in ['.','..'] for z in p.parts) and name not in seen
  data=t.extractfile(x).read();assert {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}==members[name]
  match(M/name,members[name]);seen.add(name)
assert len(seen)==len(members)==761
embedded=load(M/'members.json')['files'];assert embedded=={n:v for n,v in members.items() if n!='members.json'}
for n,v in load(R/'handoff-manifest.json')['files'].items():match(R/n,v)
observed['finite_packet']={'archive_sha256':outer['archive']['sha256'],'members':761,'safe_regular_unique':True,'embedded_and_outer_exhaustive':True,'no_author_payload_copy_in_review':True}
logical=load(M/'source-review-packet/logical-after-manifest.json');overlay=load(M/'source-review-packet/overlay-manifest.json')
assert len(logical)==1851 and sha(M/'source-review-packet/logical-after-manifest.json')=='060c2fd8e143b33560e101ac090b0a96c4a545048caa3224b05196cbd27d59f0'
assert sha(M/'source-review-packet/overlay-manifest.json')=='55b10359c2bad1b76381852d5f38f61cb800b8d5d29a37ed01c3c2b08dbe2069'
collector=info(M/'source-review-packet/collect.py');assert collector['sha256']=='736ffe4c9848b6a382d73816daaf976cb3643adb0559a5b988335251e7db7dbd'
for n,v in logical.items():match(OWN/'source'/n,v)
for n,v in overlay.items():match(M/'source-review-packet/overlay'/n,v)
app=load(M/'setup/provenance/runtime-applicability.json');assert len(app['source_inputs'])==135 and len(app['runtime'])==40
for n,v in app['source_inputs'].items():match(OWN/'source'/n,v)
for root in [OWN/'current-runtime',OWN/'fault-runtime',OWN/'source/apps/desktop/src-tauri/runtime-payload']:
 actual={p.relative_to(root).as_posix():info(p) for p in root.rglob('*') if p.is_file()};assert actual==app['runtime']
finalruntime=load(M/'runtime-final.json');assert finalruntime['current-runtime']==finalruntime['fault-runtime']==app['runtime']
for n,v in app['wheels'].items():match(M/'setup/provenance/wheels'/n,v);match(OWN/'provenance/wheels'/n,v)
for n,digest in [('build_requirements.txt','a61cfea9359f0f0f6fdab4a0d1d3753aa719e73f3404e930adb75d7f99eb9e79'),('runtime_requirements.txt','b02e40a467e53d35159f3bc06d456ca98d83020daac6d6d720e2e4bb2d8fe307')]:assert sha(M/'setup/provenance'/n)==sha(OWN/'provenance'/n)==digest
observed['actual_source_runtime']={'actual_logical1851':True,'all5_overlay':True,'actual135':True,'actual3_runtime40':True,'two_wheels_real_two_requirements':True,'no_new_Python_build':True}
# Join closed stage config/release/peer/collector records independently of the derived summary.
stages=['evidence-compile-v2','evidence-statics-v1','evidence-actors-default-v1','evidence-actors-features-v1'];controls=M/'execution-control';configs={}
for stage in stages:
 chain=load(M/'execution'/stage/'release-inputs.json');stem=stage.removeprefix('evidence-')
 configpath=controls/('config-'+stem+'.json');releasepath=controls/('release-'+stem+'.json')
 config=load(configpath);release=load(releasepath);match(configpath,chain['config']);match(releasepath,chain['release'])
 assert chain['collector']==collector and chain['environment']==config['environment']
 assert chain['independent_review']['sha256']==config['independent_review_sha256']=='182f55dd0470c979a695c553b62b67509d496ef310e4556a60d7777f9b1f1a34'
 assert release['decision']=='ROOT_RELEASED_OUTSIDE_W05_PHASE' and release['performance_hold_cleared'] is True
 assert release['collector_sha256']==collector['sha256'] and release['config_sha256']==sha(configpath) and release['logical_manifest_sha256']==sha(M/'source-review-packet/logical-after-manifest.json')
 assert config['environment']['CARGO_BUILD_JOBS']=='2' and config['environment']['CARGO_NET_OFFLINE']=='true'
 configs[stage]=config
expected=set(load(M/'source-review-packet/expected187.json'));assert len(expected)==187
compiled=load(M/'execution/evidence-compile-v2/compiled187.json');assert compiled['scope']=='COLLECTION_ONLY_NOT_EXECUTION' and set(compiled['catalogs'])=={'default','all-features','sdk-custom'}
images=load(M/'binary-images.json');assert images['physical_bytes_in_archive'] is False and len(images['files'])==6
physical={x['path']:x for x in images['files']};libs={}
for x in images['files']:
 match(Path(x['path']),x);assert oct(stat.S_IMODE(Path(x['path']).stat().st_mode))==x['mode_octal']=='0o555'
for mode,catalog in compiled['catalogs'].items():
 assert len(catalog['ids'])==len(set(catalog['ids']))==187 and set(catalog['ids'])==expected
 rawids=[];kinds=[]
 compilelog=M/'execution/evidence-compile-v2'/(mode+'-compile')/'stdout'
 compile_artifacts=[json.loads(x) for x in read(compilelog).decode().splitlines() if x.strip()]
 for i,a in enumerate(catalog['artifacts']):
  art=a['compiler_artifact'];assert art in compile_artifacts and art['manifest_path']==str((OWN/'source/apps/desktop/src-tauri/Cargo.toml').resolve()) and art['profile']['test'] is True and art['fresh'] is False
  kind=art['target']['kind'];kinds.append(kind);row=physical[a['retained']];assert a['image']=={k:row[k] for k in ['bytes','sha256']}
  p=M/'execution/evidence-compile-v2'/(mode+'-'+str(i)+'-list');raw=[x[:-6] for x in read(p/'stdout').decode().splitlines() if x.endswith(': test')]
  assert len(raw)==len(set(raw)) and len(raw)==(187 if kind==['lib'] else 0)
  rawids+=raw
  if kind==['lib']:libs[mode]=a['retained']
 assert sorted(kinds)==[['bin'],['lib']] and len(rawids)==len(set(rawids))==187 and set(rawids)==expected
observed['compiler']={'modes':3,'each_lib187_main0':True,'six_actual_retained_images_hash_mode555':True,'all_fresh_owned_package_artifacts':True}
# Product commands, not outer launch receipts.
commands=[];actors=[];compile_end=[];static_end=[];generated_present=0;generated_absent=0
allowedgen={'apps/desktop/src-tauri/gen/schemas/'+n for n in ['capabilities.json','acl-manifests.json','macOS-schema.json','desktop-schema.json']}
aux_reference=None
for stage in stages:
 base=M/'execution'/stage;config=configs[stage]
 for p in sorted(base.glob('*/upfront.json')):
  up=load(p)
  if 'actor' not in up:continue
  d=p.parent;result=load(d/'result.json');assert result['exit_code']==0 and result['failure'] is None and result['source_unchanged'] is True and result['runtime_unchanged'] is True
  assert result['collector_after']==up['collector']==collector and result['tool_after']==up['tool_before'] and result['toolchain_after']==up['toolchain_before']
  match(d/'stdout',result['stdout']);match(d/'stderr',result['stderr']);match(d/'source-before.json',up['source_before']);match(d/'runtime-before.json',up['runtime_before'])
  assert read(d/'source-before.json')==read(d/'source-after.json') and load(d/'source-before.json')==logical
  assert read(d/'runtime-before.json')==read(d/'runtime-after.json')
  rt=load(d/'runtime-before.json');assert rt['runtime']==rt['fault_runtime']==app['runtime'] and rt['compile_auxiliary']['compile_runtime_payload']==app['runtime'] and len(rt['compile_auxiliary']['frontend_dist'])==4
  if aux_reference is None:aux_reference=rt['compile_auxiliary']
  else:assert aux_reference==rt['compile_auxiliary']
  for value in rt['reused_wheel_requirement_provenance'].values():match(Path(value['path']),value)
  assert up['cwd']==str((OWN/'source').resolve()) and up['source_unchanged_scope']==result['source_unchanged_scope'] and 'four generated' in up['source_unchanged_scope']
  env={k:v for k,v in up['environment'].items() if not k.startswith('JAPP_W05_')};assert env==config['environment']
  for side in ['before','after']:
   gen=load(d/('generated-'+side+'.json'));assert set(gen)==allowedgen
   match(d/('generated-'+side+'.json'),up['generated_outputs_before'] if side=='before' else result['generated_outputs_after'])
   for n,row in gen.items():
    if row['state']=='ABSENT':generated_absent+=1;assert not (d/('generated-'+side+'-files')/n).exists()
    else:
     generated_present+=1;assert row['state']=='PRESENT';q=d/('generated-'+side+'-files')/n;match(q,row);assert oct(stat.S_IMODE(q.stat().st_mode))==row['mode']
  assert result['generated_outputs_equal']==(load(d/'generated-before.json')==load(d/'generated-after.json'))
  command={'stage':stage,'path':str(d.relative_to(M)),'up':up,'result':result};commands.append(command)
  if up['actor']:actors.append(command)
  elif stage=='evidence-compile-v2':compile_end.append(result['ended_at'])
  elif stage=='evidence-statics-v1':static_end.append(result['ended_at'])
assert len(commands)==27 and len(actors)==12 and len(compile_end)==11 and len(static_end)==4
assert max(compile_end)<min(x['up']['started_at'] for x in actors) and max(static_end)<min(x['up']['started_at'] for x in actors)
statics=[x for x in commands if x['stage']=='evidence-statics-v1'];assert sum('clippy' in x['up']['argv'] for x in statics)==3 and sum('fmt' in x['up']['argv'] for x in statics)==1
for x in statics:
 argv=x['up']['argv']
 if 'clippy' in argv:assert '--all-targets' in argv and '--locked' in argv and '--offline' in argv and argv[-2:]==['-D','warnings']
 else:assert '--check' in argv
observed['commands']={'actual_product27_zero':True,'all_three_catalogs_and_statics_before_first_actor':True,'immutable_environment_and_source_runtime_tool_refs':True,'exact_generated4_before_end':{'present':generated_present,'absent':generated_absent},'three_auxiliary_maps_unchanged':True}
# Actual four identities/case events per mode, independent raw parsing.
prefix='service::tauri_lifecycle::actual_recovery_tests::'
cases={prefix+'actual_owned_deaths_relaunch_twice_then_stop_without_orphans':('two_replacements_then_terminal',3),prefix+'actual_quit_during_backoff_closes_same_authority_and_never_restarts':('quit_during_backoff',1),prefix+'actual_monotonic_cycle_deadline_refuses_delayed_backoff_replacement':('real_clock_delayed_driver_deadline',1),prefix+'actual_missing_runtime_replacement_fails_once_without_hidden_loop':('missing_owned_runtime_replacement',1)}
case_results=[];seen_modes={m:[] for m in libs};all_spawns=[];deadlines=[];secret_candidates=[]
for command in actors:
 up=command['up'];result=command['result'];d=M/command['path'];argv=up['argv'];identity=argv[2];assert identity in cases and argv[1:] == ['--exact',identity,'--nocapture','--test-threads=1']
 mode=next(m for m,p in libs.items() if p==argv[0]);seen_modes[mode].append(identity)
 assert up['timeout_seconds']<=55 and up['tool_image']==libs[mode];process=load(d/'owned-process.json');assert process['new_session'] is True and process['pid']==process['pgid'] and process['argv']==argv
 output=read(d/'stdout').decode();assert re.findall(r'^test (.+) \.\.\. ok$',output,re.M)==[identity] and '1 passed; 0 failed; 0 ignored; 0 measured; 186 filtered out;' in output and read(d/'stderr')==b''
 ledgername=Path(up['environment']['JAPP_W05_LEDGER']).name;ledger=d.parent/ledgername;raw=read(ledger);rows=[json.loads(x) for x in raw.decode().splitlines()];name,count=cases[identity]
 assert rows and all(set(x)=={'case','details','event','harness_pid','nonce','unix_ms'} and x['case']==name and x['harness_pid']==process['pid'] and x['nonce']==up['environment']['JAPP_W05_NONCE'] for x in rows)
 events={e:[x['details'] for x in rows if x['event']==e] for e in {x['event'] for x in rows}}
 assert len(events['case_start'])==len(events['case_pass'])==len(events['cleanup_verified'])==1 and events['case_start'][0]=={'headless_actual_owner':True,'wry_background':False}
 assert 'unwind_cleanup' not in events and rows[-1]['event']=='case_pass' and events['case_pass'][0]['elapsed_ms']<45000
 spawns=events['native_spawn'];receipts=events['spawn_receipt'];acks=events['ack_live_running'];assert len(spawns)==len(receipts)==len(acks)==count
 assert [x['sequence'] for x in spawns]==list(range(1,count+1)) and [x['generation'] for x in spawns]==list(range(1,count+1))
 assert [{k:x[k] for k in ['pid','port','generation','elapsed_ns','sequence']} for x in receipts]==spawns and all(x['gone_after_owned_cleanup'] for x in receipts)
 assert all(a['same_clock_flag_hub'] and all(a[k]==s[k] for k in ['pid','port','generation']) for a,s in zip(acks,spawns))
 assert all(x['group_absent'] and x['reader_reaped_by_real_owner'] and x['rebound'] and x['first_cause']=='ChildExited' for x in events['generation_cleaned'])
 cleanup=events['cleanup_verified'][0];assert cleanup=={'acknowledged_ports_rebound':count,'actual_spawns':count,'all_observed_pids_groups_absent':True,'lost_receipts':0,'owned_slot_released':True}
 assert result['cleanup']=={'direct_child_returncode':0,'owned_group':'GONE','unregistered_OS_descendants':'UNOBSERVED'}
 service=result['service_read_only_observation'];pids=[x['pid'] for x in spawns];assert service['actual_receipt_pids']==pids and service['all_absent'] is True and service['signals_sent'] is False and service['unregistered_OS_descendants']=='UNOBSERVED'
 assert {x['target'] for x in service['observations']}==set(pids+[-p for p in pids]) and all(x['state']=='ABSENT' for x in service['observations'])
 states=[]
 for rec in events['diagnostics']:
  state=rec['state'];payload=rec['record']['payload'];assert payload['state']==state
  assert set(payload)==({'api_version','request_id','service_version','state'} if state=='READY' else {'request_id','state'})
  if state=='READY':assert payload['api_version']=='1.0.0' and payload['service_version']=='0.0.1'
  states.append(state)
  serial=json.dumps(rec['record']).lower();assert all(s not in serial for s in ['bind_port','instance_id','generation','authorization','127.0.0.1'])
 if count==3:
  assert [x['epoch'] for x in acks]==[1,3,5] and len({x['port'] for x in spawns})==3 and len({x['pid'] for x in spawns})==3
  assert [x['policy_ms'] for x in events['early_backoff_no_spawn']]==[250,1000] and all(x['now_ns']<x['until_ns'] for x in events['early_backoff_no_spawn'])
  assert states.count('READY')==3 and 'FAILED' in states
 elif name=='quit_during_backoff':
  q=events['quit_before_busy_owner'];assert len(q)==1 and q[0]['permanent_flag_closed'] and not q[0]['barrier_expired'] and q[0]['elapsed_ns']<100000000 and q[0]['epoch_after']>q[0]['epoch_before'] and 'STOPPING' in states
 elif name=='real_clock_delayed_driver_deadline':
  q=events['real_deadline_fence'];assert len(q)==1 and q[0]['delayed_driver_not_stalled_startup'] is True and q[0]['policy_cycle_ms']==24000 and q[0]['now_ns']>=q[0]['deadline_ns'] and events['case_pass'][0]['elapsed_ms']>=24000 and 'FAILED' in states;deadlines.append(events['case_pass'][0]['elapsed_ms'])
 else:
  h=events['owned_runtime_hidden'];r=events['owned_runtime_restored'];assert len(h)==len(r)==1 and h[0]['source_absent'] and not h[0]['donor_mutated'] and Path(h[0]['source']).is_relative_to((OWN/'fault-runtime').resolve()) and r[0]=={'donor_mutated':False,'entrypoint_hash_matches':True} and 'FAILED' in states
 assert states[-1]=='STOPPED'
 actorbytes=raw+read(d/'stdout')+read(d/'stderr');assert not re.search(rb'(?i)(authorization|session_token|bearer\s+)',actorbytes) and not re.search(rb'(?<![a-fA-F0-9])[a-fA-F0-9]{64}(?![a-fA-F0-9])',actorbytes)
 all_spawns+=pids;case_results.append({'mode':mode,'case':name,'identity':identity,'native_spawns':count,'harness_pid':process['pid'],'registered_native_pids':pids,'elapsed_ms':events['case_pass'][0]['elapsed_ms'],'ledger_sha256':sha(ledger),'registered_groups_absent':True,'source_assertions_for_terminal_reasons':'Exact reviewed Rust case; runtime authoritativePASS, not separately logged numeric reason'})
assert all(len(v)==4 and set(v)==set(cases) for v in seen_modes.values()) and len(all_spawns)==len(set(all_spawns))==18
observed['selected_actual_cases']={'modes':3,'each4':True,'total12':True,'native_spawns18':True,'deadline_case_elapsed_ms':deadlines,'same_actual_private_owner_clock_flag_hub_ACK':True,'registered_PID_groups_absent_all':True,'all_case_ports_rebound_and_slots_released':True,'fault_restored_each_mode':True,'no_retained_actor_authorization_field_or64hex_token_value':True,'unregistered_OS_descendants':'UNOBSERVED','existing183_not_executed':True}
put('case-results.json',case_results)
# Retention/history scope is checked directly and remains separate from product pass counts.
summary=load(M/'summary.derived.json');assert summary['product_actor_retries']==0 and summary['selected_execution']['total']==12 and summary['selected_execution']['native_spawn_receipts_total']==18
for n,v in summary['original_copies'].items():match(Path(v['original']),v);match(M/n,v)
initial=load(M/'execution/launch-compile-v1/result.json');assert initial['exit_code']==1
assert 'unexpected source/config file:' in read(M/'execution/launch-compile-v1/stderr').decode()
observed['history_and_scope']={'original_copies_exact':len(summary['original_copies']),'initial_preflight_refusal_retained':True,'preparation_datetime_mixed_inventory_path127_histories':'Author retained/disclosed setup-only, including derived-only inventory fact; not productRED','no_actual_actor_retry':True,'no_Wry_GUI_whole187_M03_or_gate_credit':True}
# Recheck immutable packet after every original/image read; no actors or caches were invoked.
assert sha(R/'proof.tar.gz')==outer['archive']['sha256'] and sha(R/'retention-manifest.json')=='6ab0c898d6590f5209856dcec6a71f33d62e46f21f27f46c34d7fcf0d4c10107'
report={'decision':'CLEAR_ACTUAL_SELECTED4x3_SCOPE','reviewer':'/root/final_runtime_review','completed_utc':datetime.now(timezone.utc).isoformat(),'findings':[],'observed':observed,'author_derived_summary_independently_reconstructed':True,'actions':['read/hash/archive stream inspection/JSON+raw parsing only'],'no_actor_compiler_rerun_provider_import_root_or_cache_write':True,'limits':['Three187 catalogs are collection only; selected4x3 actualcases and prior183campaign remain distinct.','24s case delays manual driving of realclock; no stalled-startup or lateACK claim.','Native handles/registered PIDgroups/ports are observed; unregistered OS descendants remain UNOBSERVED.','No Wry start_background/AppHandle/GUI/editable-unsaved-form/nativeplatform/M03/milestone/release acceptance.','No wholetoolchain/cache reproducibility or newPython/runtime build credit; exact retained images are outsideauthorarchive.','Secret scan covers retainedactorlogs/ledgers and closed diagnostics fields; no wholeprocess erasure/unobservedstream claim.']}
put('findings.json',report);put('input-bindings.json',bindings)
print(json.dumps({'decision':report['decision'],'product_commands':len(commands),'selected_actual_cases':len(actors),'native_spawns':len(all_spawns),'catalogs187_main0':3,'physical_images':6,'archive_members':761,'input_bindings':len(bindings),'findings_sha256':sha(B/'findings.json')},indent=2))
