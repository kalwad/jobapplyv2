import json,pathlib
ROOT=pathlib.Path('/tmp/japp-m03-w05-native-data-independent-review-20261019');records=json.loads((ROOT/'attempt3/author/closed-command-records.json').read_bytes());by={r['label']:r for r in records}
base=['test','--locked','--offline','-j2','--manifest-path','apps/desktop/src-tauri/Cargo.toml']
observed=[]
for mode,features in [('default',[]),('allfeatures',['--all-features']),('sdk-custom',['--features','tauri/custom-protocol'])]:
 r=by[mode+'-compile'];assert r['argv'][1:]==base+features+['--no-run','--message-format=json']
 observed.append({'mode':mode,'actual_compile_argv':r['argv'],'actual_test_argv':[by[f'{mode}-{i}-tests']['argv'] for i in [0,1]],'exit_code':r['exit_code']})
value={'result':'PASS','modes':observed,'scope':'Exact recorded compiler feature selection, compiler no-run catalog barrier and later serial binary test commands only. No replay or canonical parallel claim.'}
p=ROOT/'mode-command-binding.json';assert not p.exists();p.write_text(json.dumps(value,indent=2)+'\n');print('PASS exact default/all-features/dependency custom-protocol compiler argv and serial binary test argv')
