import datetime as dt,hashlib,json,pathlib,subprocess,sys,time
ROOT=pathlib.Path('/tmp/japp-m03-w05-native-data-independent-review-20261019');argv=['python3','audit.py'];started=dt.datetime.now(dt.timezone.utc).isoformat();tick=time.monotonic()
number=len(list(ROOT.glob('audit-operation*.json')))+1
p=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
row={'argv':argv,'cwd':str(ROOT),'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-tick,'exit_code':p.returncode,'scope':'Independent closed source/data/command/binary audit only; no actor, compiler, GUI or root access.'}
for stream,raw in [('stdout',p.stdout),('stderr',p.stderr)]:
 target=ROOT/(f'audit-{number:04d}.'+stream);assert not target.exists();target.write_bytes(raw);row[stream]={'path':target.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
(ROOT/f'audit-operation-{number:04d}.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row,indent=2));print(p.stdout.decode(errors='replace')[:12000]);print(p.stderr.decode(errors='replace')[:12000]);raise SystemExit(p.returncode)
