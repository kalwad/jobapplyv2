import hashlib,json,pathlib,stat
ROOT=pathlib.Path('/tmp/japp-m03-w05-native-data-independent-review-20261019');S=ROOT/'attempt3/author';A=pathlib.Path('/tmp/japp-m03-w05-current-native-execution-20261019')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_bytes())
def digest(p):return {'bytes':p.stat().st_size,'sha256':sha(p)}
app=load(S/'applicability-before-owned-mode-changes.json');assert len(app['sources'])==4
stage=A/'source/apps/desktop/src-tauri/runtime-payload';manifest=load(stage/'manifest.json')
for field,name in [('contracts_wheel_sha256','japp_contracts-0.0.1-py3-none-any.whl'),('orchestrator_wheel_sha256','orchestrator-0.0.1-py3-none-any.whl')]:assert manifest['source_inputs'][field]==app['wheels'][name]['sha256']
runtime_before=load(S/'runtime-stage-before.json');assert len(runtime_before)==40
for name,entry in runtime_before.items():
 assert digest(stage/name)=={k:entry[k] for k in ['bytes','sha256']} and stat.S_IMODE((stage/name).stat().st_mode)==entry['mode']
interpreter=load(S/'owned-interpreter-upfront.json');assert digest(pathlib.Path(interpreter['resolved']))=={k:interpreter[k] for k in ['bytes','sha256']}
records=load(S/'closed-command-records.json')
for r in records:
 for when in ['input_bindings_before','input_bindings_after']:
  if 'actual_interpreter' in r[when]:assert r[when]['actual_interpreter']==interpreter
  if 'actual_runtime40' in r[when]:assert r[when]['actual_runtime40']==app['runtime']
changes=load(S/'exact-deltas.json');assert len(changes)==9
for entry in changes:
 name=entry['path'];assert digest(S/'selected-postimages'/name)==digest(A/'source'/name)==entry['planned_postimage']
 pre=entry['current_preimage']
 if pre is not None:assert digest(S/'selected-preimages'/name)==pre
result={'result':'PASS','all9_planned_postimages_and_existing_preimages_exact':True,'actual_interpreter_and_every_command_interpreter_binding_exact':True,'actual_runtime40_bytes_modes_and_every_command_runtime_binding_exact':True,'both_wheel_hashes_join_runtime_manifest':True,'four_actual_source_projections':True,'expected_venv_copy_binding_transition':'Only03-owned-venv-copy gains actual_interpreter after the owned copy; all other per-command input bindings remain equal.','scope':'Supplement to the closed documentary data audit; no actor, compiler, runtime execution or root observation.'}
target=ROOT/'supplemental-review.json';assert not target.exists();target.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
