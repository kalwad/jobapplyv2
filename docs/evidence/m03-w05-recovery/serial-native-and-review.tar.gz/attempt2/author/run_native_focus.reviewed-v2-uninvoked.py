"""Future approved183x3 owned native campaign; invoke only after root phase release."""
from __future__ import annotations
import copy,hashlib,json,os,re,shutil,signal,stat,subprocess,sys,time,traceback
from datetime import datetime,timezone
from pathlib import Path
B=Path(__file__).resolve().parent
S=B/'source'
JOIN=Path('/tmp/japp-m03-w05-current-source-join-20261019')
CURRENT=Path('/tmp/japp-m03-w04-current-tooling-join-20261019')
APP=Path('/tmp/japp-m03-w04-current-app-build-preparation-20261019')
DONOR=Path('/tmp/japp-m03-w04-owned-session-full-preparation-v3-20261019')
BUILD=Path('/tmp/japp-m03-w04-preparation-wheels-runtime-20261018')
ORIGINAL=Path('/tmp/japp-m03-w04-current-root-shadow-20261018/source')
ROOT=Path('/Users/tanishkalwad/jobapplyv2')
RUST=Path('/Users/tanishkalwad/.rustup/toolchains/1.97.1-aarch64-apple-darwin/bin')
MANIFEST='ee091e710086c6149d019c9ac58aed68f6b8b8dedee31b572dfabedba36f4f47'
PLAN='929e4106e5da3f29502b5fa61a86634ee3af8ba3292b9dfd80e3ba3a8f814f3e'
RECORDS=[]
EXPECTED={}
ENV={'HOME':str(Path.home()),'PATH':str(RUST)+':'+str(S/'.venv/bin')+':/usr/bin:/bin:/usr/sbin:/sbin',
 'LANG':'en_US.UTF-8','LC_ALL':'en_US.UTF-8','CARGO_HOME':str(Path.home()/'.cargo'),
 'RUSTUP_HOME':str(Path.home()/'.rustup'),'RUSTC':str(RUST/'rustc'),
 'CARGO_TARGET_DIR':str(B/'cargo-target'),'CARGO_BUILD_JOBS':'2','CARGO_NET_OFFLINE':'true',
 'RUST_BACKTRACE':'1','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null',
 'GIT_TERMINAL_PROMPT':'0','GIT_OPTIONAL_LOCKS':'0','PYTHONDONTWRITEBYTECODE':'1',
 'TMPDIR':str(B/'tmp')+'/' }

def now():return datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(p,value):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(copy.deepcopy(value),indent=2)+'\n')
def require(condition,message):
 if not condition:raise RuntimeError(message)
def info(p):
 p=Path(p);require(p.is_file() and not p.is_symlink(),'not regular input '+str(p))
 return {'bytes':p.stat().st_size,'sha256':sha(p)}
def exeinfo(p):
 p=Path(p);r=p.resolve(strict=True)
 return {'requested':str(p),'resolved':str(r),'bytes':r.stat().st_size,'sha256':sha(r),'mode':stat.S_IMODE(r.stat().st_mode)}
def tree(p):
 p=Path(p);out={}
 for x in sorted(p.rglob('*')):
  n=x.relative_to(p).as_posix()
  if x.is_symlink():out[n]={'type':'symlink','target':os.readlink(x)}
  elif x.is_file():out[n]={'type':'file',**info(x),'mode':stat.S_IMODE(x.stat().st_mode)}
 return out

def logical(root):
 root=Path(root);actual={n:info(root/n) for n in EXPECTED}
 require(actual==EXPECTED,'logical source byte mismatch '+str(root))
 # Generated/ignored setup inputs do not become logical production source.
 ignored={'.git','.venv','node_modules','dist','runtime-payload','__pycache__','.pytest_cache','.mypy_cache','.ruff_cache','target','test-results','gen'}
 extra=[]
 for parent,dirs,files in os.walk(root):
  dirs[:]=[n for n in dirs if n not in ignored]
  for n in files:
   rel=(Path(parent)/n).relative_to(root).as_posix()
   if rel not in EXPECTED:extra.append(rel)
 require(not extra,'unexpected logical source paths '+str(extra))
 return {'paths':len(actual),'manifest_sha256':MANIFEST}

def current_inputs():
 bindings={}
 for n in ['applicability-before-owned-mode-changes.json','owned-interpreter-upfront.json','runtime-stage-before.json','renderer-compile-input-reuse.json','isolated-git-input.json','tool-executables.json','compiler-list-barrier.json']:
  if (B/n).is_file():bindings[n]=info(B/n)
 runtime=S/'apps/desktop/src-tauri/runtime-payload'
 if (B/'applicability-before-owned-mode-changes.json').is_file():
  expected_runtime=load(B/'applicability-before-owned-mode-changes.json')['runtime']
  # Before stage copy no staged payload is claimed; once staged bind actual40 bytes per command.
  if (runtime/'manifest.json').is_file():
   actual={n:info(runtime/n) for n in expected_runtime}
   require(actual==expected_runtime,'staged runtime changed before command')
   bindings['actual_runtime40']=actual
 if (S/'.venv/bin/python').exists():bindings['actual_interpreter']=exeinfo(S/'.venv/bin/python')
 return bindings

def command(label,argv,timeout=60,cwd=None,environment=None,source_check=True):
 d=B/'checks'/label;d.mkdir(parents=True,exist_ok=False)
 env=dict(ENV if environment is None else environment)
 argv=[str(x) for x in argv];cwd=Path(cwd or S)
 requested=Path(argv[0]) if '/' in argv[0] else Path(shutil.which(argv[0],path=env['PATH']) or '')
 require(requested.is_file(),'command executable unavailable '+argv[0])
 before=exeinfo(requested)
 if source_check:logical(S)
 rec={'label':label,'argv':list(argv),'cwd':str(cwd),'environment':dict(env),'timeout_seconds':timeout,
 'started_utc':now(),'executable_before':before,'wrapper_sha256':sha(__file__),
 'source_manifest_sha256':MANIFEST,'input_bindings_before':current_inputs(),'scope':'OUTSIDE_SERIAL183_NATIVE_ONLY_NO_GUI_NO_ROOT_WRITES'}
 put(d/'upfront.json',copy.deepcopy(rec))
 start=time.monotonic();timed=False;cleanup=[];wait_failure=None;group_after_abort="NOT_ABORTED"
 with (d/'stdout').open('xb') as out,(d/'stderr').open('xb') as err:
  child=subprocess.Popen(argv,cwd=cwd,env=dict(env),stdout=out,stderr=err,start_new_session=True)
  rec['owned_pid']=child.pid;rec['owned_process_group']=child.pid
  put(d/'launch.json',{'owned_pid':child.pid,'owned_process_group':child.pid,'started_utc':now(),'upfront_sha256':sha(d/'upfront.json')})
  try:code=child.wait(timeout=timeout)
  except BaseException as failure:
   wait_failure=failure;timed=isinstance(failure,subprocess.TimeoutExpired)
   rec['wait_error']={'type':type(failure).__name__,'message':str(failure)[:500],'traceback':traceback.format_exc()}
   def owned_group_alive():
    child.poll()  # Reap the leader; its return does not end group ownership.
    try:os.killpg(child.pid,0);return True
    except ProcessLookupError:return False
   for sig,seconds in [(signal.SIGTERM,10),(signal.SIGKILL,5)]:
    if not owned_group_alive():break
    try:os.killpg(child.pid,sig);cleanup.append({'signal':int(sig),'owned_pgid':child.pid,'utc':now()})
    except ProcessLookupError:break
    deadline=time.monotonic()+seconds
    while time.monotonic()<deadline and owned_group_alive():time.sleep(0.05)
   code=child.poll()
   group_after_abort='STILL_PRESENT' if owned_group_alive() else 'GONE'
 rec.update({'ended_utc':now(),'elapsed_seconds':time.monotonic()-start,'exit_code':code,'timed_out':timed,
 'owned_pid_reaped':child.returncode is not None,'timeout_cleanup':cleanup,'owned_group_after_abort':group_after_abort,'cleanup_scope':'OWNED_NEW_SESSION_GROUP_ONLY','descendants_outside_owned_group':'UNOBSERVED','executable_after':exeinfo(requested),
 'stdout':info(d/'stdout'),'stderr':info(d/'stderr'),'input_bindings_after':current_inputs(),'source_after':logical(S) if source_check else 'not_yet_instantiated'})
 put(d/'result.json',copy.deepcopy(rec));RECORDS.append(copy.deepcopy(rec))
 put(B/'closed-command-records.json',copy.deepcopy(RECORDS))
 print(json.dumps({'label':label,'exit_code':code,'seconds':rec['elapsed_seconds']}),flush=True)
 if wait_failure is not None:raise wait_failure
 require(not timed and code==0,'command failed: '+label)
 require(before==rec['executable_after'],'command executable changed '+label)
 return d

def clone(label,src,dst):
 src=Path(src);dst=Path(dst);require(src.is_dir() and not src.is_symlink() and not dst.exists(),'unsafe clone '+str(dst))
 dst.parent.mkdir(parents=True,exist_ok=True)
 return command(label,['/bin/cp','-cR',src,dst],300,cwd=B,source_check=S.exists())

def root_projection(label):
 paths=set(load(JOIN/'approved-plan/current13-preservation-paths.json'))|{x['path'] for x in load(JOIN/'approved-plan/exact-deltas.json')}
 obs=[]
 for i,args in enumerate([['rev-parse','HEAD'],['rev-parse','HEAD^{tree}'],['status','--porcelain=v1','--untracked-files=normal']]):
  d=command(label+'-git-'+str(i),['/usr/bin/git','-C',ROOT,*args],60,cwd=B,source_check=S.exists())
  obs.append({'argv':args,'stdout':(d/'stdout').read_text(),'stderr':(d/'stderr').read_text()})
 projection={n:info(ROOT/n) if (ROOT/n).is_file() else None for n in sorted(paths)}
 result={'utc':now(),'scope':'READ_ONLY_NAMED_MUTABLE_ROOT_PROJECTION_NO_WHOLE_ROOT_NEUTRALITY','git':obs,'paths':projection}
 put(B/(label+'.json'),result);return result

def applicability(source_roots):
 selector=load('/tmp/japp-m03-w04-owned-session-app-build-v2-20261019/unchanged-python-wheel-source-inputs.json')['paths']
 require(len(selector)==135,'selector count mismatch')
 for root in source_roots:
  for n,x in selector.items():require(info(root/n)==x,'135 actual applicability mismatch '+str(root/n))
 # Bind actual build lock separately from historical selector's nonexistent named lock.
 for p in [CURRENT/'source/scripts/service-build-tools.requirements.lock',JOIN/'source/scripts/service-build-tools.requirements.lock',S/'scripts/service-build-tools.requirements.lock',BUILD/'build-work/inputs/service-build-tools.requirements.lock']:
  require(sha(p)=='a61cfea9359f0f0f6fdab4a0d1d3753aa719e73f3404e930adb75d7f99eb9e79','actual service build lock mismatch')
 req=Path('/tmp/japp-m03-w02-service-proposal/proof/wheel-runtime-requirements.txt')
 require(sha(req)==sha(BUILD/'build-work/inputs/wheel-runtime-requirements.txt')=='b02e40a467e53d35159f3bc06d456ca98d83020daac6d6d720e2e4bb2d8fe307','runtime requirements mismatch')
 wheels={}
 for n,digest in [('japp_contracts-0.0.1-py3-none-any.whl','d1ac6f4725a98bb35dca624192bc80b89d4634a3558467b80b6b2f190b2c6d7c'),('orchestrator-0.0.1-py3-none-any.whl','6ef4e59987a42d0a4b34d9bb8507537616e7d83913133b2d5a55bbb83b5e6052')]:
  p=BUILD/'wheels'/n;require(sha(p)==sha(BUILD/'build-work/inputs'/n)==digest,'wheel mismatch '+n);wheels[n]=info(p)
 reference=load(APP/'runtime-applicability.json')['runtime']
 payload={p.relative_to(BUILD/'payload').as_posix():info(p) for p in (BUILD/'payload').rglob('*') if p.is_file()}
 require(len(reference)==40 and payload==reference,'whole runtime40 mismatch')
 require(sha(BUILD/'payload/manifest.json')=='d274dcc7194722a4ec1549043543225d63bf48e5c6c8e55f4049eee4b5ceeea0','runtime manifest mismatch')
 require(sha(BUILD/'payload/japp-orchestrator/japp-orchestrator')=='fc2293a3d6425093c03ada543249ccdc2050038613cf984b3983aada18032c7c','runtime executable mismatch')
 result={'scope':'ACTUAL135_AND_REAL_LOCK_REQUIREMENTS_TWO_WHEELS_WHOLE40_REUSE_ONLY','sources':[str(x) for x in source_roots],'source_inputs':selector,'additional_locks':{'build':info(S/'scripts/service-build-tools.requirements.lock'),'runtime':info(req)},'wheels':wheels,'runtime':reference,'new_Python_build_credit':False}
 return result

def repair_owned_runtime(label,root,reference,tracked_gitignore=False):
 changes=[]
 for n,x in reference.items():
  p=root/n
  if not p.exists():continue
  require(p.is_relative_to(B) and not p.is_symlink() and info(p)==x,'owned runtime repair input mismatch')
  if tracked_gitignore and n=='.gitignore':continue
  before=stat.S_IMODE(p.stat().st_mode)
  if not before&stat.S_IWUSR:
   p.chmod(before|stat.S_IWUSR)
   require(info(p)==x and stat.S_IMODE(p.stat().st_mode)==before|stat.S_IWUSR,'owned mode repair changed bytes')
   changes.append({'path':str(p),'before':before,'after':stat.S_IMODE(p.stat().st_mode),'bytes_sha256':x['sha256']})
 put(B/(label+'.json'),{'actual_changes':len(changes),'changes':changes,'scope':'OWNED_IGNORED_RUNTIME_ONLY_BYTES_EXECUTE_BITS_PRESERVED'})

def main():
 global EXPECTED
 require('--phase-released' in sys.argv[1:],'root phase release is required; no implicit launch')
 require(not S.exists() and not (B/'checks').exists(),'fresh execution directory required')
 require(sha(JOIN/'source-manifest.json')==MANIFEST and sha(JOIN/'FOCUSED_EXECUTION_PLAN.md')==PLAN,'approved source/plan mismatch')
 EXPECTED=load(JOIN/'source-manifest.json');require(len(EXPECTED)==1850,'1850 source required')
 require(sha(JOIN/'approved-plan/planned-test-inventory.json')=='49bc74a752ad11d5eb61e3f0ad6a725a0ecfa3a86f8b98d8be31809ec13073a9','inventory mismatch')
 (B/'tmp').mkdir();(B/'empty-git-template').mkdir()
 put(B/'campaign-upfront.json',{'utc':now(),'script':info(__file__),'interpreter':exeinfo(sys.executable),'environment':dict(ENV),'expected_source':info(JOIN/'source-manifest.json'),'approved_plan':info(JOIN/'FOCUSED_EXECUTION_PLAN.md'),'release_argument':list(sys.argv[1:]),'serial_focus_not_canonical_parallel':True})
 logical(JOIN/'source');root_projection('canonical-context-before')
 clone('01-source-copy',JOIN/'source',S);logical(S)
 shutil.copyfile(JOIN/'source-manifest.json',B/'source-manifest.json')
 source_roots=[ORIGINAL,CURRENT/'source',JOIN/'source',S]
 app=applicability(source_roots);put(B/'applicability-before-owned-mode-changes.json',app)
 # Entire frozen donors remain read-only. COW outputs are independently owned.
 put(B/'completed-donor-context.json',{'path':str(DONOR),'closed_closure':info(DONOR/'closure.json'),'source_manifest':info(DONOR/'source-manifest.json'),'cache_scope':'READ_ONLY_COMPLETED_DONOR_COW_ONLY_NO_CACHE_WIDE_ACCEPTANCE'})
 clone('02-owned-cache-copy',DONOR/'cargo-target',B/'cargo-target')
 clone('03-owned-venv-copy',DONOR/'source/.venv',S/'.venv')
 reanchors=[]
 for p in sorted((S/'.venv/bin').iterdir()):
  if not p.is_file() or p.is_symlink():continue
  data=p.read_bytes()
  if data.startswith(b'#!'):
   first,separator,rest=data.partition(b'\n')
   if b'/.venv/bin/python' in first:
    after=b'#!'+str(S/'.venv/bin/python').encode()+separator+rest
    if after!=data:
     before=info(p);p.chmod(stat.S_IMODE(p.stat().st_mode)|stat.S_IWUSR);p.write_bytes(after)
     reanchors.append({'path':str(p),'before':before,'after':info(p),'kind':'owned_interpreter_shebang'})
 for package,n in [('japp_contracts','packages/contracts/generated/python/src'),('orchestrator','services/orchestrator/src')]:
  p=S/'.venv/lib/python3.12/site-packages'/('_editable_impl_'+package+'.pth')
  require(p.is_file(),'missing owned editable metadata '+str(p));before=info(p);text=p.read_text()
  p.chmod(stat.S_IMODE(p.stat().st_mode)|stat.S_IWUSR);p.write_text(str(S/n)+'\n')
  reanchors.append({'path':str(p),'before':before,'after':info(p),'old_text':text,'new_text':p.read_text(),'kind':'owned_editable_source'})
 put(B/'owned-venv-reanchors.json',reanchors)
 put(B/'owned-venv-tree-before-actors.json',tree(S/'.venv'))
 put(B/'owned-interpreter-upfront.json',exeinfo(S/'.venv/bin/python'))
 runtime=S/'apps/desktop/src-tauri/runtime-payload'
 for n,x in app['runtime'].items():
  p=runtime/n;require(not p.is_symlink(),'stage symlink')
  if p.exists():require(info(p)==x,'runtime stage conflict '+n);continue
  p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(BUILD/'payload'/n,p)
 require({p.relative_to(runtime).as_posix():info(p) for p in runtime.rglob('*') if p.is_file()}==app['runtime'],'stage whole40 mismatch')
 put(B/'runtime-stage-before.json',tree(runtime))
 repair_owned_runtime('owned-stage-mode-changes',runtime,app['runtime'],True)
 repair_owned_runtime('owned-cache-runtime-mode-changes',B/'cargo-target/debug/runtime',app['runtime'])
 # Current b79 renderer compile-input reuse, source relation and exact actual bytes.
 require(sha(APP/'renderer-output-tree.json')=='10a4e49b7ce20d7266fcca3e6678d6568c28254c4cce89658d40e0719abaa0c9','renderer map mismatch')
 renderer_inputs=[n for n in EXPECTED if n.startswith('apps/desktop/') and not n.startswith('apps/desktop/src-tauri/')]
 require(all(info(S/n)==info(APP/'source'/n)==EXPECTED[n] for n in renderer_inputs),'current renderer source applicability mismatch')
 distmap=load(APP/'renderer-output-tree.json')
 require(tree(APP/'source/apps/desktop/dist')==distmap,'actual fresh b79 dist mismatch')
 clone('04-owned-current-renderer-copy',APP/'source/apps/desktop/dist',S/'apps/desktop/dist')
 require(tree(S/'apps/desktop/dist')==distmap,'owned renderer compile-input mismatch')
 put(B/'renderer-compile-input-reuse.json',{'actual_tree':distmap,'source_inputs':{n:EXPECTED[n] for n in renderer_inputs},'fresh_build_credit':False})
 (B/'logical-paths.nul').write_bytes(b'\0'.join(n.encode() for n in EXPECTED)+b'\0')
 command('05-owned-git-init',['/usr/bin/git','-c','core.hooksPath=/dev/null','init','--template='+str(B/'empty-git-template'),S],60)
 command('06-owned-git-add',['/usr/bin/git','-c','core.hooksPath=/dev/null','add','--force','--pathspec-from-file='+str(B/'logical-paths.nul'),'--pathspec-file-nul'],60)
 g=command('07-owned-git-write-tree',['/usr/bin/git','write-tree']);treeid=(g/'stdout').read_text().strip()
 git_env=dict(ENV);git_env.update({'GIT_AUTHOR_NAME':'Synthetic W05 proof','GIT_AUTHOR_EMAIL':'proof@example.invalid','GIT_COMMITTER_NAME':'Synthetic W05 proof','GIT_COMMITTER_EMAIL':'proof@example.invalid','GIT_AUTHOR_DATE':'2026-10-19T00:00:00+00:00','GIT_COMMITTER_DATE':'2026-10-19T00:00:00+00:00'})
 g=command('08-owned-git-commit-tree',['/usr/bin/git','commit-tree',treeid,'-m','Exact approved outside W05 source proof'],60,environment=git_env)
 commit=(g/'stdout').read_text().strip();command('09-owned-git-update-ref',['/usr/bin/git','update-ref','HEAD',commit])
 put(B/'isolated-git-input.json',{'tree':treeid,'commit':commit,'source_manifest_sha256':MANIFEST,'canonical_adoption':False})
 for label,tool,args in [('cargo',RUST/'cargo',['--version']),('rustc',RUST/'rustc',['-Vv']),('clang',Path('/usr/bin/clang'),['--version']),('python',S/'.venv/bin/python',['--version'])]:
  command('tool-'+label,[tool,*args])
 put(B/'tool-executables.json',{n:exeinfo(p) for n,p in [('cargo',RUST/'cargo'),('rustc',RUST/'rustc'),('clang',Path('/usr/bin/clang')),('python',S/'.venv/bin/python')]})
 inv=load(JOIN/'approved-plan/planned-test-inventory.json');expected=set(inv['all_ids']);actors=set(inv['planned_runtime_actor_ids'])
 require(len(expected)==183 and len(actors)==19 and actors<=expected,'planned catalog mismatch')
 allmodes={}
 for mode,features in [('default',[]),('allfeatures',['--all-features']),('sdk-custom',['--features','tauri/custom-protocol'])]:
  d=command(mode+'-compile',[RUST/'cargo','test','--locked','--offline','-j2','--manifest-path','apps/desktop/src-tauri/Cargo.toml',*features,'--no-run','--message-format=json'],600)
  artifacts=[]
  for line in (d/'stdout').read_text().splitlines():
   x=json.loads(line)
   if x.get('reason')!='compiler-artifact' or not x.get('executable') or not x.get('profile',{}).get('test'):continue
   if '#japp-desktop@' not in x.get('package_id',''):continue
   require(x['package_id'].startswith('path+file://'+str(S/'apps/desktop/src-tauri')),'compiler package not owned source')
   p=Path(x['executable']);require(p.is_file() and p.is_relative_to(B/'cargo-target'),'compiler executable outside owned cache')
   target=B/'binaries'/mode/p.name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
   artifacts.append({'original':str(p),'retained':str(target),'file':info(target),'compiler_artifact':x})
  require(bool(artifacts),'no native test artifact')
  put(B/(mode+'-artifacts-upfront.json'),artifacts)
  union=set()
  for i,x in enumerate(artifacts):
   d=command(mode+'-'+str(i)+'-list',[x['retained'],'--list'])
   raw_ids=[line[:-6] for line in (d/'stdout').read_text().splitlines() if line.endswith(': test')]
   put(d/'catalog-parsed.json',{'raw_ordered_ids':raw_ids,'raw_count':len(raw_ids),'unique_count':len(set(raw_ids))})
   require(len(raw_ids)==len(set(raw_ids)),'duplicate compiler identity within artifact')
   names=set(raw_ids)
   require(not union&names,'duplicate compiler identity across artifacts');union|=names
   x['raw_ordered_listed_ids']=list(raw_ids);x['listed_ids']=sorted(names)
  put(B/(mode+'-collection.json'),{'actual_ids':sorted(union),'expected_ids':sorted(expected),'exact183':union==expected,'artifacts':artifacts})
  require(union==expected,'actual compiler identity mismatch '+mode)
  allmodes[mode]=artifacts
 # ALL three complete lists pass before the first suite is launched.
 put(B/'compiler-list-barrier.json',{'all_three_exact183':True,'actual_tests_executed_so_far':False,'modes':list(allmodes),'utc':now()})
 results={}
 for mode,artifacts in allmodes.items():
  seen=[]
  for i,x in enumerate(artifacts):
   require(info(x['retained'])==x['file'],'retained binary changed before execution')
   d=command(mode+'-'+str(i)+'-tests',[x['retained'],'--test-threads=1'],240)
   text=(d/'stdout').read_text();ids=re.findall(r'^test (.+) \.\.\. ok$',text,flags=re.M)
   require(len(ids)==len(x['listed_ids']) and set(ids)==set(x['listed_ids']),'exact test identities missing/extra')
   require(re.search(r'test result: ok\. \d+ passed; 0 failed; 0 ignored; \d+ measured; 0 filtered out;',text) is not None,'test summary missing or skipped')
   require(info(x['retained'])==x['file'],'retained binary changed after execution');seen.extend(ids)
  require(len(seen)==183 and set(seen)==expected,'183 actual results mismatch')
  results[mode]={'all183_PASS':True,'pure_mock164':sorted(expected-actors),'existing_runtime_socket19':sorted(actors),'serial_test_threads':1,'not_canonical_default_parallel':True}
  put(B/(mode+'-actual-results.json'),results[mode])
 require(applicability(source_roots)==app,'runtime applicability changed after actors')
 require(tree(S/'apps/desktop/dist')==distmap,'renderer compile input changed')
 require({p.relative_to(runtime).as_posix():info(p) for p in runtime.rglob('*') if p.is_file()}==app['runtime'],'runtime stage bytes changed')
 put(B/'owned-venv-tree-after-actors.json',tree(S/'.venv'))
 require(load(B/'tool-executables.json')=={n:exeinfo(p) for n,p in [('cargo',RUST/'cargo'),('rustc',RUST/'rustc'),('clang',Path('/usr/bin/clang')),('python',S/'.venv/bin/python')]},'tool executable changed during campaign')
 logical(S);logical(JOIN/'source');root_projection('canonical-context-after')
 command('owned-git-tracked-clean',['/usr/bin/git','diff','--exit-code','HEAD','--'])
 status=command('owned-git-status',['/usr/bin/git','status','--porcelain=v1','--untracked-files=normal'])
 require(not (status/'stdout').read_text().strip(),'owned source has untracked logical changes')
 put(B/'FINAL_REPORT.json',{'scope':'OUTSIDE_MACOS_SERIAL183x3_NATIVE_ONLY','actual_modes':results,'source_manifest_sha256':MANIFEST,'source1850_unchanged':True,'runtime135_plus_requirements_wheels40_unchanged':True,'all_records_environment_snapshots':True,'all_owned_commands_exit0':True,'rootwrites':False,'whole_root_neutrality':False,'native_GUI':False,'real_RestartOwner_recovery_actor_proof':False,'canonical_acceptance':False,'separate187derivative':False})
 print(json.dumps(load(B/'FINAL_REPORT.json')),flush=True)

if __name__=='__main__':
 try:main()
 except BaseException as exc:
  # Preserve setup/product failures and closed commands; no retry or expectation change.
  put(B/'FAILED_CAMPAIGN.json',{'utc':now(),'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc(),'closed_commands':copy.deepcopy(RECORDS),'wrapper_sha256':sha(__file__),'actor_or_compile_credit':'ONLY_ACTUAL_CLOSED_RAW_RESULTS','automatic_retry':False})
  raise
