"""After terminal wrapper closure only: finite183 native source/data retention."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,shutil,tarfile
B=Path('/tmp/japp-m03-w05-current-native-execution-20261019')
D=B.with_name(B.name+'-retained')
J=Path('/tmp/japp-m03-w05-current-source-join-20261019')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def info(p):return {'bytes':Path(p).stat().st_size,'sha256':sha(p)}
def load(p):return json.loads(Path(p).read_text())
def put(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
assert not D.exists() and (B/'FINAL_REPORT.json').is_file() and not (B/'FAILED_CAMPAIGN.json').exists()
assert sha(B/'run_native_focus.py')=='3d76fab413b6835a7146ff54ca2a5a11dccb2dca5ab7111714878ba517d1f257'
manifest=load(B/'source-manifest.json');assert sha(B/'source-manifest.json')=='ee091e710086c6149d019c9ac58aed68f6b8b8dedee31b572dfabedba36f4f47'
for n,v in manifest.items():assert info(B/'source'/n)==v
records=load(B/'closed-command-records.json');assert all(x['exit_code']==0 and not x['timed_out'] and x['owned_pid_reaped'] for x in records)
# Closure environments must match their original immutable per-command upfront/result.
for rec in records:
 d=B/'checks'/rec['label'];up=load(d/'upfront.json');result=load(d/'result.json')
 assert up['environment']==result['environment']==rec['environment']
 assert result==rec and info(d/'stdout')==rec['stdout'] and info(d/'stderr')==rec['stderr']
barrier=load(B/'compiler-list-barrier.json');assert barrier['all_three_exact183'] and not barrier['actual_tests_executed_so_far']
inv=load(J/'approved-plan/planned-test-inventory.json');expected=set(inv['all_ids']);actors=set(inv['planned_runtime_actor_ids']);assert len(expected)==183 and len(actors)==19
modes={};physical=[]
for mode in ['default','allfeatures','sdk-custom']:
 cat=load(B/(mode+'-collection.json'));assert cat['exact183'] and set(cat['actual_ids'])==expected
 actual=[];listed=[];receipts=[]
 for i,a in enumerate(cat['artifacts']):
  d=B/'checks'/(mode+'-'+str(i)+'-list');raw=[x[:-6] for x in (d/'stdout').read_text().splitlines() if x.endswith(': test')]
  assert len(raw)==len(set(raw)) and raw==a['raw_ordered_listed_ids'];listed+=raw
  d=B/'checks'/(mode+'-'+str(i)+'-tests');up=load(d/'upfront.json');assert up['started_utc']>=barrier['utc']
  ids=re.findall(r'^test (.+) \.\.\. ok$',(d/'stdout').read_text(),re.M);assert len(ids)==len(raw) and set(ids)==set(raw)
  assert info(a['retained'])==a['file'];physical.append({'mode':mode,'retained':a['retained'],'file':a['file'],'original_compiler_output':a['original'],'in_archive':False,'retained_beside_packet':True})
  actual+=ids;receipts.append({'artifact_index':i,'actual_passed':len(ids),'list_upfront':info(B/'checks'/(mode+'-'+str(i)+'-list')/'upfront.json'),'test_upfront':info(d/'upfront.json'),'test_result':info(d/'result.json')})
 assert len(listed)==len(set(listed))==len(actual)==183 and set(actual)==expected
 modes[mode]={'actual_compiler_catalog183':True,'actual_passed183':True,'actual_pure_mock164':len(set(actual)-actors),'actual_existing_runtime_socket19':len(set(actual)&actors),'ignored':0,'filtered':0,'serial_threads':1,'artifacts':receipts}
app=load(B/'applicability-before-owned-mode-changes.json');runtime=B/'source/apps/desktop/src-tauri/runtime-payload'
assert {p.relative_to(runtime).as_posix():info(p) for p in runtime.rglob('*') if p.is_file()}==app['runtime']
venv_before=load(B/'owned-venv-tree-before-actors.json');venv_after=load(B/'owned-venv-tree-after-actors.json');vchanges=[n for n in sorted(set(venv_before)|set(venv_after)) if venv_before.get(n)!=venv_after.get(n)]
# Describe actual cache writes rather than claiming an identical Python environment tree.
put(B/'physical-binary-join.json',{'binaries':physical,'scope':'ACTUAL_RETAINED_BINARY_BYTES_REHASHED_NOT_DUPLICATED_IN_FINITE_ARCHIVE'})
put(B/'CLOSED_DATA_REPORT.json',{'closed_utc':datetime.now(timezone.utc).isoformat(),'scope':'ACTUAL_OUTSIDE_MACOS_SERIAL183x3_ONLY','source1850_manifest':info(B/'source-manifest.json'),'source1850_actual_bytes_verified':True,'modes':modes,'commands_exit0':len(records),'every_environment_matches_original_upfront_and_result':True,'all3_catalogs_before_any_suite':True,'runtime40_stage_byte_exact':True,'actual_mode_repairs':{'stage':load(B/'owned-stage-mode-changes.json')['actual_changes'],'cache_runtime':load(B/'owned-cache-runtime-mode-changes.json')['actual_changes']},'venv_actor_time_changed_paths':vchanges,'venv_changes_are_all_pycache':all(n.endswith('.pyc') for n in vchanges),'no_provider_real_RestartOwner_recovery_GUI_crossplatform_CI_or_milestone_credit':True,'normal_fixture_cleanup_scope':'Passing existing assertions and reaped direct command PIDs; outside-owned-group OS descendants UNOBSERVED','root_scope':'Read-only mutable21path projection; no whole-root-neutrality claim','separate187_campaign':'NOT_EXECUTED'})
shutil.copytree(J/'selected-postimages',B/'selected-postimages')
shutil.copytree(J/'selected-preimages',B/'selected-preimages')
for n in ['planned-nine-path.patch','planned-test-inventory.json','exact-deltas.json']:
 shutil.copyfile(J/'approved-plan'/n,B/n)
shutil.copyfile(Path(__file__),B/'seal_native_focus.executed.py')
(B/'README.md').write_text('''# Current W05 serial native campaign\n\nActual exact1850 ee091e source, reviewed3d76 wrapper, approved929e plan and phase-clear input are bound. ALL three complete compiler catalogs equal183 before any test suite. Default/allfeatures/direct SDK each execute183, with164 pure/mock plus19 existing Python/client/TCP/HTTP actor identities, zero skipped/filtered. Suites are serialthreads1; this is not a canonical default-parallel full run. Existing19 actors are not new real shipping RestartOwner recovery proof; the separate187 derivative is unexecuted here.\n\nActual135 source applicability, real build lock/runtime requirements, both wheels, complete40 staged runtime and current b79 renderer4 compile input are retained as exact maps. No new Python/renderer build credit. Stage/cache runtime permission repair count is actually0/0. The source remains1850 byte-exact; owned venv bytecode differences are reported rather than falsely called unchanged.\n\nAll closed command environments equal their original immutable upfront/result. Raw outputs, actual direct owned PIDs/returns and source/tool/runtime/binary bindings remain; successful existing fixture cleanup is not a whole-machine descendant certificate. Root was read only with a named mutable21path projection; no whole-root stability/acceptance claim. No installs, GUI, signing credentials, real data, GitHub or production provider change occurred.\n\nThe finite archive retains selected source/delta/manifest, all command records/raw outputs and report bindings. The full346MB source, native binaries, owned caches/venv and prior640MB app packet are not duplicated. Actual rehashed binaries remain at the exact paths in physical-binary-join.json; complete source is beside the packet and reconstructible from approvedb79+9pathdelta. Original uninvoked wrapper defects/drafts and the syntax-only correction attempt remain preserved and separate from this successful actor campaign.\n''')
exclude={'source','cargo-target','binaries','tmp'}
files=sorted([p for p in B.rglob('*') if p.is_file() and p.relative_to(B).parts[0] not in exclude and p.name!='proof-inputs.json'],key=lambda x:x.relative_to(B).as_posix())
inputs={p.relative_to(B).as_posix():info(p) for p in files};put(B/'proof-inputs.json',{'scope':'FINITE_CLOSED_SELECTED183_NATIVE_EVIDENCE','files':inputs,'full_source_and_binary_caches_excluded':True});files.append(B/'proof-inputs.json')
D.mkdir();archive=D/'proof.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=B.name+'/'+p.relative_to(B).as_posix(),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for member in t.getmembers():
  n=member.name.split('/',1)[1];assert hashlib.sha256(t.extractfile(member).read()).hexdigest()==sha(B/n)
for n,v in inputs.items():assert info(B/n)==v
out={'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'data_report_sha256':sha(B/'CLOSED_DATA_REPORT.json'),'final_report_sha256':sha(B/'FINAL_REPORT.json'),'physical_binary_join_sha256':sha(B/'physical-binary-join.json'),'all_selected_members_rehashed':True,'all_actor_commands_closed':True,'no_active_compiler_or_actor_owned_by_wrapper':True,'authority':'NONE','scope':'OUTSIDE_MACOS_SERIAL183x3_ONLY'}
put(D/'archive-manifest.json',out);print(json.dumps(out,indent=2))
