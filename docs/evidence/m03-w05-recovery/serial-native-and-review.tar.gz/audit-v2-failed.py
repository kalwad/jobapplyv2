"""Independent finite data audit of closed serial183 native campaign; no actors."""
import datetime as dt,hashlib,json,pathlib,re,stat,tarfile
ROOT=pathlib.Path('/tmp/japp-m03-w05-native-data-independent-review-20261019/attempt2')
AUTHOR=pathlib.Path('/tmp/japp-m03-w05-current-native-execution-20261019')
ARCHIVE=pathlib.Path(str(AUTHOR)+'-retained/proof.tar.gz')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def digest(path):
 before=path.stat();h=hashlib.sha256();count=0
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk);count+=len(chunk)
 after=path.stat();assert (before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns)
 return {'bytes':count,'sha256':h.hexdigest()}
def load(p):return json.loads(p.read_bytes())
def save(name,value):
 p=ROOT/name;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2)+'\n')
assert digest(ARCHIVE)=={'bytes':787358,'sha256':'6b29fb2512a9d0a5f502218e138d696a4447bbaab23a0cc6754d2fe768d980fa'}
inputs=ROOT/'author';inputs.mkdir(parents=True);members=[];seen=set()
with tarfile.open(ARCHIVE,'r:gz') as tar:
 for member in tar:
  name=member.name;p=pathlib.PurePosixPath(name)
  assert member.isfile() and not p.is_absolute() and '..' not in p.parts and '\\' not in name and '\0' not in name and name.casefold() not in seen
  seen.add(name.casefold());raw=tar.extractfile(member).read();assert len(raw)==member.size
  assert p.parts[0]==AUTHOR.name
  relative=pathlib.PurePosixPath(*p.parts[1:]).as_posix()
  target=inputs/relative;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();target.write_bytes(raw)
  members.append({'path':relative,'archive_member':name,'bytes':len(raw),'sha256':sha(raw),'mode':member.mode})
assert len(members)==255
manifest=load(inputs/'proof-inputs.json');assert len(manifest['files'])==254
for row in members:
 if row['path']=='proof-inputs.json':continue
 assert manifest['files'][row['path']]=={k:row[k] for k in ['bytes','sha256']}
 assert digest(AUTHOR/row['path'])==manifest['files'][row['path']]
save('author-archive-binding.json',{'archive':str(ARCHIVE),'bytes':787358,'sha256':'6b29fb2512a9d0a5f502218e138d696a4447bbaab23a0cc6754d2fe768d980fa','members':members,'all255_members_and254_original_loose_files_byte_checked':True,'source_caches_and_binaries_not_duplicated':True})
source=load(inputs/'source-manifest.json');assert len(source)==1850 and digest(inputs/'source-manifest.json')['sha256']=='ee091e710086c6149d019c9ac58aed68f6b8b8dedee31b572dfabedba36f4f47'
assert {name:digest(AUTHOR/'source'/name) for name in source}==source
report=load(inputs/'CLOSED_DATA_REPORT.json');assert digest(inputs/'CLOSED_DATA_REPORT.json')['sha256']=='1fcd1464943c82a805352c337e254f8253b4804841ed00aa5884fb0169ff1291'
records=load(inputs/'closed-command-records.json');assert len(records)==36
bylabel={r['label']:r for r in records};assert len(bylabel)==36
commands=[]
for row in records:
 folder=inputs/'checks'/row['label'];upfront=load(folder/'upfront.json');result=load(folder/'result.json');launch=load(folder/'launch.json')
 assert result==row and all(row[k]==v for k,v in upfront.items())
 assert launch['upfront_sha256']==digest(folder/'upfront.json')['sha256']
 assert row['owned_pid']==launch['owned_pid'] and row['owned_process_group']==launch['owned_process_group']==row['owned_pid']
 assert row['exit_code']==0 and row['timed_out'] is False and row['owned_pid_reaped'] is True and row['timeout_cleanup']==[]
 assert row['executable_before']==row['executable_after'] and row['source_manifest_sha256']==report['source1850_manifest']['sha256']
 assert row['input_bindings_before']==row['input_bindings_after']
 for stream in ['stdout','stderr']:assert digest(folder/stream)==row[stream]
 for name,entry in row['input_bindings_before'].items():
  if name in ['actual_runtime40','actual_interpreter']:continue
  assert digest(inputs/name)==entry
 if isinstance(row['source_after'],dict):assert row['source_after']=={'paths':1850,'manifest_sha256':report['source1850_manifest']['sha256']}
 commands.append({'label':row['label'],'argv':row['argv'],'started_utc':row['started_utc'],'ended_utc':row['ended_utc'],'exit_code':0,'environment_matches_upfront_result_and_catalog':True})
save('independent-command-review.json',{'count':36,'commands':commands,'all_environment_and_raw_bindings_match':True,'no_replay':True})
barrier=load(inputs/'compiler-list-barrier.json');assert barrier['all_three_exact183'] and barrier['actual_tests_executed_so_far'] is False
test_records=[r for r in records if r['label'].endswith('-tests')];list_records=[r for r in records if r['label'].endswith('-list')]
assert len(test_records)==len(list_records)==6
assert max(r['ended_utc'] for r in list_records)<barrier['utc']<min(r['started_utc'] for r in test_records)
planned=load(inputs/'planned-test-inventory.json');expected=planned['all_ids'];assert len(expected)==len(set(expected))==183
assert planned['planned_native_count']==183 and planned['planned_pure_mock']==164 and planned['planned_runtime_socket']==19
binary_join=load(inputs/'physical-binary-join.json');assert len(binary_join['binaries'])==6
binary_actual=[]
for row in binary_join['binaries']:
 assert digest(pathlib.Path(row['retained']))==row['file'] and row['in_archive'] is False and row['retained_beside_packet'] is True
 binary_actual.append({'mode':row['mode'],'path':row['retained'],**row['file']})
mode_summaries=[]
for mode in ['default','allfeatures','sdk-custom']:
 collection=load(inputs/(mode+'-collection.json'));actual=load(inputs/(mode+'-actual-results.json'))
 assert collection['exact183'] and collection['actual_ids']==collection['expected_ids']==expected
 assert actual['all183_PASS'] and actual['serial_test_threads']==1 and actual['not_canonical_default_parallel']
 assert len(actual['pure_mock164'])==164 and len(actual['existing_runtime_socket19'])==19
 assert set(actual['pure_mock164']).isdisjoint(actual['existing_runtime_socket19']) and set(actual['pure_mock164'])|set(actual['existing_runtime_socket19'])==set(expected)
 assert actual['existing_runtime_socket19']==planned['planned_runtime_actor_ids']
 artifacts=collection['artifacts'];assert len(artifacts)==2
 compile_record=bylabel[mode+'-compile'];compile_lines=(inputs/'checks'/(mode+'-compile')/'stdout').read_text().splitlines()
 emitted=[json.loads(line) for line in compile_lines if line.startswith('{')]
 counts=[]
 for index,artifact in enumerate(artifacts):
  record=bylabel[f'{mode}-{index}-tests'];listing=bylabel[f'{mode}-{index}-list']
  assert record['argv']==[artifact['retained'],'--test-threads=1'] and listing['argv'][0]==artifact['retained']
  assert record['executable_before']['sha256']==listing['executable_before']['sha256']==artifact['file']['sha256']
  assert artifact['compiler_artifact'] in emitted and artifact['compiler_artifact']['executable']==artifact['original']
  raw_list=(inputs/'checks'/listing['label']/'stdout').read_text()
  listed=re.findall(r'^(.+): test$',raw_list,re.M);assert listed==artifact['raw_ordered_listed_ids'] and sorted(listed)==artifact['listed_ids']
  raw_test=(inputs/'checks'/record['label']/'stdout').read_text();passed=re.findall(r'^test (.+) \.\.\. ok$',raw_test,re.M)
  assert sorted(passed)==artifact['listed_ids']
  footer=re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',raw_test,re.M)
  assert len(footer)==1 and tuple(int(x) for x in footer[0])==(len(passed),0,0,0,0)
  counts.append(len(passed))
 assert counts==[183,0]
 mode_summaries.append({'mode':mode,'listed_and_passed':183,'pure_mock':164,'existing_runtime_socket':19,'main_target_passed':0,'serial_threads':1,'all_zero_failed_ignored_measured_filtered':True})
applicability=load(inputs/'applicability-before-owned-mode-changes.json');assert len(applicability['source_inputs'])==135 and len(applicability['runtime'])==40 and applicability['new_Python_build_credit'] is False
for base in applicability['sources']:
 assert {name:digest(pathlib.Path(base)/name) for name in applicability['source_inputs']}==applicability['source_inputs']
runtime_root=AUTHOR/'source/apps/desktop/src-tauri/runtime-payload'
assert {name:digest(runtime_root/name) for name in applicability['runtime']}==applicability['runtime']
runtime_manifest=load(runtime_root/'manifest.json');assert {x['path'] for x in runtime_manifest['files']}|{'manifest.json'}==set(applicability['runtime'])
for x in runtime_manifest['files']:assert applicability['runtime'][x['path']]=={k:x[k] for k in ['bytes','sha256']}
original_runtime=pathlib.Path('/tmp/japp-m03-w04-preparation-wheels-runtime-20261018')
for name,entry in applicability['wheels'].items():assert digest(original_runtime/'wheels'/name)==entry
for key,path in [('build',AUTHOR/'source/scripts/service-build-tools.requirements.lock'),('runtime',pathlib.Path('/tmp/japp-m03-w02-service-proposal/proof/wheel-runtime-requirements.txt'))]:
 entry=applicability['additional_locks'][key];assert digest(path)==entry and runtime_manifest['source_inputs'][('build_requirements' if key=='build' else 'runtime_requirements')+'_sha256']==entry['sha256']
assert (inputs/'owned-venv-tree-before-actors.json').read_bytes()==(inputs/'owned-venv-tree-after-actors.json').read_bytes()
for name in ['owned-stage-mode-changes.json','owned-cache-runtime-mode-changes.json']:
 value=load(inputs/name);assert value['actual_changes']==0 and value['changes']==[]
context_before=load(inputs/'canonical-context-before.json');context_after=load(inputs/'canonical-context-after.json')
assert context_before['scope']==context_after['scope']=='READ_ONLY_NAMED_MUTABLE_ROOT_PROJECTION_NO_WHOLE_ROOT_NEUTRALITY'
assert context_before['paths']==context_after['paths']
result={'result':'CLEAR_FOR_CLOSED_SOURCE_DATA_AND_SERIAL183x3_ONLY','source1850_actual_bytes_match_ee091':True,'finite_author_archive_sha256':'6b29fb2512a9d0a5f502218e138d696a4447bbaab23a0cc6754d2fe768d980fa','all255_archive_members_and254_original_files_checked':True,'all36_commands_closed0_raw_environment_source_and_launch_bindings_match':True,'compiler_barrier_all3_catalogs_before_first_test':True,'modes':mode_summaries,'actual_physical_binary_count':6,'actual_physical_binary_bytes':sum(x['bytes'] for x in binary_actual),'physical_binary_bindings':binary_actual,'runtime135_all_four_actual_source_projections_and_locks_wheels40_match':True,'mode_changes':0,'venv_actor_time_changes':0,'root_scope':'Recorded named mutable projection only; reviewer never reads root and claims no whole-root neutrality.','limitations':['Serial test-thread1 campaign; no canonical default parallel proof.','164 pure/mock and19 existing runtime/socket tests per mode; no new real RestartOwner recovery actor proof.','No GUI, provider, cross-platform, hosted CI, root adoption, W05 completion or milestone acceptance credit.','Normal passing fixture assertions and direct owned PID reap only; outside-group OS descendants remain unobserved.','Full dependency/cache images and full apps are neither copied nor independently certified.']}
save('review.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in ['physical_binary_bindings','limitations']},indent=2))
