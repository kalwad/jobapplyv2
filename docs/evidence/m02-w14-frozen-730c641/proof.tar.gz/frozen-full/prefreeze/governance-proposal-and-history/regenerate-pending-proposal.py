from pathlib import Path
import difflib
import hashlib
import json
import re
base = Path('/tmp/japp-w14-governance-ki0096')
old_manifest = json.loads((base/'history/pending-001/proposal-pending-manifest.json').read_text())
paths = [item['path'] for item in old_manifest['paths']]
fixture = 'scripts/tests/test_validate_status.py'
before = (base / 'preimages' / fixture).read_text()
after = (base / 'afterimages' / fixture).read_text()
added_lines = [
    '    "KI-0096",\n',
    '            "- KI-0096 (HIGH, IN_PROGRESS) — synthetic later metadata timing finding",\n',
    '            "- KI-0096 (HIGH, IN_PROGRESS) — synthetic current metadata timing issue",\n',
]
stripped = after
for line in added_lines:
    if stripped.splitlines(keepends=True).count(line) != 1:
        raise SystemExit(f'Expected exactly one additive fixture literal: {line!r}')
    stripped = stripped.replace(line, '', 1)
if stripped != before:
    raise SystemExit('Fixture differs beyond the three exact additive literals')
patch = ''
entries = []
for relative in paths:
    pre = (base / 'preimages' / relative).read_bytes()
    post = (base / 'afterimages' / relative).read_bytes()
    patch += f'diff --git a/{relative} b/{relative}\n'
    patch += ''.join(difflib.unified_diff(pre.decode().splitlines(keepends=True), post.decode().splitlines(keepends=True), fromfile='a/'+relative, tofile='b/'+relative))
    entries.append({'path': relative, 'preimage_sha256': hashlib.sha256(pre).hexdigest(), 'afterimage_sha256': hashlib.sha256(post).hexdigest()})
(base / 'governance-pending.patch').write_text(patch)
manifest = {
    'format_version': 'W14_KI0096_GOVERNANCE_PROPOSAL_2',
    'scope': 'Outside-only four governance docs and exactly three existing corrective finding-list additions; no assertion/test identity changes.',
    'state': 'PENDING_OPTIMIZATION_ARCHIVE_PEER_AND_R9_SEAL_ROOT_MUST_RESOLVE_BEFORE_APPLY',
    'previous_proposal': 'history/pending-001/governance-pending.patch',
    'previous_proposal_sha256': hashlib.sha256((base / 'history/pending-001/governance-pending.patch').read_bytes()).hexdigest(),
    'paths': entries,
    'pending_tokens': sorted(set(re.findall(r'__PENDING_[A-Z0-9_]+__', patch))),
    'patch_sha256': hashlib.sha256((base / 'governance-pending.patch').read_bytes()).hexdigest(),
    'patch_bytes': (base / 'governance-pending.patch').stat().st_size,
    'fixture_literal_only_comparison': 'PASS_SOURCE_ONLY_THREE_LINES_REMOVED_EQUAL_PREIMAGE',
    'preparation_attempts': ['revise-pending-proposal.py: document preparation completed; source-only fixture comparison rejected an eight-space expected substring inside twelve-space literal. No fixture source changed.', 'regenerate-pending-proposal.py: exact whole-line/twelve-space comparison passes.'],
    'root_checks_tests_builds_browsers_writes': 0,
}
(base / 'proposal-pending-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(manifest, indent=2))
