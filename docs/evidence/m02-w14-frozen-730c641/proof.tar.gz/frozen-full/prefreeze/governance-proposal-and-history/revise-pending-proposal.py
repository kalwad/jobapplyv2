from pathlib import Path
import difflib
import hashlib
import json
import re
import shutil

base = Path('/tmp/japp-w14-governance-ki0096')
history = base / 'history/pending-001'
if history.exists():
    raise SystemExit('Refusing to overwrite historical pending-001')
history.mkdir(parents=True)
for name in ('governance-pending.patch', 'proposal-pending-manifest.json'):
    shutil.copy2(base / name, history / name)
shutil.copytree(base / 'afterimages', history / 'afterimages')

paths = [item['path'] for item in json.loads((base / 'proposal-pending-manifest.json').read_text())['paths']]
for relative in paths:
    p = base / 'afterimages' / relative
    text = p.read_text()
    text = text.replace(
        'Revision8 coordinator remains UNEXECUTED after the full-run failure guard; candidate/legacy actor counts are0.',
        'Revision8 coordinator is source-reviewed but NEVER INVOKED, UNEXECUTED and UNRELEASED because the full run failed; candidate/legacy actor counts are0. The reviewed guard would refuse that failed full run, but no coordinator invocation or guard-refusal execution is claimed.'
    ).replace(
        'Revision8 coordinator is UNEXECUTED after the failed full-run guard, with candidate/legacy actors0;',
        'Revision8 coordinator is source-reviewed but NEVER INVOKED, UNEXECUTED and UNRELEASED because the full run failed, with candidate/legacy actors0;'
    ).replace(
        'Revision8 coordinator is UNEXECUTED after that aggregate-failure guard, with candidate0/legacy0.',
        'Revision8 coordinator is source-reviewed but NEVER INVOKED, UNEXECUTED and UNRELEASED because that aggregate failed, with candidate0/legacy0. No executed guard-refusal proof is claimed.'
    ).replace(
        'All1478 tracked blobs and source/build/declaration endpoints are retained.',
        'Root independently retains unchanged head/status/all1478 tracked blobs; contact-campaign source/build/declaration endpoints are separately retained and unchanged.'
    )
    replacements = {
        '__PENDING_OPTIMIZATION_PROOF_PATH__': 'docs/evidence/m02-w14-build-result-concurrency/proof.tar.gz',
        '__PENDING_OPTIMIZATION_PROOF_SHA256__': '2620c4c3706a78f4895c5dc9e67450f0924b45d2f5d5ab5bd6fe94d5e09628ef',
        '__PENDING_OPTIMIZATION_PROOF_BYTES__': '4275812',
        '__PENDING_OPTIMIZATION_PROOF_MEMBERS__': '95',
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    if relative == 'docs/KNOWN_ISSUES.md':
        text = text.replace(
            'run the exact frozen target20 `pnpm verify` command recorded in docs/TEST_EVIDENCE.md § M02-W14.',
            'run the exact frozen outer Python-wrapper command recorded in docs/TEST_EVIDENCE.md § M02-W14; the wrapper records its `pnpm verify` child argv and target20 environment.'
        )
        text = text.replace(
            '4275812bytes/95members. Complete affected frozen regression remains pending;',
            '4275812bytes/95members;__PENDING_OPTIMIZATION_ARCHIVE_REVIEW_SCOPE__. Complete affected frozen regression remains pending;'
        )
    if relative == 'docs/gates/AUTOFILL_FEASIBILITY_GATE.md':
        text = text.replace(
            '4275812bytes/95members. Revision9 source-only preparation proof:',
            '4275812bytes/95members;__PENDING_OPTIMIZATION_ARCHIVE_REVIEW_SCOPE__. Revision9 source-only preparation proof:'
        )
    if relative == 'docs/TEST_EVIDENCE.md':
        start = text.index('#### Frozen focus integration failure and bounded metadata correction — 2026-10-16')
        end = text.index('#### Focus-value correction', start)
        section = '''#### Frozen focus integration failure and bounded metadata correction — 2026-10-16

The actual outer command at clean fc48930fd880795f72972fd97e2e69d68e636855/tree cb787f46afec1281c87074a82fd31e23b37c865a is `env PATH=/opt/homebrew/opt/node@24/bin:$PATH python3 /tmp/japp-w14-focus-frozen-20261016/run-frozen.py fc48930fd880795f72972fd97e2e69d68e636855`, 22:44:34Z–23:01:46Z. The wrapper records child argv `pnpm verify` and environment `JAPP_W13_PERFORMANCE_SAMPLES=20`, `JAPP_W14_REQUIRE_TARGET_PERFORMANCE=1`, `JAPP_W14_ARTIFACT_DIRECTORY=/tmp/japp-w14-focus-frozen-20261016/w14`; those records are not additional direct shell runs. Exit1: 18 active suites PASS/one FAIL; default browser241PASS/one native128 performance FAIL. P95 is1527.9433329999993ms against unchanged1500ms; every target sample preserves128actions/512resolutions/768descriptors. All8 permanent KI-0094 focus cases pass,3859 TypeScript units and62 controlled contact cases pass, and local Python1454/1454 passes299.26s. Contact200 separately retains precision/persistence1485/1485, required recall1275/1275, reporting770/770, preservation90/90 and full-settlement p95 871.287416999985ms. These passes do not turn the aggregate into PASS. Root independently establishes unchanged head/status/all1478 tracked blobs. Contact-campaign source/build/declaration endpoints are separately unchanged. Complete raw output, actual wrapper/recorded child commands and endpoints, independent Git-blob closure and reports: docs/evidence/m02-w14-frozen-fc48930/proof.tar.gz, SHA-256 **28e1132c7762c3327f0943bad8973625e74e8a14ff556d9ad0c12efacc564a0a**,5089970bytes/48 safe regular members; independent archive review passes21 checks. First audit/extraction corrections remain retained beside the corrected audit; the performance failure is not erased.

Revision8's coordinator is source-reviewed but NEVER INVOKED, UNEXECUTED and UNRELEASED because the full run failed, with candidate0/legacy0. The reviewed guard would refuse that failed full run, but root held the coordinator; no actual invocation, guard stop or executed refusal proof exists. Historical revision7 actor outcomes are not rerun or rebound. Exact source-only coordinator proof: docs/evidence/m02-w14-revision8-coordinator/proof.tar.gz, SHA-256 **9be801fefecb570931ad717d978cc5c058a2090db7045fae335f723c097fc3ff**,28025bytes/14members; archive peer review passes16 checks. KI-0094 remains IN_PROGRESS because complete affected regression and current-source comparison are pending. KI-0093/KI-0095 remain IN_PROGRESS pending fresh complete native Windows evidence; local1454PASS does not establish a cause for the unresolved contact environment F.

Root then integrates the independently source-reviewed one-file metadata correction in apps/extension/src/driver-engine.ts, final SHA-256 **22071b77f7610b315dc58f51275d3703f895c92f5f6c919f2efbbd275a312557**. The same seven immutable ID/evidence computations use a bounded Promise.allSettled join and original-order unwrapping. Every seed, field order, schema, live identity/validation/recovery check and execute/undo final authority witness stays unchanged; no cache limit, settle budget, threshold or coverage changes. Eventual raw rejection identity and original precedence are preserved; failure latency, in-flight work and cache-completion order may differ. Original patch3857cd00/b6d afterimage and the single unused-ESLint-comment correction remain retained. Root Prettier/typecheck/ESLint pass. Retained static-tool responses are derived records, not raw stdout; the initial unused-directive lint rejection is not represented as retained raw stdout. The released Node24.18.0 pure metadata AST differential passes3 full-JSON/property-order cases,7 single rejections,21 pairs and all-seven rejection precedence/identity, including non-Error reasons and handled secondary rejections. Initial Node26 guard and TypeScript6 module=None harness refusal precede the retained ESNext harness correction. This differential uses injected pure helpers and supplies no canonical-contract/browser/performance proof.

The actual affected-MV3 outer command is `env PATH=/opt/homebrew/opt/node@24/bin:$PATH python3 /tmp/japp-w14-build-result-affected-run.py`. Its wrapper records child argv `pnpm exec playwright test e2e/extension/extension-w14-result-ownership-peer.spec.ts e2e/extension/extension-w14-independent-undo-hash.spec.ts e2e/extension/extension-w14-native-validity.spec.ts e2e/extension/extension-w14-independent-extra.spec.ts e2e/extension/extension-w14-focus-value.spec.ts --trace on --output /tmp/japp-w14-build-result-affected-20261016/artifacts --reporter=list,json` and environment `PLAYWRIGHT_JSON_OUTPUT_NAME=/tmp/japp-w14-build-result-affected-20261016/results.json`; these are wrapper records, not additional direct shell runs. Exit0,21PASS in24.1s; source/status/head unchanged, completed23:06:56Z.

The separate actual target outer command is `env PATH=/opt/homebrew/opt/node@24/bin:$PATH python3 /tmp/japp-w14-build-result-target-run.py`. Its wrapper records child argv `pnpm exec playwright test e2e/extension/extension-benchmark.spec.ts --grep 'W13 L: total scan and re-resolution scaling includes work outside W11' --output /tmp/japp-w14-build-result-target-20261016/artifacts --reporter=list,json` and environment `JAPP_W13_PERFORMANCE_SAMPLES=20`, `JAPP_W14_REQUIRE_TARGET_PERFORMANCE=1`, `PLAYWRIGHT_JSON_OUTPUT_NAME=/tmp/japp-w14-build-result-target-20261016/results.json`; these are wrapper records, not additional direct shell runs. Exit0,one test/20 target samples, p95 **1473.5945839999986ms**, unchanged1500ms bound, completed23:11:06Z. Corrected355-file runtime is **3b6c0e0c0950b03e3bb9e1f12b27bb8d385174c36fb4b68ef3345597aa8b3502** at modified-root HEADfc/engine22071, distinct from the old clean fc source. Source/status/head are unchanged across each focused run; the retained build inventory is AFTER only and does not establish before/after build neutrality. Complete source/derived-static/differential/raw-affected/raw-target proof: docs/evidence/m02-w14-build-result-concurrency/proof.tar.gz, SHA-256 **2620c4c3706a78f4895c5dc9e67450f0924b45d2f5d5ab5bd6fe94d5e09628ef**,4275812bytes/95 safe regular members;__PENDING_OPTIMIZATION_ARCHIVE_REVIEW_SCOPE__. Focused timing is measured, but no isolated causal hash-cost attribution or complete changed-source aggregate PASS is claimed. KI-0096 stays HIGH/IN_PROGRESS pending complete affected frozen regression.

Revision9 source-only declaration preparation binds the changed355-file runtime, preserves all six revision8 files as history and retains revision7 observations. Proof: __PENDING_R9_DECLARATION_PROOF_PATH__, SHA-256 **__PENDING_R9_DECLARATION_PROOF_SHA256__**,__PENDING_R9_DECLARATION_PROOF_BYTES__bytes/__PENDING_R9_DECLARATION_PROOF_MEMBERS__members;__PENDING_R9_DECLARATION_REVIEW_SCOPE__. No revision8/revision9 actor, new public scored result, Simplify case, W15 approval or Gate A decision is supplied here. Public scored cases0/Simplify0,31/300 packages VERIFIED, W14/Gate A IN_PROGRESS, W15/M03 NOT_STARTED and release NOT_READY remain honest; holdout is WAIVED_BY_OWNER under ADR-0006.

'''
        text = text[:start] + section + text[end:]
    p.write_text(text)

fixture = 'scripts/tests/test_validate_status.py'
before = (base / 'preimages' / fixture).read_text()
after = (base / 'afterimages' / fixture).read_text()
added_lines = [
    '    "KI-0096",\n',
    '        "- KI-0096 (HIGH, IN_PROGRESS) — synthetic later metadata timing finding",\n',
    '        "- KI-0096 (HIGH, IN_PROGRESS) — synthetic current metadata timing issue",\n',
]
stripped = after
for line in added_lines:
    if stripped.count(line) != 1:
        raise SystemExit(f'Expected exactly one additive fixture literal: {line!r}')
    stripped = stripped.replace(line, '', 1)
if stripped != before:
    raise SystemExit('Fixture differs beyond the three exact additive literals')

patch = ''
entries = []
for relative in paths:
    pre = (base / 'preimages' / relative).read_bytes()
    post = (base / 'afterimages' / relative).read_bytes()
    patch += f'diff --git a/{relative} b/{relative}\n'
    patch += ''.join(difflib.unified_diff(pre.decode().splitlines(keepends=True), post.decode().splitlines(keepends=True), fromfile='a/'+relative, tofile='b/'+relative))
    entries.append({'path': relative, 'preimage_sha256': hashlib.sha256(pre).hexdigest(), 'afterimage_sha256': hashlib.sha256(post).hexdigest()})
(base / 'governance-pending.patch').write_text(patch)
pending = sorted(set(re.findall(r'__PENDING_[A-Z0-9_]+__', patch)))
manifest = {
    'format_version': 'W14_KI0096_GOVERNANCE_PROPOSAL_2',
    'scope': 'Outside-only four governance docs and exactly three existing corrective finding-list additions; no assertion/test identity changes.',
    'state': 'PENDING_OPTIMIZATION_ARCHIVE_PEER_AND_R9_SEAL_ROOT_MUST_RESOLVE_BEFORE_APPLY',
    'previous_proposal': 'history/pending-001/governance-pending.patch',
    'previous_proposal_sha256': hashlib.sha256((history / 'governance-pending.patch').read_bytes()).hexdigest(),
    'paths': entries,
    'pending_tokens': pending,
    'patch_sha256': hashlib.sha256((base / 'governance-pending.patch').read_bytes()).hexdigest(),
    'patch_bytes': (base / 'governance-pending.patch').stat().st_size,
    'fixture_literal_only_comparison': 'PASS_SOURCE_ONLY_THREE_LINES_REMOVED_EQUAL_PREIMAGE',
    'root_checks_tests_builds_browsers_writes': 0,
}
(base / 'proposal-pending-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(manifest, indent=2))
