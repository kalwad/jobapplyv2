from pathlib import Path, PurePosixPath
import difflib
import hashlib
import json
import re
import shutil
import tarfile

base = Path('/tmp/japp-w14-governance-ki0096')
root = Path('/Users/tanishkalwad/jobapplyv2')
history = base / 'history/pending-002'
if history.exists():
    raise SystemExit('Refusing to overwrite historical pending-002')
history.mkdir(parents=True)
for name in ('governance-pending.patch', 'proposal-pending-manifest.json'):
    shutil.copy2(base / name, history / name)
shutil.copytree(base / 'afterimages', history / 'afterimages')
old = json.loads((base / 'proposal-pending-manifest.json').read_text())
paths = [item['path'] for item in old['paths']]
fill = {
    '__PENDING_OPTIMIZATION_ARCHIVE_REVIEW_SCOPE__': ' independent archive peer review passes24 checks, distinct from the retained40-check actual-evidence audit',
    '__PENDING_R9_DECLARATION_PROOF_PATH__': 'docs/evidence/m02-w14-paired-revision9/proof.tar.gz',
    '__PENDING_R9_DECLARATION_PROOF_SHA256__': 'a46bbb17864f625138a44a49270776e13c519103e6deb5f7f8949c04c75b7d8c',
    '__PENDING_R9_DECLARATION_PROOF_BYTES__': '403370',
    '__PENDING_R9_DECLARATION_PROOF_MEMBERS__': '87',
    '__PENDING_R9_DECLARATION_REVIEW_SCOPE__': ' independent source peer review passes28 checks and separate archive peer review passes19 checks; scope is PRE-EXECUTION only',
}
for relative in paths:
    p = base / 'afterimages' / relative
    text = p.read_text()
    for token, value in fill.items():
        text = text.replace(token, value)
    if relative == 'docs/PROJECT_STATUS.md':
        text = text.replace(
            'revision9 source-only preparation does not execute a comparison.',
            'revision9 declaration is applied and its read-only loadCampaign preflight passes4 cases under the new72a68 lock; no revision9 actor is executed.'
        )
    if relative == 'docs/TEST_EVIDENCE.md':
        text = text.replace(
            'scope is PRE-EXECUTION only. No revision8/revision9 actor,',
            'scope is PRE-EXECUTION only. Root subsequently applies the reviewed revision9 declaration and its read-only loadCampaign preflight passes4 cases under the new72a68 lock. This supplies no actor execution or build and does not alter the earlier modified-fc optimization endpoints. No revision8/revision9 actor,'
        )
    if relative == 'docs/gates/AUTOFILL_FEASIBILITY_GATE.md':
        text = text.replace(
            'scope is PRE-EXECUTION only. No actor or final gate result is inferred.',
            'scope is PRE-EXECUTION only. Root applies revision9 and its read-only loadCampaign preflight passes4 cases under the new72a68 lock; no actor, build or final gate result is inferred.'
        )
    p.write_text(text)

fixture = 'scripts/tests/test_validate_status.py'
before = (base / 'preimages' / fixture).read_text()
after = (base / 'afterimages' / fixture).read_text()
added_lines = [
    '    "KI-0096",\n',
    '            "- KI-0096 (HIGH, IN_PROGRESS) — synthetic later metadata timing finding",\n',
    '            "- KI-0096 (HIGH, IN_PROGRESS) — synthetic current metadata timing issue",\n',
]
stripped = after
for line in added_lines:
    if stripped.splitlines(keepends=True).count(line) != 1:
        raise SystemExit(f'Expected exactly one whole-line additive fixture literal: {line!r}')
    stripped = stripped.replace(line, '', 1)
if stripped != before:
    raise SystemExit('Fixture differs beyond the three exact additive literals')

proofs = [
    ('docs/evidence/m02-w14-frozen-fc48930/proof.tar.gz', '28e1132c7762c3327f0943bad8973625e74e8a14ff556d9ad0c12efacc564a0a', 5089970, 48, 21),
    ('docs/evidence/m02-w14-revision8-coordinator/proof.tar.gz', '9be801fefecb570931ad717d978cc5c058a2090db7045fae335f723c097fc3ff', 28025, 14, 16),
    ('docs/evidence/m02-w14-build-result-concurrency/proof.tar.gz', '2620c4c3706a78f4895c5dc9e67450f0924b45d2f5d5ab5bd6fe94d5e09628ef', 4275812, 95, 24),
    ('docs/evidence/m02-w14-paired-revision9/proof.tar.gz', 'a46bbb17864f625138a44a49270776e13c519103e6deb5f7f8949c04c75b7d8c', 403370, 87, 19),
]
bindings = []
for relative, expected_sha, expected_bytes, expected_members, expected_checks in proofs:
    p = root / relative
    data = p.read_bytes()
    with tarfile.open(p, 'r:gz') as archive:
        members = archive.getmembers()
        names = [member.name for member in members]
        safe = all(member.isfile() and not PurePosixPath(member.name).is_absolute() and '..' not in PurePosixPath(member.name).parts for member in members) and len(names) == len(set(names))
    findings_path = p.parent / 'archive-review-findings.json'
    findings = json.loads(findings_path.read_text())
    checks = findings['checks']
    record = {
        'path': relative,
        'archive_sha256': hashlib.sha256(data).hexdigest(),
        'archive_bytes': len(data),
        'safe_regular_members': len(members),
        'all_unique_safe_regular_members': safe,
        'archive_peer_checks': len(checks),
        'archive_peer_all_checks_true': all(value is True for value in checks.values()),
        'archive_peer_all_checks_pass': findings.get('all_checks_pass'),
        'findings_sha256': hashlib.sha256(findings_path.read_bytes()).hexdigest(),
        'report_sha256': hashlib.sha256((p.parent / 'archive-review-report.md').read_bytes()).hexdigest(),
    }
    if record['archive_sha256'] != expected_sha or len(data) != expected_bytes or len(members) != expected_members or not safe or len(checks) != expected_checks or not record['archive_peer_all_checks_true'] or findings.get('all_checks_pass') is not True:
        raise SystemExit(f'Proof binding mismatch: {relative}')
    # Independently match the peer findings to the actual outer archive as well.
    for key, actual in [('archive_sha256', record['archive_sha256']), ('archive_bytes', len(data))]:
        if findings.get(key) != actual:
            raise SystemExit(f'Peer outer archive binding mismatch: {relative} {key}')
    if findings.get('regular_members') != len(members):
        raise SystemExit(f'Peer member count mismatch: {relative}')
    bindings.append(record)

patch = ''
entries = []
for relative in paths:
    pre = (base / 'preimages' / relative).read_bytes()
    post = (base / 'afterimages' / relative).read_bytes()
    if (root / relative).read_bytes() != pre:
        raise SystemExit(f'Root preimage changed; requires explicit rebase: {relative}')
    patch += f'diff --git a/{relative} b/{relative}\n'
    patch += ''.join(difflib.unified_diff(pre.decode().splitlines(keepends=True), post.decode().splitlines(keepends=True), fromfile='a/'+relative, tofile='b/'+relative))
    entries.append({'path': relative, 'preimage_sha256': hashlib.sha256(pre).hexdigest(), 'afterimage_sha256': hashlib.sha256(post).hexdigest(), 'root_matches_preimage': True})
if re.search(r'__PENDING_[A-Z0-9_]+__', patch):
    raise SystemExit('Unresolved proposal token')
for relative, expected_sha, expected_bytes, expected_members, expected_checks in proofs:
    if relative not in patch or expected_sha not in patch:
        raise SystemExit(f'Final prose does not bind expected proof: {relative}')
(base / 'governance-final.patch').write_text(patch)
report = {
    'format_version': 'W14_KI0096_GOVERNANCE_PROOF_BINDINGS_1',
    'scope': 'Read-only copied archive references and peer-count bindings plus draft fixture literal/preimage comparison; not new product tests or an independent re-audit of contained observations.',
    'proofs': bindings,
    'all_bindings_pass': True,
    'fixture_literal_only_comparison': 'PASS_SOURCE_ONLY_THREE_LINES_REMOVED_EQUAL_PREIMAGE',
    'root_preimages_match': True,
    'unresolved_tokens': [],
    'root_mutations_tests_builds_browsers': 0,
}
(base / 'proof-binding-checks.json').write_text(json.dumps(report, indent=2)+'\n')
manifest = {
    'format_version': 'W14_KI0096_GOVERNANCE_PROPOSAL_FINAL_1',
    'scope': 'Outside-only four governance docs and exactly three existing corrective finding-list additions; no assertion/test identity changes.',
    'state': 'COMPLETE_OUTSIDE_PROPOSAL_ROOT_SOLE_APPLY_AUTHORITY',
    'previous_proposal': 'history/pending-002/governance-pending.patch',
    'previous_proposal_sha256': hashlib.sha256((history / 'governance-pending.patch').read_bytes()).hexdigest(),
    'initial_proposal': 'history/pending-001/governance-pending.patch',
    'initial_proposal_sha256': hashlib.sha256((base / 'history/pending-001/governance-pending.patch').read_bytes()).hexdigest(),
    'paths': entries,
    'pending_tokens': [],
    'patch_sha256': hashlib.sha256((base / 'governance-final.patch').read_bytes()).hexdigest(),
    'patch_bytes': (base / 'governance-final.patch').stat().st_size,
    'proof_binding_checks': 'proof-binding-checks.json',
    'proof_binding_checks_sha256': hashlib.sha256((base / 'proof-binding-checks.json').read_bytes()).hexdigest(),
    'fixture_literal_only_comparison': 'PASS_SOURCE_ONLY_THREE_LINES_REMOVED_EQUAL_PREIMAGE',
    'root_preimages_match': True,
    'root_mutations_tests_builds_browsers': 0,
}
(base / 'proposal-final-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
(base / 'manifest-final-fill.diff').write_text(''.join(difflib.unified_diff((history/'proposal-pending-manifest.json').read_text().splitlines(True), (base/'proposal-final-manifest.json').read_text().splitlines(True), fromfile='pending-002/proposal-pending-manifest.json', tofile='proposal-final-manifest.json')))
(base / 'prose-final-fill.diff').write_text(''.join(difflib.unified_diff((history/'governance-pending.patch').read_text().splitlines(True), (base/'governance-final.patch').read_text().splitlines(True), fromfile='pending-002/governance-pending.patch', tofile='governance-final.patch')))
print(json.dumps(manifest, indent=2))
