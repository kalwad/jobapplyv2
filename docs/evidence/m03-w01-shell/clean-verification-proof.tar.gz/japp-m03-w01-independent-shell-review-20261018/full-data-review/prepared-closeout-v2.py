from pathlib import Path
import datetime,hashlib,json,re,tarfile,shutil,subprocess
r=Path('/Users/tanishkalwad/jobapplyv2'); out=Path('/tmp/japp-m03-w01-clean-verification-retry-20261018'); d=r/'docs/evidence/m03-w01-shell'
closure=json.loads((out/'closure.json').read_text());assert all(closure[k] for k in ('source_unchanged','all_executed_commands_pass','both_commands_executed'))
commands=json.loads((out/'commands.json').read_text());assert len(commands)==2 and all(c['exit_code']==0 for c in commands)
assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=r)==b''
before=json.loads((out/'before.json').read_text());head=before['head'];tree=before['tree']
assert head=='dbdf3c7a1f3204a7e040625fada038bfb4c7ce75'
raw=(out/'verify.log').read_text();summary=raw.split('== verification summary ==')[-1]
passing=re.findall(r'^([a-z0-9-]+)\s+ACTIVE\s+PASS\b',summary,re.M)
assert len(passing)==20,(len(passing),summary)
assert '1533 passed' in raw
(d/'clean-verification-summary.json').write_text(json.dumps({'source_commit':head,'source_tree':tree,'commands':commands,'closure':closure,'active_suites':passing,'scope':'W01 ordinary canonical full verification, not a new GateA campaign or cross-platform packaged certification'},indent=2)+'\n')
inputs=list(sorted(out.iterdir()))
reviewbase=Path('/tmp/japp-m03-w01-independent-shell-review-20261018')
for sub in ('governance-6a08f61','ux-projection-review','fixture-and-projection-retry-review/closed-review'):
 inputs += [p for p in sorted((reviewbase/sub).rglob('*')) if p.is_file() and not p.is_symlink()]
manifest=[]
with tarfile.open(d/'clean-verification-proof.tar.gz','w:gz') as archive:
 for p in inputs:
  assert p.is_file() and not p.is_symlink()
  name=str(p.relative_to('/tmp'));data=p.read_bytes()
  manifest.append({'member':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
  archive.add(p,arcname=name,recursive=False)
data=(d/'clean-verification-proof.tar.gz').read_bytes();packsha=hashlib.sha256(data).hexdigest()
(d/'clean-verification-manifest.json').write_text(json.dumps({'sha256':packsha,'bytes':len(data),'inputs':manifest},indent=2)+'\n')
# Full-tested current partial projection; closeout changes only work-package states.
x=json.loads((r/'docs/traceability.json').read_text())
for p in x['work_packages']:
 if p['id']=='M03-W01': p.update(current_state='VERIFIED',verified_revision='tree '+tree,current_evidence=[{'path':'docs/TEST_EVIDENCE.md','heading':'### M03-W01'}])
 elif p['id']=='M03-W02':p.update(current_state='IN_PROGRESS')
(r/'docs/traceability.json').write_text(json.dumps(x,indent=2)+'\n')
p=r/'docs/PROJECT_STATUS.md';s=p.read_text()
s=s.replace('Repository revision: M02 ACCEPTED at frozen95f5; Gate A PASS under OD-037 / ADR-0008; M03-W01 IN_PROGRESS','Repository revision: M03-W01 VERIFIED at '+head[:7]+'; M03-W02 IN_PROGRESS; M02 ACCEPTED / Gate A PASS')
s=s.replace('Current work package: M03-W01','Current work package: M03-W02',1)
start=s.index('## Active work\n');end=s.index('\n## Milestone table',start)
s=s[:start]+'''## Active work

- State: M03-W02 is the sole IN_PROGRESS package; 34/300 packages VERIFIED. M00/M01/M02 remain ACCEPTED; Gate A remains PASS.
- Completed prerequisite: M03-W01 VERIFIED at tree '''+tree+''' after strict doctor28/complete20-suite clean source-neutral validation and separate source/image/governance review. Initial baseline is CAPTURED/NOT_APPROVED; broader M03-W11 design/surface acceptance remains required.
- Objective: real FastAPI service skeleton with authenticated versioned health/readiness/version endpoints, canonical structured errors, owned lifespan and loopback-only binding. Random-port sidecar lifecycle, desktop client and restart remain the following packages.
- Execution: continue all eligible work without routine approval prompts under OD-035–037. Actual validation/review, numerical and safety requirements and precise ADR-0006/0007 waivers remain binding. Release remains NOT_READY.
'''+s[end:]
s,count=re.subn(r'^(\| `M03-W01` \| )IN_PROGRESS \| — \| [^\n|]* \|',r'\g<1>VERIFIED | tree '+tree+' | docs/TEST_EVIDENCE.md § M03-W01 |',s,flags=re.M);assert count==1,count
s=s.replace('| `M03-W02` | NOT_STARTED |','| `M03-W02` | IN_PROGRESS |',1)
s=s.replace('- Reason: M03-W01 is IN_PROGRESS after M02 acceptance and Gate A PASS. Continue its implementation and validation; routine approval prompts are delegated under OD-037 / ADR-0008.','- Reason: M03-W02 is IN_PROGRESS after verified M03-W01. Continue implementation and validation without routine approval stops under OD-037 / ADR-0008.')
p.write_text(s)
p=r/'docs/evidence/m03-w01-shell/foundation-review.md';s=p.read_text().replace('provide a working Home action','provide the working global Home link');p.write_text(s)
p=r/'docs/TEST_EVIDENCE.md';s=p.read_text().replace('validates real captured PNG/source identity','validates actual captured PNG identity and source-binding format',1)
entry=f'''
### M03-W01 — Verified initial desktop shell; M03-W02 continuation (2026-10-18)

- Revision: tree {tree}, commit {head}. Actual clean source-bound strict doctor28PASS/0warning/0fail/0NYA and full20ACTIVE PASS; commands and times are retained in clean-verification-summary.json. Every tracked file/HEAD/tree/clean status remained exact. Ordinary canonical default benchmark scope is distinct from accepted95f5 Gate A target20 evidence; no new gate campaign or packaged certification is claimed.
- Full raw results and exact commands: docs/evidence/m03-w01-shell/clean-verification-proof.tar.gz SHA256{packsha}, {len(data)}bytes/{len(manifest)}files; adjacent manifest binds every member. 3937TS across15packages,256defaultbrowser,2inspection+62controlledcontact,3separatevisual and1533Python actualPASS; exact timings/raw output retained. Focused33 units, renderer10/visual3 and both native6-test modes are also independently retained; no skip/expected-failure allowance added.
- Separate independent source/image and final governance review found no blocking findings after SHELL-001 closure; governance findings c2d387302eea00501bfe472426a1085f463f3297dce456349b9b105c81cf5ffc. The final native GUI and actual denial checks are separately recorded, not attributed to reviewer execution. Two review wording clarifications now specify source-binding format and the global Home link.
- Full-tested honesty metadata: UX002/003 record only the implemented foundation as SCAFFOLD_ONLY/NOT_YET_APPLICABLE, with real source/test/evidence and explicit W11/study/future-owner remainder. Independently reviewed projection9e8e8aa8d03917cc3e97a6894df774460e4febc538c1a9cb0db47998c9617625 (review f195b64bbb559ac82ec9558a6198565caf50d685c3fb324bfbfd7c1fb03df46d); previous15ea projection and immutable v1.2/v1.3 mappings/dependencies preserved. The current full candidate includes the reviewed projection and corrected fixtures; closeout changes only states and documentary evidence.
- Decision: required W01 initial-foundation evidence passes; implementation agent /root records W01 VERIFIED under delegated OD-037 / ADR-0008 authority. Initial capture is not a frozen/approved final baseline; M03-W11 retains broader obligations. M03 itself remains IN_PROGRESS, release NOT_READY, and M03-W02 starts immediately as the sole active package.

### M03-W02 — Authenticated local service skeleton start (2026-10-18)

- Dependencies: M03-W01 VERIFIED and M00/M01/M02 ACCEPTED; Gate A PASS. State IN_PROGRESS, no service PASS claimed by this start.
- Scope: real FastAPI /api/v1/health, /api/v1/ready and /api/v1/version; every route authenticated, canonical envelopes/error taxonomy, lifespan cleanup, literal loopback-only runner and private bounded token bootstrap. No unauthenticated docs/unknown-route escape, token argv/environment/logs or fake database/model readiness.
- Acceptance: meaningful unit/contract/negative tests first, actual owned loopback and wheel/runtime import proof, static and clean full verification, separate review. W03 sidecar lifecycle and W04 desktop client remain their own packages. Continue without routine approval prompts.

'''
s=s.replace('## Entries\n','## Entries\n'+entry,1);p.write_text(s)
p=r/'docs/KNOWN_ISSUES.md';s=p.read_text();needle='## M02-W14 current development findings'
entry='''## M03-W01 corrected native boundary (2026-10-18)

### KI-0101 — Debug-packaged shell accepted the development origin

- Severity: MEDIUM
- State: FIXED
- Discovered: 2026-10-18 during M03-W01 independent review (SHELL-001)
- Affects: M03-W01; native shell navigation policy
- Description: cfg!(debug_assertions) treated a debug-packaged custom-protocol app as development and permitted http://127.0.0.1:1420.
- Reproduction: actual custom-protocol test calling the shipping callback failed before the fix; original RED is retained.
- Workaround: none used.
- Resolution + evidence link: shipping callback uses tauri::is_dev(); six tests in each protocol mode pass, independent review closed SHELL-001 and the final rebuilt GUI actually denied development-origin navigation. Clean source-bound full20-suite validation passes; docs/TEST_EVIDENCE.md § M03-W01 and docs/evidence/m03-w01-shell.

'''
assert needle in s;p.write_text(s.replace(needle,entry+needle,1))
p=r/'docs/COMPATIBILITY_MATRIX.md';s=p.read_text();needle='## Current M02-W15 research review'
entry=f'''## Initial desktop shell observation — 2026-10-18

M03-W01 is VERIFIED at tree {tree}; M03 remains IN_PROGRESS. Target macOS arm64 actual local .app inspection rendered the original shell, real app0.0.1/Tauri2.12.4, native keyboard/skip behavior and bounded IPC/navigation denial checks. Bundled Chromium151.0.7922.34 exercised seven routes and captures at1120/320px plus200% text resize. Exact evidence: docs/TEST_EVIDENCE.md § M03-W01 and docs/evidence/m03-w01-shell. This is initial shell evidence, not authenticated service lifecycle, Windows/Ubuntu GUI validation, production ATS support or final frozen design certification. Gate A/M02 are accepted under the separate delegated decision chain recorded above their original historical packets.

'''
assert needle in s;p.write_text(s.replace(needle,entry+needle,1))
print(json.dumps({'head':head,'tree':tree,'full_suites':passing,'packsha':packsha,'packbytes':len(data)}))
