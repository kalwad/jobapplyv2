from pathlib import Path
import datetime, hashlib, json, os, platform, shutil, subprocess, sys, time
r=Path('/Users/tanishkalwad/jobapplyv2'); out=Path('/tmp/japp-m03-w01-clean-verification-retry-20261018')
assert not out.exists(); out.mkdir()
env=os.environ.copy(); env['PATH']='/opt/homebrew/opt/node@24/bin:'+env['PATH']
for key in ('JAPP_W13_PERFORMANCE_SAMPLES','JAPP_W14_REQUIRE_TARGET_PERFORMANCE','JAPP_W14_ARTIFACT_DIRECTORY','JAPP_W14_W06_ARTIFACT_DIRECTORY'):
 env.pop(key,None)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(data):return hashlib.sha256(data).hexdigest()
def git(*args):
 p=subprocess.run(['git',*args],cwd=r,env=env,capture_output=True,check=True);return p.stdout

def snapshot():
 paths=git('ls-files','-z').decode().split('\0'); rows=[]
 for s in paths:
  if not s: continue
  p=r/s
  if p.is_symlink(): data=os.readlink(p).encode(); kind='symlink'
  else: data=p.read_bytes(); kind='regular'
  rows.append({'path':s,'kind':kind,'bytes':len(data),'sha256':digest(data)})
 return {'head':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'status':git('status','--porcelain=v1').decode(),'tracked':rows}
def write(n,x):(out/n).write_text(json.dumps(x,indent=2)+'\n')
shutil.copy2(__file__,out/'executed-wrapper.py')
before=snapshot();assert before['status']=='',before['status'];assert before['head']=='dbdf3c7a1f3204a7e040625fada038bfb4c7ce75'
write('before.json',before)
probes={}
for name,args in [('node',['node','--version']),('pnpm',['pnpm','--version']),('python',['uv','run','python','--version']),('uv',['uv','--version']),('rust',['rustc','--version'])]:
 p=subprocess.run(args,cwd=r,env=env,capture_output=True,text=True);assert p.returncode==0
 probes[name]={'argv':args,'resolved':shutil.which(args[0],path=env['PATH']),'exit_code':p.returncode,'stdout':p.stdout.strip(),'stderr':p.stderr.strip()}
write('environment.json',{'platform':platform.platform(),'machine':platform.machine(),'probes':probes,'benchmark_scope':'ordinary canonical defaults; accepted95f5 GateA performance unchanged, not rerun as target20','wrapper_sha256':digest(Path(__file__).read_bytes())})
records=[]
for name,argv in [('doctor',['pnpm','run','doctor']),('verify',['pnpm','verify'])]:
 t=time.monotonic();start=now();print('RUN '+name+' '+start,flush=True)
 with (out/(name+'.log')).open('wb') as log: p=subprocess.run(argv,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 data=(out/(name+'.log')).read_bytes(); record={'name':name,'argv':argv,'cwd':str(r),'started_at':start,'ended_at':now(),'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-t,'log_bytes':len(data),'log_sha256':digest(data)}
 records.append(record);write('commands.json',records);print(json.dumps(record),flush=True)
 if p.returncode: break
try:
 after=snapshot();write('after.json',after);neutral=before==after
except Exception as e:neutral=False;write('after-error.json',{'type':type(e).__name__,'message':str(e)})
verdict={'ended_at':now(),'source_unchanged':neutral,'all_executed_commands_pass':all(x['exit_code']==0 for x in records),'both_commands_executed':len(records)==2}
write('closure.json',verdict);print(json.dumps(verdict),flush=True)
sys.exit(0 if all(verdict[k] for k in ('source_unchanged','all_executed_commands_pass','both_commands_executed')) else 1)
