from pathlib import Path
import ast,hashlib,json,os,subprocess,time,datetime
r=Path('/Users/tanishkalwad/jobapplyv2');d=Path(__file__).parent
a=ast.parse((d/'test_validate_status.preimage.py').read_text());b=ast.parse((r/'scripts/tests/test_validate_status.py').read_text())
asserts=lambda tree:[ast.dump(n,include_attributes=False) for n in ast.walk(tree) if isinstance(n,ast.Assert)]
assert asserts(a)==asserts(b)
(d/'assertion-preservation.json').write_text(json.dumps({'original_assertions':len(asserts(a)),'current_assertions':len(asserts(b)),'all_assertions_AST_identical':True,'change':'one explicit copied-fixture NOT_STARTED premise before unchanged invalid DONE mutation'},indent=2)+'\n')
env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@24/bin:'+env['PATH']
records=[]
commands=[('trace-generate',['pnpm','traceability:generate']),('trace-check',['pnpm','traceability:check']),('focused',['uv','run','--locked','pytest','scripts/tests/test_validate_status.py','scripts/tests/test_v14_migration.py','scripts/tests/test_ui_governance_progress.py','-q']),('ruff',['uv','run','--locked','ruff','check','scripts/tests/test_validate_status.py']),('ruff-format',['uv','run','--locked','ruff','format','--check','scripts/tests/test_validate_status.py']),('mypy',['uv','run','--locked','mypy','scripts/tests/test_validate_status.py']),('diff',['git','diff','--check'])]
for name,args in commands:
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 with (d/(name+'.log')).open('wb') as f:p=subprocess.run(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 data=(d/(name+'.log')).read_bytes();record={'name':name,'argv':args,'cwd':str(r),'started_at':started,'elapsed_seconds':time.monotonic()-t,'exit_code':p.returncode,'log_bytes':len(data),'log_sha256':hashlib.sha256(data).hexdigest()};records.append(record);(d/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
