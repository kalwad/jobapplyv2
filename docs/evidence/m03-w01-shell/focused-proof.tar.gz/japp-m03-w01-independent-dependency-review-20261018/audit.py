from pathlib import Path
import hashlib,json,subprocess,yaml
root=Path('/Users/tanishkalwad/jobapplyv2')
out=Path('/tmp/japp-m03-w01-independent-dependency-review-20261018')
base='a0439867b378703fba9d78ddf2dbf92940e84ca2'
def git_blob(ref,path):
    return subprocess.run(['git','show',f'{ref}:{path}'],cwd=root,check=True,capture_output=True).stdout
def digest(data):return hashlib.sha256(data).hexdigest()
paths=['pnpm-lock.yaml','package.json','apps/desktop/package.json','packages/ui/package.json','pnpm-workspace.yaml','.npmrc','eslint.config.mjs','apps/mock-ats-lab/package.json']
inputs={}
for path in paths:
    current=(root/path).read_bytes() if (root/path).exists() else None
    oldproc=subprocess.run(['git','show',f'{base}:{path}'],cwd=root,capture_output=True)
    previous=oldproc.stdout if oldproc.returncode==0 else None
    inputs[path]={'current':current,'previous':previous}
    for side,data in [('current',current),('previous',previous)]:
        if data is not None:
            target=out/'inputs'/side/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
old=yaml.safe_load(inputs['pnpm-lock.yaml']['previous'])
new=yaml.safe_load(inputs['pnpm-lock.yaml']['current'])
checks=[]
def check(name,actual,expected=True):
    checks.append({'name':name,'pass':actual==expected,'actual':actual,'expected':expected})
check('current lock exact submitted digest',digest(inputs['pnpm-lock.yaml']['current']),'9f9f4ec15c2fc55ffe4e32f8ab52f8193aa9e5bd1624a2e9bcf4c1db35e1e019')
check('accepted predecessor lock exact historical digest',digest(inputs['pnpm-lock.yaml']['previous']),'c9d9f2fea650873b806a28058a9f1a8ca88d38fe439ceb3ba9fd7c83d778b565')
lock95=git_blob('95f5b09f43d9bef06d6158ea0bb8b9e0e3aa9123','pnpm-lock.yaml')
(out/'inputs'/'lock95.yaml').write_bytes(lock95)
check('95f5 tested frozen lock byte-identical to predecessor',lock95==inputs['pnpm-lock.yaml']['previous'])
for section in sorted(set(old)|set(new)):
    if section not in ['importers','packages','snapshots']:
        check('unchanged lock top-level '+section,new.get(section),old.get(section))
for section in ['importers','packages','snapshots']:
    removed=sorted(set(old[section])-set(new[section]))
    changed=sorted(key for key,value in old[section].items() if key in new[section] and value!=new[section][key])
    added=sorted(set(new[section])-set(old[section]))
    check('no removed '+section,removed,[])
    check('expected changed '+section,changed,['.','apps/desktop','packages/ui'] if section=='importers' else [])
    (out/(section+'-delta.json')).write_text(json.dumps({'old_count':len(old[section]),'new_count':len(new[section]),'added':added,'changed':changed,'removed':removed},indent=2)+'\n')
check('workspace trust/script policy unchanged',inputs['pnpm-workspace.yaml']['current']==inputs['pnpm-workspace.yaml']['previous'])
check('npmrc trust policy unchanged',inputs['.npmrc']['current']==inputs['.npmrc']['previous'])
check('mock lab manifest byte unchanged',inputs['apps/mock-ats-lab/package.json']['current']==inputs['apps/mock-ats-lab/package.json']['previous'])
expected_root={**old['importers']['.'],'devDependencies':{**old['importers']['.']['devDependencies'],'eslint-plugin-react-hooks':{'specifier':'7.1.1','version':'7.1.1(eslint@10.8.0(jiti@2.7.0))'}}}
check('root importer exact additive hooks pin',new['importers']['.'],expected_root)
expected_ui={**old['importers']['packages/ui'],'devDependencies':{**old['importers']['packages/ui']['devDependencies'],'@types/react':{'specifier':'19.2.18','version':'19.2.18'},'react':{'specifier':'19.2.8','version':'19.2.8'}}}
check('UI importer exact additive React pins',new['importers']['packages/ui'],expected_ui)
expected_desktop={
 'dependencies':{
  '@japp/ui':{'specifier':'workspace:*','version':'link:../../packages/ui'},
  '@tauri-apps/api':{'specifier':'2.12.4','version':'2.12.4'},
  'react':{'specifier':'19.2.8','version':'19.2.8'},
  'react-dom':{'specifier':'19.2.8','version':'19.2.8(react@19.2.8)'}},
 'devDependencies':{
  '@tauri-apps/cli':{'specifier':'2.12.3','version':'2.12.3'},
  '@types/node':{'specifier':'catalog:','version':'24.13.3'},
  '@types/react':{'specifier':'19.2.18','version':'19.2.18'},
  '@types/react-dom':{'specifier':'19.2.4','version':'19.2.4(@types/react@19.2.18)'},
  'typescript':{'specifier':'catalog:','version':'6.0.3'},
  'vite':{'specifier':'7.3.6','version':'7.3.6(@types/node@24.13.3)(jiti@2.7.0)(lightningcss@1.33.0)'},
  'vitest':{'specifier':'catalog:','version':'4.1.10(@types/node@24.13.3)(vite@7.3.6(@types/node@24.13.3)(jiti@2.7.0)(lightningcss@1.33.0))'}}}
check('desktop importer exact reviewed graph',new['importers']['apps/desktop'],expected_desktop)
for dep in ['react','react-dom']:
    check('desktop reuses old lab '+dep,new['importers']['apps/desktop']['dependencies'][dep],old['importers']['apps/mock-ats-lab']['dependencies'][dep])
for dep in ['@types/react','@types/react-dom','vite','vitest','typescript','@types/node']:
    check('desktop reuses old lab '+dep,new['importers']['apps/desktop']['devDependencies'][dep],old['importers']['apps/mock-ats-lab']['devDependencies'][dep])
ui_manifest=json.loads(inputs['packages/ui/package.json']['current'])
check('UI React peer exact same single React version',ui_manifest['peerDependencies'],{'react':'19.2.8'})
check('UI public exports source and tokens only',ui_manifest['exports'],{'.':'./src/index.ts','./tokens.css':'./src/tokens.css'})
root_old=json.loads(inputs['package.json']['previous']);root_new=json.loads(inputs['package.json']['current'])
root_expected={**root_old,'devDependencies':{**root_old['devDependencies'],'eslint-plugin-react-hooks':'7.1.1'}}
check('root manifest exact hooks-only addition',root_new,root_expected)
for dep,record in expected_desktop['dependencies'].items():
    check('desktop manifest runtime pin '+dep,json.loads(inputs['apps/desktop/package.json']['current'])['dependencies'][dep],record['specifier'])
for dep,record in expected_desktop['devDependencies'].items():
    check('desktop manifest development pin '+dep,json.loads(inputs['apps/desktop/package.json']['current'])['devDependencies'][dep],record['specifier'])
desktop_manifest=json.loads(inputs['apps/desktop/package.json']['current'])
check('desktop manifest exact runtime dependency inventory',desktop_manifest['dependencies'],{key:value['specifier'] for key,value in expected_desktop['dependencies'].items()})
check('desktop manifest exact development dependency inventory',desktop_manifest['devDependencies'],{key:value['specifier'] for key,value in expected_desktop['devDependencies'].items()})
check('desktop scripts limited to real development/build/test/native commands',sorted(desktop_manifest['scripts']),['build','dev','e2e-server','tauri','test','typecheck'])
ui_old=json.loads(inputs['packages/ui/package.json']['previous'])
check('UI scripts unchanged',ui_manifest['scripts'],ui_old['scripts'])
check('UI exact development dependency inventory',ui_manifest['devDependencies'],{**ui_old['devDependencies'],'react':'19.2.8','@types/react':'19.2.18'})
roots=['@tauri-apps/api@2.12.4','@tauri-apps/cli@2.12.3','eslint-plugin-react-hooks@7.1.1(eslint@10.8.0(jiti@2.7.0))']
seen=set();pending=roots[:]
while pending:
    item=pending.pop()
    if item in seen:continue
    seen.add(item)
    node=new['snapshots'].get(item,{})
    for section in ['dependencies','optionalDependencies']:
        for name,version in node.get(section,{}).items():
            key=name+'@'+version
            if key in new['snapshots']:pending.append(key)
added_snap=set(new['snapshots'])-set(old['snapshots'])
check('all new snapshots reachable from scoped new direct dependencies',sorted(added_snap-seen),[])
new_packages=sorted(set(new['packages'])-set(old['packages']))
check('all added packages have integrity binding',all(new['packages'][key].get('resolution',{}).get('integrity','').startswith('sha512-') for key in new_packages))
metadata=[]
for package_key in new_packages:
    package_name,version=package_key.rsplit('@',1)
    pattern=package_key.replace('/','+')+'*'
    candidates=sorted((root/'node_modules/.pnpm').glob(pattern))
    found=[]
    for candidate in candidates:
        package_path=candidate/'node_modules'/package_name/'package.json'
        if package_path.is_file():
            data=package_path.read_bytes();manifest=json.loads(data)
            if manifest.get('version')!=version or manifest.get('name')!=package_name:continue
            local=out/'package-metadata'/package_name/version/'package.json';local.parent.mkdir(parents=True,exist_ok=True);local.write_bytes(data)
            found.append({'source_path':str(package_path),'sha256':digest(data),'name':manifest['name'],'version':manifest['version'],'license':manifest.get('license'),'lifecycle_scripts':{key:value for key,value in manifest.get('scripts',{}).items() if key in ['preinstall','install','postinstall']}})
    metadata.append({'lock_package':package_key,'installed_metadata':found[:1]})
check('no observed newly installed package install lifecycle script',all(not info['lifecycle_scripts'] for record in metadata for info in record['installed_metadata']))
(out/'package-metadata-index.json').write_text(json.dumps(metadata,indent=2)+'\n')
for path,sides in inputs.items():
    current=(root/path).read_bytes() if (root/path).exists() else None
    check('input unchanged during review '+path,current==sides['current'])
result={'scope':'PNPM_LOCK_AND_MANIFEST_SOURCE_REVIEW_ONLY','reviewer':'/root/m03_shell_ui','independence':'Reviewer authored shared UI/shell source, not these root manifests, lock, dependency choices or migration guard. No product validation independence claim.','base_commit':base,'tested_historical_commit':'95f5b09f43d9bef06d6158ea0bb8b9e0e3aa9123','historical_lock_sha256':digest(lock95),'current_lock_sha256':digest(inputs['pnpm-lock.yaml']['current']),'all_checks_pass':all(c['pass'] for c in checks),'checks':checks,'new_package_count':len(new_packages),'new_snapshot_count':len(added_snap),'installed_metadata_package_count':sum(bool(r['installed_metadata']) for r in metadata),'unavailable_metadata_packages':[r['lock_package'] for r in metadata if not r['installed_metadata']],'no_root_writes':True,'no_installs_or_actors':True,'current_historical_test_expected_failure':'test_v14_migration.py asserts historical c9d9 digest against new full lock; keep historical assertion bound95f5 and add separate reviewed M03 current hash and exact additive importer/delta guard.','limitations':['No installation, package publication, registry query, supply-chain scan or license legal opinion performed.','Primary package metadata came from actual installed publisher package.json files; non-host optional platform binaries are not installed here.','Source review does not certify native packaging or other platforms.']}
(out/'findings.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'passed':sum(c['pass'] for c in checks),'new_package_count':len(new_packages),'new_snapshot_count':len(added_snap),'installed_metadata_packages':result['installed_metadata_package_count'],'failures':[c['name'] for c in checks if not c['pass']],'unavailable_metadata_packages':result['unavailable_metadata_packages']},indent=2))
