# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: desktop/shell.spec.ts >> render boundary reset restores usable content and keyboard focus
- Location: e2e/desktop/shell.spec.ts:185:1

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  locator('.ui-boundary-content')
Expected: focused
Received: inactive
Timeout:  5000ms

Call log:
  - Expect "toBeFocused" with timeout 5000ms
  - waiting for locator('.ui-boundary-content')
    14 × locator resolved to <div class="ui-boundary-content">…</div>
       - unexpected value "inactive"

```

```yaml
- heading "Recovered view" [level=1]
```

# Test source

```ts
  104 |   await expect(page.getByText("0.0.1", { exact: true })).toBeVisible();
  105 | });
  106 | 
  107 | test("safe error retry recovers and returns focus without displaying raw exceptions", async ({
  108 |   page,
  109 | }) => {
  110 |   await page.goto(`${ORIGIN}?scenario=retry#diagnostics`);
  111 |   await expect(page.getByRole("alert")).toContainText(
  112 |     "Version information is unavailable.",
  113 |   );
  114 |   await expect(page.locator("body")).not.toContainText(
  115 |     "fixture-private-secret",
  116 |   );
  117 |   await page.getByRole("button", { name: "Try again" }).click();
  118 |   await expect(page.getByText("0.0.1", { exact: true })).toBeVisible();
  119 |   await expect(
  120 |     page.getByRole("heading", { name: "Desktop versions" }),
  121 |   ).toBeFocused();
  122 | });
  123 | 
  124 | test("late route results cannot replace a fresh version read", async ({
  125 |   page,
  126 | }) => {
  127 |   await page.goto(`${ORIGIN}?scenario=pending#diagnostics`);
  128 |   await expect(page.getByRole("status")).toBeVisible();
  129 |   await page
  130 |     .getByRole("navigation")
  131 |     .getByRole("link", { name: "Jobs", exact: true })
  132 |     .click();
  133 |   await page.evaluate(() => {
  134 |     (
  135 |       window as typeof window & {
  136 |         __desktopFixture: {
  137 |           resolveRead(
  138 |             index: number,
  139 |             value: { appVersion: string; tauriVersion: string },
  140 |           ): void;
  141 |         };
  142 |       }
  143 |     ).__desktopFixture.resolveRead(0, {
  144 |       appVersion: "9.9.9",
  145 |       tauriVersion: "9.9.9",
  146 |     });
  147 |   });
  148 |   await page
  149 |     .getByRole("navigation")
  150 |     .getByRole("link", { name: "Diagnostics", exact: true })
  151 |     .click();
  152 |   await expect(page.getByRole("status")).toBeVisible();
  153 |   await expect(page.locator("body")).not.toContainText("9.9.9");
  154 |   await page.evaluate(() => {
  155 |     (
  156 |       window as typeof window & {
  157 |         __desktopFixture: {
  158 |           resolveRead(
  159 |             index: number,
  160 |             value: { appVersion: string; tauriVersion: string },
  161 |           ): void;
  162 |         };
  163 |       }
  164 |     ).__desktopFixture.resolveRead(1, {
  165 |       appVersion: "0.0.2",
  166 |       tauriVersion: "2.12.4",
  167 |     });
  168 |   });
  169 |   await expect(page.getByText("0.0.2", { exact: true })).toBeVisible();
  170 | });
  171 | 
  172 | test("invalid native versions and absent native IPC fail safely", async ({
  173 |   page,
  174 | }) => {
  175 |   await page.goto(`${ORIGIN}?scenario=malformed#diagnostics`);
  176 |   await expect(page.getByRole("alert")).toContainText("unexpected response");
  177 |   await expect(page.locator("img")).toHaveCount(0);
  178 |   await page.goto(`${ORIGIN}?scenario=native-unavailable#diagnostics`);
  179 |   await expect(page.getByRole("alert")).toContainText(
  180 |     "Open this view in the desktop app",
  181 |   );
  182 |   await expect(page.locator("body")).not.toContainText("__TAURI_INTERNALS__");
  183 | });
  184 | 
  185 | test("render boundary reset restores usable content and keyboard focus", async ({
  186 |   page,
  187 | }) => {
  188 |   await page.goto(`${ORIGIN}?scenario=render-error`);
  189 |   await expect(page.getByRole("alert")).toContainText(
  190 |     "This view could not be displayed.",
  191 |   );
  192 |   await expect(page.locator("body")).not.toContainText(
  193 |     "fixture-render-private-secret",
  194 |   );
  195 |   await page.evaluate(() => {
  196 |     (
  197 |       window as typeof window & { __desktopFixture: { stopThrowing(): void } }
  198 |     ).__desktopFixture.stopThrowing();
  199 |   });
  200 |   await page.getByRole("button", { name: "Reload view" }).click();
  201 |   await expect(
  202 |     page.getByRole("heading", { name: "Recovered view" }),
  203 |   ).toBeVisible();
> 204 |   await expect(page.locator(".ui-boundary-content")).toBeFocused();
      |                                                      ^ Error: expect(locator).toBeFocused() failed
  205 | });
  206 | 
```