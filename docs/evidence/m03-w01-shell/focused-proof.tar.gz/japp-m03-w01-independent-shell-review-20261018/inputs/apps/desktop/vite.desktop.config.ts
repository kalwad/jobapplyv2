import { defineConfig } from "vite";

export default defineConfig({
  clearScreen: false,
  server: { host: "127.0.0.1", port: 1420, strictPort: true, hmr: false },
  esbuild: { jsx: "automatic" },
  build: { target: "es2022", outDir: "dist", emptyOutDir: true },
});
