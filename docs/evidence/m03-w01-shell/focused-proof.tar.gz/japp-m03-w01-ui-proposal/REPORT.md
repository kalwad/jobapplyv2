# M03-W01 UI proposal

This outside-root proposal implements the initial shared React shell foundation. It changes fifteen assigned source/test paths; `proposal-manifest.json` binds every proposed byte. It does not modify the root workspace, configs, manifests, locks, docs, or browser tests. Top-level package/config files and symlinks are local test-harness support and must not be integrated.

`DesktopShell({ loadMetadata?: MetadataLoader })` provides seven semantic hash destinations, native history, current-page names, a skip link, and heading focus after route changes. Home and Diagnostics are implemented; the five remaining destinations present explicit unavailable states with one working Diagnostics action. They do not claim service connectivity, model availability, app data, or platform certification.

`Diagnostics` loads the real native app/Tauri version APIs by default, validates bounded display values, presents explicit loading/error/ready states, ignores late results after unmount/retry, and retries without exposing native exception text. The shared render boundary catches view-rendering faults and remounts on its reload action. It does not label async failures as rendering faults.

Repository-owned shared components and tokens use system fonts, original inline SVG geometry, a light neutral palette and restrained blue accent. Semantic tokens supply the common navigation, buttons, empty/loading/error states and focus foundation. The desktop CSS uses a compact sidebar, content panel rows, narrow reflow, no decorative metric cards and no animation.

Actual focused validation: Vitest4.1.10, three files /32tests PASS134ms after formatting; strict TypeScript PASS using the repository base with planned ESNext/Bundler/DOM/JSX options and actual installed dependencies. A missing CSS ambient type was discovered by the first typecheck and corrected with `vite-env.d.ts`. The actual initial RED retained two missing-module suites and ten executed missing-token-file contrast failures. A preceding harness-import startup failure is preserved separately; it is not product-test failure evidence.

Browser keyboard/history/zoom/reduced-motion/async renderer cases, actual native launch/IPC, screenshots, visual review and product certification remain for root integration. This proposal claims none of those checks.
