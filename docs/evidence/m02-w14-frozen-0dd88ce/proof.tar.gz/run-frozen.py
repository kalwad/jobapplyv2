from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/Users/tanishkalwad/jobapplyv2'); out=Path('/tmp/japp-w14-0dd-frozen-20261016')
env=os.environ.copy(); env['PATH']='/opt/homebrew/opt/node@24/bin:'+env['PATH']; env.update(JAPP_W13_PERFORMANCE_SAMPLES='20',JAPP_W14_REQUIRE_TARGET_PERFORMANCE='1',JAPP_W14_ARTIFACT_DIRECTORY=str(out/'w14'))
def git(*args): return subprocess.check_output(['git',*args],cwd=root).decode().strip()
def snap():
 files=[]
 for name in subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0'):
  if not name: continue
  p=root/name; b=p.read_bytes(); files.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 return {'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain=v1'),'tracked_files':files,'tracked_inventory_digest':hashlib.sha256(json.dumps(files,separators=(',',':')).encode()).hexdigest(),'captured_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
before=snap(); assert before['head']=='0dd88ce23771f7da88d7ef103fea35e459b70392' and before['status']==''
(out/'before.json').write_text(json.dumps(before,indent=2)+'\n')
(out/'command.json').write_text(json.dumps({'argv':['pnpm','verify'],'cwd':str(root),'task_environment':{k:env[k] for k in ('JAPP_W13_PERFORMANCE_SAMPLES','JAPP_W14_REQUIRE_TARGET_PERFORMANCE','JAPP_W14_ARTIFACT_DIRECTORY')},'node_path':'/opt/homebrew/opt/node@24/bin/node','started_at':before['captured_at']},indent=2)+'\n')
with (out/'aggregate.log').open('wb') as f:
 result=subprocess.run(['pnpm','verify'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
after=snap(); (out/'after.json').write_text(json.dumps(after,indent=2)+'\n')
summary={'exit_code':result.returncode,'head_unchanged':before['head']==after['head'],'status_before':before['status'],'status_after':after['status'],'tracked_inventory_unchanged':before['tracked_inventory_digest']==after['tracked_inventory_digest'],'ended_at':after['captured_at']}
(out/'completion.json').write_text(json.dumps(summary,indent=2)+'\n'); print(json.dumps(summary),flush=True)
raise SystemExit(result.returncode)
