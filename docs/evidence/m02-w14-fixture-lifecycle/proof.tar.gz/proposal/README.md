# Function-scoped fixture lifecycle capacity proposal

This is an unapplied source-only proposal outside root. No tests, build or browser were run by the author. Independent source review and fresh affected/native Python execution are pending.

Actual native Windows clean918 CI reports a fixture setup error at `test_gate_v2_waiver_refuses_invalid_owner_decision_row[missing]`, `test_validate_status.py:117` (`shutil.copytree` of the full docs tree), followed by the runner diagnostic “There is not enough space on the disk.” The exact 962,594-byte raw log is `sha256:e866fd0df169e7ce4227f336a3b5bb6e7123c0bed94ad3d221ad61ba76ecc3ec`. This is concrete capacity evidence. It does not establish that the separate environment-guard failure was caused by disk capacity; its stack is incomplete and its cause remains unresolved.

The proposal changes only `repo_copy`, `doctor_repo` and `trace_repo`. They retain their exact complete copy setup, returned `Path`, default function scope, unique `tmp_path/repo` isolation, test identities and assertions. Each takes a typed `request: pytest.FixtureRequest` and registers `lambda: shutil.rmtree(repo)` immediately after its owned directory creation, before the first copy. Pytest runs that finalizer after the test and also if subsequent setup/copy raises. Cleanup remains strict: `rmtree` does not ignore errors. Only that local repository subtree is removed; its parent tmp directory and outside evidence file remain owned by normal pytest cleanup. Directory-child symlinks are removed without following their targets; a top-level replacement symlink would cause strict `rmtree` refusal rather than deletion outside the owned subtree.

The historical direct fixture usage counts are 196 status + 11 doctor + 48 traceability cases. Removing each completed fixture copy bounds retained full-docs trees by active fixture instances rather than accumulating 255 copies until pytest session cleanup. No archive or evidence is omitted from any case. There are no shared inputs, hardlinks, archive exclusions, timeout increases, production changes, gate changes or threshold changes. This is a storage-lifetime correction; it claims no measured runtime improvement or native success.

A finalizer is used instead of a generator because it makes the smaller patch while also covering copy/setup failures. The fixture continues to return `Path`, so no `Iterator` import or return annotation is appropriate. Its only new annotation is `pytest.FixtureRequest`; pytest is already imported in all three modules.

Exact source/hash bindings are in `source-manifest.json`; original and proposed files are under `preimages/` and `proposed/`. Static AST inspection verifies the original setup and return statements remain unchanged after removing the single added finalizer statement, and every other module statement (including tests, decorators and assertions) is identical. No source code was executed for this inspection.

Patch SHA: `sha256:186b6a45f9e7ca3636244bcb89c38363a005f74b1022574280dbfd338dcdfde8`.

Required follow-up: independent read-only source review, then fresh affected local Python and native full Python with cleanup behavior and strict teardown failures visible. Preserve all existing assertions and full inputs. The separate contact environment-guard failure requires its own actual diagnostic; this proposal changes none of its code.
