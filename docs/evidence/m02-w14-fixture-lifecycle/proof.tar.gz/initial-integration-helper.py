from pathlib import Path
import datetime

root = Path('/Users/tanishkalwad/jobapplyv2')
now = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds').replace('+00:00', 'Z')
p = root / 'docs/KNOWN_ISSUES.md'
text = p.read_text()
anchor = '\n## M02-W14 local defect closeout — 2026-10-16\n'
assert text.count(anchor) == 1
addition = '''
### KI-0094 — Focus handlers can cause text/date lost updates during execute and undo

- Severity: HIGH
- State: IN_PROGRESS
- Discovered: 2026-10-16 during supplemental independent W14 runtime review
- Affects: M02-W14; native text/date execute and undo; pre-write value preservation
- Description: a page focus handler can change a native value without a DOM mutation. The driver rechecks ownership and actionability after focus but originally omits the value. Execute overwrites the newer value and grants undo; undo overwrites it with the captured prior value. Both can report VERIFIED/ACCEPTED.
- Reproduction: the sealed eight-case actual-MV3 probe at exact918 runtime355/c375 has four unchanged positives PASS and four focus-preservation negatives FAIL in13.9s. Each negative records zero DOM mutation records for the page edit and one additional extension setter. All13 source/probe/build/tool bindings are unchanged. An earlier missing-await setup failure and two unreachable digest-pause cases remain explicitly separate from the confirmed focus defect. Complete original proof: docs/evidence/m02-w14-focus-value-red/proof.tar.gz, SHA-256 aebfb3fba84ce7c689bcb69234310cdccc87f4390ee116933631adeedaeef829,4793116bytes/459 safe regular members.
- Workaround: do not overwrite a newer page-owned focus value or grant recovery/undo authority for a refused pre-write action. The source-only asynchronous re-resolution concern is unconfirmed and its draft is not integrated.
- Resolution + evidence link: IN_PROGRESS. Root integrated the exact independently reviewed two-file patch3adbcf83e27327c1fe2293cc197c80ce22286cca50a1c7c665a1e1b1f6950177. Text/date snapshot the value immediately before focus and refuse drift before their sole setter. Execute suppresses recovery/undo only for the typed marker from those exact trusted drivers; generic and partial-write recovery remain unchanged. The unchanged eight-case independent GREEN passes11.2s with all four newer values preserved, zero additional setters/input/change events, no VERIFIED result and execute undo=false. All23 existing adjacent browser regressions pass54.7s, including actual partial-widget rollback; all13 bindings match. GREEN proof: docs/evidence/m02-w14-focus-value-green/proof.tar.gz, SHA-256 cd8fd90b9a4d2dcb7e196404e5ff791fd23b0e2325b2f5d069523c1916c2e447,9803118bytes/456 members. Corrected355-file runtime is8c61ebee8af7823f2812c514fb2bbb5eb0ca44c95b919a5ac3919eb9b5fec9cc. Full root regression and separately declared revision8 actual comparison remain pending; no Gate A approval is inferred.

### KI-0095 — Function-scoped repository copies exhaust native Windows test storage

- Severity: HIGH
- State: IN_PROGRESS
- Discovered: 2026-10-16 from terminal Windows CI job117206260868 in run38970154103
- Affects: M02-W14; full Python verification fixture lifecycle and hosted Windows capacity
- Description: full-docs fixture copies accumulate until session cleanup. The918 docs payload and255 declared fixture users imply about30.80GiB of logical copied docs. The actual Windows run reaches18 setup errors while copying docs, and the runner explicitly reports insufficient disk space. No complete Python or aggregate PASS is available.
- Reproduction: actual tested merge3781e31a17013ae361f14f371502196a7f516245 has treebd9eb473719dba61ed842c266c553e334c893538, exactly918. The first recorded setup error is test_gate_v2_waiver_refuses_invalid_owner_decision_row[missing] at full docs copytree. Original Windows raw SHA-256 e866fd0df169e7ce4227f336a3b5bb6e7123c0bed94ad3d221ad61ba76ecc3ec,962594bytes. Complete three-OS proof is retained in docs/evidence/m02-w14-918-ci; Ubuntu/macOS pass19 active suites. Windows compiler8 twice/contracts2524 pass; its final Python summary is absent and tracked-clean is SKIPPED. A separate contact child-environment test has an F progress symbol and no retained stack; its cause remains unresolved and is not assigned to disk exhaustion.
- Workaround: preserve every full input, assertion and isolated copy. Do not omit archives, share mutable hardlinks, ignore cleanup failures or increase CI budgets to conceal the capacity failure.
- Resolution + evidence link: IN_PROGRESS. The independently reviewed fixture-only patch186b6a45f9e7ca3636244bcb89c38363a005f74b1022574280dbfd338dcdfde8 registers strict cleanup of each owned tmp_path/repo immediately after creation and before its first copy in repo_copy, doctor_repo and trace_repo. Default function scope, all copy setup, returned paths and test identities/assertions stay unchanged. It handles setup failure through pytest finalization. Production/environment guards and thresholds are untouched. Full affected local Python and fresh native Windows verification remain pending. See docs/evidence/m02-w14-fixture-lifecycle and docs/TEST_EVIDENCE.md § M02-W14.
'''
p.write_text(text.replace(anchor, '\n' + addition + anchor))

p = root / 'docs/PROJECT_STATUS.md'
lines = p.read_text().splitlines()
for i,line in enumerate(lines):
    if line.startswith('Repository revision:'):
        lines[i] = 'Repository revision: M02-W14 reviewed focus-value and fixture-lifecycle integration; fresh frozen validation pending'
    elif line.startswith('Last updated:'):
        lines[i] = 'Last updated: ' + now
    elif line.startswith('- Platform correction:'):
        lines[i] = '- Platform correction: KI-0090 remains FIXED with repeated native compiler8/contracts2524 passes. Latest918 CI is FAILURE: Ubuntu/macOS pass all19; Windows exhausts fixture storage (KI-0095 IN_PROGRESS), has18 setup errors and an additional unresolved contact-environment F without a stack. Its five prior UTF8 failures map to passing progress symbols, but no final native Python/201-cohort pass exists; KI-0093 remains IN_PROGRESS. Exact tested merge3781e31a has the918 treebd9eb473; tracked-clean is SKIPPED on Windows. Original raw logs and independent32-check archive audit are retained.'
    elif line.startswith('- Local defect closeout:'):
        lines[i] = line + ' KI-0094 is IN_PROGRESS: four actual focus-value lost updates are reproduced; the reviewed two-file correction passes unchanged GREEN8 plus23 adjacent cases. Permanent8 cases and reviewed revision8 declaration are integrated; complete root regression/comparison remain pending.'
p.write_text('\n'.join(lines) + '\n')

p = root / 'docs/TEST_EVIDENCE.md'
text = p.read_text()
anchor = '#### Root final fixture integration checks — 2026-10-16\n'
assert text.count(anchor) == 1
addition = '''#### Focus-value correction and fixture capacity integration — 2026-10-16

The original clean918 local `pnpm test:python` completes1454 PASS in583.78s, exit0, with all1433 tracked files/head/status unchanged. Pinned uv Python3.12.13 is used. Its wrapper is `/tmp/japp-w14-python-918dedb-20261016/run-python.py`; complete raw/command/source proof is retained in docs/evidence/m02-w14-python-918dedb/proof.tar.gz, SHA-25687daa8d094c38e8ac94328df48549e63c1cceab362863bbbdfa87b4dd6ba5fe2,172731bytes/seven members. Separate independent audit verifies every original/member byte and Git blob. This is local affected Python proof, not full19-at918 or native Windows success.

Hosted run[38970154103](https://github.com/kalwad/jobapplyv2/actions/runs/38970154103) is terminal FAILURE. It tests merge3781e31a17013ae361f14f371502196a7f516245/treebd9eb473719dba61ed842c266c553e334c893538, exactly the918 source tree. Ubuntu/macOS pass19 active suites,3859units/234default browsers/62controlled proofs/1454Python (490.22s/547.09s), doctor and tracked-clean. Windows passes compiler8 twice/contracts2524 and visible3859/234/62, then Python has18 fixture setup errors and the runner reports insufficient disk space; final Python/suite summary is absent, tracked-clean SKIPPED. Independently reconstructed ordered progress maps the five old UTF8 cases to passing symbols, but grants no complete201/1452 native pass. Contact child-environment guard has an additional F with lost stack and unresolved cause. Hosted single-sample native128 observations are not the target-Mac20-sample performance proof. Exact raw logs/APIs/merge records and independent32-check audit are retained in docs/evidence/m02-w14-918-ci/proof.tar.gz, SHA-256c41d0e42f1bf5ba0f1b37dcdd402cf1c130b64ce3970dd3254eb4a311dd4e956,935056bytes/80 exhaustive safe regular members. All earlier failures remain unchanged.

Supplemental actual-MV3 RED at918 runtime355/c375 confirms KI-0094: four unchanged text/date execute/undo positives pass; all four focus-edit negatives overwrite the newer value and report VERIFIED/ACCEPTED (13.9s). All13 source/probe/build/tool bindings match. The first six-case setup attempt missed an await; its corrected six-case attempt has two successful unchanged controls, two actual focus failures and two unreachable cached-digest pause failures. Those are preserved separately; only the clean eight-case run supplies the complete product RED. Archive: docs/evidence/m02-w14-focus-value-red/proof.tar.gz, SHA-256aebfb3fba84ce7c689bcb69234310cdccc87f4390ee116933631adeedaeef829,4793116bytes/459 members.

Root integrated exact peer-reviewed two-file patch3adbcf83e27327c1fe2293cc197c80ce22286cca50a1c7c665a1e1b1f6950177 and the byte-identical eight-case probe16209b8cd45a86d4d313b228d6c5af0c10cd5b7830017b6e8b59ce34b61de9c6 as e2e/extension/extension-w14-focus-value.spec.ts. The unchanged independent GREEN8 passes11.2s: all newer values are preserved with zero additional extension setters/input/change events, no VERIFIED claim and execute undo=false/no recovery. All23 existing adjacent cases pass54.7s, including actual partial-widget rollback and all six native-validity cases. Typed lint, Prettier and both TypeScript checks pass; all13 endpoint bindings match. Corrected runtime355 digest8c61ebee8af7823f2812c514fb2bbb5eb0ca44c95b919a5ac3919eb9b5fec9cc; only driver-engine.ts/text-like-drivers.ts change. Complete reviewed source/RED-GREEN/adjacent proof: docs/evidence/m02-w14-focus-value-green/proof.tar.gz, SHA-256cd8fd90b9a4d2dcb7e196404e5ff791fd23b0e2325b2f5d069523c1916c2e447,9803118bytes/456 members. The unconfirmed asynchronous re-resolution draft remains excluded. Complete affected root regression is pending.

Revision8 is separately reviewed before either actor runs: lock0f22812dc44aa46fda51b78ef666738a924e00e0deaaaff977bc33d82729ab3a binds exactly355 corrected runtime files,59 payloads and six byte-preserved revision7 files. Independent448 checks/format review pass; inputs/oracles/projections/vendor31/observer/actors/assertions/fresh-output checks remain exact. Patch6f9fa1968e4a808586a4352904663425a35cc390badda22e9473070fbe12bcce is integrated; no revision7 outcome is rebound. Preparation starts no actor/build/browser. Proof: docs/evidence/m02-w14-paired-revision8/proof.tar.gz, SHA-256438d4c1755746dc19d0f8b0fde46c2b003576dc87fc4e4267616ebbc14155172,359176bytes/75 members. Fresh candidate4/legacy4 execution remains pending until the clean corrected commit.

KI-0095 records the observed Windows capacity failure. The reviewed three-fixture patch186b6a45f9e7ca3636244bcb89c38363a005f74b1022574280dbfd338dcdfde8 preserves complete copy inputs, function scope, isolation, test bodies and returned paths, and registers strict owned-copy cleanup before any copy. It changes no production/environment guard, inventory, threshold or timeout. Source/review evidence is retained under docs/evidence/m02-w14-fixture-lifecycle. Full local/fresh native validation is pending; the extra environment F remains unresolved.

M02-W14/Gate A remain IN_PROGRESS; W15/M03 remain NOT_STARTED and release NOT_READY. Public scored cases0, actual Simplify cases0 and formal independent W15/owner decision remain incomplete (KI-0089). Owner holdout remains WAIVED_BY_OWNER and successive eligible execution remains authorized without per-W stops. No package/gate is promoted by these corrective proofs.

'''
p.write_text(text.replace(anchor, addition + anchor))

p = root / 'docs/gates/AUTOFILL_FEASIBILITY_GATE.md'
with p.open('a') as file:
    file.write('''

## Subsequent focus-value and native capacity findings — 2026-10-16

The latest918 hosted run tests merge3781e31a/treebd9eb473 exactly equal to918. Ubuntu/macOS pass all19 active suites; Windows passes compiler/contracts and visible browser/controlled scopes, then exhausts fixture storage. Its final Python summary is absent,18 setup errors are observed, and tracked-clean is SKIPPED. A separate contact environment-guard F has no retained stack and remains causally unresolved. Five old waiver cases map to passing progress symbols only; KI-0093 still requires complete fresh native validation. Full raw/source/API/independent proof is retained in docs/evidence/m02-w14-918-ci. This is not a three-OS aggregate PASS.

New independent actual-MV3 focus probes reproduce KI-0094 at918: four unchanged positives pass, four text/date execute/undo focus-value negatives fail and lose the newer page edit. The exact reviewed two-file correction passes unchanged GREEN8 and23 existing adjacent cases, including real partial-write recovery, with immutable source/probe/build bindings. Newer focus values are preserved with zero additional setter/input/change events and no VERIFIED/execute-undo authority. Complete original and corrected evidence: docs/evidence/m02-w14-focus-value-red and m02-w14-focus-value-green. Root integrated the exact patch and permanent eight cases; full root validation remains pending. The asynchronous descriptor-pause concern was not reproduced and its draft is excluded.

Reviewed revision8 separately binds corrected runtime355/8c61ebee under lock0f22812d; all frozen comparison data, actors, observer and revision7 history remain exact. No actor has run under revision8 yet; revision7 results remain historical. The fixture-only KI-0095 correction registers strict cleanup for each complete isolated function-scoped copy before any copy setup; it preserves inputs/assertions/thresholds. Fresh local and native verification remain pending. No prior performance/contact/comparison result is rebound to the changed source.

Public scored coverage and actual normal-user Simplify cases remain0; formal W15 review/owner decision remain incomplete. Owner holdout is waived. Gate A and W14 stay IN_PROGRESS, W15/M03 NOT_STARTED and release NOT_READY.
''')

p = root / 'scripts/tests/test_validate_status.py'
text = p.read_text()
assert text.count('        "KI-0093",') == 3
p.write_text(text.replace('        "KI-0093",', '        "KI-0093",\n        "KI-0094",\n        "KI-0095",'))
print('Integrated current governance and existing finding-list boundaries; no package/gate promotion.')
