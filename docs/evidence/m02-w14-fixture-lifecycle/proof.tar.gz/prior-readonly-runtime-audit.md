# Preliminary read-only Python runtime audit — 918dedb

No fix is warranted from the observed timings alone. There is a concrete repeated-copy/read cost path worth investigating if native CI actually exhausts its budget, but the current 918 CI run has no observed timeout/failure. This audit ran no tests, builds, browser sessions or benchmarks and changed no repository files.

## Observations and limits

Root's retained clean-918 proof `/tmp/japp-w14-python-918-retained/proof.tar.gz` (SHA-256 `87daa8d094c38e8ac94328df48549e63c1cceab362863bbbdfa87b4dd6ba5fe2`) records 1454 PASS in 583.78 pytest seconds, unchanged HEAD/source inventory and clean before/after status. The earlier clean-0dd proof `docs/evidence/m02-w14-frozen-0dd88ce/summary.json` records the same 1454 PASS in 285.82 seconds. Focused 201-case status runs are recorded at 118.88 seconds and then 114.40 seconds in `docs/TEST_EVIDENCE.md:42`; root additionally reports an earlier approximately53-second checkpoint. These are separate executions, not a controlled performance experiment. The latest full-suite timing is about2.04times the earlier one; no per-test setup/call/teardown profile, matched host-load state or matched filesystem-cache state is available to attribute that change.

Current source reference is `918dedb3fc379e1fc19cf6ef54bbefa1110b35d3` (clean when inspected). From 0dd to918, Python source changes are limited to two issue IDs in the existing synthetic lists and explicit UTF8 reads/writes in four waiver fixtures. No fixture-copy, validator, traceability, doctor, verifier or test-inventory algorithm changed. No Python testcase was added or removed. The retained docs payload did grow.

## Exact footprint and repeated work

Read-only `git ls-tree -r -l` at each immutable commit gives logical tracked-file bytes, not filesystem allocated bytes:

| Scope | 0dd88ce | 918dedb | Delta |
|---|---:|---:|---:|
| All docs | 121,234,155 bytes / 115.62 MiB /487 files | 129,690,120 bytes / 123.68 MiB /517 files | 8,455,965 bytes /6.97% |
| docs/evidence | 118,525,890 bytes /113.04 MiB /463 files | 126,958,029 bytes /121.08 MiB /493 files | 8,432,139 bytes |
| Compressed evidence (.gz/.zip) | 95,701,237 bytes /70 files | 104,007,731 bytes /77 files | 8,306,494 bytes |

Three default function-scoped fixtures copy the entire real `docs/` tree using `shutil.copytree`:

- `scripts/tests/test_validate_status.py:112–117` (`repo_copy`):196 committed POSIX node IDs directly request this fixture, from201 module node IDs.
- `scripts/tests/test_doctor.py:109–113` (`doctor_repo`):11 committed node IDs directly request it, from50 module node IDs.
- `scripts/tests/test_traceability.py:26–29` (`trace_repo`):48 committed node IDs directly request it, from63 module node IDs.

Those counts come from existing `scripts/python-test-inventory.v1.json` joined to fixture argument names in source AST; this audit did not recollect or run pytest. At least255 declared node IDs therefore request a fresh complete docs copy. That is approximately30.80 GiB (33,070,980,600 bytes) of logical docs payload copied per full Python execution, excluding other files copied by these fixtures, repeated scans, directory metadata and temporary-directory cleanup. The commit delta alone adds about2.01 GiB (2,156,271,075 bytes) to that logical copy workload. These are payload-accounting quantities, not measured disk reads/writes: filesystem optimizations, page cache and cleanup timing can materially change physical I/O.

There is also repeated full-file content scanning: `scripts/validate_status.py:2806–2834` walks every file below docs and searches each noncanonical regular file's complete `read_bytes()` for the canonical specification marker. It does not exempt or decompress evidence archives. `run_validator` in status tests launches this validator against a fresh copied fixture (`test_validate_status.py:102–107`); `traceability.validate_repository` also calls the same full canonical check (`scripts/traceability.py:1933`). Several tests invoke validation more than once. This makes retained archive growth relevant even when the test's intended mutation is one small status row. The doctor fixture likewise pays the docs copy cost, although its command runner is often stubbed and should not be assumed to perform an actual validator scan in every test.

The docs footprint grew about6.97%, while full pytest elapsed approximately doubled. A linear byte-volume explanation alone is insufficient; metadata costs, cleanup, host contention, caches, antivirus or other test work remain unmeasured. No causation or native-Windows forecast follows from this audit.

## Native-CI capacity

The workflow has a60-minute job limit (`.github/workflows/ci.yml:56`), and an existing CI policy test explicitly enforces at most60 minutes (`scripts/tests/test_ci_workflow.py:255`). Verifier children have a separate1800-second limit (`scripts/verify.py:64,761`). Root reports historical d99 Windows Python1118.28seconds and approximately53minutes overall: that leaves about681.72seconds of Python-child headroom and about7minutes of job headroom at that historical execution. The Windows Python run failed five UTF8 fixture cases, so it is not a complete passing baseline, although its elapsed duration is useful context. Native918 is still a distinct live run; its completion and duration remain unknown here. The new macOS number must not be multiplied into the Windows history as a prediction.

## Conditional options, if native CI actually times out

1. First identify whether the terminal timeout is the1800-second child or60-minute job, and whether setup/copy/cleanup or validator execution dominates. Use retained CI timestamps and the failing terminal phase first. No additional local test run is needed now merely to collect more timings.
2. A byte-identical filesystem clone/copy-on-write helper with a complete independent-copy fallback is the cleanest theoretical harness-only route: preserve every path and byte while reducing payload copies when the host filesystem supports it. It must be capability checked, preserve fixture isolation, and prove that writing a copied archive cannot alter root or another fixture. Current native-CI support and likely benefit are unestablished, so this is an option for reviewed profiling work, not a proposed fix.
3. Simply replacing `copy2` with `copyfile` is not a demonstrated Windows improvement. The repository-pinned CPython3.12 `shutil.py` already uses `_winapi.CopyFile2` when available; `copyfile` has a separate buffered Windows path. Dropping metadata may save work on some hosts but may remove that native fast path. No change should be made without native evidence and a review of which fixture metadata is required.
4. A future fixture-scope redesign could copy only the project-memory/evidence surface each test actually consumes while retaining a complete real-repository archive/canonical guard. That requires an explicit equivalence/coverage review; it is not a safe one-line `ignore=...` patch under the present full-docs fixture contract. Omitting archives, substituting stubs/empty bytes, symlinking archives (the canonical guard skips ordinary symlink content), or sharing mutable hardlinks would change evidence or isolation and is not recommended.

Do not skip tests, remove raw evidence, lower the exact1454 inventory, alter accuracy/safety/performance thresholds, weaken the canonical guard, swallow timeouts or relax the existing CI policy to obtain green. No harness change is currently proposed. Wait for the already-running native918 result; if it completes with sufficient budget, record the observed duration and retain this as a scaling concern rather than starting a speculative optimization loop.
