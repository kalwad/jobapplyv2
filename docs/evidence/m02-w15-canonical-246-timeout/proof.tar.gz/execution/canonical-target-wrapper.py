from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
CLONE = BASE / "clone"
PROOF = BASE / "proof"
NODE = "/opt/homebrew/opt/node@24/bin/node"
PNPM = "/opt/homebrew/opt/node@24/bin/pnpm"
FREEZE = json.loads((BASE / "source-freeze.json").read_text())
HEAD = FREEZE["frozen_commit"]
TREE = FREEZE["frozen_tree"]
OVERLAY = "e2e/extension/extension-benchmark.spec.ts"
OVERLAY_SHA = "e129f819b41b22e7b05447e3a7d86d43c2c5ab1860f62724a4fa857db18904da"
RUNTIME = "sha256:4f5a9608eb23a80a15a81b4a79494901907c4ad7e5c6a996fbce455b498c77d5"
TITLE = "W13 L: total scan and re-resolution scaling includes work outside W11"
ENV = dict(os.environ)
ENV["PATH"] = "/opt/homebrew/opt/node@24/bin:" + ENV.get("PATH", "")
ENV["JAPP_W13_PERFORMANCE_SAMPLES"] = "20"
ENV["PLAYWRIGHT_JSON_OUTPUT_NAME"] = str(PROOF / "results.json")
ARGV = [PNPM, "exec", "playwright", "test", OVERLAY, "--grep", TITLE, "--reporter=line,json"]


def now() -> str:
    return dt.datetime.now(dt.UTC).isoformat()


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def save(name: str, value: object) -> None:
    (PROOF / name).write_text(json.dumps(value, indent=2) + "\n")


def capture(argv: list[str]) -> str:
    return subprocess.check_output(argv, cwd=CLONE, env=ENV, text=True).strip()


def sources() -> dict:
    paths = subprocess.check_output(["git", "ls-files", "-z"], cwd=CLONE).split(b"\0")
    files = []
    for raw in paths:
        if not raw:
            continue
        rel = raw.decode()
        data = (CLONE / rel).read_bytes()
        files.append({"path": rel, "bytes": len(data), "sha256": digest(data)})
    return {
        "at": now(),
        "head": capture(["git", "rev-parse", "HEAD"]),
        "tree": capture(["git", "rev-parse", "HEAD^{tree}"]),
        "status_porcelain": capture(["git", "status", "--porcelain=v1"]),
        "diff_binary": capture(["git", "diff", "--binary"]),
        "files": files,
        "total_bytes": sum(item["bytes"] for item in files),
    }


def verify_sources(value: dict) -> None:
    assert value["head"] == HEAD
    assert value["tree"] == TREE
    assert value["status_porcelain"] == "", value["status_porcelain"]
    assert next(item["sha256"] for item in value["files"] if item["path"] == OVERLAY) == OVERLAY_SHA


def runtime() -> dict:
    code = "import {captureRuntimeInventory} from './e2e/extension/legacy-paired-options/runtime-inventory.ts'; console.log(JSON.stringify(captureRuntimeInventory(process.cwd())));"
    value = json.loads(capture([NODE, "--input-type=module", "-e", code]))
    assert value["digest"] == RUNTIME
    assert len(value["files"]) == 355
    assert value["total_bytes"] == 3372811
    return value


def built() -> dict:
    result = {"at": now(), "scope": "Actual build-output endpoints; before is absent in fresh clone. Canonical Playwright global setup builds production and invalid-ACK variants before the test.", "directories": {}}
    for rel in ["apps/extension/dist/chrome-mv3", "apps/extension/dist/invalid-ack/chrome-mv3", "apps/mock-ats-lab/dist"]:
        target = CLONE / rel
        files = []
        if target.exists():
            for path in sorted(target.rglob("*")):
                if path.is_file():
                    data = path.read_bytes()
                    files.append({"path": path.relative_to(CLONE).as_posix(), "bytes": len(data), "sha256": digest(data)})
        result["directories"][rel] = {"exists": target.exists(), "files": files, "total_bytes": sum(item["bytes"] for item in files)}
    return result


def tools() -> dict:
    result = {
        "at": now(),
        "node": capture([NODE, "--version"]),
        "node_exec_path": capture([NODE, "-p", "process.execPath"]),
        "pnpm": capture([PNPM, "--version"]),
        "playwright": capture([PNPM, "exec", "playwright", "--version"]),
        "python": sys.version,
        "platform": platform.platform(),
        "machine": platform.machine(),
    }
    assert result["node"] == "v24.18.0"
    assert result["pnpm"] == "11.17.0"
    assert result["playwright"] == "Version 1.62.0"
    for rel in ["pnpm-lock.yaml", "node_modules/.pnpm/lock.yaml"]:
        data = (CLONE / rel).read_bytes()
        result[rel] = {"bytes": len(data), "sha256": digest(data)}
    return result


def rows_from_log() -> dict:
    raw = (PROOF / "run.log").read_bytes()
    lines = [line for line in raw.splitlines(keepends=True) if b"W13_SCALING " in line]
    assert len(lines) == 1, len(lines)
    (PROOF / "W13_SCALING-exact-line.log").write_bytes(lines[0])
    text = lines[0].decode()
    value, _ = json.JSONDecoder().raw_decode(text[text.index("W13_SCALING ") + len("W13_SCALING "):])
    rows = value["rows"]
    save("all-canonical-rows.json", rows)
    native = [row for row in rows if row["control_count"] == 128]
    assert len(rows) == 22 and len(native) == 20
    work_checks = {
        "reresolution_calls": 512, "descriptors_built": 768,
        "index_rebuilds": 1, "index_hits": 511, "index_invalidations": 0,
        "candidate_enumerations": 3, "candidates_examined": 384,
        "identity_pairs_examined": 128,
        "preflight_reresolutions": 128, "preaction_reresolutions": 128,
        "settle_reresolutions": 128, "reconcile_reresolutions": 128,
        "other_reresolutions": 0,
    }
    violations = []
    for index, row in enumerate(native, 1):
        for key, expected in {"actions_attempted": 128, "physical_actions_count": 128, "settle_budget_ms": 0}.items():
            if row[key] != expected:
                violations.append({"sample": index, "key": key, "expected": expected, "actual": row[key]})
        for key, expected in work_checks.items():
            if row["scanner_work"][key] != expected:
                violations.append({"sample": index, "key": key, "expected": expected, "actual": row["scanner_work"][key]})
        assert "phase_wall_clock_ms" not in row, "CANONICAL_TEST_HAS_NO_PHASE_OVERLAY"
    ordered = sorted(enumerate(native, 1), key=lambda pair: pair[1]["total_wall_clock_ms"])
    p95_sample, p95 = ordered[18]
    return {
        "scope": "CANONICAL_UNCHANGED_NATIVE128_TARGET20_ON_FROZEN_SOURCE; zero-settle lower-bound harness validation, not full-settlement Gate A performance or final verdict. Previous full/diagnostic/rejected-proposal failures remain historical. One invocation, no retry.",
        "source_commit": HEAD, "source_tree": TREE,
        "sample_count": 20, "rank": 19, "p95_sample": p95_sample,
        "p95_ms": p95["total_wall_clock_ms"], "threshold_ms": 1500,
        "threshold_pass": p95["total_wall_clock_ms"] <= 1500,
        "all_rows_retained": len(rows), "all_workload_checks_pass": not violations,
        "workload_violations": violations, "raw_line_bytes": len(lines[0]),
        "raw_line_sha256": digest(lines[0]),
    }


def discover() -> dict:
    argv = ARGV[:-1] + ["--list", "--reporter=json"]
    env = dict(ENV)
    env.pop("PLAYWRIGHT_JSON_OUTPUT_NAME", None)
    result = subprocess.run(argv, cwd=CLONE, env=env, capture_output=True)
    (PROOF / "discovery.stdout.json").write_bytes(result.stdout)
    (PROOF / "discovery.stderr.log").write_bytes(result.stderr)
    save("discovery-command.json", {"at": now(), "argv": argv, "cwd": str(CLONE), "exit_code": result.returncode, "scope": "Canonical --list skips global setup/build/browser"})
    value = json.loads(result.stdout)
    matches = []
    def visit(suites):
        for suite in suites:
            for spec in suite.get("specs", []):
                matches.append({"file": spec.get("file"), "title": spec["title"], "tests": len(spec.get("tests", []))})
            visit(suite.get("suites", []))
    visit(value["suites"])
    summary = {"at": now(), "exit_code": result.returncode, "matches": matches, "total_specs": len(matches), "total_tests": sum(item["tests"] for item in matches)}
    save("discovery-summary.json", summary)
    assert result.returncode == 0 and len(matches) == 1 and matches[0]["title"] == TITLE and summary["total_tests"] == 1, summary
    return summary


def run() -> int:
    release = json.loads((BASE / "root-actor-release.json").read_text())
    assert release["parent_explicit_release"] is True
    assert release["all_heavy_work_quiesced"] is True
    assert release["frozen_commit"] == HEAD
    assert release["maximum_invocations"] == 1
    discovery = json.loads((PROOF / "discovery-summary.json").read_text())
    assert discovery["exit_code"] == 0 and discovery["total_specs"] == discovery["total_tests"] == 1
    assert discovery["matches"][0]["title"] == TITLE
    assert not (PROOF / "invocation-started.json").exists(), "ONE_INVOCATION_ONLY"
    before = sources()
    verify_sources(before)
    save("before-sources.json", before)
    save("before-runtime.json", runtime())
    save("before-tools.json", tools())
    save("before-build.json", built())
    save("command.json", {"at": now(), "argv": ARGV, "cwd": str(CLONE), "environment": {key: ENV[key] for key in ["PATH", "JAPP_W13_PERFORMANCE_SAMPLES", "PLAYWRIGHT_JSON_OUTPUT_NAME"]}, "trace_policy": "Original retain-on-failure; no trace override", "parent_release": release, "wrapper_path": str(Path(__file__).resolve()), "wrapper_sha256": digest(Path(__file__).read_bytes())})
    with (PROOF / "invocation-started.json").open("x") as marker:
        marker.write(json.dumps({"at": now(), "one_invocation_only": True}) + "\n")
    started = time.monotonic()
    proc = subprocess.Popen(ARGV, cwd=CLONE, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    with (PROOF / "run.log").open("wb") as log:
        assert proc.stdout is not None
        for line in proc.stdout:
            log.write(line)
            log.flush()
            if b"W13_SCALING " not in line:
                sys.stdout.buffer.write(line)
                sys.stdout.buffer.flush()
    exit_code = proc.wait()
    save("completion.json", {"at": now(), "exit_code": exit_code, "duration_s": time.monotonic() - started})
    # Retain native test artifacts immediately, before any possible later
    # Playwright invocation can clear its default output directory.
    source_artifacts = CLONE / "test-results"
    if source_artifacts.exists():
        shutil.copytree(source_artifacts, PROOF / "native-test-results")
    artifact_files = []
    for path in sorted((PROOF / "native-test-results").rglob("*")):
        if path.is_file():
            data = path.read_bytes()
            artifact_files.append({"path": path.relative_to(PROOF).as_posix(), "bytes": len(data), "sha256": digest(data)})
    save("native-artifact-retention.json", {"at": now(), "files": artifact_files})
    after = sources()
    save("after-sources.json", after)
    save("after-runtime.json", runtime())
    save("after-tools.json", tools())
    save("after-build.json", built())
    verify_sources(after)
    assert before["files"] == after["files"]
    assert before["diff_binary"] == after["diff_binary"]
    summary = rows_from_log()
    summary["child_exit_code"] = exit_code
    summary["all_tracked_source_unchanged"] = True
    summary["no_source_overlay"] = True
    save("canonical-target-summary.json", summary)
    print(json.dumps(summary, indent=2), flush=True)
    assert summary["all_workload_checks_pass"], summary["workload_violations"]
    return exit_code


def setup_source_only() -> None:
    assert FREEZE["runtime_digest"] == RUNTIME
    assert FREEZE["runtime_files"] == 355 and FREEZE["runtime_bytes"] == 3372811
    if CLONE.exists():
        return
    commands = [
        (["git", "clone", "--no-hardlinks", "/Users/tanishkalwad/jobapplyv2", str(CLONE)], BASE),
        (["git", "checkout", "--detach", HEAD], CLONE),
        ([PNPM, "install", "--frozen-lockfile", "--offline", "--ignore-scripts"], CLONE),
    ]
    history = []
    with (PROOF / "setup.log").open("wb") as log:
        for argv, cwd in commands:
            result = subprocess.run(argv, cwd=cwd, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            log.write(result.stdout)
            log.flush()
            history.append({"at": now(), "argv": argv, "cwd": str(cwd), "exit_code": result.returncode})
            save("setup-commands.json", history)
            if result.returncode:
                sys.stdout.buffer.write(result.stdout)
                raise RuntimeError("Source setup failed; no browser/performance actor ran")


parser = argparse.ArgumentParser()
parser.add_argument("--prepare", action="store_true")
parser.add_argument("--run-after-parent-release", action="store_true")
args = parser.parse_args()
PROOF.mkdir(exist_ok=True)
if args.prepare:
    setup_source_only()
    prepared = sources()
    verify_sources(prepared)
    save("prepared-sources.json", prepared)
    save("prepared-runtime.json", runtime())
    save("prepared-tools.json", tools())
    save("prepared-build.json", built())
    save("prepared-plan.json", {"at": now(), "argv": ARGV, "cwd": str(CLONE), "source_only": True, "browser_build_actors": 0, "release_required": True, "no_source_overlay": True, "frozen_source_binding": FREEZE})
    discovery = discover()
    print("PREPARED_ONLY: clean frozen source/tools/runtime bound; canonical benchmark unchanged; exactly one W13 L test discovered; no build or browser launched.", flush=True)
elif args.run_after_parent_release:
    sys.exit(run())
else:
    parser.error("select --prepare or --run-after-parent-release")
