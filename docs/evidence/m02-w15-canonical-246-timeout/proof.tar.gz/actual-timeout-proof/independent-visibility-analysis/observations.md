# Independent closed-trace visibility and lifecycle observations

Scope: read-only analysis of the sealed trace.zip and its exact clone source. No browser, build, test, or source mutation. Derived files only in this directory.

The three embedded trace source resources are byte-identical to the clone files: extension-test.ts -> resources/src@02e076c20a88af1c4a09846339425f72789d20db.txt; research-harness.ts -> resources/src@dc5b9f7ecb4837c39f4bd155416a330263823cce.txt; extension-benchmark.spec.ts -> resources/src@f3969be1b855ab7760ce665a35ac7188448509e3.txt. Resource names are identifiers, not asserted content hashes.

Observed identities and API sequence:
- 21 harnesses create /native/ target pages and extension manifest controllers. The first 20 reach reconciliation and explicitly close both pages. Source: research-harness.ts:120-130 and benchmark.spec.ts:181-183. See harness-sequence.json for all IDs and exact trace lines.
- All 21 explicit bringToFront calls target the /native/ page, before the worker tabs.query({active:true,lastFocusedWindow:true}) and before controller creation. No controller bringToFront or later target bringToFront is recorded. This is API order, not a measurement of subsequent focus/visibility.
- Final target is page@5b9ff5a06a16c307fd27f37fa2036486; /native/ goto at 0-trace.trace:1752. Final controller is page@dec4098c0b11fd07dc8fe12195e83dbc; manifest goto at :1774.
- Final target bringToFront call@1003 runs 124008.946-124009.588 (:1765-1766); worker query call@1005 returns tabId 603821165 at 124010.608 (:1767-1769). Controller creation event occurs at 124042.609 (:1772).
- The initial page@0463296574ff1d139c1f49c724f9e83c appears in screencasts but has no recorded goto or bringToFront. Its URL/state cannot be established from these records.

Explicit observables:
- The context records headless:true, platform:darwin, Chromium channel, viewport 1280x720 (0-trace.trace:1).
- No visibilityState, document.hidden, visibilitychange, hasFocus, focus/blur event, timer scheduling/firing, requestAnimationFrame, throttling, or Page.setWebLifecycleState measurement is present in test.trace or 0-trace.trace. Broad focus matches are only the worker query's lastFocusedWindow filter. Snapshot records contain HTML/viewport/time, not document visibility or focus fields.
- Source benchmark.spec.ts:66 sets a 120000ms test-runner timeout; :126-128 overwrites each transaction settle budget to zero. :98-113 requests Browser.getVersion and Performance metrics for TaskDuration/JSHeapUsedSize. These are not timer-throttling measurements.

Timeout/lifecycle ordering:
- Initial serviceworker wait call@6 finishes at 5921.435 (0-trace.trace:2-4). The trace records 21 successful worker tab queries but no worker close/restart/crash event. That absence does not prove continuous worker lifetime.
- The final scan returns 128 descriptors (0-trace.trace:1795-1797; test.trace:11346-11347 verifies 128).
- Final execute-136 requests 32 items on tab 603821165, from the controller (0-trace.trace:1799, call@1027, startTime 124150.240); it has no library after record.
- The matching test-runner evaluate starts at 124148.823 (test.trace:11348); timeout error follows at :11349 and After Hooks begins at 124151.464 (:11350).
- ExtensionContext teardown begins at 124179.567 (:11355). Explicit Close context begins at 124472.798 (:11358; stack extension-test.ts:116, whose source is context?.close()). The pending evaluate reports Target page, context or browser has been closed at 124478.760 (:11359-11360). Close context completes at 124520.658 (:11361).
- Library events stop before those cleanup errors: final record :1803 is a screencast at 124178.899; no final target/controller pageClosed, navigation, pageerror, or crash event is recorded in the library trace. The last explicit pageClosed events are the preceding harness at :1744 and :1747.

No inference is made about OS foreground, target visibility after controller creation, timer throttling, or benchmark root cause. The trace establishes a global timeout followed by teardown and a pending evaluation's closure error; it does not supply the missing visibility/timer causal evidence.
