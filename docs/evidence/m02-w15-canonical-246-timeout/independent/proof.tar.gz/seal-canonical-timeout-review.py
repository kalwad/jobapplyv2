#!/usr/bin/env python3
"""Retain only this completed independent documentary failure component."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

BASE = Path('/tmp/japp-m02-w15-independent-audit')
OUT = Path('/tmp/japp-m02-w15-independent-canonical-246-timeout-retained')
OUT.mkdir(exist_ok=True)
archive = OUT / 'proof.tar.gz'
assert not archive.exists(), 'Refuse overwrite of immutable component'
paths = [BASE / 'audit-canonical-timeout-source.py',
         BASE / 'audit-canonical-timeout-closure.py', Path(__file__)]
for directory in ['canonical-timeout-source-review', 'canonical-timeout-source-review-v2',
                  'canonical-timeout-final-review', 'canonical-stall-trace-child']:
    paths.extend(p for p in (BASE / directory).rglob('*') if p.is_file())
assert len(paths) == len(set(paths))
rows = []
payloads = []
for path in sorted(paths):
    assert not path.is_symlink()
    name = str(path.relative_to(BASE))
    assert '..' not in Path(name).parts
    data = path.read_bytes()
    rows.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    payloads.append((name, data))
manifest = {'scope': 'Independent closed246 canonical timeout documentary component; no acceptance authority.',
            'source_commit': '2464519e0b04de123ef51c3d9cb0363456b5b0eb',
            'source_tree': '75660b6a105a2873b0020d3a2d4c24dfb75e15e5', 'files': rows}
manifest_data = (json.dumps(manifest, indent=2) + '\n').encode()
payloads.append(('retention-manifest.json', manifest_data))
with archive.open('xb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tf:
            for name, data in payloads:
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                tf.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tf:
    members = tf.getmembers()
    assert len(members) == len(payloads)
    assert len({m.name for m in members}) == len(members)
    expected = dict(payloads)
    for member in members:
        assert member.isfile() and not member.issym() and not member.islnk()
        assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        assert tf.extractfile(member).read() == expected[member.name]
for path in paths:
    row = next(row for row in rows if row['path'] == str(path.relative_to(BASE)))
    data = path.read_bytes()
    assert (len(data), hashlib.sha256(data).hexdigest()) == (row['bytes'], row['sha256'])
data = archive.read_bytes()
result = {'archive': str(archive), 'bytes': len(data),
          'sha256': hashlib.sha256(data).hexdigest(), 'regular_members': len(payloads),
          'source_members': len(rows), 'source_payload_bytes': sum(row['bytes'] for row in rows),
          'all_payload_bytes_and_safe_paths_checked': True,
          'all_source_files_recaptured_exact_after_write': True,
          'authority': 'NONE', 'outcome': 'CANONICAL_TIMEOUT_ACCEPTANCE_BLOCKED'}
(OUT / 'retention-manifest.json').write_bytes(manifest_data)
(OUT / 'archive-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
