#!/usr/bin/env python3
"""Independent documentary closure over retained bytes; no repository imports."""
from pathlib import Path
import hashlib
import json
import zipfile

BASE = Path('/tmp/japp-m02-w15-independent-audit')
CHILD = BASE / 'canonical-stall-trace-child'
RUN = Path('/tmp/japp-m02-w15-native128-canonical-final-20261017')
OUT = BASE / 'canonical-timeout-final-review'
OUT.mkdir(exist_ok=True)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def load(path):
    return json.loads(path.read_text())

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

inputs = load(CHILD / 'inputs.json')
for row in inputs:
    data = Path(row['path']).read_bytes()
    assert (len(data), digest(data)) == (row['bytes'], row['sha256']), row['path']

retained = load(CHILD / 'retention-manifest.json')['files']
for row in retained:
    rel = Path(row['path'])
    assert not rel.is_absolute() and '..' not in rel.parts
    path = CHILD / rel
    assert not path.is_symlink() and path.is_file()
    data = path.read_bytes()
    assert (len(data), digest(data)) == (row['bytes'], row['sha256']), row['path']

trace_path = Path(inputs[0]['path'])
with zipfile.ZipFile(trace_path) as archive:
    for name in archive.namelist():
        p = Path(name)
        assert not p.is_absolute() and '..' not in p.parts
    raw = {name: archive.read(name).splitlines()
           for name in ['0-trace.trace', 'test.trace']}
    library = [json.loads(line) for line in raw['0-trace.trace']]
    runner = [json.loads(line) for line in raw['test.trace']]
    for row in load(CHILD / 'trace-members.json'):
        data = archive.read(row['member'])
        assert (len(data), digest(data)) == (row['bytes'], row['sha256'])

critical = load(CHILD / 'critical-events.json')
metric_joins = load(CHILD / 'metric-boundary-joins.json')
for row in critical + metric_joins:
    line = raw[row['member']][row['line'] - 1]
    assert digest(line) == row['raw_line_sha256']
    assert json.loads(line) == row['event']

findings = load(CHILD / 'findings.json')
timing = load(CHILD / 'timing-brackets.json')
assert findings['checks_passed'] == findings['checks_total'] == 12
assert all(findings['checks'].values())
assert findings['ordinary_status'] == 'timedOut'
assert findings['p95_ms'] is None and findings['canonical_rows_emitted'] == 0
assert findings['runner_timing']['evaluate_start_to_after_hooks_ms'] == 2.641
assert findings['iteration_counts'] == {
    'scanned': 21, 'native128_scanned': 19,
    'native128_reconciled': 18, 'native128_not_started': 1,
}
assert len(timing['iterations']) == 21
completed = [row for row in timing['iterations']
             if 'source_timed_interval_duration_bracket_ms' in row]
native = [row for row in completed if row['control_count'] == 128]
assert len(completed) == 20 and len(native) == 18
for bound in [0, 1]:
    assert round(sum(row['source_timed_interval_duration_bracket_ms'][bound]
                     for row in completed), 3) == timing['all_20_completed_timed_interval_bracket_sum_ms'][bound]
    assert round(sum(row['source_timed_interval_duration_bracket_ms'][bound]
                     for row in native), 3) == timing['completed_native128_timed_interval_bracket_sum_ms'][bound]

context = library[0]
launch = next(row for row in runner if row.get('title') == 'Launch persistent context'
              and row['type'] == 'before')
assert context['type'] == 'context-options'
assert context['playwrightVersion'] == '1.62.0'
assert context['options']['ignoreAllDefaultArgs'] is False
assert launch['params']['ignoreDefaultArgs'] == 'undefined'
assert len(context['options']['args']) == 2

core_path = RUN / 'clone/node_modules/.pnpm/playwright-core@1.62.0/node_modules/playwright-core/lib/coreBundle.js'
core_data = core_path.read_bytes()
core_lines = core_data.decode().splitlines()
switches = ['--disable-background-timer-throttling',
            '--disable-backgrounding-occluded-windows', '--disable-renderer-backgrounding']
switch_locations = {switch: [n for n, line in enumerate(core_lines, 1)
                            if '"' + switch + '"' in line] for switch in switches}
assert all(switch_locations.values())
default_spread_lines = [n for n, line in enumerate(core_lines, 1)
                        if 'const chromeArguments = [...chromiumSwitches()]' in line]
assert default_spread_lines
save('pinned-playwright-launch-context.json', {
    'source_path': str(core_path), 'source_bytes': len(core_data),
    'source_sha256': digest(core_data), 'switch_locations': switch_locations,
    'default_switch_spread_lines': default_spread_lines,
    'recorded_context_options': context, 'recorded_launch_event': launch,
    'limit': 'Pinned source/default options only. Actual process command line and flag effectiveness are not recorded by this proof; no background or focus cause is established.',
})

own = load(BASE / 'canonical-timeout-source-review-v2/findings.json')
assert own['candidate_commit'] == findings['source_commit']
assert own['candidate_tree'] == findings['source_tree']
assert own['source_before_after_clean_exact']
assert own['all6_retained_native_artifact_commitments_exact']
assert own['runtime_files'] == 355 and own['runtime_bytes'] == 3372811
save('findings.json', {
    'result': 'CANONICAL_TIMEOUT_CONFIRMED_ACCEPTANCE_BLOCKED',
    'authority': 'NONE', 'owner_decision': 'PENDING',
    'source_commit': own['candidate_commit'], 'source_tree': own['candidate_tree'],
    'runtime_digest': own['runtime_digest'], 'runtime_files': own['runtime_files'],
    'runtime_bytes': own['runtime_bytes'],
    'actual_status': findings['ordinary_status'], 'deadline_ms': 120000,
    'requested_native128_samples': 20, 'canonical_rows': 0, 'p95_ms': None,
    'native128_complete_trace_iterations': 18, 'pending_iteration': 19,
    'pending_first_batch_sections': ['SECTION_0', 'SECTION_31'],
    'runner_evaluate_start_to_after_hooks_ms': 2.641,
    'completed_execute_rpc_wall_ms': timing['completed_rpc_duration_sums_ms']['M02_W11_EXECUTE_TAB'],
    'whole_before_hooks_to_after_hooks_ms': timing['whole_before_hooks_to_after_hooks_ms'],
    'child_retained_files_hash_checked': len(retained),
    'child_retained_bytes_hash_checked': sum(row['bytes'] for row in retained),
    'source_input_commitments_hash_checked': len(inputs),
    'raw_critical_event_and_boundary_joins_checked': len(critical) + len(metric_joins),
    'all_child_artifact_checks': 12,
    'canonical_source_and_all6_native_artifacts_own_audit': True,
    'review_classification': {
        'own': 'Complete tracked-snapshot/runtime-row/build/native-artifact hash closure; selected transport/driver/wait/launch source; independent raw event and boundary/hash cross-checks.',
        'delegated_independent': 'Complete retained trace request/iteration reconstruction and source endpoint timing brackets, reviewed and hash-resolved by this auditor.',
        'behavioral_reproduction_by_this_auditor': 'NONE; all browser/build/test actors held.',
    },
    'limits': [
        'No p95 or canonical elapsed rows reconstructed from partial iterations.',
        'No120-second individual RPC stall is established; overall deadline arrives just after the pending RPC starts.',
        'Completed RPC wall time includes IPC, browser/extension waits and trace/API overhead; no exclusive CPU or timer attribution.',
        'No exact physical progress inside pending first batch is established.',
        'Pinned Playwright default switches plus recorded launch options do not prove actual flag effectiveness or exclude visibility effects.',
        'Focused viewport28PASS and historical507a/6384 outcomes remain distinct; current final full/native/key/R10/owner requirements remain pending.',
        'Earlier source-audit and child timing bookkeeping failures remain retained.',
    ],
})
print(json.dumps({'result': 'DOCUMENTARY_CLOSURE_PASS_ACCEPTANCE_BLOCKED',
                  'child_files_hash_checked': len(retained),
                  'raw_event_joins_checked': len(critical) + len(metric_joins),
                  'canonical_rows': 0, 'p95_ms': None}))
