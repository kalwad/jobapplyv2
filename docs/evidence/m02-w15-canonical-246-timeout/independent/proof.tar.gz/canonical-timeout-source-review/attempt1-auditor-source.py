"""Independent closed timeout/source/artifact closure; no actors/imported code."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import subprocess

BASE = Path('/tmp/japp-m02-w15-native128-canonical-final-20261017')
PROOF = BASE / 'proof'
CLONE = BASE / 'clone'
OUT = Path('/tmp/japp-m02-w15-independent-audit/canonical-timeout-source-review')
assert not OUT.exists()
OUT.mkdir()
sha = lambda body: hashlib.sha256(body).hexdigest()
canon = lambda value: json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
read = lambda name: json.loads((PROOF / name).read_text())
command = read('command.json')
assert sha((BASE / 'canonical-target-wrapper.py').read_bytes()) == command['wrapper_sha256'] == '006328ea7ffdbda4d3e050814bd8f25ecce6a615ac51c787fa824698c0c8959d'
assert command['argv'] == ['/opt/homebrew/opt/node@24/bin/pnpm', 'exec', 'playwright', 'test',
    'e2e/extension/extension-benchmark.spec.ts', '--grep',
    'W13 L: total scan and re-resolution scaling includes work outside W11', '--reporter=line,json']
assert command['environment']['JAPP_W13_PERFORMANCE_SAMPLES'] == '20'
before, after = read('before-sources.json'), read('after-sources.json')
HEAD = '2464519e0b04de123ef51c3d9cb0363456b5b0eb'
TREE = '75660b6a105a2873b0020d3a2d4c24dfb75e15e5'
for state in [before, after]:
    assert state['head'] == HEAD and state['tree'] == TREE and state['status_porcelain'] == '' and state['diff_binary'] == ''
for key in ['head', 'tree', 'status_porcelain', 'diff_binary', 'files', 'total_bytes']:
    assert before[key] == after[key], key
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=CLONE, text=True).strip() == HEAD
assert subprocess.check_output(['git', 'rev-parse', HEAD + '^{tree}'], cwd=CLONE, text=True).strip() == TREE
runtime = read('before-runtime.json')
assert runtime == read('after-runtime.json') and len(runtime['files']) == 355 and runtime['total_bytes'] == 3372811
assert runtime['digest'] == 'sha256:4f5a9608eb23a80a15a81b4a79494901907c4ad7e5c6a996fbce455b498c77d5'
assert 'sha256:' + sha(canon(runtime['files'])) == runtime['digest']
runtime_rows = {row['path']: row for row in runtime['files']}
tracked_rows = {row['path']: row for row in before['files']}
for row in runtime['files']:
    body = (CLONE / row['path']).read_bytes()
    assert 'sha256:' + sha(body) == row['sha256']
    assert sha(body) == tracked_rows[row['path']]['sha256'] and len(body) == tracked_rows[row['path']]['bytes']
bench = (CLONE / 'e2e/extension/extension-benchmark.spec.ts').read_bytes()
assert sha(bench) == 'e129f819b41b22e7b05447e3a7d86d43c2c5ab1860f62724a4fa857db18904da'
assert 'phase_wall_clock_ms' not in bench.decode()
assert 'test.setTimeout(120_000)' in bench.decode() and 'expect(p95).toBeLessThanOrEqual(1500)' in bench.decode()
assert runtime_rows['apps/extension/src/drivers/text-like-drivers.ts']['sha256'] == 'sha256:543df12153d5c8ab0c97aa0c74dcd63eb4586e51bf849262755aba2d4698ed76'
assert runtime_rows['e2e/extension/support/extension-test.ts']['sha256'] == 'sha256:00ae82e2f237902e1081d99b3b7638030b7b5f239d10f3f226e460e0068d9e82'
assert {key: value for key, value in read('before-tools.json').items() if key != 'at'} == {key: value for key, value in read('after-tools.json').items() if key != 'at'}
completion = read('completion.json')
assert completion['exit_code'] == 1
report = read('results.json')
specs = []
def visit(suite):
    specs.extend(suite.get('specs', []))
    for child in suite.get('suites', []):
        visit(child)
for suite in report['suites']:
    visit(suite)
assert len(specs) == 1 and len(specs[0]['tests']) == 1
test = specs[0]['tests'][0]
assert test['expectedStatus'] == 'passed' and test['status'] == 'unexpected' and len(test['results']) == 1
result = test['results'][0]
assert result['retry'] == 0 and result['status'] == 'timedOut'
assert report['stats']['expected'] == 0 and report['stats']['unexpected'] == 1
assert report['stats']['skipped'] == report['stats']['flaky'] == 0 and not report['errors']
log = (PROOF / 'run.log').read_bytes()
assert b'Test timeout of 120000ms exceeded.' in log
assert not [line for line in log.splitlines() if b'W13_SCALING ' in line]
assert not [line for line in log.splitlines() if b'W13_TARGET_P95 ' in line]
retention = read('native-artifact-retention.json')
assert len(retention['files']) == 6
for row in retention['files']:
    p = PurePosixPath(row['path'])
    assert not p.is_absolute() and '..' not in p.parts
    body = (PROOF / row['path']).read_bytes()
    assert len(body) == row['bytes'] and sha(body) == row['sha256']
build = read('after-build.json')
build_files = []
for directory, group in build['directories'].items():
    assert group['exists']
    for row in group['files']:
        body = (CLONE / directory / row['path']).read_bytes()
        assert len(body) == row['bytes'] and sha(body) == row['sha256']
        build_files.append({'directory': directory, **row})
findings = {'result': 'CANONICAL_TARGET_TEST_TIMEOUT_CONFIRMED_NO_P95', 'authority': 'NONE',
    'candidate_commit': HEAD, 'candidate_tree': TREE, 'tracked_file_count_derived': len(before['files']),
    'source_before_after_clean_exact': True, 'runtime_files': 355, 'runtime_bytes': 3372811,
    'runtime_digest': runtime['digest'], 'canonical_benchmark_original_bytes_no_overlay': True,
    'deadline_ms': 120000, 'requested_native128_samples': 20, 'canonical_scaling_rows_retained': 0,
    'p95_ms': None, 'ordinary_report_status': result['status'], 'retry': 0,
    'child_exit_code': completion['exit_code'], 'run_log_bytes': len(log), 'run_log_sha256': sha(log),
    'all6_retained_native_artifact_commitments_exact': True, 'after_build_files_exact': build_files,
    'source_transport': ['runtimeMessage awaits controller.evaluate → chrome.runtime.sendMessage.',
        'Background dynamicFrameCall awaits tabs.sendMessage for exact registered frame.',
        'Content frame awaits dynamicEngine.executeDecisions; finite batch iterates each item sequentially.',
        'No per-RPC observation in this artifact supplies the precise pending native/metadata/internal event-loop operation.'],
    'source_environment_limits': ['openHarness brings target to front for tab query, then creates controller; native128 has no foreground/visibility assertion or recorded target visibility witness.',
        'settlWindow without signal awaits real setTimeout delay even for budget0. Source facts alone do not establish timer throttling or its cost.',
        'Target page/context closed error occurs after test deadline/teardown; it cannot alone establish an earlier page-close root cause.',
        'No canonical row/performance percentile may be reconstructed from partial trace iterations. Contact200 foreground/full-settlement evidence remains separate.'],
    'root_writes': 0, 'actors_run': 0}
(OUT / 'findings.json').write_text(json.dumps(findings, indent=2) + '\n')
for name in ['command.json', 'completion.json', 'results.json', 'native-artifact-retention.json']:
    (OUT / name).write_bytes((PROOF / name).read_bytes())
(OUT / 'auditor-source.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({key: findings[key] for key in ['result', 'tracked_file_count_derived', 'runtime_bytes', 'deadline_ms', 'canonical_scaling_rows_retained', 'p95_ms']}))
