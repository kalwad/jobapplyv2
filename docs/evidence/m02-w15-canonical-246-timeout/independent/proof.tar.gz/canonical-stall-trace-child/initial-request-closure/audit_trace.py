#!/usr/bin/env python3
"""Read retained Playwright JSON/ZIP only. Does not execute repository code."""
from pathlib import Path
import collections
import hashlib
import json
import re
import zipfile

ROOT = Path('/tmp/japp-m02-w15-native128-canonical-final-20261017')
OUT = Path(__file__).resolve().parent
PROOF = ROOT / 'proof'
TRACE = next((PROOF / 'native-test-results').rglob('trace.zip'))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def decode(value):
    # Playwright SerializedValue, preserving unsupported references rather than
    # guessing values. The requests/results inspected below contain no refs.
    if not isinstance(value, dict):
        return value
    if 'value' in value:
        return decode(value['value'])
    for key in ('s', 'n', 'b'):
        if key in value:
            return value[key]
    if 'v' in value:
        return value['v']
    if 'a' in value:
        return [decode(item) for item in value['a']]
    if 'o' in value:
        return {item['k']: decode(item['v']) for item in value['o']}
    return value

def specs(suite):
    yield from suite.get('specs', [])
    for child in suite.get('suites', []):
        yield from specs(child)

inputs = [TRACE, PROOF/'results.json', PROOF/'run.log', PROOF/'completion.json',
          PROOF/'command.json', ROOT/'source-freeze.json',
          ROOT/'canonical-target-wrapper.py',
          ROOT/'clone/e2e/extension/extension-benchmark.spec.ts',
          ROOT/'clone/e2e/extension/support/research-harness.ts']
input_manifest = []
for path in inputs:
    data = path.read_bytes()
    input_manifest.append({'path': str(path), 'bytes': len(data), 'sha256': sha(data)})
save('inputs.json', input_manifest)
with zipfile.ZipFile(TRACE) as archive:
    raw_members = {name: archive.read(name) for name in archive.namelist()
                   if name.endswith(('.trace', '.stacks')) or name.startswith('resources/src@')}
    member_manifest = [{'member': name, 'bytes': len(data), 'sha256': sha(data)}
                       for name, data in raw_members.items()]
    library_raw = raw_members['0-trace.trace'].splitlines()
    runner_raw = raw_members['test.trace'].splitlines()
    library = [json.loads(line) for line in library_raw]
    runner = [json.loads(line) for line in runner_raw]
save('trace-members.json', member_manifest)

after = {event['callId']: (index, event) for index, event in enumerate(library)
         if event['type'] == 'after'}
runner_after = {event['callId']: (index, event) for index, event in enumerate(runner)
                if event['type'] == 'after'}
iterations = []
requests = []
for index, event in enumerate(library):
    if event['type'] != 'before':
        continue
    argument = decode(event.get('params', {}).get('arg'))
    if not isinstance(argument, dict) or not argument.get('kind', '').startswith('M02_'):
        continue
    response_pair = after.get(event['callId'])
    response = decode(response_pair[1].get('result')) if response_pair else None
    record = {'library_before_line': index+1, 'call_id': event['callId'],
              'start_ms': event['startTime'], 'page_id': event.get('pageId'),
              'kind': argument['kind'], 'request_id': argument['requestId'],
              'tab_id': argument['tabId'], 'has_after': response_pair is not None,
              'end_ms': response_pair[1]['endTime'] if response_pair else None,
              'library_after_line': response_pair[0]+1 if response_pair else None}
    if argument['kind'] == 'M02_W08_SCAN_TAB':
        assert response['kind'] == 'M02_W08_SCAN_RESULT'
        frame = next(frame for frame in response['frames']
                     if frame['frame_context']['is_top_frame'])
        record['descriptor_count'] = len(frame['descriptors'])
        iteration = {'iteration_index_1based': len(iterations)+1,
                     'native128_index_1based': sum(x['control_count']==128 for x in iterations)+1
                     if record['descriptor_count']==128 else None,
                     'control_count': record['descriptor_count'], 'scan': record,
                     'executes': [], 'reconcile': None}
        iterations.append(iteration)
    elif argument['kind'] == 'M02_W11_EXECUTE_TAB':
        items = argument['items']
        record['item_count'] = len(items)
        record['sections'] = [item['address']['section_path'] for item in items]
        record['transaction_ids'] = [item['transaction_id'] for item in items]
        record['settle_budgets_ms'] = sorted(set(item['settle']['budget_ms'] for item in items))
        if response:
            assert response['kind'] == 'M02_W11_EXECUTE_RESULT'
            outcome = response['outcome']
            record['outcome_status'] = outcome['status']
            record['returned_item_count'] = len(outcome['items'])
            record['executed_verified_count'] = sum(
                item['status']=='EXECUTED' and item['result']['outcome']=='VERIFIED'
                for item in outcome['items'])
            record['actions_executed'] = outcome['snapshot']['actions_executed']
        iterations[-1]['executes'].append(record)
    elif argument['kind'] == 'M02_W11_RECONCILE_TAB':
        assert response['kind'] == 'M02_W11_RECONCILE_RESULT'
        outcome = response['outcome']
        record['outcome_status'] = outcome['status']
        record['actions_executed'] = outcome['snapshot']['actions_executed']
        record['inventory_counts'] = outcome['inventory']['counts']
        iterations[-1]['reconcile'] = record
    requests.append(record)
save('iterations.json', iterations)
save('requests.json', requests)

report = json.loads((PROOF/'results.json').read_text())
all_specs = [spec for suite in report['suites'] for spec in specs(suite)]
assert len(all_specs) == 1
test = all_specs[0]['tests'][0]
assert len(test['results']) == 1
result = test['results'][0]
completion = json.loads((PROOF/'completion.json').read_text())
command = json.loads((PROOF/'command.json').read_text())
scaling_lines = [line for line in (PROOF/'run.log').read_bytes().splitlines()
                 if b'W13_SCALING ' in line]
target_lines = [line for line in (PROOF/'run.log').read_bytes().splitlines()
                if b'W13_TARGET_P95 ' in line]
unresolved = [record for record in requests if not record['has_after']]
assert len(unresolved) == 1
last_request = unresolved[0]
runner_before_index, runner_before = next((index, event) for index, event in enumerate(runner)
    if event['type']=='before' and event.get('stepId')=='pw:api@5697')
runner_end_index, runner_end = runner_after[runner_before['callId']]
timeout_index, timeout = next((index, event) for index, event in enumerate(runner)
    if event['type']=='error' and 'Test timeout of 120000ms exceeded.' in event['message'])
after_hook_index, after_hook = next((index, event) for index, event in enumerate(runner)
    if index>timeout_index and event['type']=='before' and event.get('title')=='After Hooks')
close_index, close = next((index, event) for index, event in enumerate(runner)
    if index>timeout_index and event['type']=='before' and event.get('title')=='Close context')
completed = [item for item in iterations if item['reconcile']]
completed_native = [item for item in completed if item['control_count']==128]
last_native = completed_native[-1]
last_execute = last_native['executes'][-1]
last_scan = iterations[-1]['scan']
benchmark = (ROOT/'clone/e2e/extension/extension-benchmark.spec.ts').read_bytes()
harness = (ROOT/'clone/e2e/extension/support/research-harness.ts').read_bytes()
archived_source_matches = {str(path.relative_to(ROOT/'clone')): [name for name,data in raw_members.items()
    if name.startswith('resources/src@') and data==content]
    for path,content in [(ROOT/'clone/e2e/extension/extension-benchmark.spec.ts',benchmark),
                         (ROOT/'clone/e2e/extension/support/research-harness.ts',harness)]}
checks = {
    'single_failed_test_without_retry': test['status']=='unexpected' and result['status']=='timedOut'
        and result.get('retry')==0 and report['stats']['unexpected']==1,
    'timeout_is_120000': test['timeout']==120000 and runner[0]['testTimeout']==120000,
    'child_exit_1': completion['exit_code']==1,
    'target_requested_20_unchanged_single_test': command['environment']['JAPP_W13_PERFORMANCE_SAMPLES']=='20'
        and '--grep' in command['argv'] and '--repeat-each' not in command['argv'],
    'canonical_scaling_and_target_p95_unemitted': not scaling_lines and not target_lines,
    'iteration_sequence_supported': [item['control_count'] for item in iterations]==[8,32]+[128]*19,
    'eighteen_native128_completed': len(completed_native)==18 and len(completed)==20,
    'all_returned_execute_items_verified': all(record.get('executed_verified_count')==record['item_count']
        for record in requests if record['kind']=='M02_W11_EXECUTE_TAB' and record['has_after']),
    'only_unresolved_first_batch_of_native19': last_request['request_id']=='execute-136'
        and last_request['sections']==[[f'SECTION_{index}'] for index in range(32)]
        and len(iterations[-1]['executes'])==1 and iterations[-1]['reconcile'] is None,
    'last_reconciled_native_actions_and_physical_count_128': last_native['reconcile']['actions_executed']==128
        and last_native['reconcile']['inventory_counts']['verified_filled']==128
        and decode(after['call@989'][1]['result'])=='128',
    'timeout_precedes_close_and_evaluate_closed_error': timeout_index<close_index<runner_end_index
        and 'Target page, context or browser has been closed' in runner_end['error']['message'],
    'benchmark_and_harness_match_trace_archived_source': all(archived_source_matches.values()),
}
summary = {
    'scope': 'Independent read-only retained trace review; documentary reconstruction only. No actors, '
             'repository imports, performance score, retry, remedy, or Gate authority.',
    'source_commit': '2464519e0b04de123ef51c3d9cb0363456b5b0eb',
    'source_tree': '75660b6a105a2873b0020d3a2d4c24dfb75e15e5',
    'ordinary_status': result['status'], 'child_exit_code': completion['exit_code'],
    'test_timeout_ms': test['timeout'], 'canonical_W13_SCALING_lines': len(scaling_lines),
    'canonical_rows_emitted': 0, 'p95_ms': None,
    'iteration_counts': {'scanned':len(iterations), 'native128_scanned':19,
                         'native128_reconciled':18, 'native128_not_started':1},
    'last_completed_execute': last_execute,
    'last_completed_reconcile': last_native['reconcile'],
    'last_completed_request': last_scan, 'unresolved_request': last_request,
    'runner_timing': {'evaluate_start_ms':runner_before['startTime'],
        'timeout_error_line':timeout_index+1, 'timeout_error_has_timestamp':False,
        'after_hooks_start_ms':after_hook['startTime'],
        'evaluate_start_to_after_hooks_ms':round(after_hook['startTime']-runner_before['startTime'],3),
        'close_context_start_ms':close['startTime'], 'evaluate_closed_error_end_ms':runner_end['endTime'],
        'evaluate_start_to_closed_error_ms':round(runner_end['endTime']-runner_before['startTime'],3)},
    'library_execute_to_after_hooks_ms':round(after_hook['startTime']-last_request['start_ms'],3),
    'archived_source_matches':archived_source_matches,
    'checks':checks, 'checks_passed':sum(checks.values()), 'checks_total':len(checks),
    'limits': ['The timeout event has no timestamp; After Hooks bounds its position in the runner trace.',
        'The pending library call has no after event, response, or completed batch result.',
        'The last execute was only begun immediately before the overall deadline; a 120-second single-RPC stall is unsupported.',
        'No exact last physical control within the pending batch is established by an RPC result.',
        'Completed trace iterations are not emitted canonical W13_SCALING rows and do not supply target20 p95.',
        'No runtime, UA, focus, Chrome, scheduling, or contention cause is inferred.']}
save('findings.json', summary)
critical_library_ids = {'call@983','call@985','call@989','call@1025','call@1027'}
critical = []
for index,event in enumerate(library):
    if event.get('callId') in critical_library_ids and event['type'] in ('before','after'):
        critical.append({'member':'0-trace.trace','line':index+1,
                         'raw_line_sha256':sha(library_raw[index]),'event':event})
for index in [runner_before_index,timeout_index,after_hook_index,close_index,runner_end_index]:
    critical.append({'member':'test.trace','line':index+1,
                     'raw_line_sha256':sha(runner_raw[index]),'event':runner[index]})
save('critical-events.json',critical)
print(json.dumps({'checks_passed':sum(checks.values()),'checks_total':len(checks),
                  'ordinary_status':result['status'],'canonical_rows':0,'p95_ms':None,
                  'native128_completed':len(completed_native),'native128_pending_index':19,
                  'unresolved_request':last_request['request_id']}))
assert all(checks.values()), checks
