#!/usr/bin/env python3
"""Read retained Playwright JSON/ZIP only. Does not execute repository code."""
from pathlib import Path
import collections
import hashlib
import json
import re
import zipfile

ROOT = Path('/tmp/japp-m02-w15-native128-canonical-final-20261017')
OUT = Path(__file__).resolve().parent
PROOF = ROOT / 'proof'
TRACE = next((PROOF / 'native-test-results').rglob('trace.zip'))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def decode(value):
    # Playwright SerializedValue, preserving unsupported references rather than
    # guessing values. The requests/results inspected below contain no refs.
    if not isinstance(value, dict):
        return value
    if 'value' in value:
        return decode(value['value'])
    for key in ('s', 'n', 'b'):
        if key in value:
            return value[key]
    if 'v' in value:
        return value['v']
    if 'a' in value:
        return [decode(item) for item in value['a']]
    if 'o' in value:
        return {item['k']: decode(item['v']) for item in value['o']}
    return value

def specs(suite):
    yield from suite.get('specs', [])
    for child in suite.get('suites', []):
        yield from specs(child)

inputs = [TRACE, PROOF/'results.json', PROOF/'run.log', PROOF/'completion.json',
          PROOF/'command.json', ROOT/'source-freeze.json',
          ROOT/'canonical-target-wrapper.py',
          ROOT/'clone/e2e/extension/extension-benchmark.spec.ts',
          ROOT/'clone/e2e/extension/support/research-harness.ts']
input_manifest = []
for path in inputs:
    data = path.read_bytes()
    input_manifest.append({'path': str(path), 'bytes': len(data), 'sha256': sha(data)})
save('inputs.json', input_manifest)
with zipfile.ZipFile(TRACE) as archive:
    raw_members = {name: archive.read(name) for name in archive.namelist()
                   if name.endswith(('.trace', '.stacks')) or name.startswith('resources/src@')}
    member_manifest = [{'member': name, 'bytes': len(data), 'sha256': sha(data)}
                       for name, data in raw_members.items()]
    library_raw = raw_members['0-trace.trace'].splitlines()
    runner_raw = raw_members['test.trace'].splitlines()
    library = [json.loads(line) for line in library_raw]
    runner = [json.loads(line) for line in runner_raw]
save('trace-members.json', member_manifest)

after = {event['callId']: (index, event) for index, event in enumerate(library)
         if event['type'] == 'after'}
runner_after = {event['callId']: (index, event) for index, event in enumerate(runner)
                if event['type'] == 'after'}
iterations = []
requests = []
for index, event in enumerate(library):
    if event['type'] != 'before':
        continue
    argument = decode(event.get('params', {}).get('arg'))
    if not isinstance(argument, dict) or not argument.get('kind', '').startswith('M02_'):
        continue
    response_pair = after.get(event['callId'])
    response = decode(response_pair[1].get('result')) if response_pair else None
    record = {'library_before_line': index+1, 'call_id': event['callId'],
              'start_ms': event['startTime'], 'page_id': event.get('pageId'),
              'kind': argument['kind'], 'request_id': argument['requestId'],
              'tab_id': argument['tabId'], 'has_after': response_pair is not None,
              'end_ms': response_pair[1]['endTime'] if response_pair else None,
              'library_after_line': response_pair[0]+1 if response_pair else None}
    if argument['kind'] == 'M02_W08_SCAN_TAB':
        assert response['kind'] == 'M02_W08_SCAN_RESULT'
        frame = next(frame for frame in response['frames']
                     if frame['frame_context']['is_top_frame'])
        record['descriptor_count'] = len(frame['descriptors'])
        iteration = {'iteration_index_1based': len(iterations)+1,
                     'native128_index_1based': sum(x['control_count']==128 for x in iterations)+1
                     if record['descriptor_count']==128 else None,
                     'control_count': record['descriptor_count'], 'scan': record,
                     'executes': [], 'reconcile': None}
        iterations.append(iteration)
    elif argument['kind'] == 'M02_W11_EXECUTE_TAB':
        items = argument['items']
        record['item_count'] = len(items)
        record['sections'] = [item['address']['section_path'] for item in items]
        record['transaction_ids'] = [item['transaction_id'] for item in items]
        record['settle_budgets_ms'] = sorted(set(item['settle']['budget_ms'] for item in items))
        if response:
            assert response['kind'] == 'M02_W11_EXECUTE_RESULT'
            outcome = response['outcome']
            record['outcome_status'] = outcome['status']
            record['returned_item_count'] = len(outcome['items'])
            record['executed_verified_count'] = sum(
                item['status']=='EXECUTED' and item['result']['outcome']=='VERIFIED'
                for item in outcome['items'])
            record['actions_executed'] = outcome['snapshot']['actions_executed']
        iterations[-1]['executes'].append(record)
    elif argument['kind'] == 'M02_W11_RECONCILE_TAB':
        assert response['kind'] == 'M02_W11_RECONCILE_RESULT'
        outcome = response['outcome']
        record['outcome_status'] = outcome['status']
        record['actions_executed'] = outcome['snapshot']['actions_executed']
        record['inventory_counts'] = outcome['inventory']['counts']
        iterations[-1]['reconcile'] = record
    requests.append(record)
save('iterations.json', iterations)
save('requests.json', requests)

report = json.loads((PROOF/'results.json').read_text())
all_specs = [spec for suite in report['suites'] for spec in specs(suite)]
assert len(all_specs) == 1
test = all_specs[0]['tests'][0]
assert len(test['results']) == 1
result = test['results'][0]
completion = json.loads((PROOF/'completion.json').read_text())
command = json.loads((PROOF/'command.json').read_text())
scaling_lines = [line for line in (PROOF/'run.log').read_bytes().splitlines()
                 if b'W13_SCALING ' in line]
target_lines = [line for line in (PROOF/'run.log').read_bytes().splitlines()
                if b'W13_TARGET_P95 ' in line]
unresolved = [record for record in requests if not record['has_after']]
assert len(unresolved) == 1
last_request = unresolved[0]
runner_before_index, runner_before = next((index, event) for index, event in enumerate(runner)
    if event['type']=='before' and event.get('stepId')=='pw:api@5697')
runner_end_index, runner_end = runner_after[runner_before['callId']]
timeout_index, timeout = next((index, event) for index, event in enumerate(runner)
    if event['type']=='error' and 'Test timeout of 120000ms exceeded.' in event['message'])
after_hook_index, after_hook = next((index, event) for index, event in enumerate(runner)
    if index>timeout_index and event['type']=='before' and event.get('title')=='After Hooks')
close_index, close = next((index, event) for index, event in enumerate(runner)
    if index>timeout_index and event['type']=='before' and event.get('title')=='Close context')
completed = [item for item in iterations if item['reconcile']]
completed_native = [item for item in completed if item['control_count']==128]
last_native = completed_native[-1]
last_execute = last_native['executes'][-1]
last_scan = iterations[-1]['scan']
benchmark = (ROOT/'clone/e2e/extension/extension-benchmark.spec.ts').read_bytes()
harness = (ROOT/'clone/e2e/extension/support/research-harness.ts').read_bytes()
archived_source_matches = {str(path.relative_to(ROOT/'clone')): [name for name,data in raw_members.items()
    if name.startswith('resources/src@') and data==content]
    for path,content in [(ROOT/'clone/e2e/extension/extension-benchmark.spec.ts',benchmark),
                         (ROOT/'clone/e2e/extension/support/research-harness.ts',harness)]}
checks = {
    'single_failed_test_without_retry': test['status']=='unexpected' and result['status']=='timedOut'
        and result.get('retry')==0 and report['stats']['unexpected']==1,
    'timeout_is_120000': test['timeout']==120000 and runner[0]['testTimeout']==120000,
    'child_exit_1': completion['exit_code']==1,
    'target_requested_20_unchanged_single_test': command['environment']['JAPP_W13_PERFORMANCE_SAMPLES']=='20'
        and '--grep' in command['argv'] and '--repeat-each' not in command['argv'],
    'canonical_scaling_and_target_p95_unemitted': not scaling_lines and not target_lines,
    'iteration_sequence_supported': [item['control_count'] for item in iterations]==[8,32]+[128]*19,
    'eighteen_native128_completed': len(completed_native)==18 and len(completed)==20,
    'all_returned_execute_items_verified': all(record.get('executed_verified_count')==record['item_count']
        for record in requests if record['kind']=='M02_W11_EXECUTE_TAB' and record['has_after']),
    'only_unresolved_first_batch_of_native19': last_request['request_id']=='execute-136'
        and last_request['sections']==[[f'SECTION_{index}'] for index in range(32)]
        and len(iterations[-1]['executes'])==1 and iterations[-1]['reconcile'] is None,
    'last_reconciled_native_actions_and_physical_count_128': last_native['reconcile']['actions_executed']==128
        and last_native['reconcile']['inventory_counts']['verified_filled']==128
        and decode(after['call@989'][1]['result'])=='128',
    'timeout_precedes_close_and_evaluate_closed_error': timeout_index<close_index<runner_end_index
        and 'Target page, context or browser has been closed' in runner_end['error']['message'],
    'benchmark_and_harness_match_trace_archived_source': all(archived_source_matches.values()),
}
summary = {
    'scope': 'Independent read-only retained trace review; documentary reconstruction only. No actors, '
             'repository imports, performance score, retry, remedy, or Gate authority.',
    'source_commit': '2464519e0b04de123ef51c3d9cb0363456b5b0eb',
    'source_tree': '75660b6a105a2873b0020d3a2d4c24dfb75e15e5',
    'ordinary_status': result['status'], 'child_exit_code': completion['exit_code'],
    'test_timeout_ms': test['timeout'], 'canonical_W13_SCALING_lines': len(scaling_lines),
    'canonical_rows_emitted': 0, 'p95_ms': None,
    'iteration_counts': {'scanned':len(iterations), 'native128_scanned':19,
                         'native128_reconciled':18, 'native128_not_started':1},
    'last_completed_execute': last_execute,
    'last_completed_reconcile': last_native['reconcile'],
    'last_completed_request': last_scan, 'unresolved_request': last_request,
    'runner_timing': {'evaluate_start_ms':runner_before['startTime'],
        'timeout_error_line':timeout_index+1, 'timeout_error_has_timestamp':False,
        'after_hooks_start_ms':after_hook['startTime'],
        'evaluate_start_to_after_hooks_ms':round(after_hook['startTime']-runner_before['startTime'],3),
        'close_context_start_ms':close['startTime'], 'evaluate_closed_error_end_ms':runner_end['endTime'],
        'evaluate_start_to_closed_error_ms':round(runner_end['endTime']-runner_before['startTime'],3)},
    'library_execute_to_after_hooks_ms':round(after_hook['startTime']-last_request['start_ms'],3),
    'archived_source_matches':archived_source_matches,
    'checks':checks, 'checks_passed':sum(checks.values()), 'checks_total':len(checks),
    'limits': ['The timeout event has no timestamp; After Hooks bounds its position in the runner trace.',
        'The pending library call has no after event, response, or completed batch result.',
        'The last execute was only begun immediately before the overall deadline; a 120-second single-RPC stall is unsupported.',
        'No exact last physical control within the pending batch is established by an RPC result.',
        'Completed trace iterations are not emitted canonical W13_SCALING rows and do not supply target20 p95.',
        'No runtime, UA, focus, Chrome, scheduling, or contention cause is inferred.']}
save('findings.json', summary)
critical_library_ids = {'call@983','call@985','call@989','call@1025','call@1027'}
critical = []
for index,event in enumerate(library):
    if event.get('callId') in critical_library_ids and event['type'] in ('before','after'):
        critical.append({'member':'0-trace.trace','line':index+1,
                         'raw_line_sha256':sha(library_raw[index]),'event':event})
for index in [runner_before_index,timeout_index,after_hook_index,close_index,runner_end_index]:
    critical.append({'member':'test.trace','line':index+1,
                     'raw_line_sha256':sha(runner_raw[index]),'event':runner[index]})
save('critical-events.json',critical)

# Trace-only brackets around the source's performance.now() interval. The
# benchmark does not expose those two values until W13_SCALING is emitted.
# Never substitute these brackets, RPC spans, or partial iterations for it.
runner_before_by_step = {event['stepId']:(index,event) for index,event in enumerate(runner)
                        if event['type']=='before' and 'stepId' in event}
library_before_by_id = {event['callId']:event for event in library if event['type']=='before'}
metric_events = [(index,event) for index,event in enumerate(runner)
    if event['type']=='before' and event.get('title')=='Send CDP command'
    and event['params']['method']=='Performance.getMetrics']
metric_join_evidence = []
timing_iterations = []
rpc_spans = []
for item in iterations:
    scan_event = library_before_by_id[item['scan']['call_id']]
    scan_index,scan_runner = runner_before_by_step[scan_event['stepId']]
    bm_index,bm = next((index,event) for index,event in reversed(metric_events) if index<scan_index)
    bm_after_index,bm_after = runner_after[bm['callId']]
    setup_index,setup = next((index,event) for index,event in reversed(list(enumerate(runner[:bm_index])))
        if event['type']=='before' and event.get('title')=='Create page'
        and any(frame.get('function')=='openHarness' and frame.get('line')==120
                for frame in event.get('stack',[])))
    timing = {'iteration_index_1based':item['iteration_index_1based'],
        'native128_index_1based':item['native128_index_1based'], 'control_count':item['control_count'],
        'setup_begin':{'line':setup_index+1,'call_id':setup['callId'],'ms':setup['startTime']},
        'before_metrics':{'before_line':bm_index+1,'after_line':bm_after_index+1,
                          'call_id':bm['callId'],'start_ms':bm['startTime'],'end_ms':bm_after['endTime']},
        'source_timed_start_bracket_ms':[bm_after['endTime'],scan_runner['startTime']],
        'setup_span_to_before_metrics_end_ms':round(bm_after['endTime']-setup['startTime'],3)}
    evidence_indices=[setup_index,bm_index,bm_after_index,scan_index]
    if item['reconcile']:
        reconcile_event=library_before_by_id[item['reconcile']['call_id']]
        rec_index,rec_runner=runner_before_by_step[reconcile_event['stepId']]
        am_index,am=next((index,event) for index,event in metric_events if index>rec_index)
        am_after_index,am_after=runner_after[am['callId']]
        final_assert_index,final_assert=next((index,event) for index,event in reversed(list(enumerate(runner[:am_index])))
            if event['type']=='before' and event.get('method')=='expect'
            and any(frame.get('function')=='reconciled' and frame.get('line')==331
                    for frame in event.get('stack',[])))
        final_assert_after_index,final_assert_after=runner_after[final_assert['callId']]
        controller_close_index,controller_close=next((index,event) for index,event in enumerate(runner[am_index:],am_index)
            if event['type']=='before'
            and any(frame.get('line')==183 and frame['file'].endswith('extension-benchmark.spec.ts')
                    for frame in event.get('stack',[])))
        controller_close_after_index,controller_close_after=runner_after[controller_close['callId']]
        page_close_index,page_close=next((index,event) for index,event in enumerate(runner[am_index:],am_index)
            if event['type']=='before'
            and any(frame.get('line')==182 and frame['file'].endswith('extension-benchmark.spec.ts')
                    for frame in event.get('stack',[])))
        page_close_after_index,page_close_after=runner_after[page_close['callId']]
        timing.update({'after_metrics':{'before_line':am_index+1,'after_line':am_after_index+1,
                                       'call_id':am['callId'],'start_ms':am['startTime'],'end_ms':am_after['endTime']},
            'source_timed_end_bracket_ms':[final_assert_after['endTime'],am['startTime']],
            'source_timed_interval_duration_bracket_ms':[
                round(final_assert_after['endTime']-scan_runner['startTime'],3),
                round(am['startTime']-bm_after['endTime'],3)],
            'post_timed_span_after_metrics_start_to_controller_close_end_ms':
                round(controller_close_after['endTime']-am['startTime'],3),
            'page_close_span_ms':round(page_close_after['endTime']-page_close['startTime'],3),
            'controller_close_span_ms':round(controller_close_after['endTime']-controller_close['startTime'],3),
            'controller_close_end_ms':controller_close_after['endTime']})
        evidence_indices += [rec_index,am_index,am_after_index,final_assert_index,final_assert_after_index,
                             page_close_index,page_close_after_index,controller_close_index,controller_close_after_index]
    else:
        timing['partial_start_to_after_hooks_bracket_ms']=[
            round(after_hook['startTime']-scan_runner['startTime'],3),
            round(after_hook['startTime']-bm_after['endTime'],3)]
        timing['has_after_metrics']=False
    timing_iterations.append(timing)
    for index in evidence_indices:
        metric_join_evidence.append({'member':'test.trace','line':index+1,
                                    'raw_line_sha256':sha(runner_raw[index]),'event':runner[index]})
    for record in [item['scan'],*item['executes'],*([item['reconcile']] if item['reconcile'] else [])]:
        event=library_before_by_id[record['call_id']]
        ri,rb=runner_before_by_step[event['stepId']]
        ra=runner_after.get(rb['callId'])
        rpc_spans.append({'kind':record['kind'],'request_id':record['request_id'],
            'iteration_index_1based':item['iteration_index_1based'],
            'native128_index_1based':item['native128_index_1based'],
            'library_before_line':record['library_before_line'], 'library_after_line':record['library_after_line'],
            'runner_before_line':ri+1, 'runner_after_line':ra[0]+1 if ra else None,
            'library_completed_duration_ms':round(record['end_ms']-record['start_ms'],3)
            if record['has_after'] else None,
            'runner_duration_ms':round(ra[1]['endTime']-rb['startTime'],3) if ra else None,
            'runner_error':ra[1].get('error',{}).get('message') if ra else None})
first_hook=next(event for event in runner if event['type']=='before' and event.get('title')=='Before Hooks')
timing_summary={'scope':'Trace wall-time brackets only. No canonical elapsed rows or p95. '
    'RPC durations include serialization, IPC, browser/extension waiting and trace/API overhead; '
    'they do not isolate driver CPU or helper assertions after the evaluate promise resolves.',
    'CDP_metric_boundary_calls':len(metric_events),
    'CDP_metric_values_present_in_runner_after_events':any('result' in runner_after[event['callId']][1]
                                                        for _,event in metric_events),
    'before_hooks_start_ms':first_hook['startTime'], 'after_hooks_start_ms':after_hook['startTime'],
    'whole_before_hooks_to_after_hooks_ms':round(after_hook['startTime']-first_hook['startTime'],3),
    'initial_fixture_and_pre_iteration_span_ms':round(timing_iterations[0]['setup_begin']['ms']-first_hook['startTime'],3),
    'all_21_iteration_setup_span_sum_ms':round(sum(t['setup_span_to_before_metrics_end_ms'] for t in timing_iterations),3),
    'all_20_completed_timed_interval_bracket_sum_ms':[
        round(sum(t['source_timed_interval_duration_bracket_ms'][bound]
                  for t in timing_iterations if 'source_timed_interval_duration_bracket_ms' in t),3)
        for bound in [0,1]],
    'completed_native128_timed_interval_bracket_sum_ms':[
        round(sum(t['source_timed_interval_duration_bracket_ms'][bound]
                  for t in timing_iterations if t['control_count']==128 and 'source_timed_interval_duration_bracket_ms' in t),3)
        for bound in [0,1]],
    'post_timed_span_sum_ms':round(sum(t.get('post_timed_span_after_metrics_start_to_controller_close_end_ms',0)
                                     for t in timing_iterations),3),
    'page_close_span_sum_ms':round(sum(t.get('page_close_span_ms',0) for t in timing_iterations),3),
    'controller_close_span_sum_ms':round(sum(t.get('controller_close_span_ms',0) for t in timing_iterations),3),
    'completed_rpc_duration_sums_ms':{kind:round(sum(r['library_completed_duration_ms'] or 0
        for r in rpc_spans if r['kind']==kind),3) for kind in sorted(set(r['kind'] for r in rpc_spans))},
    'completed_rpc_counts':dict(collections.Counter(r['kind'] for r in rpc_spans
                                                   if r['library_completed_duration_ms'] is not None)),
    'iterations':timing_iterations}
save('metric-boundary-joins.json',metric_join_evidence)
save('rpc-spans.json',rpc_spans)
save('timing-brackets.json',timing_summary)
print(json.dumps({'checks_passed':sum(checks.values()),'checks_total':len(checks),
                  'ordinary_status':result['status'],'canonical_rows':0,'p95_ms':None,
                  'native128_completed':len(completed_native),'native128_pending_index':19,
                  'unresolved_request':last_request['request_id']}))
assert all(checks.values()), checks
