from pathlib import Path
import hashlib,json,shutil,tarfile
A=Path('/tmp/japp-m03-w06-mac-headless-data-independent-review-20261019')
O=Path('/tmp/japp-m03-w06-mac-headless-owned-root-execution-v5-20261019')
W=Path('/tmp/japp-m03-w06-macos-headless-package-execution-v5-20261019')
P=Path('/tmp/japp-m03-w06-mac-headless-data-independent-review-20261019-retained')
P.mkdir();B=P/'members';B.mkdir()
sha=lambda p: hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
selected=[]
def retain(source,relative):
    source=Path(source);destination=B/relative
    if source.is_symlink() or not source.is_file(): raise ValueError('Only regular selected files')
    before={'bytes':source.stat().st_size,'sha256':sha(source),'mode':source.stat().st_mode&0o777}
    destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,destination)
    after={'bytes':source.stat().st_size,'sha256':sha(source),'mode':source.stat().st_mode&0o777}
    assert before==after and sha(destination)==before['sha256']
    selected.append({'path':str(relative),'original_path':str(source),'bytes':before['bytes'],'sha256':before['sha256'],'mode':before['mode']})
for folder,name in [(O,'outer'),(W,'execution')]:
    for source in sorted(folder.iterdir()):
        if source.is_file() and source.name!='git-source-archive.stdout': retain(source,Path(name)/source.name)
for source in sorted((W/'observation').iterdir()):
    if source.is_file(): retain(source,Path('execution/observation')/source.name)
retain(Path(str(W)+'-context/pins.json'),Path('context/pins.json'))
c=json.loads(Path(str(W)+'-context/pins.json').read_bytes())
for name in ['actor','runner','probe_core','probe_mac','source_before','baseline_log','app_record','runtime_record']:
    source=Path(c['bindings'][name]['path']);retain(source,Path('bound-inputs')/name/source.name)
for name in ['make_pins.py','test_guard_counterexamples.py','SOURCE_CHECKS.json','HANDOFF.md']:
    source=Path(c['bindings']['runner']['path']).parent/name;retain(source,Path('reviewed-harness')/name)
d=json.loads((W/'source-derivative.json').read_bytes());z=json.loads((W/'source-after.json').read_bytes())
for name in [*d['changed'],*z['generated_build_files']]: retain(W/'source'/name,Path('selected-derivative')/name)
R=Path('/tmp/japp-m03-w06-mac-headless-native-image-retained-20261019')
for source in sorted(R.iterdir()):
    if source.is_file(): retain(source,Path('native-image-copy')/source.name)
L=Path('/tmp/japp-m03-w06-windows-manifest-local-rust-20261019')
for source in sorted(L.iterdir()):
    if source.is_file(): retain(source,Path('separate-local-rust-observer')/source.name)
reanchor=Path('/tmp/japp-m03-w06-macos-headless-package-input-plan-v5-20261019/SOURCE_REANCHOR.json')
retain(reanchor,Path('reanchor/SOURCE_REANCHOR.json'))
for name in ['audit.py','findings.json']: retain(A/name,Path('independent-review')/name)
archive=W/'git-source-archive.stdout'
helper=json.loads((W/'helper-image-before.json').read_bytes())
copy=json.loads((R/'copy.result.json').read_bytes())
omitted={
 'source_archive':{'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'physical_body_present':True,'independently_rehashed':True,'omitted_from_compact_archive':True},
 'immutable_original_source':{'head':c['expected_head'],'tree':c['expected_tree'],'files':1951,'recorded_file_map':'context/pins.json:source_files','reconstructable_from_external_source_archive':True,'fresh_full_body_rehash':False},
 'owned_derivative':{'path':str(W/'source'),'recorded_files':1952,'map':'execution/source-derivative.json:files','exact_two_changed_bodies':'selected-derivative/','generated_four_schema_bodies':'selected-derivative/','fresh_full_body_rehash':False},
 'native_helper':{'original':helper,'durable_COW':copy['retained'],'physical_body_present':True,'separately_retained_not_in_compact_archive':True,'clonefile_request_exit':copy['exit']},
 'signed_app':{'path':c['app_bundle'],'file_count':43,'recorded_file_map':'context/pins.json:app_files','before_after_maps_equal':True,'fresh_physical_rehash_by_reviewer':False},
 'runtime':{'path':str(Path(c['app_bundle'])/'Contents/Resources/runtime'),'file_count':40,'manifest_sha256':'c9049a3f63572c0de9b114700e9326bebc0518166840133cce9548565c58de1d','recorded_file_map':'context/pins.json:runtime_files','before_after_maps_equal':True,'fresh_physical_rehash_by_reviewer':False},
 'target_and_caches':{'scope':'All unselected compiled intermediates and cache bodies intentionally omitted; no whole-cache/compiler-installation closure claim'}
}
(A/'OMITTED_LARGE_BODIES.json').write_text(json.dumps(omitted,indent=2)+'\n')
report='''# Independent actual-data audit: Mac headless packaged service

DATA_CLEAR: 47/47 finite data checks. Root's actual outer command exited0 in60.759399s; the compiled selected case exited0 in3.401330s, with1passed,0failed,0ignored and232filtered/uninvoked. Catalog233 is exactly the historical232-case cohort plus this one case. The earlier whole verification failed Python/integrity; its Rust232 each3 cohort is used only as the catalog preimage, and that aggregate FAIL is preserved.

The probe compiles an immutable e0a501b/bbf94e projection (1951files) into a cfg(test)-only1952-file derivative: one append to service/mod.rs and one new reviewed actor. Four permitted generated schema files are recorded separately. This is not a current whole-tree label. The original canonical boundary is clean5b6def96/6c6f1437/1956, with exact before/after head/tree/status/byte-hash maps. Its runtime40 before/after map is exact and equals the signed app runtime40. The execution's app43/runtime40 input maps equal their expected pins and each other before/after. Physical selected module/actor/four schema/source-receipt bodies and the actual47,750,384B compiler-produced helper image were independently rehashed. The review did not reread every app/runtime/toolchain/cache/source body and does not claim that it did.

Compiler-artifact JSON identifies one actual lib-test executable; its physical SHAa4842a237eb89eef3043620d2a0c21f2a0d691b2b6b1749d65081054a417a986 matches the before pin and a new separate durable COW copy. The selected command uses that exact image, --exact named case and --test-threads=1. Physical cargo/rustc selection is explicit in receipts and child RUSTC; complete installed-toolchain/SDK/cache closure is not implied.

The raw case output confirms authenticated health/ready/version, same-owner private-session Engine READY, exact post-shutdown UNAVAILABLE schema/payload, authority withdrawal and listener reuse. The observer joins one actual signed app runtime executable directly beneath the owned helper. It records the service PID/group and listener absent after shutdown, without emergency service signals. Actor stderr records205ms same-owner cleanup against its6000ms policy wait ceiling. No token appears in launch/pin interfaces.

Worker `owned_worker_group_term:true` is preserved. It records the finisher's deliberate own-group TERM after installing its own SIG_IGN, not a service emergency termination. The separate outer fence later observes only the same live worker leader88835, sends no TERM/KILL, releases it and reaps it with group gone. Both facts are compatible. No unregistered/outside-group descendant absence claim is added.

The separate later local Rust correction command also passed0/32.382793s with232 each3, all15 registered commands and owned group gone. Its original outer wrapper returned1 because an inherited footer demanded six commands although this invocation executed one. The original wrapper/closure and derived count reconciliation remain intact. This is COMMAND_PASS/OBSERVER_FOOTER_FAIL; it is not a Rust command FAIL, Windows validation or whole20 PASS.

The compact archive retains all finite command/environment/source maps, raw logs, selected derivative and reviewed harness source, actual actor/catalog/compiler records and independent review. It excludes the419,215,360B source tar, compiled target/cache bodies and image bytes. Exact omissions bind the still-physical source archive by independently recomputed SHA and the separately COW-retained helper by SHA/size/mode/path. No image is copied into Git or into the compact proof archive. The app/runtime original physical bodies remain their existing retained paths, bound by execution maps.

No actor, subject import, test, compiler, service, network, native store or canonical-root action was performed during this review. The only new utility invocation was bounded cp -c -p to retain the closed helper image. This evidence grants no GUI/LaunchServices/Wry, OS-store, installer/platform certification or milestone acceptance.
'''
(A/'REVIEW.md').write_text(report)
retain(A/'REVIEW.md',Path('independent-review/REVIEW.md'));retain(A/'OMITTED_LARGE_BODIES.json',Path('independent-review/OMITTED_LARGE_BODIES.json'));retain(A/'retain.py',Path('independent-review/retain.py'))
index={'scope':'All selected regular payload files; compact archive excludes this index only; outer manifest binds every member','files':selected}
(B/'selected-index.json').write_text(json.dumps(index,indent=2)+'\n')
archive_path=P/'proof.tar.gz'
with tarfile.open(archive_path,'w:gz') as tar:
    for source in sorted(B.rglob('*')):
        if source.is_file(): tar.add(source,arcname=source.relative_to(B).as_posix(),recursive=False)
seen=set();member_rows=[]
with tarfile.open(archive_path,'r:gz') as tar:
    for member in tar:
        path=Path(member.name)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts and member.name not in seen
        seen.add(member.name)
        data=tar.extractfile(member).read();original=B/member.name
        assert data==original.read_bytes()
        member_rows.append({'path':member.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mode':member.mode&0o777})
manifest={'archive':{'path':str(archive_path),'bytes':archive_path.stat().st_size,'sha256':sha(archive_path),'members':len(member_rows)},'selected_bytes':sum(x['bytes'] for x in member_rows),'safe_regular_members':member_rows,'external_large_bodies':omitted}
(P/'retention-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(P/'REPORT.md').write_text(report)
print(json.dumps({'archive':manifest['archive'],'selected_bytes':manifest['selected_bytes'],'report_sha256':sha(A/'REVIEW.md'),'findings_sha256':sha(A/'findings.json'),'retention_manifest_sha256':sha(P/'retention-manifest.json')},indent=2))
