"""Read closed retained data only; never imports subject modules or runs actors."""
from pathlib import Path
import hashlib
import json
import re

O = Path('/tmp/japp-m03-w06-mac-headless-owned-root-execution-v5-20261019')
W = Path('/tmp/japp-m03-w06-macos-headless-package-execution-v5-20261019')
C = Path(str(W) + '-context')
A = Path('/tmp/japp-m03-w06-mac-headless-data-independent-review-20261019')
checks = []
def load(path): return json.loads(path.read_bytes())
def sha(path):
    with path.open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()
def check(name, condition, detail=None):
    checks.append({'check': name, 'clear': bool(condition), 'detail': detail})

a, b = load(O/'before.json'), load(O/'after.json')
r, s = load(O/'runtime-before.json'), load(O/'runtime-after.json')
c = load(C/'pins.json')
x, y = load(W/'inputs-before.json'), load(W/'inputs-after.json')
p, d, z = load(W/'source-before.json'), load(W/'source-derivative.json'), load(W/'source-after.json')
outer = load(W/'outer.result.json'); worker = load(W/'worker.result.json')
root_result = load(O/'mac-headless-result.json')
check('Recorded canonical source before/after exact1956', a == b and len(a['files']) == 1956 and a['status'] == '' and a['head'] == '5b6def96f4b38ecbfd9c9add1cb22db7d0fe15e7' and a['tree'] == '6c6f1437a607cfae3e58a4a761446f9ba16a6ab9', 'Historical execution boundary; no claim about mutable root after completion; source map records bytes/hash, not independent full source-mode inventory')
check('Recorded canonical runtime40 exact before/after', r == s and len(r) == 40 and r['manifest.json']['sha256'] == 'c9049a3f63572c0de9b114700e9326bebc0518166840133cce9548565c58de1d')
check('Root wrapper exact single command CLOSED0', root_result['exit_code'] == 0 and root_result['owned_leader_reaped'] and root_result['owned_group_after'] == 'GONE' and root_result['cleanup'] == [] and not root_result['outer_timeout'] and load(O/'closure.json')['single_command_executed'])
check('Root raw empty log binding', sha(O/'mac-headless.log') == root_result['log_sha256'] and (O/'mac-headless.log').stat().st_size == root_result['log_bytes'] == 0)
check('Root executable recorded unchanged', root_result['executable_sha256_before'] == root_result['executable_sha256_after'] == c['bindings']['python']['sha256'])
check('Exact immutable e0a source projection recorded1951', p == c['source_files'] and len(p) == 1951 and (W/'git-source-pin.stdout').read_text().splitlines() == [c['expected_head'], c['expected_tree']])
check('Derivative exactly cfgtest module append plus new actor', set(d['changed']) == {'apps/desktop/src-tauri/src/service/mod.rs','apps/desktop/src-tauri/src/service/package_validation.rs'} and len(d['files']) == 1952 and all(d['files'].get(k) == v for k,v in p.items() if k not in d['changed']))
check('Derivative recorded closure exact; four allowed generated schemas', z['selected'] == d['files'] and len(z['generated_build_files']) == 4 and all(k.startswith('apps/desktop/src-tauri/gen/schemas/') and k.endswith('.json') for k in z['generated_build_files']))
selected_physical=[]
for name in [*d['changed'], *z['generated_build_files']]:
    path = W/'source'/name; expected = d['files'].get(name, z['generated_build_files'].get(name))
    row = {'bytes':path.stat().st_size, 'sha256':sha(path), 'mode':path.stat().st_mode&0o777}
    check('Physical selected derivative/schema '+name, row == expected)
    selected_physical.append({'path':str(path),**row})
mod = (W/'source/apps/desktop/src-tauri/src/service/mod.rs').read_bytes()
marker = b'\n#[cfg(test)]\nmod package_validation;\n'
check('Physical module preimage exact appended cfgtest marker', mod.endswith(marker) and hashlib.sha256(mod[:-len(marker)]).hexdigest() == p['apps/desktop/src-tauri/src/service/mod.rs']['sha256'])
check('Physical new actor exact reviewed pin', sha(W/'source/apps/desktop/src-tauri/src/service/package_validation.rs') == c['bindings']['actor']['sha256'])
check('All execution input maps recorded exact', x == y and x['app'] == c['app_files'] and len(x['app']) == 43 and x['runtime'] == c['runtime_files'] and len(x['runtime']) == 40)
normalized = {k:{**v,'mode':int(v['mode'],8)} for k,v in r.items()}
check('Signed package runtime40 equals canonical runtime40 record', x['runtime'] == normalized)
check('Actual child compiler selection explicit physical rustc', x['environment']['RUSTC'] == c['bindings']['rustc']['path'] and '/toolchains/1.97.1-aarch64-apple-darwin/bin/' in x['environment']['RUSTC'] and x['tools']['cargo'] == c['bindings']['cargo']['path'] and x['environment']['CARGO_NET_OFFLINE'] == 'true')
source_bindings=[]
for name in ['actor','runner','probe_core','probe_mac','source_before','baseline_log','app_record','runtime_record']:
    row=c['bindings'][name];path=Path(row['path']);actual={'bytes':path.stat().st_size,'sha256':sha(path),'mode':path.stat().st_mode&0o777}
    check('Physical selected source/receipt pin '+name, actual == {k:row[k] for k in actual})
    source_bindings.append({'name':name,'path':str(path),**actual})
labels=['git-source-pin','git-source-archive','cargo-version','rustc-version','compile','catalog','actor']
command_rows=[]
for label in labels:
    u=load(W/(label+'.upfront.json'));l=load(W/(label+'.launch.json'));v=load(W/(label+'.result.json'))
    check('Actual closed command '+label, v['exit'] == 0 and v['failure'] is None and v['owned_cleanup']['reaped'] and v['owned_cleanup']['exit'] == 0 and not v['owned_cleanup']['term'] and not v['owned_cleanup'].get('kill',False) and l['owned_popen_pid'] == l['identity']['pid'])
    command_rows.append({'label':label,'upfront':u,'launch':l,'result':v})
comp = load(W/'compile.upfront.json')
check('Exact offline locked no-run lib compilation argv', comp['argv'][1:] == ['test','--offline','--locked','--lib','--no-run','--message-format=json'] and comp['argv'][0] == c['bindings']['cargo']['path'])
artifacts=[]
for line in (W/'compile.stdout').read_text().splitlines():
    item=json.loads(line)
    if item.get('reason')=='compiler-artifact' and item.get('profile',{}).get('test') and item.get('executable'): artifacts.append(item)
helper=load(W/'helper-image-before.json');image=Path(helper['path'])
actual_helper={'bytes':image.stat().st_size,'sha256':sha(image),'mode':image.stat().st_mode&0o777}
check('One actual compiler test artifact matches physical helper', len(artifacts)==1 and Path(artifacts[0]['executable']).resolve()==image.resolve() and actual_helper == {k:helper[k] for k in actual_helper})
ids=[line[:-6] for line in (W/'catalog.stdout').read_text().splitlines() if line.endswith(': test')]
barrier=load(W/'catalog-barrier.json')
check('233 exact unique catalog =232 historical plus one selected', len(ids)==len(set(ids))==233 and ids == barrier['exact_ids'] and sorted(ids)==sorted(c['baseline_test_ids']+[c['case']]) and not barrier['old_cases_invoked'])
# Independently parse first closed232 block, without importing the preparer.
raw=Path(c['bindings']['baseline_log']['path']).read_text().splitlines();i=raw.index('running 232 tests');names=[]
for line in raw[i+1:]:
    m=re.fullmatch(r'test ([A-Za-z0-9_:]+) \.\.\. ok',line)
    if m: names.append(m.group(1))
    if line.startswith('test result:'): break
check('Historical232 catalog preimage joins original failed full Rust subset', names == c['baseline_test_ids'] and len(names)==len(set(names))==232 and '232 passed; 0 failed; 0 ignored;' in line and any('python' in t and 'FAIL' in t and 'dynamic pytest' in t for t in raw))
actor_u=load(W/'actor.upfront.json');actor_r=load(W/'actor.result.json')
check('One selected actual actor with serial exact args', actor_u['argv']==[str(image),'--exact',c['case'],'--test-threads=1','--nocapture'] and actor_r['exit']==0 and '1 passed; 0 failed; 0 ignored; 0 measured; 232 filtered out;' in (W/'actor.stdout').read_text())
stderr=(W/'actor.stderr').read_text()
check('Positive health/ready/version and same-owner Engine closure raw markers', 'PACKAGE_SERVICE_ACTOR_PASS actual_native_actors=1 health=1 ready=1 version=1 engine_ready=1 engine_after_cleanup_unavailable=1 shutdown=1 authority_withdrawn=1 listener_released=1 gui_claim=0' in stderr and 'PACKAGE_OWNED_CLEANUP success=true elapsed_ms=205 policy_wait_bound_ms=6000' in stderr)
registration=load(W/'registered-service.json');package_pins=load(W/'package-pins.json')
check('Observed registered service is actual signed package runtime direct helper child', registration['identity']['ppid']==registration['helper_pid']==load(W/'actor.launch.json')['owned_popen_pid'] and registration['identity']['pid']==registration['identity']['pgid'] and registration['identity']['executable']==str(Path(package_pins['runtime_root'])/'japp-orchestrator/japp-orchestrator') and not registration['private_token_retained'])
check('No token in retained launch/pin interfaces', set(package_pins)=={'target','runtime_root','manifest_sha256','entrypoint_sha256','observation_root'} and set(actor_u['environment'])=={'PATH','HOME','JAPP_PACKAGE_PROBE_INPUT'} and actor_u['environment']['JAPP_PACKAGE_PROBE_INPUT']==str(W.resolve()/'package-pins.json'))
closure=worker['owned_service_closure'];fence=load(W/'worker-group-fence.json')
check('Registered service PID/group/listener closure, no emergency signals', worker['status']=='HEADLESS_PACKAGE_SERVICE_CASE_PASS' and worker['helper_launches']==1 and all(closure[k] for k in ['registered_service','pid_absent','group_absent','listener_closed']) and not closure['emergency_term'] and not closure['emergency_kill'])
check('Intentional worker-group TERM distinct from outer emergency fence', worker['owned_worker_group_term'] is True and fence==outer['worker_group_fence'] and fence['leader_live'] and fence['before']==[load(W/'outer.launch.json')['owned_popen_pid']] and fence['remaining_before_release']==[] and fence['released'] and not fence['term'] and not fence['kill'])
check('Outer worker reaped/group absent and bounded', outer['status']=='OUTER_CLOSED' and outer['worker_exit']==0 and outer['worker_cleanup']['reaped'] and outer['worker_group_absent'] and outer['within_total_bound'] and outer['elapsed_seconds']<1000)
# Preserve separate local Rust observer defect, never reinterpret it as Windows.
L=Path('/tmp/japp-m03-w06-windows-manifest-local-rust-20261019')
local=load(L/'rust-result.json');lc=load(L/'closure.json');recon=load(L/'single-command-reconciliation.derived.json')
check('Separate local Rust command PASS, original footer FAIL preserved', local['exit_code']==0 and local['owned_group_after']=='GONE' and local['cleanup']==[] and sha(L/'rust.log')==local['log_sha256']==recon['raw_log_sha256'] and lc['all6_commands_executed'] is False and lc['all_executed_commands_exit0'] is True and load(L/'before.json')==load(L/'after.json') and load(L/'runtime-before.json')==load(L/'runtime-after.json') and sha(L/'closure.json')==recon['original_closure_sha256'] and sha(L/'executed-wrapper.py')==recon['original_wrapper_sha256'])
check('Separate local Rust actual232 each3 summaries', len(re.findall(r'test result: ok\. 232 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', (L/'rust.log').read_text()))==3)
summary={'decision':'DATA_CLEAR' if all(r['clear'] for r in checks) else 'DATA_FINDING','checks':checks,'source':{'immutable_probe_head':c['expected_head'],'immutable_probe_tree':c['expected_tree'],'historical_canonical_boundary_head':a['head'],'historical_canonical_boundary_tree':a['tree']},'counts':{'catalog':233,'selected_actual_tests':1,'filtered_uninvoked':232,'app_files':43,'runtime_files':40,'recorded_immutable_source':1951,'recorded_derivative_source':1952,'recorded_canonical_source':1956},'selected_physical_bindings':selected_physical+source_bindings,'helper_image':{'path':str(image),**actual_helper},'command_records':command_rows,'limitations':['Record-map joins are not a fresh physical rehash of all417MB source/app/runtime/toolchain/cache bodies','Physical selected actor/module/schema/receipt sources and47.75MB helper were independently rehashed','No full233-case execution, GUI/LaunchServices/OS-store/package certification or milestone acceptance','Worker intentional own-group TERM=true is preserved, service and outer emergency TERM/KILL=false are separately scoped','No process/import/test/compiler/native actor/root operation was performed by this review']}
(A/'findings.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'decision':summary['decision'],'clear':sum(x['clear'] for x in checks),'checks':len(checks),'failed':[x['check'] for x in checks if not x['clear']]},indent=2))
