"""UNEXECUTED future Mac headless service probe. Requires a separately reviewed pin file.

No GUI, LaunchServices, OS-store, or installer action. Only cfg(test) source differs.
The outer process owns the worker session; the worker owns every fixed Popen child.
"""
from __future__ import annotations

import argparse
import ctypes
import hashlib
import importlib.util
import json
import os
import platform
import signal
import stat
import subprocess
import sys
import tarfile
import time
from dataclasses import asdict
from pathlib import Path, PurePosixPath

HERE = Path(__file__).resolve().parent
HEAD = 'e0a501b4979d5e76bf68859fe8c514a17c3c5b7e'
TREE = 'bbf94e791c7d5ad038dded4b0683f4cc57f57b83'
CASE = 'service::package_validation::packaged_runtime_health_auth_and_owned_cleanup'
MANIFEST = 'c9049a3f63572c0de9b114700e9326bebc0518166840133cce9548565c58de1d'
ENTRYPOINT = 'fc2293a3d6425093c03ada543249ccdc2050038613cf984b3983aada18032c7c'
MAX_LOG = 32 * 1024 * 1024
MAX_SOURCE = 512 * 1024 * 1024
# Pinned e0a manifest: 417,520,452 source bytes. 512MiB includes finite tar overhead.
WORK_SECONDS = 840
TOTAL_SECONDS = 900


def write(path: Path, data: object) -> None:
    with path.open('x') as target:
        json.dump(data, target, indent=2)
        target.write('\n')


def file_row(path: Path) -> dict:
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_size > 512 * 1024 * 1024:
        raise ValueError('Bounded regular file required')
    h = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            h.update(block)
    after = path.lstat()
    signature = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_mode)
    if signature(before) != signature(after):
        raise ValueError('Input changed while hashing')
    return {'bytes': before.st_size, 'sha256': h.hexdigest(), 'mode': stat.S_IMODE(before.st_mode)}


def bind(row: dict) -> Path:
    path = Path(row['path'])
    if not path.is_absolute() or path.is_symlink() or path.resolve() != path:
        raise ValueError('Explicit physical file path required')
    if file_row(path) != {name: row[name] for name in ('bytes', 'sha256', 'mode')}:
        raise ValueError(f'Input pin mismatch: {path}')
    return path


def tree_rows(root: Path, max_files: int = 2048) -> dict:
    if not root.is_absolute() or root.is_symlink() or root.resolve() != root or not root.is_dir():
        raise ValueError('Physical absolute input directory required')
    rows = {}
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise ValueError('Input tree symlink refused')
        if path.is_file():
            if len(rows) >= max_files:
                raise ValueError('Input file-count bound exceeded')
            rows[path.relative_to(root).as_posix()] = file_row(path)
        elif not path.is_dir():
            raise ValueError('Input tree special entry refused')
    return rows


def load_probe(c: dict):
    # Verify both source files before either source is imported. No ambient sys.path.
    core_path = bind(c['bindings']['probe_core'])
    mac_path = bind(c['bindings']['probe_mac'])
    for name, path in [('japp_probe_core', core_path), ('japp_mac_probe', mac_path)]:
        if name in sys.modules:
            raise ValueError('Observer module name already occupied')
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    return sys.modules['japp_mac_probe'].MacProbe(), sys.modules['japp_probe_core'].same_process


def preflight(c: dict, out: Path) -> dict:
    if platform.python_version() != '3.12.13':
        raise ValueError('Exact project Python 3.12.13 required')
    if platform.system() != 'Darwin' or platform.machine() != 'arm64':
        raise ValueError('Native arm64 macOS required')
    if c['expected_head'] != HEAD or c['expected_tree'] != TREE:
        raise ValueError('Exact reviewed immutable source required')
    if c['case'] != CASE or len(c['baseline_test_ids']) != 232 or len(set(c['baseline_test_ids'])) != 232 or CASE in c['baseline_test_ids']:
        raise ValueError('Exact prior source-bound 232-case catalog plus one new case required')
    tools = {name: str(bind(c['bindings'][name])) for name in ('python', 'git', 'cargo', 'rustc', 'actor', 'runner', 'probe_core', 'probe_mac')}
    if Path(sys.executable).resolve() != Path(tools['python']) or Path(tools['runner']) != Path(__file__).resolve():
        raise ValueError('Actual interpreter and runner must equal reviewed pins')
    app = Path(c['app_bundle'])
    runtime = app/'Contents/Resources/runtime'
    observed = {'app': tree_rows(app, 64), 'runtime': tree_rows(runtime, 64)}
    if observed['app'] != c['app_files'] or observed['runtime'] != c['runtime_files']:
        raise ValueError('Exact previously retained signed app/runtime bodies and modes required')
    if len(observed['app']) != 43 or len(observed['runtime']) != 40 or observed['runtime']['manifest.json']['sha256'] != MANIFEST or observed['runtime']['japp-orchestrator/japp-orchestrator']['sha256'] != ENTRYPOINT:
        raise ValueError('Exact current 43-file app / 40-file c904 runtime required')
    for name in ('source_repo', 'cargo_home', 'rustup_home'):
        path = Path(c[name])
        if not path.is_absolute() or path.is_symlink() or path.resolve() != path or not path.is_dir():
            raise ValueError('Physical existing bounded context directory required')
    # This is a bound environment, not an assertion about every SDK or cache byte.
    env = dict(c['build_environment'])
    allowed = {'PATH', 'HOME', 'CARGO_HOME', 'RUSTUP_HOME', 'RUSTC', 'CARGO_BUILD_JOBS', 'MACOSX_DEPLOYMENT_TARGET', 'SDKROOT'}
    if set(env) - allowed or env.get('RUSTC') != tools['rustc'] or env.get('CARGO_HOME') != c['cargo_home'] or env.get('RUSTUP_HOME') != c['rustup_home'] or env.get('CARGO_BUILD_JOBS') != '2':
        raise ValueError('Reviewed explicit build environment required')
    env.update(CARGO_TARGET_DIR=str(out/'target'), CARGO_NET_OFFLINE='true')
    observed['tools'] = tools
    observed['environment'] = env
    return observed


def group_members(probe, pgid: int) -> list[int]:
    # Apple libproc.c returns a PID count from proc_listpgrppids, not bytes.
    operation = probe.lib.proc_listpgrppids
    operation.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_int]
    operation.restype = ctypes.c_int
    values = (ctypes.c_int * 512)()
    ctypes.set_errno(0)
    count = int(operation(pgid, values, ctypes.sizeof(values)))
    if count < 0 or count >= 512:
        raise ValueError('Owned group inventory failed or exceeded bound')
    if count == 0 and probe.group_present(pgid):
        raise ValueError('Present owned group inventory was not observable')
    return [int(values[index]) for index in range(count) if values[index] > 0]


def release_worker(probe, same, identity, out: Path) -> dict:
    # The worker deliberately remains a live session leader after writing its
    # result. It cannot exit normally until this fence releases it, and its own
    # finite guard KILLs the group if an outer release never arrives.
    record = {'leader_live': False, 'term': False, 'kill': False, 'released': False}
    if identity is None or not same(identity, probe.identity(identity.pid)):
        return record
    record['leader_live'] = True
    members = group_members(probe, identity.pgid)
    record['before'] = members
    others = [pid for pid in members if pid != identity.pid]
    if others:
        if not same(identity, probe.identity(identity.pid)):
            raise ValueError('Owned witness exited immediately before group TERM')
        os.killpg(identity.pgid, signal.SIGTERM)
        record['term'] = True
        deadline = time.monotonic()+3
        while time.monotonic() < deadline:
            if not same(identity, probe.identity(identity.pid)):
                raise ValueError('Owned witness exited before group fence')
            others = [pid for pid in group_members(probe, identity.pgid) if pid != identity.pid]
            if not others:
                break
            time.sleep(.02)
    record['remaining_before_release'] = others
    if others:
        if not same(identity, probe.identity(identity.pid)):
            raise ValueError('Owned witness exited before group escalation')
        os.killpg(identity.pgid, signal.SIGKILL)
        record['kill'] = True
    else:
        # Only the live worker remains, and its post-marker source spawns no
        # further child. Atomic release closes the final source of new members.
        ready = out/'worker-release.tmp'
        ready.write_bytes(b'RELEASE')
        ready.replace(out/'worker-release')
        record['released'] = True
    write(out/'worker-group-fence.json', record)
    return record


def stop_child(child: subprocess.Popen | None, term_seconds: float = 8) -> dict:
    result = {'owned_popen': child is not None, 'term': False, 'kill': False, 'reaped': child is None}
    if child is None:
        return result
    if child.poll() is None:
        child.terminate()
        result['term'] = True
        try:
            child.wait(timeout=term_seconds)
        except subprocess.TimeoutExpired:
            child.kill()
            result['kill'] = True
    try:
        result['exit'] = child.wait(timeout=3)
        result['reaped'] = True
    except subprocess.TimeoutExpired:
        result['reaped'] = False
    return result


def command(c: dict, probe, out: Path, label: str, argv: list[str], cwd: Path, env: dict, seconds: float, observe=None) -> tuple[int, dict | None]:
    for row in c['bindings'].values():
        bind(row)
    started = time.monotonic()
    write(out/(label+'.upfront.json'), {'argv': argv, 'cwd': str(cwd), 'environment': env, 'seconds': seconds, 'start_utc_ns': time.time_ns()})
    child = None
    observed = None
    failure = None
    code = None
    try:
        with (out/(label+'.stdout')).open('xb') as stdout, (out/(label+'.stderr')).open('xb') as stderr:
            # Inherit the owned worker group; no shell and no independent group.
            if os.getpgrp() != os.getpid():
                raise ValueError('Observed worker session leadership required')
            child = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
            identity = probe.identity(child.pid)
            if identity is None or identity.ppid != os.getpid() or identity.pgid != os.getpgrp():
                raise ValueError('Actual direct owned command identity unavailable')
            write(out/(label+'.launch.json'), {'identity': asdict(identity), 'owned_popen_pid': child.pid})
            while child.poll() is None:
                if time.monotonic()-started > seconds:
                    raise TimeoutError(label+' exceeded declared work budget')
                if stdout.tell() > (MAX_SOURCE if label == 'git-source-archive' else MAX_LOG) or stderr.tell() > MAX_LOG:
                    raise ValueError('Command raw log bound exceeded')
                if observe is not None and observed is None:
                    observed = observe(child)
                time.sleep(.01)
            code = child.returncode
    except BaseException as error:
        failure = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        cleanup = stop_child(child)
        write(out/(label+'.result.json'), {'exit': code, 'failure': failure, 'owned_cleanup': cleanup, 'elapsed_seconds': time.monotonic()-started})
        for row in c['bindings'].values():
            bind(row)
    return code, observed


def prepare_projection(c: dict, observed: dict, probe, out: Path) -> Path:
    git = observed['tools']['git']
    env = {'PATH': '/usr/bin:/bin', 'HOME': c['build_environment']['HOME'], 'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_OPTIONAL_LOCKS': '0'}
    repository = Path(c['source_repo'])
    code, _ = command(c, probe, out, 'git-source-pin', [git, '-C', str(repository), 'rev-parse', HEAD, HEAD+'^{tree}'], HERE, env, 20)
    if code != 0 or (out/'git-source-pin.stdout').read_text().splitlines() != [HEAD, TREE]:
        raise ValueError('Immutable Git source/tree pin mismatch')
    code, _ = command(c, probe, out, 'git-source-archive', [git, '-C', str(repository), 'archive', '--format=tar', HEAD], HERE, env, 30)
    if code != 0 or (out/'git-source-archive.stdout').stat().st_size > MAX_SOURCE:
        raise ValueError('Git source archive failed or exceeded bound')
    source = out/'source'
    source.mkdir(mode=0o700)
    total = 0
    seen = set()
    with tarfile.open(out/'git-source-archive.stdout', 'r:') as archive:
        for member in archive:
            name = PurePosixPath(member.name)
            if name.is_absolute() or '..' in name.parts or member.name in seen or not (member.isfile() or member.isdir()):
                raise ValueError('Unsafe source archive member')
            seen.add(member.name)
            target = source.joinpath(*name.parts)
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            total += member.size
            if total > MAX_SOURCE:
                raise ValueError('Source projection size bound exceeded')
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.extractfile(member) as old, target.open('xb') as new:
                new.write(old.read())
            target.chmod(0o755 if member.mode & 0o111 else 0o644)
    original = tree_rows(source)
    if original != c['source_files'] or len(original) != 1951:
        raise ValueError('Complete exact immutable source projection mismatch')
    write(out/'source-before.json', original)
    service = source/'apps/desktop/src-tauri/src/service/mod.rs'
    marker = '\n#[cfg(test)]\nmod package_validation;\n'
    if 'mod package_validation;' in service.read_text():
        raise ValueError('Probe module already present')
    service.write_text(service.read_text()+marker)
    actor = source/'apps/desktop/src-tauri/src/service/package_validation.rs'
    actor.write_bytes(bind(c['bindings']['actor']).read_bytes())
    actor.chmod(0o644)
    changed = tree_rows(source)
    difference = {name for name in set(original)|set(changed) if original.get(name) != changed.get(name)}
    if difference != {'apps/desktop/src-tauri/src/service/mod.rs', 'apps/desktop/src-tauri/src/service/package_validation.rs'}:
        raise ValueError('Only exact cfg(test) derivative is permitted')
    write(out/'source-derivative.json', {'files': changed, 'changed': sorted(difference)})
    return source


def service_closure(probe, same, service, port) -> dict:
    closure = {'registered_service': service is not None, 'emergency_term': False, 'emergency_kill': False, 'unregistered_descendants': 'UNOBSERVED'}
    if service is None:
        return closure
    deadline = time.monotonic()+8
    while time.monotonic() < deadline and (probe.present(service.pid) or probe.group_present(service.pgid) or not probe.socket_closed(port)):
        time.sleep(.02)
    if probe.present(service.pid) and same(service, probe.identity(service.pid)):
        os.killpg(service.pgid, signal.SIGTERM)
        closure['emergency_term'] = True
        deadline = time.monotonic()+3
        while time.monotonic() < deadline and probe.present(service.pid):
            time.sleep(.02)
    if probe.present(service.pid) and same(service, probe.identity(service.pid)):
        os.killpg(service.pgid, signal.SIGKILL)
        closure['emergency_kill'] = True
    deadline = time.monotonic()+3
    while time.monotonic() < deadline and (probe.present(service.pid) or probe.group_present(service.pgid) or not probe.socket_closed(port)):
        time.sleep(.02)
    closure.update(pid_absent=not probe.present(service.pid), group_absent=not probe.group_present(service.pgid), listener_closed=probe.socket_closed(port))
    return closure


def finish_live_worker_group(out: Path, result: dict) -> None:
    # This guard begins BEFORE any final result/release/timeout-receipt I/O.
    # Failed metadata writes cannot release the live group ownership witness.
    if os.getpgrp() != os.getpid():
        raise ValueError('Cannot finalize an unowned worker session')
    released = False
    failure = None
    deadline = time.monotonic()+20
    try:
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        os.killpg(os.getpgrp(), signal.SIGTERM)
        result['owned_worker_group_term'] = True
        write(out/'worker.result.json', result)
        release = out/'worker-release'
        while time.monotonic() < deadline:
            if release.exists():
                if release.is_symlink() or release.stat().st_size != 7 or release.read_bytes() != b'RELEASE':
                    raise ValueError('Invalid outer worker release')
                if time.monotonic() >= deadline:
                    raise TimeoutError('Outer worker release arrived too late')
                released = True
                return
            time.sleep(.02)
        raise TimeoutError('Owned worker group release deadline expired')
    except BaseException as error:
        failure = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        if not released:
            try:
                write(out/'worker-group-guard-timeout.json', {'status': 'OWNED_GROUP_KILL', 'seconds': 20, 'failure': failure})
            except BaseException:
                # Retention failure never suppresses owned group escalation.
                pass
            # The still-running worker is the original owned session leader.
            # KILL includes it and any TERM-resistant inherited descendants.
            # A forced cleanup outcome is nonzero and can never become PASS.
            os.killpg(os.getpgrp(), signal.SIGKILL)


def worker(c: dict, out: Path) -> None:
    observed = preflight(c, out)
    write(out/'inputs-before.json', observed)
    probe, same = load_probe(c)
    service = None
    port = None
    result = {'status': 'INCOMPLETE', 'native_actor_observation': 'UNOBSERVED', 'gui_claim': False, 'real_store_claim': False}
    source = None
    original_failure = False
    try:
        source = prepare_projection(c, observed, probe, out)
        cwd = source/'apps/desktop/src-tauri'
        cargo = observed['tools']['cargo']
        env = observed['environment']
        for label, tool, expected in [('cargo-version', cargo, 'cargo 1.97.1 '), ('rustc-version', observed['tools']['rustc'], 'rustc 1.97.1 ')]:
            code, _ = command(c, probe, out, label, [tool, '--version'], cwd, env, 20)
            if code != 0 or not (out/(label+'.stdout')).read_text().startswith(expected):
                raise ValueError('Exact compiler/tool version required')
        code, _ = command(c, probe, out, 'compile', [cargo, 'test', '--offline', '--locked', '--lib', '--no-run', '--message-format=json'], cwd, env, 660)
        if code != 0:
            raise ValueError('Actual cfg(test) derivative compilation failed')
        binaries = []
        for line in (out/'compile.stdout').read_text().splitlines():
            item = json.loads(line)
            if item.get('reason') == 'compiler-artifact' and item.get('profile', {}).get('test') and item.get('executable'):
                binaries.append(Path(item['executable']))
        if len(binaries) != 1 or not binaries[0].resolve().is_relative_to(out/'target'):
            raise ValueError('Exactly one owned compiled lib-test image required')
        image = binaries[0].resolve()
        write(out/'helper-image-before.json', {'path': str(image), **file_row(image)})
        code, _ = command(c, probe, out, 'catalog', [str(image), '--list'], cwd, env, 20)
        catalog = [line[:-6] for line in (out/'catalog.stdout').read_text().splitlines() if line.endswith(': test')]
        if code != 0 or len(catalog) != 233 or sorted(catalog) != sorted(c['baseline_test_ids']+[CASE]):
            raise ValueError('Exact 232 preserved native cases plus one selected case required')
        write(out/'catalog-barrier.json', {'exact_ids': catalog, 'selected_case': CASE, 'old_cases_invoked': False})
        control = out/'observation'
        control.mkdir(mode=0o700)
        package_pins = {'target': 'aarch64-apple-darwin', 'runtime_root': str(Path(c['app_bundle'])/'Contents/Resources/runtime'), 'manifest_sha256': MANIFEST, 'entrypoint_sha256': ENTRYPOINT, 'observation_root': str(control)}
        write(out/'package-pins.json', package_pins)
        actor_env = {'PATH': '/usr/bin:/bin', 'HOME': c['build_environment']['HOME'], 'JAPP_PACKAGE_PROBE_INPUT': str(out/'package-pins.json')}
        def register(child):
            nonlocal service, port
            marker = control/'service-started.json'
            if not marker.exists():
                return None
            if marker.is_symlink() or marker.stat().st_size > 4096:
                raise ValueError('Invalid test-only observation marker')
            try:
                message = json.loads(marker.read_text())
            except json.JSONDecodeError:
                return None
            if set(message) != {'helper_pid', 'port'} or message['helper_pid'] != child.pid or type(message['port']) is not int or not 0 < message['port'] < 65536:
                raise ValueError('Marker does not bind the owned helper')
            current = [probe.identity(pid) for pid in probe.children(child.pid)]
            expected_executable = str(Path(package_pins['runtime_root'])/'japp-orchestrator/japp-orchestrator')
            candidates = [row for row in current if row is not None and row.ppid == child.pid and row.pid == row.pgid and row.status != 5 and row.executable == expected_executable]
            if len(candidates) != 1:
                raise ValueError('Exactly one native direct service/session leader required')
            service = candidates[0]
            port = message['port']
            write(out/'registered-service.json', {'identity': asdict(service), 'port': port, 'helper_pid': child.pid, 'lineage': 'observed direct Popen-child lineage', 'private_token_retained': False})
            if probe.socket_closed(port):
                raise ValueError('ACK-gated service listener was not observed live')
            ready = control/'observer-ready.tmp'
            ready.write_bytes(b'OBSERVED')
            ready.replace(control/'observer-ready')
            return asdict(service)
        code, registration = command(c, probe, out, 'actor', [str(image), '--exact', CASE, '--test-threads=1', '--nocapture'], cwd, actor_env, 45, register)
        result['actor_exit'] = code
        result['native_actor_observation'] = 'ONE_REGISTERED_SERVICE' if registration else 'UNOBSERVED'
        if code != 0 or registration is None:
            raise ValueError('Selected packaged service case did not close successfully')
        raw = (out/'actor.stderr').read_text()
        if 'PACKAGE_SERVICE_ACTOR_PASS actual_native_actors=1' not in raw or 'engine_ready=1 engine_after_cleanup_unavailable=1' not in raw or 'PACKAGE_OWNED_CLEANUP success=true' not in raw or 'PACKAGE_OWNED_CLEANUP_FAILURE' in raw:
            raise ValueError('Expected explicit Engine and same-owner cleanup results absent')
        if '1 passed; 0 failed; 0 ignored;' not in (out/'actor.stdout').read_text():
            raise ValueError('Exact one actual selected test success required')
        if file_row(image) != {key: value for key, value in json.loads((out/'helper-image-before.json').read_text()).items() if key != 'path'}:
            raise ValueError('Actual helper image changed')
        result['status'] = 'CASE_SUCCEEDED_PENDING_CLOSURE'
    except BaseException as error:
        original_failure = True
        result['failure'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        # The whole bookkeeping/observing/pinning boundary is protected, not
        # only the final result write. A second shutdown exception or I/O error
        # cannot let the last live worker witness exit before its finisher.
        try:
            result['helper_launches'] = int((out/'actor.launch.json').exists())
            # A forced helper exit is never a test pass; only registered identities
            # authorize emergency cleanup, after a private-lease EOF grace period.
            try:
                closure = service_closure(probe, same, service, port)
            except BaseException as error:
                closure = {'registered_service': service is not None, 'emergency_term': False, 'emergency_kill': False, 'observation_error': {'type': type(error).__name__, 'message': str(error)}}
            result['owned_service_closure'] = closure
            if not service or not all(closure.get(key) for key in ('pid_absent', 'group_absent', 'listener_closed')) or closure['emergency_term'] or closure['emergency_kill']:
                result['status'] = 'FAILED_OR_UNPROVED_NATIVE_CLOSURE'
            elif result['status'] == 'CASE_SUCCEEDED_PENDING_CLOSURE':
                result['status'] = 'HEADLESS_PACKAGE_SERVICE_CASE_PASS'
            try:
                after = preflight(c, out)
                write(out/'inputs-after.json', after)
                result['input_bytes_modes_unchanged'] = after == observed
                if source is not None:
                    expected = json.loads((out/'source-derivative.json').read_text())['files']
                    actual = tree_rows(source)
                    selected = {name: actual.get(name) for name in expected}
                    extras = {name: row for name, row in actual.items() if name not in expected}
                    result['source_bytes_modes_unchanged'] = selected == expected
                    result['generated_build_files'] = extras
                    if any(not name.startswith('apps/desktop/src-tauri/gen/schemas/') or not name.endswith('.json') for name in extras):
                        raise ValueError('Unanticipated output outside owned build-schema directory')
                    write(out/'source-after.json', {'selected': selected, 'generated_build_files': extras})
                else:
                    result['source_bytes_modes_unchanged'] = False
            except BaseException as error:
                result['post_binding_failure'] = {'type': type(error).__name__, 'message': str(error)}
                result['input_bytes_modes_unchanged'] = False
            if not result.get('input_bytes_modes_unchanged') or not result.get('source_bytes_modes_unchanged'):
                result['status'] = 'FAILED_OR_UNPROVED_INPUT_CLOSURE'
        except BaseException as error:
            result['cleanup_bookkeeping_failure'] = {'type': type(error).__name__, 'message': str(error)}
            result['status'] = 'FAILED_CLEANUP_BOOKKEEPING'
            if not original_failure:
                raise
            # Preserve the already pending original test/work exception.
        finally:
            finish_live_worker_group(out, result)
        if not original_failure and result['status'] != 'HEADLESS_PACKAGE_SERVICE_CASE_PASS':
            raise SystemExit(1)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pins', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--worker', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    args.pins = args.pins.resolve()
    args.output = args.output.resolve()
    c = json.loads(args.pins.read_text())
    if args.worker:
        signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(TimeoutError('Owned outer requested bounded shutdown')))
        worker(c, args.output)
        return
    started = time.monotonic()
    if bind(c['bindings']['runner']) != Path(__file__).resolve() or Path(sys.executable).resolve() != bind(c['bindings']['python']):
        raise ValueError('Reviewed runner/interpreter required before process launch')
    out = args.output
    protected = [HERE, *(Path(c[name]).resolve() for name in ('source_repo', 'app_bundle', 'cargo_home', 'rustup_home'))]
    if not out.is_absolute() or out.exists() or any(out.resolve().is_relative_to(path) or path.is_relative_to(out.resolve()) for path in protected):
        raise ValueError('Fresh disjoint outside evidence/work directory required')
    out.mkdir(mode=0o700)
    probe, same = load_probe(c)
    env = {'PATH': '/usr/bin:/bin', 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1'}
    argv = [sys.executable, '-I', '-S', '-B', str(Path(__file__).resolve()), '--pins', str(args.pins.resolve()), '--output', str(out), '--worker']
    write(out/'outer.upfront.json', {'argv': argv, 'cwd': str(HERE), 'environment': env, 'work_seconds': WORK_SECONDS, 'total_seconds': TOTAL_SECONDS, 'pin_file': file_row(args.pins)})
    child = None
    identity = None
    result = {'status': 'INCOMPLETE', 'gui_claim': False, 'unregistered_descendants': 'UNOBSERVED'}
    try:
        with (out/'worker.stdout').open('xb') as stdout, (out/'worker.stderr').open('xb') as stderr:
            child = subprocess.Popen(argv, cwd=HERE, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, start_new_session=True)
            identity = probe.identity(child.pid)
            if identity is None or identity.pid != identity.pgid or identity.ppid != os.getpid():
                raise ValueError('Owned worker birth/session identity unavailable')
            write(out/'outer.launch.json', {'identity': asdict(identity), 'owned_popen_pid': child.pid})
            while child.poll() is None:
                if time.monotonic()-started > WORK_SECONDS or stdout.tell()>MAX_LOG or stderr.tell()>MAX_LOG:
                    raise TimeoutError('Outer work/log bound reached; cleanup reserve begins')
                if (out/'worker.result.json').exists() and not (out/'worker-release').exists():
                    result['worker_group_fence'] = release_worker(probe, same, identity, out)
                time.sleep(.05)
            result['worker_exit'] = child.returncode
    except BaseException as error:
        result['failure'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        cleanup = {'owned_popen': child is not None, 'term': False, 'group_kill': False, 'reaped': child is None}
        if child is not None:
            if child.poll() is None:
                child.terminate()
                cleanup['term'] = True
                try:
                    child.wait(timeout=35)
                except subprocess.TimeoutExpired:
                    # Signal the whole worker session only while its exact saved
                    # live leader still proves this owned session's identity.
                    if identity is not None and same(identity, probe.identity(identity.pid)):
                        os.killpg(identity.pgid, signal.SIGKILL)
                        cleanup['group_kill'] = True
                    else:
                        child.kill()  # The fixed Popen handle only; no guessed group.
            try:
                cleanup['exit'] = child.wait(timeout=3)
                cleanup['reaped'] = True
            except subprocess.TimeoutExpired:
                cleanup['reaped'] = False
        result['worker_cleanup'] = cleanup
        # If the worker had to be terminated, its already retained, direct-child
        # registration still binds the native service's exact birth/group. Never
        # discover or signal a process by name. A missing registration stays
        # UNOBSERVED and cannot confer a successful native closure result.
        if result.get('worker_exit') != 0:
            try:
                record = out/'registered-service.json'
                if record.exists() and not record.is_symlink() and record.stat().st_size <= 8192:
                    retained = json.loads(record.read_text())
                    native = sys.modules['japp_probe_core'].Identity(**retained['identity'])
                    expected = str(Path(c['app_bundle'])/'Contents/Resources/runtime/japp-orchestrator/japp-orchestrator')
                    if native.pid != native.pgid or native.executable != expected or retained['helper_pid'] != native.ppid or type(retained['port']) is not int or not 0 < retained['port'] < 65536:
                        raise ValueError('Invalid saved direct-child service registration')
                    result['outer_service_cleanup'] = service_closure(probe, same, native, retained['port'])
                else:
                    result['outer_service_cleanup'] = {'registered_service': False, 'status': 'UNOBSERVED'}
            except BaseException as error:
                result['outer_service_cleanup'] = {'status': 'UNPROVED', 'error': type(error).__name__, 'message': str(error)}
        if identity is not None:
            deadline = time.monotonic()+3
            while time.monotonic() < deadline and probe.group_present(identity.pgid):
                time.sleep(.02)
        result['worker_group_absent'] = identity is not None and not probe.group_present(identity.pgid)
        result['elapsed_seconds'] = time.monotonic()-started
        result['within_total_bound'] = result['elapsed_seconds'] <= TOTAL_SECONDS
        result['status'] = 'OUTER_CLOSED' if result.get('worker_exit') == 0 and result['worker_cleanup']['reaped'] and result['worker_group_absent'] and result['within_total_bound'] and not result.get('worker_group_fence', {}).get('kill') else 'FAILED_OR_UNPROVED_OUTER_CLOSURE'
        write(out/'outer.result.json', result)
    if result['status'] != 'OUTER_CLOSED':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
