"""Unexecuted fake-only oracles for the actual closed v4 guard source.

The selected two functions are AST-extracted into an injected fake namespace.
No subject module, native library, Popen, signal, store, or network is imported.
"""
from __future__ import annotations

import ast
import hashlib
from pathlib import Path
from types import SimpleNamespace

import pytest

RUNNER = Path(__file__).with_name('run_mac_packaged_service.py')
EXPECTED_RUNNER_SHA256 = '46558ea45adc54524a2c47d7647a13f1a51028f3d927f864f55e21e7ae1f334e'


class GuardKilled(BaseException):
    pass


class FakePath:
    def __init__(self, name='', *, ack=b'RELEASE', read_error=False):
        self.name = name
        self.ack = ack
        self.read_error = read_error

    def __truediv__(self, name):
        return FakePath(name, ack=self.ack, read_error=self.read_error)

    def exists(self):
        return True

    def is_symlink(self):
        return False

    def stat(self):
        return SimpleNamespace(st_size=len(self.ack))

    def read_bytes(self):
        if self.read_error:
            raise PermissionError('fake unreadable release')
        return self.ack


def injected(*, clock=(0, 0, 0), write_error=False, pgid=50):
    source = RUNNER.read_bytes()
    assert hashlib.sha256(source).hexdigest() == EXPECTED_RUNNER_SHA256
    parsed = ast.parse(source)
    selected = [node for node in parsed.body if isinstance(node, ast.FunctionDef) and node.name in {'finish_live_worker_group', 'release_worker'}]
    assert len(selected) == 2
    signals = []
    writes = []
    ticks = iter(clock)
    def killpg(group, kind):
        signals.append((group, kind))
        if kind == 9:
            raise GuardKilled()
    def write(path, value):
        writes.append((path.name, value))
        if write_error:
            raise OSError('fake no space for any receipt')
    env = {'Path': object, 'os': SimpleNamespace(getpgrp=lambda: pgid, getpid=lambda: 50, killpg=killpg), 'signal': SimpleNamespace(SIGTERM=15, SIGKILL=9, SIG_IGN=1, signal=lambda *_: None), 'time': SimpleNamespace(monotonic=lambda: next(ticks), sleep=lambda _: None), 'write': write, 'group_members': lambda *_: [50, 52]}
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(RUNNER), 'exec'), env)
    return env, signals, writes


def test_result_and_timeout_receipt_write_failure_cannot_skip_kill():
    env, signals, writes = injected(write_error=True)
    with pytest.raises(GuardKilled):
        env['finish_live_worker_group'](FakePath(), {'status': 'ORIGINAL_TEST_FAILURE'})
    assert signals == [(50, 15), (50, 9)]
    assert [name for name, _ in writes] == ['worker.result.json', 'worker-group-guard-timeout.json']
    assert writes[0][1]['status'] == 'ORIGINAL_TEST_FAILURE'
    assert writes[1][1]['failure']['type'] == 'OSError'


def test_invalid_release_cannot_drop_ownership_witness():
    env, signals, writes = injected()
    with pytest.raises(GuardKilled):
        env['finish_live_worker_group'](FakePath(ack=b'BAD'), {})
    assert signals == [(50, 15), (50, 9)]
    assert writes[-1][1]['failure']['type'] == 'ValueError'


def test_unreadable_release_cannot_drop_ownership_witness():
    env, signals, writes = injected()
    with pytest.raises(GuardKilled):
        env['finish_live_worker_group'](FakePath(read_error=True), {})
    assert signals == [(50, 15), (50, 9)]
    assert writes[-1][1]['failure']['type'] == 'PermissionError'


def test_missing_release_deadline_kills_still_owned_group():
    env, signals, writes = injected(clock=(0, 21))
    with pytest.raises(GuardKilled):
        env['finish_live_worker_group'](FakePath(), {})
    assert signals == [(50, 15), (50, 9)]
    assert writes[-1][1]['seconds'] == 20
    assert writes[-1][1]['failure']['type'] == 'TimeoutError'


def test_late_release_is_not_success():
    env, signals, writes = injected(clock=(0, 19, 21))
    with pytest.raises(GuardKilled):
        env['finish_live_worker_group'](FakePath(), {})
    assert signals == [(50, 15), (50, 9)]
    assert writes[-1][1]['failure']['type'] == 'TimeoutError'


def test_exact_timely_release_does_not_kill_or_relabel_failure():
    env, signals, writes = injected(clock=(0, 1, 2))
    outcome = {'status': 'ORIGINAL_TEST_FAILURE'}
    env['finish_live_worker_group'](FakePath(), outcome)
    assert signals == [(50, 15)]
    assert len(writes) == 1
    assert outcome['status'] == 'ORIGINAL_TEST_FAILURE'


def test_unowned_group_never_receives_signal():
    env, signals, writes = injected(pgid=99)
    with pytest.raises(ValueError, match='unowned'):
        env['finish_live_worker_group'](FakePath(), {})
    assert signals == []
    assert writes == []


def test_identity_change_during_group_query_refuses_term():
    env, signals, writes = injected()
    answers = iter((True, False))
    identity = SimpleNamespace(pid=50, pgid=50)
    probe = SimpleNamespace(identity=lambda _: identity)
    with pytest.raises(ValueError, match='immediately before group TERM'):
        env['release_worker'](probe, lambda *_: next(answers), identity, FakePath())
    assert signals == []
    assert writes == []


class BookkeepingFaultPath(FakePath):
    def __init__(self, error):
        self.error = error

    def __truediv__(self, _name):
        return self

    def exists(self):
        raise self.error


def actual_worker_finally(*, error, original_failure):
    # Execute the actual closed worker-finally AST, not a second implementation
    # of its intended try/finally. No other part of worker is imported/executed.
    source = RUNNER.read_bytes()
    assert hashlib.sha256(source).hexdigest() == EXPECTED_RUNNER_SHA256
    parsed = ast.parse(source)
    worker = next(node for node in parsed.body if isinstance(node, ast.FunctionDef) and node.name == 'worker')
    boundary = next(node for node in worker.body if isinstance(node, ast.Try) and node.finalbody)
    shell = ast.parse('def actual_boundary():\n    pass\n').body[0]
    shell.body = boundary.finalbody
    closed = ast.fix_missing_locations(ast.Module(body=[shell], type_ignores=[]))
    result = {'status': 'ORIGINAL_TEST_FAILURE', 'failure': {'type': 'AssertionError', 'message': 'original native assertion'}}
    finishes = []
    env = {'result': result, 'out': BookkeepingFaultPath(error), 'original_failure': original_failure, 'finish_live_worker_group': lambda out, current: finishes.append(dict(current))}
    exec(compile(closed, str(RUNNER), 'exec'), env)
    return env['actual_boundary'], result, finishes


def test_original_bookkeeping_io_error_still_finishes_and_keeps_original_failure():
    boundary, result, finishes = actual_worker_finally(error=OSError('fake bookkeeping I/O'), original_failure=True)
    boundary()
    assert len(finishes) == 1
    assert result['failure'] == {'type': 'AssertionError', 'message': 'original native assertion'}
    assert result['cleanup_bookkeeping_failure']['type'] == 'OSError'
    assert finishes[0]['status'] == 'FAILED_CLEANUP_BOOKKEEPING'


def test_sigterm_style_bookkeeping_exception_still_finishes_and_propagates():
    error = TimeoutError('fake SIGTERM while observing closure')
    boundary, result, finishes = actual_worker_finally(error=error, original_failure=False)
    with pytest.raises(TimeoutError) as failure:
        boundary()
    assert failure.value is error
    assert len(finishes) == 1
    assert result['cleanup_bookkeeping_failure']['type'] == 'TimeoutError'
    assert finishes[0]['status'] == 'FAILED_CLEANUP_BOOKKEEPING'
