"""UNEXECUTED future documentary pin preparation; no compiler/provider/actor import."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
HEAD = 'e0a501b4979d5e76bf68859fe8c514a17c3c5b7e'
TREE = 'bbf94e791c7d5ad038dded4b0683f4cc57f57b83'


def row(path: Path) -> dict:
    path = path.resolve(strict=True)
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode):
        raise ValueError('Physical regular pin input required')
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024*1024), b''):
            digest.update(block)
    return {'path': str(path), 'bytes': info.st_size, 'sha256': digest.hexdigest(), 'mode': stat.S_IMODE(info.st_mode)}


def baseline_ids(path: Path) -> list[str]:
    # The aggregate can have a separate failure. Only its actual first closed
    # 232-case Rust block is used as the catalog preimage, never as full PASS.
    active = False
    names = []
    for line in path.read_text().splitlines():
        if not active:
            if line == 'running 232 tests':
                active = True
            continue
        found = re.fullmatch(r'test ([A-Za-z0-9_:]+) \.\.\. ok', line)
        if found:
            names.append(found.group(1))
        if line.startswith('test result:'):
            if not re.match(r'test result: ok\. 232 passed; 0 failed; 0 ignored;', line) or len(names) != 232 or len(set(names)) != 232:
                raise ValueError('First actual 232-case block was not exact zero-skip PASS')
            return names
    raise ValueError('Actual closed 232-case catalog evidence absent')


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('output', 'source-repo', 'source-before', 'baseline-log', 'app-bundle', 'app-record', 'runtime-record', 'python', 'git', 'cargo', 'rustc', 'cargo-home', 'rustup-home', 'home', 'probe-core', 'probe-mac'):
        p.add_argument('--'+name, type=Path, required=True)
    p.add_argument('--sdkroot', type=Path)
    p.add_argument('--deployment-target')
    a = p.parse_args()
    if a.output.exists():
        raise ValueError('New pin output only')
    before = json.loads(a.source_before.read_text())
    if before['head'] != HEAD or before['tree'] != TREE or before['status'] != '' or len(before['files']) != 1951:
        raise ValueError('Exact closed source preimage metadata required')
    env = {'PATH': '/usr/bin:/bin', 'HOME': str(a.home.resolve()), 'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_OPTIONAL_LOCKS': '0'}
    argv = [str(a.git.resolve()), '-C', str(a.source_repo.resolve()), 'ls-tree', '-r', '--full-tree', HEAD]
    result = subprocess.run(argv, env=env, capture_output=True, timeout=20, check=False)
    if result.returncode:
        raise ValueError('Read-only immutable tree mode inventory failed')
    modes = {}
    for line in result.stdout.decode().splitlines():
        left, name = line.split('\t', 1)
        mode, kind, _object = left.split()
        if kind != 'blob' or mode not in {'100644', '100755'}:
            raise ValueError('Only regular Git source entries are supported')
        modes[name] = 0o755 if mode == '100755' else 0o644
    if set(modes) != set(before['files']):
        raise ValueError('Whole source metadata and immutable Git tree differ')
    source = {name: {**value, 'mode': modes[name]} for name, value in before['files'].items()}
    app = json.loads(a.app_record.read_text())
    runtime = json.loads(a.runtime_record.read_text())
    if len(app) != 43 or len(runtime) != 40:
        raise ValueError('Exact closed app/runtime records required')
    tools = {'python': a.python, 'git': a.git, 'cargo': a.cargo, 'rustc': a.rustc, 'actor': HERE/'package_validation.rs', 'runner': HERE/'run_mac_packaged_service.py', 'probe_core': a.probe_core, 'probe_mac': a.probe_mac, 'source_before': a.source_before, 'baseline_log': a.baseline_log, 'app_record': a.app_record, 'runtime_record': a.runtime_record}
    bindings = {name: row(path) for name, path in tools.items()}
    build = {'PATH': '/usr/bin:/bin:/usr/sbin:/sbin', 'HOME': str(a.home.resolve()), 'CARGO_HOME': str(a.cargo_home.resolve()), 'RUSTUP_HOME': str(a.rustup_home.resolve()), 'RUSTC': bindings['rustc']['path'], 'CARGO_BUILD_JOBS': '2'}
    if a.sdkroot:
        build['SDKROOT'] = str(a.sdkroot.resolve(strict=True))
    if a.deployment_target:
        build['MACOSX_DEPLOYMENT_TARGET'] = a.deployment_target
    config = {'schema': 'UNEXECUTED_MAC_HEADLESS_PACKAGE_SERVICE_V2', 'expected_head': HEAD, 'expected_tree': TREE, 'case': 'service::package_validation::packaged_runtime_health_auth_and_owned_cleanup', 'source_repo': str(a.source_repo.resolve()), 'source_files': source, 'baseline_test_ids': baseline_ids(a.baseline_log), 'baseline_scope': 'Closed Rust subset only; original aggregate failure is preserved', 'app_bundle': str(a.app_bundle.resolve()), 'app_files': app, 'runtime_files': runtime, 'bindings': bindings, 'cargo_home': build['CARGO_HOME'], 'rustup_home': build['RUSTUP_HOME'], 'build_environment': build, 'metadata_preparation_command': {'argv': argv, 'environment': env, 'exit': result.returncode, 'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(), 'stderr': result.stderr.decode()}}
    a.output.parent.mkdir(parents=True, exist_ok=True)
    with a.output.open('x') as target:
        json.dump(config, target, indent=2)
        target.write('\n')


if __name__ == '__main__':
    main()
