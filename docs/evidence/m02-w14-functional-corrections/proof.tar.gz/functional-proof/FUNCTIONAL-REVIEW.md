# Finite W14 functional corrections

Base: a744ff2287f0714740121009df8ef06e8559823b. Root source was never modified by this agent. No schemas, RPCs, numeric thresholds or gate decisions changed.

Patch: FUNCTIONAL-DELTA.patch, SHA256 ea5f36a5b0c0fd5ab27ff5ee04f76b3ba5a30020517729b2beddac457d4e354b. Eight declared files; exact preimages and before/after hashes are retained.

The mounted helper now refreshes each original target through the existing bounded W08 re-resolution endpoint before W09. It requires the same session/frame/document/durable field ID and refuses missing or ambiguous targets. Composite validation clearing proves that unchanged local references/help/ownership/classes/roles remain exact and only observed rejected error text becomes empty. The exact settled component observation follows W11 and undo; it grants no fresh-fill authority. Physical collision observations remain separate, required/optional uncertainty is canonical, distinct report item IDs never become field authority, and genuine root/capacity/currentness refusals remain unchanged.

Actual results: six new composite cases passed twice; original P8 plus stronger collision-count/removal checks passed; original W06 passed all32 catalog cases with43/43 declared contact controls. Zero scanner gaps, unreported required controls, execution errors, unsupported writes/value changes, duplicate primary events, button clicks or submissions. Source and built extension inventories were unchanged during the successful W06 execution. The missing confirm-email field now has exactly one input event and VERIFIED_FILLED evidence.

Six new cases cover document/shadow stable-help clearing with W11+undo; changed help, ownership and references during input; and post-verified reference rebinding refusing W11+undo. P8 retains12 complete collision snapshots, each with2 distinct required unresolved members and RECONCILED/NOT_READY, then removes only one duplicate. Existing successful edit/add/reorder behavior stays asserted.

Static/CPU results: extension TypeScript PASS, e2e TypeScript PASS, typed ESLint PASS, Prettier PASS, extension units186/186 PASS (14 files), focused classifier24/24 PASS. Pinned Node24.18.0, pnpm11.17.0, WXT0.20.27; real built MV3 in Playwright Chromium.

Preserved setup failures: first outside W06 attempt lacked Git metadata; second had an index but no HEAD. Neither reached W06 assertions. Both logs/results/traces remain outside. The tar copy was given an outside-only detached a744 HEAD/index with read-only object alternates; no test body/expectation was changed for this repair. A dependency wrapper self-link initially prevented extension package lifecycle execution; direct pinned WXT prepare succeeded, outside generated links were repaired, and full checks then passed.

The final eight source hashes match the sealed patch after all runs. Source was operationally held unchanged through P8 and the six composite cases; their run did not independently record whole-source before/after inventories. The successful W06 records complete source/build before/after inventories at the same final source. This is focused correction evidence; complete affected regression/performance and separate final gate review remain with root. This agent implemented these corrections and does not claim an independent final gate approval.

Commands (outside tree, Node24 PATH; pnpm_config_verify_deps_before_run=false):
- pnpm --filter @japp/extension typecheck
- pnpm exec tsc --noEmit -p tsconfig.json
- pnpm exec eslint [the8declaredfiles]
- pnpm --filter @japp/extension test
- pnpm --filter @japp/extension exec vitest run test/m02-w11/dynamic-reconcile.test.ts --no-file-parallelism --maxWorkers=1
- pnpm exec playwright test e2e/extension/extension-w14-w06.spec.ts e2e/extension/extension-w14-composite-clear.spec.ts --trace on --output /tmp/japp-w14-functional-fixes/composite-after-artifacts --reporter=list,json
- pnpm exec playwright test e2e/extension/extension-w14-w06.spec.ts e2e/extension/extension-w14-composite-clear.spec.ts e2e/extension/extension-research.spec.ts --grep 'W14 W06:|composite|P8 regression:' --trace on --output /tmp/japp-w14-functional-fixes/combined-after-artifacts --reporter=list,json
- pnpm exec playwright test e2e/extension/extension-w14-w06.spec.ts --trace on --output /tmp/japp-w14-functional-fixes/w06-after-artifacts --reporter=list,json

Full actual artifacts remain under the paths named above. This compact archive keeps exact compressed before/after W06 rows, raw native runtime responses, all outcome logs/results, setup-failure traces, and representative successful P8/composite traces, without duplicate full output trees.
