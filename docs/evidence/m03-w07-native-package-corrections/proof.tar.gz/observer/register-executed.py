from pathlib import Path
import datetime
import hashlib
import io
import json
import shutil
import stat
import tarfile

E = Path(__file__).parent
ROOT = Path('/Users/tanishkalwad/jobapplyv2')
OUT = E / 'm03-w07-native-corrections-evidence-v3'
OUT.mkdir()
selected = {}

def add(path, name):
    assert stat.S_ISREG(path.lstat().st_mode) and name not in selected
    selected[name] = path

def top(directory, prefix):
    for path in sorted(directory.iterdir()):
        if path.is_file() and not path.is_symlink():
            add(path, prefix + '/' + path.name)

top(E / 'm03-w07-native-corrections-evidence-v2', 'reviewed-preparation')
adoption = E / 'native-package-canonical-adoption-v2'
for path in sorted(adoption.rglob('*')):
    if path.is_dir() and not path.is_symlink():
        continue
    add(path, 'canonical-adoption/' + path.relative_to(adoption).as_posix())
top(E / 'native-canonical-focus-v2', 'canonical-focus')
add(Path(__file__), 'observer/register-executed.py')
rows = []
with tarfile.open(OUT / 'proof.tar.gz', 'w:gz') as archive:
    for name, path in sorted(selected.items()):
        info = path.lstat()
        data = path.read_bytes()
        assert len(data) == info.st_size
        member = tarfile.TarInfo(name)
        member.size = len(data)
        member.mode = stat.S_IMODE(info.st_mode)
        archive.addfile(member, io.BytesIO(data))
        rows.append({'path': name, 'source_path': str(path), 'bytes': len(data), 'mode': member.mode, 'sha256': hashlib.sha256(data).hexdigest()})
with tarfile.open(OUT / 'proof.tar.gz', 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(rows)
    for member, row in zip(members, rows, strict=True):
        stream = archive.extractfile(member)
        assert stream is not None
        body = stream.read()
        original = Path(row['source_path'])
        assert member.isfile() and member.name == row['path'] and member.mode == row['mode']
        assert len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256']
        assert body == original.read_bytes() and member.mode == stat.S_IMODE(original.stat().st_mode)

def dump(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

proof = OUT / 'proof.tar.gz'
dump('artifact.json', {'path': proof.name, 'bytes': proof.stat().st_size, 'sha256': hashlib.sha256(proof.read_bytes()).hexdigest()})
dump('retention-manifest.json', {'members': rows, 'regular_members': len(rows), 'all_selected_original_archive_bytes_full_modes_join': True, 'omissions': ['Canonical-focus temporary fixture bodies.', 'Nested reviewed-preparation archive explicitly omits original package payload ZIPs, complete canonical/runtime bodies, listener compiled binary bodies and private vendor/cache/target trees; their exact bindings remain.']})
focus = E / 'native-canonical-focus-v2'
closure = json.loads((focus / 'closure.json').read_text())
results = json.loads((focus / 'results.json').read_text())
assert closure['all_six_commands_closed_zero'] and closure['source_bytes_fullmodes_status_head_tree_equal']
assert len(results) == 6 and all(r['exit_code'] == 0 and r['reaped'] and r['group'] == 'ABSENT' and not r['signals'] and not r['timeout'] for r in results)
dump('summary.json', {'created_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'scope': 'REVIEWED_NATIVE_PACKAGE_CORRECTIONS_CANONICALLY_ADOPTED_AND_FOCUSED_CHECKED', 'nested_preparation': json.loads((E / 'm03-w07-native-corrections-evidence-v2/summary.json').read_text()), 'canonical_focus': {'commands': results, 'closure': closure, 'python_selected_pass': 26, 'pytest_seconds': 0.09}, 'fresh_corrected_hosted_native_package_windows11_gnome_or_release_credit': False})
(OUT / 'README.md').write_text('''# Reviewed package corrections and actual canonical adoption

This outer packet preserves the immutable reviewed Windows private-build-home
and Unix listener-measurement preparation v2, including Windows original
2PASS/1FAIL versus fixed3PASS, listener v1 shared-target HOLD and separately
compiled v2 five-case controls, and both independent clear reviews. The Unix
afterimage does not assert an unobserved original TIME_WAIT cause or Linux
execution; production socket exclusivity and existing actor oracles remain.

Root guarded adoption copies exactly three reviewed afterimages onto clean
2ea0fde after its completed full run. All other2240tracked source/runtime40
bytes/full modes and HEAD/tree endpoints stay equal. Actual canonical focused
checks then execute six commands: strict Ruff/format/Mypy,26selected Python
tests PASS0.09s, whole portability and integrity PASS. All direct children
exit0/reaped/groupsABSENT/no signals/timeouts; before/after source/runtime
bytes/full modes, three-path dirty status and HEAD/tree endpoints agree.

Exact source/preimages, raw stdout/stderr, argv, closures and nested independent
reviews remain with original selected bytes/full modes. Temporary fixture
bodies and the nested packet's declared original payload/binary/vendor/cache
omissions remain outside. A corrected fresh full and hosted campaign follows;
this source/focused-check packet supplies no Windows11/defaultGNOME GUI,
native-package pass, W07/W08 completion, platform certification or release.
''')

registrations = [
    (E / 'm03-w07-full-2ea-evidence-v1', 'm03-w07-clean-aggregate-2ea'),
    (E / 'm03-w07-ci-80e68ac-failure-evidence-v1', 'm03-w07-ci-80e68ac-failure'),
    (OUT, 'm03-w07-native-package-corrections'),
]
names = {'README.md', 'artifact.json', 'summary.json', 'retention-manifest.json', 'proof.tar.gz'}
for source, name in registrations:
    assert {p.name for p in source.iterdir()} == names
    target = ROOT / 'docs/evidence' / name
    assert not target.exists()
    shutil.copytree(source, target, copy_function=shutil.copy2)
    assert all((source / p).read_bytes() == (target / p).read_bytes() and stat.S_IMODE((source / p).stat().st_mode) == stat.S_IMODE((target / p).stat().st_mode) for p in names)
print(json.dumps({'registered': [name for _, name in registrations], 'outer_members': len(rows), 'proof': json.loads((OUT / 'artifact.json').read_text())}))
