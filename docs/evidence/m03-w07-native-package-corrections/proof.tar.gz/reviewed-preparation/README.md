# Narrow native package build and listener measurement corrections

Windows correction supplies a fresh private build profile, AppData directories
and PyInstaller cache under the owned build work directory. It inherits no
ambient home/cache/token or extra PATH authority. Original native tool/version,
hash locks, all build stages, payload validation and deadlines remain. Actual
final original2PASS1FAIL vs fixed3PASS plus strict Ruff/format/Mypy pass on the
portable synthetic builder/Windows-stdlib seam. All original three IDs and18
assertions remain, with28 final assertions; different34 source/data checks clear
the exact source and original hosted Path.home failure. No corrected native
Windows build, GUI or platform acceptance is supplied by this preparation.

The additive package test keeps Windows' original bind/drop oracle. On Unix,
one250ms raw connection must fail specifically with ConnectionRefused after
same-owner shutdown/drain. A live connection, timeout or other error fails.
It checks listener release; immediate address reuse is not asserted. An inline
owned live/retired connected-server control explicitly uses previous
SO_REUSEADDR=false and logs a legacy-bind differential without an expected
result. Original health/ready/version/auth/authority/shutdown and30s/45s/6s
budgets reconstruct byte-exact; production socket exclusivity is unchanged.

Initial listener v1's data review holds because nominal old/fixed commands
shared a Cargo target and could run the same prior image. V1 and its HOLD stay
immutable. Separate v2 compiles fresh offline into distinct target and Cargo
home directories, retains Cargo JSON source/executable bindings and directly
runs both different image hashes against the exact same five test bodies.
Actual macOS legacy5PASS and fixed5PASS, strict formatting/Clippy pass. Eight
final commands close0/reaped/groupsABSENT/no signals/timeouts, all2240source
and40runtime bytes/fullmodes/status/HEAD-tree endpoints equal. No Linux run,
old TIME_WAIT cause or RED-to-GREEN result is fabricated. The next exact hosted
campaign must execute the inline Linux control and real packaged service.

Selected source/preimages, honest histories, original command and endpoint
records, nested Windows proof, v1 HOLD and v2 independent review are retained.
All selected original/archive bytes/full modes join. Original package payloads,
complete canonical/runtime bodies, compiled listener binaries and private
vendor/cache/target trees remain outside with explicit hash bindings. This
packet is source/test preparation and adds no M03-W07/08 completion, native
Windows11/defaultGNOME GUI certification, final baseline or release readiness.
