from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import stat
import subprocess

R=Path('/Users/tanishkalwad/jobapplyv2');E=Path(__file__).parent
O=E/'native-package-canonical-adoption-v2';O.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
assert git('status','--porcelain')==''
assert git('rev-parse','HEAD')=='2ea0fdedb5eb5452027d9b9760541bd1c30b0e12'
assert git('rev-parse','HEAD^{tree}')=='785d5bad70977edd51afbe602ad2abff39c8458d'
checks={
 'windows-builder-home-fix-v1/SOURCE.json':'2342fbc7b4d2648933e24e9aaae094e59f432b607017c6f2654417e2adc9cd77',
 'windows-builder-home-fix-v1/proof.tar.gz':'a13cfbffd16252e0575ea6054af9b3a10c38fcca3c1d6276733d7f4dfc585568',
 'windows-builder-home-fix-independent-review/v1/manifest.json':'929ebb827593ac9702f7905225d18892721377c7821b7add32a40faa2775d867',
 'ubuntu-package-listener-fix-v2/SOURCE.json':'8f8dca293b618a9a25d1893682426addf0cc2917e0def04dfbf3588338ab8228',
 'ubuntu-package-listener-fix-v2/HANDOFF.json':'fdd2d396079f37e1125bb8e746d176bcd1417a3d886e3bf461ee4fdcb2a636e2',
 'ubuntu-package-listener-fix-independent-review/v2/manifest.json':'af223782bd9824c7a0d273a5268aed12c4b783bbd38a76bf7294888ccbaca51a',
 'full-2ea0fde-independent-review/manifest.json':'1b8edd567e427ffb3892faf5103ebbcb9cfbe473c82e27f2b0558502dc3810c0',
}
assert all(sha(E/n)==s for n,s in checks.items())
closure=json.loads((E/'full-2ea0fde/closure.json').read_text())
assert all(closure[k] for k in ['all_commands_exit_zero','source_bytes_modes_unchanged','runtime_bytes_modes_unchanged','commit_and_tree_equal_at_end_observation'])
rows=[]
for n in ['scripts/build-windows-runtime.py','scripts/tests/test_windows_builder.py']:
    before=E/'windows-builder-home-fix-v1/original'/n;after=E/'windows-builder-home-fix-v1/fixed'/n
    assert (R/n).read_bytes()==before.read_bytes()
    rows.append((n,before,after))
n='scripts/package_validation.rs';before=E/'ubuntu-package-listener-fix-v2/before'/n;after=E/'ubuntu-package-listener-fix-v2/after'/n
assert (R/n).read_bytes()==before.read_bytes() and sha(after)=='0eda23d489e0f902cfa946e403ca2b60251acd4ab5ebaa07d1a7ff087b331c97'
rows.append((n,before,after))
def snapshot():
    source={};runtime={}
    for raw in subprocess.check_output(['git','ls-files','-z'],cwd=R).split(b'\0'):
        if not raw:continue
        n=os.fsdecode(raw);p=R/n;s=p.lstat();assert stat.S_ISREG(s.st_mode)
        source[n]={'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'sha256':sha(p)}
    P=R/'apps/desktop/src-tauri/runtime-payload'
    for p in sorted(P.rglob('*')):
        s=p.lstat()
        if stat.S_ISDIR(s.st_mode):continue
        assert stat.S_ISREG(s.st_mode)
        runtime[p.relative_to(P).as_posix()]={'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'sha256':sha(p)}
    return {'source':source,'runtime':runtime,'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain')}
before=snapshot();(O/'before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
(O/'executed-observer.py').write_bytes(Path(__file__).read_bytes())
for n,preimage,afterimage in rows:
    assert stat.S_ISREG((R/n).lstat().st_mode)
    q=O/'preimages'/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/n,q)
    shutil.copy2(afterimage,R/n)
    assert (R/n).read_bytes()==afterimage.read_bytes()
after=snapshot();(O/'after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n')
changed=sorted(n for n in before['source'] if before['source'][n]!=after['source'][n])
assert changed==sorted(n for n,_,_ in rows)
assert before['runtime']==after['runtime'] and before['head']==after['head'] and before['tree']==after['tree']
record={'observed_utc':datetime.datetime.now(datetime.UTC).isoformat(),'changed_paths':changed,'source_count':len(before['source']),'runtime_count':len(before['runtime']),'runtime_bytes_full_modes_equal':True,'head_tree_equal':True,'review_manifest_pins':checks,'operation':'APPLIED_REVIEWED_THREE_EXISTING_SOURCE_AFTERIMAGES_ONLY','next':'Focused current canonical checks and truthful evidence registration; fresh hosted native Windows/Linux outcomes remain pending'}
(O/'APPLIED.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps(record,indent=2))
