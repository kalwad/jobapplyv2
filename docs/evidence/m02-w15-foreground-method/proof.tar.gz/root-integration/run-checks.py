from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
out=Path(__file__).parent;root=Path('/Users/tanishkalwad/jobapplyv2')
env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@24/bin:'+env['PATH']
steps=[('root-e2e-typecheck',['pnpm','exec','tsc','-p','tsconfig.json']),('benchmark-lint',['pnpm','exec','eslint','e2e/extension/extension-benchmark.spec.ts']),('benchmark-format',['pnpm','exec','prettier','--check','e2e/extension/extension-benchmark.spec.ts']),('status',['uv','run','python','scripts/validate_status.py']),('traceability',['pnpm','traceability:check']),('diff',['git','diff','--check'])]
rows=[]
for name,argv in steps:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 with (out/(name+'.log')).open('wb') as stream:r=subprocess.run(argv,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
 b=(out/(name+'.log')).read_bytes();row=dict(name=name,argv=argv,cwd=str(root),started_at=start,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-t,exit_code=r.returncode,log_bytes=len(b),log_sha256=hashlib.sha256(b).hexdigest());rows.append(row)
 (out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print(b.decode(errors='replace')[-9000:],flush=True);raise SystemExit(r.returncode)
