from pathlib import Path
import datetime as dt
import difflib
import hashlib
import json

BASE = Path('/tmp/japp-m02-w15-native128-foreground-diagnostic-proposal-v3-20261017')
original = (BASE / 'preimage.ts').read_text()
candidate = (BASE / 'candidate.ts').read_text()


def span(value, first, last):
    start = value.index(first)
    return value[start:value.index(last, start)]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


test_start = 'test("W13 L: total scan and re-resolution scaling includes work outside W11"'
next_test = 'test("W13 J: overlapping delayed repeater operations perform one physical click"'
assert original[:original.index(test_start)] == candidate[:candidate.index(test_start)]
assert original[original.index(next_test):] == candidate[candidate.index(next_test):]
timed_first = '    const before = await metrics();'
timed_last = '    expect(outcome.inventory.counts.verified_filled).toBe(count);'
timed = span(original, timed_first, timed_last)
assert timed == span(candidate, timed_first, timed_last)
assert span(original, timed_last, '    rows.push({') == span(candidate, timed_last, '    rows.push({')
old_row = span(original, '    rows.push({', '    await cdp.detach();')
row_start = candidate.index('    rows.push({')
assert candidate[row_start:row_start + len(old_row)] == old_row
retention_start = row_start + len(old_row)
retention_end = candidate.index('    const foregroundAfter = await foregroundState(harness);', retention_start)
retention = candidate[retention_start:retention_end]
assert 'await ' not in retention
assert 'W13_PROFILE_COMPLETED_ROW' in retention
assert candidate.count('"Browser.getBrowserCommandLine"') == 1
assert candidate.count('await harness.page.bringToFront()') == 1
for unchanged in [
    'test.setTimeout(120_000);',
    'Array.from({ length: sampleCount }, () => 128)',
    'expect([1, 20]).toContain(sampleCount);',
    'transactions.push({ ...transaction, settle: { budget_ms: 0 } });',
    'expect(p95).toBeLessThanOrEqual(1500);',
    'const elapsed = performance.now() - started;',
]:
    assert span(original, test_start, next_test).count(unchanged) == 1
    assert span(candidate, test_start, next_test).count(unchanged) == 1

relative = 'e2e/extension/extension-benchmark.spec.ts'
patch = ''.join(difflib.unified_diff(
    original.splitlines(keepends=True), candidate.splitlines(keepends=True),
    fromfile='a/' + relative, tofile='b/' + relative,
))
assert (BASE / 'foreground-diagnostic.patch').read_text() == patch
manifest = {
    'schema': 'M02_W15_FOREGROUND_PROFILE_SOURCE_PROPOSAL_V1',
    'scope': 'SOURCE_ONLY_PROFILE_DIAGNOSTIC_NOT_ACCEPTANCE',
    'created_at': dt.datetime.now(dt.UTC).isoformat(),
    'frozen_commit': '2464519e0b04de123ef51c3d9cb0363456b5b0eb',
    'frozen_tree': '75660b6a105a2873b0020d3a2d4c24dfb75e15e5',
    'runtime_unchanged': {
        'digest': 'sha256:4f5a9608eb23a80a15a81b4a79494901907c4ad7e5c6a996fbce455b498c77d5',
        'files': 355, 'bytes': 3372811,
    },
    'benchmark_preimage_sha256': sha(BASE / 'preimage.ts'),
    'benchmark_candidate_sha256': sha(BASE / 'candidate.ts'),
    'patch_sha256': sha(BASE / 'foreground-diagnostic.patch'),
    'static_equivalence': {
        'all_changes_inside_existing_W13L': True,
        'original_metrics_and_timed_span_byte_identical': True,
        'timed_span_sha256': hashlib.sha256(timed.encode()).hexdigest(),
        'original_post_timing_assertions_byte_identical': True,
        'original_row_object_byte_identical': True,
        'no_added_await_between_original_row_and_completed_row_log': True,
        'original_sample_threshold_timeout_settle_guards_preserved': True,
        'command_line_CDP_callsite_count': 1,
        'command_line_once_per_test_attempt_guard': True,
        'optional_metadata_unavailable_logged_without_flag_change': True,
        'target_bringToFront_callsite_count': 1,
        'visibility_probes_and_logs_outside_original_interval': True,
    },
    'measurement_sequence': [
        'Original fixtures, counters, CDP version and Performance.enable unchanged',
        'Once: attempt Browser.getBrowserCommandLine via existing target CDP session; AVAILABLE retains actual arguments, UNAVAILABLE retains actual error name/message and arguments:null; mark attempted after either branch',
        'Original target/controller visibilityState, hidden and hasFocus plus active tabs query',
        'Target bringToFront, measure acquisition time outside original timer',
        'Record foreground target/controller/active tabs; assert target visible and not hidden',
        'Original metrics/start/work/elapsed/after metrics and original assertions byte-identical',
        'Synchronously log original completed row immediately after original assertions/rows.push, with no added await before logging',
        'Then probe/log separate postwork page state, assert target visible/not hidden and perform original teardown',
    ],
    'limits': [
        'Diagnostic actively changes target tab posture; it is not canonical acceptance and cannot close KI96 or Gate A.',
        'Original frozen246 canonical timeout remains immutable.',
        'Point visibility readings do not prove uninterrupted visibility or timer scheduling inside work.',
        'Sequential target/controller/tab reads are not an atomic visibility snapshot.',
        'No browser, build, performance or discovery actor has been run for this distinct V3 proposal.',
        'The V2 diagnostic consumed one actor and failed at the optional metadata API before sample work; retained separately as0samples/p95null.',
    ],
    'reference_preimages': [
        {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}
        for path in sorted((BASE / 'reference-preimages').rglob('*')) if path.is_file()
    ],
}
output = BASE / 'source-proposal.json'
assert not output.exists()
output.write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({key: manifest[key] for key in (
    'benchmark_preimage_sha256', 'benchmark_candidate_sha256', 'patch_sha256', 'static_equivalence',
)}, indent=2))
print('Proposal SHA256:', sha(output))
