from pathlib import Path
import datetime as dt
import difflib
import hashlib
import json

BASE = Path('/tmp/japp-m02-w15-native128-canonical-foreground-method-proposal-20261017')
original = (BASE / 'preimage.ts').read_text()
candidate = (BASE / 'candidate.ts').read_text()


def span(value, first, last):
    start = value.index(first)
    return value[start:value.index(last, start)]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


test_start = 'test("W13 L: total scan and re-resolution scaling includes work outside W11"'
next_test = 'test("W13 J: overlapping delayed repeater operations perform one physical click"'
assert original[:original.index(test_start)] == candidate[:candidate.index(test_start)]
assert original[original.index(next_test):] == candidate[candidate.index(next_test):]
timed_first = '    const before = await metrics();'
timed_last = '    expect(outcome.inventory.counts.verified_filled).toBe(count);'
timed = span(original, timed_first, timed_last)
assert timed == span(candidate, timed_first, timed_last)
assert span(original, timed_last, '    rows.push({') == span(candidate, timed_last, '    rows.push({')
old_row = span(original, '    rows.push({', '    await cdp.detach();')
row_start = candidate.index('    rows.push({')
assert candidate[row_start:row_start + len(old_row)] == old_row
retention_start = row_start + len(old_row)
retention_end = candidate.index('    await expectForeground(harness);', retention_start)
retention = candidate[retention_start:retention_end]
assert 'await ' not in retention
assert 'W13_SCALING_COMPLETED_ROW' in retention
assert candidate.count('await harness.page.bringToFront()') == 1
assert candidate.count('await expectForeground(harness);') == 2
assert 'expect(activeTabIds).toEqual([harness.tabId]);' in candidate
assert 'expect(await harness.page.evaluate(() => document.visibilityState)).toBe(' in candidate
assert 'Browser.getBrowserCommandLine' not in candidate
assert 'document.hasFocus' not in candidate
assert 'PROFILE_DIAGNOSTIC' not in candidate
for unchanged in [
    'test.setTimeout(120_000);',
    'Array.from({ length: sampleCount }, () => 128)',
    'expect([1, 20]).toContain(sampleCount);',
    'transactions.push({ ...transaction, settle: { budget_ms: 0 } });',
    'expect(p95).toBeLessThanOrEqual(1500);',
    'const elapsed = performance.now() - started;',
]:
    assert span(original, test_start, next_test).count(unchanged) == 1
    assert span(candidate, test_start, next_test).count(unchanged) == 1
relative = 'e2e/extension/extension-benchmark.spec.ts'
patch = ''.join(difflib.unified_diff(
    original.splitlines(keepends=True), candidate.splitlines(keepends=True),
    fromfile='a/' + relative, tofile='b/' + relative,
))
assert (BASE / 'canonical-foreground-method.patch').read_text() == patch
manifest = {
    'schema': 'M02_W15_CANONICAL_FOREGROUND_MEASUREMENT_SOURCE_PROPOSAL_V1',
    'scope': 'SOURCE_ONLY_EXISTING_W13L_MEASUREMENT_METHOD_CORRECTION',
    'created_at': dt.datetime.now(dt.UTC).isoformat(),
    'frozen_commit': '2464519e0b04de123ef51c3d9cb0363456b5b0eb',
    'frozen_tree': '75660b6a105a2873b0020d3a2d4c24dfb75e15e5',
    'runtime_unchanged': {
        'digest': 'sha256:4f5a9608eb23a80a15a81b4a79494901907c4ad7e5c6a996fbce455b498c77d5',
        'files': 355, 'bytes': 3372811,
    },
    'benchmark_preimage_sha256': sha(BASE / 'preimage.ts'),
    'benchmark_candidate_sha256': sha(BASE / 'candidate.ts'),
    'patch_sha256': sha(BASE / 'canonical-foreground-method.patch'),
    'static_equivalence': {
        'all_changes_inside_existing_W13L': True,
        'every_other_test_byte_identical': True,
        'original_metrics_and_timed_span_byte_identical': True,
        'timed_span_sha256': hashlib.sha256(timed.encode()).hexdigest(),
        'original_post_timing_assertions_byte_identical': True,
        'original_row_object_byte_identical': True,
        'original_sample_threshold_timeout_settle_guards_preserved': True,
        'no_added_await_between_original_row_and_completed_row_log': True,
        'foreground_guards_outside_original_timed_interval': True,
        'target_bringToFront_callsite_count': 1,
        'foreground_active_tab_and_visibility_assertion_calls_per_iteration': 2,
        'runtime_harness_fixture_browser_flags_unchanged': True,
    },
    'method': [
        'Retain original fixtures/counters/CDP version/Performance.enable/metrics helper.',
        'Before original metrics/start: bring target to front, read active Chrome tab IDs, require exactly target ID and visible target document.',
        'Keep original metrics/start/work/elapsed/after metrics, all original assertions and row object unchanged.',
        'Synchronously emit each original completed row before any added await.',
        'After the completed-row log, require active Chrome target tab ID and visible document again, then retain original teardown.',
    ],
    'limits': [
        'This is a declared active-application-tab benchmark method correction, not a runtime optimization or proof of cause.',
        'No browser, build, discovery, performance or test actor has been run for this permanent proposal.',
        'Added foreground guards and completed-row logging consume the unchanged whole-test deadline outside the original sample interval.',
        'Before/after checks are point observations and do not claim uninterrupted foreground through all work.',
        'Canonical246 timeout, V1 source retention gap, V2 failed metadata query and V3 diagnostic-only PASS remain distinct and retained.',
        'Date/background timer/performance root cause remains unproven; V3 DOM visibility/hasFocus never changed, while Chrome active-tab IDs did.',
        'Parent handles integration, validation and Gate A verdict.',
    ],
    'reference_preimages': [
        {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}
        for path in sorted((BASE / 'reference-preimages').rglob('*')) if path.is_file()
    ],
    'history': {'path': str(BASE / 'retained-diagnostic-history.json'),
                'sha256': sha(BASE / 'retained-diagnostic-history.json')},
}
output = BASE / 'source-proposal.json'
assert not output.exists()
output.write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({key: manifest[key] for key in (
    'benchmark_preimage_sha256', 'benchmark_candidate_sha256', 'patch_sha256', 'static_equivalence',
)}, indent=2))
print('Proposal SHA256:', sha(output))
