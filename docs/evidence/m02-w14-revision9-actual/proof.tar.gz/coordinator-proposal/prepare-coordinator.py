"""Outside-only source preparation; does not import or invoke either coordinator."""

import ast
import difflib
import hashlib
import json
from pathlib import Path


OLD = Path('/tmp/japp-w14-r8-coordinator-proposal')
NEW = Path('/tmp/japp-w14-r9-coordinator-proposal')
R9 = Path('/tmp/japp-w14-paired-revision9/proposed/e2e/extension/legacy-paired-options')
RUN = Path('/tmp/japp-w14-r9-730c641-20261016')
EXPECTED_OLD_SHA = 'sha256:1caf0c988d1dcc9435c68414556ffc54d4b7fde8827d3f6d712553e4065993d8'
REPLACEMENTS = {
    '/tmp/japp-w14-r8-fc48930-20261016': str(RUN),
    '/tmp/japp-w14-focus-frozen-20261016': '/tmp/japp-w14-concurrency-frozen-20261016',
    'fc48930fd880795f72972fd97e2e69d68e636855': '730c641a9855fc3e95620636314a28d0eee8439a',
    'cb787f46afec1281c87074a82fd31e23b37c865a': '7402873a081286dbddce5b93ed4db997fea4f24d',
    'sha256:0f22812dc44aa46fda51b78ef666738a924e00e0deaaaff977bc33d82729ab3a': 'sha256:72a68f2929823583c878a20dc8c9b57414f65a5ca59cf21b144c5e1af6466a5a',
    'sha256:8c61ebee8af7823f2812c514fb2bbb5eb0ca44c95b919a5ac3919eb9b5fec9cc': 'sha256:3b6c0e0c0950b03e3bb9e1f12b27bb8d385174c36fb4b68ef3345597aa8b3502',
    'sha256:e0b33901856391d669ad9c15aa49f71e083ee8421f572a8eb9493e9522c0ced9': 'sha256:ae42e5bf466dff2a1df91deec4747fe6af47e73ee44ad49dca3e53453b67e72d',
    'EXACT_CLEAN_COMMITTED_FC_SOURCE_REQUIRED': 'EXACT_CLEAN_COMMITTED_730C641_SOURCE_REQUIRED',
}


def sha(body):
    return 'sha256:' + hashlib.sha256(body).hexdigest()


def put(name, body):
    path = NEW / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(body)


def put_json(name, value):
    put(name, (json.dumps(value, indent=2) + '\n').encode())


if NEW.exists() or NEW.is_symlink() or RUN.exists() or RUN.is_symlink():
    raise SystemExit('FRESH_PROPOSAL_AND_PLANNED_RUN_PATH_REQUIRED')
old_body = (OLD / 'run-revision8.py').read_bytes()
if sha(old_body) != EXPECTED_OLD_SHA:
    raise SystemExit('EXACT_REVIEWED_R8_REVISION2_SOURCE_REQUIRED')
source = old_body.decode()
for before, after in REPLACEMENTS.items():
    if source.count(before) != 1:
        raise SystemExit('EXACT_ONE_SOURCE_REBIND_REQUIRED:' + before)
    source = source.replace(before, after)
new_body = source.encode()
ast.parse(source, filename='run-revision9.py')
reversed_source = source
for before, after in REPLACEMENTS.items():
    reversed_source = reversed_source.replace(after, before)
if reversed_source.encode() != old_body:
    raise SystemExit('SOURCE_REBIND_REVERSAL_FAILED')
NEW.mkdir()
for name in ('run-revision8.py', 'plan.json', 'plan.md'):
    put('history/revision-8-reviewed/' + name, (OLD / name).read_bytes())
put('run-revision9.py', new_body)
put('source-rebinding.diff', ''.join(difflib.unified_diff(old_body.decode().splitlines(True), source.splitlines(True), fromfile='reviewed-r8-revision2/run-revision8.py', tofile='proposed-r9/run-revision9.py')).encode())
old_plan = json.loads((OLD / 'plan.json').read_text())
plan = json.loads((OLD / 'plan.json').read_text())
plan.update({
    'format_version': 'W14_REVISION9_POST_FROZEN_COORDINATOR_PREPARATION_1',
    'script': str(NEW / 'run-revision9.py'),
    'script_sha256': sha(new_body),
    'expected_head': REPLACEMENTS[old_plan['expected_head']],
    'expected_tree': REPLACEMENTS[old_plan['expected_tree']],
    'expected_lock': REPLACEMENTS[old_plan['expected_lock']],
    'expected_runtime': REPLACEMENTS[old_plan['expected_runtime']],
    'runtime_bytes': 3371960,
    'campaign_locked_payload_files': 65,
    'campaign_directory_regular_files': 67,
    'planned_run_directory': str(RUN),
    'planned_candidate_output': str(RUN / 'candidate'),
    'planned_legacy_output': str(RUN / 'legacy'),
    'release_guard': 'Require explicit --execute-after-root-full-pass, exact frozen pnpm verify argv/cwd/730c641/node/target flags/pinned wrapper identity and matching clean before/after plus exit0/tracked neutrality, all before output creation or tools. Root explicit execution release remains required.',
    'full_completion_directory': '/tmp/japp-w14-concurrency-frozen-20261016',
    'intended_invocation': ['/Users/tanishkalwad/jobapplyv2/.venv/bin/python', str(NEW / 'run-revision9.py'), '--execute-after-root-full-pass'],
    'proposal_revision': 1,
    'frozen_wrapper_sha256': REPLACEMENTS[old_plan['frozen_wrapper_sha256']],
})
plan['phases'][0]['behavior'] = 'Require clean730c641/tree7402873, exact72a68lock/3553b6c runtime/31vendor files/13dependencies. Record full tracked inventory and tools before. No install.'
plan['current_source_documents'] = {name: sha((R9 / name).read_bytes()) for name in old_plan['current_source_documents']}
if plan['current_source_documents']['campaign.lock.json'] != plan['expected_lock']:
    raise SystemExit('R9_OUTSIDE_LOCK_BINDING_MISMATCH')
plan.pop('history_revision1')
plan['adapted_from_reviewed_revision8_revision2'] = {
    'directory': str(OLD),
    'script_sha256': EXPECTED_OLD_SHA,
    'independent_source_review': '/tmp/japp-w14-r8-coordinator-independent-review/revision-2',
    'review_source_checks': 29,
    'exact_history_copy': str(NEW / 'history/revision-8-reviewed'),
    'execution_status': 'NEVER_INVOKED_UNEXECUTED_UNRELEASED',
    'reason': 'Matching frozen fc48930 full run failed native128 target performance; no actual coordinator guard refusal was executed.',
    'history_revision1': old_plan['history_revision1'],
}
plan['source_rebinding'] = {
    'constant_literal_changes': 7,
    'diagnostic_literal_changes': 1,
    'other_source_changes': 0,
    'exact_byte_reversal_matches_reviewed_r8_revision2': True,
    'release_and_owned_group_cleanup_logic_unchanged': True,
}
plan['preparation_execution']['syntax_validation'] = 'ast.parse only; neither coordinator imported or invoked; no active frozen artifacts read'
plan['limits'].append('The new frozen full run was active at authoring; no outcome, completion inspection or execution release is claimed.')
put_json('plan.json', plan)
put('plan.md', f'''# Revision 9 paired execution plan — source preparation only

Root full verification on clean `{plan['expected_head']}` / tree `{plan['expected_tree']}` was active when this source was prepared. Neither this coordinator nor its reviewed Revision8 predecessor was imported or invoked. No active frozen artifacts, tool versions, product preflights, builds, tests, browsers or actors were queried or launched. Root remains hard frozen. The planned run directory `{RUN}` and its candidate/legacy directories have not been created by this preparation.

The exact reviewed Revision8 revision2 script `{EXPECTED_OLD_SHA}` and its original plans are copied byte-for-byte to `history/revision-8-reviewed/`. The new script changes only seven fixed literal bindings (OUT, FROZEN, HEAD, TREE, LOCK, RUNTIME and pinned frozen-wrapper SHA) plus one diagnostic label naming the new source. Reversing those eight substitutions recovers the complete old script bytes. All source snapshots, environment sanitization, actor commands/assertions, final evidence capture and bounded owned-process-group TERM10s/KILL5s cleanup logic remain unchanged. The old Revision8 coordinator was never invoked or released because its matching frozen full run failed; this is not an actual guard-refusal observation.

Exact current commitments: Revision9 lock `{plan['expected_lock']}`; runtime355 / 3,371,960 bytes / `{plan['expected_runtime']}`; 65 locked payloads / 67 regular campaign files. The legacy cleanroom remains `/tmp/japp-legacy-cleanroom.ByLBQU` with31 bound vendor sources and its existing Python3.12.13/13 frozen dependencies. Required Node24.18.0/pnpm11.17.0 and all deadlines remain unchanged. No installation is planned.

Before any output creation or tool call, release validation requires explicit `--execute-after-root-full-pass`, the exact full `pnpm verify` argv/cwd/current head/pinned Node/three target flags, pinned frozen-wrapper `{plan['frozen_wrapper_sha256']}`, and the matching clean before/after source/tree/tracked-inventory closure with exit0. It reads every closure record before output creation. The fresh outside path and currently clean committed source must then match. Missing, failed or mismatched records refuse; this source preparation grants no execution release. Root must independently review this exact source and explicitly authorize execution only after the matching full run closes PASS.

The planned invocation, after that separate release, is:

```sh
/Users/tanishkalwad/jobapplyv2/.venv/bin/python {NEW}/run-revision9.py --execute-after-root-full-pass
```

Execution order remains: bind tracked/runtime/vendor/comparison/tool/invocation state; production `loadCampaign`; a fresh default extension build with inherited public/performance/paired flags and `TEST_WORKER_INDEX` stripped; inventory build before actors; dedicated one-worker/zero-retry discovery of four declared titles; candidate4 normal passes and four fresh raw artifacts; legacy4 under its unchanged owned18886 launcher with complete raw control/lifecycle records; offline four-case/forty-field join under the new lock; production postflight and exact final source/build/tool inventories. Raw stdout/stderr, command/start/end/timeout/exit records, unexpected-native arrays, errors and partial output must be retained. No expected metric is inherited from Revision7 or Revision8.

Outer bounds remain build300s, discovery60s, candidate360s, legacy240s, join60s, source pre/postflight60s and each tool/git30s. Abort cleanup checks the entire owned group independently of direct-leader exit, then bounded TERM10s/KILL5s; outside-group OS descendants remain UNOBSERVED. Normal cleanup scope is limited to the unchanged passed fixture/raw legacy records, not a per-case OS descendant certificate. An occupied unknown18886 service is refused without contacting or terminating its owner. These are coordinator bounds, with no production assertion, threshold or budget change.

Historical Revision7 command-record references and all four immutable input/oracle case declarations are preserved in `plan.json`; current source-document hashes come from the exact reviewed outside Revision9 afterimages. The active root/full artifacts were not inspected to infer outcomes. Syntax checking used `ast.parse` only, and exact reversed bytes were checked without importing the coordinator. Current full outcome, actual comparison metrics, phone equivalence, tool/build/lifecycle stability and cleanup require fresh independent inspection after authorized execution. Public/Simplify, formal W15, owner GateA, whole-product parity and timing-win claims remain unavailable.

Coordinator SHA: `{sha(new_body)}`.
'''.encode())
put('README.md', b'''This is an outside-only, unexecuted Revision9 coordinator proposal. Read plan.md and plan.json before any use. Root review and explicit release after the matching frozen full PASS are required. The active root checkout is hard frozen; preparation imports or invokes neither coordinator and creates no planned actor/run directory. source-rebinding.diff and history/revision-8-reviewed retain the exact reviewed Revision8 revision2 predecessor, which was never invoked. No actor outcome or guard-refusal observation is inherited. payload-manifest.json closes every proposal payload except its own self-referential bytes; it is not an execution or gate approval.
''')
put('prepare-coordinator.py', Path(__file__).read_bytes())
payloads = []
for path in sorted(NEW.rglob('*')):
    if path.is_symlink():
        raise SystemExit('PROPOSAL_SYMLINK_REFUSED')
    if path.is_file():
        body = path.read_bytes()
        payloads.append({'path': path.relative_to(NEW).as_posix(), 'bytes': len(body), 'sha256': sha(body)})
put_json('payload-manifest.json', {'format_version': 'W14_R9_COORDINATOR_SOURCE_PAYLOADS_1', 'authority': 'NONE', 'status': 'SOURCE_ONLY_NOT_EXECUTED_PENDING_INDEPENDENT_REVIEW', 'self_excluded': 'payload-manifest.json', 'files': payloads})
print(json.dumps({'proposal': str(NEW), 'script_sha256': sha(new_body), 'diff_sha256': sha((NEW / 'source-rebinding.diff').read_bytes()), 'manifest_sha256': sha((NEW / 'payload-manifest.json').read_bytes()), 'payload_files': len(payloads), 'total_regular_files': len(payloads) + 1, 'planned_run_directory_created': RUN.exists(), 'coordinator_imported_or_invoked': False}, indent=2))
