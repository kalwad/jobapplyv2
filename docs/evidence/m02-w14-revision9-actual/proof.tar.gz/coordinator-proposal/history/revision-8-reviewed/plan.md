# Revision 8 paired execution plan — prepared only

The coordinator is source-only and has not been invoked, imported or preflighted. No tool version query, test, build, actor, browser, root write or candidate/legacy output-directory creation occurred during preparation. Root full verification was active when this was prepared. Root must review this exact source and explicitly release execution after its frozen run closes successfully.

Exact commitments: clean `fc48930fd880795f72972fd97e2e69d68e636855`, tree `cb787f46afec1281c87074a82fd31e23b37c865a`; revision8 lock `sha256:0f22812dc44aa46fda51b78ef666738a924e00e0deaaaff977bc33d82729ab3a`; runtime355 / `sha256:8c61ebee8af7823f2812c514fb2bbb5eb0ca44c95b919a5ac3919eb9b5fec9cc`. The unchanged legacy cleanroom is `/tmp/japp-legacy-cleanroom.ByLBQU`, with31 bound vendor sources and existing Python3.12.13/13 frozen dependencies. Node24.18.0 and pnpm11.17.0 are required; nothing is installed.

Planned output: `/tmp/japp-w14-r8-fc48930-20261016`, with fresh `candidate` and `legacy` subdirectories. The coordinator itself creates neither actor directory; each unchanged actor owns its own fresh output. The whole run directory must be absent. Discovery has a separate fresh output path. No runbook result, pass, timing or unexpected-native count is inherited from revision7.

The release guard first requires the exact `pnpm verify` command argv/cwd/fc head/pinned Node path/three target flags and frozen wrapper SHA, plus its `completion.json` exit0, matching clean before/after head/tree, all tracked bytes unchanged and clean endpoints. Every release record is read and validated before output creation; missing or mismatched provenance refuses without creating output. It then requires a current clean committed fc source and fresh outside output before creating any run output or running a preflight. The explicit execution flag is mandatory. This guard is not permission to launch now.

After root review and release, the exact invocation is:

```sh
/Users/tanishkalwad/jobapplyv2/.venv/bin/python /tmp/japp-w14-r8-coordinator-proposal/run-revision8.py --execute-after-root-full-pass
```

Execution order:

1. Record all tracked bytes, runtime/vendor/comparison inventories, actual tool binaries/versions and invocation/environment commitments. Run the unchanged production `loadCampaign` for exact59-file lock/runtime/input/vendor checks, only after release.
2. Freshly run default `pnpm --filter @japp/extension build` with every inherited public-mode flag removed. Preserve exact stdout/stderr and build invocation; inventory actual output before actors. Root ignored build outputs may change only during this explicitly released phase.
3. Discover exactly the four frozen fixture titles through the dedicated immutable configuration; preserve raw JSON. Discovery's four skipped listing symbols represent no execution. Require one worker and zero retries.
4. Run actual candidate4 with fresh output and JSON reporter. Require four normal passes, no skipped/flaky cases and four raw case artifacts. The actor's original60-second case bounds, source/control assertions and observations remain unchanged.
5. Run actual legacy4 using the unchanged owned launcher/runtime. Preserve `.control.json`, `.server.log`, raw result and all launcher stdout/stderr. Its original15-second startup,180-second browser and5-second direct-child stop bounds remain unchanged; an occupied18886 service causes refusal without contacting or terminating the unknown owner.
6. Run the existing offline join against these exact fresh artifacts, requiring four cases/forty fields under the new lock. Preserve exact worksheet bytes and all unexpected native mutation arrays. Actual metrics and phone digits equivalence must be independently audited; no earlier metric is an expected result.
7. Repeat production source validation and record end source/build/tool inventories. Missing evidence, drift, timeout, child failure or incomplete final capture produces a failed completion record and never an accepted comparison.

Outer operation deadlines are build300s, discovery60s, candidate360s, legacy240s, compare60s, source pre/postflight60s each, and each tool/git subprocess30s. These are coordinator bounds, not product threshold changes. Timeout/interrupt cleanup signals only the coordinator's own new process group, checks that group through bounded TERM10s/KILL5s waits even if the direct leader exits, retains raw logs/signals/remaining-group state and stops subsequent actors. Normal candidate context/profile cleanup is inferred only from the passed existing fixture, with no per-case OS descendant certificate. Legacy direct-child/context/profile cleanup is reported only from raw normal-success records; browser OS descendants remain UNOBSERVED. Abnormal wrapper termination never proves normal cleanup.

Every stage records exact argv, cwd, selected declared task environment, start/end/timeouts, raw stdout/stderr SHA/bytes and exit status. Public-prefix and inherited paired/performance flags plus `TEST_WORKER_INDEX` are removed; only the reviewed lock, explicit opt-in and phase paths are supplied. Unrelated environment secrets are never serialized. Full-verification closure records and the coordinator source/invocation are hash-bound. Tool/version/binary/dependency records are captured before and after; build bytes are compared after fresh compilation through actor completion.

I read the current PREEXECUTION runbook, prior revision7 actual candidate argv/discovery record and legacy lifecycle record to preserve their control and provenance scope. This plan does not copy any actor result into the new run.

Coordinator SHA: `sha256:1caf0c988d1dcc9435c68414556ffc54d4b7fde8827d3f6d712553e4065993d8`.

`plan.json` binds the commands, declarations, source documents, historical command records and scope. Syntax was checked by `ast.parse` only. Actual independent source review and root release are still required. This work grants no formal W15/Gate A decision or public/Simplify/whole-product/timing verdict.

The exact first proposal remains under `history/revision-1/`. Peer source review found the abort leader-exit shortcut and unvalidated frozen command identity before output creation; revision2 corrects both without claiming execution. The new source requires separate review.
