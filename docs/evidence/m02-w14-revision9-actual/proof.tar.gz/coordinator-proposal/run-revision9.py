"""Explicit post-freeze coordinator; preparation/import never runs a campaign."""

from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import signal
import stat
import subprocess
import sys
import time


ROOT = Path('/Users/tanishkalwad/jobapplyv2')
LEGACY = Path('/tmp/japp-legacy-cleanroom.ByLBQU')
OUT = Path('/tmp/japp-w14-r9-730c641-20261016')
FROZEN = Path('/tmp/japp-w14-concurrency-frozen-20261016')
HERE = ROOT / 'e2e/extension/legacy-paired-options'
DIST = ROOT / 'apps/extension/dist/chrome-mv3'
NODE = Path('/opt/homebrew/opt/node@24/bin/node')
PYTHON = LEGACY / 'evaluation-runtime/bin/python'
HEAD = '730c641a9855fc3e95620636314a28d0eee8439a'
TREE = '7402873a081286dbddce5b93ed4db997fea4f24d'
LOCK = 'sha256:72a68f2929823583c878a20dc8c9b57414f65a5ca59cf21b144c5e1af6466a5a'
RUNTIME = 'sha256:3b6c0e0c0950b03e3bb9e1f12b27bb8d385174c36fb4b68ef3345597aa8b3502'
FROZEN_WRAPPER_SHA = 'sha256:ae42e5bf466dff2a1df91deec4747fe6af47e73ee44ad49dca3e53453b67e72d'


def sha(body):
    return 'sha256:' + hashlib.sha256(body).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()


def read(path):
    return json.loads(path.read_text())


def write(name, value):
    path = OUT / name
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, timeout=30).decode().strip()


def files(directory):
    result = []
    for path in sorted(directory.rglob('*')):
        if path.is_symlink():
            raise RuntimeError('INVENTORY_SYMLINK_REFUSED:' + str(path))
        if path.is_dir():
            continue
        if not stat.S_ISREG(path.lstat().st_mode):
            raise RuntimeError('INVENTORY_NONREGULAR_REFUSED:' + str(path))
        body = path.read_bytes()
        result.append({'path': path.relative_to(directory).as_posix(), 'bytes': len(body), 'sha256': sha(body)})
    return result


def snapshot(include_build):
    tracked = []
    for name in subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT, timeout=30).decode().split('\0'):
        if not name:
            continue
        path = ROOT / name
        if path.is_symlink() or not stat.S_ISREG(path.lstat().st_mode):
            raise RuntimeError('TRACKED_REGULAR_SOURCE_REQUIRED:' + name)
        body = path.read_bytes()
        tracked.append({'path': name, 'bytes': len(body), 'sha256': sha(body)})
    bindings = read(HERE / 'source-bindings.json')
    runtime = [{'path': row['path'], 'sha256': sha((ROOT / row['path']).read_bytes())} for row in bindings['candidate_runtime_sources']]
    vendor = [{'path': row['path'], 'sha256': sha((LEGACY / row['path']).read_bytes())} for row in bindings['legacy_sources']]
    if len(runtime) != 355 or sha(canonical(runtime)) != RUNTIME or runtime != bindings['candidate_runtime_sources']:
        raise RuntimeError('CURRENT_RUNTIME_BINDING_DRIFT')
    if len(vendor) != 31 or vendor != bindings['legacy_sources']:
        raise RuntimeError('LEGACY_VENDOR_BINDING_DRIFT')
    if sha((HERE / 'campaign.lock.json').read_bytes()) != LOCK:
        raise RuntimeError('LOCK_DRIFT')
    return {'captured_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'status': git('status', '--porcelain=v1', '--untracked-files=normal'), 'tracked_files': tracked, 'tracked_inventory_digest': sha(canonical(tracked)), 'runtime_sources': runtime, 'runtime_digest': sha(canonical(runtime)), 'vendor_sources': vendor, 'comparison_sources': files(HERE), 'build_files': files(DIST) if include_build else None}


def clean_exact(value):
    return value['head'] == HEAD and value['tree'] == TREE and value['status'] == ''


def sanitized_environment():
    env = os.environ.copy()
    stripped = []
    for key in list(env):
        if key == 'TEST_WORKER_INDEX' or key.startswith(('JAPP_W14_PUBLIC', 'JAPP_W14_PAIRED', 'JAPP_W13_')) or key in {'JAPP_W14_ARTIFACT_DIRECTORY', 'JAPP_W14_REQUIRE_TARGET_PERFORMANCE', 'PLAYWRIGHT_JSON_OUTPUT_NAME', 'PLAYWRIGHT_JSON_OUTPUT_FILE', 'PLAYWRIGHT_JSON_OUTPUT_DIR'}:
            stripped.append(key)
            del env[key]
    env['PATH'] = str(NODE.parent) + os.pathsep + env.get('PATH', '')
    env.update(JAPP_W14_PAIRED_EXPECTED_LOCK=LOCK, JAPP_W14_PAIRED_OPTIONS_EVALUATION='1')
    return env, sorted(stripped)


def run_stage(name, argv, env, timeout, stage_env=None):
    actual = env.copy()
    actual.update(stage_env or {})
    # The coordinator never supplies a worker index; Playwright alone owns it.
    actual.pop('TEST_WORKER_INDEX', None)
    log = OUT / (name + '.log')
    stderr_log = OUT / (name + '.stderr.log')
    record = {'stage': name, 'argv': argv, 'cwd': str(ROOT), 'timeout_seconds': timeout, 'task_environment': {k: v for k, v in actual.items() if k.startswith('JAPP_W14_PAIRED_') or k.startswith('PLAYWRIGHT_JSON_')}, 'worker_index_supplied': False, 'started_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'signals': [], 'cleanup_scope': 'OWNED_COORDINATOR_CHILD_PROCESS_GROUP_ONLY', 'os_descendants_outside_owned_group': 'UNOBSERVED'}
    started = time.monotonic()
    with log.open('xb') as stream, stderr_log.open('xb') as error_stream:
        child = subprocess.Popen(argv, cwd=ROOT, env=actual, stdout=stream, stderr=error_stream, start_new_session=True)
        record['pid'] = child.pid
        try:
            record['exit_code'] = child.wait(timeout=timeout)
            record['timed_out'] = False
        except BaseException as failure:
            record['timed_out'] = isinstance(failure, subprocess.TimeoutExpired)
            record['wait_error'] = {'type': type(failure).__name__, 'message': str(failure)[:500]}
            def owned_group_alive():
                child.poll()  # Reap the direct leader without assuming the group ended.
                try:
                    os.killpg(child.pid, 0)
                    return True
                except ProcessLookupError:
                    return False

            for sig, grace in [(signal.SIGTERM, 10), (signal.SIGKILL, 5)]:
                if not owned_group_alive():
                    break
                try:
                    os.killpg(child.pid, sig)
                    record['signals'].append(sig.name)
                except ProcessLookupError:
                    break
                deadline = time.monotonic() + grace
                while time.monotonic() < deadline and owned_group_alive():
                    time.sleep(0.05)
            record['exit_code'] = child.poll()
            record['owned_group_after_abort'] = 'STILL_PRESENT' if owned_group_alive() else 'GONE'
    record['ended_at'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    record['duration_seconds'] = time.monotonic() - started
    record['log_sha256'] = sha(log.read_bytes())
    record['log_bytes'] = log.stat().st_size
    record['stderr_sha256'] = sha(stderr_log.read_bytes())
    record['stderr_bytes'] = stderr_log.stat().st_size
    write(name + '.command.json', record)
    if record['timed_out'] or 'wait_error' in record or record['exit_code'] != 0:
        raise RuntimeError('STAGE_FAILED:' + name)
    return log.read_bytes()


def capture_tools(env, pnpm, suffix):
    node = run_stage('node-version-' + suffix, [str(NODE), '--version'], env, 30).decode().strip()
    package = run_stage('pnpm-version-' + suffix, [pnpm, '--version'], env, 30).decode().strip()
    code = "import importlib.metadata as m,json,sys; print(json.dumps({'python':sys.version,'executable':sys.executable,'dependencies':sorted(d.metadata['Name'].lower().replace('_','-')+'=='+d.version for d in m.distributions())},sort_keys=True))"
    python = json.loads(run_stage('legacy-python-' + suffix, [str(PYTHON), '-c', code], env, 30))
    frozen = sorted((HERE / 'preimages/evaluation-runtime.freeze.txt').read_text().splitlines())
    if node != 'v24.18.0' or package != '11.17.0' or not python['python'].startswith('3.12.13 ') or python['dependencies'] != frozen or len(frozen) != 13:
        raise RuntimeError('PINNED_TOOL_OR_PYTHON_DEPENDENCY_DRIFT')
    return {'coordinator_python': {'version': sys.version, 'executable': sys.executable, 'binary_sha256': sha(Path(sys.executable).read_bytes())}, 'node_version': node, 'node_path': str(NODE), 'node_realpath': str(NODE.resolve()), 'node_binary_sha256': sha(NODE.read_bytes()), 'pnpm_version': package, 'pnpm_path': pnpm, 'pnpm_realpath': str(Path(pnpm).resolve()), 'pnpm_binary_sha256': sha(Path(pnpm).read_bytes()), 'legacy_python': python, 'legacy_python_binary_sha256': sha(PYTHON.read_bytes())}


def specs(report):
    def walk(suites):
        for suite in suites:
            yield from suite.get('specs', [])
            yield from walk(suite.get('suites', []))
    return list(walk(report.get('suites', [])))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute-after-root-full-pass', action='store_true', required=True)
    args = parser.parse_args()
    if not args.execute_after_root_full_pass:
        raise RuntimeError('EXPLICIT_ROOT_RELEASE_REQUIRED')
    # Validate every release record before any run-output creation or tool call.
    completion_bytes = (FROZEN / 'completion.json').read_bytes()
    completion = json.loads(completion_bytes)
    command_bytes = (FROZEN / 'command.json').read_bytes()
    command = json.loads(command_bytes)
    opened_bytes = (FROZEN / 'before.json').read_bytes()
    closed_bytes = (FROZEN / 'after.json').read_bytes()
    opened = json.loads(opened_bytes)
    closed = json.loads(closed_bytes)
    target_flags = {'JAPP_W13_PERFORMANCE_SAMPLES': '20', 'JAPP_W14_REQUIRE_TARGET_PERFORMANCE': '1', 'JAPP_W14_ARTIFACT_DIRECTORY': str(FROZEN / 'w14')}
    if command.get('argv') != ['pnpm', 'verify'] or command.get('cwd') != str(ROOT) or command.get('expected_head') != HEAD or command.get('node_path') != str(NODE) or command.get('task_environment') != target_flags or command.get('wrapper_sha256') != FROZEN_WRAPPER_SHA.removeprefix('sha256:') or sha((FROZEN / 'run-frozen.py').read_bytes()) != FROZEN_WRAPPER_SHA or command.get('started_at') != opened.get('captured_at'):
        raise RuntimeError('EXACT_FROZEN_FULL_COMMAND_IDENTITY_REQUIRED')
    if completion.get('exit_code') != 0 or completion.get('head_unchanged') is not True or completion.get('tracked_inventory_unchanged') is not True or completion.get('status_before') != '' or completion.get('status_after') != '' or not clean_exact(opened) or not clean_exact(closed) or opened.get('tracked_files') != closed.get('tracked_files') or opened.get('tracked_inventory_digest') != closed.get('tracked_inventory_digest') or completion.get('ended_at') != closed.get('captured_at'):
        raise RuntimeError('EXACT_FROZEN_FULL_PASS_COMPLETION_REQUIRED')
    if OUT.exists() or OUT.is_symlink() or ROOT in OUT.parents or not OUT.is_absolute():
        raise RuntimeError('FRESH_OUTSIDE_RUN_DIRECTORY_REQUIRED')
    before = snapshot(False)
    if not clean_exact(before):
        raise RuntimeError('EXACT_CLEAN_COMMITTED_730C641_SOURCE_REQUIRED')
    env, stripped = sanitized_environment()
    pnpm = shutil.which('pnpm', path=env['PATH'])
    if pnpm is None:
        raise RuntimeError('PINNED_PNPM_MISSING')
    OUT.mkdir()
    write('before.json', before)
    write('coordinator.json', {'authority': 'NONE', 'script_sha256': sha(Path(__file__).read_bytes()), 'argv': [sys.executable, *sys.argv], 'invocation_cwd': str(Path.cwd()), 'expected_head': HEAD, 'expected_tree': TREE, 'expected_lock': LOCK, 'expected_runtime': RUNTIME, 'prior_full_completion_sha256': sha(completion_bytes), 'prior_full_before_snapshot_sha256': sha(opened_bytes), 'prior_full_after_snapshot_sha256': sha(closed_bytes), 'prior_full_command_sha256': sha(command_bytes), 'removed_environment_variable_names_only': stripped, 'outcomes_inherited': False, 'candidate_output': str(OUT / 'candidate'), 'legacy_output': str(OUT / 'legacy')})
    before_tools = None
    before_actors = None
    success = False
    error = None
    try:
        before_tools = capture_tools(env, pnpm, 'before')
        write('tools-before.json', before_tools)
        preflight = "import {loadCampaign} from './e2e/extension/legacy-paired-options/campaign.mjs';const c=loadCampaign({candidateRoot:" + json.dumps(str(ROOT)) + ",legacyRoot:" + json.dumps(str(LEGACY)) + "});process.stdout.write(JSON.stringify({lock:c.lock_digest,cases:c.inputs.length})+'\\n');"
        run_stage('source-preflight', [str(NODE), '--input-type=module', '-e', preflight], env, 60)
        run_stage('default-build', [pnpm, '--filter', '@japp/extension', 'build'], env, 300)
        before_actors = snapshot(True)
        write('before-actors.json', before_actors)
        if not clean_exact(before_actors) or before_actors['tracked_inventory_digest'] != before['tracked_inventory_digest']:
            raise RuntimeError('SOURCE_CHANGED_DURING_FRESH_BUILD')
        cli = [str(NODE), str(ROOT / 'node_modules/@playwright/test/cli.js'), 'test', '--config', 'e2e/extension/legacy-paired-options/playwright.config.ts']
        discovery_bytes = run_stage('discovery', cli + ['--list', '--reporter=json'], env, 60, {'JAPP_W14_PAIRED_OPTIONS_OUTPUT': str(OUT / 'discovery')})
        with (OUT / 'discovery.json').open('xb') as stream:
            stream.write(discovery_bytes)
        discovery = json.loads(discovery_bytes)
        bindings = read(HERE / 'source-bindings.json')
        expected_titles = ['paired explicit approved options: ' + row['fixture_id'] for row in bindings['cases']]
        declared_specs = specs(discovery)
        if discovery.get('errors') or [row['title'] for row in declared_specs] != expected_titles or len(declared_specs) != 4 or discovery['config']['workers'] != 1 or any(project['retries'] != 0 for project in discovery['config']['projects']):
            raise RuntimeError('EXACT_FOUR_DISCOVERY_REQUIRED')
        run_stage('candidate', cli + ['--reporter=list,json'], env, 360, {'JAPP_W14_PAIRED_OPTIONS_OUTPUT': str(OUT / 'candidate'), 'PLAYWRIGHT_JSON_OUTPUT_NAME': str(OUT / 'candidate-report.json')})
        candidate_report = read(OUT / 'candidate-report.json')
        if candidate_report.get('errors') or any(candidate_report['stats'][key] != value for key, value in {'expected': 4, 'unexpected': 0, 'skipped': 0, 'flaky': 0}.items()):
            raise RuntimeError('EXACT_FOUR_NORMAL_CANDIDATE_PASSES_REQUIRED')
        candidates = list((OUT / 'candidate').rglob('paired-options-candidate.json'))
        expected_ids = {row['case_id'] for row in bindings['cases']}
        if len(candidates) != 4 or {read(path)['case_id'] for path in candidates} != expected_ids:
            raise RuntimeError('FOUR_CANDIDATE_RAW_ARTIFACTS_REQUIRED')
        run_stage('legacy-launch', [str(NODE), str(HERE / 'run-legacy.mjs')], env, 240, {'JAPP_W14_PAIRED_CANDIDATE_ROOT': str(ROOT), 'JAPP_W14_PAIRED_LEGACY_ROOT': str(LEGACY), 'JAPP_W14_PAIRED_PYTHON': str(PYTHON), 'JAPP_W14_PAIRED_PLAYWRIGHT_MODULE': str(ROOT / 'node_modules/@playwright/test/index.mjs'), 'JAPP_W14_PAIRED_LEGACY_OUTPUT': str(OUT / 'legacy')})
        legacy = read(OUT / 'legacy/paired-options-legacy.json')
        control = read(OUT / 'legacy.control.json')
        if legacy.get('complete') is not True or legacy.get('source_stability') is not True or len(legacy.get('results', [])) != 4 or control.get('complete') is not True or control.get('campaign_lock_digest') != LOCK:
            raise RuntimeError('FRESH_COMPLETE_LEGACY_FOUR_REQUIRED')
        run_stage('offline-compare', [str(NODE), str(HERE / 'compare-paired.mjs'), str(OUT / 'candidate'), str(OUT / 'legacy/paired-options-legacy.json'), str(OUT / 'paired-comparison.json')], env, 60)
        worksheet = read(OUT / 'paired-comparison.json')
        if worksheet.get('campaign_lock_digest') != LOCK or len(worksheet.get('cases', [])) != 4 or sum(len(row['fields']) for row in worksheet['cases']) != 40:
            raise RuntimeError('EXACT_NEW_FOUR_CASE_FORTY_FIELD_JOIN_REQUIRED')
        run_stage('source-postflight', [str(NODE), '--input-type=module', '-e', preflight], env, 60)
        success = True
    except BaseException as failure:
        error = {'type': type(failure).__name__, 'message': str(failure)[:1000]}
    finally:
        after = None
        after_tools = None
        evidence_errors = []
        try:
            after = snapshot(before_actors is not None)
            write('after.json', after)
        except BaseException as failure:
            evidence_errors.append({'scope': 'after_snapshot', 'type': type(failure).__name__, 'message': str(failure)[:1000]})
        try:
            after_tools = capture_tools(env, pnpm, 'after')
            write('tools-after.json', after_tools)
        except BaseException as failure:
            evidence_errors.append({'scope': 'after_tools', 'type': type(failure).__name__, 'message': str(failure)[:1000]})
        checks = {'clean_exact_head_tree': clean_exact(after) if after is not None else False, 'all_tracked_bytes_unchanged': before['tracked_inventory_digest'] == after['tracked_inventory_digest'] if after is not None else False, 'runtime_unchanged': before['runtime_sources'] == after['runtime_sources'] if after is not None else False, 'vendor_unchanged': before['vendor_sources'] == after['vendor_sources'] if after is not None else False, 'comparison_sources_unchanged': before['comparison_sources'] == after['comparison_sources'] if after is not None else False, 'tools_unchanged': before_tools == after_tools if before_tools is not None and after_tools is not None else False, 'fresh_build_unchanged_through_actors': before_actors['build_files'] == after['build_files'] if before_actors is not None and after is not None else False}
        write('completion.json', {'authority': 'NONE', 'pipeline_exit_success': success and not evidence_errors and all(checks.values()), 'error': error, 'evidence_errors': evidence_errors, 'checks': checks, 'outcomes_inherited': False, 'gate_pass': False, 'candidate_cleanup_scope': 'Normal fixture context.close/profile removal awaited by passing tests; no per-case OS descendant certificate.', 'legacy_cleanup_scope': 'Use raw legacy.control.json and legacy artifact normal context/profile records; OS browser descendants UNOBSERVED.', 'actual_metrics': 'REQUIRE_READ_ONLY_AUDIT_OF_NEW_RAW_WORKSHEET_INCLUDING_UNEXPECTED_NATIVE_ARRAYS', 'ended_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())})
    return 0 if success and not evidence_errors and all(checks.values()) else 1


if __name__ == '__main__':
    raise SystemExit(main())
