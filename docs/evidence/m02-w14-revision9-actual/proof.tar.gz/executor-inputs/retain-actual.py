"""Retain closed Revision9 evidence only; no product invocation or mutation."""

import json
import runpy
from pathlib import Path


m = runpy.run_path('/tmp/japp-w14-retain-fc-closure.py')
raw = Path('/tmp/japp-w14-r9-730c641-20261016')
audit = Path('/tmp/japp-w14-r9-actual-independent-audit')
proposal = Path('/tmp/japp-w14-r9-coordinator-proposal')
source_peer = Path('/tmp/japp-w14-r9-coordinator-independent-review')
inputs = Path('/tmp/japp-w14-r9-actual-retention-inputs')
if len(m['source_files'](raw)) != 62 or len(m['source_files'](audit)) != 21:
    raise RuntimeError('EXPECTED_CLOSED_MEMBER_COUNTS_REQUIRED')
if m['sha']((audit / 'audit-member-manifest.json').read_bytes()) != 'bbb3e30e0a5b2bfebc9d432c2153d3a8a8f42f9b1438eacd475b4fd818c7c8b7' or m['sha']((audit / 'report.md').read_bytes()) != '82ebca074b6e24b7ae78e938c1b2772bedbf6c574f0ba84f46b4e9f78ac17232':
    raise RuntimeError('EXACT_SEALED_R9_ACTUAL_AUDIT_REQUIRED')
if m['sha']((proposal / 'run-revision9.py').read_bytes()) != '4406859859e32fd5b22e449970dc4419abbfb5cabb76eb826f8dd2223a4bd42b':
    raise RuntimeError('EXACT_REVIEWED_EXECUTED_R9_COORDINATOR_REQUIRED')
c = json.loads((raw / 'completion.json').read_text())
if c['pipeline_exit_success'] is not True or not all(c['checks'].values()) or c['error'] is not None or c['evidence_errors']:
    raise RuntimeError('CLOSED_SUCCESSFUL_R9_NEUTRALITY_REQUIRED')
scope = ('Actual fresh Revision9 candidate4/legacy4/offlinejoin40 at clean730c641a9855fc3e95620636314a28d0eee8439a/tree7402873a081286dbddce5b93ed4db997fea4f24d under lock72a68f2929823583c878a20dc8c9b57414f65a5ca59cf21b144c5e1af6466a5a/runtime355sha256:3b6c0e0c0950b03e3bb9e1f12b27bb8d385174c36fb4b68ef3345597aa8b3502. '
         'Exact reviewed coordinator44068598 invoked ONCE after matching frozen full19PASS and explicit rootrelease, exit0/closed23:43:00Z/all7neutralitychecks true; all62originalrawstages/artifacts retained. '
         'Candidate40/40exact vslegacy28/40; separate exact-or-ASCII-phone-digits40/40vs32/40. Unexpected nativecandidate0/legacy4 country-code ACTIVATIONs; nonordinaryfinal/navigation/submission0both. '
         'Same immutableinputs/oracles/projections/observer31vendor/source/build/tool/lifecycle scopes independently reconciled. Sealed corrected200/200 actualaudit retains original199/200 reviewer-alias expectation, exact correction and attempts, no product rerun/raw rewrites. '
         'Preserve unexecuted R8R2 predecessor history/sourcepeer32/wrapper source and explicitly DERIVED executor records. Normal owned contexts/profiles/directchildren only; OS browser/outsidegroup descendants UNOBSERVED. '
         'No timing superiority/public/Simplify/broadproductparity/nativeCIaggregate/formalW15/ownerGateA approval or inherited outcome.')
result = m['retain'](Path('/tmp/japp-w14-revision9-actual-retained'), [('actual-run', raw), ('coordinator-proposal', proposal), ('coordinator-source-review', source_peer), ('independent-actual-audit', audit), ('executor-inputs', inputs)], scope)
print(json.dumps(result, indent=2))
