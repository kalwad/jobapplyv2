"""Independent, read-only raw audit. Imports no project code; launches no actor."""
from pathlib import Path
import hashlib
import json
import re
import sys

P = Path('/tmp/japp-w14-r9-730c641-20261016')
C = Path('/tmp/japp-w14-paired-revision9/proposed/e2e/extension/legacy-paired-options')
F = Path('/tmp/japp-w14-concurrency-frozen-20261016')
A = Path('/tmp/japp-w14-730-full-independent-audit')
O = Path(__file__).parent
HEAD = '730c641a9855fc3e95620636314a28d0eee8439a'
TREE = '7402873a081286dbddce5b93ed4db997fea4f24d'
LOCK = 'sha256:72a68f2929823583c878a20dc8c9b57414f65a5ca59cf21b144c5e1af6466a5a'
RUNTIME = 'sha256:3b6c0e0c0950b03e3bb9e1f12b27bb8d385174c36fb4b68ef3345597aa8b3502'
MUTATIONS = {'INPUT_VALUE', 'TEXTAREA_VALUE', 'SELECT_VALUE', 'INPUT_CHECKED', 'INPUT_FILES', 'SELECT_INDEX', 'ACTIVATION'}
checks = []
field_rows = []
case_rows = []

def sha(b):
    return 'sha256:' + hashlib.sha256(b).hexdigest()

def canonical(x):
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()

def csha(x):
    return sha(canonical(x))

def data(p):
    if p.is_symlink() or not p.is_file():
        raise ValueError('SAFE_REGULAR_FILE_REQUIRED:' + str(p))
    return p.read_bytes()

def read(p):
    return json.loads(data(p))

def check(name, passed, observed=None):
    checks.append({'name': name, 'passed': passed is True, 'observed': observed})

def inventory(p):
    result = []
    for f in sorted(p.rglob('*')):
        if f.is_symlink():
            raise ValueError('SYMLINK_REFUSED:' + str(f))
        if f.is_file():
            b = data(f)
            result.append({'path': f.relative_to(p).as_posix(), 'bytes': len(b), 'sha256': sha(b)})
        elif not f.is_dir():
            raise ValueError('NONREGULAR_REFUSED:' + str(f))
    return result

def specs(report):
    def walk(rows):
        for row in rows:
            yield from row.get('specs', [])
            yield from walk(row.get('suites', []))
    return list(walk(report.get('suites', [])))

initial_inventory = inventory(P)
before, actors, after = [read(P / n) for n in ['before.json', 'before-actors.json', 'after.json']]
coordinator, completion = read(P / 'coordinator.json'), read(P / 'completion.json')
bindings, lock = read(C / 'source-bindings.json'), read(C / 'campaign.lock.json')
inputs, oracles, projections = [read(C / n) for n in ['paired-inputs.json', 'paired-oracles.json', 'legacy-projections.json']]
worksheet, legacy, control = [read(P / n) for n in ['paired-comparison.json', 'legacy/paired-options-legacy.json', 'legacy.control.json']]
full_summary = read(A / 'summary.json')
check('sealed_independent_full79_pass_before_release', full_summary['checks_passed'] == 79 and full_summary['verification_exit_code'] == 0 and sha(data(A / 'audit-member-manifest.json')) == 'sha256:c991cf72894e62b96b88d11664d330dd9c2268d805caecd3a14329aa3d32da7f')
check('reviewed_exact_coordinator_invocation', coordinator['script_sha256'] == sha(data(Path('/tmp/japp-w14-r9-coordinator-proposal/run-revision9.py'))) == 'sha256:4406859859e32fd5b22e449970dc4419abbfb5cabb76eb826f8dd2223a4bd42b' and coordinator['argv'] == ['/Users/tanishkalwad/jobapplyv2/.venv/bin/python', '/tmp/japp-w14-r9-coordinator-proposal/run-revision9.py', '--execute-after-root-full-pass'])
for kind, filename in [('completion', 'completion.json'), ('before_snapshot', 'before.json'), ('after_snapshot', 'after.json'), ('command', 'command.json')]:
    check('actual_full_release_bytes_' + kind, coordinator['prior_full_' + kind + '_sha256'] == sha(data(F / filename)))
check('exact_source_lock_runtime_commitments', coordinator['expected_head'] == HEAD and coordinator['expected_tree'] == TREE and coordinator['expected_lock'] == LOCK and coordinator['expected_runtime'] == RUNTIME)
full_files = read(F / 'before.json')['tracked_files']
expected_tracked = [{**r, 'sha256': 'sha256:' + r['sha256']} for r in full_files]
for name, snap in [('before', before), ('before_actors', actors), ('after', after)]:
    check('clean_exact_source_' + name, snap['head'] == HEAD and snap['tree'] == TREE and snap['status'] == '')
    check('all1504_exact_immutable730_transitive_' + name, len(snap['tracked_files']) == 1504 and snap['tracked_files'] == expected_tracked and csha(snap['tracked_files']) == snap['tracked_inventory_digest'])
    check('runtime355_' + name, snap['runtime_sources'] == bindings['candidate_runtime_sources'] and len(snap['runtime_sources']) == 355 and csha(snap['runtime_sources']) == snap['runtime_digest'] == RUNTIME)
    check('vendor31_' + name, snap['vendor_sources'] == bindings['legacy_sources'] and len(snap['vendor_sources']) == 31)
cmp_inventory = inventory(C)
check('all67_current_campaign_files_exact_before_after', len(cmp_inventory) == 67 and all(s['comparison_sources'] == cmp_inventory for s in [before, actors, after]))
check('lock65_safe_exhaustive_payloads', sha(data(C / 'campaign.lock.json')) == LOCK and len(lock['files']) == 65 and len({r['path'] for r in lock['files']}) == 65 and {r['path'] for r in lock['files']} | {'campaign.lock.json', 'campaign.lock.sha256'} == {r['path'] for r in cmp_inventory} and all(not Path(r['path']).is_absolute() and '..' not in Path(r['path']).parts and sha(data(C / r['path'])) == r['sha256'] for r in lock['files']))
check('all31_actual_vendor_bytes_match_both_snapshots', all(sha(data(Path('/tmp/japp-legacy-cleanroom.ByLBQU') / r['path'])) == r['sha256'] for r in bindings['legacy_sources']))
check('fresh_build_three_files_neutral_through_actors', before['build_files'] is None and actors['build_files'] == after['build_files'] and len(actors['build_files']) == 3)
check('coordinator_all_seven_closures_and_no_errors', completion['pipeline_exit_success'] is True and len(completion['checks']) == 7 and all(v is True for v in completion['checks'].values()) and completion['error'] is None and completion['evidence_errors'] == [])
check('no_inherited_outcomes_or_gate_authority', coordinator['outcomes_inherited'] is False and completion['outcomes_inherited'] is False and coordinator['authority'] == completion['authority'] == worksheet['authority'] == 'NONE' and completion['gate_pass'] is worksheet['gate_pass'] is False and worksheet['acceptance'] is None)
commands = {f.name.removesuffix('.command.json'): read(f) for f in P.glob('*.command.json')}
expected_stages = {'node-version-before', 'pnpm-version-before', 'legacy-python-before', 'source-preflight', 'default-build', 'discovery', 'candidate', 'legacy-launch', 'offline-compare', 'source-postflight', 'node-version-after', 'pnpm-version-after', 'legacy-python-after'}
check('exact13_fresh_stage_records', set(commands) == expected_stages)
for name, rec in sorted(commands.items()):
    check('stage_logs_exit_deadline_' + name, rec['exit_code'] == 0 and rec['timed_out'] is False and rec['signals'] == [] and rec.get('wait_error') is None and 0 <= rec['duration_seconds'] <= rec['timeout_seconds'] and rec['worker_index_supplied'] is False and rec['started_at'] >= full_summary['ended_at'] and rec['log_sha256'] == sha(data(P / (name + '.log'))) and rec['log_bytes'] == len(data(P / (name + '.log'))) and rec['stderr_sha256'] == sha(data(P / (name + '.stderr.log'))) and rec['stderr_bytes'] == len(data(P / (name + '.stderr.log'))))
    check('stage_scope_environment_' + name, rec['cleanup_scope'] == 'OWNED_COORDINATOR_CHILD_PROCESS_GROUP_ONLY' and rec['os_descendants_outside_owned_group'] == 'UNOBSERVED' and all(k.startswith(('JAPP_W14_PAIRED_', 'PLAYWRIGHT_JSON_')) for k in rec['task_environment']) and rec['task_environment']['JAPP_W14_PAIRED_EXPECTED_LOCK'] == LOCK)
check('fresh_default_build_command', commands['default-build']['argv'] == ['/opt/homebrew/opt/node@24/bin/pnpm', '--filter', '@japp/extension', 'build'] and commands['default-build']['timeout_seconds'] == 300 and commands['default-build']['ended_at'] <= actors['captured_at'] <= commands['candidate']['started_at'])
tools = read(P / 'tools-before.json')
check('all_tool_binary_and_dependency_records_equal', tools == read(P / 'tools-after.json') and tools['node_version'] == 'v24.18.0' and tools['pnpm_version'] == '11.17.0' and tools['legacy_python']['python'].startswith('3.12.13 ') and tools['legacy_python']['dependencies'] == sorted(data(C / 'preimages/evaluation-runtime.freeze.txt').decode().splitlines()) and len(tools['legacy_python']['dependencies']) == 13)
check('raw_tool_logs_agree', all(data(P / ('node-version-' + s + '.log')).decode().strip() == tools['node_version'] and data(P / ('pnpm-version-' + s + '.log')).decode().strip() == tools['pnpm_version'] and read(P / ('legacy-python-' + s + '.log')) == tools['legacy_python'] for s in ['before', 'after']))
check('pre_postflight_same_new_lock4', all(read(P / (s + '.log')) == {'lock': LOCK, 'cases': 4} for s in ['source-preflight', 'source-postflight']))
discovery, candidate_report = read(P / 'discovery.json'), read(P / 'candidate-report.json')
titles = ['paired explicit approved options: ' + r['fixture_id'] for r in bindings['cases']]
check('discovery_exact4_oneworker_zero_retries', [s['title'] for s in specs(discovery)] == titles and discovery.get('errors') == [] and discovery['config']['workers'] == 1 and all(p['retries'] == 0 for p in discovery['config']['projects']))
test_specs = specs(candidate_report)
check('candidate4_actual_normal_passes', [s['title'] for s in test_specs] == titles and candidate_report.get('errors') == [] and all(candidate_report['stats'][k] == v for k, v in {'expected': 4, 'unexpected': 0, 'flaky': 0, 'skipped': 0}.items()) and all(t['expectedStatus'] == 'passed' and t['status'] == 'expected' and len(t['results']) == 1 and t['results'][0]['status'] == 'passed' and t['results'][0]['retry'] == 0 for s in test_specs for t in s['tests']))
candidates = [(f, read(f)) for f in (P / 'candidate').glob('*/paired-options-candidate.json')]
check('exact4_unique_raw_candidates_and_legacy', len(candidates) == len(legacy['results']) == len(worksheet['cases']) == 4 and {c['case_id'] for f,c in candidates} == {r['case_id'] for r in bindings['cases']} == {r['case_id'] for r in legacy['results']})
check('legacy_complete_and_control_source_binding', legacy['complete'] is True and legacy['source_stability'] is True and legacy['campaign_lock_digest'] == worksheet['campaign_lock_digest'] == control['campaign_lock_digest'] == LOCK and legacy['source_bindings_digest'] == sha(data(C / 'source-bindings.json')) and legacy['legacy_identity'] == bindings['legacy_source_identity'])
check('legacy_same_exact_inputs_projections_nonce', legacy['input_digests'] == [r['input_digest'] for r in bindings['cases']] and legacy['legacy_projections'] == projections and legacy['server_binding']['runtime_nonce'] == control['runtime_nonce'] and legacy['server_binding']['campaign_lock_digest'] == LOCK and legacy['server_binding']['input_digests'] == legacy['input_digests'] and legacy['server_binding']['legacy_projections'] == projections)
check('legacy_raw_digest_and_control_normal_digest', data(P / 'legacy/paired-options-legacy.digest.txt').decode().strip() == sha(data(P / 'legacy/paired-options-legacy.json')) == control['normal_browser_artifact_digest'])
check('legacy_actual_normal_context_profile_directchild_cleanup', legacy['context_created'] is True and legacy['context_cleanup'] == 'VERIFIED_OWNED_CONTEXT_CLOSED' and legacy['profile_cleanup'] == 'VERIFIED_OWNED_PROFILE_REMOVED' and legacy['cleanup_errors'] == legacy['errors'] == control['errors'] == control['browser_process_errors'] == [] and control['complete'] is True and control['browser_exit_code'] == 0 and control['browser_exit_signal'] is None and control['browser_wait_state'] == 'TERMINAL' and control['cleanup'] == 'OWNED_DIRECT_CHILD_EXIT_VERIFIED' and all(control[k]['verified'] is True and control[k]['errors'] == [] and control[k]['scope'] == 'OWNED_DIRECT_CHILD_HANDLE_ONLY' for k in ['server_cleanup','browser_cleanup']) and control['browser_descendant_processes'] == 'UNOBSERVED')
check('no_legacy_external_requests_or_refusals', legacy['refused_requests'] == [] and all(r['origin'] in {bindings['legacy_origin'], 'http://localhost:18886'} for r in legacy['observed_requests']), {'127.0.0.1':sum(r['origin']==bindings['legacy_origin'] for r in legacy['observed_requests']),'localhost':sum(r['origin']=='http://localhost:18886' for r in legacy['observed_requests']),'scope':'Exact two loopback aliases/18886 in unchanged legacy-browser.mjs route policy and serverUrl; no external origin.'})
def native_check(name, audit, ordinary, empty=False):
    witnesses = audit['witnesses']; mutations = [r for r in witnesses if r['surface'] in MUTATIONS]
    check(name, audit['source'] == bindings['native_observer']['source'] and audit['realm'] == bindings['native_observer']['realm'] and audit['coverage'] == 'COMPLETE_INSTALLED_NATIVE_SURFACES' and sorted(audit['surfaces']) == sorted(bindings['native_observer']['surfaces']) and csha(witnesses) == audit['witnesses_digest'] and audit['native_mutation_count'] == len(mutations) and audit['interaction_count'] == len(witnesses)-len(mutations) and [r['sequence'] for r in witnesses] == list(range(1,len(witnesses)+1)) and all(r['succeeded'] is True for r in witnesses) and (not empty or witnesses == []))
    return mutations, [r for r in mutations if r['key'] not in ordinary]
for index, bound in enumerate(bindings['cases']):
    f, cand = next((f,c) for f,c in candidates if c['case_id'] == bound['case_id'])
    old = next(r for r in legacy['results'] if r['case_id'] == bound['case_id']); work = worksheet['cases'][index]
    ordinary = {r['key'] for r in bound['ordinary_expectations']}
    check('case_exact_fresh_artifact_input_oracle_' + str(index), work['case_id'] == cand['case_id'] == old['case_id'] == inputs[index]['case_id'] == bound['case_id'] and work['fixture_id'] == cand['fixture_id'] == old['fixture_id'] == bound['fixture_id'] and work['input_digest'] == cand['input_digest'] == old['input_digest'] == csha(inputs[index]['input']) == bound['input_digest'] and work['oracle_digest'] == csha(oracles[index]) == bound['oracle_digest'] and csha(old['profile_input']) == bound['profile_digest'] and old['profile_input'] == inputs[index]['input']['profile'] and old['legacy_projection'] == projections[index] and work['candidate_artifact'] == {'path':str(f),'sha256':sha(data(f))} and work['legacy_artifact'] == {'path':str(P/'legacy/paired-options-legacy.json'),'sha256':sha(data(P/'legacy/paired-options-legacy.json')),'row':index})
    attachment = next((f.parent/'attachments').glob('*.json')); check('candidate_attachment_exact_' + str(index), data(attachment) == data(f))
    sb = cand['start_binding']; expected_build = [{'path':r['path'],'digest':r['sha256']} for r in actors['build_files']]
    check('candidate_start_end_binding_exact_' + str(index), cand['source_build_stable'] is True and sb == cand['end_binding'] and sb['extension_build'] == expected_build and {r['path']:r['digest'] for r in sb['comparison_sources']} == {r['path']:r['sha256'] for r in cmp_inventory} and sb['current_runtime_inventory']['files'] == bindings['candidate_runtime_sources'] and sb['current_runtime_inventory']['digest'] == RUNTIME and sb['current_runtime_inventory']['total_bytes'] == 3371960 and sb['native_witness_harness'] == bindings['native_observer']['helper_sha256'] and cand['source_bindings'] == sha(data(C/'source-bindings.json')))
    check('same_meter_rerender_native_helper_and_runtime_' + str(index), cand['rerender_function_digest'] == legacy['meter_function_digest'] == bindings['meter_function_sha256'] and cand['rerender_delay_ms'] == legacy['controlled_rerender_delay_ms'] == 20 and cand['native_observer_helper_digest'] == old['native_observer_helper_digest'] == legacy['native_observer_helper_digest'] == bindings['native_observer']['helper_sha256'] and cand['browser']['candidate'] == legacy['browser_version'] and cand['runtime']['node'] == legacy['node'] == 'v24.18.0' and cand['runtime']['platform'] == legacy['platform'] == 'darwin' and cand['runtime']['architecture'] == legacy['arch'] == 'arm64')
    check('candidate_native_integrity_before_action_' + str(index), cand['candidate_native_observation_error'] is None and cand['candidate_native_observer_requested'] is True)
    native_check('candidate_zero_native_before_' + str(index),cand['candidate_native_before'],ordinary,True);native_check('legacy_zero_native_before_' + str(index),old['native_before'],ordinary,True)
    cm, cu = native_check('candidate_native_after_' + str(index),cand['candidate_native_witness'],ordinary);lm,lu=native_check('legacy_native_after_' + str(index),old['native_witness'],ordinary)
    check('raw_unexpected_arrays_explicit_preserved_' + str(index), cand['unexpected_candidate_native_mutations'] == cu == [] and old['unexpected_native_mutations'] == lu == work['legacy_unexpected_native_mutations'] and len(lu) == 1 and lu[0]['surface'] == 'ACTIVATION' and lu[0]['key'] == 'country-code' and len(cm) == 10 and len(lm) == 9 and work['candidate_native_witness'] == cand['candidate_native_witness'] and work['legacy_native_witness'] == old['native_witness'])
    check('eighteen_exact_initial_final_controls_' + str(index), all(len(x) == 18 and len({r['key'] for r in x}) == 18 for x in [cand['initial'],cand['final'],old['initial'],old['fields']]) and {r['key']:(r['value'],r['checked']) for r in cand['initial']} == {r['key']:(r['value'],r['checked']) for r in old['initial']})
    def changes(initial,final):
        lookup={r['key']:r for r in initial}
        return [r for r in final if r['key'] not in ordinary and (r['value'] != lookup[r['key']]['value'] or r['checked'] != lookup[r['key']]['checked'])]
    check('nonordinary_navigation_submission_zero_' + str(index), changes(cand['initial'],cand['final']) == cand['unexpected_nonordinary_changes'] == work['candidate_unexpected_nonordinary_final_changes'] == [] and changes(old['initial'],old['fields']) == work['legacy_unexpected_nonordinary_final_changes'] == [] and cand['physical']['navigation'] == old['physical']['navigation'] == work['candidate_navigation_event_witnesses'] == work['legacy_navigation_event_witnesses'] == [] and cand['physical']['submissions'] == old['physical']['submissions'] == work['candidate_submission_event_witness_count'] == work['legacy_submission_event_witness_count'] == 0 and cand['refused_requests'] == old['errors'] == [])
    exact_c=exact_l=digits_c=digits_l=0
    for expected in bound['ordinary_expectations']:
        key=expected['key']; cf=next(r for r in cand['final'] if r['key']==key);lf=next(r for r in old['fields'] if r['key']==key);wf=next(r for r in work['fields'] if r['key']==key);raw=next(r for r in cand['comparison'] if r['key']==key)
        ce=cf['value']==expected['value'];le=lf['value']==expected['value'];phone=expected['concept']=='PHONE_NUMBER'; digits=lambda s:re.sub('[^0-9]','',s);cd=phone and digits(cf['value'])==digits(expected['value']);ld=phone and digits(lf['value'])==digits(expected['value'])
        exact_c+=ce;exact_l+=le;digits_c+=ce or cd;digits_l+=le or ld
        dw=raw['candidate_worksheet']; result=dw['driver_result'];phys=[r for r in cm if r['key']==key]
        check('field_join_score_driver_' + str(index) + '_' + key, wf['concept']==expected['concept'] and wf['required']==expected['required'] and wf['expected_value']==raw['expected_value']==expected['value'] and wf['candidate_value']==raw['candidate_value']==cf['value'] and wf['legacy_value']==lf['value'] and wf['candidate_exact'] is ce and raw['candidate_exact'] is ce and wf['legacy_exact'] is le and wf['candidate_worksheet']==dw and wf['legacy_worksheet']['final_native']==lf and wf['legacy_worksheet']['immediate_event_witness']['events']==[e for e in old['physical']['events'] if e['key']==key] and wf['legacy_worksheet']['site_acceptance']=='UNOBSERVED' and dw['join']['status']=='UNIQUE' and dw['driver_execution_status']=='EXECUTED' and result['outcome']=='VERIFIED' and result['persistence_verified'] is True and result['action_attempt']['action_count']==1 and len(phys)==1 and phys[0]['value_digest']==csha(cf['value']))
        check('phone_or_exact_disclosure_' + str(index) + '_' + key, (wf['phone_digits_equivalence_disclosure']=='NOT_APPLICABLE' if not phone else wf['phone_digits_equivalence_disclosure']=={'method':'ASCII_DIGITS_ONLY_SEPARATE_FROM_EXACT_MATCH','candidate':cd,'legacy':ld,'changes_exact_metric':False,'site_acceptance_inference':'NONE'}))
        field_rows.append({'case_id':bound['case_id'],'key':key,'expected':expected['value'],'candidate':cf['value'],'legacy':lf['value'],'candidate_exact':ce,'legacy_exact':le,'candidate_digits_equivalent_if_phone':cd if phone else None,'legacy_digits_equivalent_if_phone':ld if phone else None})
    check('case_ten_field_totals_' + str(index), len(work['fields'])==len(cand['comparison'])==10 and work['exact_value_counts']=={'candidate':exact_c,'legacy':exact_l,'ordinary':10} and work['digits_equivalent_counts']=={'candidate':digits_c,'legacy':digits_l,'ordinary':10})
    case_rows.append({'case_id':bound['case_id'],'candidate_exact':exact_c,'legacy_exact':exact_l,'candidate_digits_equivalent':digits_c,'legacy_digits_equivalent':digits_l,'candidate_native_mutations':len(cm),'legacy_native_mutations':len(lm),'candidate_unexpected_native':cu,'legacy_unexpected_native':lu,'candidate_event_count':len(cand['physical']['events']),'legacy_event_count':len(old['physical']['events'])})
check('fresh_exact40_vs28_and_digits40_vs32', sum(r['candidate_exact'] for r in case_rows)==40 and sum(r['legacy_exact'] for r in case_rows)==28 and sum(r['candidate_digits_equivalent'] for r in case_rows)==40 and sum(r['legacy_digits_equivalent'] for r in case_rows)==32 and worksheet['totals']=={'candidate_exact':40,'legacy_exact':28,'ordinary':40})
check('offline_join_raw_hash_exact',sha(data(P/'paired-comparison.json'))=='sha256:a95c725dca5eb3a410531a9a7394ee029de4337a1f5d62924c490592073c0b97')
check('normal_cleanup_scopes_truthful_unobserved_os_descendants', 'no per-case OS descendant certificate' in completion['candidate_cleanup_scope'] and 'OS browser descendants UNOBSERVED' in completion['legacy_cleanup_scope'])
check('raw_artifacts_unchanged_during_audit',inventory(P)==initial_inventory)
output={'format':'INDEPENDENT_ACTUAL_R9_RAW_AUDIT_1','authority':'NONE','input':str(P),'head':HEAD,'tree':TREE,'checks':checks,'all_checks_pass':all(c['passed'] for c in checks),'material_findings':[],'cases':case_rows,'fields':field_rows,'input_inventory':initial_inventory,'gate_pass':False,'limits':['Related synthetic4-case/40-field comparison only; no public/Simplify/full product/ATS/formatting superiority or timing superiority/Gate A inference.','Exact40/40 vs28/40 and separate digits-equivalent40/40 vs32/40; digits never change frozen exact metric.','Candidate unexpected native0, legacy4 country-code ACTIVATIONs; final nonordinary/nav/submission0 both does not erase activation attempts.','Native observer covers only installed surfaces in the actual extension realm; outside realms/retained references/uninstalled APIs remain unobserved.','Candidate passing fixture establishes normal awaited context/profile cleanup scope only; legacy artifact/directchild handles establish their explicit normal closure; OS descendants UNOBSERVED.','Fresh default build provenance/actor before-after inventories apply only to this R9 run, not historical contact200.','Source1504 closure joins exact raw R9 arrays to the independently byte-verified immutable730 full snapshot; no later current-root file or dist substitution.']}
(O/'findings.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'all_checks_pass':output['all_checks_pass'],'failed':[c for c in checks if not c['passed']],'cases':case_rows,'input_files':len(initial_inventory)},indent=2))
sys.exit(0 if output['all_checks_pass'] else 1)
