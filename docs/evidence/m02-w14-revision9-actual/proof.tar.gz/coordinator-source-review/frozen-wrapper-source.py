from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

root = Path('/Users/tanishkalwad/jobapplyv2')
out = Path('/tmp/japp-w14-concurrency-frozen-20261016')
expected = sys.argv[1]
assert re.fullmatch('[0-9a-f]{40}', expected)
env = os.environ.copy()
env['PATH'] = '/opt/homebrew/opt/node@24/bin:' + env['PATH']
env.update(JAPP_W13_PERFORMANCE_SAMPLES='20', JAPP_W14_REQUIRE_TARGET_PERFORMANCE='1', JAPP_W14_ARTIFACT_DIRECTORY=str(out / 'w14'))

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root).decode().strip()

def snapshot():
    files = []
    for name in subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0'):
        if not name:
            continue
        body = (root / name).read_bytes()
        files.append({'path': name, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'status': git('status', '--porcelain=v1'), 'tracked_files': files, 'tracked_inventory_digest': hashlib.sha256(json.dumps(files, separators=(',', ':')).encode()).hexdigest(), 'captured_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}

assert not (out / 'before.json').exists() and not (out / 'aggregate.log').exists() and not (out / 'w14').exists(), 'Fresh frozen output required'
before = snapshot()
assert before['head'] == expected and before['status'] == '', 'Exact clean committed source required'
(out / 'before.json').write_text(json.dumps(before, indent=2) + '\n')
command = {'argv': ['pnpm', 'verify'], 'cwd': str(root), 'expected_head': expected, 'task_environment': {key: env[key] for key in ('JAPP_W13_PERFORMANCE_SAMPLES', 'JAPP_W14_REQUIRE_TARGET_PERFORMANCE', 'JAPP_W14_ARTIFACT_DIRECTORY')}, 'node_path': '/opt/homebrew/opt/node@24/bin/node', 'wrapper_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'started_at': before['captured_at']}
(out / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
with (out / 'aggregate.log').open('wb') as stream:
    result = subprocess.run(['pnpm', 'verify'], cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT)
after = snapshot()
(out / 'after.json').write_text(json.dumps(after, indent=2) + '\n')
completion = {'exit_code': result.returncode, 'head_unchanged': before['head'] == after['head'], 'status_before': before['status'], 'status_after': after['status'], 'tracked_inventory_unchanged': before['tracked_inventory_digest'] == after['tracked_inventory_digest'], 'ended_at': after['captured_at']}
(out / 'completion.json').write_text(json.dumps(completion, indent=2) + '\n')
print(json.dumps(completion), flush=True)
raise SystemExit(result.returncode)
