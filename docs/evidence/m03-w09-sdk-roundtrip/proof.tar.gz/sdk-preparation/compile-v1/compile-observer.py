import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import time

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
BASE = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/w09-sdk-proof-preparation')
OUT = BASE / 'compile-v1'
TARGET = BASE / 'owned-target'
CRATE = BASE / 'derivative/apps/desktop/src-tauri'

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def item(path, relative):
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode), f'Nonregular input: {relative}'
    data = path.read_bytes()
    return {'path': relative, 'bytes': len(data), 'mode': stat.S_IMODE(s.st_mode), 'sha256': hashlib.sha256(data).hexdigest()}

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args]).decode().strip()

inputs = json.loads((BASE / 'INPUTS.json').read_text())['files']
handoff = json.loads((BASE / 'HANDOFF.json').read_text())
protected = json.loads((BASE / 'PROTECTED-RUNTIME-AND-SHIPPING-before-reviewed-actor.json').read_text())['files']
manifest = json.loads((BASE / 'PREPARATION-MANIFEST.json').read_text())
assert hashlib.sha256((BASE / 'HANDOFF.json').read_bytes()).hexdigest() == '073eab2bf2e39dd55d6e4856edcedae205e87ad740e2d778d09352f472bfa59f'
assert hashlib.sha256((BASE / 'PREPARATION-MANIFEST.json').read_bytes()).hexdigest() == '1de4693ce2f878123972b8f1f80ae8af67a9d286d1f26aa6c0b3cc315d0d9319'
for row in manifest['files']:
    current = item(BASE / row['path'], row['path'])
    assert all(current[k] == row[k] for k in ['bytes', 'sha256']), f'Sealed packet changed: {row["path"]}'

def snapshot():
    names = sorted(set(subprocess.check_output(['git', '-C', str(ROOT), 'ls-files', '--cached', '--others', '--exclude-standard', '-z']).decode().split('\0')) - {''})
    return {
        'head': git('rev-parse', 'HEAD'),
        'tree': git('rev-parse', 'HEAD^{tree}'),
        'status': git('status', '--porcelain=v1', '--untracked-files=all'),
        'canonical_files': [item(ROOT / p, p) for p in names],
        'selected_161': [item(ROOT / row['path'], row['path']) for row in inputs],
        'protected_44': [item(ROOT / row['path'], row['path']) for row in protected],
        'overlays_7': [item(BASE / 'derivative' / row['path'], row['path']) for row in handoff['derivative_only_overlays']],
    }

before = snapshot()
assert before['head'].startswith('204bc06'), before['head']
assert before['tree'].startswith('5b5bfeda'), before['tree']
assert not before['status'], before['status']
assert len(before['canonical_files']) == 2070
assert before['selected_161'] == inputs
assert before['protected_44'] == protected
assert len(before['protected_44']) == 44
for row, actual in zip(handoff['derivative_only_overlays'], before['overlays_7']):
    assert {k: actual[k] for k in ['bytes', 'sha256', 'mode']} == row['after']
    if row['before'] and row['path'].endswith('.rs'):
        assert (BASE / 'derivative' / row['path']).read_bytes().startswith((ROOT / row['path']).read_bytes())
assert not TARGET.exists() and not TARGET.is_symlink(), 'Fresh owned target required'
TARGET.mkdir(mode=0o700)
write('before.json', before)

argv = handoff['future_build']['argv']
env = dict(os.environ)
env['CARGO_TARGET_DIR'] = str(TARGET)
cargo = Path(shutil.which(argv[0])).resolve()
write('command.json', {
    'argv': argv, 'cwd': str(CRATE), 'explicit_environment': {'CARGO_TARGET_DIR': str(TARGET)},
    'cargo_executable': item(cargo, str(cargo)), 'timeout_seconds': 900, 'output_cap_bytes': 2097152,
    'scope': 'COMPILE_ONLY_NO_SDK_EXECUTION', 'observer': item(Path(__file__), 'compile-observer.py'),
})

started = time.monotonic()
signals = []
reason = None
with (OUT / 'cargo.stdout.log').open('wb') as stdout, (OUT / 'cargo.stderr.log').open('wb') as stderr:
    child = subprocess.Popen(argv, cwd=CRATE, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
    pgid = os.getpgid(child.pid)
    assert pgid == child.pid
    write('started.json', {'pid': child.pid, 'pgid': pgid, 'started_monotonic': started, 'scope': 'OWNED_COMPILE_CHILD_ONLY'})
    print(json.dumps({'compile_started': child.pid, 'owned_pgid': pgid, 'output': str(OUT)}), flush=True)
    while True:
        exit_code = child.poll()
        if exit_code is not None:
            break
        elapsed = time.monotonic() - started
        output_bytes = stdout.tell() + stderr.tell()
        if elapsed > 900 or output_bytes > 2097152:
            reason = 'TIMEOUT' if elapsed > 900 else 'OUTPUT_CAP'
            # poll() above established this owned direct child is unreaped/alive.
            # No group signal is sent after a successful reap observation.
            os.killpg(pgid, signal.SIGTERM)
            signals.append({'signal': 'SIGTERM', 'elapsed': elapsed})
            until = time.monotonic() + 2
            while time.monotonic() < until:
                exit_code = child.poll()
                if exit_code is not None:
                    break
                time.sleep(0.05)
            if exit_code is None:
                os.killpg(pgid, signal.SIGKILL)
                signals.append({'signal': 'SIGKILL', 'elapsed': time.monotonic() - started})
                exit_code = child.wait(timeout=5)
            break
        time.sleep(0.2)

try:
    os.killpg(pgid, 0)
except ProcessLookupError:
    group = 'ABSENT'
except PermissionError:
    group = 'EXISTS_NO_PERMISSION'
else:
    group = 'EXISTS'

after = snapshot()
write('after.json', after)
binary = TARGET / 'debug/sdk_paths_probe'
result = {
    'scope': 'COMPILE_ONLY_NO_SDK_EXECUTION',
    'exit_code': exit_code, 'elapsed_seconds': time.monotonic() - started,
    'limit_reason': reason, 'signals': signals, 'direct_child_reaped': child.returncode is not None,
    'owned_group_after_reap_observation': group, 'before_after_exact_equal': before == after,
    'canonical_selected_161_unchanged': before['selected_161'] == after['selected_161'],
    'canonical_all_2070_unchanged': before['canonical_files'] == after['canonical_files'],
    'protected_44_unchanged': before['protected_44'] == after['protected_44'],
    'derivative_overlays_7_unchanged': before['overlays_7'] == after['overlays_7'],
    'stdout': item(OUT / 'cargo.stdout.log', 'cargo.stdout.log'),
    'stderr': item(OUT / 'cargo.stderr.log', 'cargo.stderr.log'),
    'binary': item(binary, str(binary)) if binary.exists() else None,
}
write('result.json', result)
print(json.dumps(result, indent=2), flush=True)
raise SystemExit(0 if exit_code == 0 and reason is None and before == after and group == 'ABSENT' else 1)
