//! Derivative-only actual Wry/SDK proof. No window, IPC handler or service start.
use crate::{ManagedService, NativePathService, PathFailure, PathRequest, PathRole, PathState, Scope};
use serde_json::{Value, json};
use std::{os::unix::fs::MetadataExt, path::{Path, PathBuf}, time::Duration};
use tauri::Manager;

const ID: &str = "dev.jobapply.desktop";
const IDLE_CAP: Duration = Duration::from_secs(3);
const WORKFLOW_CAP: Duration = Duration::from_secs(40);

#[derive(Clone)]
struct Roots { data: PathBuf, cache: PathBuf, temp: PathBuf }
impl Roots {
    fn fixed(&self) -> Vec<PathBuf> {
        vec![self.data.clone(), self.data.join("data"), self.cache.clone(),
            self.cache.join("cache"), self.temp.join(ID)]
    }
}
fn emit(stage: &str, data: Value) { println!("{}", json!({"stage": stage, "data": data})); }
fn metadata(path: &Path) -> Value {
    match std::fs::symlink_metadata(path) {
        Ok(m) => json!({"path": path, "kind": if m.file_type().is_symlink() { "symlink" }
            else if m.is_dir() { "directory" } else { "other" },
            "dev": m.dev(), "ino": m.ino(), "uid": m.uid(), "gid": m.gid(),
            "mode": m.mode() & 0o7777}),
        Err(e) => json!({"path": path, "kind": match e.kind() {
            std::io::ErrorKind::NotFound => "missing",
            std::io::ErrorKind::PermissionDenied => "denied", _ => "metadata_error" }}),
    }
}
fn demand(ok: bool, label: &str) -> Result<(), String> {
    if ok { Ok(()) } else { Err(label.to_owned()) }
}
fn fixed_metadata(roots: &Roots) -> Vec<Value> { roots.fixed().iter().map(|p| metadata(p)).collect() }
fn check_persistent(before: &[Value], after: &[Value]) -> Result<(), String> {
    demand(before.len() == 5 && after.len() == 5, "fixed_metadata_count")?;
    let uid = unsafe { libc::geteuid() };
    for (index, (a, b)) in before.iter().zip(after).enumerate() {
        demand(b["kind"] == "directory", "fixed_directory_missing_after")?;
        if a["kind"] == "directory" {
            for field in ["dev", "ino", "uid", "gid", "mode"] {
                demand(a[field] == b[field], "existing_persistent_metadata_changed")?;
            }
        } else {
            demand(a["kind"] == "missing", "fixed_preimage_not_missing_directory")?;
            demand(b["uid"] == uid && b["mode"] == 0o700, "created_directory_not_private_owner")?;
        }
        if matches!(index, 1 | 3 | 4) {
            demand(b["uid"] == uid && b["mode"] == 0o700, "role_or_temp_namespace_not_private")?;
        }
    }
    Ok(())
}
async fn idle(paths: &NativePathService) -> Result<(), String> {
    tokio::time::timeout(IDLE_CAP, async {
        while paths.busy() { tokio::time::sleep(Duration::from_millis(1)).await; }
    }).await.map_err(|_| "actual_worker_remained_busy".to_owned())
}
async fn snapshot(paths: &NativePathService) -> Result<Value, String> {
    idle(paths).await?;
    paths.sdk_probe_snapshot().map_err(|e| format!("snapshot_{e:?}"))
}
fn request(role: PathRole, segments: Vec<String>) -> PathRequest {
    PathRequest { role, scope: Scope::User, relative_segments: segments, create_if_missing: true }
}
fn segment(prefix: &str) -> Result<String, String> {
    let mut bytes = [0u8; 16];
    getrandom::fill(&mut bytes).map_err(|_| "driver_nonce_failed".to_owned())?;
    Ok(format!("{prefix}_{}", bytes.iter().map(|b| format!("{b:02x}")).collect::<String>()))
}
fn capture_temp(snapshot: &Value, roots: &Roots, known: &mut Vec<PathBuf>) -> Result<Vec<PathBuf>, String> {
    let rows = snapshot["temporary_paths"].as_array().ok_or("temporary_paths_shape")?;
    demand(rows.len() <= 18, "temporary_path_bound")?;
    let uid = unsafe { libc::geteuid() };
    let mut captured = Vec::new();
    for row in rows {
        let text = row.as_str().ok_or("temporary_path_not_text")?;
        let path = PathBuf::from(text);
        demand(path.is_absolute() && text.len() <= 32768, "temporary_path_invalid")?;
        // Read-only comparison of this one observed system alias. Production's
        // unchanged no-follow adapter performs the actual ownership validation.
        let normalized_temp = roots.temp.strip_prefix("/var").map_or_else(
            |_| roots.temp.clone(), |suffix| Path::new("/private/var").join(suffix));
        let namespace = normalized_temp.join(ID);
        let relative = path.strip_prefix(&namespace).map_err(|_| "temp_outside_sdk_namespace".to_owned())?;
        let components = relative.components().collect::<Vec<_>>();
        demand((1..=2).contains(&components.len()), "unexpected_temp_depth")?;
        let nonce = components[0].as_os_str().to_str().ok_or("temp_nonce_not_text")?;
        demand(nonce.len() == 32 && nonce.bytes().all(|b| b.is_ascii_hexdigit()), "temp_nonce_shape")?;
        let m = metadata(&path);
        demand(m["kind"] == "directory" && m["uid"] == uid && m["mode"] == 0o700,
            "owned_temporary_metadata")?;
        if !known.contains(&path) { known.push(path.clone()); }
        captured.push(path);
    }
    demand(!captured.is_empty(), "no_owned_temporary_paths")?;
    Ok(captured)
}
fn absent(paths: &[PathBuf]) -> bool { paths.iter().all(|p| metadata(p)["kind"] == "missing") }
async fn exercise(app: &tauri::AppHandle<tauri::Wry>, paths: &NativePathService,
                  roots: &Roots, known: &mut Vec<PathBuf>) -> Result<(), String> {
    for role in [PathRole::ApplicationData, PathRole::Cache] {
        let outcome = paths.resolve(app, request(role, vec![]), Some(Duration::from_secs(4)))
            .await.map_err(|e| format!("persistent_resolve_{role:?}_{e:?}"))?;
        demand(outcome.view.resolution_state == PathState::Resolved && outcome.view.exists
            && outcome.view.writable, "persistent_result_not_resolved_writable")?;
        let observed = snapshot(paths).await?;
        for (field, expected) in [("data", roots.data.join("data")), ("cache", roots.cache.join("cache"))] {
            let actual = PathBuf::from(observed[field].as_str().ok_or("persistent_observation_missing")?);
            let a = metadata(&actual); let e = metadata(&expected);
            demand(a["kind"] == "directory" && a["dev"] == e["dev"] && a["ino"] == e["ino"],
                "actual_native_lease_not_sdk_role_directory")?;
        }
        emit("persistent_resolved", json!({"role": role, "view": outcome.view.clone(), "owner": observed}));
        let released = paths.release(outcome).await;
        demand(released == Err(PathFailure::Policy), "persistent_release_must_refuse")?;
        idle(paths).await?;
        emit("persistent_release_refused", json!({"role": role, "reason": "POLICY"}));
    }
    let first = paths.resolve(app, request(PathRole::Temporary, vec![segment("release")?]),
        Some(Duration::from_secs(4))).await.map_err(|e| format!("temporary_resolve_{e:?}"))?;
    demand(first.view.resolution_state == PathState::Resolved && first.view.writable,
        "temporary_result_not_writable")?;
    let observed = snapshot(paths).await?;
    let first_paths = capture_temp(&observed, roots, known)?;
    emit("temporary_retained_before_release", observed);
    paths.release(first).await.map_err(|e| format!("temporary_release_{e:?}"))?;
    let released = snapshot(paths).await?;
    demand(released["pending_cleanup"] == false && absent(&first_paths), "released_temp_not_settled")?;
    emit("temporary_released", json!({"owner": released,
        "named_paths_after": first_paths.iter().map(|p| metadata(p)).collect::<Vec<_>>()}));
    let dropped = paths.resolve(app, request(PathRole::Temporary, vec![segment("dropped")?]),
        Some(Duration::from_secs(4))).await.map_err(|e| format!("second_temporary_resolve_{e:?}"))?;
    demand(dropped.view.resolution_state == PathState::Resolved && dropped.view.writable,
        "second_temporary_not_writable")?;
    drop(dropped);
    let retained = snapshot(paths).await?;
    capture_temp(&retained, roots, known)?;
    demand(retained["pending_cleanup"] == true, "dropped_outcome_lost_owner")?;
    emit("dropped_outcome_still_retained", retained);
    Ok(())
}
async fn probe(app: tauri::AppHandle<tauri::Wry>, paths: NativePathService, roots: Roots) {
    let before = fixed_metadata(&roots);
    emit("sdk_roots_and_fixed_before", json!({"sdk_data": roots.data, "sdk_cache": roots.cache,
        "sdk_temp": roots.temp, "fixed_metadata": before, "create_missing_app_owned_dirs": true}));
    let mut known = Vec::new();
    let work = tokio::time::timeout(WORKFLOW_CAP, exercise(&app, &paths, &roots, &mut known)).await
        .unwrap_or_else(|_| Err("workflow_timeout".to_owned()));
    // Cleanup is attempted even when work fails. Only actual finished worker state
    // admits a new cleanup worker; no expiry frees an in-flight native operation.
    let cleanup = match idle(&paths).await {
        Ok(()) => paths.sdk_probe_path_quit_cleanup().await.map_err(|e| format!("path_quit_cleanup_{e:?}")),
        Err(e) => Err(e),
    };
    let final_state = snapshot(&paths).await;
    let after = fixed_metadata(&roots);
    let persistent = check_persistent(&before, &after);
    let named_absent = absent(&known);
    let no_pending = final_state.as_ref().is_ok_and(|s| s["pending_cleanup"] == false);
    let closed = paths.resolve(&app, request(PathRole::Temporary, vec![]), Some(Duration::from_secs(4))).await;
    let work_revoked = closed.err() == Some(PathFailure::Cancelled);
    let passed = work.is_ok() && cleanup.is_ok() && persistent.is_ok() && named_absent
        && no_pending && work_revoked;
    emit("final", json!({"pass": passed, "work": work, "cleanup": cleanup,
        "persistent_metadata_invariants": persistent, "fixed_after": after,
        "known_owned_temp_names_absent": named_absent, "owner": final_state,
        "work_stays_revoked": work_revoked, "gui_proof": false,
        "service_start_called": false, "native_package_proof": false}));
    app.exit(if passed { 0 } else { 1 });
}
pub fn run() {
    if std::env::args().collect::<Vec<_>>().get(1).map(String::as_str)
        != Some("--initialize-app-owned-roots") {
        eprintln!("Expected explicit --initialize-app-owned-roots"); std::process::exit(64);
    }
    let main_thread = std::thread::current().id();
    let app = tauri::Builder::<tauri::Wry>::default().setup(move |app| {
        if std::thread::current().id() != main_thread || unsafe { libc::pthread_main_np() } != 1 {
            return Err(std::io::Error::other("Wry setup must run on actual main thread").into());
        }
        if app.config().identifier != ID || app.config().app.app_directories_override.is_some()
            || !app.webview_windows().is_empty()
            || app.config().app.windows.iter().any(|window| window.create) {
            return Err(std::io::Error::other("Unexpected actual SDK context or window").into());
        }
        let resolver = app.path();
        let roots = Roots { data: resolver.app_local_data_dir()?, cache: resolver.app_cache_dir()?,
            temp: resolver.temp_dir()? };
        for parent in [roots.data.parent(), roots.cache.parent(), Some(roots.temp.as_path())] {
            let parent = parent.ok_or_else(|| std::io::Error::other("SDK parent missing"))?;
            if metadata(parent)["kind"] != "directory" {
                return Err(std::io::Error::other("Existing SDK parent required before app initialization").into());
            }
        }
        let service = ManagedService::new(crate::service::ConfiguredRuntime::unavailable())
            .map_err(|_| std::io::Error::other("Service owner construction failed"))?;
        let paths = service.native_paths();
        app.manage(service);
        emit("actual_wry_ready", json!({"main_thread": true, "bundle_id": ID,
            "runtime": "tauri::Wry", "tauri_version": tauri::VERSION, "development_context": tauri::is_dev(), "mock_runtime": false, "observed_webview_windows": 0,
            "configured_auto_create_windows": 0,
            "native_window_enumeration": "unavailable_in_stable_Manager_API",
            "production_service_started": false}));
        tauri::async_runtime::spawn(probe(app.handle().clone(), paths, roots));
        Ok(())
    }).build(tauri::generate_context!(test = true));
    match app {
        Ok(app) => { let code = app.run_return(|_, _| {}); std::process::exit(code); }
        Err(_) => { emit("build_failed", json!({"pass": false})); std::process::exit(70); }
    }
}
