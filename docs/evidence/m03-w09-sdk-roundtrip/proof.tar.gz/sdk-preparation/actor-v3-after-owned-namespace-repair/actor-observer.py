import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import time

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
BASE = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/w09-sdk-proof-preparation')
OUT = BASE / 'actor-v3-after-owned-namespace-repair'
TARGET = BASE / 'owned-target-v3'
DERIVATIVE = BASE / 'derivative-v3'
CRATE = DERIVATIVE / 'apps/desktop/src-tauri'

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def item(path, relative):
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode), f'Nonregular input: {relative}'
    data = path.read_bytes()
    return {'path': relative, 'bytes': len(data), 'mode': stat.S_IMODE(s.st_mode), 'sha256': hashlib.sha256(data).hexdigest()}

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args]).decode().strip()

inputs = json.loads((BASE / 'INPUTS.json').read_text())['files']
handoff = json.loads((BASE / 'HANDOFF.json').read_text())
protected = json.loads((BASE / 'PROTECTED-RUNTIME-AND-SHIPPING-before-reviewed-actor.json').read_text())['files']
manifest = json.loads((BASE / 'PREPARATION-MANIFEST.json').read_text())
assert hashlib.sha256((BASE / 'HANDOFF.json').read_bytes()).hexdigest() == '073eab2bf2e39dd55d6e4856edcedae205e87ad740e2d778d09352f472bfa59f'
assert hashlib.sha256((BASE / 'PREPARATION-MANIFEST.json').read_bytes()).hexdigest() == '1de4693ce2f878123972b8f1f80ae8af67a9d286d1f26aa6c0b3cc315d0d9319'
for row in manifest['files']:
    current = item(BASE / row['path'], row['path'])
    assert all(current[k] == row[k] for k in ['bytes', 'sha256']), f'Sealed packet changed: {row["path"]}'

correction_path = BASE / 'driver-compile-correction-v3/CORRECTION.json'
assert hashlib.sha256(correction_path.read_bytes()).hexdigest() == '5157c523aa942502fe17a1bd355293a837438f72b441927b77ff7c6681bafa83'
correction = json.loads(correction_path.read_text())
for row in correction['files']:
    assert item(Path(row['path']), row['path']) == row

def snapshot():
    names = sorted(set(subprocess.check_output(['git', '-C', str(ROOT), 'ls-files', '--cached', '--others', '--exclude-standard', '-z']).decode().split('\0')) - {''})
    return {
        'head': git('rev-parse', 'HEAD'),
        'tree': git('rev-parse', 'HEAD^{tree}'),
        'status': git('status', '--porcelain=v1', '--untracked-files=all'),
        'canonical_files': [item(ROOT / p, p) for p in names],
        'selected_161': [item(ROOT / row['path'], row['path']) for row in inputs],
        'protected_44': [item(ROOT / row['path'], row['path']) for row in protected],
        'overlays_7': [item(DERIVATIVE / row['path'], row['path']) for row in handoff['derivative_only_overlays']],
        'derivative_all_163': [item(Path(row['path']), row['path']) for row in correction['files']],
    }

repair_path = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/w09-sdk-namespace-repair-v1/result.json')
repair = json.loads(repair_path.read_text())
assert repair['pass'] is True and repair['all_owned_descriptors_closed'] is True
assert repair['script_sha256'] == '5aa2c18aca3a8f2122857e380a078168f27c8cc343f242984719ccadf0d5aa2d'
assert repair['before']['ino'] == 323964303 and repair['before']['uid'] == 501 and repair['before']['mode'] == 0o755
assert repair['after']['ino'] == 323964303 and repair['after']['uid'] == 501 and repair['after']['mode'] == 0o700
assert repair['after'] == repair['named_after']
write('environment-repair-bridge.json', {'scope': 'SEPARATELY_AUTHORIZED_SECOND_ATTEMPT_AFTER_REVIEWED_EXACT_OWNED_NAMESPACE_MODE_REPAIR', 'repair_result': item(repair_path, str(repair_path)), 'original_actor_result': item(BASE / 'actor-v3/result.json', 'actor-v3/result.json'), 'original_actor_proof_manifest': item(BASE / 'ACTUAL-SDK-PROOF-MANIFEST.json', 'ACTUAL-SDK-PROOF-MANIFEST.json')})

before = snapshot()
assert before['head'].startswith('204bc06'), before['head']
assert before['tree'].startswith('5b5bfeda'), before['tree']
assert not before['status'], before['status']
assert len(before['canonical_files']) == 2070
assert before['selected_161'] == inputs
assert before['protected_44'] == protected
assert len(before['protected_44']) == 44
for row, actual in zip(handoff['derivative_only_overlays'], before['overlays_7']):
    expected = row['after'] if not row['path'].endswith('/sdk_probe_driver.rs') else {k: correction['driver_after'][k] for k in ['bytes', 'sha256', 'mode']}
    assert {k: actual[k] for k in ['bytes', 'sha256', 'mode']} == expected
    if row['before'] and row['path'].endswith('.rs'):
        assert (DERIVATIVE / row['path']).read_bytes().startswith((ROOT / row['path']).read_bytes())
binary = TARGET / 'debug/sdk_paths_probe'
compile_result = json.loads((BASE / 'compile-v3/result.json').read_text())
assert compile_result['exit_code'] == 0 and compile_result['before_after_exact_equal']
assert compile_result['owned_group_after_reap_observation'] == 'ABSENT'
assert compile_result['signals'] == []
binary_before = item(binary, str(binary))
assert binary_before == compile_result['binary']
write('before.json', before)
argv = [str(binary), '--initialize-app-owned-roots']
write('command.json', {'argv': argv, 'cwd': str(CRATE), 'timeout_seconds': 60,
    'output_cap_bytes': 262144, 'binary': binary_before,
    'scope': 'ONE_ACTUAL_WRY_SDK_ACTOR_NO_WINDOW_NO_SERVICE_NOT_GUI_PROOF',
    'observer': item(Path(__file__), 'actor-observer.py')})
started = time.monotonic()
signals = []
reason = None
with (OUT / 'sdk.stdout.log').open('wb') as stdout, (OUT / 'sdk.stderr.log').open('wb') as stderr:
    child = subprocess.Popen(argv, cwd=CRATE, stdout=stdout, stderr=stderr, start_new_session=True)
    pgid = os.getpgid(child.pid)
    assert pgid == child.pid
    write('started.json', {'pid': child.pid, 'pgid': pgid, 'started_monotonic': started,
        'scope': 'ONE_AUTHORIZED_OWNED_SDK_CHILD'})
    print(json.dumps({'sdk_actor_started': child.pid, 'owned_pgid': pgid}), flush=True)
    while True:
        exit_code = child.poll()
        if exit_code is not None:
            break
        elapsed = time.monotonic() - started
        output_bytes = (OUT / 'sdk.stdout.log').stat().st_size + (OUT / 'sdk.stderr.log').stat().st_size
        if elapsed > 60 or output_bytes > 262144:
            reason = 'TIMEOUT' if elapsed > 60 else 'OUTPUT_CAP'
            os.killpg(pgid, signal.SIGTERM)
            signals.append({'signal': 'SIGTERM', 'elapsed': elapsed})
            until = time.monotonic() + 2
            while time.monotonic() < until:
                exit_code = child.poll()
                if exit_code is not None:
                    break
                time.sleep(0.05)
            if exit_code is None:
                os.killpg(pgid, signal.SIGKILL)
                signals.append({'signal': 'SIGKILL', 'elapsed': time.monotonic() - started})
                exit_code = child.wait(timeout=5)
            break
        time.sleep(0.05)
try:
    os.killpg(pgid, 0)
except ProcessLookupError:
    group = 'ABSENT'
except PermissionError:
    group = 'EXISTS_NO_PERMISSION'
else:
    group = 'EXISTS'
after = snapshot()
write('after.json', after)
binary_after = item(binary, str(binary))
result = {'scope': 'ACTUAL_WRY_SDK_ACTOR_NOT_GUI_PACKAGE_FULL_APP_QUIT_PROOF',
    'exit_code': exit_code, 'elapsed_seconds': time.monotonic() - started,
    'limit_reason': reason, 'signals': signals, 'direct_child_reaped': child.returncode is not None,
    'owned_group_after_reap_observation': group, 'before_after_exact_equal': before == after,
    'canonical_selected_161_unchanged': before['selected_161'] == after['selected_161'],
    'canonical_all_2070_unchanged': before['canonical_files'] == after['canonical_files'],
    'protected_44_unchanged': before['protected_44'] == after['protected_44'],
    'derivative_overlays_7_unchanged': before['overlays_7'] == after['overlays_7'],
    'binary_before': binary_before, 'binary_after': binary_after, 'binary_unchanged': binary_before == binary_after,
    'stdout': item(OUT / 'sdk.stdout.log', 'sdk.stdout.log'),
    'stderr': item(OUT / 'sdk.stderr.log', 'sdk.stderr.log')}
write('result.json', result)
print(json.dumps(result, indent=2), flush=True)
raise SystemExit(0 if exit_code == 0 and reason is None and before == after and binary_before == binary_after and group == 'ABSENT' else 1)
