"""One guarded development-environment permission tightening; no product policy change."""
from pathlib import Path
from datetime import UTC,datetime
import hashlib,json,os,stat,sys

BASE=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
RAW=BASE/'w09-sdk-proof-preparation/actor-v3/sdk.stdout.log'
OUT=BASE/'w09-sdk-namespace-repair-v1'
BUNDLE='dev.jobapply.desktop'
EXPECTED_RAW='b818202b041fd60468870f06dfe643206b083affb973a0e2bab9e3823529ca94'

def view(s):
    return {'dev':s.st_dev,'ino':s.st_ino,'uid':s.st_uid,'gid':s.st_gid,'mode':stat.S_IMODE(s.st_mode),'directory':stat.S_ISDIR(s.st_mode)}

def main():
    # An explicit root-review release is required for this one exact script.
    if sys.argv[1:]!=['--root-reviewed-tighten-own-namespace']:
        raise SystemExit('No permission mutation requested')
    OUT.mkdir(exist_ok=False)
    source=Path(__file__).read_bytes()
    (OUT/'executed-driver.py').write_bytes(source)
    raw=RAW.read_bytes();raw_hash=hashlib.sha256(raw).hexdigest()
    assert raw_hash==EXPECTED_RAW
    rows=[json.loads(line) for line in raw.decode().splitlines()]
    first=next(r['data'] for r in rows if r['stage']=='sdk_roots_and_fixed_before')
    expected=first['fixed_metadata'][4]
    path=Path(expected['path'])
    assert expected['kind']=='directory' and expected['mode']==0o755
    assert expected['uid']==os.getuid()==os.geteuid()==501
    assert path==Path(first['sdk_temp'])/BUNDLE
    assert path.parts[:3]==('/','var','folders') and path.name==BUNDLE
    physical=Path('/private/var').joinpath(*path.parts[2:])
    assert physical.parts[-2]=='T'
    record={'start_utc':datetime.now(UTC).isoformat(),'actor_raw_sha256':raw_hash,'script_sha256':hashlib.sha256(source).hexdigest(),'path':str(path),'physical_no_follow_chain':str(physical),'scope':'Tighten only the exact prior-observed current-user-owned application temp namespace from0755 to0700. Existing content is never listed/read/deleted. No product path-policy change. No hostile same-UID atomicity claim.'}
    (OUT/'started.json').write_text(json.dumps(record,indent=2)+'\n')
    fds=[]
    try:
        flags=os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
        fd=os.open('/',flags);fds.append(fd)
        for part in physical.parts[1:-1]:
            fd=os.open(part,flags,dir_fd=fd);fds.append(fd)
        parent=fd;parent_info=os.fstat(parent)
        assert stat.S_ISDIR(parent_info.st_mode) and parent_info.st_uid==501 and stat.S_IMODE(parent_info.st_mode)==0o700
        held=os.open(BUNDLE,flags,dir_fd=parent);fds.append(held)
        before=os.fstat(held);named=os.stat(BUNDLE,dir_fd=parent,follow_symlinks=False)
        expected_view={k:expected[k] for k in ['dev','ino','uid','gid','mode']}
        assert {k:view(before)[k] for k in expected_view}==expected_view
        assert view(named)==view(before) and stat.S_ISDIR(before.st_mode)
        record.update(before=view(before),parent=view(parent_info),mutation='fchmod on held no-follow directory descriptor only')
        # This exact product-owned directory is the sole mutation target.
        os.fchmod(held,0o700)
        after=os.fstat(held);named_after=os.stat(BUNDLE,dir_fd=parent,follow_symlinks=False)
        record.update(after=view(after),named_after=view(named_after))
        assert view(after)==view(named_after)
        assert after.st_dev==before.st_dev and after.st_ino==before.st_ino and after.st_uid==before.st_uid and after.st_gid==before.st_gid
        assert stat.S_IMODE(after.st_mode)==0o700
        record['pass']=True
    finally:
        for descriptor in reversed(fds):os.close(descriptor)
        record['end_utc']=datetime.now(UTC).isoformat()
        record['all_owned_descriptors_closed']=True
        (OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record,indent=2))

if __name__=='__main__':main()
