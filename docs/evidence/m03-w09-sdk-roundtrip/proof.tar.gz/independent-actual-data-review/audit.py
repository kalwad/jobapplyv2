"""Read-only actual SDK receipt, finite archive and five-file proposal review."""
import hashlib,json,tarfile,stat
from pathlib import Path

BASE=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
SDK=BASE/'w09-sdk-proof-preparation'
PROPOSAL=BASE/'w09-sdk-positive-metadata-proposal'
DOC=PROPOSAL/'after/docs/evidence/m03-w09-sdk-roundtrip'
SOURCE=PROPOSAL/'proof-source'
REPAIR=BASE/'w09-sdk-namespace-repair-v1'
POS=SDK/'actor-v3-after-owned-namespace-repair'
OUT=BASE/'sdk-positive-evidence-review'
checks=[]
def digest(data):return hashlib.sha256(data).hexdigest()
def sha(path):return digest(path.read_bytes())
def load(path):return json.loads(path.read_text())
def check(name,ok):checks.append({'name':name,'pass':bool(ok)})
plan=load(PROPOSAL/'PLAN.json')
for row in plan['changes']:
 p=PROPOSAL/'after'/row['path']
 check('five-file-addition:'+row['path'],row['action']=='ADD_ONLY' and row['before'] is None and row['path'].startswith('docs/evidence/m03-w09-sdk-roundtrip/') and p.stat().st_size==row['after']['bytes'] and sha(p)==row['after']['sha256'] and stat.S_IMODE(p.stat().st_mode)==row['after']['source_mode'])
check('exactly-five-documentation-additions',len(plan['changes'])==5)
summary=load(DOC/'summary.json');artifact=load(DOC/'artifact.json');manifest=load(DOC/'retention-manifest.json')
archive=DOC/'proof.tar.gz'
check('archive-artifact-exact-hash-size',sha(archive)==artifact['archive']['sha256']=='a3f5fb1020682349c94f7349e60f21f40c2b6610e8357753af33cf178a844ed5' and archive.stat().st_size==artifact['archive']['bytes']==1842950)
members={}
with tarfile.open(archive,'r:gz') as tf:
 for member in tf.getmembers():
  check('safe-archive-member:'+member.name,member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts and member.name not in members and member.name in manifest['members'] and member.mode & 0o111==0)
  stream=tf.extractfile(member)
  assert stream is not None
  data=stream.read();members[member.name]=data;r=manifest['members'][member.name]
  check('archive-manifest-source-join:'+member.name,len(data)==r['bytes'] and digest(data)==r['sha256'] and (SOURCE/member.name).is_file() and not (SOURCE/member.name).is_symlink() and data==(SOURCE/member.name).read_bytes() and stat.S_IMODE((SOURCE/member.name).stat().st_mode)==r['source_mode'])
check('finite387-exact-retention-set',set(members)==set(manifest['members']) and len(members)==manifest['safe_regular_members']==artifact['safe_regular_members']==plan['archive_safe_regular_members']==387 and sum(map(len,members.values()))==manifest['archive_member_bytes']==7881702)

def archived(name):return json.loads(members[name])
before,after=load(POS/'before.json'),load(POS/'after.json')
result=load(POS/'result.json');command=load(POS/'command.json')
check('positive-endpoints-exact-unchanged',before==after and before['head']==summary['evaluated_head']=='204bc06a374631f4b40d4fc382f573a77ef9242a' and before['tree']==summary['evaluated_tree']=='5b5bfeda09b60654adce335e0e21cd9ad056e120' and before['status']=='')
for key,count in [('canonical_files',2070),('selected_161',161),('protected_44',44),('overlays_7',7),('derivative_all_163',163)]:
 check('exact-endpoint-cardinality:'+key,len(before[key])==count)
for row in before['selected_161']:
 name='canonical-selected-inputs/'+row['path']
 check('actual-selected-canonical-projection:'+row['path'],name in members and len(members[name])==row['bytes'] and digest(members[name])==row['sha256'])
for row in before['derivative_all_163']:
 relative=Path(row['path']).relative_to(SDK/'derivative-v3');name='sdk-preparation/derivative-v3/'+str(relative)
 check('actual-derivative-projection:'+str(relative),name in members and len(members[name])==row['bytes'] and digest(members[name])==row['sha256'])
for filename in ['before.json','after.json','command.json','result.json','sdk.stdout.log','sdk.stderr.log','environment-repair-bridge.json','actor-observer.py']:
 check('exact-positive-original:'+filename,members['sdk-preparation/actor-v3-after-owned-namespace-repair/'+filename]==(POS/filename).read_bytes())
check('positive-summary-exact-actual-result',summary['positive_actor']==result and result['exit_code']==0 and result['elapsed_seconds']==0.40081191703211516 and result['limit_reason'] is None and result['signals']==[] and result['direct_child_reaped'] is True and result['owned_group_after_reap_observation']=='ABSENT')
binary=result['binary_before'];compiled=load(SDK/'compile-v3/result.json')['binary']
check('same-exact-previous-binary',binary==result['binary_after']==compiled==command['binary']==artifact['binary_retained_external'] and binary['bytes']==33137024 and binary['sha256']=='7ca2f08f95f8aca8beea2afd1edb831b5b1f9be7230b6e1de70fb0de4d71d296' and sha(Path(binary['path']))==binary['sha256'])
check('exact-actor-observer-command-bound',command['observer']['sha256']==sha(POS/'actor-observer.py') and command['argv']==[binary['path'],'--initialize-app-owned-roots'] and command['timeout_seconds']==60)
for stream in ['stdout','stderr']:
 p=POS/result[stream]['path'];check('actual-stream-binding:'+stream,p.stat().st_size==result[stream]['bytes'] and sha(p)==result[stream]['sha256'])
rawrows=[json.loads(line) for line in (POS/'sdk.stdout.log').read_text().splitlines()]
check('actual-stage-list-exact',summary['actual_positive_stages']==[r['stage'] for r in rawrows])
def stage(name):return next(r['data'] for r in rawrows if r['stage']==name)
ready=stage('actual_wry_ready')
check('actual-Wry-main-thread-no-service-scope',ready['runtime']=='tauri::Wry' and ready['tauri_version']=='2.12.4' and ready['bundle_id']=='dev.jobapply.desktop' and ready['main_thread'] is True and ready['configured_auto_create_windows']==ready['observed_webview_windows']==0 and ready['mock_runtime'] is False and ready['production_service_started'] is False)
fixed=stage('sdk_roots_and_fixed_before')['fixed_metadata'];final=stage('final')
check('all-fixed-metadata-exactly-unchanged',fixed==final['fixed_after'])
retained=stage('temporary_retained_before_release');released=stage('temporary_released');dropped=stage('dropped_outcome_still_retained')
check('real-explicit-release-owned-before-absent-after',retained['issued_entries']==1 and retained['pending_cleanup'] is True and len(retained['temporary_paths'])==2 and [p['path'] for p in released['named_paths_after']]==retained['temporary_paths'] and all(p['kind']=='missing' for p in released['named_paths_after']) and released['owner']['issued_entries']==0 and released['owner']['pending_cleanup'] is False and released['owner']['temporary_paths']==[])
check('dropped-outcome-separately-retained',dropped['issued_entries']==1 and dropped['pending_cleanup'] is True and len(dropped['temporary_paths'])==2 and not set(dropped['temporary_paths']) & set(retained['temporary_paths']))
check('positive-final-same-path-owner-cleanup-settled',final['pass'] is True and final['work']=={'Ok':None} and final['cleanup']=={'Ok':None} and final['persistent_metadata_invariants']=={'Ok':None} and final['known_owned_temp_names_absent'] is True and final['owner']['Ok']['issued_entries']==0 and final['owner']['Ok']['pending_cleanup'] is False and final['owner']['Ok']['temporary_paths']==[] and final['work_stays_revoked'] is True and final['gui_proof'] is False and final['native_package_proof'] is False and final['service_start_called'] is False)
persist=[r['data'] for r in rawrows if r['stage']=='persistent_resolved'];refused=[r['data'] for r in rawrows if r['stage']=='persistent_release_refused']
check('two-positive-persistent-roles-and-release-refusals',len(persist)==len(refused)==2 and {r['role'] for r in persist}=={'APPLICATION_DATA','CACHE'} and all(r['view']['resolution_state']=='RESOLVED' and r['view']['writable'] is True for r in persist) and all(r['reason']=='POLICY' for r in refused))
repair=load(REPAIR/'result.json');bridge=load(POS/'environment-repair-bridge.json')
check('repair-summary-exact-original',summary['repair']==repair and sha(REPAIR/'result.json')==bridge['repair_result']['sha256']=='1f6f796550c4cb42cdee20d0aa6d809453cf8cecf448583a6123a6630893323a')
check('reviewed-repair-driver-bound',repair['script_sha256']==sha(REPAIR/'executed-driver.py')==sha(BASE/'repair-owned-sdk-temp-permission.py')=='5aa2c18aca3a8f2122857e380a078168f27c8cc343f242984719ccadf0d5aa2d')
check('repair-same-identity-only-mode-tightening',repair['pass'] is True and repair['all_owned_descriptors_closed'] is True and repair['after']==repair['named_after'] and all(repair['before'][k]==repair['after'][k] for k in ['dev','ino','uid','gid','directory']) and repair['before']['mode']==0o755 and repair['after']['mode']==0o700 and repair['parent']['uid']==repair['after']['uid']==501 and repair['parent']['mode']==0o700)
originalrows=[json.loads(line) for line in (SDK/'actor-v3/sdk.stdout.log').read_text().splitlines()]
original_fixed=next(r['data'] for r in originalrows if r['stage']=='final')['fixed_after']
check('cross-attempt-environment-bridge-only-temp-mode',all(original_fixed[i]==fixed[i] for i in range(4)) and all(original_fixed[4][k]==fixed[4][k] for k in ['dev','ino','uid','gid','kind','path']) and original_fixed[4]['mode']==0o755 and fixed[4]['mode']==0o700)
for phase,expected in [('compile-v1',101),('compile-v2',101),('compile-v3',0),('actor-v3',1)]:
 p=SDK/phase/'result.json';value=load(p)
 check('historical-attempt-exact-preserved:'+phase,members['sdk-preparation/'+phase+'/result.json']==p.read_bytes() and value['exit_code']==expected)
check('original-failure-bridge-hash',sha(SDK/'actor-v3/result.json')==bridge['original_actor_result']['sha256'] and sha(SDK/'ACTUAL-SDK-PROOF-MANIFEST.json')==bridge['original_actor_proof_manifest']['sha256'])
check('review-not-preclaimed-or-milestone-promoted',summary['independent_actual_data_review']==artifact['review']==plan['review']=='PENDING_SEPARATE_REVIEW_NOT_CLAIMED' and summary['milestone_state']=={'M03-W06':'IN_PROGRESS','M03':'IN_PROGRESS','verified_work_packages':38,'M05':'NOT_STARTED','release':'NOT_READY'})
check('observer-direct-fstat-claim-explicitly-excluded','No direct exported held-FD fstat receipt.' in summary['observer_metadata_limit'] and b'does not directly export/fstat held descriptors' in members['POSITIVE-AUTHOR-CLOSURE.md'])
doc={'scope':'Read-only finite proposal/archive/original actual receipts, source-projection hashes, endpoint/repair/stage joins; no actor, namespace-content inspection or canonical write','verdict':'CLEAR_FOR_SCOPED_ACTUAL_SDK_EVIDENCE_INTEGRATION','checks':checks,'passed':sum(r['pass'] for r in checks),'total':len(checks),'failed':[r['name'] for r in checks if not r['pass']],'proposal_plan_sha256':sha(PROPOSAL/'PLAN.json'),'archive_sha256':sha(archive),'milestone_or_platform_or_release_promotion':False}
(OUT/'checks.json').write_text(json.dumps(doc,indent=2)+'\n')
print(json.dumps({k:doc[k] for k in ['verdict','passed','total','failed']},indent=2))
raise SystemExit(bool(doc['failed']))
