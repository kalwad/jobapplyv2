# Revision 7 history and retained-evidence subreview

No actionable finding in this scope. This is read-only supplemental metadata review, not execution approval, W15 approval, or Gate A approval. Config/coordinator/worker behavior and current 355-file runtime verification belong to the parent review.

Reviewed proposal: `/tmp/japp-w14-paired-revision7/revision7-proposal.patch`, SHA-256 `5ba19e736829b844300009e426ffba5a40be183e4e20a8d25505f95154bdec6c`.

Verified facts:

- All six revision 6 history additions (`campaign.lock.json`, sidecar, `predeclaration.json`, `source-bindings.json`, `playwright.config.ts`, `PREEXECUTION.md`) equal the current root revision 6 files and proposal source preimages byte for byte. Their manifest SHA-256 values and byte lengths match.
- Old revision 6 lock `sha256:47b6fe33c9e68d8aed9815f2cd35887e289a0e93fbf27045a059e467d35fe6fb` and its sidecar match; all 47 old payload hashes verify. Proposed revision 7 lock `sha256:e5b9a8dd4163a6f3c9e61782ef808692ebf65da0997fdfdb486d77e671b50042` and sidecar match; all 53 proposed payload hashes verify.
- Comparing complete campaign copies finds exactly six changed current files and six added revision 6 history files, with no deletion or other changed campaign byte. Revision 3/4/5 histories and both actor implementations/source-control assertions remain unchanged.
- Inputs `sha256:2d1ce7ba5acf2414f5936b47055e9afd412ffbee0f8a247cd2c6f583548c3812`, oracles `sha256:96a9fa8780c4b0c5bee78edf9f0b721ea171c598ef3e9cd89cd33ddf8ccb3626`, and projections `sha256:7c7cd5d546aee296ddaa50455b95b4baf7c32e2984ba1df53ddacf5c445531ed` equal root bytes. Frozen case declarations and source preimages remain equal.
- All 31 declared legacy source files match their hashes against `/tmp/japp-legacy-cleanroom.ByLBQU`; their declarations and identity are unchanged. The symmetric observer declaration is unchanged, and its actual helper remains `sha256:9000acd4227e906f9f7b0063dab5a39e7aa2187a226bdb82df530e6e2a329a49`.
- The retained comparison archive remains `sha256:017c88bd23b00158870d1cb23c5369b8ee32fc3d86f18ce737fef5f87ae79e5d` (1,399,137 bytes). All 32 externally declared payload members verify, and the exposed comparison worksheet is byte-identical to its archive member.
- The four archived candidate observations, four legacy results, and four-case worksheet all bind the old revision 6 lock. Both actors identify archived source bindings `sha256:34930423d1a3bcf37165c3894718328f337dee45a0563cb73ea6ed1d0ef7db10`. Each candidate's equal start/end bindings record the exact archived runtime inventory and all 49 revision 6 campaign files, including the configuration and checklist, with no hash discrepancy.
- Proposed declaration changes explicitly identify revision 6's actual results as historical and require fresh revision 7 actor execution. The worksheet remains authority `NONE`, `gate_pass: false`, and `acceptance: null`; no retained outcome has been relabeled as revision 7 evidence.

No tests, builds, browsers, servers, candidate actors, legacy actors, root edits, proposal edits, or ignored-output writes were performed. Only this outside-root review report was written.
