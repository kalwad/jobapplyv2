# Revision 7 proposal — source preparation only

No browser, build, server, candidate actor or legacy actor has run for revision 7. No root or existing worktree file was modified by this authoring task. Separate read-only review is pending.

Apply only the reviewed `revision7-proposal.patch` after comparing all root preimages to `source-manifest.json`. The patch modifies six current metadata/configuration files and adds six exact revision 6 files under `preexecution-history/revision-6/`. `proposed/` is an outside-root campaign copy for inspection, not an executed checkout.

The original revision 6 lock remains `sha256:47b6fe33c9e68d8aed9815f2cd35887e289a0e93fbf27045a059e467d35fe6fb`. Its actual candidate 4 / legacy 4 results remain historical under that lock. The new revision 7 lock is `sha256:e5b9a8dd4163a6f3c9e61782ef808692ebf65da0997fdfdb486d77e671b50042`; its 53 payload paths include the exact preserved history. The new lock sidecar is derived from the complete serialized lock; no outcome is inherited.

The production inventory helper independently captures and validates 355 runtime files at `sha256:c3757409d0e43b12e517eae863e4985d8a509273dd45b86f59a5bfb8478cc89c`. Exactly two current runtime hashes differ from revision 6: driver-engine.ts becomes `sha256:749b00ac70478f94d8e78779e39f973475ba8d6ee003cb9a68ad1e3b623f2382`, and drivers/driver-dom.ts becomes `sha256:8256c4ec3893d3f3e9671715c3f5f5b736f59f6600cdbaeb9d520d2068d695bc`.

Inputs `2d1ce7ba…`, oracle `96a9fa87…`, projection `7c7cd5d5…`, all 31 declared legacy/vendor sources, the symmetric native observer, prior history, actor code and source/control assertions are byte-identical. The config adds only a declaration guard for source revision 7 and the exact revision 6 predecessor lock. Removing that inserted guard and readFileSync import addition reproduces the original config exactly, including coordinator freshness and worker reread logic.

Read-only checks performed: every old revision 6 lock payload SHA; old lock SHA/sidecar; all three frozen data SHAs; all 31 vendor SHAs; observer SHA; production captureRuntimeInventory and assertRuntimeInventory against proposed bindings; proposed predeclaration digest; every one of 53 proposed lock payload SHAs; exact history copies; root campaign unchanged after preparation. No test outcomes or final approval are claimed.

The historical revision 3 authoring tool remains unchanged and deliberately refuses later locks; this proposal was authored outside root instead of weakening that tool's old-lock guard. Root should obtain separate review, integrate and commit exact source/metadata, freshly build the default extension, then actually run candidate 4 and legacy 4 under the independently retained new lock with fresh output directories. Use the existing pinned Python 3.12.13 / 13-dependency legacy runtime without installation. Preserve partial/failure artifacts and keep the old comparison archive unchanged.
