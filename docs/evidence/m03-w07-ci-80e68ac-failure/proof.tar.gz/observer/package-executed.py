from pathlib import Path
import datetime
import hashlib
import io
import json
import stat
import tarfile

E=Path(__file__).parent; C=E/'ci-80e68ac'; O=E/'m03-w07-ci-80e68ac-failure-evidence-v1';O.mkdir()
files={}
def add(p,n):
    assert stat.S_ISREG(p.lstat().st_mode) and n not in files
    files[n]=p
def tree(p,n):
    for q in sorted(p.rglob('*')):
        if q.is_dir() and not q.is_symlink():continue
        add(q,n+'/'+q.relative_to(p).as_posix())
for n in ['collector-context.json','collector-closure.json','collector-executed.py','terminal-run.json','terminal-jobs.json','official-logs.zip','api-receipts.json','log-members.json','checkout-source-bindings.json','immutable-git-source-sha256.json','immutable-source-api-join.json','head-commit.json','head-tree.json']:
    add(C/n,'hosted/'+n)
for folder in ['closed-jobs','source-bindings','artifact-lists']:
    tree(C/folder,'hosted/'+folder)
for p in sorted((C/'artifacts').glob('*.json')):add(p,'hosted/artifacts/'+p.name)
tree(E/'ci-80e68ac-independent-review','independent')
for artifact,names in {
    '12911338406':['runtime-build/builder-executed.py','runtime-build/build-proof.json','runtime-build/06-native-build.stdout','runtime-build/06-native-build.stderr','worker/ci-result.json','worker/pipeline.result.json'],
    '12911479368':['pipeline/15-package-actor.stderr','pipeline/15-package-actor.stdout','pipeline/15-package-actor.result.json','worker/ci-result.json','worker/pipeline.result.json'],
}.items():
    for n in names:add(C/'artifacts'/(artifact+'-contents')/n,'selected-original-failure/'+artifact+'/'+n)
add(Path(__file__),'observer/package-executed.py')
rows=[]
with tarfile.open(O/'proof.tar.gz','w:gz') as a:
    for n,p in sorted(files.items()):
        s=p.lstat();data=p.read_bytes();assert len(data)==s.st_size
        m=tarfile.TarInfo(n);m.size=len(data);m.mode=stat.S_IMODE(s.st_mode);a.addfile(m,io.BytesIO(data))
        rows.append({'path':n,'source_path':str(p),'bytes':len(data),'mode':m.mode,'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(O/'proof.tar.gz','r:gz') as a:
    members=a.getmembers();assert len(members)==len(rows)
    for m,r in zip(members,rows,strict=True):
        stream=a.extractfile(m);assert stream is not None;data=stream.read()
        assert m.isfile() and m.name==r['path'] and m.mode==r['mode'] and len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
        p=Path(r['source_path']);assert p.read_bytes()==data and stat.S_IMODE(p.stat().st_mode)==r['mode']
def dump(n,x):(O/n).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
p=O/'proof.tar.gz';dump('artifact.json',{'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
dump('retention-manifest.json',{'members':rows,'regular_members':len(rows),'original_bytes_full_modes_and_archive_equal':True,'omissions':['Full2187immutableGit source bodies and all runtime/package payloads','Two original package artifact ZIP bodies and complete unpacked640member bodies remain durable in original CI collector; exact API ZIP digest and every member map retained here.']})
dump('summary.json',{'created_utc':datetime.datetime.now(datetime.UTC).isoformat(),'run':40898412173,'attempt':1,'head':'80e68ac9a24cd7ebf2874af625b866a055b9abe6','tree':'3ce188444df26df24a9cc24b112c4d0ab03e892b','actual_tested_merge':'6f54aa9e09b6c7356dc00d73469c411ef8bd60b8','conclusion':'failure','canonical_each_active_suites_pass':20,'typescript_each':4006,'python':{'macos':2141,'ubuntu':2141,'windows':2139},'native_unique_cases_each_three_modes':{'macos':342,'ubuntu':338,'windows':316},'native_package':{'windows':'FAILURE:PyInstaller import Path.home missing scrubbed home, before app/service actor','ubuntu':'FAILURE:0PASS1FAIL; actual owned packaged service health/auth/shutdown reached, immediate stdTcpListener rebind AddrInUse after cleanup success; old cause UNKNOWN'},'independent_data_checks':5720,'independent_verdict':'CLEAR_AS_RECORDED_FAILURE','native_platform_certification_or_work_package_promotion':False})
(O/'README.md').write_text('''# Three-platform aggregate pass and separate native package failures

Original run40898412173/attempt1 at80e68/tree3ce18844 is terminal FAILURE.
All three canonical jobs succeed with all20ACTIVE suites PASS and4006fresh
TypeScript cases each. Python Mac2141PASS863.51s, Ubuntu2141PASS611.55s,
Windows2139PASS1068.69s (two POSIX-only cases absent by declared inventory).
Native unique sets Mac342/Ubuntu338/Windows316 each pass in all three modes.
Actual tested merge6f54aa9e shares the exact2187-file source tree; it is not
relabeled as the API head. Different5720 data checks CLEAR these recorded
outcomes at report7bc52397. All five complete job logs join official log ZIP.

The separate Windows native-package job123566716686 fails before native app
production: PyInstaller6.22.3 imports WinExcludeList, Python Path.home raises
Could not determine home directory under the exact eight-key scrubbed build
environment. Job123566716778 on Ubuntu completes runtime/app build, catalog
and static inspection and reaches the actual owned packaged-service test.
The actor records cleanup success221ms within the unchanged6000ms policy,
then panics at package_validation.rs149 because immediate plain TcpListener
rebind returns AddrInUse/OS98. Its original result is exit101,0PASS1FAIL,
338filtered,4.267s; session and members absent, keeper reaped, no cleanup
error or signals. That record does not establish TIME_WAIT, a residual owner
or an external collision as the cause. Both worker outcomes remain
PREPARATION_INCOMPLETE. Neither package is passed or certified.

Proof retains exact official logs, original source/API/checkout and artifact
metadata, selected original failure records and independent data review.
Original Windows81.27MB/205-member and Ubuntu258.38MB/435-member artifact ZIPs
and payload bodies remain outside this compact archive, hash-bound by the
retained API/member manifests. No whole-payload canonical retention is claimed.
All selected regular bytes/full modes and archive members join exactly.
No later correction, Windows11 desktop, defaultGNOME GUI, M03 acceptance,
final visual baseline or release readiness follows from these results.
''')
print(json.dumps({'packet':str(O),'members':len(rows),'proof_bytes':p.stat().st_size,'proof_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
