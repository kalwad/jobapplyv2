# Fixed80e68 CI retained-data review

**CLEAR as recorded, 5,720/5,720 retained-data checks. The overall CI result is FAILURE.** This review executed only a standard-library data observer over retained API responses, logs and archives. It did not import repository modules, execute downloaded files, run a product actor, modify canonical files, cancel or rerun CI.

Run [40898412173](https://github.com/kalwad/jobapplyv2/actions/runs/40898412173), attempt1, completed with all three canonical jobs successful and both native package jobs failed. Exact run head is `80e68ac9a24cd7ebf2874af625b866a055b9abe6`, tree `3ce188444df26df24a9cc24b112c4d0ab03e892b`, 2,187 Git blobs. All five actual checkout logs bind merge `6f54aa9e09b6c7356dc00d73469c411ef8bd60b8`, whose tree equals that head tree and whose parents include that head. The immutable map matches the official API blob OIDs, modes and sizes.

| Hosted job | Canonical suites | Ordinary Python | Native tests in each of three modes |
|---|---:|---:|---:|
| Windows2025,123533749306 |20 ACTIVE PASS|2,139 PASS/1,068.69s|316 PASS|
| Ubuntu24.04,123533749595 |20 ACTIVE PASS|2,141 PASS/611.55s|338 PASS|
| macOS15,123533749839 |20 ACTIVE PASS|2,141 PASS/863.51s|342 PASS|

Each canonical job also retains 4,006 passing TypeScript tests in15 fresh tasks/zero cache, ordinary Playwright summaries278 browser/2 controlled public/62 contact/17 visual, native unit1 and contract10. These are observations for80e68; the later browser fixture and GNOME source changes receive no validation credit from this run.

Windows native job123566716686 failed at `pipeline/09-native-runtime`. The retained PyInstaller traceback calls `pathlib.Path.home().resolve()` and ends `RuntimeError: Could not determine home directory.` The exact retained builder has a scrubbed build environment without `HOME`, `USERPROFILE`, `HOMEDRIVE` or `HOMEPATH`. Its retained executed source matches the immutable Git builder body. This failure precedes later package and service actor stages.

Ubuntu native job123566716778 completed native runtime build, Tauri package build, static archive inspection, extraction, actor compile and catalog with exit0. Its separately invoked single owned package service test failed0 PASS/1 FAIL, exit101. The test reported `PACKAGE_OWNED_CLEANUP success=true elapsed_ms=221 policy_wait_bound_ms=6000`, then failed immediate `TcpListener::bind` at the listener release assertion with `AddrInUse`/OS98. Its wrapper records no cleanup error, no signal, absent owned session/members, reaped keeper, no discarded capture bytes and closed readers. The receipt establishes the failed rebinding oracle; listener ownership, TIME_WAIT or external collision causality remains unobserved. Both workers retain `PREPARATION_INCOMPLETE`, clean/equal original2,187 source bodies and full file modes, no GUI claim and no canonical waiver.

The five complete job logs equal their official whole-run ZIP members. Original Windows artifact12911338406 is81,268,800B/SHA256`425a5d94d1106b149801e6e49215eacebddcdcae0752cf58adb915995b7b941b`/205 safe regular members. Original Ubuntu artifact12911479368 is258,382,958B/SHA256`f004fb51eba7acc4e2a1d30202934d5c2351a603ec35a6e287b1a5acf4f02f63`/435 members. Both API archive digests, every ZIP member, every expanded retained member and every declared retention manifest join exactly. Whole-run logs ZIP is1,740,179B/SHA256`06e2f10f58b19fd0d3eb26d5e258cfc74ea76f436191c1676746982f0f8ddb3d`. All originals remain under the sibling `ci-80e68ac` folder; nothing was executed.

The initial expanded reviewer observer used an incorrect retained label `10-package-build`; its FileNotFoundError and source are preserved in `observer-label-correction.json` and `audit-observer-before-label-correction.py`. Correcting that observer label to the actual `10-tauri-package` and joining extraction yielded the final5,720 checks. This was no product rerun or changed product outcome.

Hosted labels do not establish Windows11 or default GNOME desktop GUI acceptance. No native package acceptance, later-tree transfer, milestone promotion or release readiness is granted. Original07eb failures and its missing browser failure attachments remain separate evidence. The one-shot running-log404 probes are separately retained and do not alter the complete terminal records.
