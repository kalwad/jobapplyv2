"""Read-only retained terminal CI joins; never imports or executes subjects."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import stat
import zipfile

B = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/ci-80e68ac')
O = Path(__file__).parent
HEAD = '80e68ac9a24cd7ebf2874af625b866a055b9abe6'
TREE = '3ce188444df26df24a9cc24b112c4d0ab03e892b'
MERGE = '6f54aa9e09b6c7356dc00d73469c411ef8bd60b8'
RUN = 40898412173
checks = []

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()

def load(name):
    return json.loads((B / name).read_bytes())

def check(name, passed):
    checks.append({'name': name, 'pass': bool(passed)})

def clean(raw):
    text = '\n'.join(re.sub(r'^\d{4}-\d\d-\d\dT[^ ]+ ', '', x) for x in raw.decode().splitlines())
    return re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', text)

run = load('terminal-run.json')
jobs = load('terminal-jobs.json')['jobs']
closure = load('collector-closure.json')
immutable = load('immutable-git-source-sha256.json')
bindings = load('checkout-source-bindings.json')
logs = load('log-members.json')
check('fixed attempt1 terminal failure', run['id'] == RUN and run['head_sha'] == HEAD and run['run_attempt'] == 1 and run['status'] == 'completed' and run['conclusion'] == 'failure')
canonical = [j for j in jobs if j['name'].startswith('doctor + verify (')]
native = [j for j in jobs if j['name'].startswith('native development package (')]
check('all three canonical successes plus two terminal native jobs', len(jobs) == 5 and len(canonical) == 3 and len(native) == 2 and all(j['status'] == 'completed' for j in jobs) and all(j['conclusion'] == 'success' for j in canonical))
pin = bindings[MERGE]
check('exact observed merge2187tree and head parent', pin['same_tree_as_run_head'] and pin['tree'] == TREE == immutable['tree'] and pin['blob_count'] == 2187 == immutable['blob_count'] and HEAD in pin['parents'] and immutable['commit'] == HEAD)
api = {r['path']: r for r in load('head-tree.json')['tree'] if r['type'] == 'blob'}
check('immutable OID mode size API join', set(api) == set(immutable['files']) and all(api[p]['sha'] == r['git_blob'] and api[p]['mode'] == r['git_mode'] and api[p]['size'] == r['bytes'] for p, r in immutable['files'].items()))
results = []
for job in jobs:
    identity = job['id']
    path = B / f'closed-jobs/{identity}.log'
    raw = path.read_bytes()
    plain = clean(raw)
    checkout = re.search(r'log -1 --format=%H\n[^\n]*?\b([0-9a-f]{40})\s*\n', plain)
    check(f'exact actual checkout {identity}', checkout is not None and checkout.group(1) == MERGE)
    check(f'complete official ZIP job equality {identity}', any(r['bytes'] == len(raw) and r['sha256'] == sha(path) and r['path'].endswith(job['name'] + '.txt') for r in logs))
    row = {'id': identity, 'name': job['name'], 'conclusion': job['conclusion'], 'raw_log_bytes': len(raw), 'raw_log_sha256': sha(path)}
    if job in canonical:
        section = plain.split('== verification summary ==\n')[-1]
        suites = re.findall(r'^(\S+)[ \t]+ACTIVE[ \t]+(PASS|FAIL)', section, re.M)
        check(f'exact all20 ACTIVE PASS {identity}', len(suites) == len({r[0] for r in suites}) == 20 and all(r[1] == 'PASS' for r in suites) and 'verification exit code: 0' in section)
        python_count = 2139 if 'windows' in job['name'] else 2141
        py = re.search(r'^=+ ' + str(python_count) + r' passed in ([\d.]+)s[^\n]*=+$', plain, re.M)
        check(f'ordinary Python count {identity}', py is not None)
        unit = plain.split('$ pnpm exec turbo run test --force --concurrency=2 -- --reporter=default\n')[1].split('$ pnpm generate:contracts --check')[0]
        totals = re.findall(r'^(?:@japp/[^:]+:test:)?[ \t]+Tests[ \t]+(\d+) passed \(\d+\)', unit, re.M)
        check(f'actual4006 TS15fresh {identity}', len(totals) == 15 and sum(map(int, totals)) == 4006 and 'Cached:    0 cached, 15 total' in unit)
        for count in [278, 2, 62, 17]:
            check(f'ordinary Playwright summary {count} {identity}', re.search(r'^  ' + str(count) + r' passed \(', plain, re.M) is not None)
        native_count = 316 if 'windows' in job['name'] else 342 if 'macos' in job['name'] else 338
        for count, repeats in [(1, 1), (10, 1), (native_count, 3)]:
            check(f'native ordinary count{count} repeats{repeats} {identity}', len(re.findall(r'^test result: ok\. ' + str(count) + r' passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', plain, re.M)) == repeats)
        row.update({'active_pass_suites': 20, 'python_passed': python_count, 'python_seconds': float(py.group(1)) if py else None, 'unit_ts': 4006, 'unit_ts_fresh_tasks': 15, 'browser_public_contact_visual': [278, 2, 62, 17], 'native_each_three_modes': native_count})
    results.append(row)

artifacts = json.loads(sorted((B / 'artifact-lists').glob('*.json'))[-1].read_bytes())['artifacts']
records = []
native_details = []
for artifact in artifacts:
    identity = artifact['id']
    path = B / f'artifacts/{identity}.zip'
    members = load(f'artifacts/{identity}-members.json')
    digest = sha(path)
    check(f'artifact API size digest {identity}', artifact['size_in_bytes'] == path.stat().st_size and artifact['digest'] == 'sha256:' + digest and not artifact['expired'])
    with zipfile.ZipFile(path) as archive:
        regular = {r.filename.replace('\\', '/'): r for r in archive.infolist() if not r.is_dir()}
        check(f'safe unique ZIP paths {identity}', len(regular) == len(members) and set(regular) == {r['path'] for r in members} and all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and stat.S_IFMT(r.external_attr >> 16) in (0, stat.S_IFREG) for n, r in regular.items()))
        for member in members:
            retained = B / f'artifacts/{identity}-contents' / member['path']
            h = hashlib.sha256()
            with archive.open(member['path']) as stream:
                while chunk := stream.read(1024 * 1024):
                    h.update(chunk)
            check(f'ZIP and retained member {identity}/{member["path"]}', retained.is_file() and not retained.is_symlink() and retained.stat().st_size == member['bytes'] == regular[member['path']].file_size and sha(retained) == member['sha256'] == h.hexdigest())
    record = {'id': identity, 'name': artifact['name'], 'bytes': path.stat().st_size, 'sha256': digest, 'safe_regular_members': len(members)}
    records.append(record)
    if artifact['name'].startswith('native-development-'):
        contents = B / f'artifacts/{identity}-contents'
        manifest = json.loads((contents / 'manifest.json').read_bytes())
        for name, member in manifest['files'].items():
            retained = contents / name
            check(f'native retention manifest {identity}/{name}', retained.is_file() and not retained.is_symlink() and retained.stat().st_size == member['bytes'] and sha(retained) == member['sha256'])
        ci = json.loads((contents / 'worker/ci-result.json').read_bytes())
        check(f'native immutable source preserved {identity}', ci['original_source_bytes_and_modes_equal'] and ci['original_source_clean'] and not ci['gui_claim'] and not ci['canonical_verification_waived'])
        before = json.loads((contents / 'worker/original-source-before.json').read_bytes())
        after = json.loads((contents / 'worker/original-source-after.json').read_bytes())
        check(f'native exact2187 before-after source endpoint {identity}', before == after and before['head'] == MERGE and before['tree'] == TREE and set(before['files']) == set(immutable['files']))
        for name, member in before['files'].items():
            check(f'native immutable Git body size {identity}/{name}', member['sha256'] == immutable['files'][name]['sha256'] and member['bytes'] == immutable['files'][name]['bytes'])
        inputs = json.loads((contents / 'worker/native-inputs.json').read_bytes())
        check(f'native projected source hashes {identity}', inputs['expected_git_head'] == MERGE and all(name in immutable['files'] and digest == immutable['files'][name]['sha256'] for name, digest in inputs['source_projection'].items()))
        native_details.append({'artifact_id': identity, 'name': artifact['name'], 'ci_result': ci, 'paths': sorted(r['path'] for r in members)})

win = next(r for r in native_details if 'windows' in r['name'])
w = B / f'artifacts/{win["artifact_id"]}-contents'
stderr = w / 'runtime-build/06-native-build.stderr'
check('actual Windows PyInstaller Path.home failure', win['ci_result']['status'] == 'PREPARATION_INCOMPLETE' and 'self._home_dir = pathlib.Path.home().resolve()' in stderr.read_text() and 'RuntimeError: Could not determine home directory.' in stderr.read_text())
build = json.loads((w / 'runtime-build/build-proof.json').read_bytes())
check('actual Windows builder retained exact immutable source', build['builder_script_sha256'] == sha(w / 'runtime-build/builder-executed.py') == immutable['files']['scripts/build-windows-runtime.py']['sha256'])
command = next(r for r in build['commands'] if r['label'] == '06-native-build')
check('actual Windows scrubbed builder env lacks home variables', command['exit_code'] != 0 and all(n not in command['environment'] for n in ['HOME', 'USERPROFILE', 'HOMEDRIVE', 'HOMEPATH']))
linux = next(r for r in native_details if 'ubuntu' in r['name'])
l = B / f'artifacts/{linux["artifact_id"]}-contents'
actor = json.loads((l / 'pipeline/15-package-actor.result.json').read_bytes())
actor_stdout = (l / 'pipeline/15-package-actor.stdout').read_text()
actor_stderr = (l / 'pipeline/15-package-actor.stderr').read_text()
check('actual Ubuntu one owned actor FAIL after success cleanup and AddrInUse', linux['ci_result']['status'] == 'PREPARATION_INCOMPLETE' and actor['exit_code'] == 101 and actor['success'] is False and '0 passed; 1 failed; 0 ignored; 0 measured; 338 filtered out' in actor_stdout and 'PACKAGE_OWNED_CLEANUP success=true elapsed_ms=221 policy_wait_bound_ms=6000' in actor_stderr and 'Owned listener must be released: Os { code: 98, kind: AddrInUse' in actor_stderr)
check('actual Ubuntu actor wrapper cleanup closed without signal', actor['cleanup_error'] is None and actor['containment']['signals'] == [] and actor['containment']['session_members_absent'] and actor['containment']['keeper_reaped'] and actor['containment']['session_absent'] and actor['capture']['discarded_bytes'] == 0 and actor['capture']['errors'] == [] and actor['capture']['readers_closed'])
check('actual Ubuntu actor stdout stderr receipt identity', actor['stdout_sha256'] == sha(l / 'pipeline/15-package-actor.stdout') and actor['stderr_sha256'] == sha(l / 'pipeline/15-package-actor.stderr'))
for label in ['09-native-runtime', '10-tauri-package', '11-package-inspect', '12-package-extract', '13-package-actor-compile', '14-package-actor-catalog']:
    receipt = json.loads((l / f'pipeline/{label}.result.json').read_bytes())
    check('actual Ubuntu prior phase PASS ' + label, receipt['exit_code'] == 0 and receipt['success'] and receipt['cleanup_error'] is None)
inspection = json.loads((l / 'deb-inspection/inspection.json').read_bytes())
probe = json.loads((l / 'pipeline/package-probe-input.json').read_bytes())
check('actual Ubuntu static archive scope and actor runtime manifest join', inspection['status'] == 'ARCHIVE_BYTES_PASS_NATIVE_DEPENDENCIES_AND_LIFECYCLE_PENDING' and inspection['runtime_manifest_sha256'] == probe['manifest_sha256'] and probe['target'] == 'x86_64-unknown-linux-gnu')
check('terminal collector retains all five jobs and all artifacts without subject execution', set(closure['downloaded_jobs']) == {j['id'] for j in jobs} and set(closure['downloaded_artifacts']) == {r['id'] for r in records} and closure['run_status'] == 'completed' and closure['run_conclusion'] == 'failure' and closure['no_subject_execution'] and closure['canonical_writes'] == 0)
report = {'scope': 'INDEPENDENT_FIXED80E68_TERMINAL_CI_RETAINED_DATA_REVIEW', 'verdict': 'CLEAR_AS_RECORDED_THREE_CANONICAL20_PASS_WITH_NATIVE_PACKAGE_FAILURE', 'passed_checks': sum(c['pass'] for c in checks), 'total_checks': len(checks), 'checks': checks, 'run': RUN, 'head': HEAD, 'tree': TREE, 'actual_merge': MERGE, 'source_files': 2187, 'jobs': results, 'artifacts': records, 'native_details': native_details, 'native_failures': {'windows': 'PyInstaller import calls Path.home with no home variables in scrubbed builder environment; native runtime build fails before later package/actor stages', 'ubuntu': 'Actual single owned package service actor fails immediate port rebinding with AddrInUse after reported successful shutdown; listener ownership/TIME_WAIT/external collision cause unobserved'}, 'limits': ['Observed hosted OS labels do not establish Windows11/default GNOME GUI acceptance', 'This run predates later browser-fixture/GNOME source changes; no later-tree validation transfer', 'Original07eb failures and missing failure attachments remain separate evidence', 'No reviewer subject imports, actors, canonical writes, package success inferred from canonical pass, or milestone/release promotion']}
(O / 'actual-data-checks.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'passed': report['passed_checks'], 'total': len(checks), 'failed': [r['name'] for r in checks if not r['pass']], 'jobs': results, 'artifacts': records}, indent=2))
assert all(c['pass'] for c in checks)
