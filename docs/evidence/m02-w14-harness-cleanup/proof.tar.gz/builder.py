from __future__ import annotations

import gzip
import hashlib
import io
import json
import tarfile
import zlib
from pathlib import Path, PurePosixPath

DRAFT = Path("/tmp/japp-w14-harness-cleanup-draft")
REVIEW = Path("/tmp/japp-w14-source-closure-review")
OUT = Path("/tmp/japp-w14-harness-cleanup-retained-20261017")
PATCH = "98d6e14cd31514623bf5d93550ecd73dc65a0347fb81f3baf12d134319e2dcb8"
PROOF = "11dd77fa091be1873e929fd94f5cbaa24ba88583f7e8b6215845a23c823a7a13"
INDEX = "retention-index.json"

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def safe(name: str) -> None:
    path = PurePosixPath(name)
    assert not path.is_absolute() and name == path.as_posix()
    assert all(part not in {"", ".", ".."} for part in path.parts)
    assert "\\" not in name and ":" not in name
    assert not any(part in {"red-tree", "green-tree", "node_modules", "__pycache__", ".cache", ".vite", ".wxt"} for part in path.parts)

assert digest((DRAFT / "harness-cleanup.patch").read_bytes()) == PATCH
assert digest((DRAFT / "final-focused-proof.json").read_bytes()) == PROOF
final_seal = json.loads((REVIEW / "cleanup-final-proposal-review/seal.json").read_text())
for row in final_seal["review_outputs"]:
    data = (REVIEW / "cleanup-final-proposal-review" / row["path"]).read_bytes()
    assert len(data) == row["bytes"] and digest(data) == row["sha256"]

sources: dict[str, Path] = {}
for name in ["README.md", "harness-cleanup.patch", "proposal-manifest.json", "final-focused-proof.json"]:
    sources["proposal/" + name] = DRAFT / name
for name in ["before", "after", "history", "logs"]:
    for path in sorted((DRAFT / name).rglob("*")):
        assert not path.is_symlink()
        if path.is_file():
            sources["proposal/" + path.relative_to(DRAFT).as_posix()] = path
for path in sorted(REVIEW.rglob("*")):
    assert not path.is_symlink()
    if path.is_file():
        sources["independent-review/" + path.relative_to(REVIEW).as_posix()] = path
sources["builder.py"] = Path(__file__)
payloads: dict[str, bytes] = {}
rows = []
for name, source in sorted(sources.items()):
    safe(name)
    assert source.is_file() and not source.is_symlink()
    data = source.read_bytes()
    payloads[name] = data
    rows.append({"path": name, "bytes": len(data), "sha256": digest(data), "original_source": str(source)})
assert len({name.casefold() for name in sources}) == len(sources)
index = {
    "format": "W14_HARNESS_CLEANUP_EXHAUSTIVE_PAYLOAD_INDEX_1",
    "self_excluded_member": INDEX,
    "self_exclusion_reason": "An index cannot contain its own digest; outer archive-manifest.json hashes this member too.",
    "patch_sha256": PATCH,
    "focused_proof_sha256": PROOF,
    "members": rows,
}
payloads[INDEX] = (json.dumps(index, indent=2) + "\n").encode()
OUT.mkdir(parents=True, exist_ok=True)
archive = OUT / "proof.tar.gz"
assert not archive.exists(), "Refuse replacing a sealed archive"
with archive.open("wb") as stream:
    with gzip.GzipFile(filename="", mode="wb", fileobj=stream, mtime=0) as zipped:
        with tarfile.open(mode="w", fileobj=zipped, format=tarfile.PAX_FORMAT) as tar:
            for name, data in sorted(payloads.items()):
                safe(name)
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.uid = info.gid = 0
                info.uname = info.gname = ""
                info.mtime = 0
                tar.addfile(info, io.BytesIO(data))

raw = archive.read_bytes()
decoder = zlib.decompressobj(31)
plain = decoder.decompress(raw) + decoder.flush()
assert decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail
with tarfile.open(fileobj=io.BytesIO(plain), mode="r:") as tar:
    members = tar.getmembers()
    assert len(members) == len(payloads)
    assert len({member.name for member in members}) == len(members)
    assert {member.name for member in members} == set(payloads)
    final_rows = []
    last_end = 0
    for member in members:
        safe(member.name)
        assert member.isfile() and not member.pax_headers
        assert member.uid == member.gid == member.mtime == 0 and member.mode == 0o644
        extracted = tar.extractfile(member)
        assert extracted is not None
        data = extracted.read()
        assert data == payloads[member.name]
        if member.name in sources:
            assert data == sources[member.name].read_bytes()
        final_rows.append({"path": member.name, "bytes": len(data), "sha256": digest(data), "original_source": str(sources[member.name]) if member.name in sources else "generated:self-excluded-index"})
        last_end = max(last_end, member.offset_data + ((member.size + 511) // 512) * 512)
    assert len(plain) - last_end >= 1024 and not any(plain[last_end:])
    embedded = json.loads(payloads[INDEX])
    assert {row["path"] for row in embedded["members"]} == set(payloads) - {INDEX}
    for row in embedded["members"]:
        data = payloads[row["path"]]
        assert row["bytes"] == len(data) and row["sha256"] == digest(data)

manifest = {
    "format": "W14_HARNESS_CLEANUP_ARCHIVE_OUTER_MANIFEST_1",
    "archive": archive.name,
    "archive_sha256": digest(raw),
    "archive_bytes": len(raw),
    "regular_member_count": len(final_rows),
    "payload_bytes": sum(row["bytes"] for row in final_rows),
    "original_regular_sources": len(sources),
    "embedded_index": {"path": INDEX, "bytes": len(payloads[INDEX]), "sha256": digest(payloads[INDEX])},
    "members": final_rows,
    "roundtrip_and_original_byte_closure": "PASS",
    "gzip_members": 1,
    "safe_paths_regular_only_no_collision_no_hidden_tar_tail": "PASS",
    "root_writes": 0,
    "product_commands_or_browser_operations": 0,
    "authority": "NONE",
    "scope": "Exact narrow cleanup proposal, focused fake-context RED/GREEN/static proof, original and final source review; no full-unit/controlled/aggregate/Gate/W15 authority.",
}
(OUT / "archive-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({key: manifest[key] for key in ["archive_sha256", "archive_bytes", "regular_member_count", "payload_bytes", "original_regular_sources", "roundtrip_and_original_byte_closure"]}))
