# Source-only V2 preflight correction

The source-only proposal now requires successful runtime, tool and build endpoint
captures, the unchanged bound 355-file/4f5 runtime identity, and absent fresh-clone
build outputs **before** either doctor or aggregate can launch. All three endpoint
capture functions execute before this eligibility decision, so one failure does
not hide the other actual preflight outcomes. `preflight-checks.json` records the
individual checks, failures and launch eligibility.

A failed preflight writes completion with doctor/aggregate/verification results
NULL, wrapper exit one and integrity exit one, then stops without invoking doctor
or aggregate. Earlier source-precondition and preparation failure records now also
explicitly show doctor and aggregate as NULL. Nonzero preparation commands retain
their actual primary command status. The endpoint retention and distinct result
semantics from V1 otherwise remain unchanged.

Original wrapper and all published V1 candidate/patch/identity/manifest bytes remain
unchanged. The initial internal V2 draft is retained separately; the final V2 adds
the same explicit NULL fields to the earlier preflight exits. Syntax was checked
only by AST parsing and `compile()`. No wrapper actor, install, build, discovery,
test, browser, push or workflow dispatch was invoked. Future candidate commit is
NULL; authority is NONE. Root source review and a concrete committed source are
still required before execution.

| File | Bytes | SHA-256 |
|---|---:|---|
| `candidate-v2.py` | 17024 | `154ea9bf473467fc15409a8e62c0b45f23781b908535ef43fc2c536a2562cd20` |
| Minimal `correction-v2.patch` against V1 | 3008 | `177ba04a7a0f130a1207f4b637af43bd1a9f4a17a284d34ee37321bfcdb7161a` |
| Cumulative `proposal-v2.patch` against original | 21020 | `dbabc46df47729787bbbb8f9e69c340e15e229c5c536d220f81753ebca5bb0a9` |

The earlier read-only workflow and GitHub findings in `review.md` remain applicable:
the PR branch is correct, but future CI must bind both the exact PR head and the
actual tested merge tree rather than assume the checkout is the candidate commit.
