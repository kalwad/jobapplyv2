# M02-W15 final full wrapper: bounded source review

Authority: **NONE**. Future candidate commit: **NULL**. No wrapper, install,
build, discovery, test, browser actor, push, workflow dispatch or CI run was
invoked in this review. The candidate below passed Python AST parsing and
`compile()` only; its runtime behavior remains unexecuted and requires root
source review before use.

Observed repository source was commit
`2464519e0b04de123ef51c3d9cb0363456b5b0eb`, tree
`75660b6a105a2873b0020d3a2d4c24dfb75e15e5`. Existing root metadata and retained
failure archives were already dirty and were not edited by this reviewer.
The prepared original wrapper was copied before review and remains byte-exact.

## Original wrapper

The original source is clear on the main execution sequence: a new exclusive
output directory, fresh local clone with `--no-hardlinks --no-checkout`, detached
checkout of the sole supplied 40-character commit, frozen JS/Python installs,
actual `pnpm run doctor`, and `pnpm verify` only after doctor returns zero. A
clean committed source is required immediately before those commands, and all
tracked file bytes, HEAD, tree and porcelain status are recaptured afterward.
The local source clone excludes the root's uncommitted metadata by construction.

The environment explicitly requires native128 samples=20 and the full-settlement
contact target assertion=1. Current test source consumes those exact variables.
The native128 source retains the original 120000 ms whole-test deadline and
1500 ms target; the contact target requires the target macOS/Apple M5 hardware.
The wrapper changes none of that test source or its workload.

Default Playwright output remains `test-results/`. The current controlled contact
and research configs resolve their distinct `../../../test-results/public-contact`
and `../../../test-results/public-research` paths to children of that directory,
with retries still zero. Their later invocations therefore preserve the default
suite's earlier traces and screenshots. The wrapper copies all regular closed
native artifacts immediately after the aggregate process returns, before any
future test invocation. PASS and FAIL child output is retained in either case.

The original needs two material improvements before use as the final source-bound
proof producer:

- It has no explicit before/after capture of the existing 355-file source/harness
  runtime policy, installed dependency lock, activated tools or actual build
  outputs. Doctor proves the initial tool pins, but does not supply all later
  endpoint commitments needed by the prepared R10 release.
- `completion.json.exit_code` is the verification child's status alone. An
  integrity mismatch can leave that field at zero while the wrapper exits one.
  Endpoint capture exceptions can also prevent the completion record and hide
  the already-observed verification result behind a later failure.

## Separate source proposal

`candidate.py` is a source-only proposed replacement, not an executed proof or a
release authorization. It preserves the sole future-commit argument, fresh clone,
the original install commands, the actual strict doctor-to-aggregate sequence,
all four explicit task environment values and native retention before later
endpoint commands. It adds:

- Before/after `assertRuntimeInventory()` from the unchanged existing
  `legacy-paired-options-r10/runtime-inventory.ts`, using its committed source
  bindings. It requires the existing 355 files, 3372811 bytes and
  `sha256:4f5a9608eb23a80a15a81b4a79494901907c4ad7e5c6a996fbce455b498c77d5`.
  This remains the declared runtime **and harness** source policy, not solely
  shipped production source. The R9 and R10 inventory helper bytes are identical.
- Before/after tool versions and executable resolution, the installed pnpm lock
  and committed pnpm/uv lock identities, platform metadata, and separate raw
  stdout/stderr plus command outcomes. The source tool pins remain enforced by
  doctor and the aggregate, with explicit Node/pnpm/Playwright identity checks.
- Before/after regular-file build inventories for production MV3, invalid-ACK
  MV3 and the mock ATS lab. Fresh clone outputs must initially be absent; a
  successful aggregate must leave each output nonempty. Build outputs are
  expected to change from absent to built, so they are not compared as though
  they were unchanged tracked source.
- Regular nonsymlink source/artifact checks with size/inode/mtime stability
  during reads, an incremental native artifact manifest, and raw Git endpoint
  outputs. Captured failures remain failures with their actual data retained.
- Distinct `doctor_exit_code`, `aggregate_exit_code`,
  `verification_command_exit_code`, `integrity_exit_code` and
  `wrapper_exit_code`. A nonzero verification result remains the primary result
  when later endpoint capture also fails; a zero verification result plus an
  integrity failure gives a nonzero wrapper result. A signaled child keeps its
  negative command status while the wrapper uses exit one.

The proposal captures endpoint exceptions as secondary evidence and continues
the remaining endpoint captures. It does not manufacture missing identities,
infer a percentile from incomplete rows, retry an actor, waive an assertion,
change browser flags, enable unsupported metadata queries or grant Gate A
authority. Capture failure makes the wrapper fail even if verification passes.
The wrapper's completion explicitly keeps authority NONE, owner PENDING and
gate_pass false; an actual zero result would establish verification evidence
only.

Frozen source identities:

| File | Bytes | SHA-256 |
|---|---:|---|
| Original and `preimage.py` | 5971 | `05db1320800ea1a9a6aa034b89ddf9b967d617cfa20d858a5a15cf891d391be2` |
| `candidate.py` | 15276 | `09c200175460fee40d9679896bd6db462b87b90c6898ff21374c544071ea3bb8` |
| `proposal.patch` | 19259 | `9cb6a3f9eb20b64500af782cee6a26177a42d1ae908a5f98006442da3a63cbdb` |

The patch is an ordinary unified diff between the frozen preimage and candidate;
it has not been applied to the original wrapper. `identities.json` also commits
the workflow, configs, existing inventory helpers and source-binding files read
for this review. There is no empirical PASS claim for the candidate's error or
retention paths.

## Read-only GitHub and workflow check

Actual `gh api repos/kalwad/jobapplyv2/pulls/1` and `git ls-remote` reads both
reported the open draft PR's branch as
`kalwad/jobapplyv2:codex/autofill-evaluation-hardening`, currently at
`6384d98156ae198cd93d7b35d1bb28b501ed475e`. Its base is `main` at
`4745149f4b5da7190b5b0c68753f8ec07bed572d`; the then-current merge commit is
`52fcfc186251205180197b9b9f88fcb0b4acf534`. Actual read-only results and argv are
retained in `github-readonly-check.json` as tool-response-derived records.

The working workflow and three Playwright configs are unchanged from HEAD.
The workflow's `pull_request` trigger will react to synchronization of that
existing PR; branch pushes are not independently covered by the workflow's
`push` filter, which lists only `main`. Using an explicit reviewed commit-to-ref
push would avoid a moving local HEAD selection. No such push was executed.

The workflow uses the default pull-request checkout revision, which is the
GitHub merge revision, not automatically the exact candidate commit itself.
After a future push, evidence must separately confirm the PR/run head SHA equals
the reviewed candidate and bind the actual tested checkout's tree. Equality of
the merge tree to the candidate tree must be checked rather than assumed. A
concurrent base change can invalidate that equality. This review cannot certify
a future push or a future workflow result.

All three native jobs retain the same actual doctor then aggregate commands,
frozen/locked installs, fetch-depth zero, no retry policy, and failure artifact
upload rooted at `test-results/`. They do not set the local wrapper's target20
or target-hardware environment variables. Native portability CI is therefore
separate evidence from the local target20/native128 and full-settlement contact
target assertions; CI success alone cannot substitute for those local results.
