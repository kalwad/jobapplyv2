from pathlib import Path
import datetime
import hashlib
import json
import os
import platform
import re
import shutil
import stat
import subprocess
import sys
import time

source = Path('/Users/tanishkalwad/jobapplyv2')
out = Path('/tmp/japp-m02-w15-final-candidate2-20261018')
assert len(sys.argv) == 2, 'The sole argument must be the reviewed future commit'
expected = sys.argv[1]
assert re.fullmatch('[0-9a-f]{40}', expected)
assert not out.exists(), 'A fresh output directory is required'
out.mkdir()
proof = out / 'proof'
proof.mkdir()
root = out / 'clone'
env = os.environ.copy()
env['PATH'] = '/opt/homebrew/opt/node@24/bin:' + env['PATH']
env.update(
    JAPP_W13_PERFORMANCE_SAMPLES='20',
    JAPP_W14_REQUIRE_TARGET_PERFORMANCE='1',
    JAPP_W14_ARTIFACT_DIRECTORY=str(proof / 'w14'),
    JAPP_W14_W06_ARTIFACT_DIRECTORY=str(proof / 'mounted32'),
)
records = []
endpoint_failures = []
git_endpoint_number = 0


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    (proof / name).write_text(json.dumps(value, indent=2) + '\n')


def regular_identity(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode), 'Regular nonsymlink file required: ' + str(path)
    data = path.read_bytes()
    after = path.lstat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns
    ), 'File changed during capture: ' + str(path)
    assert len(data) == before.st_size
    return data, {'bytes': len(data), 'sha256': sha(data)}


def run(name, argv, cwd):
    print('RUN ' + name, flush=True)
    started = now()
    t = time.monotonic()
    exception = None
    with (proof / (name + '.log')).open('wb') as log:
        try:
            result = subprocess.run(argv, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT)
            code = result.returncode
        except OSError as error:
            exception = {'type': type(error).__name__, 'message': str(error)}
            log.write((json.dumps(exception) + '\n').encode())
            code = 127
    b = (proof / (name + '.log')).read_bytes()
    record = {'name': name, 'argv': argv, 'cwd': str(cwd), 'started_at': started,
              'ended_at': now(), 'exit_code': code, 'spawn_exception': exception,
              'elapsed_seconds': time.monotonic() - t, 'log_bytes': len(b),
              'log_sha256': sha(b)}
    records.append(record)
    save('commands.json', records)
    print(json.dumps(record), flush=True)
    if code:
        print(b.decode(errors='replace')[-9000:], flush=True)
    return code


def endpoint_command(name, argv, binary=False):
    started = now()
    exception = None
    stdout = stderr = b''
    code = None
    try:
        result = subprocess.run(argv, cwd=root, env=env, capture_output=True, timeout=60)
        stdout, stderr, code = result.stdout, result.stderr, result.returncode
    except (OSError, subprocess.TimeoutExpired) as error:
        exception = {'type': type(error).__name__, 'message': str(error)}
        stdout = getattr(error, 'stdout', None) or b''
        stderr = getattr(error, 'stderr', None) or b''
    (proof / (name + '.stdout')).write_bytes(stdout)
    (proof / (name + '.stderr')).write_bytes(stderr)
    record = {'argv': argv, 'cwd': str(root), 'started_at': started, 'ended_at': now(),
              'exit_code': code, 'exception': exception,
              'stdout': {'bytes': len(stdout), 'sha256': sha(stdout)},
              'stderr': {'bytes': len(stderr), 'sha256': sha(stderr)}}
    save(name + '-command.json', record)
    if code != 0 or exception is not None:
        raise RuntimeError('Endpoint command failed: ' + name)
    return stdout if binary else stdout.decode().strip()


def capture_endpoint(name, callback):
    try:
        value = callback()
        save(name + '.json', value)
        save(name + '-capture.json', {'captured_at': now(), 'state': 'CAPTURED'})
        return value
    except Exception as error:
        failure = {'name': name, 'captured_at': now(), 'state': 'FAILED',
                   'exception': {'type': type(error).__name__, 'message': str(error)}}
        endpoint_failures.append(failure)
        save(name + '.json', failure)
        return None


def git(*args):
    global git_endpoint_number
    git_endpoint_number += 1
    return endpoint_command('source-git-' + str(git_endpoint_number).zfill(4), ['git', *args])


def snapshot():
    head, tree = git('rev-parse', 'HEAD'), git('rev-parse', 'HEAD^{tree}')
    files = []
    global git_endpoint_number
    git_endpoint_number += 1
    names = endpoint_command('source-git-' + str(git_endpoint_number).zfill(4), ['git', 'ls-files', '-z'], binary=True).decode().split('\0')
    for name in sorted(name for name in names if name):
        _, identity = regular_identity(root / name)
        files.append({'path': name, **identity})
    assert head == git('rev-parse', 'HEAD') and tree == git('rev-parse', 'HEAD^{tree}')
    return {'head': head, 'tree': tree, 'status': git('status', '--porcelain=v1'),
            'tracked_files': files,
            'tracked_inventory_digest': sha(json.dumps(files, separators=(',', ':')).encode()),
            'captured_at': now()}


def runtime(name):
    # Reuse the unchanged, already reviewed 355-file source/harness policy.
    # This imports no actor and never rebuilds, lists or runs Playwright tests.
    code = "import {readFileSync} from 'node:fs'; import {assertRuntimeInventory} from './e2e/extension/legacy-paired-options-r10/runtime-inventory.ts'; const binding=JSON.parse(readFileSync('e2e/extension/legacy-paired-options-r10/source-bindings.json','utf8')); console.log(JSON.stringify(assertRuntimeInventory(process.cwd(),binding)));"
    value = json.loads(endpoint_command(name + '-capture', ['node', '--input-type=module', '-e', code]))
    readiness = json.loads((root / 'e2e/extension/legacy-paired-options-r10/r10-readiness.json').read_text())
    assert len(value['files']) == readiness['candidate_runtime_inventory_count'] == 355
    assert value['digest'] == readiness['candidate_runtime_inventory_digest']
    assert value['digest'] == 'sha256:4f5a9608eb23a80a15a81b4a79494901907c4ad7e5c6a996fbce455b498c77d5'
    assert value['total_bytes'] == 3372811
    return value


def tools(name):
    probes = {
        'node': ['node', '--version'],
        'node_exec_path': ['node', '-p', 'process.execPath'],
        'pnpm': ['pnpm', '--version'],
        'uv': ['uv', '--version'],
        'python': ['uv', 'run', 'python', '-VV'],
        'python_exec_path': ['uv', 'run', 'python', '-c', 'import sys; print(sys.executable)'],
        'playwright': ['pnpm', 'exec', 'playwright', '--version'],
        'rust_active_toolchain': ['rustup', 'show', 'active-toolchain'],
        'cargo_toolchain_path': ['rustup', 'which', 'cargo'],
        'cargo': ['cargo', '--version'],
        'rustc': ['rustc', '--version'],
    }
    identities = {}
    failures = []
    for key, argv in probes.items():
        try:
            identities[key] = endpoint_command(name + '-' + key, argv)
        except Exception as error:
            failures.append({'probe': key, 'type': type(error).__name__, 'message': str(error)})
    identities['resolved_commands'] = {
        command: shutil.which(command, path=env['PATH'])
        for command in ('node', 'pnpm', 'uv', 'rustup', 'cargo', 'rustc')
    }
    for rel in ('pnpm-lock.yaml', 'node_modules/.pnpm/lock.yaml', 'uv.lock'):
        try:
            _, identities[rel] = regular_identity(root / rel)
        except Exception as error:
            failures.append({'probe': rel, 'type': type(error).__name__, 'message': str(error)})
    value = {'identities': identities, 'probe_failures': failures,
             'platform': platform.platform(), 'machine': platform.machine(),
             'wrapper_python': sys.version}
    save(name + '-partial.json', value)
    if failures:
        raise RuntimeError('Tool endpoint failures retained: ' + name)
    assert identities['node'] == 'v24.18.0'
    assert identities['pnpm'] == '11.17.0'
    assert identities['playwright'] == 'Version 1.62.0'
    return value


def built():
    result = {'scope': 'Actual build-output endpoints; absent in a fresh clone. Canonical aggregate builds the production and invalid-ACK MV3 outputs and mock ATS lab.', 'directories': {}}
    for rel in ('apps/extension/dist/chrome-mv3', 'apps/extension/dist/invalid-ack/chrome-mv3', 'apps/mock-ats-lab/dist'):
        directory = root / rel
        files = []
        if directory.exists():
            assert directory.is_dir() and not directory.is_symlink()
            for path in sorted(directory.rglob('*')):
                mode = path.lstat().st_mode
                if stat.S_ISDIR(mode):
                    continue
                _, identity = regular_identity(path)
                files.append({'path': path.relative_to(root).as_posix(), **identity})
        result['directories'][rel] = {'exists': directory.exists(), 'files': files,
                                      'total_bytes': sum(item['bytes'] for item in files)}
    return result


def retain_native(code):
    retained = []
    native_root = root / 'test-results'
    save('native-artifact-retention-partial.json', {'captured_at': now(), 'regular_files': retained})
    if native_root.exists():
        assert native_root.is_dir() and not native_root.is_symlink()
        for path in sorted(native_root.rglob('*')):
            mode = path.lstat().st_mode
            if stat.S_ISDIR(mode):
                continue
            data, identity = regular_identity(path)
            relative = path.relative_to(native_root)
            target = proof / 'native-test-results' / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            assert target.read_bytes() == data and path.read_bytes() == data
            retained.append({'path': relative.as_posix(), **identity})
            save('native-artifact-retention-partial.json', {'captured_at': now(), 'regular_files': retained})
    return {'captured_at': now(), 'verification_command_exit_code': code,
            'scope': 'Closed aggregate native artifacts before any later invocation; distinct controlled outputDirs preserve earlier default failures; no authority inferred',
            'regular_files': retained}


save('wrapper-command.json', {
    'outer_argv': sys.argv, 'source_repository': str(source), 'expected_head': expected,
    'candidate_commit': expected, 'authority': 'NONE', 'owner_decision': 'PENDING',
    'wrapper_sha256': sha(Path(__file__).read_bytes()),
    'task_environment': {key: env[key] for key in ('JAPP_W13_PERFORMANCE_SAMPLES', 'JAPP_W14_REQUIRE_TARGET_PERFORMANCE', 'JAPP_W14_ARTIFACT_DIRECTORY', 'JAPP_W14_W06_ARTIFACT_DIRECTORY')},
    'started_at': now(),
})
steps = [
    ('clone', ['git', 'clone', '--no-hardlinks', '--no-checkout', str(source), str(root)], out),
    ('checkout', ['git', 'checkout', '--detach', expected], root),
    ('pnpm-install', ['pnpm', 'install', '--frozen-lockfile'], root),
    ('uv-sync', ['uv', 'sync', '--locked'], root),
    ('playwright-install', ['pnpm', 'exec', 'playwright', 'install', 'chromium'], root),
]
for name, argv, cwd in steps:
    code = run(name, argv, cwd)
    if code:
        wrapper_code = code if code > 0 else 1
        save('completion.json', {'stage': name, 'command_exit_code': code,
                                'verification_command_exit_code': None,
                                'wrapper_exit_code': wrapper_code, 'integrity_exit_code': None,
                                'authority': 'NONE', 'ended_at': now()})
        raise SystemExit(wrapper_code)

before = capture_endpoint('before', snapshot)
eligible = before is not None and before['head'] == expected and before['status'] == ''
if not eligible:
    save('completion.json', {'stage': 'before-source-precondition',
                            'command_exit_code': None, 'verification_command_exit_code': None,
                            'wrapper_exit_code': 1, 'integrity_exit_code': 1,
                            'endpoint_failures': endpoint_failures,
                            'authority': 'NONE', 'ended_at': now()})
    raise SystemExit(1)
before_runtime = capture_endpoint('before-runtime', lambda: runtime('before-runtime'))
before_tools = capture_endpoint('before-tools', lambda: tools('before-tools'))
before_build = capture_endpoint('before-build', built)
preflight_checks = {
    'runtime_endpoint_captured_and_bound': before_runtime is not None,
    'tool_endpoints_captured_and_pinned': before_tools is not None,
    'build_endpoint_captured': before_build is not None,
    'fresh_build_outputs_absent': before_build is not None and all(not value['exists'] for value in before_build['directories'].values()),
    'no_endpoint_capture_failure': not endpoint_failures,
}
save('preflight-checks.json', {'checks': preflight_checks,
                               'endpoint_failures': endpoint_failures,
                               'eligible_to_launch_verification': all(preflight_checks.values()),
                               'captured_at': now()})
if not all(preflight_checks.values()):
    save('completion.json', {'stage': 'before-endpoint-precondition',
                            'doctor_exit_code': None, 'aggregate_exit_code': None,
                            'command_exit_code': None, 'verification_command_exit_code': None,
                            'wrapper_exit_code': 1, 'integrity_exit_code': 1,
                            'preflight_checks': preflight_checks,
                            'endpoint_failures': endpoint_failures,
                            'source_head': before['head'], 'source_tree': before['tree'],
                            'authority': 'NONE', 'owner_decision': 'PENDING', 'gate_pass': False,
                            'scope': 'Verification was not launched: a required source-bound preflight endpoint failed',
                            'ended_at': now()})
    raise SystemExit(1)
doctor_code = run('doctor', ['pnpm', 'run', 'doctor'], root)
aggregate_code = None
if doctor_code == 0:
    aggregate_code = run('aggregate', ['pnpm', 'verify'], root)
command_code = doctor_code if aggregate_code is None else aggregate_code
# Retain closed artifacts first, before endpoint tools or any future test run.
capture_endpoint('native-artifact-retention', lambda: retain_native(command_code))
after = capture_endpoint('after', snapshot)
after_runtime = capture_endpoint('after-runtime', lambda: runtime('after-runtime'))
after_tools = capture_endpoint('after-tools', lambda: tools('after-tools'))
after_build = capture_endpoint('after-build', built)
checks = {
    'head_unchanged': after is not None and before['head'] == after['head'] == expected,
    'tree_unchanged': after is not None and before['tree'] == after['tree'],
    'status_clean_before': before['status'] == '',
    'status_clean_after': after is not None and after['status'] == '',
    'tracked_inventory_unchanged': after is not None and before['tracked_inventory_digest'] == after['tracked_inventory_digest'],
    'runtime_inventory_unchanged': before_runtime is not None and after_runtime is not None and before_runtime == after_runtime,
    'tool_identities_unchanged': before_tools is not None and after_tools is not None and before_tools['identities'] == after_tools['identities'],
    'all_endpoints_captured': not endpoint_failures,
    'fresh_build_outputs_absent_before': before_build is not None and all(not value['exists'] for value in before_build['directories'].values()),
    'successful_aggregate_has_nonempty_build_outputs': aggregate_code != 0 or (after_build is not None and all(value['exists'] and value['files'] for value in after_build['directories'].values())),
}
integrity_code = int(not all(checks.values()))
wrapper_code = command_code if command_code > 0 else (1 if command_code < 0 else integrity_code)
completion = {
    'doctor_exit_code': doctor_code, 'aggregate_exit_code': aggregate_code,
    'command_exit_code': command_code, 'verification_command_exit_code': command_code,
    'wrapper_exit_code': wrapper_code, 'integrity_exit_code': integrity_code,
    'checks': checks, 'endpoint_failures': endpoint_failures,
    'source_head': before['head'], 'source_tree': before['tree'],
    'authority': 'NONE', 'owner_decision': 'PENDING', 'gate_pass': False,
    'scope': 'Actual strict doctor then aggregate and endpoint preservation; exit zero is verification evidence only, never an owner or independent gate decision',
    'ended_at': now(),
}
save('completion.json', completion)
print(json.dumps(completion), flush=True)
raise SystemExit(wrapper_code)
