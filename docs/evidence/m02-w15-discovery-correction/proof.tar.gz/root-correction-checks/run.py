from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
root=Path('/Users/tanishkalwad/jobapplyv2');out=Path(__file__).parent
env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@24/bin:'+env['PATH'];env['R10_ACTOR_SOURCE']=str(root/'e2e/extension/legacy-paired-options-r10/legacy-browser.mjs');env['PLAYWRIGHT_JSON_OUTPUT_NAME']=str(out/'discovery.json')
steps=[('node42',['node','--experimental-vm-modules','--test',*[str(p.relative_to(root)) for p in sorted((root/'e2e/extension/legacy-paired-options-r10').glob('*.test.mjs'))]]),('browser-discovery',['pnpm','exec','playwright','test','--list','--reporter=json']),('config-typecheck',['pnpm','exec','tsc','-p','tsconfig.json']),('config-lint',['pnpm','exec','eslint','playwright.config.ts']),('config-format',['pnpm','exec','prettier','--check','playwright.config.ts']),('diff',['git','diff','--check'])]
rows=[]
for name,argv in steps:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 with (out/(name+'.log')).open('wb') as stream:r=subprocess.run(argv,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
 b=(out/(name+'.log')).read_bytes();row=dict(name=name,argv=argv,cwd=str(root),started_at=start,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-t,exit_code=r.returncode,log_bytes=len(b),log_sha256=hashlib.sha256(b).hexdigest());rows.append(row);(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print(b.decode(errors='replace')[-8000:],flush=True);raise SystemExit(r.returncode)
d=json.loads((out/'discovery.json').read_text());specs=[]
def walk(s):
 for x in s.get('specs',[]):specs.append(x)
 for x in s.get('suites',[]):walk(x)
walk(d);actual_files=sorted({s['file'] for s in specs});expected_files=sorted(p.relative_to(root/'e2e').as_posix() for p in (root/'e2e').rglob('*.spec.ts'))
assert actual_files==expected_files,(actual_files,expected_files)
count=sum(len(s['tests']) for s in specs);assert count==246
node=(out/'node42.log').read_text();assert '# tests 42' in node and '# pass 42' in node and '# fail 0' in node and '# skipped 0' in node
source=(root/'playwright.config.ts').read_bytes();assert hashlib.sha256(source).hexdigest()=='776766f9be450e31616673fd33e3a7a4960f08ec3862afacd8f8d3b28c97a4e3'
summary={'scope':'REAL_BROWSER_DISCOVERY_AND_SEPARATE_NODE_STRUCTURAL_TESTS_NOT_BROWSER_EXECUTION','base_commit':'3c79bd0dbcd9e604c4b05320e45f20a46c3aef46','config_sha256':hashlib.sha256(source).hexdigest(),'actual_default_playwright_cases':count,'actual_default_spec_files':len(actual_files),'every_declared_spec_file_discovered':True,'actual_node_structural_tests':42,'actual_node_pass':42,'actual_node_fail':0,'actual_node_skip':0,'browser_execution':0,'canonical_p95_ms':None,'actual_discovered_files':actual_files,'authority':'NONE','owner_decision':'PENDING'}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='actual_discovered_files'}),flush=True)
