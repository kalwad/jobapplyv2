from pathlib import Path
import hashlib,json,re
out=Path(__file__).parent;root=Path('/Users/tanishkalwad/jobapplyv2')
commands=json.loads((out/'commands.json').read_text());assert len(commands)==6 and all(x['exit_code']==0 for x in commands)
node=(out/'node42.log').read_text();counts={}
for line in node.splitlines():
 m=re.fullmatch(r'ℹ (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)',line)
 if m:counts[m[1]]=int(m[2])
assert counts=={'tests':42,'suites':0,'pass':42,'fail':0,'cancelled':0,'skipped':0,'todo':0},counts
d=json.loads((out/'discovery.json').read_text());specs=[]
def walk(s):
 specs.extend(s.get('specs',[]))
 for child in s.get('suites',[]):walk(child)
walk(d);files=sorted({s['file'] for s in specs});expected=sorted(p.relative_to(root/'e2e').as_posix() for p in (root/'e2e').rglob('*.spec.ts'))
assert files==expected and len(files)==54 and sum(len(s['tests']) for s in specs)==246
summary={'scope':'CLOSED_NODE_STRUCTURAL_AND_BROWSER_DISCOVERY_NOT_BROWSER_EXECUTION','base_commit':'3c79bd0dbcd9e604c4b05320e45f20a46c3aef46','config_sha256':hashlib.sha256((root/'playwright.config.ts').read_bytes()).hexdigest(),'actual_default_playwright_cases':246,'actual_spec_files':54,'all_declared_spec_files_present':True,'node_actual_summary':counts,'commands_exit_codes':[x['exit_code'] for x in commands],'browser_actors':0,'canonical_p95_ms':None,'postprocessor_correction':'Original run.py wrongly expected TAP # summaries; actual Node spec reporter uses ℹ. All six original command exits are0. This separate pure analysis reads original bytes; no rerun or source/assertion change.','authority':'NONE','owner_decision':'PENDING','actual_discovered_files':files}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='actual_discovered_files'}))
