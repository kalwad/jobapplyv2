from pathlib import Path
import ast,hashlib,json,re,stat
R=Path('/Users/tanishkalwad/jobapplyv2');B=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');P=B/'unit-ts-concurrency-proposal';V=B/'unit-ts-actual-v1';O=B/'unit-ts-actual-independent-review'
def j(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
def ck(name,value,detail=None):checks.append({'name':name,'pass':bool(value),'detail':detail})
a=j(V/'before.json');z=j(V/'after.json');context=j(V/'context.json');close=j(V/'closure.json');rows=j(V/'results.json')
ck('2065 source regular-entry count',len(a['source'])==2065)
ck('40 runtime entry count',len(a['runtime'])==40)
ck('Source/runtime/permission-mode/status endpoints identical',a==z)
ck('Exactly1planned/executed phase',close['executed_phases']==close['planned_phases']==len(rows)==1)
ck('Closure reports allpass/neutrality',close['all_pass'] and close['source_runtime_status_modes_unchanged'])
ck('Context reference35b not clean current commit',context['head']=='35b46287dc754a5987d653490ab49f978647ca26' and bool(a['git_status']))
row=rows[0]
ck('Exact actual outerargv',row['argv']==['uv','run','--no-sync','--offline','python','scripts/verify.py','--suite','unit-ts'])
ck('Zeroexit/no timeout/reaped/group absent/no cleanup',row['exit_code']==0 and not row['timeout'] and row['direct_child_reaped'] and row['observed_group']=='ABSENT' and not row['outer_cleanup_signals'])
ck('Recorded actual88.91856595792342s',row['seconds']==88.91856595792342)
ck('Chronological actual timestamps',context['start_utc']<close['end_utc'])
log=(V/'unit-ts.log').read_text();expected='$ pnpm exec turbo run test --force --concurrency=2 -- --reporter=default'
ck('Exact prepared command channel',log.splitlines()[0]==expected)
ck('15successful tasks',re.search(r'Tasks:\s+15 successful, 15 total',log) is not None)
ck('0cached tasks15fresh',re.search(r'Cached:\s+0 cached, 15 total',log) is not None and log.count('cache bypass, force executing')==15)
ck('Canonical suite ACTIVE PASS exit0',re.search(r'^unit-ts\s+ACTIVE\s+PASS\s*$',log,re.M) is not None and 'verification exit code: 0' in log)
counts={name:int(count) for name,count in re.findall(r'^(@japp/[A-Za-z0-9_-]+):test:\s+Tests\s+(\d+) passed \(\d+\)',log,re.M)}
ck('15package summaries total4006',len(counts)==15 and sum(counts.values())==4006,counts)
old=(B/'full-35b4628/verify.log').read_text();oldcounts={name:int(count) for name,count in re.findall(r'^(@japp/[A-Za-z0-9_-]+):test:\s+Tests\s+(\d+) passed \(\d+\)',old,re.M)}
ck('Perpackage counts match prior actual clean35b',len(oldcounts)==15 and counts==oldcounts)
ck('All15 task scripts forced builtin reporter',len(re.findall(r'^@japp/[^:]+:test: \$ vitest run .*--reporter=default$',log,re.M))==15)
protected=j(P/'protected-test-inputs.json')
ck('Same15workspace package set',set(counts)=={x['name'] for x in protected['workspace_test_tasks']})
for rel,value in protected['protected_files'].items():
    ck('TS/package/config source pin '+rel,a['source'][rel]['sha256']==value['sha256'] and a['source'][rel]['bytes']==value['bytes'])
plan=j(P/'PLAN.json')
for item in plan['changed_paths']:
    rel=item['path'];ck('Evaluated exact reviewed afterimage '+rel,a['source'][rel]['sha256']==item['after']['sha256'] and a['source'][rel]['bytes']==item['after']['bytes'])
    ck('Root adoption exact afterimage '+rel,next(r for r in j(P/'root-adoption.json')['paths'] if r['path']==rel)['after']['sha256']==item['after']['sha256'])
oldpy=ast.parse((P/'before/scripts/tests/test_suite_states.py').read_text());newpy=ast.parse((P/'after/scripts/tests/test_suite_states.py').read_text())
ck('All prior Python testhelper AST statements preserved',len(newpy.body)==len(oldpy.body)+2 and all(ast.dump(x,include_attributes=False)==ast.dump(y,include_attributes=False) for x,y in zip(oldpy.body,newpy.body,strict=False)))
ck('Nineteen focused ordinary passes retained',re.search(r'^19 passed, 296 deselected in 0\.63s$',(P/'root-focused-tests.log').read_text(),re.M) is not None)
inv=j(P/'inventory-after.json');beforeinv=j(P/'inventory-before.json');delta=j(P/'inventory-delta.json')
ck('Inventory evaluated at TSsource snapshot',a['source']['scripts/python-test-inventory.v1.json']['sha256']==sha(P/'inventory-after.json'))
ids=re.findall(r'^([^\s]+::[^\r\n]+)$',(P/'root-full-collection.log').read_text(),re.M)
ck('Actual canonical collection2120 exact IDs',len(ids)==len(set(ids))==2120 and set(ids)==set(inv['common']['node_ids'])|set(inv['posix_only_node_ids']))
ck('Inventory2118common+2POSIX',inv['common']['count']==len(inv['common']['node_ids'])==2118 and len(inv['posix_only_node_ids'])==2)
ck('All2082priorcommon IDs preserved',len(beforeinv['common']['node_ids'])==2082 and set(beforeinv['common']['node_ids'])<=set(inv['common']['node_ids']))
add=set(inv['common']['node_ids'])-set(beforeinv['common']['node_ids']);harness={x for x in add if x.startswith('scripts/tests/test_suite_states.py::test_turbo_')};gen=add-harness
ck('36collected additions split19harness17generation',len(add)==36 and len(harness)==19 and len(gen)==17 and all(x.startswith('services/orchestrator/tests/test_generation_boundary.py::') for x in gen))
ck('Inventory digest recomputed',hashlib.sha256(('\n'.join(inv['common']['node_ids'])+'\n').encode()).hexdigest()==inv['common']['sha256'])
# Independent terminal CI metadata/raw summary reading; no claim about unrecorded merge-tree queries.
C=B/'ci-35b4628';run=j(C/'terminal-run.json');jobs=j(C/'terminal-jobs.json')['jobs']
ck('CI40782097996 attempt1 terminalfailure exact35b',run['id']==40782097996 and run['run_attempt']==1 and run['status']=='completed' and run['conclusion']=='failure' and run['head_sha']==context['head'])
ck('CIhead treef078 exact',j(C/'head-commit.json')['tree']['sha']==j(C/'head-tree.json')['sha']=='f0789de7f5c82f6931eebe489110fcb771130724')
ci=[]
for host,expected in [('macos-15',(19,1)),('windows-2025',(20,0)),('ubuntu-24.04',(20,0))]:
    p=next((C/('logs/doctor + verify ('+host+')')).glob('25_Canonical*'));raw=p.read_text();tail=raw[raw.rfind('== verification summary =='):]
    pairs=re.findall(r'\b([a-z][a-z-]+)\s+ACTIVE\s+(PASS|FAIL)\s',tail)
    actual=(sum(s=='PASS' for n,s in pairs),sum(s=='FAIL' for n,s in pairs))
    ck('CI '+host+' actual20suite summary',len(pairs)==20 and actual==expected,actual)
    ci.append({'host':host,'passed':actual[0],'failed':actual[1],'raw_path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
mac=Path(ci[0]['raw_path']).read_text()
ck('Mac explicit5000ms holdout boundary timeout','Error: Test timed out in 5000ms.' in mac and 'holdout-boundary.test.ts > M02-W06 owner-external holdout boundary > verifies a complete one-read synthetic owner snapshot' in mac)
ck('Mac otherfailedlabels retained5713/5294','paired counts reject at the raw adapter observation boundary 5713ms' in mac and 'the complete 0000-9999 domain matches the independent reference 5294ms' in mac)
ck('Native package matrix skipped',any(x['conclusion']=='skipped' and x['name'].startswith('native development package') for x in jobs))
ck('No failed checks',all(c['pass'] for c in checks))
receipt_index={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(V.iterdir()) if p.is_file()}
report={'scope':'INDEPENDENT_ACTUAL_UNIT_TS_DATA_REVIEW_NOT_FUTURE_CI_OR_MILESTONE_ACCEPTANCE','verdict':'CLEAR' if all(c['pass'] for c in checks) else 'HOLD','checks':checks,'actual_context':context,'actual_closure':close,'actual_outer_record':row,'per_package_counts':counts,'actual_receipts':receipt_index,'CI_observations':ci,'new_harness_collected_IDs':sorted(harness),'separate_generation_collected_IDs':sorted(gen),'focused_python_receipt_limit':'Retained19PASS296deselected0.63s log; exact focused argv/source-neutrality receipt was not durably captured. No invented command.','limits':['Only15task/per-package counts and unchanged test input bytes are proved; no complete Vitest per-case-ID reporter exists in this log.','No fresh hosted CI or definitive contention cause is inferred from local PASS.','This dirty2065source/40runtime cohort does not prove clean committed-source full-project validation.','Source/runtime/status/mode endpoints are retained; final HEAD/tree and global escaped descendants are not observed.','2120Python cases are actually collected, not all executed here; only19focused harness passes recorded.','No milestone, platform certification, storage/model qualification or whole-product acceptance.'],'states':{'M03-W06':'IN_PROGRESS','M03':'IN_PROGRESS','verified':38,'release':'NOT_READY'}}
(O/'actual-data-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'verdict':report['verdict'],'checks':len(checks),'passed':sum(c['pass'] for c in checks),'failed':[c['name'] for c in checks if not c['pass']],'tasks':len(counts),'total':sum(counts.values()),'CI':[(x['host'],x['passed'],x['failed']) for x in ci]}))
