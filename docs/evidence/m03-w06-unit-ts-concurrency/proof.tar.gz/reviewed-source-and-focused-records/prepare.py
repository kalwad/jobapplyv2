from pathlib import Path
import difflib,hashlib,json,stat
R=Path('/Users/tanishkalwad/jobapplyv2')
O=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/unit-ts-concurrency-proposal')
paths=['scripts/verification-suites.json','scripts/verify.py','scripts/tests/test_suite_states.py']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pre={p:(R/p).read_text() for p in paths};after=dict(pre)
old='"commands": [["pnpm", "exec", "turbo", "run", "test", "--force"]],'
new='''"commands": [
        ["pnpm", "exec", "turbo", "run", "test", "--force", "--concurrency=2"]
      ],'''
assert after[paths[0]].count(old)==1;after[paths[0]]=after[paths[0]].replace(old,new)
old='''            in ((), ("--force",))'''
new='''            in ((), ("--force",), ("--force", "--concurrency=2"))'''
assert after[paths[1]].count(old)==1;after[paths[1]]=after[paths[1]].replace(old,new)
addition='''

@pytest.mark.parametrize(
    "command",
    [
        pytest.param(
            ["pnpm", "exec", "turbo", "run", "test"],
            id="retained-no-options",
        ),
        pytest.param(
            ["pnpm", "exec", "turbo", "run", "test", "--force"],
            id="retained-force",
        ),
        pytest.param(
            ["pnpm", "exec", "turbo", "run", "test", "--force", "--concurrency=2"],
            id="force-bounded-two-tasks",
        ),
        pytest.param(
            ["pnpm.cmd", "exec", "turbo", "run", "test", "--force", "--concurrency=2"],
            id="windows-force-bounded-two-tasks",
        ),
        pytest.param(
            [
                "pnpm",
                "exec",
                "turbo",
                "run",
                "test",
                "--force",
                "--concurrency=2",
                "--",
                "--pool=threads",
            ],
            id="bounded-tasks-with-safe-vitest-forwarding",
        ),
    ],
)
def test_turbo_bounded_package_concurrency_preserves_full_reporter_channel(
    fixture_repo: verify.Context,
    monkeypatch: pytest.MonkeyPatch,
    command: list[str],
) -> None:
    write_vitest_workspace(fixture_repo)
    write_registry(
        fixture_repo.registry_path,
        [make_suite(id="unit-ts", commands=[command])],
    )
    observed: list[tuple[str, ...]] = []
    monkeypatch.setattr(verify, "run_command", record_successfully(observed))
    registry = verify.load_registry(fixture_repo.registry_path)
    states = verify.parse_package_states(fixture_repo.status_path)
    outcome = verify.run_suite(fixture_repo, registry.suites[0], states, registry)
    assert outcome.verdict is verify.Verdict.PASS
    if "--" in command:
        split = command.index("--")
        expected = (
            *command[: split + 1],
            "--reporter=default",
            *command[split + 1 :],
        )
    else:
        expected = (*command, "--", "--reporter=default")
    assert observed == [expected]
    assert observed[0].count("--reporter=default") == 1
    if "--concurrency=2" in command:
        assert "--force" in observed[0]
        assert observed[0].index("--concurrency=2") < observed[0].index("--")


@pytest.mark.parametrize(
    "options",
    [
        pytest.param(["--force", "--concurrency=0"], id="zero"),
        pytest.param(["--force", "--concurrency=1"], id="unreviewed-one"),
        pytest.param(["--force", "--concurrency=3"], id="unreviewed-three"),
        pytest.param(["--force", "--concurrency=100%"], id="unbounded-percentage"),
        pytest.param(["--force", "--concurrency"], id="missing-value"),
        pytest.param(["--force", "--concurrency", "2"], id="unapproved-split-form"),
        pytest.param(["--concurrency=2"], id="cache-may-replay-without-force"),
        pytest.param(["--concurrency=2", "--force"], id="unapproved-order"),
        pytest.param(
            ["--force", "--concurrency=2", "--concurrency=2"],
            id="duplicate-option",
        ),
        pytest.param(
            ["--force", "--concurrency=2", "--filter=@japp/probe"],
            id="package-filter",
        ),
        pytest.param(
            ["--force", "--concurrency=2", "--continue=always"],
            id="ignore-task-failure",
        ),
        pytest.param(["--force", "--concurrency=2", "--only"], id="task-scope-only"),
        pytest.param(
            ["--force", "--concurrency=2", "--dry-run"],
            id="discovery-without-execution",
        ),
        pytest.param(
            ["--force", "--concurrency=2", "--daemon"],
            id="unapproved-extra-option",
        ),
    ],
)
def test_turbo_package_concurrency_expansion_fails_before_any_child(
    fixture_repo: verify.Context,
    monkeypatch: pytest.MonkeyPatch,
    options: list[str],
) -> None:
    write_vitest_workspace(fixture_repo)
    write_registry(
        fixture_repo.registry_path,
        [make_suite(id="unit-ts", commands=[["pnpm", "exec", "turbo", "run", "test", *options]])],
    )
    observed: list[tuple[str, ...]] = []
    monkeypatch.setattr(verify, "run_command", record_successfully(observed))
    registry = verify.load_registry(fixture_repo.registry_path)
    states = verify.parse_package_states(fixture_repo.status_path)
    outcome = verify.run_suite(fixture_repo, registry.suites[0], states, registry)
    assert outcome.verdict is verify.Verdict.FAIL
    assert observed == []
    assert any("bounded grammar" in message for message in outcome.messages)
'''
assert not pre[paths[2]].endswith(addition);after[paths[2]]=pre[paths[2]]+addition
for rel in paths:
    for side,data in [('before',pre[rel]),('after',after[rel])]:
        p=O/side/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
(O/'source.patch').write_text(''.join(''.join(difflib.unified_diff(pre[p].splitlines(True),after[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p)) for p in paths))
registry_before=json.loads(pre[paths[0]]);registry_after=json.loads(after[paths[0]])
assert len(registry_before['suites'])==len(registry_after['suites'])
changes=[]
for a,b in zip(registry_before['suites'],registry_after['suites'],strict=True):
    if a!=b:
        assert a['id']=='unit-ts';a=dict(a);b=dict(b);ac=a.pop('commands');bc=b.pop('commands');assert a==b;assert bc==[ac[0]+['--concurrency=2']];changes.append('unit-ts command only')
assert changes==['unit-ts command only']
protected={}
for pattern in ['apps/*/package.json','packages/*/package.json','apps/*/test/**/*.test.ts','apps/*/test/**/*.test.tsx','packages/*/test/**/*.test.ts','packages/*/test/**/*.test.tsx','apps/*/vitest.config.*','packages/*/vitest.config.*']:
    for p in R.glob(pattern):
        if p.is_file():protected[p.relative_to(R).as_posix()]={'bytes':p.stat().st_size,'sha256':sha(p)}
workspace=[{'path':p.relative_to(R).as_posix(),'name':j['name'],'test_script':j['scripts']['test']} for p in sorted([*R.glob('apps/*/package.json'),*R.glob('packages/*/package.json')]) if (j:=json.loads(p.read_text())).get('scripts',{}).get('test')]
(O/'protected-test-inputs.json').write_text(json.dumps({'scope':'STATIC_UNCHANGED_TEST_INPUT_SNAPSHOT_NOT_ACTUAL_TEST_DISCOVERY','workspace_test_tasks':workspace,'protected_files':protected},indent=2)+'\n')
plan={'scope':'THREE_FILE_BOUNDED_HARNESS_SOURCE_PROPOSAL_NO_TEST_EXECUTION','canonical_writes':0,'actual_tests_executed':0,'changed_paths':[],'new_python_regression_cases_declared_not_collected':19,'typescript_tests_changed':0,'registry_proofs_discovery_threshold_changes':0,'python_inventory_refresh':'Root must collect19new parametrized test node IDs and refresh the separately authored exact inventory before aggregate validation.'}
for rel in paths:
    plan['changed_paths'].append({'path':rel,'before':{'bytes':(O/'before'/rel).stat().st_size,'sha256':sha(O/'before'/rel),'mode':stat.S_IMODE((R/rel).lstat().st_mode)},'after':{'bytes':(O/'after'/rel).stat().st_size,'sha256':sha(O/'after'/rel)}})
(O/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'source_paths':len(paths),'workspace_test_tasks':len(workspace),'protected_sourcefiles':len(protected),'test_cases_declared':19,'patch_sha256':sha(O/'source.patch')}))
