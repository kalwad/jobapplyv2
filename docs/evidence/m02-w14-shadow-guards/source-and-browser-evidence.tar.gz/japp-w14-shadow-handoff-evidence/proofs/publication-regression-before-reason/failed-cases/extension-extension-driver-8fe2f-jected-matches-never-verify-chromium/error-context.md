# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-drivers.spec.ts >> FW3/VAL1/VAL2/DATE2: immediate-only or site-rejected matches never verify
- Location: e2e/extension/extension-drivers.spec.ts:616:1

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected value: "SITE_REJECTED"
Received array: ["PERSISTENCE_NOT_VERIFIED", "RESOLUTION_STALE"]
```

# Test source

```ts
  581 |   await expect(vuePage.locator("html")).toHaveAttribute(
  582 |     CONTENT_READY_ATTRIBUTE,
  583 |     CONTENT_READY_VALUE,
  584 |   );
  585 |   const vueTabId = await tabIdForPage(serviceWorker, vuePage);
  586 |   const vue: Harness = {
  587 |     page: vuePage,
  588 |     controller: react.controller,
  589 |     tabId: vueTabId,
  590 |   };
  591 |   scanned = await descriptors(vue);
  592 |   await vue.page.evaluate(() => {
  593 |     window.setTimeout(() => {
  594 |       document
  595 |         .getElementById("vue-rerender")
  596 |         ?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
  597 |     }, 20);
  598 |   });
  599 |   const vueResult = await execute(
  600 |     vue,
  601 |     descriptorByLabel(scanned, "Full name (required)"),
  602 |     { kind: "TEXT", text: "Synthetic Vue" },
  603 |     undefined,
  604 |     125,
  605 |   );
  606 |   expect(vueResult.result.outcome).toBe("VERIFIED");
  607 |   await expect(vue.page.locator("#vue-state-full-name")).toHaveText(
  608 |     "Synthetic Vue",
  609 |   );
  610 |   await vue.page.locator("#vue-rerender").dispatchEvent("click");
  611 |   expect(await vue.page.locator("#vue-full-name").inputValue()).toBe(
  612 |     "Synthetic Vue",
  613 |   );
  614 | });
  615 | 
  616 | test("FW3/VAL1/VAL2/DATE2: immediate-only or site-rejected matches never verify", async ({
  617 |   extensionContext,
  618 |   extensionId,
  619 |   serviceWorker,
  620 | }) => {
  621 |   const react = await openHarness(
  622 |     extensionContext,
  623 |     extensionId,
  624 |     serviceWorker,
  625 |     "/react/",
  626 |   );
  627 |   const scannedReact = await descriptors(react);
  628 |   await react.page.evaluate(() => {
  629 |     for (const eventName of ["input", "change"]) {
  630 |       document.addEventListener(
  631 |         eventName,
  632 |         (event) => {
  633 |           if ((event.target as HTMLElement).id === "react-full-name") {
  634 |             event.stopImmediatePropagation();
  635 |           }
  636 |         },
  637 |         true,
  638 |       );
  639 |     }
  640 |     window.setTimeout(() => {
  641 |       document
  642 |         .getElementById("react-rerender")
  643 |         ?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
  644 |     }, 20);
  645 |   });
  646 |   const rollback = await execute(
  647 |     react,
  648 |     descriptorByLabel(scannedReact, "Full name (required)"),
  649 |     { kind: "TEXT", text: "Transient only" },
  650 |     undefined,
  651 |     125,
  652 |   );
  653 |   expect(rollback.result.outcome).toBe("FAILED");
  654 |   expect(rollback.result.reason_codes).toContain("PERSISTENCE_NOT_VERIFIED");
  655 |   expect(await react.page.locator("#react-full-name").inputValue()).toBe("");
  656 | 
  657 |   await replaceBody(
  658 |     react,
  659 |     `<main><form>
  660 |       <label for="rejected">Rejected value</label>
  661 |       <input id="rejected" aria-describedby="rejected-error">
  662 |       <p id="rejected-error" class="error"></p>
  663 |       <label for="date">Bounded date</label>
  664 |       <input id="date" type="date" min="2030-01-01">
  665 |     </form></main>`,
  666 |   );
  667 |   await react.page.locator("#rejected").evaluate((input) => {
  668 |     input.addEventListener("input", () => {
  669 |       const error = document.getElementById("rejected-error");
  670 |       if (error === null) throw new Error("rejection surface missing");
  671 |       error.textContent = "Rejected by synthetic site rule";
  672 |     });
  673 |   });
  674 |   const scanned = await descriptors(react);
  675 |   const rejected = await execute(
  676 |     react,
  677 |     descriptorByLabel(scanned, "Rejected value"),
  678 |     { kind: "TEXT", text: "matching-dom-value" },
  679 |   );
  680 |   expect(rejected.result.outcome).toBe("NEEDS_REVIEW");
> 681 |   expect(rejected.result.reason_codes).toContain("SITE_REJECTED");
      |                                        ^ Error: expect(received).toContain(expected) // indexOf
  682 |   expect(JSON.stringify(rejected)).not.toContain("matching-dom-value");
  683 |   expect(JSON.stringify(rejected)).not.toContain("Rejected by synthetic");
  684 | 
  685 |   const invalidDate = await execute(
  686 |     react,
  687 |     descriptorByLabel(scanned, "Bounded date"),
  688 |     { kind: "DATE", iso_date: "2027-01-01" },
  689 |   );
  690 |   expect(invalidDate.result.outcome).not.toBe("VERIFIED");
  691 |   expect(invalidDate.result.site_acceptance).toBe("REJECTED");
  692 | });
  693 | 
  694 | test("SEL2/SEL3/RAD2: missing, disabled, disappearing, and duplicate semantic options are never guessed", async ({
  695 |   extensionContext,
  696 |   extensionId,
  697 |   serviceWorker,
  698 | }) => {
  699 |   const harness = await openHarness(
  700 |     extensionContext,
  701 |     extensionId,
  702 |     serviceWorker,
  703 |     "/native/",
  704 |   );
  705 |   await replaceBody(
  706 |     harness,
  707 |     `<main><form>
  708 |       <label for="choice">Exact choice</label>
  709 |       <select id="choice"><option value="" selected>Choose exactly</option><option value="unrelated">Only unrelated</option><option value="disabled" disabled>Disabled target</option></select>
  710 |       <fieldset><legend>Duplicate radio</legend>
  711 |         <label><input type="radio" name="dup" value="same"> First</label>
  712 |         <label><input type="radio" name="dup" value="same"> Second</label>
  713 |       </fieldset>
  714 |     </form></main>`,
  715 |   );
  716 |   const scanned = await descriptors(harness);
  717 |   const choice = descriptorByLabel(scanned, "Exact choice");
  718 |   const missing = await execute(harness, choice, {
  719 |     kind: "OPTION",
  720 |     value_digest: await semanticDigest("option-value-v1\0missing"),
  721 |   });
  722 |   expect(missing.result.outcome).not.toBe("VERIFIED");
  723 |   expect(await harness.page.locator("#choice").inputValue()).toBe("");
  724 |   const disabled = await execute(harness, choice, {
  725 |     kind: "OPTION",
  726 |     value_digest: await semanticDigest("option-value-v1\0disabled"),
  727 |   });
  728 |   expect(disabled.result.outcome).not.toBe("VERIFIED");
  729 |   expect(await harness.page.locator("#choice").inputValue()).toBe("");
  730 | 
  731 |   const radio = await execute(
  732 |     harness,
  733 |     descriptorByLabel(scanned, "Duplicate radio"),
  734 |     {
  735 |       kind: "OPTION",
  736 |       value_digest: await semanticDigest("option-value-v1\0same"),
  737 |     },
  738 |   );
  739 |   expect(radio.result.outcome).not.toBe("VERIFIED");
  740 |   expect(await harness.page.locator("input[type=radio]:checked").count()).toBe(
  741 |     0,
  742 |   );
  743 | 
  744 |   await harness.page.locator("option[value='disabled']").evaluate((option) => {
  745 |     option.remove();
  746 |   });
  747 |   const vanished = await execute(harness, choice, {
  748 |     kind: "OPTION",
  749 |     value_digest: await semanticDigest("option-value-v1\0disabled"),
  750 |   });
  751 |   expect(vanished.result.outcome).not.toBe("VERIFIED");
  752 |   expect(await harness.page.locator("#choice").inputValue()).toBe("");
  753 | });
  754 | 
  755 | test("COMBO1/COMBO2/COMBO3: ARIA combobox commits exact options, reselects after stale query, and refuses missing/duplicate targets", async ({
  756 |   extensionContext,
  757 |   extensionId,
  758 |   serviceWorker,
  759 | }) => {
  760 |   const harness = await openHarness(
  761 |     extensionContext,
  762 |     extensionId,
  763 |     serviceWorker,
  764 |     "/combobox/",
  765 |   );
  766 |   let scanned = await descriptors(harness);
  767 |   let combo = descriptorByLabel(scanned, "Office location");
  768 |   const first = await execute(harness, combo, {
  769 |     kind: "OPTION",
  770 |     value_digest: await semanticDigest(
  771 |       "option-value-v1\0Fable Crossing (synthetic)",
  772 |     ),
  773 |   });
  774 |   expect(first.result.outcome).toBe("VERIFIED");
  775 |   expect(await harness.page.locator("#cbx-input").inputValue()).toBe(
  776 |     "Fable Crossing (synthetic)",
  777 |   );
  778 | 
  779 |   scanned = await descriptors(harness);
  780 |   combo = descriptorByLabel(scanned, "Office location");
  781 |   const second = await execute(harness, combo, {
```