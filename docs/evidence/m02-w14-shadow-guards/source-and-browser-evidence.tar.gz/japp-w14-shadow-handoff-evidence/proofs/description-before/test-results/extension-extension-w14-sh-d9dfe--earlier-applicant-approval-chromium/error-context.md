# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w14-shadow-peer.spec.ts >> W14 peer: document description ownership change invalidates an earlier applicant approval
- Location: e2e/extension/extension-w14-shadow-peer.spec.ts:508:3

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 2
+ Received  + 2

  Object {
-   "change": 0,
-   "input": 0,
+   "change": 1,
+   "input": 1,
  }
```

# Test source

```ts
  505 | });
  506 | 
  507 | for (const ownershipTree of ["document", "shadow"] as const) {
  508 |   test(`W14 peer: ${ownershipTree} description ownership change invalidates an earlier applicant approval`, async ({
  509 |     extensionContext,
  510 |     extensionId,
  511 |     serviceWorker,
  512 |   }, testInfo) => {
  513 |     const harness = await openHarness(
  514 |       extensionContext,
  515 |       extensionId,
  516 |       serviceWorker,
  517 |       "/native/",
  518 |     );
  519 |     try {
  520 |       const controls =
  521 |         '<span id="ownership">Your contact</span><label for="first">First name</label><input id="first" name="first" aria-describedby="ownership" required>';
  522 |       await setFixture(
  523 |         harness,
  524 |         '<form data-japp-application-root="true"><div id="owner-host"></div></form>',
  525 |       );
  526 |       await harness.page.evaluate(
  527 |         ({ controls, ownershipTree }) => {
  528 |           const host = document.getElementById("owner-host");
  529 |           if (host === null) throw new Error("owner host absent");
  530 |           const root =
  531 |             ownershipTree === "shadow"
  532 |               ? host.attachShadow({ mode: "open" })
  533 |               : host;
  534 |           root.innerHTML = controls;
  535 |           const input = root.querySelector("input");
  536 |           if (input === null) throw new Error("input absent");
  537 |           const meter = { input: 0, change: 0 };
  538 |           (
  539 |             window as unknown as { peerDescriptionMeter: typeof meter }
  540 |           ).peerDescriptionMeter = meter;
  541 |           input.addEventListener("input", () => {
  542 |             meter.input++;
  543 |           });
  544 |           input.addEventListener("change", () => {
  545 |             meter.change++;
  546 |           });
  547 |         },
  548 |         { controls, ownershipTree },
  549 |       );
  550 |       const top = foundTopFrame(await scanFrames(harness));
  551 |       const before = descriptorByLabel(top.descriptors, "First name");
  552 |       expect(before.description?.normalized_text).toBe("Your contact");
  553 |       const oldApproval = await approvedTransaction(
  554 |         before,
  555 |         `peer-owner-before-${ownershipTree}`,
  556 |         {
  557 |           kind: "TEXT",
  558 |           text: "Synthetic",
  559 |         },
  560 |       );
  561 |       expect(oldApproval.decision.final_decision).toBe("FILL");
  562 |       await harness.page.locator("#ownership").evaluate((node) => {
  563 |         node.textContent = "Employer";
  564 |       });
  565 |       const changed = descriptorByLabel(
  566 |         foundTopFrame(await scanFrames(harness)).descriptors,
  567 |         "First name",
  568 |       );
  569 |       expect(changed.description?.normalized_text).toBe("Employer");
  570 |       const currentApproval = await approvedTransaction(
  571 |         changed,
  572 |         `peer-owner-after-${ownershipTree}`,
  573 |         {
  574 |           kind: "TEXT",
  575 |           text: "Synthetic",
  576 |         },
  577 |       );
  578 |       expect(currentApproval.decision.final_decision).not.toBe("FILL");
  579 |       const execution = await dynExecute(harness, [oldApproval]);
  580 |       const meter = await harness.page.evaluate(
  581 |         () =>
  582 |           (
  583 |             window as unknown as {
  584 |               peerDescriptionMeter: { input: number; change: number };
  585 |             }
  586 |           ).peerDescriptionMeter,
  587 |       );
  588 |       const value = await harness.page.locator("#first").inputValue();
  589 |       await testInfo.attach(`w14-description-ownership-${ownershipTree}.json`, {
  590 |         body: JSON.stringify(
  591 |           {
  592 |             before,
  593 |             changed,
  594 |             oldApproval,
  595 |             currentApproval,
  596 |             execution,
  597 |             meter,
  598 |             value,
  599 |           },
  600 |           null,
  601 |           2,
  602 |         ),
  603 |         contentType: "application/json",
  604 |       });
> 605 |       expect(meter).toEqual({ input: 0, change: 0 });
      |                     ^ Error: expect(received).toEqual(expected) // deep equality
  606 |       expect(value).toBe("");
  607 |       expect(execution.items[0]?.status).toBe("EXECUTED");
  608 |       if (execution.items[0]?.status === "EXECUTED")
  609 |         expect(execution.items[0].result.outcome).not.toBe("VERIFIED");
  610 |     } finally {
  611 |       await harness.page.close();
  612 |       await harness.controller.close();
  613 |     }
  614 |   });
  615 | }
  616 | 
```