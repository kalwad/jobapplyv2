# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w14-outside-owner-peer.spec.ts >> W14 peer: shadow outside-root Employer ownership at initial prevents applicant writes
- Location: e2e/extension/extension-w14-outside-owner-peer.spec.ts:17:5

# Error details

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "FILL"
```

# Test source

```ts
  29  |         await setFixture(
  30  |           harness,
  31  |           '<section id="outside-owner" aria-label="Your contact"><div id="owner-host"></div></section>',
  32  |         );
  33  |         await harness.page.evaluate(
  34  |           ({ tree, phase }) => {
  35  |             const outer = document.getElementById("outside-owner"),
  36  |               host = document.getElementById("owner-host");
  37  |             if (outer === null || host === null)
  38  |               throw new Error("outer owner fixture missing");
  39  |             outer.setAttribute(
  40  |               "aria-label",
  41  |               phase === "initial" ? "Employer" : "Your contact",
  42  |             );
  43  |             const root =
  44  |               tree === "shadow" ? host.attachShadow({ mode: "open" }) : host;
  45  |             root.innerHTML =
  46  |               '<form data-japp-application-root="true"><label for="first">First name</label><input id="first" name="first" required></form>';
  47  |             const input = root.querySelector("input");
  48  |             if (input === null) throw new Error("input fixture missing");
  49  |             const meter = { focus: 0, input: 0, change: 0 };
  50  |             (
  51  |               window as unknown as { peerOutsideOwnerMeter: typeof meter }
  52  |             ).peerOutsideOwnerMeter = meter;
  53  |             input.addEventListener("focus", () => {
  54  |               meter.focus++;
  55  |               if (phase === "focus")
  56  |                 outer.setAttribute("aria-label", "Employer");
  57  |             });
  58  |             input.addEventListener("input", () => {
  59  |               meter.input++;
  60  |             });
  61  |             input.addEventListener("change", () => {
  62  |               meter.change++;
  63  |             });
  64  |           },
  65  |           { tree, phase },
  66  |         );
  67  |         const top = foundTopFrame(await scanFrames(harness));
  68  |         const before = descriptorByLabel(top.descriptors, "First name");
  69  |         const transaction = await approvedTransaction(
  70  |           before,
  71  |           `peer-outside-owner-${tree}-${phase}`,
  72  |           { kind: "TEXT", text: "Synthetic" },
  73  |         );
  74  |         if (phase === "before-execute")
  75  |           await harness.page.locator("#outside-owner").evaluate((node) => {
  76  |             node.setAttribute("aria-label", "Employer");
  77  |           });
  78  |         // Preserve the actual erroneous before behavior only when real W09
  79  |         // permits it. No forged FILL decision or authority enters this probe.
  80  |         const execution =
  81  |           transaction.decision.final_decision === "FILL"
  82  |             ? await dynExecute(harness, [transaction])
  83  |             : null;
  84  |         const changed = descriptorByLabel(
  85  |           foundTopFrame(await scanFrames(harness)).descriptors,
  86  |           "First name",
  87  |         );
  88  |         const currentDecision = await approvedTransaction(
  89  |           changed,
  90  |           `peer-outside-owner-after-${tree}-${phase}`,
  91  |           { kind: "TEXT", text: "Synthetic" },
  92  |         );
  93  |         const inventory = reconciled(
  94  |           await dynReconcile(harness, top.frame_context.frame_id),
  95  |         );
  96  |         const meter = await harness.page.evaluate(
  97  |           () =>
  98  |             (
  99  |               window as unknown as {
  100 |                 peerOutsideOwnerMeter: {
  101 |                   focus: number;
  102 |                   input: number;
  103 |                   change: number;
  104 |                 };
  105 |               }
  106 |             ).peerOutsideOwnerMeter,
  107 |         );
  108 |         const value = await harness.page.locator("#first").inputValue();
  109 |         await testInfo.attach(`w14-outside-owner-${tree}-${phase}.json`, {
  110 |           body: JSON.stringify(
  111 |             {
  112 |               tree,
  113 |               phase,
  114 |               before,
  115 |               transaction,
  116 |               changed,
  117 |               currentDecision,
  118 |               execution,
  119 |               inventory,
  120 |               meter,
  121 |               value,
  122 |             },
  123 |             null,
  124 |             2,
  125 |           ),
  126 |           contentType: "application/json",
  127 |         });
  128 |         if (phase === "initial")
> 129 |           expect(transaction.decision.final_decision).not.toBe("FILL");
      |                                                           ^ Error: expect(received).not.toBe(expected) // Object.is equality
  130 |         else expect(transaction.decision.final_decision).toBe("FILL");
  131 |         expect(currentDecision.decision.final_decision).not.toBe("FILL");
  132 |         expect(meter.input).toBe(0);
  133 |         expect(meter.change).toBe(0);
  134 |         expect(value).toBe("");
  135 |         if (phase === "focus") expect(meter.focus).toBe(1);
  136 |         if (execution?.items[0]?.status === "EXECUTED")
  137 |           expect(execution.items[0].result.outcome).not.toBe("VERIFIED");
  138 |         expect(inventory.inventory.readiness).toBe("NOT_READY");
  139 |       } finally {
  140 |         await harness.page.close();
  141 |         await harness.controller.close();
  142 |       }
  143 |     });
  144 |   }
  145 | }
  146 | 
```