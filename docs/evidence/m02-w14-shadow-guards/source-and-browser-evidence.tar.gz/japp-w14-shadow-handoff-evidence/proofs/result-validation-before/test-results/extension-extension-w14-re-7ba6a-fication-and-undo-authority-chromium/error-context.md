# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w14-result-ownership-peer.spec.ts >> W14 peer: aria-invalid drift during final result metadata hash refuses direct verification and undo authority
- Location: e2e/extension/extension-w14-result-ownership-peer.spec.ts:104:3

# Error details

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "VERIFIED"
```

# Test source

```ts
  108 |   }, testInfo) => {
  109 |     const harness = await openHarness(
  110 |       extensionContext,
  111 |       extensionId,
  112 |       serviceWorker,
  113 |       "/native/",
  114 |     );
  115 |     let session: CDPSession | undefined;
  116 |     let contextId: number | undefined;
  117 |     let pending: ReturnType<typeof dynExecute> | undefined;
  118 |     try {
  119 |       await setFixture(
  120 |         harness,
  121 |         '<form data-japp-application-root="true"><span id="ownership">Your contact</span><label for="first">First name</label><input id="first" name="first" aria-describedby="ownership" aria-invalid="false" required></form>',
  122 |       );
  123 |       await harness.page.evaluate(() => {
  124 |         const input = document.getElementById("first");
  125 |         if (input === null) throw new Error("input missing");
  126 |         const meter = { input: 0, change: 0 };
  127 |         (
  128 |           window as unknown as { peerResultMeter: typeof meter }
  129 |         ).peerResultMeter = meter;
  130 |         input.addEventListener("input", () => {
  131 |           meter.input++;
  132 |         });
  133 |         input.addEventListener("change", () => {
  134 |           meter.change++;
  135 |         });
  136 |       });
  137 |       const top = foundTopFrame(await scanFrames(harness));
  138 |       const descriptor = descriptorByLabel(top.descriptors, "First name");
  139 |       const transaction = await approvedTransaction(
  140 |         descriptor,
  141 |         `peer-result-hash-${drift}`,
  142 |         { kind: "TEXT", text: "Synthetic" },
  143 |       );
  144 |       expect(transaction.decision.final_decision).toBe("FILL");
  145 |       session = await extensionContext.newCDPSession(harness.page);
  146 |       contextId = await contentExecutionContext(session, extensionId);
  147 |       await session.send("Runtime.evaluate", {
  148 |         contextId,
  149 |         expression: `(${installResultHashPause.toString()})(${JSON.stringify(`w10-idempotency-v1\0${transaction.transaction_id}\0EXECUTE`)})`,
  150 |       });
  151 |       pending = dynExecute(harness, [transaction]);
  152 |       const activeSession = session,
  153 |         activeContext = contextId;
  154 |       await expect
  155 |         .poll(
  156 |           async () => {
  157 |             const response = await activeSession.send("Runtime.evaluate", {
  158 |               contextId: activeContext,
  159 |               expression:
  160 |                 "globalThis.__JAPP_W14_TEST_RESULT_HASH_PAUSE__?.reached === true",
  161 |               returnByValue: true,
  162 |             });
  163 |             return response.result.value as unknown;
  164 |           },
  165 |           { timeout: 5000 },
  166 |         )
  167 |         .toBe(true);
  168 |       expect(await harness.page.locator("#first").inputValue()).toBe(
  169 |         "Synthetic",
  170 |       );
  171 |       if (drift === "description") {
  172 |         await harness.page.locator("#ownership").evaluate((node) => {
  173 |           node.textContent = "Employer";
  174 |         });
  175 |       } else {
  176 |         await harness.page.locator("#first").evaluate((node) => {
  177 |           node.setAttribute("aria-invalid", "true");
  178 |         });
  179 |       }
  180 |       await session.send("Runtime.evaluate", {
  181 |         contextId,
  182 |         expression: "globalThis.__JAPP_W14_TEST_RESULT_HASH_PAUSE__.release()",
  183 |       });
  184 |       const execution = await pending;
  185 |       pending = undefined;
  186 |       const inventory = reconciled(
  187 |         await dynReconcile(harness, top.frame_context.frame_id),
  188 |       );
  189 |       const meter = await harness.page.evaluate(
  190 |         () =>
  191 |           (
  192 |             window as unknown as {
  193 |               peerResultMeter: { input: number; change: number };
  194 |             }
  195 |           ).peerResultMeter,
  196 |       );
  197 |       await testInfo.attach(`w14-result-hash-${drift}.json`, {
  198 |         body: JSON.stringify(
  199 |           { drift, descriptor, transaction, execution, inventory, meter },
  200 |           null,
  201 |           2,
  202 |         ),
  203 |         contentType: "application/json",
  204 |       });
  205 |       expect(meter).toEqual({ input: 1, change: 1 });
  206 |       expect(execution.items[0]?.status).toBe("EXECUTED");
  207 |       if (execution.items[0]?.status === "EXECUTED") {
> 208 |         expect(execution.items[0].result.outcome).not.toBe("VERIFIED");
      |                                                       ^ Error: expect(received).not.toBe(expected) // Object.is equality
  209 |         expect(execution.items[0].undo_available).toBe(false);
  210 |       }
  211 |       expect(inventory.inventory.readiness).toBe("NOT_READY");
  212 |     } finally {
  213 |       if (session !== undefined && contextId !== undefined)
  214 |         await session.send("Runtime.evaluate", {
  215 |           contextId,
  216 |           expression:
  217 |             "globalThis.__JAPP_W14_TEST_RESULT_HASH_PAUSE__?.restore()",
  218 |         });
  219 |       await pending?.catch(() => undefined);
  220 |       await session?.detach();
  221 |       await harness.page.close();
  222 |       await harness.controller.close();
  223 |     }
  224 |   });
  225 | }
  226 | 
```