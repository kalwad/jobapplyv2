# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w14-shadow-peer.spec.ts >> W14 peer: delayed prompt ownership change prevents post-await option commit
- Location: e2e/extension/extension-w14-shadow-peer.spec.ts:623:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 1

  Object {
-   "commits": 0,
+   "commits": 1,
    "opens": 1,
  }
```

# Test source

```ts
  622 | 
  623 | test("W14 peer: delayed prompt ownership change prevents post-await option commit", async ({
  624 |   extensionContext,
  625 |   extensionId,
  626 |   serviceWorker,
  627 | }, testInfo) => {
  628 |   const harness = await openHarness(
  629 |     extensionContext,
  630 |     extensionId,
  631 |     serviceWorker,
  632 |     "/native/",
  633 |   );
  634 |   try {
  635 |     await setFixture(
  636 |       harness,
  637 |       '<form data-japp-application-root="true"><span id="ownership">Your contact</span><div id="country" aria-label="Country" role="combobox" aria-controls="options" aria-expanded="false" aria-describedby="ownership" aria-required="true" tabindex="0" style="display:block;width:240px;height:32px"></div><div id="options" role="listbox" hidden><div id="country-us" role="option" data-value="US" aria-selected="false">United States</div><div role="option" data-value="CA" aria-selected="false">Canada</div></div></form>',
  638 |     );
  639 |     await harness.page.evaluate(() => {
  640 |       const prompt = document.getElementById("country"),
  641 |         list = document.getElementById("options"),
  642 |         ownership = document.getElementById("ownership");
  643 |       if (prompt === null || list === null || ownership === null)
  644 |         throw new Error("prompt fixture missing");
  645 |       const meter = { opens: 0, commits: 0 };
  646 |       (window as unknown as { peerPromptMeter: typeof meter }).peerPromptMeter =
  647 |         meter;
  648 |       prompt.addEventListener("click", () => {
  649 |         meter.opens++;
  650 |         prompt.setAttribute("aria-expanded", "true");
  651 |         ownership.textContent = "Employer";
  652 |         setTimeout(() => {
  653 |           list.removeAttribute("hidden");
  654 |         }, 20);
  655 |       });
  656 |       list.addEventListener("click", (event) => {
  657 |         const option = event.target;
  658 |         if (
  659 |           !(option instanceof HTMLElement) ||
  660 |           option.getAttribute("role") !== "option"
  661 |         )
  662 |           return;
  663 |         meter.commits++;
  664 |         option.setAttribute("aria-selected", "true");
  665 |         prompt.setAttribute("aria-activedescendant", option.id);
  666 |         prompt.setAttribute("aria-expanded", "false");
  667 |         list.setAttribute("hidden", "");
  668 |       });
  669 |     });
  670 |     const top = foundTopFrame(await scanFrames(harness));
  671 |     const field = descriptorByLabel(top.descriptors, "Country");
  672 |     const decision = await resolveFieldDecision({
  673 |       descriptor: field,
  674 |       records: buildApprovedRecordSet([
  675 |         {
  676 |           recordId: await stableSemanticId("record", "peer-delayed-country"),
  677 |           concept: "ADDRESS_COUNTRY",
  678 |           valueToken: "US",
  679 |           policy: "FILL_FROM_EXPLICIT_RECORD",
  680 |           confirmation: { state: "MISSING" },
  681 |           valueConfidence: 1,
  682 |         },
  683 |       ]),
  684 |       correlationId: await stableSemanticId("cor", "peer-delayed-country"),
  685 |     });
  686 |     expect(decision.status).toBe("RESOLVED");
  687 |     if (
  688 |       decision.status !== "RESOLVED" ||
  689 |       decision.resolution.optionResolution?.status !== "RESOLVED"
  690 |     )
  691 |       throw new Error("approved country option absent");
  692 |     expect(decision.resolution.decision.final_decision).toBe("FILL");
  693 |     const transaction = await buildTransaction(
  694 |       field,
  695 |       {
  696 |         kind: "OPTION",
  697 |         value_digest: decision.resolution.optionResolution.valueDigest,
  698 |       },
  699 |       decision.resolution.decision,
  700 |       "peer-delayed-country",
  701 |     );
  702 |     const execution = await dynExecute(harness, [transaction]);
  703 |     const meter = await harness.page.evaluate(
  704 |       () =>
  705 |         (
  706 |           window as unknown as {
  707 |             peerPromptMeter: { opens: number; commits: number };
  708 |           }
  709 |         ).peerPromptMeter,
  710 |     );
  711 |     const selected = await harness.page
  712 |       .locator("#country-us")
  713 |       .getAttribute("aria-selected");
  714 |     await testInfo.attach("w14-delayed-prompt-ownership.json", {
  715 |       body: JSON.stringify(
  716 |         { field, decision, execution, meter, selected },
  717 |         null,
  718 |         2,
  719 |       ),
  720 |       contentType: "application/json",
  721 |     });
> 722 |     expect(meter).toEqual({ opens: 1, commits: 0 });
      |                   ^ Error: expect(received).toEqual(expected) // deep equality
  723 |     expect(selected).toBe("false");
  724 |     expect(execution.items[0]?.status).toBe("EXECUTED");
  725 |     if (execution.items[0]?.status === "EXECUTED")
  726 |       expect(execution.items[0].result.outcome).not.toBe("VERIFIED");
  727 |   } finally {
  728 |     await harness.page.close();
  729 |     await harness.controller.close();
  730 |   }
  731 | });
  732 | 
```