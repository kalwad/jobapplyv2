# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w14-outside-owner-peer.spec.ts >> W14 peer: document outside-root ancestry depth270 refuses positive authority and reports required field
- Location: e2e/extension/extension-w14-outside-owner-peer.spec.ts:148:3

# Error details

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "FILL"
```

# Test source

```ts
  119 |               inventory,
  120 |               meter,
  121 |               value,
  122 |             },
  123 |             null,
  124 |             2,
  125 |           ),
  126 |           contentType: "application/json",
  127 |         });
  128 |         if (phase === "initial")
  129 |           expect(transaction.decision.final_decision).not.toBe("FILL");
  130 |         else expect(transaction.decision.final_decision).toBe("FILL");
  131 |         expect(currentDecision.decision.final_decision).not.toBe("FILL");
  132 |         expect(meter.input).toBe(0);
  133 |         expect(meter.change).toBe(0);
  134 |         expect(value).toBe("");
  135 |         if (phase === "focus") expect(meter.focus).toBe(1);
  136 |         if (execution?.items[0]?.status === "EXECUTED")
  137 |           expect(execution.items[0].result.outcome).not.toBe("VERIFIED");
  138 |         expect(inventory.inventory.readiness).toBe("NOT_READY");
  139 |       } finally {
  140 |         await harness.page.close();
  141 |         await harness.controller.close();
  142 |       }
  143 |     });
  144 |   }
  145 | }
  146 | 
  147 | for (const tree of ["document", "shadow"] as const) {
  148 |   test(`W14 peer: ${tree} outside-root ancestry depth270 refuses positive authority and reports required field`, async ({
  149 |     extensionContext,
  150 |     extensionId,
  151 |     serviceWorker,
  152 |   }, testInfo) => {
  153 |     const harness = await openHarness(
  154 |       extensionContext,
  155 |       extensionId,
  156 |       serviceWorker,
  157 |       "/native/",
  158 |     );
  159 |     try {
  160 |       await setFixture(
  161 |         harness,
  162 |         `<section aria-label="Employer">${"<div>".repeat(270)}<div id="deep-owner-host"></div>${"</div>".repeat(270)}</section>`,
  163 |       );
  164 |       await harness.page.evaluate((tree) => {
  165 |         const host = document.getElementById("deep-owner-host");
  166 |         if (host === null) throw new Error("deep host missing");
  167 |         const root =
  168 |           tree === "shadow" ? host.attachShadow({ mode: "open" }) : host;
  169 |         root.innerHTML =
  170 |           '<form data-japp-application-root="true"><label for="first">First name</label><input id="first" name="first" required></form>';
  171 |         const input = root.querySelector("input");
  172 |         if (input === null) throw new Error("deep input missing");
  173 |         const meter = { input: 0, change: 0 };
  174 |         (
  175 |           window as unknown as { peerDeepOwnerMeter: typeof meter }
  176 |         ).peerDeepOwnerMeter = meter;
  177 |         input.addEventListener("input", () => {
  178 |           meter.input++;
  179 |         });
  180 |         input.addEventListener("change", () => {
  181 |           meter.change++;
  182 |         });
  183 |       }, tree);
  184 |       const top = foundTopFrame(await scanFrames(harness));
  185 |       const descriptor = top.descriptors[0];
  186 |       if (descriptor === undefined)
  187 |         throw new Error("required field must be inventoried");
  188 |       const transaction = await approvedTransaction(
  189 |         descriptor,
  190 |         `peer-deep-owner-${tree}`,
  191 |         { kind: "TEXT", text: "Synthetic" },
  192 |       );
  193 |       const execution =
  194 |         transaction.decision.final_decision === "FILL"
  195 |           ? await dynExecute(harness, [transaction])
  196 |           : null;
  197 |       const inventory = reconciled(
  198 |         await dynReconcile(harness, top.frame_context.frame_id),
  199 |       );
  200 |       const meter = await harness.page.evaluate(
  201 |         () =>
  202 |           (
  203 |             window as unknown as {
  204 |               peerDeepOwnerMeter: { input: number; change: number };
  205 |             }
  206 |           ).peerDeepOwnerMeter,
  207 |       );
  208 |       const value = await harness.page.locator("#first").inputValue();
  209 |       await testInfo.attach(`w14-outside-owner-depth270-${tree}.json`, {
  210 |         body: JSON.stringify(
  211 |           { descriptor, transaction, execution, inventory, meter, value },
  212 |           null,
  213 |           2,
  214 |         ),
  215 |         contentType: "application/json",
  216 |       });
  217 |       expect(top.descriptors).toHaveLength(1);
  218 |       expect(descriptor.required).toBe(true);
> 219 |       expect(transaction.decision.final_decision).not.toBe("FILL");
      |                                                       ^ Error: expect(received).not.toBe(expected) // Object.is equality
  220 |       expect(meter).toEqual({ input: 0, change: 0 });
  221 |       expect(value).toBe("");
  222 |       expect(inventory.inventory.counts.required_unresolved).toBe(1);
  223 |       expect(inventory.inventory.readiness).toBe("NOT_READY");
  224 |     } finally {
  225 |       await harness.page.close();
  226 |       await harness.controller.close();
  227 |     }
  228 |   });
  229 | }
  230 | 
```