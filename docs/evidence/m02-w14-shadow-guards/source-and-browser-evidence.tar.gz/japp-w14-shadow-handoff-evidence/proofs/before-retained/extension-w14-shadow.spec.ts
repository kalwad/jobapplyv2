/** W14 regression on the unchanged frozen W03 mounted open-shadow page.
 * Expected behavior is required-field reporting without an other-party fill.
 * A failed assertion preserves the actual missing-root evidence; it is not PASS.
 */
import { mkdirSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { test, expect } from "./support/extension-test.ts";
import {
  openHarness,
  scanFrames,
  dynReconcile,
} from "./support/research-harness.ts";
import {
  buildApprovedRecordSet,
  resolveFieldDecision,
  stableSemanticId,
} from "../../packages/form-engine/src/index.ts";

test("W14 W06 MAL-SHD-001: open-shadow other-party required field is reported and never filled", async ({
  extensionContext,
  extensionId,
  serviceWorker,
}, testInfo) => {
  const harness = await openHarness(extensionContext, extensionId, serviceWorker, "/shadow/");
  try {
    // Playwright's independent locator pierces the OPEN shadow root. The
    // candidate still receives no node reference, selector, or expected answer.
    const actual = await harness.page.locator("#shadow-contact-name").evaluate((node) => ({
      id: node.id,
      required: (node as HTMLInputElement).required,
      value: (node as HTMLInputElement).value,
      open_root: node.getRootNode() instanceof ShadowRoot && (node.getRootNode() as ShadowRoot).mode === "open",
      owner_label: (node as HTMLInputElement).labels?.[0]?.textContent?.trim() ?? null,
    }));
    const frames = await scanFrames(harness);
    const top = frames.find((frame) => frame.frame_context.is_top_frame);
    const descriptor = top?.descriptors.find((field) => field.label.normalized_text === "Emergency contact name (required)");
    const decision = descriptor === undefined ? null : await resolveFieldDecision({
      descriptor,
      records: buildApprovedRecordSet([{
        recordId: await stableSemanticId("record", "w14-shadow-applicant-full-name"),
        concept: "FULL_NAME",
        policy: "FILL_FROM_EXPLICIT_RECORD",
        confirmation: { state: "MISSING" },
        valueConfidence: 1,
      }]),
      correlationId: await stableSemanticId("cor", "w14-shadow-other-party-required"),
    });
    const reconciliation = top === undefined ? null : await dynReconcile(harness, top.frame_context.frame_id);
    const evidence = {
      format_version: "W14_W06_SHADOW_REPORTING_REGRESSION_1",
      authority: "NONE",
      fixture_id: "MAL-SHD-001",
      expected: { required_observed: true, candidate_reports_required: true, applicant_fill_permitted: false },
      actual,
      frames,
      decision,
      reconciliation,
      application_actions: 0,
      limitations: ["Mounted open-shadow fixture only; no closed-shadow claim; no product submit capability."],
    };
    const text = JSON.stringify(evidence, null, 2) + "\n";
    await testInfo.attach("w14-shadow-required-gap.json", { body: text, contentType: "application/json" });
    const directory = process.env.JAPP_W14_W06_ARTIFACT_DIRECTORY;
    if (directory !== undefined) {
      mkdirSync(resolve(directory), { recursive: true });
      writeFileSync(resolve(directory, "shadow-required-gap.json"), text);
    }
    // Correct product expectations remain assertions, rather than accepting
    // UNAVAILABLE/empty inventory as a successful protected-field abstention.
    expect(actual.open_root).toBe(true);
    expect(actual.required).toBe(true);
    expect(actual.value).toBe("");
    expect(top?.root_status).toBe("FOUND");
    expect(descriptor).toBeDefined();
    expect(descriptor?.required).toBe(true);
    expect(decision?.status).toBe("RESOLVED");
    if (decision?.status === "RESOLVED") expect(decision.resolution.decision.final_decision).not.toBe("FILL");
    expect(reconciliation?.status).toBe("RECONCILED");
    if (reconciliation?.status === "RECONCILED") {
      expect(reconciliation.inventory.counts.required_unresolved).toBeGreaterThanOrEqual(1);
      expect(reconciliation.inventory.readiness).toBe("NOT_READY");
    }
    expect(await harness.page.locator("#shadow-contact-name").inputValue()).toBe("");
  } finally {
    await harness.page.close();
    await harness.controller.close();
  }
});


// All writes below are approved through the real W09 resolver. These are
// synthetic contact facts, never a forced decision or selector-based target.
import type { FormFieldDescriptorV1 } from "../../packages/contracts/generated/typescript/index.ts";
import {
  buildTransaction, descriptorByLabel, dynExecute, dynStart, foundTopFrame,
  reconciled, requireValue, setFixture, type Harness,
} from "./support/research-harness.ts";

async function ownFirstNameTransaction(field: FormFieldDescriptorV1, seed: string) {
  const resolved = await resolveFieldDecision({
    descriptor: field,
    records: buildApprovedRecordSet([{
      recordId: await stableSemanticId("record", "w14-shadow-own-first-name"),
      concept: "FIRST_NAME", policy: "FILL_FROM_EXPLICIT_RECORD",
      confirmation: { state: "MISSING" }, valueConfidence: 1,
    }]),
    correlationId: await stableSemanticId("cor", seed),
  });
  expect(resolved.status).toBe("RESOLVED");
  if (resolved.status !== "RESOLVED") throw new Error("shadow decision refused");
  expect(resolved.resolution.decision.final_decision).toBe("FILL");
  return buildTransaction(field, { kind: "TEXT", text: "Synthetic" }, resolved.resolution.decision, seed);
}

async function createShadow(harness: Harness, markup: string, hosts = 1) {
  await setFixture(harness, `<main data-japp-application-root aria-label="Application"><h1>Contact</h1>${Array.from({length: hosts}, (_, i) => `<div id="host-${String(i)}"></div>`).join("")}</main>`);
  await harness.page.evaluate(({ html, count }) => {
    for (let i = 0; i < count; i++) document.getElementById(`host-${String(i)}`)?.attachShadow({mode:"open"}).replaceChildren(document.createRange().createContextualFragment(html));
  }, { html: markup, count: hosts });
}
const OWN = '<label for="given">First name</label><input id="given" name="given" required aria-describedby="error"><p id="error" class="error"></p>';

for (const scenario of ["approved", "duplicate", "late-duplicate", "rerender", "removed", "hidden-host", "local-error"] as const) {
  test(`W14 open shadow: ${scenario}`, async ({ extensionContext, extensionId, serviceWorker }) => {
    const harness = await openHarness(extensionContext, extensionId, serviceWorker, "/native/");
    try {
      await harness.page.bringToFront();
      await createShadow(harness, OWN, scenario === "duplicate" ? 2 : 1);
      // Same ID outside the local tree must never label/validate shadow fields.
      await harness.page.evaluate(() => {
        document.body.insertAdjacentHTML("beforeend", '<label for="given">Employer first name</label><p id="error" class="error">Wrong global error</p>');
      });
      const top = foundTopFrame(await scanFrames(harness));
      const field = descriptorByLabel(top.descriptors, "First name");
      expect(field.required).toBe(true);
      const transaction = await ownFirstNameTransaction(field, `shadow-${scenario}`);
      // Build the current semantic index once before a silent root attachment.
      await dynReconcile(harness, top.frame_context.frame_id);
      if (scenario === "late-duplicate") await harness.page.evaluate((html) => {
        const host = document.createElement("div"); host.id = "late-host";
        document.querySelector("main")?.append(host);
        // Let the light DOM observer drain before attaching the previously empty host.
        (window as unknown as {lateHost: HTMLElement}).lateHost = host;
      }, OWN);
      if (scenario === "late-duplicate") {
        await dynReconcile(harness, top.frame_context.frame_id);
        await harness.page.evaluate((html) => (window as unknown as {lateHost: HTMLElement}).lateHost.attachShadow({mode:"open"}).innerHTML = html, OWN);
      }
      await harness.page.evaluate(({ scenario }) => {
        const root = requireRoot();
        function requireRoot() { const value = document.getElementById("host-0")?.shadowRoot; if (!value) throw new Error("root absent"); return value; }
        const meter = { inputs: 0, rerenders: 0 }; (window as unknown as {shadowMeter: typeof meter}).shadowMeter = meter;
        root.addEventListener("input", (event) => {
          if (!(event.target instanceof HTMLInputElement)) return;
          meter.inputs++;
          const node = event.target; const value = node.value;
          if (scenario === "rerender" || scenario === "removed") setTimeout(() => {
            if (scenario === "removed") node.remove();
            else { const replacement = node.cloneNode(true) as HTMLInputElement; replacement.value = value; node.replaceWith(replacement); }
            meter.rerenders++;
          }, 20);
        }, true);
        if (scenario === "hidden-host") document.getElementById("host-0")?.setAttribute("aria-hidden", "true");
        if (scenario === "local-error") { const error = root.getElementById("error"); if (error) error.textContent = "Site rejects this value"; }
      }, { scenario });
      const result = requireValue((await dynExecute(harness, [transaction])).items[0], "missing result");
      expect(result.status).toBe("EXECUTED");
      if (result.status !== "EXECUTED") throw new Error("missing driver result");
      const meter = await harness.page.evaluate(() => (window as unknown as {shadowMeter: {inputs:number;rerenders:number}}).shadowMeter);
      if (scenario === "duplicate" || scenario === "late-duplicate" || scenario === "hidden-host") {
        expect(meter.inputs).toBe(0);
        expect(result.result.outcome).not.toBe("VERIFIED");
        if (scenario !== "hidden-host") expect(result.result.resolution_result).toBe("AMBIGUOUS");
      } else {
        expect(meter.inputs).toBe(1);
        expect(result.result.action_attempt.duration_ms).toBeGreaterThanOrEqual(75);
        if (scenario === "removed" || scenario === "local-error") expect(result.result.outcome).not.toBe("VERIFIED");
        else { expect(result.result.outcome).toBe("VERIFIED"); expect(result.result.persistence_verified).toBe(true); expect(result.result.site_acceptance).toBe("ACCEPTED"); expect(await harness.page.locator("#given").inputValue()).toBe("Synthetic"); }
      }
      if (scenario === "rerender" || scenario === "removed") expect(meter.rerenders).toBe(1);
    } finally { await harness.page.close(); await harness.controller.close(); }
  });
}

test("W14 open shadow: late attached unknown required control joins active reconciliation", async ({ extensionContext, extensionId, serviceWorker }) => {
  const harness = await openHarness(extensionContext, extensionId, serviceWorker, "/native/");
  try {
    await createShadow(harness, OWN);
    await harness.page.evaluate(() => { const host = document.createElement("div"); host.id = "late-host"; document.querySelector("main")?.append(host); });
    const top = foundTopFrame(await scanFrames(harness));
    expect((await dynStart(harness, top.frame_context.frame_id)).status).toBe("STARTED");
    await dynReconcile(harness, top.frame_context.frame_id);
    await harness.page.evaluate(() => { const host = document.getElementById("late-host"); if (!host) throw new Error("host absent"); host.attachShadow({mode:"open"}).innerHTML = '<label for="unknown">Emergency contact name (required)</label><input id="unknown" required>'; });
    const inventory = reconciled(await dynReconcile(harness, top.frame_context.frame_id)).inventory;
    expect(inventory.items.filter((item) => item.required)).toHaveLength(2);
    expect(inventory.counts.required_unresolved).toBe(2);
    expect(inventory.readiness).toBe("NOT_READY");
    expect(await harness.page.locator("#unknown").inputValue()).toBe("");
  } finally { await harness.page.close(); await harness.controller.close(); }
});

test("W14 open shadow: root capacity refuses complete-inventory claims", async ({ extensionContext, extensionId, serviceWorker }) => {
  const harness = await openHarness(extensionContext, extensionId, serviceWorker, "/native/");
  try {
    await createShadow(harness, OWN, 65);
    const top = (await scanFrames(harness)).find((frame) => frame.frame_context.is_top_frame);
    expect(top?.root_status).toBe("CAPACITY_EXCEEDED");
    expect(top?.descriptors).toEqual([]);
  } finally { await harness.page.close(); await harness.controller.close(); }
});
