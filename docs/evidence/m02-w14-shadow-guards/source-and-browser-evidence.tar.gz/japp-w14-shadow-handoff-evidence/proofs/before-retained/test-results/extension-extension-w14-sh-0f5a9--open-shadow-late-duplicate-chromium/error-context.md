# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w14-shadow.spec.ts >> W14 open shadow: late-duplicate
- Location: e2e/extension/extension-w14-shadow.spec.ts:125:3

# Error details

```
Error: top frame with application root missing
```

# Test source

```ts
  1   | // Shared W12 harness derived from retained W11 browser proof; original tests remain byte-identical.
  2   | // M02-W11 real-MV3 dynamic-state proof. Every scenario routes through the
  3   | // generated WXT worker, the registered frame content agent, W08 semantic
  4   | // scanning/re-resolution, canonical W09 decisions, the W10 transaction
  5   | // kernel, and the W11 dynamic engine — bounded observation, batched
  6   | // affected-subtree scanning, conditional discovery/removal, duplicate-action
  7   | // suppression, page-changed-value detection, canonical reconciliation, and
  8   | // truthful CPU/memory/scan instrumentation — in bundled Chromium.
  9   | import type {
  10  |   FormFieldDecisionV1,
  11  |   FormFieldDescriptorV1,
  12  | } from "../../../packages/contracts/generated/typescript/index.ts";
  13  | import {
  14  |   validateFormReconciliationInventoryV1,
  15  |   validateSemanticContractV1,
  16  | } from "../../../packages/contracts/generated/typescript/index.ts";
  17  | import type { BrowserContext, Page, Worker } from "@playwright/test";
  18  | 
  19  | import { fieldAddressDigest } from "../../../apps/extension/src/driver-evidence.ts";
  20  | import type {
  21  |   DriverIntendedValue,
  22  |   DriverTransactionRequest,
  23  | } from "../../../apps/extension/src/driver-protocol.ts";
  24  | import {
  25  |   buildDynamicExecuteTabRequest,
  26  |   buildDynamicReconcileTabRequest,
  27  |   buildDynamicStartTabRequest,
  28  |   buildDynamicStateTabRequest,
  29  |   buildDynamicStopTabRequest,
  30  |   parseDynamicExecuteTabResult,
  31  |   parseDynamicReconcileTabResult,
  32  |   parseDynamicStartTabResult,
  33  |   parseDynamicStateTabResult,
  34  |   parseDynamicStopTabResult,
  35  |   type DynamicInstrumentationSnapshot,
  36  |   type DynamicReconcileOutcome,
  37  | } from "../../../apps/extension/src/dynamic-protocol.ts";
  38  | import {
  39  |   buildScanTabRequest,
  40  |   CONTENT_FRAME_SCAN_FOUND,
  41  |   parseAggregatedScanResult,
  42  |   type FrameScanReport,
  43  | } from "../../../apps/extension/src/scanner-protocol.ts";
  44  | import {
  45  |   CONTENT_READY_ATTRIBUTE,
  46  |   CONTENT_READY_VALUE,
  47  | } from "../../../apps/extension/src/feasibility-protocol.ts";
  48  | import { stableSemanticId } from "../../../apps/extension/src/semantic-identity.ts";
  49  | import { expect, LAB_ORIGIN } from "./extension-test.ts";
  50  | 
  51  | export const READY_TIMEOUT_MS = 15_000;
  52  | export const DRAIN_TIMEOUT_MS = 15_000;
  53  | export const DRAIN_POLL_MS = 50;
  54  | let sequence = 0;
  55  | 
  56  | export function nextId(prefix: string): string {
  57  |   sequence += 1;
  58  |   return `${prefix}-${String(sequence)}`;
  59  | }
  60  | 
  61  | export interface ChromeTab {
  62  |   readonly id?: number;
  63  | }
  64  | 
  65  | export interface Harness {
  66  |   readonly page: Page;
  67  |   readonly controller: Page;
  68  |   readonly tabId: number;
  69  | }
  70  | 
  71  | export function requireValue<T>(
  72  |   value: T | null | undefined,
  73  |   message: string,
  74  | ): T {
  75  |   if (value === null || value === undefined) {
> 76  |     throw new Error(message);
      |           ^ Error: top frame with application root missing
  77  |   }
  78  |   return value;
  79  | }
  80  | 
  81  | export async function tabIdForPage(
  82  |   serviceWorker: Worker,
  83  |   page: Page,
  84  | ): Promise<number> {
  85  |   await page.bringToFront();
  86  |   return serviceWorker.evaluate(async () => {
  87  |     const runtime = globalThis as unknown as {
  88  |       chrome: { tabs: { query(query: object): Promise<ChromeTab[]> } };
  89  |     };
  90  |     const tabs = await runtime.chrome.tabs.query({
  91  |       active: true,
  92  |       lastFocusedWindow: true,
  93  |     });
  94  |     const match = tabs[0];
  95  |     if (tabs.length !== 1 || match?.id === undefined) {
  96  |       throw new Error("no unique active browser tab");
  97  |     }
  98  |     return match.id;
  99  |   });
  100 | }
  101 | 
  102 | export async function runtimeMessage(
  103 |   controller: Page,
  104 |   message: unknown,
  105 | ): Promise<unknown> {
  106 |   return controller.evaluate(async (wireMessage) => {
  107 |     const runtime = globalThis as unknown as {
  108 |       chrome: { runtime: { sendMessage(value: unknown): Promise<unknown> } };
  109 |     };
  110 |     return runtime.chrome.runtime.sendMessage(wireMessage);
  111 |   }, message);
  112 | }
  113 | 
  114 | export async function openHarness(
  115 |   extensionContext: BrowserContext,
  116 |   extensionId: string,
  117 |   serviceWorker: Worker,
  118 |   route: string,
  119 | ): Promise<Harness> {
  120 |   const page = await extensionContext.newPage();
  121 |   await page.goto(`${LAB_ORIGIN}${route}`);
  122 |   await expect(page.locator("html")).toHaveAttribute(
  123 |     CONTENT_READY_ATTRIBUTE,
  124 |     CONTENT_READY_VALUE,
  125 |     { timeout: READY_TIMEOUT_MS },
  126 |   );
  127 |   const tabId = await tabIdForPage(serviceWorker, page);
  128 |   const controller = await extensionContext.newPage();
  129 |   await controller.goto(`chrome-extension://${extensionId}/manifest.json`);
  130 |   return { page, controller, tabId };
  131 | }
  132 | 
  133 | export async function setFixture(
  134 |   harness: Harness,
  135 |   markup: string,
  136 | ): Promise<void> {
  137 |   await harness.page.locator("body").evaluate((body, value) => {
  138 |     body.innerHTML = value;
  139 |   }, markup);
  140 | }
  141 | 
  142 | export async function scanFrames(harness: Harness): Promise<FrameScanReport[]> {
  143 |   const response = await runtimeMessage(
  144 |     harness.controller,
  145 |     buildScanTabRequest(nextId("scan"), harness.tabId, {
  146 |       kind: "APPLICATION_ROOT",
  147 |     }),
  148 |   );
  149 |   const parsed = parseAggregatedScanResult(response);
  150 |   expect(parsed).not.toBeNull();
  151 |   return [...requireValue(parsed, "invalid aggregate").frames];
  152 | }
  153 | 
  154 | export function foundTopFrame(
  155 |   frames: readonly FrameScanReport[],
  156 | ): FrameScanReport {
  157 |   return requireValue(
  158 |     frames.find(
  159 |       (frame) =>
  160 |         frame.frame_context.is_top_frame &&
  161 |         frame.root_status === CONTENT_FRAME_SCAN_FOUND,
  162 |     ),
  163 |     "top frame with application root missing",
  164 |   );
  165 | }
  166 | 
  167 | export function descriptorByLabel(
  168 |   values: readonly FormFieldDescriptorV1[],
  169 |   label: string,
  170 | ): FormFieldDescriptorV1 {
  171 |   return requireValue(
  172 |     values.find((value) => value.label.normalized_text === label),
  173 |     `descriptor labelled ${label} is missing`,
  174 |   );
  175 | }
  176 | 
```