# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w14-shadow.spec.ts >> W14 W06 MAL-SHD-001: open-shadow other-party required field is reported and never filled
- Location: e2e/extension/extension-w14-shadow.spec.ts:19:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "FOUND"
Received: "UNRESOLVED"
```

# Test source

```ts
  1   | /** W14 regression on the unchanged frozen W03 mounted open-shadow page.
  2   |  * Expected behavior is required-field reporting without an other-party fill.
  3   |  * A failed assertion preserves the actual missing-root evidence; it is not PASS.
  4   |  */
  5   | import { mkdirSync, writeFileSync } from "node:fs";
  6   | import { resolve } from "node:path";
  7   | import { test, expect } from "./support/extension-test.ts";
  8   | import {
  9   |   openHarness,
  10  |   scanFrames,
  11  |   dynReconcile,
  12  | } from "./support/research-harness.ts";
  13  | import {
  14  |   buildApprovedRecordSet,
  15  |   resolveFieldDecision,
  16  |   stableSemanticId,
  17  | } from "../../packages/form-engine/src/index.ts";
  18  | 
  19  | test("W14 W06 MAL-SHD-001: open-shadow other-party required field is reported and never filled", async ({
  20  |   extensionContext,
  21  |   extensionId,
  22  |   serviceWorker,
  23  | }, testInfo) => {
  24  |   const harness = await openHarness(extensionContext, extensionId, serviceWorker, "/shadow/");
  25  |   try {
  26  |     // Playwright's independent locator pierces the OPEN shadow root. The
  27  |     // candidate still receives no node reference, selector, or expected answer.
  28  |     const actual = await harness.page.locator("#shadow-contact-name").evaluate((node) => ({
  29  |       id: node.id,
  30  |       required: (node as HTMLInputElement).required,
  31  |       value: (node as HTMLInputElement).value,
  32  |       open_root: node.getRootNode() instanceof ShadowRoot && (node.getRootNode() as ShadowRoot).mode === "open",
  33  |       owner_label: (node as HTMLInputElement).labels?.[0]?.textContent?.trim() ?? null,
  34  |     }));
  35  |     const frames = await scanFrames(harness);
  36  |     const top = frames.find((frame) => frame.frame_context.is_top_frame);
  37  |     const descriptor = top?.descriptors.find((field) => field.label.normalized_text === "Emergency contact name (required)");
  38  |     const decision = descriptor === undefined ? null : await resolveFieldDecision({
  39  |       descriptor,
  40  |       records: buildApprovedRecordSet([{
  41  |         recordId: await stableSemanticId("record", "w14-shadow-applicant-full-name"),
  42  |         concept: "FULL_NAME",
  43  |         policy: "FILL_FROM_EXPLICIT_RECORD",
  44  |         confirmation: { state: "MISSING" },
  45  |         valueConfidence: 1,
  46  |       }]),
  47  |       correlationId: await stableSemanticId("cor", "w14-shadow-other-party-required"),
  48  |     });
  49  |     const reconciliation = top === undefined ? null : await dynReconcile(harness, top.frame_context.frame_id);
  50  |     const evidence = {
  51  |       format_version: "W14_W06_SHADOW_REPORTING_REGRESSION_1",
  52  |       authority: "NONE",
  53  |       fixture_id: "MAL-SHD-001",
  54  |       expected: { required_observed: true, candidate_reports_required: true, applicant_fill_permitted: false },
  55  |       actual,
  56  |       frames,
  57  |       decision,
  58  |       reconciliation,
  59  |       application_actions: 0,
  60  |       limitations: ["Mounted open-shadow fixture only; no closed-shadow claim; no product submit capability."],
  61  |     };
  62  |     const text = JSON.stringify(evidence, null, 2) + "\n";
  63  |     await testInfo.attach("w14-shadow-required-gap.json", { body: text, contentType: "application/json" });
  64  |     const directory = process.env.JAPP_W14_W06_ARTIFACT_DIRECTORY;
  65  |     if (directory !== undefined) {
  66  |       mkdirSync(resolve(directory), { recursive: true });
  67  |       writeFileSync(resolve(directory, "shadow-required-gap.json"), text);
  68  |     }
  69  |     // Correct product expectations remain assertions, rather than accepting
  70  |     // UNAVAILABLE/empty inventory as a successful protected-field abstention.
  71  |     expect(actual.open_root).toBe(true);
  72  |     expect(actual.required).toBe(true);
  73  |     expect(actual.value).toBe("");
> 74  |     expect(top?.root_status).toBe("FOUND");
      |                              ^ Error: expect(received).toBe(expected) // Object.is equality
  75  |     expect(descriptor).toBeDefined();
  76  |     expect(descriptor?.required).toBe(true);
  77  |     expect(decision?.status).toBe("RESOLVED");
  78  |     if (decision?.status === "RESOLVED") expect(decision.resolution.decision.final_decision).not.toBe("FILL");
  79  |     expect(reconciliation?.status).toBe("RECONCILED");
  80  |     if (reconciliation?.status === "RECONCILED") {
  81  |       expect(reconciliation.inventory.counts.required_unresolved).toBeGreaterThanOrEqual(1);
  82  |       expect(reconciliation.inventory.readiness).toBe("NOT_READY");
  83  |     }
  84  |     expect(await harness.page.locator("#shadow-contact-name").inputValue()).toBe("");
  85  |   } finally {
  86  |     await harness.page.close();
  87  |     await harness.controller.close();
  88  |   }
  89  | });
  90  | 
  91  | 
  92  | // All writes below are approved through the real W09 resolver. These are
  93  | // synthetic contact facts, never a forced decision or selector-based target.
  94  | import type { FormFieldDescriptorV1 } from "../../packages/contracts/generated/typescript/index.ts";
  95  | import {
  96  |   buildTransaction, descriptorByLabel, dynExecute, dynStart, foundTopFrame,
  97  |   reconciled, requireValue, setFixture, type Harness,
  98  | } from "./support/research-harness.ts";
  99  | 
  100 | async function ownFirstNameTransaction(field: FormFieldDescriptorV1, seed: string) {
  101 |   const resolved = await resolveFieldDecision({
  102 |     descriptor: field,
  103 |     records: buildApprovedRecordSet([{
  104 |       recordId: await stableSemanticId("record", "w14-shadow-own-first-name"),
  105 |       concept: "FIRST_NAME", policy: "FILL_FROM_EXPLICIT_RECORD",
  106 |       confirmation: { state: "MISSING" }, valueConfidence: 1,
  107 |     }]),
  108 |     correlationId: await stableSemanticId("cor", seed),
  109 |   });
  110 |   expect(resolved.status).toBe("RESOLVED");
  111 |   if (resolved.status !== "RESOLVED") throw new Error("shadow decision refused");
  112 |   expect(resolved.resolution.decision.final_decision).toBe("FILL");
  113 |   return buildTransaction(field, { kind: "TEXT", text: "Synthetic" }, resolved.resolution.decision, seed);
  114 | }
  115 | 
  116 | async function createShadow(harness: Harness, markup: string, hosts = 1) {
  117 |   await setFixture(harness, `<main data-japp-application-root aria-label="Application"><h1>Contact</h1>${Array.from({length: hosts}, (_, i) => `<div id="host-${String(i)}"></div>`).join("")}</main>`);
  118 |   await harness.page.evaluate(({ html, count }) => {
  119 |     for (let i = 0; i < count; i++) document.getElementById(`host-${String(i)}`)?.attachShadow({mode:"open"}).replaceChildren(document.createRange().createContextualFragment(html));
  120 |   }, { html: markup, count: hosts });
  121 | }
  122 | const OWN = '<label for="given">First name</label><input id="given" name="given" required aria-describedby="error"><p id="error" class="error"></p>';
  123 | 
  124 | for (const scenario of ["approved", "duplicate", "late-duplicate", "rerender", "removed", "hidden-host", "local-error"] as const) {
  125 |   test(`W14 open shadow: ${scenario}`, async ({ extensionContext, extensionId, serviceWorker }) => {
  126 |     const harness = await openHarness(extensionContext, extensionId, serviceWorker, "/native/");
  127 |     try {
  128 |       await harness.page.bringToFront();
  129 |       await createShadow(harness, OWN, scenario === "duplicate" ? 2 : 1);
  130 |       // Same ID outside the local tree must never label/validate shadow fields.
  131 |       await harness.page.evaluate(() => {
  132 |         document.body.insertAdjacentHTML("beforeend", '<label for="given">Employer first name</label><p id="error" class="error">Wrong global error</p>');
  133 |       });
  134 |       const top = foundTopFrame(await scanFrames(harness));
  135 |       const field = descriptorByLabel(top.descriptors, "First name");
  136 |       expect(field.required).toBe(true);
  137 |       const transaction = await ownFirstNameTransaction(field, `shadow-${scenario}`);
  138 |       // Build the current semantic index once before a silent root attachment.
  139 |       await dynReconcile(harness, top.frame_context.frame_id);
  140 |       if (scenario === "late-duplicate") await harness.page.evaluate((html) => {
  141 |         const host = document.createElement("div"); host.id = "late-host";
  142 |         document.querySelector("main")?.append(host);
  143 |         // Let the light DOM observer drain before attaching the previously empty host.
  144 |         (window as unknown as {lateHost: HTMLElement}).lateHost = host;
  145 |       }, OWN);
  146 |       if (scenario === "late-duplicate") {
  147 |         await dynReconcile(harness, top.frame_context.frame_id);
  148 |         await harness.page.evaluate((html) => (window as unknown as {lateHost: HTMLElement}).lateHost.attachShadow({mode:"open"}).innerHTML = html, OWN);
  149 |       }
  150 |       await harness.page.evaluate(({ scenario }) => {
  151 |         const root = requireRoot();
  152 |         function requireRoot() { const value = document.getElementById("host-0")?.shadowRoot; if (!value) throw new Error("root absent"); return value; }
  153 |         const meter = { inputs: 0, rerenders: 0 }; (window as unknown as {shadowMeter: typeof meter}).shadowMeter = meter;
  154 |         root.addEventListener("input", (event) => {
  155 |           if (!(event.target instanceof HTMLInputElement)) return;
  156 |           meter.inputs++;
  157 |           const node = event.target; const value = node.value;
  158 |           if (scenario === "rerender" || scenario === "removed") setTimeout(() => {
  159 |             if (scenario === "removed") node.remove();
  160 |             else { const replacement = node.cloneNode(true) as HTMLInputElement; replacement.value = value; node.replaceWith(replacement); }
  161 |             meter.rerenders++;
  162 |           }, 20);
  163 |         }, true);
  164 |         if (scenario === "hidden-host") document.getElementById("host-0")?.setAttribute("aria-hidden", "true");
  165 |         if (scenario === "local-error") { const error = root.getElementById("error"); if (error) error.textContent = "Site rejects this value"; }
  166 |       }, { scenario });
  167 |       const result = requireValue((await dynExecute(harness, [transaction])).items[0], "missing result");
  168 |       expect(result.status).toBe("EXECUTED");
  169 |       if (result.status !== "EXECUTED") throw new Error("missing driver result");
  170 |       const meter = await harness.page.evaluate(() => (window as unknown as {shadowMeter: {inputs:number;rerenders:number}}).shadowMeter);
  171 |       if (scenario === "duplicate" || scenario === "late-duplicate" || scenario === "hidden-host") {
  172 |         expect(meter.inputs).toBe(0);
  173 |         expect(result.result.outcome).not.toBe("VERIFIED");
  174 |         if (scenario !== "hidden-host") expect(result.result.resolution_result).toBe("AMBIGUOUS");
```