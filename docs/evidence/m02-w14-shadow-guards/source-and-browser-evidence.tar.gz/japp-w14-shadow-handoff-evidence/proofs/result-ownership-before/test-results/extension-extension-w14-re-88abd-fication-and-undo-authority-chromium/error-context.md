# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w14-result-ownership-peer.spec.ts >> W14 peer: description drift during final result metadata hash refuses direct verification and undo authority
- Location: e2e/extension/extension-w14-result-ownership-peer.spec.ts:103:1

# Error details

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "VERIFIED"
```

# Test source

```ts
  98  |       return native;
  99  |     },
  100 |   });
  101 | }
  102 | 
  103 | test("W14 peer: description drift during final result metadata hash refuses direct verification and undo authority", async ({
  104 |   extensionContext,
  105 |   extensionId,
  106 |   serviceWorker,
  107 | }, testInfo) => {
  108 |   const harness = await openHarness(
  109 |     extensionContext,
  110 |     extensionId,
  111 |     serviceWorker,
  112 |     "/native/",
  113 |   );
  114 |   let session: CDPSession | undefined;
  115 |   let contextId: number | undefined;
  116 |   let pending: ReturnType<typeof dynExecute> | undefined;
  117 |   try {
  118 |     await setFixture(
  119 |       harness,
  120 |       '<form data-japp-application-root="true"><span id="ownership">Your contact</span><label for="first">First name</label><input id="first" name="first" aria-describedby="ownership" required></form>',
  121 |     );
  122 |     await harness.page.evaluate(() => {
  123 |       const input = document.getElementById("first");
  124 |       if (input === null) throw new Error("input missing");
  125 |       const meter = { input: 0, change: 0 };
  126 |       (window as unknown as { peerResultMeter: typeof meter }).peerResultMeter =
  127 |         meter;
  128 |       input.addEventListener("input", () => {
  129 |         meter.input++;
  130 |       });
  131 |       input.addEventListener("change", () => {
  132 |         meter.change++;
  133 |       });
  134 |     });
  135 |     const top = foundTopFrame(await scanFrames(harness));
  136 |     const descriptor = descriptorByLabel(top.descriptors, "First name");
  137 |     const transaction = await approvedTransaction(
  138 |       descriptor,
  139 |       "peer-result-hash-ownership",
  140 |       { kind: "TEXT", text: "Synthetic" },
  141 |     );
  142 |     expect(transaction.decision.final_decision).toBe("FILL");
  143 |     session = await extensionContext.newCDPSession(harness.page);
  144 |     contextId = await contentExecutionContext(session, extensionId);
  145 |     await session.send("Runtime.evaluate", {
  146 |       contextId,
  147 |       expression: `(${installResultHashPause.toString()})(${JSON.stringify(`w10-idempotency-v1\0${transaction.transaction_id}\0EXECUTE`)})`,
  148 |     });
  149 |     pending = dynExecute(harness, [transaction]);
  150 |     const activeSession = session,
  151 |       activeContext = contextId;
  152 |     await expect
  153 |       .poll(
  154 |         async () => {
  155 |           const response = await activeSession.send("Runtime.evaluate", {
  156 |             contextId: activeContext,
  157 |             expression:
  158 |               "globalThis.__JAPP_W14_TEST_RESULT_HASH_PAUSE__?.reached === true",
  159 |             returnByValue: true,
  160 |           });
  161 |           return response.result.value as unknown;
  162 |         },
  163 |         { timeout: 5000 },
  164 |       )
  165 |       .toBe(true);
  166 |     expect(await harness.page.locator("#first").inputValue()).toBe("Synthetic");
  167 |     await harness.page.locator("#ownership").evaluate((node) => {
  168 |       node.textContent = "Employer";
  169 |     });
  170 |     await session.send("Runtime.evaluate", {
  171 |       contextId,
  172 |       expression: "globalThis.__JAPP_W14_TEST_RESULT_HASH_PAUSE__.release()",
  173 |     });
  174 |     const execution = await pending;
  175 |     pending = undefined;
  176 |     const inventory = reconciled(
  177 |       await dynReconcile(harness, top.frame_context.frame_id),
  178 |     );
  179 |     const meter = await harness.page.evaluate(
  180 |       () =>
  181 |         (
  182 |           window as unknown as {
  183 |             peerResultMeter: { input: number; change: number };
  184 |           }
  185 |         ).peerResultMeter,
  186 |     );
  187 |     await testInfo.attach("w14-result-hash-ownership.json", {
  188 |       body: JSON.stringify(
  189 |         { descriptor, transaction, execution, inventory, meter },
  190 |         null,
  191 |         2,
  192 |       ),
  193 |       contentType: "application/json",
  194 |     });
  195 |     expect(meter).toEqual({ input: 1, change: 1 });
  196 |     expect(execution.items[0]?.status).toBe("EXECUTED");
  197 |     if (execution.items[0]?.status === "EXECUTED") {
> 198 |       expect(execution.items[0].result.outcome).not.toBe("VERIFIED");
      |                                                     ^ Error: expect(received).not.toBe(expected) // Object.is equality
  199 |       expect(execution.items[0].undo_available).toBe(false);
  200 |     }
  201 |     expect(inventory.inventory.readiness).toBe("NOT_READY");
  202 |   } finally {
  203 |     if (session !== undefined && contextId !== undefined)
  204 |       await session.send("Runtime.evaluate", {
  205 |         contextId,
  206 |         expression: "globalThis.__JAPP_W14_TEST_RESULT_HASH_PAUSE__?.restore()",
  207 |       });
  208 |     await pending?.catch(() => undefined);
  209 |     await session?.detach();
  210 |     await harness.page.close();
  211 |     await harness.controller.close();
  212 |   }
  213 | });
  214 | 
```