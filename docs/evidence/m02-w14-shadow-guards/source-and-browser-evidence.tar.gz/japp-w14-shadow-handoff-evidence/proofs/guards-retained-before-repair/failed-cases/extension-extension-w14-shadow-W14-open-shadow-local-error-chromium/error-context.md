# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w14-shadow.spec.ts >> W14 open shadow: local-error
- Location: e2e/extension/extension-w14-shadow.spec.ts:219:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 1
Received: 0
```

# Test source

```ts
  297 |                     document
  298 |                       .createRange()
  299 |                       .createContextualFragment(
  300 |                         '<label for="given">First name</label><input id="given" name="given" required>',
  301 |                       ),
  302 |                   );
  303 |             },
  304 |             { capture: true, once: true },
  305 |           );
  306 |           root.addEventListener(
  307 |             "input",
  308 |             (event) => {
  309 |               if (!(event.target instanceof HTMLInputElement)) return;
  310 |               meter.inputs++;
  311 |               if (scenario === "during-action-duplicate")
  312 |                 document
  313 |                   .getElementById("boundary-host")
  314 |                   ?.attachShadow({ mode: "open" })
  315 |                   .replaceChildren(
  316 |                     document
  317 |                       .createRange()
  318 |                       .createContextualFragment(
  319 |                         '<label for="given">First name</label><input id="given" name="given" required>',
  320 |                       ),
  321 |                   );
  322 |               const node = event.target;
  323 |               const value = node.value;
  324 |               if (
  325 |                 scenario === "rerender" ||
  326 |                 scenario === "removed" ||
  327 |                 scenario === "removed-host"
  328 |               )
  329 |                 setTimeout(() => {
  330 |                   if (scenario === "removed") node.remove();
  331 |                   else if (scenario === "removed-host")
  332 |                     document.getElementById("host-0")?.remove();
  333 |                   else {
  334 |                     const replacement = node.cloneNode(
  335 |                       true,
  336 |                     ) as HTMLInputElement;
  337 |                     replacement.value = value;
  338 |                     node.replaceWith(replacement);
  339 |                   }
  340 |                   meter.rerenders++;
  341 |                 }, 20);
  342 |             },
  343 |             true,
  344 |           );
  345 |           if (scenario === "hidden-host")
  346 |             document
  347 |               .getElementById("host-0")
  348 |               ?.setAttribute("aria-hidden", "true");
  349 |           if (scenario === "transparent-host") {
  350 |             const host = document.getElementById("host-0");
  351 |             if (host) host.style.opacity = "0";
  352 |           }
  353 |           if (scenario === "disabled-host") {
  354 |             const host = document.getElementById("host-0");
  355 |             if (host) {
  356 |               const fieldset = document.createElement("fieldset");
  357 |               fieldset.disabled = true;
  358 |               host.replaceWith(fieldset);
  359 |               fieldset.append(host);
  360 |             }
  361 |           }
  362 |           if (scenario === "local-error") {
  363 |             const error = root.getElementById("error");
  364 |             if (error) error.textContent = "Site rejects this value";
  365 |           }
  366 |         },
  367 |         { scenario },
  368 |       );
  369 |       const result = requireValue(
  370 |         (await dynExecute(harness, [transaction])).items[0],
  371 |         "missing result",
  372 |       );
  373 |       expect(result.status).toBe("EXECUTED");
  374 |       if (result.status !== "EXECUTED")
  375 |         throw new Error("missing driver result");
  376 |       const meter = await harness.page.evaluate(
  377 |         () =>
  378 |           (
  379 |             window as unknown as {
  380 |               shadowMeter: { inputs: number; rerenders: number };
  381 |             }
  382 |           ).shadowMeter,
  383 |       );
  384 |       if (
  385 |         scenario === "duplicate" ||
  386 |         scenario === "late-duplicate" ||
  387 |         scenario === "hidden-host" ||
  388 |         scenario === "transparent-host" ||
  389 |         scenario === "disabled-host" ||
  390 |         scenario === "focus-duplicate"
  391 |       ) {
  392 |         expect(meter.inputs).toBe(0);
  393 |         expect(result.result.outcome).not.toBe("VERIFIED");
  394 |         if (scenario === "duplicate" || scenario === "late-duplicate")
  395 |           expect(result.result.resolution_result).toBe("AMBIGUOUS");
  396 |       } else {
> 397 |         expect(meter.inputs).toBe(1);
      |                              ^ Error: expect(received).toBe(expected) // Object.is equality
  398 |         expect(result.result.action_attempt.duration_ms).toBeGreaterThanOrEqual(
  399 |           75,
  400 |         );
  401 |         if (
  402 |           scenario === "removed" ||
  403 |           scenario === "removed-host" ||
  404 |           scenario === "local-error" ||
  405 |           scenario === "during-action-duplicate"
  406 |         )
  407 |           expect(result.result.outcome).not.toBe("VERIFIED");
  408 |         else {
  409 |           expect(result.result.outcome).toBe("VERIFIED");
  410 |           expect(result.result.persistence_verified).toBe(true);
  411 |           expect(result.result.site_acceptance).toBe("ACCEPTED");
  412 |           expect(await harness.page.locator("#given").inputValue()).toBe(
  413 |             "Synthetic",
  414 |           );
  415 |         }
  416 |       }
  417 |       if (
  418 |         scenario === "duplicate" ||
  419 |         scenario === "late-duplicate" ||
  420 |         scenario === "focus-duplicate" ||
  421 |         scenario === "during-action-duplicate"
  422 |       ) {
  423 |         expect(
  424 |           (await dynReconcile(harness, top.frame_context.frame_id)).status,
  425 |         ).toBe("ROOT_AMBIGUOUS");
  426 |       }
  427 |       if (
  428 |         scenario === "rerender" ||
  429 |         scenario === "removed" ||
  430 |         scenario === "removed-host"
  431 |       )
  432 |         expect(meter.rerenders).toBe(1);
  433 |     } finally {
  434 |       await harness.page.close();
  435 |       await harness.controller.close();
  436 |     }
  437 |   });
  438 | }
  439 | 
  440 | test("W14 open shadow: late attached unknown required control joins active reconciliation", async ({
  441 |   extensionContext,
  442 |   extensionId,
  443 |   serviceWorker,
  444 | }) => {
  445 |   const harness = await openHarness(
  446 |     extensionContext,
  447 |     extensionId,
  448 |     serviceWorker,
  449 |     "/native/",
  450 |   );
  451 |   try {
  452 |     await createShadow(harness, OWN);
  453 |     await harness.page.evaluate(() => {
  454 |       const host = document.createElement("div");
  455 |       host.id = "late-host";
  456 |       document.querySelector("main")?.append(host);
  457 |     });
  458 |     const top = foundTopFrame(await scanFrames(harness));
  459 |     expect((await dynStart(harness, top.frame_context.frame_id)).status).toBe(
  460 |       "STARTED",
  461 |     );
  462 |     await dynReconcile(harness, top.frame_context.frame_id);
  463 |     await harness.page.evaluate(() => {
  464 |       const host = document.getElementById("late-host");
  465 |       if (!host) throw new Error("host absent");
  466 |       host.attachShadow({ mode: "open" }).innerHTML =
  467 |         '<label for="unknown">Emergency contact name (required)</label><input id="unknown" required>';
  468 |     });
  469 |     const inventory = reconciled(
  470 |       await dynReconcile(harness, top.frame_context.frame_id),
  471 |     ).inventory;
  472 |     expect(inventory.items.filter((item) => item.required)).toHaveLength(2);
  473 |     expect(inventory.counts.required_unresolved).toBe(2);
  474 |     expect(inventory.readiness).toBe("NOT_READY");
  475 |     expect(await harness.page.locator("#unknown").inputValue()).toBe("");
  476 |   } finally {
  477 |     await harness.page.close();
  478 |     await harness.controller.close();
  479 |   }
  480 | });
  481 | 
  482 | test("W14 open shadow: root capacity refuses complete-inventory claims", async ({
  483 |   extensionContext,
  484 |   extensionId,
  485 |   serviceWorker,
  486 | }) => {
  487 |   const harness = await openHarness(
  488 |     extensionContext,
  489 |     extensionId,
  490 |     serviceWorker,
  491 |     "/native/",
  492 |   );
  493 |   try {
  494 |     await createShadow(harness, OWN, 65);
  495 |     const top = (await scanFrames(harness)).find(
  496 |       (frame) => frame.frame_context.is_top_frame,
  497 |     );
```