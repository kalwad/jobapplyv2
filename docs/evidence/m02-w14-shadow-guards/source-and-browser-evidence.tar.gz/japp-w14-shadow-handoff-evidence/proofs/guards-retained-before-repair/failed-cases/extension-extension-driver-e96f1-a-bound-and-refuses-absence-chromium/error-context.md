# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-drivers.spec.ts >> VIRT1/VIRT2: the 480-row windowed list finds one off-window exact target within a bound and refuses absence
- Location: e2e/extension/extension-drivers.spec.ts:899:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "VERIFIED"
Received: "NEEDS_REVIEW"
```

# Test source

```ts
  829  |   let scanned = await descriptors(harness);
  830  |   let combo = descriptorByLabel(scanned, "Office location");
  831  |   const priorDisplay = "Fable Crossing (synthetic)";
  832  |   const intendedDisplay = "Harbor Point (synthetic)";
  833  |   expect(
  834  |     (
  835  |       await execute(harness, combo, {
  836  |         kind: "OPTION",
  837  |         value_digest: await semanticDigest(`option-value-v1\0${priorDisplay}`),
  838  |       })
  839  |     ).result.outcome,
  840  |   ).toBe("VERIFIED");
  841  |   // Force the reviewed fixture back to its committed-value filtered window;
  842  |   // this makes the driver's reversible precondition probe the point where a
  843  |   // same-document semantic replacement can race the action.
  844  |   await harness.page.locator("#cbx-input").dispatchEvent("input");
  845  |   await harness.page.locator("#cbx-input").press("Escape");
  846  | 
  847  |   await harness.page.locator("#cbx-input").evaluate((input) => {
  848  |     let changed = false;
  849  |     input.addEventListener("input", () => {
  850  |       if (changed || (input as HTMLInputElement).value !== "") return;
  851  |       changed = true;
  852  |       const label = document.querySelector("label[for='cbx-input']");
  853  |       if (label === null) throw new Error("combobox label missing");
  854  |       label.textContent = "Replacement office location";
  855  |     });
  856  |   });
  857  |   const staleAction = await execute(harness, combo, {
  858  |     kind: "OPTION",
  859  |     value_digest: await semanticDigest(`option-value-v1\0${intendedDisplay}`),
  860  |   });
  861  |   expect(staleAction.result.resolution_result).not.toBe("UNIQUE");
  862  |   expect(await harness.page.locator("#cbx-input").inputValue()).toBe(
  863  |     priorDisplay,
  864  |   );
  865  | 
  866  |   await harness.page.locator("label[for='cbx-input']").evaluate((label) => {
  867  |     label.textContent = "Office location";
  868  |   });
  869  |   scanned = await descriptors(harness);
  870  |   combo = descriptorByLabel(scanned, "Office location");
  871  |   await harness.page.locator("#cbx-input").evaluate((input) => {
  872  |     let clearCount = 0;
  873  |     input.addEventListener("input", () => {
  874  |       if ((input as HTMLInputElement).value !== "") return;
  875  |       clearCount += 1;
  876  |       if (clearCount !== 3) return;
  877  |       document
  878  |         .querySelector<HTMLElement>(
  879  |           "[role='option'][data-value='Harbor Point (synthetic)']",
  880  |         )
  881  |         ?.remove();
  882  |     });
  883  |   });
  884  |   const recovered = await execute(harness, combo, {
  885  |     kind: "OPTION",
  886  |     value_digest: await semanticDigest(`option-value-v1\0${intendedDisplay}`),
  887  |   });
  888  |   expect(recovered.result.outcome).toBe("FAILED");
  889  |   expect(recovered.result.recovery).toMatchObject({
  890  |     attempted: true,
  891  |     restored: true,
  892  |   });
  893  |   expect(recovered.undo_available).toBe(false);
  894  |   expect(await harness.page.locator("#cbx-input").inputValue()).toBe(
  895  |     priorDisplay,
  896  |   );
  897  | });
  898  | 
  899  | test("VIRT1/VIRT2: the 480-row windowed list finds one off-window exact target within a bound and refuses absence", async ({
  900  |   extensionContext,
  901  |   extensionId,
  902  |   serviceWorker,
  903  | }) => {
  904  |   // The W10 windowed-listbox driver legitimately walks up to 480 bounded
  905  |   // scroll windows with real settle polls, measured at ~25 s green on the
  906  |   // reference machine — inside the Playwright 30 s default only by margin.
  907  |   // Explicit bounded budget for exactly this scenario (M02-W09 KI-precedent
  908  |   // pattern: per-test budget, no global change, no assertion change).
  909  |   test.setTimeout(60_000);
  910  |   const harness = await openHarness(
  911  |     extensionContext,
  912  |     extensionId,
  913  |     serviceWorker,
  914  |     "/virtualized/",
  915  |   );
  916  |   const scanned = await descriptors(harness);
  917  |   const listbox = descriptorByLabel(scanned, "Assessment cohort");
  918  |   expect(await harness.page.locator("[role=option]").count()).toBeLessThan(30);
  919  |   const selected = await execute(
  920  |     harness,
  921  |     listbox,
  922  |     {
  923  |       kind: "OPTION",
  924  |       value_digest: await semanticDigest("option-value-v1\0COHORT-0417"),
  925  |     },
  926  |     undefined,
  927  |     100,
  928  |   );
> 929  |   expect(selected.result.outcome).toBe("VERIFIED");
       |                                   ^ Error: expect(received).toBe(expected) // Object.is equality
  930  |   await expect(harness.page.locator("#vl-committed")).toHaveText("COHORT-0417");
  931  |   expect(await harness.page.locator("[role=option]").count()).toBeLessThan(30);
  932  | 
  933  |   const absent = await execute(
  934  |     harness,
  935  |     listbox,
  936  |     {
  937  |       kind: "OPTION",
  938  |       value_digest: await semanticDigest("option-value-v1\0COHORT-9999"),
  939  |     },
  940  |     undefined,
  941  |     25,
  942  |   );
  943  |   expect(absent.result.outcome).not.toBe("VERIFIED");
  944  |   await expect(harness.page.locator("#vl-committed")).toHaveText("COHORT-0417");
  945  | });
  946  | 
  947  | test("REP1/REP2/REP3: bounded repeater add/edit/remove uses stable labels and undo never uses an index", async ({
  948  |   extensionContext,
  949  |   extensionId,
  950  |   serviceWorker,
  951  | }) => {
  952  |   const harness = await openHarness(
  953  |     extensionContext,
  954  |     extensionId,
  955  |     serviceWorker,
  956  |     "/native/",
  957  |   );
  958  |   await replaceBody(
  959  |     harness,
  960  |     `<main><form><div data-japp-repeater="EXPERIENCE" data-japp-repeater-valid="true">
  961  |       <label for="rep-controller">Experience repeater</label>
  962  |       <input id="rep-controller" name="experienceRepeater" data-japp-repeater-controller="EXPERIENCE">
  963  |       <button type="button" data-japp-repeater-action="ADD">Add experience</button>
  964  |       <div data-japp-repeater-items></div>
  965  |     </div></form></main>`,
  966  |   );
  967  |   await harness.page.locator("[data-japp-repeater]").evaluate((root) => {
  968  |     root.addEventListener("click", (event) => {
  969  |       const target = event.target;
  970  |       if (!(target instanceof HTMLElement)) return;
  971  |       const action = target.getAttribute("data-japp-repeater-action");
  972  |       const items = root.querySelector<HTMLElement>(
  973  |         "[data-japp-repeater-items]",
  974  |       );
  975  |       if (items === null) throw new Error("repeater items missing");
  976  |       if (action === "ADD") {
  977  |         const controller = root.querySelector<HTMLInputElement>(
  978  |           "[data-japp-repeater-controller]",
  979  |         );
  980  |         if (controller === null) throw new Error("repeater controller missing");
  981  |         const label = controller.value;
  982  |         const item = document.createElement("div");
  983  |         item.setAttribute("data-japp-repeater-item", "");
  984  |         item.setAttribute("data-japp-item-label", label);
  985  |         const editor = document.createElement("input");
  986  |         editor.setAttribute("data-japp-repeater-value", "");
  987  |         editor.setAttribute("aria-label", `${label} details`);
  988  |         const remove = document.createElement("button");
  989  |         remove.type = "button";
  990  |         remove.textContent = `Remove ${label}`;
  991  |         remove.setAttribute("data-japp-repeater-action", "REMOVE");
  992  |         remove.setAttribute("data-japp-item-label", label);
  993  |         item.append(editor, remove);
  994  |         items.append(item);
  995  |         controller.value = "";
  996  |       } else if (action === "REMOVE") {
  997  |         target.closest("[data-japp-repeater-item]")?.remove();
  998  |       }
  999  |     });
  1000 |   });
  1001 |   let scanned = await descriptors(harness);
  1002 |   let controller = descriptorByLabel(scanned, "Experience repeater");
  1003 |   const added = await executeWithUndoId(harness, controller, {
  1004 |     kind: "REPEATER_ADD",
  1005 |     item_label: "Synthetic Role",
  1006 |   });
  1007 |   expect(added.result.outcome).toBe("VERIFIED");
  1008 |   expect(await harness.page.locator("[data-japp-repeater-item]").count()).toBe(
  1009 |     1,
  1010 |   );
  1011 |   expect((await undo(harness, added)).status).toBe("COMPLETED");
  1012 |   expect(await harness.page.locator("[data-japp-repeater-item]").count()).toBe(
  1013 |     0,
  1014 |   );
  1015 | 
  1016 |   scanned = await descriptors(harness);
  1017 |   controller = descriptorByLabel(scanned, "Experience repeater");
  1018 |   expect(
  1019 |     (
  1020 |       await execute(harness, controller, {
  1021 |         kind: "REPEATER_ADD",
  1022 |         item_label: "Synthetic Role",
  1023 |       })
  1024 |     ).result.outcome,
  1025 |   ).toBe("VERIFIED");
  1026 |   scanned = await descriptors(harness);
  1027 |   controller = descriptorByLabel(scanned, "Experience repeater");
  1028 |   expect(
  1029 |     (
```