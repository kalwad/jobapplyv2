# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w14-post-input-ownership-peer.spec.ts >> W14 peer: document input-handler ownership drift refuses verification and undo authority
- Location: e2e/extension/extension-w14-post-input-ownership-peer.spec.ts:16:3

# Error details

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "VERIFIED"
```

# Test source

```ts
  1   | /** A legitimate authorized first write must not validate later ownership. */
  2   | import { test, expect } from "./support/extension-test.ts";
  3   | import {
  4   |   openHarness,
  5   |   setFixture,
  6   |   scanFrames,
  7   |   foundTopFrame,
  8   |   descriptorByLabel,
  9   |   dynExecute,
  10  |   dynReconcile,
  11  |   reconciled,
  12  | } from "./support/research-harness.ts";
  13  | import { approvedTransaction } from "./support/research-core.ts";
  14  | 
  15  | for (const ownershipTree of ["document", "shadow"] as const) {
  16  |   test(`W14 peer: ${ownershipTree} input-handler ownership drift refuses verification and undo authority`, async ({
  17  |     extensionContext,
  18  |     extensionId,
  19  |     serviceWorker,
  20  |   }, testInfo) => {
  21  |     const harness = await openHarness(
  22  |       extensionContext,
  23  |       extensionId,
  24  |       serviceWorker,
  25  |       "/native/",
  26  |     );
  27  |     try {
  28  |       await setFixture(
  29  |         harness,
  30  |         '<form data-japp-application-root="true"><div id="owner-host"></div></form>',
  31  |       );
  32  |       await harness.page.evaluate((tree) => {
  33  |         const host = document.getElementById("owner-host");
  34  |         if (host === null) throw new Error("owner host absent");
  35  |         const root =
  36  |           tree === "shadow" ? host.attachShadow({ mode: "open" }) : host;
  37  |         root.innerHTML =
  38  |           '<span id="ownership">Your contact</span><label for="first">First name</label><input id="first" name="first" aria-describedby="ownership" required>';
  39  |         const input = root.querySelector("input"),
  40  |           description = root.querySelector("#ownership");
  41  |         if (input === null || description === null)
  42  |           throw new Error("fixture missing");
  43  |         const meter = { input: 0, change: 0 };
  44  |         (
  45  |           window as unknown as { peerPostInputMeter: typeof meter }
  46  |         ).peerPostInputMeter = meter;
  47  |         input.addEventListener("input", () => {
  48  |           meter.input++;
  49  |           description.textContent = "Employer";
  50  |         });
  51  |         input.addEventListener("change", () => {
  52  |           meter.change++;
  53  |         });
  54  |       }, ownershipTree);
  55  |       const top = foundTopFrame(await scanFrames(harness));
  56  |       const before = descriptorByLabel(top.descriptors, "First name");
  57  |       expect(before.description?.normalized_text).toBe("Your contact");
  58  |       const transaction = await approvedTransaction(
  59  |         before,
  60  |         `peer-post-input-${ownershipTree}`,
  61  |         { kind: "TEXT", text: "Synthetic" },
  62  |       );
  63  |       expect(transaction.decision.final_decision).toBe("FILL");
  64  |       const execution = await dynExecute(harness, [transaction]);
  65  |       const changed = descriptorByLabel(
  66  |         foundTopFrame(await scanFrames(harness)).descriptors,
  67  |         "First name",
  68  |       );
  69  |       const inventory = reconciled(
  70  |         await dynReconcile(harness, top.frame_context.frame_id),
  71  |       );
  72  |       const meter = await harness.page.evaluate(
  73  |         () =>
  74  |           (
  75  |             window as unknown as {
  76  |               peerPostInputMeter: { input: number; change: number };
  77  |             }
  78  |           ).peerPostInputMeter,
  79  |       );
  80  |       const value = await harness.page.locator("#first").inputValue();
  81  |       await testInfo.attach(`w14-post-input-ownership-${ownershipTree}.json`, {
  82  |         body: JSON.stringify(
  83  |           { before, transaction, execution, changed, inventory, meter, value },
  84  |           null,
  85  |           2,
  86  |         ),
  87  |         contentType: "application/json",
  88  |       });
  89  |       expect(meter).toEqual({ input: 1, change: 1 });
  90  |       expect(value).toBe("Synthetic");
  91  |       expect(changed.description?.normalized_text).toBe("Employer");
  92  |       expect(execution.items[0]?.status).toBe("EXECUTED");
  93  |       if (execution.items[0]?.status === "EXECUTED") {
> 94  |         expect(execution.items[0].result.outcome).not.toBe("VERIFIED");
      |                                                       ^ Error: expect(received).not.toBe(expected) // Object.is equality
  95  |         expect(execution.items[0].undo_available).toBe(false);
  96  |       }
  97  |       expect(inventory.inventory.readiness).toBe("NOT_READY");
  98  |       expect(inventory.inventory.counts.required_unresolved).toBe(1);
  99  |     } finally {
  100 |       await harness.page.close();
  101 |       await harness.controller.close();
  102 |     }
  103 |   });
  104 | }
  105 | 
```