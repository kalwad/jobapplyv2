# Selected narrow W03 CI retry tooling evidence

This is archival source/data retention for two immutable proposals and their
independent reviews. It is not the ongoing root retry candidate: that candidate
was not read, frozen, committed, pushed or executed by this collector.

The durable CAS retains all 1,959 indexed present author records plus index,
the complete 1,798-file proposed source set, all 185 bounded-review files, the
exact cbf26606... / 416,957-byte owned-temp archive and its 72 logical members,
and all 24 owned-temp review index members plus manifest. Selection preserves
original paths, hashes, sizes and modes; alias bodies are content-addressed once.

The REMOTE TAR IS SELECTED, NOT A COMPLETE SOURCE OR HISTORICAL INPUT IMAGE.
Every omitted present-file body is listed in remote-omissions.json with its
full durable CAS bytes and exact clean d28 Git recovery identity. All raw patches,
preimages, the two changed/new bounded-scan source files, owned-temp workflow
before/after, raw commands, old 1 FAIL / 2 PASS counterproof, final 323 PASS,
broader 352 PASS / 3 host-environment FAIL, measurements, manifests and reports
remain available remotely, including aliases where the body is already selected.
No huge unchanged source archives, full toolchain or dependency images are added
to the remote tar. The complete indexed source bytes remain durable locally.

Preserved archival limits are explicit. The old profiling-plugin body with hash
a11f1f9c88c9329755e39154ff693a639c1c91c916c2fb3021cd56876d4c8059
is unavailable, not reconstructed, and not claimed retained. The later retained
plugin does not replace that historical body. Three Ruff cache files totaling
306 bytes ARE actually retained, locally and remotely; no blanket cache exclusion
is claimed. Retrospective dependency hashes are not an upfront environment image.

The bounded scan result is a memory-only correction under the original fixed
nonempty marker. It proves no useful Windows speedup, 60-minute headroom, CI,
native GUI or complete verification result. Broader real host/preflight failures
remain failures. The owned-temp workflow changes only eight lines in two step
env mappings; canonical tests, command scope and 60-minute timeout are preserved.
Neither source proposal grants adoption, W03 PASS, Gate A or platform credit.

Original frozen records and both independent reports retain their exact words,
historical paths, counterproofs and author/reviewer premise errors. No product or
helper module was imported, and no test, build, install, service, socket, GUI,
CI, root commit/push or product actor was run. Root remained clean d28/e72 with
all 1,797 tracked file bytes, modes, Git identities and status neutral.

retention-manifest.json exhaustively binds durable payloads except itself. The
adjacent selected archive manifest binds every safe regular tar member, all read
back byte-for-byte. Collection source and HANDOFF are sealed for a different
independent binding reviewer; this collector supplies no independent source verdict.
