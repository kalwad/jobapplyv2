"""Frozen tooling-input retention only; imports no project or helper modules."""
from pathlib import Path, PurePosixPath
import datetime
import gzip
import hashlib
import io
import json
import shutil
import stat
import subprocess
import tarfile
import traceback

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
OUT = Path('/tmp/japp-m03-w03-ci-retry-tooling-retained-20261019')
STORE = Path('/Users/tanishkalwad/jobapplyv2-evidence/m03-w03-ci-retry-tooling-20261019')
AUTHOR = Path('/tmp/japp-m03-w03-ci-performance-preparation-20261019')
SCAN_REVIEW = Path('/tmp/japp-m03-w03-independent-bounded-scan-review-20261019')
TEMP = Path('/tmp/japp-m03-w03-ci-owned-temp-proposal-20261019-retained')
TEMP_REVIEW = Path('/tmp/japp-m03-w03-ci-owned-temp-independent-review-20261019')
HEAD = 'd28cfc70feda604c508bc18c778992a0ca559e5a'
TREE = 'e72a0523d4b3183b5a658ccd74ce02a8dbd4b8e8'
TEMP_SHA = 'cbf266068eeac6d48d63205a24e61a119e96febe627395d55d0fe0e92cc08076'
PREFIX = 'm03-w03-ci-retry-tooling-20261019'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def dump(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')

def safe(name):
    path = PurePosixPath(name)
    assert name and not path.is_absolute() and '..' not in path.parts and '\\' not in name, name
    return path

def tracked():
    records = []
    raw = subprocess.run(['git', 'ls-files', '--stage', '-z'], cwd=ROOT, capture_output=True, check=True).stdout
    for item in raw.split(b'\0'):
        if not item:
            continue
        header, name = item.split(b'\t', 1)
        mode, blob, stage = header.decode().split()
        path = ROOT / name.decode()
        info = path.lstat()
        assert stat.S_ISREG(info.st_mode)
        records.append({'path': name.decode(), 'git_mode': mode, 'git_blob': blob, 'stage': stage, 'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode), 'sha256': digest(path)})
    return {'head': subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=ROOT, capture_output=True, check=True, text=True).stdout.strip(), 'tree': subprocess.run(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, capture_output=True, check=True, text=True).stdout.strip(), 'status': subprocess.run(['git', 'status', '--porcelain=v1'], cwd=ROOT, capture_output=True, check=True, text=True).stdout, 'tracked': records}

def main():
    assert not STORE.exists()
    before = tracked()
    assert before['head'] == HEAD and before['tree'] == TREE and before['status'] == '' and len(before['tracked']) == 1797
    dump(OUT / 'tracked-before.json', before)
    STORE.mkdir()
    (STORE / 'blobs').mkdir()
    selected = {}
    remote_hashes = set()
    baseline = {row['path']: row for row in before['tracked']}
    source_unchanged = []
    source_changed = []

    def select(path, role, expected=None, size=None, remote=True, recovery=None):
        info = path.lstat()
        assert stat.S_ISREG(info.st_mode), str(path)
        observed = digest(path)
        assert expected is None or observed == expected, str(path)
        assert size is None or info.st_size == size, str(path)
        blob = STORE / 'blobs' / observed
        if not blob.exists():
            shutil.copyfile(path, blob)
            assert digest(blob) == observed
        key = str(path)
        if key in selected:
            assert selected[key]['sha256'] == observed
            if role not in selected[key]['roles']:
                selected[key]['roles'].append(role)
        else:
            selected[key] = {'kind': 'original-file', 'original': key, 'sha256': observed, 'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode), 'mode_octal': oct(stat.S_IMODE(info.st_mode)), 'roles': [role], 'durable_relative': 'blobs/' + observed, 'git_recovery': recovery}
        if recovery is not None:
            selected[key]['git_recovery'] = recovery
        if remote:
            remote_hashes.add(observed)

    author_manifest = json.loads((AUTHOR / 'retention-manifest.json').read_text())
    source_manifest = json.loads((AUTHOR / 'source-manifest.json').read_text())
    assert len(author_manifest) == 1959 and len(source_manifest) == 1798
    for name, record in sorted(author_manifest.items()):
        safe(name)
        recovery = None
        remote = not name.startswith('source/')
        if name.startswith('source/'):
            relative = name[len('source/'):]
            assert source_manifest[relative] == record
            old = baseline.get(relative)
            if old is not None and old['sha256'] == record['sha256'] and old['bytes'] == record['bytes']:
                recovery = {'commit': HEAD, 'tree': TREE, 'path': relative, 'git_blob': old['git_blob'], 'git_mode': old['git_mode'], 'sha256': old['sha256'], 'bytes': old['bytes']}
                source_unchanged.append(relative)
            else:
                remote = True
                source_changed.append(relative)
        select(AUTHOR / name, 'frozen-bounded-scan-author-1959', record['sha256'], record['bytes'], remote, recovery)
    assert len(source_unchanged) == 1796
    assert source_changed == ['scripts/tests/test_status_scan_streaming.py', 'scripts/validate_status.py']
    select(AUTHOR / 'retention-manifest.json', 'original-author-index')
    caches = [name for name in author_manifest if name.startswith('.ruff_cache/')]
    assert len(caches) == 3 and sum(author_manifest[name]['bytes'] for name in caches) == 306
    review_manifest = json.loads((SCAN_REVIEW / 'retention-manifest.json').read_text())['records']
    assert len(review_manifest) == 184
    for row in review_manifest:
        safe(row['path'])
        select(SCAN_REVIEW / row['path'], 'independent-bounded-review-sealed-record', row['sha256'], row['bytes'])
    select(SCAN_REVIEW / 'retention-manifest.json', 'independent-bounded-review-original-index')
    actual_review = {str(path.relative_to(SCAN_REVIEW)) for path in SCAN_REVIEW.rglob('*') if path.is_file()}
    assert actual_review == {row['path'] for row in review_manifest} | {'retention-manifest.json'} and len(actual_review) == 185
    temp_manifest = json.loads((TEMP / 'manifest.json').read_text())
    temp_archive = TEMP / 'proof.tar.gz'
    assert digest(temp_archive) == TEMP_SHA and temp_archive.stat().st_size == 416957
    assert temp_manifest['sha256'] == TEMP_SHA and temp_manifest['regular_members'] == 72
    select(temp_archive, 'exact-owned-temp-author-sealed-archive', TEMP_SHA, 416957)
    select(TEMP / 'manifest.json', 'owned-temp-author-adjacent-original-manifest')
    temp_review_manifest = json.loads((TEMP_REVIEW / 'retention-manifest.json').read_text())
    assert len(temp_review_manifest) == 24
    for name, row in sorted(temp_review_manifest.items()):
        safe(name)
        select(TEMP_REVIEW / name, 'independent-owned-temp-review-sealed-record', row['sha256'], row['bytes'])
    select(TEMP_REVIEW / 'retention-manifest.json', 'independent-owned-temp-review-original-index')
    assert {str(path.relative_to(TEMP_REVIEW)) for path in TEMP_REVIEW.rglob('*') if path.is_file()} == set(temp_review_manifest) | {'retention-manifest.json'}
    nested = []
    with tarfile.open(temp_archive, 'r:gz') as archive:
        assert len(archive.getmembers()) == 72
        seen = set()
        for member in archive.getmembers():
            safe(member.name)
            assert member.isfile() and not member.issym() and not member.islnk() and member.name not in seen
            seen.add(member.name)
            stream = archive.extractfile(member)
            assert stream is not None
            data = stream.read()
            assert len(data) == member.size
            observed = sha(data)
            blob = STORE / 'blobs' / observed
            if not blob.exists():
                blob.write_bytes(data)
            key = str(temp_archive) + '!' + member.name
            selected[key] = {'kind': 'logical-archive-member', 'original': key, 'parent_archive_sha256': TEMP_SHA, 'member': member.name, 'sha256': observed, 'bytes': member.size, 'mode': member.mode, 'mode_octal': oct(member.mode), 'roles': ['complete-owned-temp-72-member-logical-binding'], 'durable_relative': 'blobs/' + observed, 'git_recovery': None}
            remote_hashes.add(observed)
            nested.append({'member': member.name, 'sha256': observed, 'bytes': member.size, 'mode': member.mode, 'durable_relative': 'blobs/' + observed})
    limits = json.loads((SCAN_REVIEW / 'nonblocking-retention-limits.json').read_text())
    assert limits['historical_profile_plugin']['unretained_source_sha256'] == 'a11f1f9c88c9329755e39154ff693a639c1c91c916c2fb3021cd56876d4c8059'
    assert not (STORE / 'blobs' / limits['historical_profile_plugin']['unretained_source_sha256']).exists()
    scan_findings = json.loads((SCAN_REVIEW / 'findings.json').read_text())
    owned_findings = json.loads((TEMP_REVIEW / 'findings.json').read_text())
    assert scan_findings['actual_scoped_result'].startswith('323') and scan_findings['actual_broader_result'].startswith('352')
    assert owned_findings['only8inserted_lines_two_step_envs'] is True
    assert owned_findings['base_sha'] == HEAD and owned_findings['base_tree'] == TREE
    rows = []
    for record in sorted(selected.values(), key=lambda row: row['original']):
        record['remote_included_by_content'] = record['sha256'] in remote_hashes
        record['durable_full_copy'] = str(STORE / record['durable_relative'])
        if not record['remote_included_by_content']:
            assert record['git_recovery'] is not None, record['original']
            record['remote_omission_reason'] = 'Unchanged source recoverable from exact d28 Git object; complete bytes retained in durable CAS.'
        rows.append(record)
    omitted = [row for row in rows if not row['remote_included_by_content']]
    dump(STORE / 'selection.json', {'scope': 'COMPLETE_FROZEN_PRESENT_INPUTS_LOCAL_SELECTED_CONTENT_REMOTE_NOT_COMPLETE_SOURCE_IMAGE', 'records': rows})
    dump(STORE / 'remote-omissions.json', {'scope': 'EXACT_REMOTE_SELECTED_CONTENT_OMISSIONS_ALL_HAVE_FULL_LOCAL_CAS_AND_GIT_IDENTITIES', 'records': omitted, 'original_path_count': len(omitted), 'unique_blob_count': len({row['sha256'] for row in omitted}), 'never_a_complete_remote_source_image': True})
    dump(STORE / 'owned-temp-archive-member-bindings.json', {'original_archive': str(temp_archive), 'sha256': TEMP_SHA, 'bytes': 416957, 'safe_regular_members': nested})
    dump(STORE / 'provenance-limits.json', {'missing_historical_plugin_body': limits['historical_profile_plugin'], 'missing_body_not_reconstructed_or_claimed_retained': True, 'tiny_Ruff_cache_exception': {'paths': caches, 'bytes': 306, 'all_three_exact_bodies_retained_locally_and_remotely': True}, 'retrospective_dependency_environment': 'Original review hashes 3218 regular dependency files retrospectively. That environment is not an upfront image and is not one of these frozen present-file input sets. Hash manifests/limits are retained; no full dependency/toolchain/environment-image claim is made.', 'observed_scope': {'final_focused': scan_findings['actual_scoped_result'], 'overbroad': scan_findings['actual_broader_result'], 'old_RED': scan_findings['actual_old_bounded_read_RED'], 'memory_only_not_Windows_headroom': True, 'workflow_only_eight_step_env_lines': True, 'canonical_tests_commands_and_60_minute_limit_preserved': True}, 'ongoing_root_retry_candidate': 'Excluded entirely; no candidate tree, commit, push or verification claim is supplied.', 'no_current_CI_native_or_full_run_claim': True})
    after = tracked()
    assert after == before
    dump(OUT / 'tracked-after.json', after)
    dump(STORE / 'tracked-before.json', before)
    dump(STORE / 'tracked-after.json', after)
    shutil.copyfile(Path(__file__), STORE / 'collector.py')
    dump(STORE / 'invocation.json', {'argv': [str(Path(__file__))], 'collector_sha256': digest(Path(__file__)), 'started_at_utc': STARTED, 'scope': 'READ_HASH_COPY_ARCHIVE_GIT_IDENTITY_ONLY_NO_PROJECT_IMPORT_HELPER_TEST_BUILD_INSTALL_PROCESS_NETWORK_CI_OR_ROOT_WRITE'})
    dump(STORE / 'collection-checks.json', {'author_index_records': 1959, 'author_source_files': 1798, 'unchanged_source_paths_vs_clean_d28': 1796, 'remote_required_changed_or_new_source_paths': source_changed, 'bounded_review_actual_files': 185, 'owned_temp_archive_sha256': TEMP_SHA, 'owned_temp_archive_bytes': 416957, 'owned_temp_regular_members': 72, 'owned_temp_independent_index_records': 24, 'tiny_Ruff_cache_count': 3, 'tiny_Ruff_cache_bytes': 306, 'missing_historical_plugin_not_reconstructed': True, 'root_before_after_all_1797_tracked_entries_identical': True})
    (STORE / 'HANDOFF.md').write_text('''# Selected narrow W03 CI retry tooling evidence

This is archival source/data retention for two immutable proposals and their
independent reviews. It is not the ongoing root retry candidate: that candidate
was not read, frozen, committed, pushed or executed by this collector.

The durable CAS retains all 1,959 indexed present author records plus index,
the complete 1,798-file proposed source set, all 185 bounded-review files, the
exact cbf26606... / 416,957-byte owned-temp archive and its 72 logical members,
and all 24 owned-temp review index members plus manifest. Selection preserves
original paths, hashes, sizes and modes; alias bodies are content-addressed once.

The REMOTE TAR IS SELECTED, NOT A COMPLETE SOURCE OR HISTORICAL INPUT IMAGE.
Every omitted present-file body is listed in remote-omissions.json with its
full durable CAS bytes and exact clean d28 Git recovery identity. All raw patches,
preimages, the two changed/new bounded-scan source files, owned-temp workflow
before/after, raw commands, old 1 FAIL / 2 PASS counterproof, final 323 PASS,
broader 352 PASS / 3 host-environment FAIL, measurements, manifests and reports
remain available remotely, including aliases where the body is already selected.
No huge unchanged source archives, full toolchain or dependency images are added
to the remote tar. The complete indexed source bytes remain durable locally.

Preserved archival limits are explicit. The old profiling-plugin body with hash
a11f1f9c88c9329755e39154ff693a639c1c91c916c2fb3021cd56876d4c8059
is unavailable, not reconstructed, and not claimed retained. The later retained
plugin does not replace that historical body. Three Ruff cache files totaling
306 bytes ARE actually retained, locally and remotely; no blanket cache exclusion
is claimed. Retrospective dependency hashes are not an upfront environment image.

The bounded scan result is a memory-only correction under the original fixed
nonempty marker. It proves no useful Windows speedup, 60-minute headroom, CI,
native GUI or complete verification result. Broader real host/preflight failures
remain failures. The owned-temp workflow changes only eight lines in two step
env mappings; canonical tests, command scope and 60-minute timeout are preserved.
Neither source proposal grants adoption, W03 PASS, Gate A or platform credit.

Original frozen records and both independent reports retain their exact words,
historical paths, counterproofs and author/reviewer premise errors. No product or
helper module was imported, and no test, build, install, service, socket, GUI,
CI, root commit/push or product actor was run. Root remained clean d28/e72 with
all 1,797 tracked file bytes, modes, Git identities and status neutral.

retention-manifest.json exhaustively binds durable payloads except itself. The
adjacent selected archive manifest binds every safe regular tar member, all read
back byte-for-byte. Collection source and HANDOFF are sealed for a different
independent binding reviewer; this collector supplies no independent source verdict.
''')
    payload = [{'path': str(path.relative_to(STORE)), 'bytes': path.stat().st_size, 'mode': 0o444, 'sha256': digest(path)} for path in sorted(STORE.rglob('*')) if path.is_file()]
    dump(STORE / 'retention-manifest.json', {'scope': 'EXHAUSTIVE_LOCAL_PRESENT_FROZEN_INPUTS_AND_COLLECTION_RECORDS_EXCEPT_THIS_MANIFEST', 'files': payload})
    members = []
    for path in sorted(STORE.rglob('*')):
        if path.is_file() and (path.parent != STORE / 'blobs' or path.name in remote_hashes):
            members.append({'path': str(path.relative_to(STORE)), 'bytes': path.stat().st_size, 'mode': 0o444, 'sha256': digest(path)})
    archive_path = OUT / 'ci-retry-tooling-selected.tar.gz'
    with archive_path.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
                for row in members:
                    safe(row['path'])
                    info = tarfile.TarInfo(PREFIX + '/' + row['path'])
                    info.size = row['bytes']
                    info.mode = row['mode']
                    info.mtime = info.uid = info.gid = 0
                    info.uname = info.gname = ''
                    with (STORE / row['path']).open('rb') as stream:
                        archive.addfile(info, stream)
    assert archive_path.stat().st_size < 15 * 1024 * 1024
    expected = {PREFIX + '/' + row['path']: row for row in members}
    seen = set()
    with tarfile.open(archive_path, 'r:gz') as archive:
        for member in archive.getmembers():
            safe(member.name)
            assert member.isfile() and not member.issym() and not member.islnk()
            assert member.name not in seen and member.name in expected
            seen.add(member.name)
            stream = archive.extractfile(member)
            assert stream is not None
            data = stream.read()
            row = expected[member.name]
            assert len(data) == row['bytes'] and sha(data) == row['sha256'] and member.mode == row['mode']
    assert seen == set(expected)
    for row in payload:
        path = STORE / row['path']
        assert path.stat().st_size == row['bytes'] and digest(path) == row['sha256']
    final = tracked()
    assert final == before
    dump(OUT / 'tracked-final.json', final)
    result = {'scope': 'SELECTED_IMMUTABLE_NARROW_CI_RETRY_TOOLING_NOT_ROOT_CANDIDATE_OR_EXECUTION', 'durable': str(STORE), 'archive': str(archive_path), 'archive_bytes': archive_path.stat().st_size, 'archive_sha256': digest(archive_path), 'safe_regular_members': len(members), 'complete_member_and_local_readback': True, 'duplicate_missing_unsafe_nonregular_member_count': 0, 'original_and_logical_bindings': len(rows), 'unique_local_blobs': len(list((STORE / 'blobs').iterdir())), 'remote_omitted_path_bindings': len(omitted), 'remote_omitted_unique_blobs': len({row['sha256'] for row in omitted}), 'all_remote_omissions_have_full_durable_CAS_and_exact_d28_Git_identity': True, 'selection_sha256': digest(STORE / 'selection.json'), 'omissions_sha256': digest(STORE / 'remote-omissions.json'), 'retention_manifest_sha256': digest(STORE / 'retention-manifest.json'), 'handoff_sha256': digest(STORE / 'HANDOFF.md'), 'collector_sha256': digest(Path(__file__)), 'root_tracked_before_after_final_identical': True, 'tracked_snapshot_sha256': digest(OUT / 'tracked-before.json'), 'missing_historical_plugin_body_reconstructed': False, 'tiny_Ruff_cache_bytes_actually_retained': 306, 'current_candidate_or_CI_native_or_Windows_credit': False}
    dump(OUT / 'ci-retry-tooling-selected.manifest.json', {**result, 'members': members})
    dump(OUT / 'collection-result.json', result)
    for path in STORE.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            path.chmod(0o444)
    for path in sorted((path for path in STORE.rglob('*') if path.is_dir()), key=lambda path: len(path.parts), reverse=True):
        path.chmod(0o555)
    STORE.chmod(0o555)
    for row in payload:
        assert stat.S_IMODE((STORE / row['path']).stat().st_mode) == row['mode']
    for path in OUT.iterdir():
        if path.is_file():
            path.chmod(0o444)
    print(json.dumps(result, indent=2), flush=True)

STARTED = datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
    main()
except BaseException as error:
    dump(OUT / 'collector-failure.json', {'scope': 'ARCHIVAL_COLLECTOR_PREMISE_FAILURE_NOT_PRODUCT_OR_PROPOSAL_FAILURE', 'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc(), 'collector_sha256': digest(Path(__file__))})
    raise
