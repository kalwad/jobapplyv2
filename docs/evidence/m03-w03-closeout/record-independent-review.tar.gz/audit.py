"""Finite, read-only closeout records/copy binding; no subject imports or execution."""
import hashlib, io, json, pathlib, subprocess, tarfile

R=pathlib.Path('/Users/tanishkalwad/jobapplyv2')
E=R/'docs/evidence/m03-w03-closeout'
O=pathlib.Path(__file__).parent
HEAD='6d3a6b8ccde5b75e12248ae7bbefc473b72922e4'
TREE='34fcf854cb4a1a452b267a02a05e0c34aeb6f89c'
G=['/usr/bin/git','--no-optional-locks','-C',str(R)]
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(G+list(args))
def safe(n):
 p=pathlib.PurePosixPath(n)
 return bool(n) and not p.is_absolute() and '..' not in p.parts and '\\' not in n and '\x00' not in n
assert git('rev-parse','HEAD').decode().strip()==HEAD
changed=git('diff','--name-only').decode().splitlines()
expected=['docs/KNOWN_ISSUES.md','docs/PROJECT_STATUS.md','docs/REQUIREMENTS_TRACEABILITY.md','docs/TEST_EVIDENCE.md','docs/traceability.json']
assert changed==expected
for n in ['docs/MASTER_IMPLEMENTATION_SPEC.md','docs/DECISIONS.md','docs/CRITICAL_GATES.md','CLAUDE.md']:
 assert (R/n).read_bytes()==git('show',HEAD+':'+n)
old=json.loads(git('show',HEAD+':docs/traceability.json'))
new=json.loads((R/'docs/traceability.json').read_bytes())
differences=[]
def diff(a,b,path=''):
 if type(a)!=type(b):differences.append((path,a,b));return
 if isinstance(a,dict):
  assert set(a)==set(b)
  for k in a:diff(a[k],b[k],path+'/'+k)
 elif isinstance(a,list):
  if len(a)!=len(b):differences.append((path,a,b));return
  for i,(x,y) in enumerate(zip(a,b)):diff(x,y,path+'/'+str(i))
 elif a!=b:differences.append((path,a,b))
diff(old,new)
assert len(differences)==4
packages=new['work_packages']
assert len(packages)==300 and len(new['requirements'])==193 and len({p['milestone'] for p in packages})==39
lookup={x['id']:x for x in packages}
assert lookup['M03-W03']['current_state']=='VERIFIED' and lookup['M03-W03']['verified_revision']=='tree '+TREE
assert lookup['M03-W04']['current_state']=='IN_PROGRESS'
assert [x['id'] for x in packages if x['current_state']=='IN_PROGRESS']==['M03-W04']
assert sum(x['current_state']=='VERIFIED' for x in packages)==36
assert {p.split('/')[2] for p,_,_ in differences}=={str(packages.index(lookup['M03-W03'])),str(packages.index(lookup['M03-W04']))}
artifacts=json.loads((E/'artifacts.json').read_bytes())
assert len(artifacts)==8
archive_results=[]
for n,row in artifacts.items():
 b=(E/n).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
 assert b==pathlib.Path(row['source']).read_bytes()
 with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as t:
  ms=t.getmembers();assert len(ms)==row['safe_regular_members'] and all(m.isfile() and safe(m.name) for m in ms)
  assert len({m.name.casefold() for m in ms})==len(ms)
  # Read every member without extraction; copy review does not reinterpret their prior proof.
  for m in ms:assert len(t.extractfile(m).read())==m.size
 archive_results.append({'path':n,'sha256':sha(b),'regular_members':len(ms),'donor_bytes_exact':True})
copies=[('terminal-ci-independent-review','/tmp/japp-m03-w03-independent-hosted-ci-6d3-review-20261019'),('acceptance-obligations','/tmp/japp-m03-w04-independent-acceptance-obligations-20261019')]
copy_rows=[]
for dest,source in copies:
 actual={p.name:p for p in (E/dest).iterdir() if p.is_file()}
 donor={p.name:p for p in pathlib.Path(source).iterdir() if p.is_file()}
 assert set(actual)==set(donor)
 for n,p in actual.items():
  b=p.read_bytes();assert b==donor[n].read_bytes();copy_rows.append({'path':dest+'/'+n,'sha256':sha(b)})
decision=json.loads((E/'decision.json').read_bytes())
assert decision['decision']=='VERIFIED' and decision['work_package']=='M03-W03' and decision['evaluated_commit']==HEAD and decision['evaluated_tree']==TREE
assert decision['manual_owner_click'] is False and decision['milestone_accepted'] is False and decision['release_ready'] is False
assert decision['independent_ci_review_sha256']=='06601fe88e7001cae570f92f41186b91beb96da6b7ff3dfba8ab33a882c809e5'
assert decision['next_package']=='M03-W04' and 'KI-0108 OPEN' in decision['remaining_issue']
inputs=[]
for p in [R/n for n in expected]+sorted(p for p in E.rglob('*') if p.is_file()):
 b=p.read_bytes();inputs.append({'path':str(p),'bytes':len(b),'sha256':sha(b)})
result={'result':'PASS_STATIC_RECORDS_WITH_ONE_PENDING_WORDING_CORRECTION_AND_FOCUSED_TEST_CLOSURE','evaluated_source':HEAD,'tree':TREE,'changed_canonical_paths':changed,'traceability_semantic_changes':differences,'inventories':{'requirements':193,'milestones':39,'work_packages':300,'verified':36,'sole_in_progress':'M03-W04'},'archive_copies':archive_results,'independent_review_copies':copy_rows,'canonical_master_decisions_gateA_CLAUDE_unchanged':True,'pending_wording':'KNOWN_ISSUES.md:43 case finishes its1.7s body must be case reports1.7s and fails during fixture teardown; parent has accepted correction after running focused tests close.','focused_tests':'RUNNING at review; partial dot output only, no final result inferred','inputs':inputs,'scope':'Read-only Git/data/static copy audit only; no subject tests, builds, imports, network, actors, CI or root writes.'}
(O/'findings.json').write_text(json.dumps(result,indent=2)+'\n')
(O/'reviewed-doc-diff.patch').write_bytes(git('diff','--',*expected))
print(json.dumps({k:v for k,v in result.items() if k not in ('inputs','independent_review_copies','traceability_semantic_changes')},indent=2))
