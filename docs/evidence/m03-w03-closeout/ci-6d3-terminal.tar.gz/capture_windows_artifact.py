"""Retain official explicit test outputs without opening a browser or trace viewer."""
import io,json,pathlib,stat,zipfile
from collect_hosted_ci import ROOT,REPO,RUN_ID,HEAD,TREE,api,capture,sha

listing,lr=api(f'repos/{REPO}/actions/runs/{RUN_ID}/artifacts?per_page=100','official-artifact-list')
assert len(listing['artifacts'])==listing['total_count']
assert not (ROOT/'official-artifacts-list.json').exists()
(ROOT/'official-artifacts-list.json').write_bytes((ROOT/lr['stdout']['path']).read_bytes())
matches=[x for x in listing['artifacts'] if x['name']=='playwright-failure-windows-2025']
assert len(matches)<=1
result={'run_id':RUN_ID,'head_sha':HEAD,'expected_tree_sha':TREE,'list_record':lr,'matching_artifact_count':len(matches),'artifacts':[],'scope':'Official Windows explicit Playwright failure outputs retained as bytes only. No viewer, browser, native actor, retry or workflow mutation.'}
for artifact in matches:
 assert artifact['workflow_run']['id']==RUN_ID and artifact['workflow_run']['head_sha']==HEAD
 assert artifact['expired'] is False
 raw,rr=capture(['/opt/homebrew/bin/gh','api','-H','Accept: application/vnd.github+json',f"repos/{REPO}/actions/artifacts/{artifact['id']}/zip"],'official-windows-playwright-artifact-zip')
 archive_path=ROOT/'windows-playwright-failure-artifact.zip';assert not archive_path.exists();archive_path.write_bytes(raw)
 folder=ROOT/'windows-playwright-failure-artifact';assert not folder.exists();folder.mkdir()
 rows=[];seen=set();folded=set();directories=[]
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  infos=z.infolist();assert len(infos)<=10000 and sum(x.file_size for x in infos)<=2*1024*1024*1024
  for info in infos:
   name=info.filename;p=pathlib.PurePosixPath(name)
   assert name and '\\' not in name and '\0' not in name and not p.is_absolute() and '..' not in p.parts
   assert name not in seen and name.casefold() not in folded
   seen.add(name);folded.add(name.casefold());assert not stat.S_ISLNK(info.external_attr>>16)
   assert info.file_size<=512*1024*1024
   target=folder/pathlib.Path(*p.parts)
   if info.is_dir():target.mkdir(parents=True,exist_ok=True);directories.append(name);continue
   # Frozen workflow uploads only test-results/; GitHub may strip that root.
   data=z.read(info);assert len(data)==info.file_size
   target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();target.write_bytes(data)
   row={'path':name,'bytes':len(data),'sha256':sha(data),'compressed_bytes':info.compress_size,'crc32_hex':f'{info.CRC:08x}'}
   if name.endswith('trace.zip'):
    with zipfile.ZipFile(io.BytesIO(data)) as trace:
     inner=trace.infolist();assert len(inner)<=20000 and sum(x.file_size for x in inner)<=1024*1024*1024
     assert trace.testzip() is None
     row['inner_trace_zip_crc_checked']=True;row['inner_trace_zip_entry_count']=len(inner)
   rows.append(row)
 result['artifacts'].append({'artifact_id':artifact['id'],'name':artifact['name'],'official_metadata':artifact,'zip':{'path':str(archive_path.relative_to(ROOT)),'bytes':len(raw),'sha256':sha(raw),'command_stdout':rr['stdout']['path']},'download_record':rr,'extracted_folder':str(folder.relative_to(ROOT)),'zip_entry_count':len(infos),'safe_regular_file_count':len(rows),'directories':directories,'files':rows,'all_members_read_with_crc_validation':True})
assert not (ROOT/'windows-playwright-artifact-manifest.json').exists()
(ROOT/'windows-playwright-artifact-manifest.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'matching_artifact_count':len(matches),'artifacts':[{'artifact_id':x['artifact_id'],'name':x['name'],'zip':x['zip'],'regular_files':x['safe_regular_file_count'],'explicit_output_names':[r['path'] for r in x['files']]} for x in result['artifacts']]},indent=2))
