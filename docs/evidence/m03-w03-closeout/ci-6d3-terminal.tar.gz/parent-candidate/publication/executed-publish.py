from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,time,traceback
B=Path('/tmp/japp-m03-w03-ci-retry-candidate-20261019');S=B/'source';R=Path('/Users/tanishkalwad/jobapplyv2');O=B/'publication';O.mkdir(exist_ok=False)
HEAD='d28cfc70feda604c508bc18c778992a0ca559e5a';TREE='34fcf854cb4a1a452b267a02a05e0c34aeb6f89c';REF='refs/heads/codex/autofill-evaluation-hardening'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def inv(p,rows):return {n:{'bytes':(p/n).stat().st_size,'sha256':sha(p/n)} for n in sorted(rows)}
def rootgit(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
shutil.copy2(__file__,O/'executed-publish.py');expected=json.loads((B/'candidate-source-manifest.json').read_text());rootrows=json.loads((B/'root-before.json').read_text())
review=Path('/tmp/japp-m03-w03-composed-ci-retry-independent-review-20261019');assert sha(review/'findings.json')=='bf54d875ce899a57813277105fb034b0badf23b9ba9c50eba1a36a2fd0eabeb5'
assert sha(review/'REVIEW.md')=='2407ec30ca2d5e61e62b973e8f037e502143710da912171a0ff49fe32c4ae71e'
assert inv(S,expected)==expected and inv(R,rootrows)==rootrows and rootgit('rev-parse','HEAD')==HEAD and rootgit('status','--porcelain=v1','--untracked-files=all')==''
env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@24/bin:'+env['PATH'];records=[]
def run(label,args,cwd=S,timeout=120):
 exe=Path(shutil.which(args[0],path=env['PATH']) or args[0]).resolve(strict=True)
 d={'argv':args,'cwd':str(cwd),'started_utc':datetime.now(timezone.utc).isoformat(),'tool':str(exe),'tool_sha256_before':sha(exe),'candidate_tree':TREE,'review_findings_sha256':sha(review/'findings.json'),'environment_scope':'Normal authenticated Git environment inherited; credentials and full environment not serialized. PATH selects pinned Node24; normal Git user configuration/hook/signing policy retained.'};write(O/(label+'-upfront.json'),d);t=time.monotonic()
 with (O/(label+'.stdout')).open('xb') as out,(O/(label+'.stderr')).open('xb') as err:p=subprocess.run(args,cwd=cwd,env=env,stdout=out,stderr=err,check=False,timeout=timeout)
 d.update(exit_code=p.returncode,seconds=time.monotonic()-t,ended_utc=datetime.now(timezone.utc).isoformat(),stdout_sha256=sha(O/(label+'.stdout')),stderr_sha256=sha(O/(label+'.stderr')),tool_sha256_after=sha(exe));write(O/(label+'-result.json'),d);records.append(d);print(label,p.returncode,flush=True)
 assert p.returncode==0 and d['tool_sha256_before']==d['tool_sha256_after'],label
 return (O/(label+'.stdout')).read_text().strip()
try:
 assert run('verify-tree',['git','write-tree'])==TREE
 run('whitespace',['git','diff','--cached','--check'])
 assert (S/'.git/HEAD').read_text()=='ref: refs/heads/codex/ci-retry-candidate\n'
 assert not (S/'.git/refs/heads/codex/ci-retry-candidate').exists()
 run('set-reviewed-parent',['git','update-ref','refs/heads/codex/ci-retry-candidate',HEAD])
 name=rootgit('config','user.name');email=rootgit('config','user.email');assert name and email
 run('commit',['git','-c','user.name='+name,'-c','user.email='+email,'commit','-m','Bound evidence scan memory and use runner-owned CI temporary files'])
 commit=run('committed-head',['git','rev-parse','HEAD']);assert run('committed-tree',['git','rev-parse','HEAD^{tree}'])==TREE
 assert run('committed-parent',['git','rev-parse','HEAD^'])==HEAD
 assert run('candidate-clean',['git','status','--porcelain=v1','--untracked-files=all'])==''
 remote=rootgit('remote','get-url','origin');assert remote in ['https://github.com/kalwad/jobapplyv2.git','https://github.com/kalwad/jobapplyv2','git@github.com:kalwad/jobapplyv2.git']
 run('remote',['git','remote','add','origin',remote])
 current=run('remote-head-before',['git','ls-remote','--heads','origin',REF]);assert current.split()==[HEAD,REF],current
 run('push-normal-fast-forward',['git','push','--porcelain','origin','HEAD:'+REF])
 remote_after=run('remote-head-after',['git','ls-remote','--heads','origin',REF]);assert remote_after.split()==[commit,REF]
 assert inv(S,expected)==expected and inv(R,rootrows)==rootrows and rootgit('rev-parse','HEAD')==HEAD and rootgit('status','--porcelain=v1','--untracked-files=all')==''
 write(O/'publication-closure.json',{'commit':commit,'tree':TREE,'actual_parent':HEAD,'remote_ref':REF,'normal_fast_forward_pushed':True,'force_used':False,'root_local_head':HEAD,'root1797_unchanged':True,'candidate1798_unchanged':True,'new_full_or_hosted_pass_claimed':False,'commands':records})
 print('PUSHED',commit,'TREE',TREE,'LOCALROOTREMAINS',HEAD,flush=True)
except BaseException as e:
 write(O/'publication-failure.json',{'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc(),'closure_claim':False});raise
