import base64,hashlib,json,pathlib,stat
from collect_hosted_ci import ROOT,REPO,RUN_ID,HEAD,TREE,CANDIDATE,PRIVATE_ROOT,api,capture,sha

commit,cr=api(f'repos/{REPO}/git/commits/{HEAD}','expected-head-git-commit')
assert commit['sha']==HEAD and commit['tree']['sha']==TREE
inventory,ir=api(f'repos/{REPO}/git/trees/{TREE}?recursive=1','expected-recursive-tree')
assert inventory['sha']==TREE and inventory.get('truncated') is False
raw,lr=capture(['/usr/bin/git','-C',str(CANDIDATE),'ls-tree','-rz','--full-tree',HEAD],'candidate-exact-git-ls-tree')
local=[]
for entry in raw.split(b'\0'):
 if not entry:continue
 meta,path=entry.split(b'\t',1);mode,kind,obj=meta.decode().split();local.append({'path':path.decode(),'mode':mode,'type':kind,'sha':obj})
remote=[{k:r[k] for k in ['path','mode','type','sha']} for r in inventory['tree'] if r['type']!='tree']
assert len(local)==len(remote)==1798 and sorted(local,key=lambda x:x['path'])==sorted(remote,key=lambda x:x['path'])
parent=CANDIDATE.parent
parent_manifest=json.loads((parent/'candidate-source-manifest.json').read_text())
assert set(parent_manifest)=={x['path'] for x in local}
bindings=[]
for entry in local:
 path=CANDIDATE/entry['path'];st=path.lstat();assert stat.S_ISREG(st.st_mode)
 h=hashlib.sha256();g=hashlib.sha1(f'blob {st.st_size}\0'.encode())
 with path.open('rb') as stream:
  for block in iter(lambda:stream.read(1024*1024),b''):h.update(block);g.update(block)
 assert g.hexdigest()==entry['sha'] and parent_manifest[entry['path']]=={'bytes':st.st_size,'sha256':h.hexdigest()}
 bindings.append({'path':entry['path'],'git_blob_sha':entry['sha'],'bytes':st.st_size,'sha256':h.hexdigest()})
(ROOT/'candidate-working-source-binding.json').write_text(json.dumps({'candidate_path':str(CANDIDATE),'head_sha':HEAD,'tree_sha':TREE,'file_count':len(bindings),'all_actual_bytes_equal_git_and_parent_manifest':True,'files':bindings,'scope':'Published candidate-owned source only; private root intentionally remains the older d28 version during independent W04 work.'},indent=2)+'\n')
pull,pr=api(f'repos/{REPO}/pulls/1','pull1-source-context')
assert pull['head']['sha']==HEAD
root_before,rb=capture(['/usr/bin/git','-C',str(PRIVATE_ROOT),'rev-parse','HEAD','HEAD^{tree}'],'private-root-live-version-source-prep')
record={'run_id':RUN_ID,'head_sha':HEAD,'head_tree_sha':TREE,'head_commit_api_tree_verified':True,'candidate_git_directory':str(CANDIDATE),'complete_local_git_entries':len(local),'complete_github_git_entries':len(remote),'local_github_git_entries_equal':True,'recursive_tree_truncated':False,'candidate_working_bytes_match_git_and_parent_manifest':True,'observed_pull_head':pull['head']['sha'],'observed_pull_base':pull['base']['sha'],'observed_pull_merge':pull.get('merge_commit_sha'),'actual_tested_checkout_sha':None,'actual_tested_tree':None,'actual_checkout_scope':'PENDING_CLOSED_ACTUAL_OFFICIAL_HOST_LOGS','private_root_observation':{'head_and_tree':root_before.decode().splitlines(),'record':rb,'scope':'Observed private checkout version, not used as new candidate source.'},'input_records':[cr,ir,lr,pr],'scope':'Immutable remote+candidate-owned source proof only. No result, native behavior, performance or approval inferred.'}
(ROOT/'source-binding-preparation.json').write_text(json.dumps(record,indent=2)+'\n')
parent_rows=[]
for name in ['candidate-source-manifest.json','candidate-source-delta.json','inventory-join.json','preparation-closure.json']:
 data=(parent/name).read_bytes();out=ROOT/'parent-candidate'/name;out.parent.mkdir(parents=True,exist_ok=True);assert not out.exists();out.write_bytes(data);parent_rows.append({'source':str(parent/name),'retained':str(out.relative_to(ROOT)),'bytes':len(data),'sha256':sha(data)})
for folder in ['publication','publication-v2']:
 for path in sorted((parent/folder).iterdir()):
  assert path.is_file() and not path.is_symlink()
  data=path.read_bytes();out=ROOT/'parent-candidate'/folder/path.name;out.parent.mkdir(parents=True,exist_ok=True);assert not out.exists();out.write_bytes(data);parent_rows.append({'source':str(path),'retained':str(out.relative_to(ROOT)),'bytes':len(data),'sha256':sha(data)})
(ROOT/'parent-publication-provenance.json').write_text(json.dumps({'artifacts':parent_rows,'scope':'Actual parent preparation/publication records copied read-only; collector neither pushes nor reruns. Initial observer-whitespace failure remains preserved and distinct from successful normal fast-forward publication-v2.'},indent=2)+'\n')
blobs={x['path']:x for x in inventory['tree'] if x['type']=='blob'}
paths=['.github/workflows/ci.yml','scripts/verification-suites.json','scripts/verify.py','scripts/doctor.py','scripts/validate_status.py','scripts/tests/test_status_scan_streaming.py','scripts/python-test-inventory.v1.json','apps/desktop/src-tauri/Cargo.toml','apps/desktop/src-tauri/src/lib.rs','apps/desktop/src-tauri/src/main.rs','apps/desktop/src-tauri/src/service/platform.rs','apps/desktop/src-tauri/src/service/runtime_descriptor.rs','services/native-host/Cargo.toml','packages/contracts/test/contract/rust-harness/Cargo.toml','apps/desktop/package.json','package.json','pyproject.toml','.nvmrc','.python-version','rust-toolchain.toml','playwright.config.ts','e2e/extension/extension-benchmark.spec.ts']
rows=[]
for index,path in enumerate(paths):
 entry=blobs[path];blob,br=api(f'repos/{REPO}/git/blobs/{entry["sha"]}',f'selected-source-blob-{index+1:02d}')
 assert blob['sha']==entry['sha'] and blob['encoding']=='base64'
 data=base64.b64decode(blob['content']);assert len(data)==blob['size']==entry['size']
 assert hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()==entry['sha']
 assert sha(data)==parent_manifest[path]['sha256']
 out=ROOT/'source'/path;out.parent.mkdir(parents=True,exist_ok=True);assert not out.exists();out.write_bytes(data)
 rows.append({'path':path,'git_blob_sha':entry['sha'],'bytes':len(data),'sha256':sha(data),'record_stdout':br['stdout']['path']})
(ROOT/'selected-source-manifest.json').write_text(json.dumps({'head_sha':HEAD,'tree_sha':TREE,'files':rows,'scope':'Selected exact remote Git blobs joined to all1798 candidate-owned actual working source entries. No private d28 or earlier result transfer.'},indent=2)+'\n')
print(json.dumps({'run_id':RUN_ID,'head':HEAD,'tree':TREE,'complete_entries':len(local),'all_git_and_parent_manifest_equal':True,'selected_blob_count':len(rows),'observed_pull_merge':pull.get('merge_commit_sha'),'private_root_head_and_tree':record['private_root_observation']['head_and_tree'],'parent_artifacts_retained':len(parent_rows)},indent=2))
