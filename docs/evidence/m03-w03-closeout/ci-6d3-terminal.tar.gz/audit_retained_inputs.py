"""Finite raw/source/archive consistency audit; no product checks executed."""
import base64,hashlib,json,pathlib,stat,zipfile
from collect_hosted_ci import ROOT,RUN_ID,HEAD,TREE,sha

def load(name):return json.loads((ROOT/name).read_text())
records=[]
for folder in ['commands','operations']:
    for path in sorted((ROOT/folder).glob('*.record.json')):
        row=json.loads(path.read_text())
        for stream in ['stdout','stderr']:
            item=row[stream];data=(ROOT/item['path']).read_bytes()
            assert len(data)==item['bytes'] and sha(data)==item['sha256'],(path,stream)
        records.append({'path':str(path.relative_to(ROOT)),'exit_code':row['exit_code'],'command_timeout':row.get('collector_command_timeout',False),'argv':row['argv']})
source=load('selected-source-manifest.json')
assert source['head_sha']==HEAD and source['tree_sha']==TREE
failure_source=load('failure-source-manifest.json')
assert failure_source['head_sha']==HEAD and failure_source['tree_sha']==TREE
for row in source['files']+failure_source['files']:
    data=(ROOT/'source'/row['path']).read_bytes()
    assert len(data)==row['bytes'] and sha(data)==row['sha256']
    assert hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()==row['git_blob_sha']
    raw=load(row['record_stdout'])
    assert raw['encoding']=='base64' and raw['sha']==row['git_blob_sha'] and base64.b64decode(raw['content'])==data
prep=load('source-binding-preparation.json')
assert prep['head_sha']==HEAD and prep['head_tree_sha']==TREE and prep['head_commit_api_tree_verified']
assert prep['complete_local_git_entries']==prep['complete_github_git_entries']==1798 and prep['local_github_git_entries_equal']
assert prep['recursive_tree_truncated'] is False
candidate=load('candidate-working-source-binding.json')
assert candidate['head_sha']==HEAD and candidate['tree_sha']==TREE and candidate['file_count']==1798 and candidate['all_actual_bytes_equal_git_and_parent_manifest']
parent=load('parent-candidate/candidate-source-manifest.json')
assert len(parent)==1798
for row in candidate['files']:assert parent[row['path']]=={'bytes':row['bytes'],'sha256':row['sha256']}
for provenance in ['parent-publication-provenance.json','parent-root-fast-forward-provenance.json']:
    value=load(provenance)
    for row in value.get('artifacts',value.get('files',[])):
        data=(ROOT/row['retained']).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256']
platform=load('platform-logs-manifest.json')
assert platform['all_actual_content_trees_match'] and len(platform['platforms'])==3
for row in platform['platforms']:
    data=(ROOT/row['platform_log']).read_bytes()
    assert len(data)==row['bytes'] and sha(data)==row['sha256']
    assert (ROOT/'official-logs'/row['official_combined_member']).read_bytes()==data
    actual=load(row['checkout_commit_api']['record_stdout'])
    assert actual['sha']==row['actual_checkout_sha'] and actual['tree']['sha']==row['actual_checkout_tree']==TREE
manifest=load('official-logs-manifest.json');archive=(ROOT/'logs.zip').read_bytes()
assert len(archive)==manifest['zip']['bytes'] and sha(archive)==manifest['zip']['sha256']
assert archive==(ROOT/manifest['zip']['command_stdout']).read_bytes()
expected={row['path']:row for row in manifest['files']}
with zipfile.ZipFile(ROOT/'logs.zip') as zip:
    members=zip.infolist()
    assert len(members)==manifest['zip_entry_count']
    assert len([m for m in members if not m.is_dir()])==len(expected)==manifest['safe_regular_file_count']
    assert zip.testzip() is None and len({m.filename.casefold() for m in members})==len(members)
    for member in members:
        path=pathlib.PurePosixPath(member.filename)
        assert not path.is_absolute() and '..' not in path.parts and '\\' not in member.filename and '\0' not in member.filename
        assert not stat.S_ISLNK(member.external_attr>>16)
        if member.is_dir():continue
        row=expected[member.filename];data=zip.read(member)
        assert len(data)==row['bytes'] and sha(data)==row['sha256']
        assert format(member.CRC,'08x')==row['crc32_hex'] and (ROOT/'official-logs'/member.filename).read_bytes()==data
artifacts=load('windows-playwright-artifact-manifest.json')
assert artifacts['run_id']==RUN_ID and artifacts['head_sha']==HEAD and artifacts['expected_tree_sha']==TREE
listing=load('official-artifacts-list.json')
assert len(listing['artifacts'])==listing['total_count']
assert (ROOT/'official-artifacts-list.json').read_bytes()==(ROOT/artifacts['list_record']['stdout']['path']).read_bytes()
matches=[x for x in listing['artifacts'] if x['name']=='playwright-failure-windows-2025']
assert len(matches)==artifacts['matching_artifact_count']==len(artifacts['artifacts'])
artifact_regular_count=0
for item in artifacts['artifacts']:
    raw=(ROOT/item['zip']['path']).read_bytes()
    assert len(raw)==item['zip']['bytes'] and sha(raw)==item['zip']['sha256']
    assert raw==(ROOT/item['zip']['command_stdout']).read_bytes()
    expected_artifact={x['path']:x for x in item['files']}
    with zipfile.ZipFile(ROOT/item['zip']['path']) as zip:
        members=zip.infolist();assert len(members)==item['zip_entry_count'] and zip.testzip() is None
        assert len([m for m in members if not m.is_dir()])==len(expected_artifact)==item['safe_regular_file_count']
        for member in members:
            path=pathlib.PurePosixPath(member.filename)
            assert not path.is_absolute() and '..' not in path.parts and '\\' not in member.filename and '\0' not in member.filename
            assert not stat.S_ISLNK(member.external_attr>>16)
            if member.is_dir():continue
            row=expected_artifact[member.filename];data=zip.read(member)
            assert len(data)==row['bytes'] and sha(data)==row['sha256']
            assert (ROOT/item['extracted_folder']/member.filename).read_bytes()==data
    artifact_regular_count+=len(expected_artifact)
artifact_note=load('windows-artifact-availability.json')
assert artifact_note['official_artifact_total_count']==listing['total_count']
windows_lines=(ROOT/'platform-logs/windows-2025.log').read_text().splitlines()
assert artifact_note['raw_upload_excerpt']==windows_lines[10574:10588]
assert 'No files were found with the provided path: test-results/. No artifacts will be uploaded.' in windows_lines[10587]
summary=load('hosted-ci-summary.json')
assert summary['run_id']==RUN_ID and summary['head_sha']==HEAD and summary['expected_source_tree']==TREE
assert summary['run_status']=='completed' and len(summary['platforms'])==3
assert all(p['job_status']=='completed' and len(p['suite_rows'])==20 for p in summary['platforms'])
assert summary['scope']['native_gui_credit'] is False and summary['scope']['platform_packaging_credit'] is False and summary['scope']['performance_saving_claim'] is False
actual_all_pass=all(p['job_conclusion']=='success' and p['reported_suite_count']==p['reported_suite_pass_count']==20 and p['verification_exit_code']==0 and all(s['state']=='ACTIVE' and s['result']=='PASS' for s in p['suite_rows']) for p in summary['platforms'])
assert actual_all_pass==summary['all_three_hosts_pass']
result={'result':'PASS','scope':'Documentary consistency only, not a product rerun or acceptance decision','raw_record_count_at_audit_start':len(records),'nonzero_or_timeout_records':[r for r in records if r['exit_code']!=0 or r['command_timeout']],'selected_source_blobs_checked':len(source['files']),'additional_failure_source_blobs_checked':len(failure_source['files']),'complete_source_entries_equal':1798,'parent_candidate_and_publication_copies_hash_checked':True,'actual_checkout_trees_match_all_three_hosts':True,'official_zip_regular_members_checked':len(expected),'zip_crc_full_platform_copies_checked':True,'official_failure_artifacts_available':len(artifacts['artifacts']),'official_failure_artifact_members_checked':artifact_regular_count,'actual_empty_artifact_listing_and_upload_no_files_message_bound':True,'collector_wrapper_invocation_error_note':'collector-invocation-error-note.json preserves the observed pre-record invocation error separately; not reconstructed raw stderr.','actual_all_three_host_pass':actual_all_pass,'no_gui_packaging_or_speed_claim':True,'audit_own_record_note':'This audit operation record is written after this process closes; the final finite archive binds it as well.'}
assert not (ROOT/'retained-input-audit.json').exists();(ROOT/'retained-input-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
