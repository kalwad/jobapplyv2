import datetime as dt
import hashlib
import json
import pathlib
import subprocess
import sys
import time

ROOT=pathlib.Path('/tmp/japp-m03-w03-hosted-ci-6d3a6b8-20261019')
REPO='kalwad/jobapplyv2'
HEAD='6d3a6b8ccde5b75e12248ae7bbefc473b72922e4'
TREE='34fcf854cb4a1a452b267a02a05e0c34aeb6f89c'
CANDIDATE=pathlib.Path('/tmp/japp-m03-w03-ci-retry-candidate-20261019/source')
PRIVATE_ROOT=pathlib.Path('/Users/tanishkalwad/jobapplyv2')

def utc():return dt.datetime.now(dt.timezone.utc).isoformat()
def sha(data):return hashlib.sha256(data).hexdigest()

def capture(argv,label):
    folder=ROOT/'commands';folder.mkdir(exist_ok=True)
    number=len(list(folder.glob('*.record.json')))+1
    stem=f'{number:04d}-{label}'
    out=folder/(stem+'.stdout');err=folder/(stem+'.stderr')
    assert not out.exists() and not err.exists()
    started=utc();tick=time.monotonic()
    timed_out=False
    try:
        proc=subprocess.run(argv,cwd=str(ROOT),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
        stdout=proc.stdout;stderr=proc.stderr;code=proc.returncode
    except subprocess.TimeoutExpired as exc:
        timed_out=True;stdout=exc.stdout or b'';stderr=exc.stderr or b'';code=None
    ended=utc();out.write_bytes(stdout);err.write_bytes(stderr)
    row={'argv':argv,'cwd':str(ROOT),'started_at_utc':started,'ended_at_utc':ended,'elapsed_seconds':time.monotonic()-tick,'exit_code':code,'collector_command_timeout':timed_out,'stdout':{'path':str(out.relative_to(ROOT)),'bytes':len(stdout),'sha256':sha(stdout)},'stderr':{'path':str(err.relative_to(ROOT)),'bytes':len(stderr),'sha256':sha(stderr)},'scope':'READ_ONLY_GITHUB_OR_IMMUTABLE_GIT_SOURCE_OR_DOCUMENTARY_ANALYSIS_NO_WORKFLOW_MUTATION_NO_NATIVE_ACTOR'}
    (folder/(stem+'.record.json')).write_text(json.dumps(row,indent=2)+'\n')
    if timed_out or code!=0:raise RuntimeError(f'{label} exit{code} timeout={timed_out}; exact available output retained')
    return stdout,row

def api(endpoint,label):
    raw,row=capture(['/opt/homebrew/bin/gh','api','-H','Accept: application/vnd.github+json',endpoint],label)
    return json.loads(raw),row

def run_id():
    return json.loads((ROOT/'discovered-run.json').read_text())['run_id']

RUN_ID=run_id() if (ROOT/'discovered-run.json').exists() else None

def discover():
    data,row=api(f'repos/{REPO}/actions/runs?head_sha={HEAD}&per_page=100','discover-exact-head-runs')
    matches=[r for r in data['workflow_runs'] if r['head_sha']==HEAD and r['path']=='.github/workflows/ci.yml']
    assert len(matches)==1,[(r['id'],r['status']) for r in matches]
    run=matches[0]
    target=ROOT/'discovered-run.json';assert not target.exists()
    target.write_text(json.dumps({'run_id':run['id'],'run_attempt':run['run_attempt'],'head_sha':HEAD,'expected_tree_sha':TREE,'url':run['html_url'],'discovery_record':row,'scope':'New normally triggered CI run for the pushed6d candidate; no rerun or dispatch performed.'},indent=2)+'\n')
    print(json.dumps({'run_id':run['id'],'status':run['status'],'conclusion':run['conclusion'],'url':run['html_url']},indent=2))

def status():
    identity=run_id()
    run,rr=api(f'repos/{REPO}/actions/runs/{identity}','run-status')
    assert run['id']==identity and run['head_sha']==HEAD
    attempt=run['run_attempt']
    jobs,jr=api(f'repos/{REPO}/actions/runs/{identity}/attempts/{attempt}/jobs?per_page=100',f'jobs-attempt{attempt}')
    assert len(jobs['jobs'])==jobs['total_count']
    snapshot={'observed_at_utc':utc(),'run_id':identity,'run_attempt':attempt,'head_sha':HEAD,'expected_tree_sha':TREE,'run_status':run['status'],'run_conclusion':run['conclusion'],'actual_checkout_sha':None,'actual_checkout_tree':None,'checkout_binding_status':'PENDING_CLOSED_OFFICIAL_FULL_HOST_LOGS_AND_ACTUAL_GIT_OBJECT','run_record':rr,'jobs_record':jr,'jobs':[{'job_id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'started_at':j['started_at'],'completed_at':j['completed_at'],'active_steps':[{k:s.get(k) for k in ['number','name','status','started_at']} for s in j.get('steps',[]) if s['status']=='in_progress']} for j in jobs['jobs']],'scope':'Actual states only. No unobserved suite, performance, GUI, packaging or acceptance result inferred.'}
    path=ROOT/f'snapshot-{len(list(ROOT.glob("snapshot-*.json")))+1:04d}.json';assert not path.exists();path.write_text(json.dumps(snapshot,indent=2)+'\n')
    print(json.dumps({'snapshot':str(path),'run_id':identity,'run_attempt':attempt,'head_sha':HEAD,'status':run['status'],'conclusion':run['conclusion'],'jobs':snapshot['jobs']},indent=2))

if __name__=='__main__':
    assert len(sys.argv)==2 and sys.argv[1] in ['discover','status']
    discover() if sys.argv[1]=='discover' else status()
