import json
from collect_hosted_ci import ROOT,RUN_ID,HEAD,TREE
lines=(ROOT/'platform-logs/windows-2025.log').read_text().splitlines()
listing=json.loads((ROOT/'official-artifacts-list.json').read_text())
assert listing['total_count']==0 and listing['artifacts']==[]
assert 'No files were found with the provided path: test-results/. No artifacts will be uploaded.' in lines[10587]
value={'run_id':RUN_ID,'head_sha':HEAD,'tree_sha':TREE,'official_artifact_total_count':listing['total_count'],'artifact_listing':'official-artifacts-list.json','artifact_manifest':'windows-playwright-artifact-manifest.json','platform_log':'platform-logs/windows-2025.log','upload_excerpt_line_start':10575,'upload_excerpt_line_end':10588,'raw_upload_excerpt':lines[10574:10588],'reported_earlier_failure_output_paths':[r'test-results\extension-extension-resear-8d737-rfaces-pause-without-action-chromium\error-context.md',r'test-results\extension-extension-resear-8d737-rfaces-pause-without-action-chromium\trace.zip'],'reported_paths_are_not_retained_bytes':True,'missing_official_outputs':['error-context.md','trace.zip','screenshot','video'],'cause_of_absent_outputs':'Not inferred from the empty artifact listing or upload no-files message.','scope':'Actual official artifact absence only. The failure footer names context/trace paths; no missing output is reconstructed or treated as captured evidence.'}
assert not (ROOT/'windows-artifact-availability.json').exists()
(ROOT/'windows-artifact-availability.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps({'artifact_total_count':listing['total_count'],'upload_message_bound_to_raw_line':10588,'context_and_trace_bytes_available':False},indent=2))
