import datetime as dt,gzip,io,json,os,pathlib,stat,tarfile
from collect_hosted_ci import ROOT,RUN_ID,HEAD,TREE,sha
OUT=pathlib.Path(str(ROOT)+'-retained')

def read_regular(path):
    before=path.lstat();assert stat.S_ISREG(before.st_mode)
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    try:
        chunks=[]
        while True:
            data=os.read(fd,1024*1024)
            if not data:break
            chunks.append(data)
        after=os.fstat(fd)
    finally:os.close(fd)
    last=path.lstat();key=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    assert key(before)==key(after)==key(last)
    return b''.join(chunks)

def files():
    result=[]
    for path in sorted(ROOT.rglob('*')):
        assert not path.is_symlink()
        if not path.is_file():continue
        name=path.relative_to(ROOT).as_posix()
        if name=='evidence-inputs.json' or '__pycache__' in pathlib.PurePosixPath(name).parts:continue
        assert not pathlib.PurePosixPath(name).is_absolute() and '..' not in pathlib.PurePosixPath(name).parts
        result.append((name,path))
    return result

summary=json.loads((ROOT/'hosted-ci-summary.json').read_text())
assert summary['run_id']==RUN_ID and summary['head_sha']==HEAD and summary['expected_source_tree']==TREE
assert summary['run_status']=='completed' and len(summary['platforms'])==3 and all(p['job_status']=='completed' for p in summary['platforms'])
assert summary['scope']['native_gui_credit'] is False and summary['scope']['platform_packaging_credit'] is False and summary['scope']['performance_saving_claim'] is False
assert json.loads((ROOT/'retained-input-audit.json').read_text())['result']=='PASS'
assert not OUT.exists()
rows=[]
for name,path in files():
    data=read_regular(path);rows.append({'path':name,'bytes':len(data),'sha256':sha(data)})
manifest={'run_id':RUN_ID,'head_sha':HEAD,'expected_source_tree':TREE,'file_count':len(rows),'files':rows,'scope':'Exact finite new6d hosted CI source/metadata/official complete ZIP/full platform logs/raw commands/parent provenance/analysis. Old cancelled run remains distinct. No native GUI, packaging, local result transfer, performance claim or acceptance approval.'}
mb=(json.dumps(manifest,indent=2)+'\n').encode();(ROOT/'evidence-inputs.json').write_bytes(mb)
all_rows=rows+[{'path':'evidence-inputs.json','bytes':len(mb),'sha256':sha(mb)}]
OUT.mkdir();archive=OUT/'proof.tar.gz'
with archive.open('wb') as output:
    with gzip.GzipFile(fileobj=output,filename='',mode='wb',mtime=0,compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT) as tar:
            for row in all_rows:
                data=read_regular(ROOT/row['path']);assert len(data)==row['bytes'] and sha(data)==row['sha256']
                info=tarfile.TarInfo(row['path']);info.size=len(data);info.mode=0o644;info.uid=0;info.gid=0;info.uname='';info.gname='';info.mtime=0
                tar.addfile(info,io.BytesIO(data))
assert [p[0] for p in files()]==[r['path'] for r in rows]
for row in all_rows:
    data=read_regular(ROOT/row['path']);assert len(data)==row['bytes'] and sha(data)==row['sha256']
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers();assert len(members)==len(all_rows)==len({m.name for m in members})
    expected={r['path']:r for r in all_rows}
    for member in members:
        assert member.isfile() and member.name in expected
        data=tar.extractfile(member).read();row=expected[member.name]
        assert len(data)==row['bytes'] and sha(data)==row['sha256']
data=archive.read_bytes()
outer={'archive':'proof.tar.gz','bytes':len(data),'sha256':sha(data),'regular_members':len(all_rows),'input_manifest_sha256':sha(mb),'run_id':RUN_ID,'head_sha':HEAD,'expected_source_tree':TREE,'actual_conclusion':summary['run_conclusion'],'actual_all_three_hosts_pass':summary['all_three_hosts_pass'],'captured_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'scope':'New6d source-bound actual hosted CI only; no GUI, packaging or speed/acceptance claim.'}
(OUT/'manifest.json').write_text(json.dumps(outer,indent=2)+'\n')
print(json.dumps(outer,indent=2))
