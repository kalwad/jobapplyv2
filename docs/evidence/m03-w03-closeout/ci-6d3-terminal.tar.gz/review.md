# Hosted CI 39188122249: FAILURE

Exact published head `6d3a6b8ccde5b75e12248ae7bbefc473b72922e4`, tree `34fcf854cb4a1a452b267a02a05e0c34aeb6f89c`. All three actual closed checkout content trees match the complete remote/candidate1798-entry source.

| Host | Job | Actual terminal suites | Python execution | Native desktop feature modes |
|---|---|---|---|---|
| ubuntu-24.04 | success | 20/20 reported PASS; verifier exit 0 | 1653 passed | 76/76/76 |
| windows-2025 | failure | 19/20 reported PASS; verifier exit 1 | 1651 passed | 70/70/70 |
| macos-15 | success | 20/20 reported PASS; verifier exit 0 | 1653 passed | 77/77/77 |

Every terminal suite row, actual counts, raw timestamp/line references, strict Clippy block, native feature mode and temp declaration are in hosted-ci-summary.json. Absent results remain unreported. Direct child exit0 values are not printed: completed Rust command exit0 is explicitly inferred from the frozen stop-on-nonzero sequence or final Rust PASS.

The new workflow emits TMPDIR/TEMP/TMP for doctor and verify. Actual declared paths are retained. There is no explicit Python gettempdir or physical-volume benchmark, and no causal speed claim. Root/candidate source equivalence, source publication history and the initial private d28 observation remain separate records.

The full official logs.zip, all safely extracted member hashes and complete platform logs are retained. This packet is distinct from cancelled run39181477863 and cannot relabel it. No prior local result, native GUI, packaging, Windows11 or Ubuntu default-GNOME certification is transferred.

Windows default Playwright reports 255 passed and one failed (13.7m). The WD1–WD10/XATS research case at extension-research.spec.ts:585 fails during fixture cleanup: AggregateError EXTENSION_CONTEXT_CLEANUP_FAILED contains an already-closed browserContext.close error and an EPERM removal error for D:\a\_temp\japp-m02-w07-profile-kUL6PB. Exact raw lines and the two immutable source blobs are retained. No flake or timeout cause is inferred.

Official artifact listing returned total_count 0. The actual Windows upload step says no files were found in test-results/ and no artifacts would be uploaded. The earlier test footer names an error-context.md and trace.zip, but their bytes, screenshots and video are unavailable from this run's official artifacts. windows-artifact-availability.json binds both observations without reconstructing missing outputs.

Windows aggregate integrity is ACTIVE PASS, while the standalone step26 “Assert verification left no tracked changes” is SKIPPED after verifier exit1. That step succeeds on Ubuntu and macOS. Every host's extension target payload has only one sample; macOS emits 2426.769916ms. The frozen performance assertion applies to 20-sample Darwin runs, so these hosted payloads provide no canonical 20-sample performance validation.
