import hashlib,json,os,stat
from collect_hosted_ci import ROOT,PRIVATE_ROOT,HEAD,TREE,capture,utc

before,br=capture(['/usr/bin/git','-C',str(PRIVATE_ROOT),'rev-parse','HEAD','HEAD^{tree}'],'private-root-head-before-equivalence')
candidate=json.loads((ROOT/'candidate-working-source-binding.json').read_text())
matches=[];differences=[]
for row in candidate['files']:
    path=PRIVATE_ROOT/row['path']
    if not path.exists():
        differences.append({'path':row['path'],'reason':'missing'});continue
    start=path.lstat()
    if not stat.S_ISREG(start.st_mode):
        differences.append({'path':row['path'],'reason':'not regular'});continue
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    digest=hashlib.sha256()
    try:
        while True:
            data=os.read(fd,1024*1024)
            if not data:break
            digest.update(data)
        end=os.fstat(fd)
    finally:os.close(fd)
    final=path.lstat();key=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    stable=key(start)==key(end)==key(final)
    item={'path':row['path'],'bytes':final.st_size,'sha256':digest.hexdigest(),'stable_read':stable}
    if not stable or final.st_size!=row['bytes'] or digest.hexdigest()!=row['sha256']:differences.append(item)
    else:matches.append(item)
after,ar=capture(['/usr/bin/git','-C',str(PRIVATE_ROOT),'rev-parse','HEAD','HEAD^{tree}'],'private-root-head-after-equivalence')
result={'observed_at_utc':utc(),'expected_published_head':HEAD,'expected_published_tree':TREE,'private_root_head_tree_before':before.decode().splitlines(),'private_root_head_tree_after':after.decode().splitlines(),'head_tree_stable':before==after,'head_tree_matches_published_candidate':before.decode().splitlines()==after.decode().splitlines()==[HEAD,TREE],'expected_tracked_file_count':len(candidate['files']),'matching_actual_tracked_files':len(matches),'differences':differences,'all_expected_tracked_bytes_equal_candidate':not differences,'records':[br,ar],'scope':'Read-only later private-root transition/source equivalence, distinct from authoritative candidate-owned source binding. Does not claim absence of untracked/ignored files or performance/native behavior. Earlier d28 observations remain historical.'}
path=ROOT/f'private-root-source-equivalence-{len(list(ROOT.glob("private-root-source-equivalence-*.json")))+1:02d}.json';assert not path.exists();path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['observed_at_utc','private_root_head_tree_before','private_root_head_tree_after','head_tree_matches_published_candidate','matching_actual_tracked_files','all_expected_tracked_bytes_equal_candidate','differences']},indent=2))
