import datetime as dt,json,subprocess,sys,time
from collect_hosted_ci import ROOT,sha
assert len(sys.argv)>=4
label=sys.argv[1];argv=sys.argv[2:]
folder=ROOT/'operations';folder.mkdir(exist_ok=True)
stem=f'{len(list(folder.glob("*.record.json")))+1:04d}-{label}'
started=dt.datetime.now(dt.timezone.utc).isoformat();tick=time.monotonic()
proc=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
record={'argv':argv,'cwd':str(ROOT),'started_at_utc':started,'ended_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-tick,'exit_code':proc.returncode,'scope':'DOCUMENTARY_SOURCE_METADATA_LOG_EXTRACTION_OR_ANALYSIS_ONLY_NO_NATIVE_OR_TEST_ACTOR'}
for stream,data in [('stdout',proc.stdout),('stderr',proc.stderr)]:
 path=folder/(stem+'.'+stream);assert not path.exists();path.write_bytes(data);record[stream]={'path':str(path.relative_to(ROOT)),'bytes':len(data),'sha256':sha(data)}
(folder/(stem+'.record.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
if proc.stdout:print(proc.stdout.decode(errors='replace')[:14000])
if proc.stderr:print(proc.stderr.decode(errors='replace')[:14000],file=sys.stderr)
raise SystemExit(proc.returncode)
