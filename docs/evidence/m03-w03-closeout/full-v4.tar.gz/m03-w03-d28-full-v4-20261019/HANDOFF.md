# Fresh local W03 FULL v4 retained evidence

This packet retains only the newly completed local macOS verification at clean
d28cfc70feda604c508bc18c778992a0ca559e5a / e72a0523d4b3183b5a658ccd74ce02a8dbd4b8e8
and its independent data review. It introduces no new product/test execution.

The original doctor and full verify commands both exited zero. The complete
649,359-byte raw verify log has SHA-256
971a64645160aa16687ac75900ce265b183d722167ff14301f57f44da31b74bd.
The independent review reports all 65 data checks clear: 20 ACTIVE PASS suites,
1,650 ordinary Python tests and unchanged 1,797-file source. Its original
reports, all 48 retained input copies, 1,807 input bindings, parsed raw blocks,
source/inventory manifests, exact wrapper and two reviewer premise errors are
preserved unchanged. Historical paths and scopes remain inside original bytes.

Missing evidence remains explicit: there is no separate retained outer-wrapper
invocation/exit transcript, and no complete archive of the inherited environment
or final PATH. The exact wrapper, sole HEAD-argument guard, original child argv,
logs, exit/timing receipts, clearing/isolation source and version probes remain.
No missing transcript or environment evidence is reconstructed or implied.

This is local full verification evidence, not current hosted CI success, current
native GUI/signing/OS trust, target20, Gate A, holdout, pilot, W03 acceptance or
cross-platform certification. Prior actual native cases, current v4 NOT_EXECUTED
records and their separate applicability review retain their own scopes.

selection.json maps original paths to content-addressed full local copies and
records exact source SHA-256, length and mode. Every selected byte is included in
the complete small remote tar; no selected omission exists. The already-retained
347,514,880-byte source archive is referenced, not duplicated. No full toolchain,
dependency/cache directory, unrelated old packet or incomplete CI record is added.

The collection source and HANDOFF are frozen. retention-manifest.json hashes all
durable payloads except itself; the adjacent archive manifest binds every safe
regular tar member, each of which was read back. Root tracked content, Git
identity and clean status are equal before/after/final. Root and sealed originals
were never written by this collector. A different reviewer can assess the packet.
