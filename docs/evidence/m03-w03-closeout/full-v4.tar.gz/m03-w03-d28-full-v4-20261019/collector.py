"""Standalone archival collector: standard-library file/Git reads only."""
from pathlib import Path, PurePosixPath
import datetime
import gzip
import hashlib
import io
import json
import shutil
import stat
import subprocess
import tarfile
import traceback

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
OUT = Path('/tmp/japp-m03-w03-full-v4-retained-20261019')
STORE = Path('/Users/tanishkalwad/jobapplyv2-evidence/m03-w03-d28-full-v4-20261019')
RUN = Path('/tmp/japp-m03-w03-clean-verification-v4-20261019')
WRAPPER = Path('/tmp/japp-m03-w03-clean-verify-v4.py')
REVIEW = Path('/tmp/japp-m03-w03-independent-full-v4-data-review-20261019')
PREFIX = 'm03-w03-d28-full-v4-20261019'
HEAD = 'd28cfc70feda604c508bc18c778992a0ca559e5a'
TREE = 'e72a0523d4b3183b5a658ccd74ce02a8dbd4b8e8'
LOG = '971a64645160aa16687ac75900ce265b183d722167ff14301f57f44da31b74bd'
EXPECTED = {'REVIEW.md': 'f291706de666f3b55d4b8031f7452951452505fccaf5e579d54a133d61e3b763', 'findings.json': 'ee3129aa818f343cda77bcda32f12090ccc1284795bb9e686d1b8bf42d9cace1', 'retention-manifest.json': 'c985da2960d47a36105e7cc9cb1cfa5cf52d832072ab1cd3297ae96faa422383'}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def safe(name):
    p = PurePosixPath(name)
    assert name and not p.is_absolute() and '..' not in p.parts and '\\' not in name, name
    return p

def tracked():
    raw = subprocess.run(['git', 'ls-files', '--stage', '-z'], cwd=ROOT, capture_output=True, check=True).stdout
    records = []
    for row in raw.split(b'\0'):
        if not row:
            continue
        header, name = row.split(b'\t', 1)
        mode, blob, stage = header.decode().split()
        path = ROOT / name.decode()
        info = path.lstat()
        assert stat.S_ISREG(info.st_mode)
        records.append({'path': name.decode(), 'git_mode': mode, 'git_blob': blob, 'stage': stage, 'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode), 'sha256': digest(path)})
    return {'head': subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=ROOT, capture_output=True, check=True, text=True).stdout.strip(), 'tree': subprocess.run(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, capture_output=True, check=True, text=True).stdout.strip(), 'status': subprocess.run(['git', 'status', '--porcelain=v1'], cwd=ROOT, capture_output=True, check=True, text=True).stdout, 'tracked': records}

def main():
    assert not STORE.exists()
    before = tracked()
    assert before['head'] == HEAD and before['tree'] == TREE and before['status'] == '' and len(before['tracked']) == 1797
    dump(OUT / 'tracked-before.json', before)
    STORE.mkdir()
    (STORE / 'blobs').mkdir()
    selected = {}

    def select(path, role, expected=None, length=None):
        assert path.is_absolute()
        info = path.lstat()
        assert stat.S_ISREG(info.st_mode), str(path)
        observed = digest(path)
        assert expected is None or observed == expected, str(path)
        assert length is None or info.st_size == length, str(path)
        assert info.st_size < 4 * 1024 * 1024, 'Unexpected large input; no partial selection: ' + str(path)
        blob = STORE / 'blobs' / observed
        if not blob.exists():
            shutil.copyfile(path, blob)
            assert digest(blob) == observed
        name = str(path)
        if name in selected:
            assert selected[name]['sha256'] == observed
            if role not in selected[name]['roles']:
                selected[name]['roles'].append(role)
        else:
            selected[name] = {'original': name, 'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode), 'mode_octal': oct(stat.S_IMODE(info.st_mode)), 'sha256': observed, 'roles': [role], 'durable_relative': 'blobs/' + observed}

    original_files = sorted(path for path in RUN.iterdir() if path.is_file())
    assert len(original_files) == 8 and not any(path.is_dir() for path in RUN.iterdir())
    for path in original_files:
        select(path, 'newly-closed-fresh-local-full-v4-original-record')
    assert digest(RUN / 'verify.log') == LOG
    assert (RUN / 'verify.log').stat().st_size == 649359
    select(WRAPPER, 'actual-outer-wrapper-source')
    assert WRAPPER.read_bytes() == (RUN / 'executed-wrapper.py').read_bytes()
    for name, expected in EXPECTED.items():
        assert digest(REVIEW / name) == expected, name
    review_manifest = json.loads((REVIEW / 'retention-manifest.json').read_text())
    for row in review_manifest['records']:
        safe(row['path'])
        select(REVIEW / row['path'], 'independent-review-sealed-member', row['sha256'], row['bytes'])
    for path in sorted(REVIEW.rglob('*')):
        assert not path.is_symlink(), str(path)
        if path.is_file():
            select(path, 'complete-independent-data-review-original')
    bindings = json.loads((REVIEW / 'input-retention.json').read_text())['records']
    assert len(bindings) == 1807
    root_map = {str(ROOT / row['path']): row for row in before['tracked']}
    copied_inputs = 0
    for row in bindings:
        path = Path(row['path'])
        if str(path) in root_map:
            actual = root_map[str(path)]
            assert actual['sha256'] == row['sha256'] and actual['bytes'] == row['bytes']
        else:
            assert digest(path) == row['sha256'] and path.stat().st_size == row['bytes'], str(path)
        if row.get('retained_copy'):
            safe(row['retained_copy'])
            select(REVIEW / row['retained_copy'], 'independent-input-chain-copy', row['sha256'], row['bytes'])
            copied_inputs += 1
    assert copied_inputs == 48
    findings = json.loads((REVIEW / 'findings.json').read_text())
    assert findings['independent_checks'] == findings['passed_checks'] == 65
    assert findings['verify']['active_pass_suites'] == 20 and findings['ordinary_counts']['python_actual'] == 1650
    assert json.loads((RUN / 'before.json').read_text()) == json.loads((RUN / 'after.json').read_text())
    assert json.loads((RUN / 'closure.json').read_text())['all_executed_commands_pass'] is True
    commands = json.loads((RUN / 'commands.json').read_text())
    assert [row['argv'] for row in commands] == [['pnpm', 'run', 'doctor'], ['pnpm', 'verify']]
    assert all(row['exit_code'] == 0 for row in commands)
    for row in commands:
        log = RUN / (row['name'] + '.log')
        assert digest(log) == row['log_sha256'] and log.stat().st_size == row['log_bytes']
    source_archive = Path('/Users/tanishkalwad/jobapplyv2-evidence/m03-w03-d28-v4-build-applicability-20261019/blobs/620e7c6a113894c597673448615639dc831edca6d8959dcfdef9a61e717470c2')
    assert source_archive.stat().st_size == 347514880 and digest(source_archive) == source_archive.name
    dump(STORE / 'already-retained-source-reference.json', {'scope': 'REFERENCE_ONLY_NO_LARGE_SOURCE_ARCHIVE_DUPLICATED', 'source_commit': HEAD, 'source_tree': TREE, 'durable_archive': str(source_archive), 'archive_bytes': source_archive.stat().st_size, 'archive_sha256': source_archive.name, 'root_source_binding': 'Independent root-source-bindings and immutable Git tree retain all 1797 file identities.', 'not_copied': ['already-retained 347514880-byte root source archive', 'full build toolchain', 'Cargo/node/venv caches'], 'no_execution_or_build_applicability_inference': True})
    after = tracked()
    assert after == before
    dump(OUT / 'tracked-after.json', after)
    dump(STORE / 'tracked-before.json', before)
    dump(STORE / 'tracked-after.json', after)
    dump(STORE / 'selection.json', {'scope': 'ONLY_NEWLY_CLOSED_LOCAL_FULL_V4_AND_ITS_INDEPENDENT_REVIEW_INPUT_CHAIN', 'records': sorted(selected.values(), key=lambda row: row['original'])})
    shutil.copyfile(Path(__file__), STORE / 'collector.py')
    dump(STORE / 'invocation.json', {'argv': [str(Path(__file__))], 'collector_sha256': digest(Path(__file__)), 'started_at_utc': STARTED, 'scope': 'ARCHIVAL_ONLY_READ_HASH_COPY_ARCHIVE_GIT_IDENTITY_NO_PROJECT_IMPORTS_OR_ACTORS'})
    dump(STORE / 'collection-checks.json', {'original_run_files': 8, 'original_raw_verify_log_sha256': LOG, 'actual_wrapper_and_executed_copy_identical': True, 'independent_review_expected_three_endpoint_hashes_verified': EXPECTED, 'independent_input_bindings_rechecked': 1807, 'retained_independent_input_copies': 48, 'all_1797_tracked_entries_head_tree_and_clean_status_neutral': True, 'large_source_archive_not_duplicated': True, 'collector_failure_count': 0})
    (STORE / 'HANDOFF.md').write_text('''# Fresh local W03 FULL v4 retained evidence

This packet retains only the newly completed local macOS verification at clean
d28cfc70feda604c508bc18c778992a0ca559e5a / e72a0523d4b3183b5a658ccd74ce02a8dbd4b8e8
and its independent data review. It introduces no new product/test execution.

The original doctor and full verify commands both exited zero. The complete
649,359-byte raw verify log has SHA-256
971a64645160aa16687ac75900ce265b183d722167ff14301f57f44da31b74bd.
The independent review reports all 65 data checks clear: 20 ACTIVE PASS suites,
1,650 ordinary Python tests and unchanged 1,797-file source. Its original
reports, all 48 retained input copies, 1,807 input bindings, parsed raw blocks,
source/inventory manifests, exact wrapper and two reviewer premise errors are
preserved unchanged. Historical paths and scopes remain inside original bytes.

Missing evidence remains explicit: there is no separate retained outer-wrapper
invocation/exit transcript, and no complete archive of the inherited environment
or final PATH. The exact wrapper, sole HEAD-argument guard, original child argv,
logs, exit/timing receipts, clearing/isolation source and version probes remain.
No missing transcript or environment evidence is reconstructed or implied.

This is local full verification evidence, not current hosted CI success, current
native GUI/signing/OS trust, target20, Gate A, holdout, pilot, W03 acceptance or
cross-platform certification. Prior actual native cases, current v4 NOT_EXECUTED
records and their separate applicability review retain their own scopes.

selection.json maps original paths to content-addressed full local copies and
records exact source SHA-256, length and mode. Every selected byte is included in
the complete small remote tar; no selected omission exists. The already-retained
347,514,880-byte source archive is referenced, not duplicated. No full toolchain,
dependency/cache directory, unrelated old packet or incomplete CI record is added.

The collection source and HANDOFF are frozen. retention-manifest.json hashes all
durable payloads except itself; the adjacent archive manifest binds every safe
regular tar member, each of which was read back. Root tracked content, Git
identity and clean status are equal before/after/final. Root and sealed originals
were never written by this collector. A different reviewer can assess the packet.
''')
    payload = [{'path': str(path.relative_to(STORE)), 'bytes': path.stat().st_size, 'mode': 0o444, 'sha256': digest(path)} for path in sorted(STORE.rglob('*')) if path.is_file()]
    dump(STORE / 'retention-manifest.json', {'scope': 'EXHAUSTIVE_DURABLE_PAYLOAD_EXCEPT_THIS_MANIFEST', 'files': payload})
    members = [{'path': str(path.relative_to(STORE)), 'bytes': path.stat().st_size, 'mode': 0o444, 'sha256': digest(path)} for path in sorted(STORE.rglob('*')) if path.is_file()]
    archive_path = OUT / 'full-v4-selected.tar.gz'
    with archive_path.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
                for row in members:
                    safe(row['path'])
                    info = tarfile.TarInfo(PREFIX + '/' + row['path'])
                    info.size = row['bytes']
                    info.mode = row['mode']
                    info.mtime = info.uid = info.gid = 0
                    info.uname = info.gname = ''
                    with (STORE / row['path']).open('rb') as stream:
                        archive.addfile(info, stream)
    assert archive_path.stat().st_size < 15 * 1024 * 1024
    expected = {PREFIX + '/' + row['path']: row for row in members}
    seen = set()
    with tarfile.open(archive_path, 'r:gz') as archive:
        for member in archive.getmembers():
            safe(member.name)
            assert member.isfile() and not member.issym() and not member.islnk()
            assert member.name not in seen and member.name in expected
            seen.add(member.name)
            stream = archive.extractfile(member)
            assert stream is not None
            data = stream.read()
            row = expected[member.name]
            assert len(data) == row['bytes'] and sha(data) == row['sha256'] and member.mode == row['mode']
    assert seen == set(expected)
    for row in payload:
        path = STORE / row['path']
        assert path.stat().st_size == row['bytes'] and digest(path) == row['sha256']
    final = tracked()
    assert final == before
    dump(OUT / 'tracked-final.json', final)
    result = {'scope': 'SELECTED_COMPLETED_FRESH_LOCAL_FULL_V4_AND_INDEPENDENT_DATA_REVIEW_ONLY', 'durable': str(STORE), 'archive': str(archive_path), 'archive_bytes': archive_path.stat().st_size, 'archive_sha256': digest(archive_path), 'member_count': len(members), 'selected_original_paths': len(selected), 'unique_blobs': len(list((STORE / 'blobs').iterdir())), 'all_selected_bytes_remotely_included': True, 'selected_omissions': [], 'complete_tar_and_durable_readback': True, 'duplicate_missing_unsafe_nonregular_member_count': 0, 'manifest_sha256': digest(STORE / 'retention-manifest.json'), 'selection_sha256': digest(STORE / 'selection.json'), 'handoff_sha256': digest(STORE / 'HANDOFF.md'), 'collector_sha256': digest(Path(__file__)), 'tracked_before_after_final_identical': True, 'tracked_snapshot_sha256': digest(OUT / 'tracked-before.json'), 'limitations': findings['limitations']}
    dump(OUT / 'full-v4-selected.manifest.json', {**result, 'members': members})
    dump(OUT / 'collection-result.json', result)
    for path in STORE.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            path.chmod(0o444)
    for path in sorted((p for p in STORE.rglob('*') if p.is_dir()), key=lambda p: len(p.parts), reverse=True):
        path.chmod(0o555)
    STORE.chmod(0o555)
    for row in payload:
        assert stat.S_IMODE((STORE / row['path']).stat().st_mode) == row['mode']
    for path in OUT.iterdir():
        if path.is_file():
            path.chmod(0o444)
    print(json.dumps(result, indent=2), flush=True)

STARTED = datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
    main()
except BaseException as error:
    dump(OUT / 'collector-failure.json', {'scope': 'ARCHIVAL_COLLECTOR_PREMISE_FAILURE_NOT_PRODUCT_RUN', 'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc(), 'collector_sha256': digest(Path(__file__))})
    raise
