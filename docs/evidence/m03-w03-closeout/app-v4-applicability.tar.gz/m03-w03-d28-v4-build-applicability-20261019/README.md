# Selected v4 W03 build and applicability evidence

This is BUILD/APPLICABILITY retention, not current native execution or acceptance.
All current canonical close/quit/forced cases are PREPARED / NOT_EXECUTED; close
was blocked by the locked Mac before any actor. The original invalid force config
and separate owned-force correction receipt remain verbatim. New contained and
escaped v4 fixtures are built, not executed. Prior actual cases remain cac56.

The original independent reports support logical shipping-software path
applicability only. They do not prove current GUI execution, signing, OS launch
trust, full Windows success, full verification, hosted CI success, or W03 PASS.
No running full/CI artifacts were selected as completed proof.

selection.json preserves original absolute paths, byte SHA-256, length and mode.
blobs/ content-addresses every selected file, deduplicating archives/app/runtime
copies. The complete six 42-file actual/upfront app sets and five 40-file runtime
stages are listed separately. Canonical archive 620e7c6a... is retained locally
once at its full 347,514,880 bytes. Selected large build tools are local copies;
this is not a full archival copy of the build toolchain, caches or dependencies.

The remote tar omits EVERY blob over 4 MiB. remote-omissions.json lists each
omission, every source alias, and the full durable local copy. No 350 MB source
archive, full current main binary, or large tool/runtime blob enters that tar.
The sparse byte delta plus the old full binary in the Git-retained cac56 packet
reconstructs current canonical main a1d7a5... exactly in memory. This is data
reconstruction only: it executes neither binary and makes no signature or OS
launch claim. The independent Mach-O category report is preserved unchanged;
the collector separately verifies 2,493 changed bytes and whole-file identities.

All original records, historical scopes and paths are preserved unchanged.
HANDOFF, collectors and collector premise error records are retained as data.
The collector imported no project/helper module and ran no product/test actor.
The full 1,797 tracked Git entries, HEAD/tree and clean status were neutral.
retention-manifest.json hashes all local payload files except itself; the
adjacent remote archive manifest exhaustively hashes every safe regular member.
