"""Selected read/hash/copy/archive retention only; never import project code."""
from pathlib import Path, PurePosixPath
import datetime
import gzip
import hashlib
import io
import json
import os
import shutil
import stat
import subprocess
import tarfile
import traceback

OUT = Path('/tmp/japp-m03-w03-v4-build-applicability-retained-20261019')
STORE = Path('/Users/tanishkalwad/jobapplyv2-evidence/m03-w03-d28-v4-build-applicability-20261019')
ROOT = Path('/Users/tanishkalwad/jobapplyv2')
BUILD = Path('/tmp/japp-m03-w03-root-app-build-v4-20261019')
FIX = Path('/tmp/japp-m03-w03-root-fixture-apps-v4-20261019')
OLD = Path('/Users/tanishkalwad/jobapplyv2-evidence/m03-w03-cac56-native-20261019/blobs/d484086d9ad3a6cd24b0e0e6c8abeb17136142c2b1c8e4befdbc8cfbdc414ae2')
OLD_SHA = OLD.name
NEW_SHA = 'a1d7a5a54bcda473e6b26a6f572ebf012ec59331996d170c40769796514ffeea'
ARCHIVE_SHA = '620e7c6a113894c597673448615639dc831edca6d8959dcfdef9a61e717470c2'
LIMIT = 4 * 1024 * 1024
PREFIX = 'm03-w03-d28-v4-build-applicability-20261019'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def dump(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')

def safe(name):
    p = PurePosixPath(name)
    assert name and not p.is_absolute() and '..' not in p.parts and '\\' not in name, name
    return p

def tracked():
    entries = []
    raw = subprocess.run(['git', 'ls-files', '--stage', '-z'], cwd=ROOT, check=True, capture_output=True).stdout
    for row in raw.split(b'\0'):
        if not row:
            continue
        header, name = row.split(b'\t', 1)
        mode, blob, stage = header.decode().split()
        path = ROOT / name.decode()
        metadata = path.lstat()
        assert stat.S_ISREG(metadata.st_mode)
        entries.append({'path': name.decode(), 'git_mode': mode, 'git_blob': blob, 'stage': stage, 'mode': stat.S_IMODE(metadata.st_mode), 'bytes': metadata.st_size, 'sha256': digest(path)})
    return {'head': subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=ROOT, check=True, capture_output=True, text=True).stdout.strip(), 'tree': subprocess.run(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, check=True, capture_output=True, text=True).stdout.strip(), 'status_porcelain_hex': subprocess.run(['git', 'status', '--porcelain=v1', '-z'], cwd=ROOT, check=True, capture_output=True).stdout.hex(), 'tracked_count': len(entries), 'entries': entries}

selected = {}
checks = []
appsets = []
stages = []

def select(path, role, expected_sha=None, expected_bytes=None):
    name = str(path)
    assert path.is_absolute(), name
    record = selected.setdefault(name, {'source': name, 'roles': [], 'expectations': []})
    if role not in record['roles']:
        record['roles'].append(role)
    expectation = {'sha256': expected_sha, 'bytes': expected_bytes}
    if expectation not in record['expectations']:
        record['expectations'].append(expectation)

def top(root, role):
    assert root.is_dir(), str(root)
    for path in sorted(root.iterdir()):
        if path.is_file() and not path.is_symlink():
            select(path, role)

def all_regular(root, role):
    assert root.is_dir(), str(root)
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink(), str(path)
        if path.is_file():
            select(path, role)

def manifest(root, filename, role):
    path = root / filename
    data = json.loads(path.read_text())
    rows = data.get('files', data.get('records'))
    assert isinstance(rows, list), str(path)
    select(path, role + ':manifest')
    for row in rows:
        original = Path(row['path'])
        if not original.is_absolute():
            safe(row['path'])
            original = root / original
        select(original, role, row.get('sha256'), row.get('bytes'))
    return len(rows)

def appset(root, tree, role):
    assert len(tree) == 42
    actual = [p for p in root.rglob('*') if p.is_file()]
    assert len(actual) == 42 and not any(p.is_symlink() for p in root.rglob('*'))
    rows = []
    for relative, record in sorted(tree.items()):
        safe(relative)
        path = root / relative
        select(path, role, record['sha256'], record['bytes'])
        rows.append({'relative': relative, 'source': str(path), **record})
    appsets.append({'role': role, 'root': str(root), 'file_count': 42, 'files': rows, 'runtime_observation': 'NOT_EXECUTED_V4'})

def stage(root, role, tree=None):
    paths = [p for p in root.rglob('*') if p.is_file()]
    assert len(paths) == 40 and not any(p.is_symlink() for p in root.rglob('*'))
    rows = []
    for path in sorted(paths):
        relative = str(path.relative_to(root))
        expected = tree[relative] if tree is not None else {}
        select(path, role, expected.get('sha256'), expected.get('bytes'))
        rows.append({'relative': relative, 'source': str(path)})
    assert (root / 'manifest.json').is_file()
    stages.append({'role': role, 'root': str(root), 'file_count_including_manifest': 40, 'files': rows})

def collect():
    assert not STORE.exists(), str(STORE)
    STORE.mkdir()
    (STORE / 'blobs').mkdir()
    before = json.loads((OUT / 'tracked-before.json').read_text())
    assert before['head'] == 'd28cfc70feda604c508bc18c778992a0ca559e5a' and before['tree'] == 'e72a0523d4b3183b5a658ccd74ce02a8dbd4b8e8'
    assert before['tracked_count'] == 1797 and before['status_porcelain_hex'] == ''
    top(BUILD, 'canonical-build-receipts')
    all_regular(BUILD / 'descriptors', 'canonical-generated-descriptors')
    canonical = json.loads((BUILD / 'app.json').read_text())
    canonical_tree = json.loads((BUILD / 'app-tree.json').read_text())
    canonical_app = Path(canonical['path'])
    appset(canonical_app, canonical_tree, 'canonical-actual-app-build-NOT_EXECUTED')
    appset(BUILD / 'app-upfront/Desktop App.app', canonical_tree, 'canonical-upfront-app-copy-NOT_EXECUTED')
    stage(ROOT / 'apps/desktop/src-tauri/runtime-payload', 'canonical-stage-39-plus-manifest', json.loads((BUILD / 'runtime-stage-before.json').read_text()))
    for operation in ('close', 'quit', 'forced'):
        case = Path('/tmp/japp-m03-w03-canonical-' + operation + '-v4-20261019')
        top(case, 'canonical-' + operation + '-PREPARED-NOT_EXECUTED')
        all_regular(case / 'retained', 'canonical-' + operation + '-upfront-retained-inputs-NOT_EXECUTED')
    assert manifest(FIX, 'artifact-retention.json', 'fixture-frozen-425-bindings') == 425
    assert manifest(FIX, 'retention-manifest.json', 'fixture-frozen-handoff-bindings') == 11
    top(FIX, 'fixture-top-level-build-receipts')
    for directory in ('upfront-build-inputs', 'upfront-v4-source-binding', 'serial-commands'):
        all_regular(FIX / directory, 'fixture-' + directory)
    for kind in ('contained', 'escaped'):
        base = FIX / kind
        top(base, kind + '-case-build-receipts-NOT_EXECUTED')
        top(base / 'native-build', kind + '-native-build-top-receipts')
        all_regular(base / 'fixture-input', kind + '-fixture-preparation-input')
        config = json.loads((base / 'case-config.json').read_text())
        app = Path(config['artifacts']['app']['path']).parents[2]
        tree = json.loads((base / 'app-upfront-tree.json').read_text())
        appset(app, tree, kind + '-actual-app-build-NOT_EXECUTED')
        appset(base / 'app-upfront/Desktop App.app', tree, kind + '-upfront-app-copy-NOT_EXECUTED')
        stage(base / 'repo/apps/desktop/src-tauri/runtime-payload', kind + '-repo-stage-39-plus-manifest')
        stage(base / 'native-build/runtime-stage', kind + '-native-stage-39-plus-manifest')
        marker = Path(config['fixture_marker'])
        assert not marker.exists(), str(marker)
        checks.append({'check': kind + '-current-marker-absent', 'path': str(marker), 'absent': True, 'meaning': 'No current execution claim; frozen handoff retains preparation state.'})
    for name in ('independent-v4-build-applicability-review', 'independent-v4-fixture-path-applicability-addendum', 'independent-clippy-root-adoption'):
        directory = Path('/tmp/japp-m03-w03-' + name + '-20261019')
        top(directory, name + '-original-records')
        manifest(directory, 'retention-manifest.json', name + '-retained-inputs')
    for name in ('clippy-root-adoption-20261019', 'precommit-checks-20261019', 'precommit-checks-corrected-20261019', 'root-adoption-20261018', 'mode-root-adoption-20261018', 'source-check-receipts-v2-20261018'):
        top(Path('/tmp/japp-m03-w03-' + name), 'selected-focused-and-precommit-receipts:' + name)
    helpers = Path('/tmp/japp-m03-w03-root-lifecycle-proof-tools-correction')
    top(helpers, 'reviewed-helper-source-requirements-and-handoff')
    manifest(helpers, 'retention-manifest.json', 'reviewed-helper-exact-retained-inputs')
    # Select canonical artifact/wheel inputs from the exact prepared config.
    for record in json.loads((BUILD / 'close-input.json').read_text())['artifacts'].values():
        select(Path(record['path']), 'canonical-declared-artifact-input', record['sha256'])
    old_tar = ROOT / 'docs/evidence/m03-w03-lifecycle/native-cac56-selected.tar.gz'
    git_record = subprocess.run(['git', 'ls-tree', 'HEAD', '--', str(old_tar.relative_to(ROOT))], cwd=ROOT, check=True, capture_output=True, text=True).stdout.strip()
    assert git_record
    git_blob = git_record.split()[2]
    assert subprocess.run(['git', 'hash-object', str(old_tar)], cwd=ROOT, check=True, capture_output=True, text=True).stdout.strip() == git_blob
    old_data = OLD.read_bytes()
    new_data = Path(canonical['main_executable']).read_bytes()
    assert sha(old_data) == OLD_SHA and sha(new_data) == NEW_SHA
    assert len(old_data) == len(new_data) == 31553552
    with tarfile.open(old_tar, 'r:gz') as archive:
        matches = [member for member in archive.getmembers() if member.name.endswith('/blobs/' + OLD_SHA) or member.name == 'blobs/' + OLD_SHA]
        assert len(matches) == 1 and matches[0].isfile()
        source = archive.extractfile(matches[0])
        assert source is not None and source.read() == old_data
        old_member = matches[0].name
    dump(STORE / 'old-git-packet-reference.json', {'root_commit': before['head'], 'git_path': str(old_tar.relative_to(ROOT)), 'git_blob': git_blob, 'packet_sha256': digest(old_tar), 'packet_bytes': old_tar.stat().st_size, 'old_main_member': old_member, 'old_main_sha256': OLD_SHA, 'old_main_bytes': len(old_data), 'old_durable_source': str(OLD), 'meaning': 'Reads original Git-retained actual cac56 binary only. No old packet mutation or new execution.'})
    positions = []
    for offset in range(0, len(old_data), 65536):
        old_chunk = old_data[offset:offset + 65536]
        new_chunk = new_data[offset:offset + 65536]
        if old_chunk != new_chunk:
            positions.extend(offset + index for index, (old, new) in enumerate(zip(old_chunk, new_chunk)) if old != new)
    assert len(positions) == 2493
    ranges = []
    for position in positions:
        if ranges and ranges[-1][1] == position:
            ranges[-1][1] += 1
        else:
            ranges.append([position, position + 1])
    runs = [{'offset': start, 'length': end - start, 'old_hex': old_data[start:end].hex(), 'new_hex': new_data[start:end].hex(), 'old_sha256': sha(old_data[start:end]), 'new_sha256': sha(new_data[start:end])} for start, end in ranges]
    rebuilt = bytearray(old_data)
    reversed_data = bytearray(new_data)
    end = 0
    for run in runs:
        start = run['offset']
        assert start >= end
        end = start + run['length']
        old_part, new_part = bytes.fromhex(run['old_hex']), bytes.fromhex(run['new_hex'])
        assert len(old_part) == len(new_part) == run['length'] and old_data[start:end] == old_part and new_data[start:end] == new_part
        rebuilt[start:end] = new_part
        reversed_data[start:end] = old_part
    assert sha(rebuilt) == NEW_SHA and sha(reversed_data) == OLD_SHA
    delta = {'scope': 'SPARSE_BYTE_DATA_RECONSTRUCTION_ONLY_NEVER_EXECUTION_OR_OS_SIGNATURE_TRUST', 'old_sha256': OLD_SHA, 'new_sha256': NEW_SHA, 'old_bytes': len(old_data), 'new_bytes': len(new_data), 'changed_bytes': len(positions), 'run_count': len(runs), 'sorted_nonoverlapping': True, 'runs': runs, 'old_full_binary_git_reference': 'old-git-packet-reference.json', 'current_full_binary_durable_blob': 'blobs/' + NEW_SHA, 'forward_and_reverse_whole_sha256_verified_in_memory': True}
    dump(STORE / 'canonical-main-sparse-byte-delta.json', delta)
    assert (STORE / 'canonical-main-sparse-byte-delta.json').stat().st_size < 1024 * 1024
    copied = {}
    for number, record in enumerate(sorted(selected.values(), key=lambda row: row['source']), 1):
        path = Path(record['source'])
        metadata = path.lstat()
        assert stat.S_ISREG(metadata.st_mode), str(path)
        actual_sha = digest(path)
        for expected in record['expectations']:
            if expected['sha256'] is not None:
                assert actual_sha == expected['sha256'], str(path)
            if expected['bytes'] is not None:
                assert metadata.st_size == expected['bytes'], str(path)
        blob = STORE / 'blobs' / actual_sha
        if not blob.exists():
            with path.open('rb') as source, blob.open('xb') as target:
                shutil.copyfileobj(source, target, 1024 * 1024)
            assert digest(blob) == actual_sha
            blob.chmod(0o444)
        else:
            assert blob.stat().st_size == metadata.st_size
        record.update({'sha256': actual_sha, 'bytes': metadata.st_size, 'mode': stat.S_IMODE(metadata.st_mode), 'mode_octal': oct(stat.S_IMODE(metadata.st_mode)), 'durable': str(blob), 'durable_relative': 'blobs/' + actual_sha, 'remote_included': metadata.st_size <= LIMIT})
        copied[record['source']] = record
        if number % 200 == 0:
            print(json.dumps({'selected_paths_processed': number, 'total': len(selected), 'unique_blobs_so_far': len(list((STORE / 'blobs').iterdir()))}), flush=True)
    assert (STORE / 'blobs' / ARCHIVE_SHA).stat().st_size == 347514880
    assert digest(STORE / 'blobs' / NEW_SHA) == NEW_SHA
    for bundle in appsets:
        for row in bundle['files']:
            observed = copied[row['source']]
            row['mode'] = observed['mode']
            row['durable_relative'] = observed['durable_relative']
    for runtime in stages:
        for row in runtime['files']:
            observed = copied[row['source']]
            row.update({key: observed[key] for key in ('sha256', 'bytes', 'mode', 'durable_relative')})
    dump(STORE / 'selection.json', {'scope': 'SELECTED_ORIGINAL_PATHS_EXACT_BYTES_MODE_NO_EXECUTION', 'records': list(copied.values())})
    dump(STORE / 'complete-app-and-runtime-stage-sets.json', {'actual_and_upfront_app_sets': appsets, 'runtime_stage_sets': stages})
    dump(STORE / 'collection-assertions.json', {'checks': checks, 'six_complete_app_sets': len(appsets) == 6, 'app_file_counts': [row['file_count'] for row in appsets], 'five_runtime_stage_counts': [row['file_count_including_manifest'] for row in stages], 'canonical_build_exit': json.loads((BUILD / 'invocation.json').read_text())['exit_code'], 'fixture_frozen_bindings': 425, 'sparse_delta_changed_bytes': 2493, 'sparse_delta_run_count': len(runs)})
    after = tracked()
    assert after == before, 'Tracked Git neutrality changed during collection'
    dump(OUT / 'tracked-after.json', after)
    dump(STORE / 'tracked-before.json', before)
    dump(STORE / 'tracked-after.json', after)
    dump(STORE / 'neutrality.json', {'all_1797_tracked_entries_head_tree_status_identical': True, 'before_sha256': digest(OUT / 'tracked-before.json'), 'after_sha256': digest(OUT / 'tracked-after.json')})
    shutil.copyfile(Path(__file__), STORE / 'collector.py')
    dump(STORE / 'invocation.json', {'argv': [str(Path(__file__))], 'collector_sha256': digest(Path(__file__)), 'scope': 'READ_HASH_COPY_ARCHIVE_GIT_OBJECT_INSPECTION_ONLY', 'started_at_utc': STARTED, 'prohibited_actors': 'No project/helper imports, tests, builds, services, processes, sockets, GUI, browser, installs, CI calls or root writes.'})
    large = [{'durable_relative': str(path.relative_to(STORE)), 'durable_full_copy': str(path), 'sha256': path.name, 'bytes': path.stat().st_size, 'omission_reason': 'All blobs greater than 4 MiB are omitted from remote Git tar.', 'original_sources': sorted(row['source'] for row in copied.values() if row['sha256'] == path.name)} for path in sorted((STORE / 'blobs').iterdir()) if path.stat().st_size > LIMIT]
    dump(STORE / 'remote-omissions.json', {'remote_limit_bytes': LIMIT, 'every_large_blob_omitted': True, 'full_large_bytes_retained_locally': True, 'omissions': large})
    (STORE / 'README.md').write_text('''# Selected v4 W03 build and applicability evidence

This is BUILD/APPLICABILITY retention, not current native execution or acceptance.
All current canonical close/quit/forced cases are PREPARED / NOT_EXECUTED; close
was blocked by the locked Mac before any actor. The original invalid force config
and separate owned-force correction receipt remain verbatim. New contained and
escaped v4 fixtures are built, not executed. Prior actual cases remain cac56.

The original independent reports support logical shipping-software path
applicability only. They do not prove current GUI execution, signing, OS launch
trust, full Windows success, full verification, hosted CI success, or W03 PASS.
No running full/CI artifacts were selected as completed proof.

selection.json preserves original absolute paths, byte SHA-256, length and mode.
blobs/ content-addresses every selected file, deduplicating archives/app/runtime
copies. The complete six 42-file actual/upfront app sets and five 40-file runtime
stages are listed separately. Canonical archive 620e7c6a... is retained locally
once at its full 347,514,880 bytes. Selected large build tools are local copies;
this is not a full archival copy of the build toolchain, caches or dependencies.

The remote tar omits EVERY blob over 4 MiB. remote-omissions.json lists each
omission, every source alias, and the full durable local copy. No 350 MB source
archive, full current main binary, or large tool/runtime blob enters that tar.
The sparse byte delta plus the old full binary in the Git-retained cac56 packet
reconstructs current canonical main a1d7a5... exactly in memory. This is data
reconstruction only: it executes neither binary and makes no signature or OS
launch claim. The independent Mach-O category report is preserved unchanged;
the collector separately verifies 2,493 changed bytes and whole-file identities.

All original records, historical scopes and paths are preserved unchanged.
HANDOFF, collectors and collector premise error records are retained as data.
The collector imported no project/helper module and ran no product/test actor.
The full 1,797 tracked Git entries, HEAD/tree and clean status were neutral.
retention-manifest.json hashes all local payload files except itself; the
adjacent remote archive manifest exhaustively hashes every safe regular member.
''')
    payload = []
    for path in sorted(STORE.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            payload.append({'path': str(path.relative_to(STORE)), 'bytes': path.stat().st_size, 'mode': 0o444, 'sha256': digest(path)})
    dump(STORE / 'retention-manifest.json', {'scope': 'EXHAUSTIVE_DURABLE_SELECTED_PAYLOAD_EXCEPT_THIS_MANIFEST', 'files': payload})
    members = []
    for path in sorted(STORE.rglob('*')):
        if path.is_file() and path.stat().st_size <= LIMIT:
            members.append({'path': str(path.relative_to(STORE)), 'bytes': path.stat().st_size, 'sha256': digest(path), 'mode': 0o444})
    archive_path = OUT / 'v4-build-applicability-selected.tar.gz'
    with archive_path.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
                for row in members:
                    safe(row['path'])
                    source = STORE / row['path']
                    info = tarfile.TarInfo(PREFIX + '/' + row['path'])
                    info.size = row['bytes']
                    info.mode = row['mode']
                    info.mtime = info.uid = info.gid = 0
                    info.uname = info.gname = ''
                    with source.open('rb') as stream:
                        archive.addfile(info, stream)
    assert archive_path.stat().st_size < 15 * 1024 * 1024
    expected = {PREFIX + '/' + row['path']: row for row in members}
    seen = set()
    with tarfile.open(archive_path, 'r:gz') as archive:
        for member in archive.getmembers():
            safe(member.name)
            assert member.isfile() and not member.issym() and not member.islnk()
            assert member.name not in seen and member.name in expected
            seen.add(member.name)
            stream = archive.extractfile(member)
            assert stream is not None
            data = stream.read()
            row = expected[member.name]
            assert len(data) == row['bytes'] and sha(data) == row['sha256'] and member.mode == row['mode']
    assert seen == set(expected)
    # Exhaustive durable readback, including all locally omitted large blobs.
    for row in payload:
        path = STORE / row['path']
        assert path.stat().st_size == row['bytes'] and digest(path) == row['sha256']
    final = tracked()
    assert final == before
    dump(OUT / 'tracked-final.json', final)
    archive_record = {'scope': 'SAFE_REMOTE_SELECTED_BUILD_APPLICABILITY_ONLY', 'archive': str(archive_path), 'archive_bytes': archive_path.stat().st_size, 'archive_sha256': digest(archive_path), 'member_count': len(members), 'members': members, 'omitted_large_blob_count': len(large), 'omissions_manifest_sha256': digest(STORE / 'remote-omissions.json'), 'durable_manifest_sha256': digest(STORE / 'retention-manifest.json'), 'complete_readback': True, 'duplicate_missing_unexpected_unsafe_nonregular_members': 0, 'full_tracked_before_after_final_identical': True}
    dump(OUT / 'v4-build-applicability-selected.manifest.json', archive_record)
    result = {key: value for key, value in archive_record.items() if key != 'members'}
    result.update({'durable': str(STORE), 'selected_original_path_count': len(copied), 'unique_content_blob_count': len(list((STORE / 'blobs').iterdir())), 'complete_app_sets': 6, 'complete_app_files_each': 42, 'runtime_stage_sets': 5, 'runtime_stage_files_each': 40, 'sparse_delta_sha256': digest(STORE / 'canonical-main-sparse-byte-delta.json'), 'sparse_delta_runs': len(runs), 'sparse_delta_changed_bytes': len(positions), 'selection_sha256': digest(STORE / 'selection.json'), 'collector_sha256': digest(Path(__file__)), 'root_neutrality': '1797 tracked entries, clean HEAD/tree/status equal before/after/final', 'current_native_status': 'ALL_V4_NOT_EXECUTED_NO_W03_ACCEPTANCE'})
    dump(OUT / 'collection-result.json', result)
    for path in STORE.rglob('*'):
        if path.is_file():
            path.chmod(0o444)
    for path in sorted((p for p in STORE.rglob('*') if p.is_dir()), key=lambda p: len(p.parts), reverse=True):
        path.chmod(0o555)
    STORE.chmod(0o555)
    for row in payload:
        assert stat.S_IMODE((STORE / row['path']).stat().st_mode) == row['mode']
    for path in OUT.iterdir():
        if path.is_file():
            path.chmod(0o444)
    print(json.dumps(result, indent=2), flush=True)

STARTED = datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
    collect()
except BaseException as error:
    failure = {'scope': 'COLLECTOR_PREMISE_OR_COLLECTION_FAILURE_NOT_PRODUCT_EXECUTION', 'started_at_utc': STARTED, 'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc(), 'collector_sha256': digest(Path(__file__))}
    dump(OUT / 'collector-failure.json', failure)
    print(json.dumps(failure, indent=2), flush=True)
    raise
