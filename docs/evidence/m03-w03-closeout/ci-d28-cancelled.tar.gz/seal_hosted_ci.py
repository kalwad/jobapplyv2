import datetime as dt,gzip,hashlib,io,json,os,pathlib,stat,tarfile
from collect_hosted_ci import ROOT,RUN_ID,HEAD,TREE,sha
OUT=pathlib.Path(str(ROOT)+'-retained')

def read_regular(p):
 before=p.lstat();assert stat.S_ISREG(before.st_mode)
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  chunks=[]
  while True:
   chunk=os.read(fd,1024*1024)
   if not chunk:break
   chunks.append(chunk)
  after=os.fstat(fd)
 finally:os.close(fd)
 final=p.lstat();keys=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 assert keys(before)==keys(after)==keys(final)
 return b''.join(chunks)

def files():
 rows=[]
 for p in sorted(ROOT.rglob('*')):
  assert not p.is_symlink()
  if not p.is_file():continue
  name=p.relative_to(ROOT).as_posix()
  if name=='evidence-inputs.json' or name.startswith('__pycache__/'):continue
  parts=pathlib.PurePosixPath(name)
  assert not parts.is_absolute() and '..' not in parts.parts
  rows.append((name,p))
 return rows

summary=json.loads((ROOT/'hosted-ci-summary.json').read_text())
assert summary['run_id']==RUN_ID and summary['head_sha']==HEAD and summary['expected_source_tree']==TREE
assert summary['run_status']=='completed' and len(summary['platforms'])==3
assert all(x['job_status']=='completed' for x in summary['platforms'])
assert summary['scope']['native_gui_credit'] is False and summary['scope']['platform_packaging_credit'] is False
assert not OUT.exists()
rows=[]
for name,path in files():
 data=read_regular(path);rows.append({'path':name,'bytes':len(data),'sha256':sha(data)})
manifest={'run_id':RUN_ID,'head_sha':HEAD,'expected_source_tree':TREE,'file_count':len(rows),'files':rows,'scope':'Exact finite captured source/metadata/official complete logs/analysis inputs. Earlier empty artifact and missing-original-stderr limitation are retained. This archive supplies no native GUI, packaged-target, or unrelated local-run credit.'}
mb=(json.dumps(manifest,indent=2)+'\n').encode();(ROOT/'evidence-inputs.json').write_bytes(mb)
all_rows=rows+[{'path':'evidence-inputs.json','bytes':len(mb),'sha256':sha(mb)}]
OUT.mkdir();archive=OUT/'proof.tar.gz'
with archive.open('wb') as output:
 with gzip.GzipFile(fileobj=output,filename='',mode='wb',mtime=0,compresslevel=6) as compressed:
  with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for row in all_rows:
    data=read_regular(ROOT/row['path']);assert len(data)==row['bytes'] and sha(data)==row['sha256']
    info=tarfile.TarInfo(row['path']);info.size=len(data);info.mode=0o644;info.uid=0;info.gid=0;info.uname='';info.gname='';info.mtime=0
    tar.addfile(info,io.BytesIO(data))
assert [x[0] for x in files()]==[x['path'] for x in rows]
for row in rows:
 data=read_regular(ROOT/row['path']);assert len(data)==row['bytes'] and sha(data)==row['sha256']
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(all_rows) and len({m.name for m in members})==len(members)
 expected={x['path']:x for x in all_rows}
 for member in members:
  assert member.isfile() and member.name in expected
  data=tar.extractfile(member).read();row=expected[member.name]
  assert len(data)==row['bytes'] and sha(data)==row['sha256']
ab=archive.read_bytes()
outer={'archive':'proof.tar.gz','bytes':len(ab),'sha256':sha(ab),'regular_members':len(all_rows),'input_manifest_sha256':sha(mb),'run_id':RUN_ID,'head_sha':HEAD,'expected_source_tree':TREE,'actual_conclusion':summary['run_conclusion'],'captured_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'scope':'Hosted source-bound CI only; official complete logs ZIP retained; no GUI or platform-packaging credit.'}
(OUT/'manifest.json').write_text(json.dumps(outer,indent=2)+'\n')
print(json.dumps(outer,indent=2))
