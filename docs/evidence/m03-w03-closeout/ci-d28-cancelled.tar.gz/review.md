# Hosted CI 39181477863: CANCELLED

Head `d28cfc70feda604c508bc18c778992a0ca559e5a`, source tree `e72a0523d4b3183b5a658ccd74ce02a8dbd4b8e8`. All three official job logs identify actual PR merge checkout `73f1695530705f88b29f2f5918580e7a7f527c4a` with the same source tree. Complete official ZIP and all 85 safely extracted regular members are retained.

| Host | Job result | Terminal suite results | Python | Desktop native test modes |
|---|---|---|---|---|
| windows-2025 | cancelled | 0/20 PASS rows emitted | 1648 passed, zero skips | 70/STARTED_INTERRUPTED/NOT_STARTED_IN_RETAINED_LOG |
| ubuntu-24.04 | success | 20/20 PASS rows emitted | 1650 passed, zero skips | 76/76/76 |
| macos-15 | success | 20/20 PASS rows emitted | 1650 passed, zero skips | 77/77/77 |

All three doctors report 28 pass, zero warning/fail/not-yet-applicable. Each host completed 15 root unit-TS workspace summaries, 256 default browser tests, 2 controlled public-research tests, 62 controlled public-contact tests, and 3 visual browser tests with zero reported failures/skips. Exact counts, commands, raw timestamped evidence and normalized line references are in hosted-ci-summary.json.

All three strict Clippy commands (native-host, contract harness and desktop) completed on each host with `-D warnings`, finished profiles, and subsequent Rust commands. Individual command exit values are inferred as zero from the frozen verifier's stop-on-nonzero control flow; separate per-command process exits are not printed in the hosted logs.

Windows completed the default desktop native command with 70 library tests plus zero-test successful main/doc targets. Its all-features command began at 01:35:48.429Z and was interrupted; no output or exit completion for that command is credited. The dependency-only `tauri/custom-protocol` mode and final desktop build were not started in the retained log. Portability, traceability, status, integrity and the complete 20-suite verdict table were not reached/reported; no Windows terminal suite PASS rows are reconstructed.

GitHub's final check-run annotations explicitly state: The job has exceeded the maximum execution time of 1h0m0s. The log also retains KeyboardInterrupt and The operation was canceled. This is official cancellation evidence, not an inferred product failure. Root must diagnose the actual aggregate duration before claiming completion.

Ubuntu and macOS completed all 20 ACTIVE suites with verification exit code 0. Their three desktop native Cargo modes completed 76 library tests per mode on Ubuntu and 77 per mode on macOS, with zero-failure main/doc targets, followed by each native build. This supplies no native GUI or platform packaging certification, and Windows Server 2025 is not Windows 11 packaged-target proof.

Python outer collection and execution summaries report 1650 on Ubuntu/macOS and 1648 on Windows, zero skips/failures. The visible collected-node-line multiset differs by two POSIX cases. GitHub masks twelve authorization-test parameter lines to repeated *** prefixes, so unique unredacted node-ID equality cannot be established from hosted logs. The masked lines and actual count summaries are preserved without reconstruction.

The initial TLS failure has only the original empty initial-run.json and a reported chat-tool failure description. Its original standalone stderr/transcript is unavailable and has not been reconstructed. Later successful metadata collection attempts, including actual exit records, remain separate from workflow attempt 1. Earlier CI and local v4 results are separate evidence and are not transferred.

The finite archive manifest binds all retained raw API command output, stderr, exits, source blobs, complete ZIP, full platform logs and analysis files. No workflow was dispatched/retried/cancelled, and no native actor was run by this collector.
