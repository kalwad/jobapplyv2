"""Finite documentary hash, source, raw-record and ZIP consistency audit."""
import hashlib
import base64
import json
import pathlib
import stat
import zipfile

from collect_hosted_ci import ROOT, RUN_ID, HEAD, TREE, sha


def load(name):
    return json.loads((ROOT / name).read_text())


records = []
for directory in ["commands", "operations"]:
    for path in sorted((ROOT / directory).glob("*.record.json")):
        record = json.loads(path.read_text())
        for stream in ["stdout", "stderr"]:
            item = record[stream]
            data = (ROOT / item["path"]).read_bytes()
            assert len(data) == item["bytes"] and sha(data) == item["sha256"], (path, stream)
        records.append({"path": str(path.relative_to(ROOT)), "exit_code": record["exit_code"], "argv": record["argv"]})
assert all(x["exit_code"] == 0 for x in records if x["path"].startswith("commands/"))
failures = [x for x in records if x["exit_code"] != 0]
assert [pathlib.Path(x["path"]).name.split("-")[0] for x in failures] == ["0011", "0012", "0013", "0014", "0016"]
expected_originals = {"initial-run.json": (0, "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"), "initial-run-attempt2.json": (12365, "3f626835d7dda2149b80e32d7bcb634c10120bf4ebce2513ce18fd44874ef2b0"), "initial-jobs-attempt2.json": (19504, "52444bc23cedfc0251f5a33c1cea86f526f65db8e1960a5d56d566a41fe6a4eb")}
for name, expected in expected_originals.items():
    data = (ROOT / name).read_bytes()
    assert (len(data), sha(data)) == expected
source = load("selected-source-manifest.json")
assert source["head_sha"] == HEAD and source["tree_sha"] == TREE
for row in source["files"]:
    data = (ROOT / "source" / row["path"]).read_bytes()
    assert len(data) == row["bytes"] and sha(data) == row["sha256"]
    assert hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest() == row["git_blob_sha"]
    raw_blob = load(row["record_stdout"])
    assert raw_blob["encoding"] == "base64" and raw_blob["sha"] == row["git_blob_sha"]
    assert base64.b64decode(raw_blob["content"]) == data
prep = load("source-binding-preparation.json")
assert prep["head_commit_api_tree_verified"] and prep["local_github_git_entries_equal"]
assert prep["complete_local_git_entries"] == prep["complete_github_git_entries"] == 1797
assert prep["recursive_tree_truncated"] is False
platform = load("platform-logs-manifest.json")
assert platform["all_actual_content_trees_match"]
for row in platform["platforms"]:
    data = (ROOT / row["platform_log"]).read_bytes()
    assert len(data) == row["bytes"] and sha(data) == row["sha256"]
    assert (ROOT / "official-logs" / row["official_combined_member"]).read_bytes() == data
    actual = load(row["checkout_commit_api"]["record_stdout"])
    assert actual["sha"] == row["actual_checkout_sha"] and actual["tree"]["sha"] == row["actual_checkout_tree"] == TREE
manifest = load("official-logs-manifest.json")
archive = (ROOT / manifest["zip"]["path"]).read_bytes()
assert len(archive) == manifest["zip"]["bytes"] and sha(archive) == manifest["zip"]["sha256"]
assert archive == (ROOT / manifest["zip"]["command_stdout"]).read_bytes()
expected = {row["path"]: row for row in manifest["files"]}
with zipfile.ZipFile(ROOT / "logs.zip") as zip:
    members = zip.infolist()
    assert len(members) == len(expected) == manifest["safe_regular_file_count"] == manifest["zip_entry_count"] == 85
    assert zip.testzip() is None
    assert len({row.filename for row in members}) == len(members)
    for member in members:
        path = pathlib.PurePosixPath(member.filename)
        assert not path.is_absolute() and ".." not in path.parts and "\\" not in member.filename and "\0" not in member.filename
        assert not stat.S_ISLNK(member.external_attr >> 16) and not member.is_dir()
        row = expected[member.filename]
        data = zip.read(member)
        assert len(data) == row["bytes"] and sha(data) == row["sha256"]
        assert format(member.CRC, "08x") == row["crc32_hex"]
        assert (ROOT / "official-logs" / member.filename).read_bytes() == data
summary = load("hosted-ci-summary.json")
assert summary["run_id"] == RUN_ID and summary["head_sha"] == HEAD and summary["expected_source_tree"] == TREE
assert summary["all_three_hosts_pass"] is False and summary["run_conclusion"] == "cancelled"
assert not summary["scope"]["native_gui_credit"] and not summary["scope"]["platform_packaging_credit"]
for row in summary["platforms"]:
    assert len(row["suite_rows"]) == 20
    if row["label"] == "windows-2025":
        assert row["job_conclusion"] == "cancelled" and row["verification_exit_code"] is None
        assert row["reported_suite_count"] == row["reported_suite_pass_count"] == 0
        assert all(x["result"] == "NOT_REPORTED_DUE_TO_CANCELLATION" and x["state"] is None for x in row["suite_rows"])
    else:
        assert row["job_conclusion"] == "success" and row["verification_exit_code"] == 0
        assert row["reported_suite_count"] == row["reported_suite_pass_count"] == 20
        assert all(x["result"] == "PASS" and x["state"] == "ACTIVE" for x in row["suite_rows"])
result = {"result": "PASS", "scope": "Finite documentary consistency audit, not an additional product test run or a three-platform CI pass", "record_count_checked": len(records), "read_only_command_record_count": len([x for x in records if x["path"].startswith("commands/")]), "operation_record_count_at_audit_start": len([x for x in records if x["path"].startswith("operations/")]), "all_read_only_commands_exit_zero": True, "retained_documentary_analysis_failures": failures, "original_artifacts_unchanged": True, "selected_git_blobs_checked": len(source["files"]), "complete_git_entries_equal": 1797, "official_zip_regular_members_checked": len(expected), "zip_crc_and_full_platform_copies_checked": True, "actual_checkout_content_tree_matches_all_hosts": True, "no_three_platform_pass_invented": True, "self_audit_record_note": "The operation wrapper writes this audit's own record only after this program exits; the final finite archive binds that record as well."}
assert not (ROOT / "retained-input-audit.json").exists()
(ROOT / "retained-input-audit.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
