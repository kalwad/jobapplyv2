import json
from collect_hosted_ci import ROOT,REPO,RUN_ID,HEAD,TREE,api,capture,sha

commit,cr=api('repos/{}/git/commits/{}'.format(REPO,HEAD),'expected-head-git-commit')
assert commit['sha']==HEAD and commit['tree']['sha']==TREE
inventory,ir=api('repos/{}/git/trees/{}?recursive=1'.format(REPO,TREE),'expected-recursive-tree')
assert inventory['sha']==TREE and inventory.get('truncated') is False
local,lr=capture(['/usr/bin/git','-C','/Users/tanishkalwad/jobapplyv2','ls-tree','-rz','--full-tree',HEAD],'expected-local-git-ls-tree')
local_rows=[]
for item in local.split(b'\0'):
 if not item:continue
 lhs,path=item.split(b'\t',1);mode,kind,obj=lhs.decode().split()
 local_rows.append({'path':path.decode(),'mode':mode,'type':kind,'sha':obj})
api_rows=[{k:x[k] for k in ['path','mode','type','sha']} for x in inventory['tree'] if x['type']!='tree']
assert sorted(local_rows,key=lambda x:x['path'])==sorted(api_rows,key=lambda x:x['path'])
pull,pr=api('repos/{}/pulls/1'.format(REPO),'pull1-source-context')
record={'head_sha':HEAD,'head_tree_sha':TREE,'head_commit_api_tree_verified':True,'complete_local_git_entries':len(local_rows),'complete_github_git_entries':len(api_rows),'local_github_git_entries_equal':True,'recursive_tree_truncated':False,'observed_pull_head':pull['head']['sha'],'observed_pull_base':pull['base']['sha'],'observed_pull_merge':pull.get('merge_commit_sha'),'actual_tested_checkout_sha':None,'actual_tested_tree':None,'actual_checkout_scope':'PENDING_ACTUAL_COMPLETE_OFFICIAL_HOST_LOGS','input_records':[cr,ir,lr,pr],'scope':'Exact immutable source binding only; no CI result, packaging, GUI, or owner decision is inferred.'}
(ROOT/'source-binding-preparation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['head_sha','head_tree_sha','complete_local_git_entries','local_github_git_entries_equal','observed_pull_merge']}))
print(json.dumps({'desktop_source_paths':[x['path'] for x in api_rows if ('desktop' in x['path'] and (x['path'].endswith('Cargo.toml') or x['path'].endswith('package.json') or x['path'].endswith('/lib.rs') or x['path'].endswith('/main.rs'))) or ('suites' in x['path'] and x['path'].endswith('.json'))]},indent=2))
