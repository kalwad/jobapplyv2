import datetime as dt
import hashlib
import json
import pathlib
import subprocess
import sys
import time

ROOT=pathlib.Path('/tmp/japp-m03-w03-hosted-ci-d28cfc7-20261019')
REPO='kalwad/jobapplyv2'
RUN_ID=39181477863
HEAD='d28cfc70feda604c508bc18c778992a0ca559e5a'
TREE='e72a0523d4b3183b5a658ccd74ce02a8dbd4b8e8'

def utc():return dt.datetime.now(dt.timezone.utc).isoformat()
def sha(data):return hashlib.sha256(data).hexdigest()

def capture(argv,label):
 folder=ROOT/'commands';folder.mkdir(exist_ok=True)
 number=len(list(folder.glob('*.record.json')))+1
 stem='{:04d}-{}'.format(number,label)
 started=utc();tick=time.monotonic()
 p=subprocess.run(argv,cwd=str(ROOT),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 elapsed=time.monotonic()-tick;ended=utc()
 out=folder/(stem+'.stdout');err=folder/(stem+'.stderr')
 assert not out.exists() and not err.exists()
 out.write_bytes(p.stdout);err.write_bytes(p.stderr)
 record={'argv':argv,'cwd':str(ROOT),'started_at_utc':started,'ended_at_utc':ended,'elapsed_seconds':elapsed,'exit_code':p.returncode,'stdout':{'path':str(out.relative_to(ROOT)),'bytes':len(p.stdout),'sha256':sha(p.stdout)},'stderr':{'path':str(err.relative_to(ROOT)),'bytes':len(p.stderr),'sha256':sha(p.stderr)},'scope':'READ_ONLY_GITHUB_METADATA_LOGS_SOURCE_OR_DOCUMENTARY_ANALYSIS_NO_WORKFLOW_MUTATION_NO_NATIVE_ACTOR'}
 (folder/(stem+'.record.json')).write_text(json.dumps(record,indent=2)+'\n')
 if p.returncode:raise RuntimeError('{} exited {}; exact stdout/stderr retained'.format(label,p.returncode))
 return p.stdout,record

def api(endpoint,label):
 out,record=capture(['/opt/homebrew/bin/gh','api','-H','Accept: application/vnd.github+json',endpoint],label)
 return json.loads(out),record

def status():
 run,rr=api('repos/{}/actions/runs/{}'.format(REPO,RUN_ID),'run-status')
 assert run['id']==RUN_ID and run['head_sha']==HEAD
 attempt=run['run_attempt']
 jobs,jr=api('repos/{}/actions/runs/{}/attempts/{}/jobs?per_page=100'.format(REPO,RUN_ID,attempt),'jobs-attempt{}'.format(attempt))
 assert len(jobs['jobs'])==jobs['total_count']
 snapshot={'observed_at_utc':utc(),'run_id':RUN_ID,'run_attempt':attempt,'head_sha':HEAD,'expected_tree_sha':TREE,'run_status':run['status'],'run_conclusion':run['conclusion'],'actual_checkout_sha':None,'actual_checkout_tree':None,'checkout_binding_status':'PENDING_ACTUAL_COMPLETE_HOST_LOGS_AND_GIT_API','run_record':rr,'jobs_record':jr,'jobs':[{'job_id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'started_at':j['started_at'],'completed_at':j['completed_at'],'active_steps':[{k:s.get(k) for k in ['number','name','status','started_at']} for s in j.get('steps',[]) if s['status']=='in_progress']} for j in jobs['jobs']],'scope':'Actual workflow states only. No suite counts, platform packaging, GUI behavior, or owner decision inferred.'}
 target=ROOT/('snapshot-{:04d}.json'.format(len(list(ROOT.glob('snapshot-*.json')))+1))
 target.write_text(json.dumps(snapshot,indent=2)+'\n')
 print(json.dumps({'snapshot':str(target),'run_id':RUN_ID,'run_attempt':attempt,'head_sha':HEAD,'status':run['status'],'conclusion':run['conclusion'],'jobs':snapshot['jobs']},indent=2))

if __name__=='__main__':
 assert sys.argv[1:]==['status']
 status()
