import base64,hashlib,json
from collect_hosted_ci import ROOT,REPO,HEAD,TREE,api

inventory=json.loads(sorted((ROOT/'commands').glob('*expected-recursive-tree.stdout'))[-1].read_text())
blobs={x['path']:x for x in inventory['tree'] if x['type']=='blob'}
paths=['.github/workflows/ci.yml','scripts/verification-suites.json','scripts/verify.py','scripts/doctor.py','apps/desktop/src-tauri/Cargo.toml','apps/desktop/src-tauri/src/lib.rs','apps/desktop/src-tauri/src/main.rs','apps/desktop/package.json','package.json','pyproject.toml','.nvmrc','.python-version','rust-toolchain.toml','playwright.config.ts','e2e/extension/extension-benchmark.spec.ts']
rows=[]
for path in paths:
 entry=blobs[path]
 blob,record=api('repos/{}/git/blobs/{}'.format(REPO,entry['sha']),'selected-source-blob-{:02d}'.format(len(rows)+1))
 assert blob['sha']==entry['sha'] and blob['encoding']=='base64'
 data=base64.b64decode(blob['content'])
 assert len(data)==blob['size']==entry['size']
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==entry['sha']
 out=ROOT/'source'/path;out.parent.mkdir(parents=True,exist_ok=True);assert not out.exists();out.write_bytes(data)
 rows.append({'path':path,'git_blob_sha':entry['sha'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'record_stdout':record['stdout']['path']})
manifest={'head_sha':HEAD,'tree_sha':TREE,'files':rows,'scope':'Selected exact source bytes only. All1797Gitentries are independently bound by immutable Git objects; no unexecuted native or GUI result is inferred.'}
(ROOT/'selected-source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'selected_sources':len(rows),'selected_bytes':sum(x['bytes'] for x in rows)}))
