"""Analyze closed official logs; no repository commands or test actors are run."""
import datetime as dt
import collections
import json
import pathlib
import re

from collect_hosted_ci import ROOT, RUN_ID, HEAD, TREE, sha


def read_json(name):
    return json.loads((ROOT / name).read_text())


def save(name, value):
    path = ROOT / name
    assert not path.exists(), name
    path.write_text(json.dumps(value, indent=2) + "\n")


registry = read_json("source/scripts/verification-suites.json")
suite_ids = [s["id"] for s in registry["suites"]]
assert len(suite_ids) == 20 and len(set(suite_ids)) == 20
rust_commands = ["$ " + " ".join(x) for x in next(s for s in registry["suites"] if s["id"] == "rust")["commands"]]
clippy_commands = [x for x in rust_commands if x.startswith("$ cargo clippy ")]
native_commands = [x for x in rust_commands if x.startswith("$ cargo test ") and "apps/desktop/src-tauri" in x]
assert len(clippy_commands) == len(native_commands) == 3
run = read_json("final-run.json")
jobs = read_json("final-jobs.json")["jobs"]
bindings = read_json("platform-logs-manifest.json")
assert run["status"] == "completed" and run["conclusion"] == "cancelled"
assert run["head_sha"] == HEAD and all(j["status"] == "completed" for j in jobs)
assert bindings["all_actual_content_trees_match"] is True
platforms = []
collection_ids = {}
native_ids = {}

for binding in bindings["platforms"]:
    label = binding["label"]
    data = (ROOT / binding["platform_log"]).read_bytes()
    assert sha(data) == binding["sha256"] and len(data) == binding["bytes"]
    raw = data.decode("utf-8").splitlines()
    lines = [re.sub(r"^\d{4}-\d\d-\d\dT\S+\s*", "", re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", x)).strip() for x in raw]
    job = next(j for j in jobs if j["id"] == binding["job_id"])
    assert len(lines) == binding["normalized_lines"]

    def found(pattern, start=0, end=None):
        return [(i, re.fullmatch(pattern, x)) for i, x in enumerate(lines) if i >= start and (end is None or i < end) and re.fullmatch(pattern, x)]

    def locate(command, after=0):
        rows = [i for i, x in enumerate(lines) if x == command and i >= after]
        assert len(rows) <= 1, (label, command)
        return rows[0] if rows else None

    def reference(i):
        return {"log": binding["platform_log"], "line": i + 1, "text": lines[i], "raw": raw[i]}

    def block(command):
        start = locate(command, execute_i + 1 if command in rust_commands else 0)
        if start is None:
            return {"command": command, "status": "NOT_STARTED_IN_RETAINED_LOG", "direct_exit_code": None}
        next_commands = [i for i in range(start + 1, len(lines)) if lines[i].startswith("$ ")]
        end = next_commands[0] if next_commands else len(lines)
        finished = [reference(i) for i in range(start + 1, end) if re.match(r"^Finished `(?:dev|test)` profile ", lines[i])]
        results = []
        for i, match in found(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in (.+)", start + 1, end):
            results.append({"passed": int(match[1]), "failed": int(match[2]), "ignored": int(match[3]), "measured": int(match[4]), "filtered_out": int(match[5]), "duration": match[6], "evidence": reference(i)})
        interruption = [reference(i) for i in range(start + 1, end) if lines[i] in ("KeyboardInterrupt", "##[error]The operation was canceled.")]
        complete = bool(next_commands) and not interruption
        return {"command": command, "status": "COMPLETED_VERIFIER_CONTINUED" if complete else "STARTED_INTERRUPTED", "command_evidence": reference(start), "next_command_evidence": reference(end) if next_commands else None, "finished_profiles": finished, "test_results": results, "interruptions": interruption, "direct_exit_code": None, "exit_inference": "0 inferred from frozen verify.py run_suite breaking on nonzero before the next Rust command; not a separately emitted process exit code" if complete else "No completed command exit was emitted; no exit value is invented"}

    doctor = found(r"summary: (\d+) pass, (\d+) warning, (\d+) fail, (\d+) not-yet-applicable")
    assert len(doctor) == 1
    doctor_i, doctor_m = doctor[0]
    doctor_row = {"pass": int(doctor_m[1]), "warning": int(doctor_m[2]), "fail": int(doctor_m[3]), "not_yet_applicable": int(doctor_m[4]), "evidence": reference(doctor_i)}
    assert doctor_row["pass"] == 28 and not any(doctor_row[k] for k in ["warning", "fail", "not_yet_applicable"])

    summary_start = [i for i, x in enumerate(lines) if x == "== verification summary =="]
    exits = found(r"verification exit code: (\d+)")
    suite_rows = []
    if summary_start:
        assert len(summary_start) == 1 and len(exits) == 1
        rows = [(i, re.fullmatch(r"(\S+)\s+(ACTIVE|NOT_YET_APPLICABLE|REQUIRED_MISSING)\s+(\S+)(?:\s+(.*))?", x)) for i, x in enumerate(lines) if i > summary_start[0]]
        rows = [(i, m) for i, m in rows if m and m[1] in suite_ids]
        assert [m[1] for _, m in rows] == suite_ids
        suite_rows = [{"suite_id": m[1], "state": m[2], "result": m[3], "detail": m[4], "evidence": reference(i)} for i, m in rows]
        assert all(x["state"] == "ACTIVE" and x["result"] == "PASS" for x in suite_rows)
        assert int(exits[0][1][1]) == 0 and job["conclusion"] == "success"
    else:
        assert label == "windows-2025" and not exits and job["conclusion"] == "cancelled"
        suite_rows = [{"suite_id": sid, "state": None, "result": "NOT_REPORTED_DUE_TO_CANCELLATION", "detail": "The final aggregate summary was never emitted. Observed component completions are recorded separately; no terminal suite verdict is reconstructed."} for sid in suite_ids]

    unit_start = locate("$ pnpm exec turbo run test --force -- --reporter=default")
    unit_end = locate("$ pnpm generate:contracts --check")
    assert unit_start is not None and unit_end is not None
    test_rows = found(r"Tests\s+(\d+) passed \((\d+)\)", unit_start, unit_end)
    file_rows = found(r"Test Files\s+(\d+) passed \((\d+)\)", unit_start, unit_end)
    assert len(test_rows) == len(file_rows) == 15
    assert all(m[1] == m[2] for _, m in test_rows + file_rows)
    unit = {"workspace_summaries": len(test_rows), "passed": sum(int(m[1]) for _, m in test_rows), "failed": 0, "skipped": 0, "todo": 0, "test_files": sum(int(m[1]) for _, m in file_rows), "evidence": [reference(i) for i, _ in test_rows], "scope": "Only the root forced Turbo unit-TS block; later repeated fixture/contract/controlled tests are excluded."}

    browser = {}
    for key, command in [("default", "$ pnpm exec playwright test"), ("controlled_public_research", "$ pnpm exec playwright test --config e2e/extension/public-research/playwright.config.ts"), ("controlled_public_contact", "$ pnpm exec playwright test --config e2e/extension/public-contact/playwright.config.ts --reporter=list,json"), ("visual", "$ pnpm exec playwright test e2e/visual")]:
        start = locate(command)
        assert start is not None
        end = next(i for i in range(start + 1, len(lines)) if lines[i].startswith("$ "))
        passed = found(r"(\d+) passed \(([^)]+)\)", start + 1, end)
        assert len(passed) == 1
        index, match = passed[0]
        browser[key] = {"passed": int(match[1]), "failed": 0, "skipped": 0, "duration": match[2], "command_evidence": reference(start), "summary_evidence": reference(index)}
    assert [browser[k]["passed"] for k in browser] == [256, 2, 62, 3]

    collection_commands = [i for i, x in enumerate(lines) if x.startswith("$ uv run pytest ") and " --collect-only -q " in x]
    execution_commands = [i for i, x in enumerate(lines) if x.startswith("$ uv run pytest ") and " --collect-only " not in x]
    assert len(collection_commands) == len(execution_commands) == 1
    collect_i = collection_commands[0]
    execute_i = execution_commands[0]
    first_rust = locate(rust_commands[0], execute_i + 1)
    assert first_rust is not None
    collect_summary = found(r"(\d+) tests collected in ([0-9.]+)s", collect_i + 1, execute_i)
    assert len(collect_summary) == 1
    collect_end, collect_match = collect_summary[0]
    ids = [x for x in lines[collect_i + 1:collect_end] if re.match(r"^(?:scripts|services)/[^ ]+\.py::", x)]
    assert len(ids) == int(collect_match[1]), (label, len(ids), collect_match[1])
    collection_ids[label] = ids
    save(f"python-collected-ids-{label}.json", {"platform": label, "count": len(ids), "distinct_visible_lines": len(set(ids)), "visible_node_id_lines": ids, "duplicate_visible_lines": {x: n for x, n in collections.Counter(ids).items() if n > 1}, "limitation": "GitHub's retained logs mask some parameter text as ***. Visible duplicate node-ID lines are preserved as occurrences; no unique unredacted-ID proof is claimed.", "command_evidence": reference(collect_i), "summary_evidence": reference(collect_end)})
    collected_execution = found(r"collected (\d+) items", execute_i + 1, first_rust)
    assert len(collected_execution) == 1
    pytest_summary = found(r"=+ (\d+) passed in ([0-9.]+)s(?: \([^)]*\))? =+", execute_i + 1, first_rust)
    assert len(pytest_summary) == 1
    pytest_i, pytest_m = pytest_summary[0]
    assert int(pytest_m[1]) == len(ids) == int(collected_execution[0][1][1])
    python = {"collection_count": len(ids), "execution_collection_count": int(collected_execution[0][1][1]), "passed": int(pytest_m[1]), "failed": 0, "skipped": 0, "xfailed": 0, "xpassed": 0, "duration_seconds": float(pytest_m[2]), "collection_ids_file": f"python-collected-ids-{label}.json", "execution_command_evidence": reference(execute_i), "summary_evidence": reference(pytest_i), "scope": "Anchored real outer pytest terminal summary, scoped after the actual execution command; poison-fixture parameter IDs and collection text do not count as execution summaries."}

    strict = [block(c) for c in clippy_commands]
    assert all(x["status"] == "COMPLETED_VERIFIER_CONTINUED" and x["finished_profiles"] for x in strict)
    assert all("-D warnings" in x["command"] for x in strict)
    modes = [block(c) for c in native_commands]
    for index, row in enumerate(modes):
        if row["status"] == "COMPLETED_VERIFIER_CONTINUED":
            assert len(row["test_results"]) == 3 and all(x["failed"] == x["ignored"] == x["measured"] == x["filtered_out"] == 0 for x in row["test_results"])
            assert row["test_results"][0]["passed"] > 0 and [x["passed"] for x in row["test_results"]][1:] == [0, 0]
            start = row["command_evidence"]["line"] - 1
            end = row["next_command_evidence"]["line"] - 1
            passed_ids = [m[1] for _, m in found(r"test (\S+) \.\.\. ok", start + 1, end)]
            assert len(passed_ids) == row["test_results"][0]["passed"]
            native_ids[(label, index)] = passed_ids
    if label == "windows-2025":
        assert [x["status"] for x in modes] == ["COMPLETED_VERIFIER_CONTINUED", "STARTED_INTERRUPTED", "NOT_STARTED_IN_RETAINED_LOG"]
    else:
        assert all(x["status"] == "COMPLETED_VERIFIER_CONTINUED" for x in modes)
    final_build = block("$ cargo build --locked --manifest-path apps/desktop/src-tauri/Cargo.toml")
    if label != "windows-2025":
        assert final_build["status"] == "COMPLETED_VERIFIER_CONTINUED" and final_build["finished_profiles"]
    else:
        assert final_build["status"] == "NOT_STARTED_IN_RETAINED_LOG"

    platforms.append({**binding, "started_at": job["started_at"], "completed_at": job["completed_at"], "aggregate_step": next(s for s in job["steps"] if s["number"] == 25), "doctor": doctor_row, "suite_rows": suite_rows, "reported_suite_count": len(summary_start) * 20, "reported_suite_pass_count": sum(x["result"] == "PASS" for x in suite_rows), "verification_exit_code": int(exits[0][1][1]) if exits else None, "verification_exit_evidence": reference(exits[0][0]) if exits else None, "unit_ts": unit, "playwright": browser, "python": python, "strict_clippy": strict, "desktop_native_test_modes": modes, "desktop_native_final_build": final_build, "rust_registry_commands": [block(c) for c in rust_commands]})

posix_ids = collections.Counter(collection_ids["ubuntu-24.04"])
assert posix_ids == collections.Counter(collection_ids["macos-15"])
windows_ids = collections.Counter(collection_ids["windows-2025"])
python_difference = {"posix_count": sum(posix_ids.values()), "windows_count": sum(windows_ids.values()), "posix_only_visible_occurrences": list((posix_ids - windows_ids).elements()), "windows_only_visible_occurrences": list((windows_ids - posix_ids).elements()), "scope": "Actual visible collected-node-line multiset difference. GitHub masks twelve auth-test parameter lines to a repeated *** prefix; unique unredacted-ID equality is unavailable. Actual anchored outer collection/execution summaries establish counts. No unobserved skips, omissions, or explanation is invented."}
native_difference = {"default_mode_counts": {label: len(native_ids[(label, 0)]) for label in collection_ids}, "relative_to_windows": {label: {"other_only_ids": sorted(set(native_ids[(label, 0)]) - set(native_ids[("windows-2025", 0)])), "windows_only_ids": sorted(set(native_ids[("windows-2025", 0)]) - set(native_ids[(label, 0)]))} for label in ["ubuntu-24.04", "macos-15"]}, "macos_only_relative_to_ubuntu": sorted(set(native_ids[("macos-15", 0)]) - set(native_ids[("ubuntu-24.04", 0)])), "ubuntu_only_relative_to_macos": sorted(set(native_ids[("ubuntu-24.04", 0)]) - set(native_ids[("macos-15", 0)])), "scope": "Actual completed default-mode Rust test-name set differences, including the additional macOS bounded-reader test. No Windows all-features result is inferred."}
annotations_path = "commands/0044-terminal-windows-check-annotations.stdout"
annotations = read_json(annotations_path)
assert any(x["message"] == "The job has exceeded the maximum execution time of 1h0m0s" for x in annotations)
cancellation = {"official_cause": "The job has exceeded the maximum execution time of 1h0m0s", "annotation_file": annotations_path, "annotation_sha256": sha((ROOT / annotations_path).read_bytes()), "annotations": annotations, "scope": "Cause is explicitly emitted by GitHub's completed check-run annotations, not inferred solely from wall-clock duration. Triggering actor metadata is not a cancellation actor."}
source_final = {"head_sha": HEAD, "head_tree_sha": TREE, "actual_checkout_sha": bindings["platforms"][0]["actual_checkout_sha"], "actual_checkout_tree": TREE, "all_three_job_logs_identify_actual_checkout": True, "actual_checkout_commit_differs_from_head": bindings["platforms"][0]["actual_checkout_sha"] != HEAD, "all_actual_content_trees_match": True, "source_preparation": read_json("source-binding-preparation.json"), "actual_log_binding_manifest": "platform-logs-manifest.json", "scope": "Source preparation's earlier pending-checkout fields remain historical. Final actual checkout comes from closed full official logs and its immutable Git API object, not from assuming checkout of PR head."}
save("source-binding-final.json", source_final)
summary = {"run_id": RUN_ID, "run_attempt": 1, "head_sha": HEAD, "expected_source_tree": TREE, "run_status": run["status"], "run_conclusion": run["conclusion"], "run_url": run["html_url"], "all_three_hosts_pass": False, "registry_suite_ids": suite_ids, "source_binding": source_final, "platforms": platforms, "python_platform_difference": python_difference, "native_default_mode_platform_difference": native_difference, "windows_cancellation": cancellation, "official_complete_logs_zip": read_json("official-logs-manifest.json")["zip"], "initial_capture_limitation": read_json("initial-artifact-provenance.json"), "scope": {"native_gui_credit": False, "platform_packaging_credit": False, "windows_11_packaged_credit": False, "local_v4_result_transfer": False, "prior_ci_result_transfer": False, "summary": "Read-only exact-source hosted execution evidence. Cargo modes test native Rust backend configurations; browser visual checks cover frontend behavior. Windows aggregate cancellation leaves unfinished native modes and final suites unvalidated; successful Ubuntu/macOS do not substitute for them."}, "analyzed_at_utc": dt.datetime.now(dt.timezone.utc).isoformat()}
save("hosted-ci-summary.json", summary)
review = [f"# Hosted CI {RUN_ID}: CANCELLED", "", f"Head `{HEAD}`, source tree `{TREE}`. All three official job logs identify actual PR merge checkout `{source_final['actual_checkout_sha']}` with the same source tree. Complete official ZIP and all 85 safely extracted regular members are retained.", "", "| Host | Job result | Terminal suite results | Python | Desktop native test modes |", "|---|---|---|---|---|"]
for row in platforms:
    counts = "/".join(str(mode.get("test_results", [{}])[0].get("passed", "unfinished")) if mode.get("test_results") else mode["status"] for mode in row["desktop_native_test_modes"])
    review.append(f"| {row['label']} | {row['job_conclusion']} | {row['reported_suite_pass_count']}/20 PASS rows emitted | {row['python']['passed']} passed, zero skips | {counts} |")
review += ["", "All three doctors report 28 pass, zero warning/fail/not-yet-applicable. Each host completed 15 root unit-TS workspace summaries, 256 default browser tests, 2 controlled public-research tests, 62 controlled public-contact tests, and 3 visual browser tests with zero reported failures/skips. Exact counts, commands, raw timestamped evidence and normalized line references are in hosted-ci-summary.json.", "", "All three strict Clippy commands (native-host, contract harness and desktop) completed on each host with `-D warnings`, finished profiles, and subsequent Rust commands. Individual command exit values are inferred as zero from the frozen verifier's stop-on-nonzero control flow; separate per-command process exits are not printed in the hosted logs.", "", "Windows completed the default desktop native command with 70 library tests plus zero-test successful main/doc targets. Its all-features command began at 01:35:48.429Z and was interrupted; no output or exit completion for that command is credited. The dependency-only `tauri/custom-protocol` mode and final desktop build were not started in the retained log. Portability, traceability, status, integrity and the complete 20-suite verdict table were not reached/reported; no Windows terminal suite PASS rows are reconstructed.", "", "GitHub's final check-run annotations explicitly state: The job has exceeded the maximum execution time of 1h0m0s. The log also retains KeyboardInterrupt and The operation was canceled. This is official cancellation evidence, not an inferred product failure. Root must diagnose the actual aggregate duration before claiming completion.", "", "Ubuntu and macOS completed all 20 ACTIVE suites with verification exit code 0. Their three desktop native Cargo modes completed 76 library tests per mode on Ubuntu and 77 per mode on macOS, with zero-failure main/doc targets, followed by each native build. This supplies no native GUI or platform packaging certification, and Windows Server 2025 is not Windows 11 packaged-target proof.", "", "Python outer collection and execution summaries report 1650 on Ubuntu/macOS and 1648 on Windows, zero skips/failures. The visible collected-node-line multiset differs by two POSIX cases. GitHub masks twelve authorization-test parameter lines to repeated *** prefixes, so unique unredacted node-ID equality cannot be established from hosted logs. The masked lines and actual count summaries are preserved without reconstruction.", "", "The initial TLS failure has only the original empty initial-run.json and a reported chat-tool failure description. Its original standalone stderr/transcript is unavailable and has not been reconstructed. Later successful metadata collection attempts, including actual exit records, remain separate from workflow attempt 1. Earlier CI and local v4 results are separate evidence and are not transferred.", "", "The finite archive manifest binds all retained raw API command output, stderr, exits, source blobs, complete ZIP, full platform logs and analysis files. No workflow was dispatched/retried/cancelled, and no native actor was run by this collector."]
(ROOT / "review.md").write_text("\n".join(review) + "\n")
print(json.dumps({"run": RUN_ID, "conclusion": run["conclusion"], "platforms": [{"host": p["label"], "job": p["job_conclusion"], "suite_pass_rows": p["reported_suite_pass_count"], "unit_ts": p["unit_ts"]["passed"], "python": p["python"]["passed"], "native_modes": [{"status": m["status"], "passed": [r["passed"] for r in m.get("test_results", [])]} for m in p["desktop_native_test_modes"]]} for p in platforms], "python_difference": python_difference, "native_default_difference": native_difference, "windows_cause": cancellation["official_cause"]}, indent=2))
