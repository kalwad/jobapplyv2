import datetime as dt,json,pathlib,subprocess,sys,time
from collect_hosted_ci import ROOT,sha
assert len(sys.argv)>=4
label=sys.argv[1];argv=sys.argv[2:]
folder=ROOT/'operations';folder.mkdir(exist_ok=True)
number=len(list(folder.glob('*.record.json')))+1
stem='{:04d}-{}'.format(number,label)
started=dt.datetime.now(dt.timezone.utc).isoformat();tick=time.monotonic()
p=subprocess.run(argv,cwd=str(ROOT),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
ended=dt.datetime.now(dt.timezone.utc).isoformat()
out=folder/(stem+'.stdout');err=folder/(stem+'.stderr')
assert not out.exists() and not err.exists()
out.write_bytes(p.stdout);err.write_bytes(p.stderr)
r={'argv':argv,'cwd':str(ROOT),'started_at_utc':started,'ended_at_utc':ended,'elapsed_seconds':time.monotonic()-tick,'exit_code':p.returncode,'stdout':{'path':str(out.relative_to(ROOT)),'bytes':len(p.stdout),'sha256':sha(p.stdout)},'stderr':{'path':str(err.relative_to(ROOT)),'bytes':len(p.stderr),'sha256':sha(p.stderr)},'scope':'Documentary collection/extraction/analysis operation, separate from nested captured read-only API commands; no native actor.'}
(folder/(stem+'.record.json')).write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
if p.stdout:print(p.stdout.decode('utf-8',errors='replace')[:16000])
if p.stderr:print(p.stderr.decode('utf-8',errors='replace')[:16000],file=sys.stderr)
raise SystemExit(p.returncode)
