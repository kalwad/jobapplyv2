import io,json,pathlib,stat,zipfile
from collect_hosted_ci import ROOT,REPO,RUN_ID,HEAD,TREE,api,capture,sha

snapshot=json.loads(sorted(ROOT.glob('snapshot-*.json'))[-1].read_text())
assert snapshot['run_status']=='completed'
assert len(snapshot['jobs'])==3 and all(j['status']=='completed' for j in snapshot['jobs'])
attempt=snapshot['run_attempt']
for name,record in [('final-run.json',snapshot['run_record']),('final-jobs.json',snapshot['jobs_record'])]:
 data=(ROOT/record['stdout']['path']).read_bytes()
 assert len(data)==record['stdout']['bytes'] and sha(data)==record['stdout']['sha256']
 assert not (ROOT/name).exists();(ROOT/name).write_bytes(data)
attempt_data,ar=api('repos/{}/actions/runs/{}/attempts/{}'.format(REPO,RUN_ID,attempt),'terminal-attempt-metadata')
assert attempt_data['id']==RUN_ID and attempt_data['head_sha']==HEAD and attempt_data['run_attempt']==attempt and attempt_data['status']=='completed'
(ROOT/'final-attempt.json').write_bytes((ROOT/ar['stdout']['path']).read_bytes())
zip_bytes,zr=capture(['/opt/homebrew/bin/gh','api','-H','Accept: application/vnd.github+json','repos/{}/actions/runs/{}/attempts/{}/logs'.format(REPO,RUN_ID,attempt)],'official-complete-logs-zip')
zip_path=ROOT/'logs.zip';assert not zip_path.exists();zip_path.write_bytes(zip_bytes)
folder=ROOT/'official-logs';assert not folder.exists();folder.mkdir()
rows=[];seen=set();case_seen=set()
with zipfile.ZipFile(io.BytesIO(zip_bytes)) as archive:
 infos=archive.infolist();assert len(infos)<=2000
 assert sum(x.file_size for x in infos)<=1024*1024*1024
 for info in infos:
  raw=info.filename
  p=pathlib.PurePosixPath(raw)
  assert raw and '\\' not in raw and '\x00' not in raw and not p.is_absolute() and '..' not in p.parts
  assert raw not in seen and raw.casefold() not in case_seen
  seen.add(raw);case_seen.add(raw.casefold())
  mode=info.external_attr>>16
  assert not stat.S_ISLNK(mode)
  assert info.file_size<=256*1024*1024
  if info.is_dir():
   (folder/pathlib.Path(*p.parts)).mkdir(parents=True,exist_ok=True)
   continue
  data=archive.read(info)
  assert len(data)==info.file_size
  target=folder/pathlib.Path(*p.parts);target.parent.mkdir(parents=True,exist_ok=True)
  assert not target.exists();target.write_bytes(data)
  rows.append({'path':raw,'bytes':len(data),'sha256':sha(data),'compressed_bytes':info.compress_size,'crc32_hex':'{:08x}'.format(info.CRC)})
manifest={'run_id':RUN_ID,'run_attempt':attempt,'head_sha':HEAD,'expected_tree_sha':TREE,'official_api_endpoint':zr['argv'][-1],'zip':{'path':'logs.zip','bytes':len(zip_bytes),'sha256':sha(zip_bytes),'command_stdout':zr['stdout']['path']},'safe_regular_file_count':len(rows),'zip_entry_count':len(infos),'files':rows,'all_members_read_with_crc_validation':True,'scope':'Official complete workflow-attempt logs ZIP, safely extracted as exact bytes. No truncated gh --log-failed output is used.'}
(ROOT/'official-logs-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'terminal_status':snapshot['run_status'],'conclusion':snapshot['run_conclusion'],'zip_bytes':len(zip_bytes),'zip_sha256':sha(zip_bytes),'members':len(rows),'root_log_members':[x['path'] for x in rows if '/' not in x['path']]},indent=2))
