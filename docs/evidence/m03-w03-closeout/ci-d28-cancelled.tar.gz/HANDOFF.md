# Read-only hosted CI handoff

Run 39181477863, attempt 1, is terminal **CANCELLED**. Exact head is `d28cfc70feda604c508bc18c778992a0ca559e5a`; expected content tree is `e72a0523d4b3183b5a658ccd74ce02a8dbd4b8e8`. Actual checkout in all three official full logs is PR merge `73f1695530705f88b29f2f5918580e7a7f527c4a`; its immutable Git API object binds the same tree.

| Host | Actual job | Final suite rows | Python | Default/all-features/dependency-only desktop Rust |
|---|---|---|---|---|
| Ubuntu 24.04 | SUCCESS | 20 ACTIVE PASS, exit 0 | 1650 passed, zero skips | 76/76/76; all main/doc targets also succeed; final native build completes |
| macOS 15 | SUCCESS | 20 ACTIVE PASS, exit 0 | 1650 passed, zero skips | 77/77/77; all main/doc targets also succeed; final native build completes |
| Windows 2025 | CANCELLED | No final suite table or verifier exit emitted | 1648 passed, zero skips | default70 succeeds; all-features interrupted; dependency-only mode and final build not started |

Every host has actual doctor 28 PASS, root unit-TS 3937 PASS across 15 workspace summaries, default browser 256 PASS, controlled research2 PASS, controlled contact62 PASS, and browser visual3 PASS. These observations do not reconstruct absent Windows terminal suite results. All three strict Clippy commands completed on each host. Exit zero is an explicit control-flow inference from the frozen verifier's break-on-nonzero rule and subsequent command execution; raw logs do not print each child exit separately.

Windows official check-run annotation: **The job has exceeded the maximum execution time of 1h0m0s**. The annotations are retained at `commands/0044-terminal-windows-check-annotations.stdout`, SHA256 `30224b1bd53aace69caed3a81443dea9540c0bbfc1a7818d7956b727dbba7711`. Aggregate step25 is cancelled, final cleanliness step26 skipped. Default native test completion was followed by the all-features command at 01:35:48.429Z, KeyboardInterrupt at 01:35:53.449Z and cancellation at 01:35:54.005Z. No three-platform completion claim is supported.

The official complete `logs.zip` is 1,334,148 bytes, SHA256 `55e169cab63cbb3877b298d8b60620658b275022de69e3747f1fe1d6ba2f2332`. All 85 safely extracted regular members were read with CRC verification, and full platform copies match the official combined-log bytes. `official-logs-manifest.json` binds every member. `platform-logs-manifest.json` binds checkout evidence and complete combined copies. `hosted-ci-summary.json` contains exact command blocks, normalized line references and original timestamped evidence. `source-binding-final.json` joins final actual checkout to the earlier 1,797-entry immutable source comparison and 15 selected exact source blobs.

All 44 captured read-only command records exited0. `retained-input-audit.json` passed finite raw-output/hash/ZIP/source/summary checks. Five documentary analysis/audit failures remain with actual stderr/exit records and source preimages; they are disclosed in `collector-analysis-limitations.json`, followed by corrected analysis operation0015 and audit0017 exit0. None caused a CI retry or workflow mutation. The audit's own operation0017 record is also included in the finite archive.

The original empty `initial-run.json` and successful later metadata collection artifacts are unchanged. Original standalone TLS stderr is unavailable and has not been reconstructed. GitHub masks twelve authorization parameter lines, so visible node-line occurrences and actual outer counts are retained without claiming unique unredacted-ID equality. Python POSIX-only visible cases are FIFO/socket migration cases. Native default-mode names differ by six Ubuntu-vs-Windows cases plus one additional macOS bounded-reader case; exact differences are in the summary.

This collector ran no native/browser/build/test actor and changed no repository file, workflow, run or job. The evidence supplies no GUI, platform packaging, Windows11 product certification, prior-CI result transfer or local-v4 result transfer.

The finite sealed archive is written beside this directory at `/tmp/japp-m03-w03-hosted-ci-d28cfc7-20261019-retained/proof.tar.gz`. Its exact bytes, SHA256, member count and input-manifest hash are in the adjacent `manifest.json`; the archive's `evidence-inputs.json` enumerates every retained member before sealing.
