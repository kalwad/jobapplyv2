"""Offline retention binding only; imports standard library, no project code."""
from pathlib import Path, PurePosixPath
from collections import Counter
import hashlib
import json
import stat
import subprocess
import tarfile

ROOT=Path('/Users/tanishkalwad/jobapplyv2')
STORE=Path('/Users/tanishkalwad/jobapplyv2-evidence/m03-w03-ci-retry-tooling-20261019')
REMOTE=Path('/tmp/japp-m03-w03-ci-retry-tooling-retained-20261019')
OUT=Path(__file__).parent
AUTHOR=Path('/tmp/japp-m03-w03-ci-performance-preparation-20261019')
SCAN=Path('/tmp/japp-m03-w03-independent-bounded-scan-review-20261019')
TEMP=Path('/tmp/japp-m03-w03-ci-owned-temp-proposal-20261019-retained')
TEMPREVIEW=Path('/tmp/japp-m03-w03-ci-owned-temp-independent-review-20261019')
BASE='d28cfc70feda604c508bc18c778992a0ca559e5a'
TREE='e72a0523d4b3183b5a658ccd74ce02a8dbd4b8e8'
PREFIX='m03-w03-ci-retry-tooling-20261019/'
checks=[]
def check(name,condition,detail=None):
    checks.append({'name':name,'pass':bool(condition),'detail':detail})
    if not condition:
        raise AssertionError(name+': '+str(detail))
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def dig(p):
    info=p.lstat();check('regular file '+str(p),stat.S_ISREG(info.st_mode) and not p.is_symlink())
    h=hashlib.sha256();g=hashlib.sha1(('blob '+str(info.st_size)+'\0').encode())
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b);g.update(b)
    return {'bytes':info.st_size,'sha256':h.hexdigest(),'git_blob':g.hexdigest(),'mode':stat.S_IMODE(info.st_mode)}
def safe(name):
    p=PurePosixPath(name)
    return bool(name) and not p.is_absolute() and '..' not in p.parts and '\\' not in name and str(p)==name
def git(args,name):
    r=subprocess.run(['git',*args],cwd=ROOT,capture_output=True)
    (OUT/(name+'.stdout')).write_bytes(r.stdout);(OUT/(name+'.stderr')).write_bytes(r.stderr)
    check('readonly git '+name,r.returncode==0)
    return r.stdout
before_head=git(['rev-parse','HEAD'],'root-head-before').decode().strip()
before_status=git(['status','--porcelain=v1'],'root-status-before').decode()
check('root remains clean exact old source before review',before_head==BASE and before_status=='')
check('immutable old tree identity',git(['rev-parse',BASE+'^{tree}'],'base-tree').decode().strip()==TREE)
tree={}
for line in git(['ls-tree','-r','-z','--full-tree',BASE],'base-git-tree').split(b'\0'):
    if not line:continue
    header,name=line.split(b'\t',1);mode,kind,blob=header.decode().split();tree[name.decode()]={'mode':mode,'kind':kind,'blob':blob}
check('exact1797 old Git blob leaves',len(tree)==1797 and all(r['kind']=='blob' for r in tree.values()))

outer=load(REMOTE/'ci-retry-tooling-selected.manifest.json')
check('exact handoff digest',sha((STORE/'HANDOFF.md').read_bytes())=='e66d98ca33726056b373992a3bd005ddc31d208ec65b0350a8f00d3f0498af81')
check('exact adjacent selected manifest',sha((REMOTE/'ci-retry-tooling-selected.manifest.json').read_bytes())=='9650cab167c22751dac52f8df3e59b9c8b0651ef31d170fd8923dd961e4a65f5')
archive=REMOTE/'ci-retry-tooling-selected.tar.gz';ad=dig(archive)
check('exact selected archive digest and bytes',ad['sha256']=='7c87d8c4d9b106a4e7d19408e1244f74daa7a4266b69d87c2c10993211e9da2c'==outer['archive_sha256'] and ad['bytes']==3951506==outer['archive_bytes'])
for key,name in [('selection_sha256','selection.json'),('omissions_sha256','remote-omissions.json'),('retention_manifest_sha256','retention-manifest.json'),('handoff_sha256','HANDOFF.md'),('collector_sha256','collector.py')]:
    check('outer binds '+name,sha((STORE/name).read_bytes())==outer[key])
local_manifest=load(STORE/'retention-manifest.json')['files']
local_paths={r['path'] for r in local_manifest}
actual_local={str(p.relative_to(STORE)) for p in STORE.rglob('*') if p.is_file()}
check('local retention manifest exhaustive except itself',len(local_paths)==len(local_manifest)==1828 and actual_local==local_paths|{'retention-manifest.json'})
local_results={}
for r in local_manifest:
    check('safe local manifest path '+r['path'],safe(r['path']))
    d=dig(STORE/r['path']);local_results[r['path']]=d
    check('local bytes digest mode '+r['path'],d['bytes']==r['bytes'] and d['sha256']==r['sha256'] and d['mode']==r['mode']==0o444)
check('no local symlink or unexpected directory contents',all(not p.is_symlink() for p in STORE.rglob('*')))
cas={name.split('/',1)[1]:r for name,r in local_results.items() if name.startswith('blobs/')}
check('1818 exact content-addressed blobs',len(cas)==1818 and all(k==r['sha256'] for k,r in cas.items()))

remote_rows=outer['members'];expected={PREFIX+r['path']:r for r in remote_rows}
check('outer member inventory202 unique paths',len(expected)==len(remote_rows)==202)
tar_bodies={};names=set();folded=set()
with tarfile.open(archive,'r:gz') as t:
    members=t.getmembers();check('selected tar actual202 members',len(members)==202)
    for m in members:
        check('safe unique regular selected member '+m.name,safe(m.name) and m.isfile() and not m.issym() and not m.islnk() and m.name not in names and m.name.casefold() not in folded and m.name in expected)
        names.add(m.name);folded.add(m.name.casefold());b=t.extractfile(m).read();r=expected[m.name]
        check('selected tar full readback '+m.name,len(b)==m.size==r['bytes'] and sha(b)==r['sha256'] and m.mode==r['mode']==0o444 and b==(STORE/r['path']).read_bytes())
        tar_bodies[r['path']]=b
check('selected tar exact declared membership',names==set(expected))
remote_blobs={p.split('/',1)[1] for p in tar_bodies if p.startswith('blobs/')}
check('191selected blobs plus11 bookkeeping files',len(remote_blobs)==191 and len(tar_bodies)-len(remote_blobs)==11)

selection=load(STORE/'selection.json')['records'];by_original={r['original']:r for r in selection}
check('2244 aliases unique actual original names',len(selection)==len(by_original)==2244)
check('2172original files plus72 logical archive members',Counter(r['kind'] for r in selection)=={'original-file':2172,'logical-archive-member':72})
alias_results=[]
for r in selection:
    d=cas[r['sha256']]
    check('alias complete durable content '+r['original'],r['durable_relative']=='blobs/'+r['sha256'] and r['durable_full_copy']==str(STORE/r['durable_relative']) and d['bytes']==r['bytes'] and oct(r['mode'])==r['mode_octal'])
    check('alias remote flag from actual selected content '+r['original'],r['remote_included_by_content']==(r['sha256'] in remote_blobs))
    if r['kind']=='original-file':
        actual=dig(Path(r['original']))
        check('original alias exact present source bytes mode '+r['original'],actual['sha256']==r['sha256'] and actual['bytes']==r['bytes'] and actual['mode']==r['mode'])
    if r['git_recovery'] is not None:
        g=r['git_recovery'];old=tree[g['path']]
        check('alias immutable old Git recovery '+r['original'],g['commit']==BASE and g['tree']==TREE and old['blob']==g['git_blob']==d['git_blob'] and old['mode']==g['git_mode'] and g['sha256']==r['sha256'] and g['bytes']==r['bytes'])
    alias_results.append({'original':r['original'],'sha256':r['sha256'],'bytes':r['bytes'],'remote':r['sha256'] in remote_blobs,'kind':r['kind']})
check('CAS exactly covers all alias content with no unbound bodies',set(cas)=={r['sha256'] for r in selection})
omissions=load(STORE/'remote-omissions.json')
actual_omissions=[r for r in selection if not r['remote_included_by_content']]
check('1742omissions exact records and1627unique bodies',omissions['records']==actual_omissions and len(actual_omissions)==omissions['original_path_count']==1742 and len({r['sha256'] for r in actual_omissions})==omissions['unique_blob_count']==1627 and omissions['never_a_complete_remote_source_image'] is True)
check('all omissions have durable bytes and exact old Git identity',all(r['git_recovery'] is not None and r['durable_relative'] in local_results for r in actual_omissions))

author_index=load(AUTHOR/'retention-manifest.json');source_index=load(AUTHOR/'source-manifest.json')
check('author original1959 index plus1798source leaves',len(author_index)==1959 and len(source_index)==1798)
source_records={n[7:]:r for n,r in author_index.items() if n.startswith('source/')}
check('author source index exact projection',source_records==source_index)
source_actual={str(p.relative_to(AUTHOR/'source')) for p in (AUTHOR/'source').rglob('*') if p.is_file()}
check('proposed source complete actual1798 files',source_actual==set(source_index))
author_aliases={r['original']:r for r in selection if 'frozen-bounded-scan-author-1959' in r['roles']}
check('all1959author indexed files exactly selected aliases',set(author_aliases)=={str(AUTHOR/n) for n in author_index})
changed=[];unchanged=[]
for name,r in author_index.items():
    a=author_aliases[str(AUTHOR/name)]
    check('author original index bytes/hash '+name,a['sha256']==r['sha256'] and a['bytes']==r['bytes'])
    if name.startswith('source/'):
        rel=name[7:]
        if a['git_recovery'] is None:changed.append(rel)
        else:unchanged.append(rel)
    else:check('all nonsource author evidence remotely included '+name,a['sha256'] in remote_blobs)
check('exact1796unchanged2changed-new source leaves',len(unchanged)==1796 and set(changed)=={'scripts/validate_status.py','scripts/tests/test_status_scan_streaming.py'})
check('changed and new source both selected remotely',all(author_aliases[str(AUTHOR/'source'/n)]['sha256'] in remote_blobs for n in changed))
check('original author index itself selected remotely',by_original[str(AUTHOR/'retention-manifest.json')]['sha256'] in remote_blobs)
scan_index=load(SCAN/'retention-manifest.json')['records']
scan_actual={str(p.relative_to(SCAN)) for p in SCAN.rglob('*') if p.is_file()}
check('bounded review184records plusindex185actual files',len(scan_index)==184 and scan_actual=={r['path'] for r in scan_index}|{'retention-manifest.json'})
for r in scan_index:
    a=by_original[str(SCAN/r['path'])]
    check('bounded review original record remote '+r['path'],a['sha256']==r['sha256'] and a['bytes']==r['bytes'] and a['sha256'] in remote_blobs)
check('bounded review own original index included',by_original[str(SCAN/'retention-manifest.json')]['sha256'] in remote_blobs)

temp=TEMP/'proof.tar.gz';td=dig(temp);tm=load(TEMP/'manifest.json');nested=load(STORE/'owned-temp-archive-member-bindings.json')
check('exact owned-temp author archive and original manifest',td['sha256']==tm['sha256']==nested['sha256']=='cbf266068eeac6d48d63205a24e61a119e96febe627395d55d0fe0e92cc08076' and td['bytes']==tm['bytes']==nested['bytes']==416957 and tm['regular_members']==72)
check('exact owned-temp archive itself remote selected',by_original[str(temp)]['sha256'] in remote_blobs and by_original[str(TEMP/'manifest.json')]['sha256'] in remote_blobs)
logical={r['member']:r for r in selection if r['kind']=='logical-archive-member'};nested_rows={r['member']:r for r in nested['safe_regular_members']}
with tarfile.open(temp,'r:gz') as t:
    members=t.getmembers();check('all72actual owned-temp logical members bound',len(members)==len(logical)==len(nested_rows)==72 and {m.name for m in members}==set(logical)==set(nested_rows))
    seen=set();fold=set()
    for m in members:
        check('safe unique regular owned-temp member '+m.name,safe(m.name) and m.isfile() and not m.issym() and not m.islnk() and m.name not in seen and m.name.casefold() not in fold)
        seen.add(m.name);fold.add(m.name.casefold());b=t.extractfile(m).read();a=logical[m.name];n=nested_rows[m.name]
        check('complete owned-temp logical durable and remote binding '+m.name,len(b)==m.size==a['bytes']==n['bytes'] and sha(b)==a['sha256']==n['sha256'] and m.mode==a['mode']==n['mode'] and a['parent_archive_sha256']==td['sha256'] and a['original']==str(temp)+'!'+m.name and n['durable_relative']==a['durable_relative'] and b==(STORE/a['durable_relative']).read_bytes() and a['sha256'] in remote_blobs)
temp_review_index=load(TEMPREVIEW/'retention-manifest.json');temp_review_actual={str(p.relative_to(TEMPREVIEW)) for p in TEMPREVIEW.rglob('*') if p.is_file()}
check('owned-temp independent24records plusindex complete',len(temp_review_index)==24 and temp_review_actual==set(temp_review_index)|{'retention-manifest.json'})
for name,r in temp_review_index.items():
    a=by_original[str(TEMPREVIEW/name)]
    check('owned-temp independent original record remotely included '+name,a['sha256']==r['sha256'] and a['bytes']==r['bytes'] and a['sha256'] in remote_blobs)
check('owned-temp independent own index remotely included',by_original[str(TEMPREVIEW/'retention-manifest.json')]['sha256'] in remote_blobs)

limits=load(STORE/'provenance-limits.json');sf=load(SCAN/'findings.json');tf=load(TEMPREVIEW/'findings.json')
check('old323PASS and352PASS3FAIL and1FAIL2PASS outcomes retained distinctly',limits['observed_scope']['final_focused']==sf['actual_scoped_result'] and sf['actual_scoped_result'].startswith('323') and limits['observed_scope']['overbroad']==sf['actual_broader_result'] and sf['actual_broader_result'].startswith('352 PASS3') and limits['observed_scope']['old_RED']==sf['actual_old_bounded_read_RED'] and sf['actual_old_bounded_read_RED'].startswith('1FAIL2PASS'))
check('owned-temp source-only8lines review remains exact',tf['only8inserted_lines_two_step_envs'] is True and tf['base_sha']==BASE and tf['base_tree']==TREE and tf['archive_sha256']==td['sha256'] and tf['no_actual_performance_or_CI_or_native_certification_credit'] is True)
missing='a11f1f9c88c9329755e39154ff693a639c1c91c916c2fb3021cd56876d4c8059'
check('missing historical plugin not reconstructed retained or remotely implied',limits['missing_historical_plugin_body']['unretained_source_sha256']==missing and missing not in cas and missing not in remote_blobs and limits['missing_body_not_reconstructed_or_claimed_retained'] is True)
caches={n:r for n,r in author_index.items() if n.startswith('.ruff_cache/')}
check('three306bytecache bodies actually included local and remote',len(caches)==3 and sum(r['bytes'] for r in caches.values())==306 and all(author_aliases[str(AUTHOR/n)]['sha256'] in remote_blobs for n in caches) and limits['tiny_Ruff_cache_exception']['bytes']==306)
check('retrospective environment and no actor credits remain explicit','not an upfront image' in limits['retrospective_dependency_environment'] and limits['no_current_CI_native_or_full_run_claim'] is True and 'Excluded entirely' in limits['ongoing_root_retry_candidate'] and outer['current_candidate_or_CI_native_or_Windows_credit'] is False and 'SELECTED' in outer['scope'])

snapshots=[load(REMOTE/n) for n in ['tracked-before.json','tracked-after.json','tracked-final.json']]+[load(STORE/n) for n in ['tracked-before.json','tracked-after.json']]
check('collector all5source snapshots byte-data identical',all(s==snapshots[0] for s in snapshots) and snapshots[0]['head']==BASE and snapshots[0]['tree']==TREE and snapshots[0]['status']=='')
baseline={r['path']:r for r in snapshots[0]['tracked']};check('collector1797snapshot exact old Git identity set',set(baseline)==set(tree))
for name,r in baseline.items():
    t=tree[name];d=dig(ROOT/name)
    check('current root exact tracked bytes modes old Git '+name,r['git_blob']==t['blob']==d['git_blob'] and r['git_mode']==t['mode'] and r['bytes']==d['bytes'] and r['sha256']==d['sha256'] and r['mode']==d['mode'] and r['stage']=='0')
check('root remains old d28 clean after read-only review',git(['rev-parse','HEAD'],'root-head-after').decode().strip()==BASE and git(['status','--porcelain=v1'],'root-status-after').decode()=='')

(OUT/'alias-bindings.json').write_text(json.dumps(alias_results,indent=2)+'\n')
result={'verdict':'CLEAR_RETENTION_BINDING_ONLY','reviewer':'/root/delegated_acceptance_audit','passed_checks':len(checks),'failed_checks':0,'root_commit':BASE,'root_tree':TREE,'root_clean_1797_bytes_modes_Git_verified':True,'selected_archive':{'path':str(archive),'sha256':ad['sha256'],'bytes':ad['bytes'],'safe_regular_members':202},'original_and_logical_aliases':2244,'durable_CAS_blobs':1818,'selected_remote_CAS_blobs':191,'remote_omitted_aliases':1742,'remote_omitted_unique_CAS_blobs':1627,'author_index_present_records':1959,'author_source_files':1798,'old_Git_unchanged_source':1796,'changed_new_source_remote':changed,'bounded_review_complete_files':185,'owned_temp_archive_safe_regular_members':72,'owned_temp_independent_records_plus_index':25,'missing_old_plugin_body':'UNAVAILABLE_NOT_RECONSTRUCTED_NOT_RETAINED','Ruff_caches':{'count':3,'bytes':306,'actually_remote':True},'retrospective_environment':'HASH_MANIFESTS_ONLY_NOT_UPFRONT_IMAGE','ongoing_new_candidate':'EXCLUDED_NO_EVIDENCE_TRANSFER','no_actor_test_build_network_CI_or_rootwrites':True,'does_not_repeat_component_source_reviews':True,'no_performance_CI_Windows_native_package_or_gate_acceptance':True,'checks':checks}
(OUT/'findings.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
