"""Read/hash/Git/static review only. No subject helper is imported or executed."""
import ast
import hashlib
import json
import os
import re
import subprocess
import tarfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/tanishkalwad/jobapplyv2')
PROOF = Path('/tmp/japp-m03-w03-clean-verification-v5-20261019')
RETAINED = Path('/tmp/japp-m03-w03-full-v5-retained-20261019')
DURABLE = Path('/Users/tanishkalwad/jobapplyv2-evidence/m03-w03-full-v5-20261019')
HEAD = '6d3a6b8ccde5b75e12248ae7bbefc473b72922e4'
TREE = '34fcf854cb4a1a452b267a02a05e0c34aeb6f89c'
BASE = 'd28cfc70feda604c508bc18c778992a0ca559e5a'
ARCHIVE = 'fdbd9686ad5e10b9796fab21cf11d6f7bedcc73ec95fc5b72e32df2f976bc414'
MANIFEST = 'c4046cae191f6a1a6aabde5d785b44f541ca8f552d941509830d7394f74704b9'
INPUTS = {}

def sha(payload):
    return hashlib.sha256(payload).hexdigest()

def check(value, reason):
    if not value:
        raise RuntimeError(reason)

def read(path):
    payload = path.read_bytes()
    INPUTS[str(path)] = {'bytes': len(payload), 'sha256': sha(payload)}
    return payload

def data(path):
    return json.loads(read(path))

def git(*args, input_bytes=None):
    p = subprocess.run(['git', *args], cwd=ROOT, input=input_bytes, capture_output=True, check=True)
    return p.stdout

def ls_tree(revision):
    raw = git('ls-tree', '-rz', '--full-tree', revision)
    items = {}
    for line in raw.split(b'\0'):
        if not line:
            continue
        meta, path = line.split(b'\t', 1)
        mode, kind, oid = meta.decode().split()
        check(kind == 'blob' and mode in ('100644', '100755', '120000'), 'unexpected Git entry')
        items[path.decode()] = {'mode': mode, 'oid': oid}
    return items

archive = read(RETAINED / 'full-v5-selected.tar.gz')
check(len(archive) == 277133 and sha(archive) == ARCHIVE, 'selected archive pin')
check(read(DURABLE / 'full-v5-selected.tar.gz') == archive, 'durable archive byte match')
check(read(DURABLE / 'archive-manifest.json') == read(RETAINED / 'archive-manifest.json'), 'durable outer manifest byte match')
members = {}
with tarfile.open(RETAINED / 'full-v5-selected.tar.gz', 'r:gz') as tar:
    regular = tar.getmembers()
    check(len(regular) == 10, 'ten selected members')
    for member in regular:
        path = PurePosixPath(member.name)
        check(member.isfile() and not path.is_absolute() and '..' not in path.parts and len(path.parts) == 2 and path.parts[0] == 'proof', 'safe regular archive member')
        name = path.parts[1]
        check(name not in members, 'unique archive member')
        members[name] = tar.extractfile(member).read()
        check(len(members[name]) == member.size, 'archive member size')
        check(members[name] == read(PROOF / name), 'selected archive/current proof exact')
check(sha(members['retention-manifest.json']) == MANIFEST, 'selected input manifest pin')
manifest = json.loads(members['retention-manifest.json'])
check(manifest['selected_regular_count'] == len(manifest['files']) == 9 and
      set(manifest['files']) == set(members) - {'retention-manifest.json'}, 'nine record inputs plus manifest')
for name, entry in manifest['files'].items():
    check(len(members[name]) == entry['bytes'] and sha(members[name]) == entry['sha256'], 'selected manifest bytes')
outer = data(RETAINED / 'archive-manifest.json')
check(outer['bytes'] == len(archive) and outer['sha256'] == ARCHIVE and outer['members'] == 10 and outer['input_manifest_sha256'] == MANIFEST, 'outer manifest binding')

before = json.loads(members['before.json'])
after = json.loads(members['after.json'])
check(members['before.json'] == members['after.json'] and before == after, 'source snapshots exact before/after')
check(before['head'] == HEAD and before['tree'] == TREE and before['status'] == '' and len(before['tracked']) == 1798, 'snapshot Git/source identity')
check(git('rev-parse', HEAD + '^{tree}').decode().strip() == TREE, 'immutable tree identity')
entries = ls_tree(HEAD)
check(set(entries) == {row['path'] for row in before['tracked']} and len(entries) == 1798, 'Git/snapshot inventory closure')
ordered = list(entries)
raw = git('cat-file', '--batch', input_bytes=('\n'.join(entries[path]['oid'] for path in ordered) + '\n').encode())
offset = 0
source = {}
for path in ordered:
    end = raw.index(b'\n', offset)
    oid, kind, size = raw[offset:end].decode().split()
    size = int(size)
    check(oid == entries[path]['oid'] and kind == 'blob', 'Git object stream identity')
    offset = end + 1
    payload = raw[offset:offset + size]
    offset += size
    check(raw[offset:offset + 1] == b'\n', 'Git stream framing')
    offset += 1
    source[path] = payload
check(offset == len(raw), 'complete Git stream framing')
snapshot = {row['path']: row for row in before['tracked']}
for path, payload in source.items():
    entry = snapshot[path]
    expected_kind = 'symlink' if entries[path]['mode'] == '120000' else 'regular'
    check(entry['kind'] == expected_kind and entry['bytes'] == len(payload) and entry['sha256'] == sha(payload), 'all1798 exact immutable Git bytes')

old_entries = ls_tree(BASE)
delta = sorted(path for path in set(entries) | set(old_entries) if entries.get(path) != old_entries.get(path))
expected_delta = ['.github/workflows/ci.yml', 'scripts/python-test-inventory.v1.json', 'scripts/tests/test_status_scan_streaming.py', 'scripts/validate_status.py']
check(delta == expected_delta and len(old_entries) == 1797, 'four tooling-only paths d28 to 6d3')
current_before = {'head': git('rev-parse', 'HEAD').decode().strip(), 'status': git('status', '--porcelain=v1', '--untracked-files=all').decode()}
live_matches = None
if current_before == {'head': HEAD, 'status': ''}:
    live_matches = True
    for path, payload in source.items():
        live = ROOT / path
        actual = os.readlink(live).encode() if live.is_symlink() else live.read_bytes()
        if actual != payload:
            live_matches = False
    current_after = {'head': git('rev-parse', 'HEAD').decode().strip(), 'status': git('status', '--porcelain=v1', '--untracked-files=all').decode()}
    check(live_matches and current_before == current_after, 'current6d3 clean exact source')
else:
    current_after = current_before

wrapper = members['executed-wrapper.py'].decode()
ast.parse(wrapper)
env_record = json.loads(members['environment.json'])
check(env_record['wrapper_sha256'] == sha(members['executed-wrapper.py']), 'wrapper reported hash')
cleared = ('JAPP_W13_PERFORMANCE_SAMPLES', 'JAPP_W14_REQUIRE_TARGET_PERFORMANCE', 'JAPP_W14_ARTIFACT_DIRECTORY', 'JAPP_W14_W06_ARTIFACT_DIRECTORY')
check(all(name in wrapper for name in cleared) and 'env.pop(key,None)' in wrapper and "env=os.environ.copy()" in wrapper, 'four overrides cleared normal inherited environment')
check("('doctor',['pnpm','run','doctor'])" in wrapper and "('verify',['pnpm','verify'])" in wrapper, 'plain full invocation without suite/registry override')
check(json.loads(source['package.json'])['scripts']['verify'] == 'uv run python scripts/verify.py', 'package full verify delegation')

commands = json.loads(members['commands.json'])
check(len(commands) == 2 and [r['name'] for r in commands] == ['doctor', 'verify'], 'both top level commands')
for command, expected in zip(commands, [['pnpm', 'run', 'doctor'], ['pnpm', 'verify']]):
    name = command['name']
    check(command['argv'] == expected and command['cwd'] == str(ROOT) and command['exit_code'] == 0, 'actual top-level argv exit')
    log = members[name + '.log']
    check(command['log_bytes'] == len(log) and command['log_sha256'] == sha(log), 'raw log record')
    elapsed = (datetime.fromisoformat(command['ended_at']) - datetime.fromisoformat(command['started_at'])).total_seconds()
    check(abs(elapsed - command['elapsed_seconds']) < 0.1, 'wallclock/monotonic duration agree')
check(commands[1]['elapsed_seconds'] == 1107.8862267500372, 'actual verify duration')
closure = json.loads(members['closure.json'])
check(all(closure[k] for k in ('source_unchanged', 'all_executed_commands_pass', 'both_commands_executed')), 'actual closure')

doctor = members['doctor.log'].decode()
check('summary: 28 pass, 0 warning, 0 fail, 0 not-yet-applicable' in doctor and
      len(re.findall(r'^.+?\s+PASS\s+', doctor, re.M)) == 28, 'doctor actual28')
verify = members['verify.log'].decode()
summary_text = verify.split('== verification summary ==')[-1]
summary = re.findall(r'^([\w-]+)\s+ACTIVE\s+PASS\s*$', summary_text, re.M)
registry = json.loads(source['scripts/verification-suites.json'])
check(summary == [suite['id'] for suite in registry['suites']] and len(summary) == 20 and summary_text.rstrip().endswith('verification exit code: 0'), 'all20 ACTIVE PASS in canonical order')
check(registry['allowed_skips'] == [], 'canonical zero allowed skip inventory')
unit_block = verify.split('$ pnpm exec turbo run test --force -- --reporter=default\n')[1].split('$ pnpm generate:contracts --check\n')[0]
unit_counts = re.findall(r'^(@japp/[^:]+):test:\s+Tests\s+(\d+) passed \((\d+)\)\s*$', unit_block, re.M)
check(len(unit_counts) == 15 and all(a == b for _, a, b in unit_counts) and sum(int(a) for _, a, _ in unit_counts) == 3937, 'unitTS3937 all15 packages')
check('cache hit' not in unit_block and '15 successful, 15 total' in unit_block, 'forced unit executions not replay')
check('cache hit, replaying logs' in verify.split('$ pnpm exec turbo run typecheck\n')[1].split('$ pnpm exec turbo run test')[0], 'typecheck cache scope retained')

collection_block = verify.split('--collect-only -q ', 1)[1].split('\n', 1)[1].split('\n1653 tests collected in 0.36s')[0]
node_ids = [line for line in collection_block.splitlines() if line]
inventory = json.loads(source['scripts/python-test-inventory.v1.json'])
expected_ids = inventory['common']['node_ids'] + inventory['posix_only_node_ids']
check(len(node_ids) == len(set(node_ids)) == 1653 and sorted(node_ids) == sorted(expected_ids), 'exact actual1653 Python node inventory')
check(inventory['common']['count'] == 1651 and sha(('\n'.join(inventory['common']['node_ids']) + '\n').encode()) == inventory['common']['sha256'], 'Python common digest')
check(re.findall(r'^=+ (\d+) passed in ([^\n]+?) =+$', verify, re.M) == [('1653', '368.57s (0:06:08)')], 'Python execution ordinary no skips failures')
check('collected 1653 items' in verify, 'Python actual collection execution')

native_modes = [
    '$ cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml\n',
    '$ cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml --all-features\n',
    '$ cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml --features tauri/custom-protocol\n',
]
native_ids = []
for marker in native_modes:
    block = verify.split(marker)[1].split('\n$ ', 1)[0]
    tests = re.findall(r'^test ([^\n]+) \.\.\. ok$', block, re.M)
    check(len(tests) == len(set(tests)) == 77, '77 actual native tests per mode')
    check(re.findall(r'^test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', block, re.M) == ['77', '0', '0'], 'native no skipped/filtered plus empty main/doc targets')
    native_ids.append(sorted(tests))
check(native_ids[0] == native_ids[1] == native_ids[2], 'same77 exact native IDs all modes')

browser_summaries = re.findall(r'^\s+(\d+) passed \(([^\n]+)\)\s*$', verify, re.M)
check(browser_summaries == [('256', '8.6m'), ('2', '1.5s'), ('62', '39.0s'), ('3', '5.2s')], 'actual four browser summaries')
check(re.findall(r'^Total: (\d+) tests? in \d+ files?$', verify, re.M) == ['256', '2', '62', '3'], 'browser exact discovery counts')
contact = verify.split('$ pnpm exec playwright test --config e2e/extension/public-contact/playwright.config.ts --reporter=list,json\n')[1].split('$ pnpm exec playwright test --config e2e/extension/public-contact/playwright.config.ts --reporter=list,json --list')[0]
contact_report = None
for match in re.finditer(r'^\{', contact, re.M):
    try:
        candidate, _ = json.JSONDecoder().raw_decode(contact[match.start():])
    except ValueError:
        continue
    if isinstance(candidate, dict) and 'stats' in candidate and 'suites' in candidate:
        contact_report = candidate
        break
check(contact_report is not None and contact_report['errors'] == [], 'contact actual JSON result')
stats = contact_report['stats']
check(stats['expected'] == 62 and stats['unexpected'] == stats['flaky'] == stats['skipped'] == 0, 'contact62 no skipped flaky unexpected')
def test_records(suites):
    found = []
    for suite in suites:
        for spec in suite.get('specs', []):
            found.extend(spec.get('tests', []))
        found.extend(test_records(suite.get('suites', [])))
    return found
contact_tests = test_records(contact_report['suites'])
check(len(contact_tests) == 62 and all(t['expectedStatus'] == 'passed' and len(t['results']) == 1 and t['results'][0]['status'] == 'passed' for t in contact_tests), '62 actual single passed contact results')
target_lines = [json.loads(line.partition('W13_TARGET_P95 ')[2]) for line in verify.splitlines() if line.startswith('W13_TARGET_P95 ')]
check(len(target_lines) == 1 and target_lines[0]['samples'] == 1 and target_lines[0]['scope'] == 'TARGET_MACHINE_LOWER_BOUND_HARNESS_VALIDATION', 'ordinary default sample not target20')
check('$ pnpm exec turbo run build --force\n' in verify and '3 successful, 3 total' in verify and '$ cargo build --locked --manifest-path apps/desktop/src-tauri/Cargo.toml\n' in verify, 'build stages retained')
check('PASS: portability policy validated' in verify and 'PASS: all checks passed (45 check groups)' in verify and '$ python3 scripts/traceability.py check --quiet' in verify, 'portability traceability status integrity result')

result = {
    'schema': 'INDEPENDENT_ROOT_FULL_V5_SOURCE_DATA_REVIEW_1',
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'result': 'PASS_SELECTED_FULL_VERIFICATION_SOURCE_DATA_BINDING',
    'reviewer_subject_execution': False,
    'head': HEAD, 'tree': TREE, 'source_paths': 1798,
    'all1798_snapshot_Git_objects_match': True,
    'all1798_before_after_snapshot_bytes_identical': True,
    'current_root_before': current_before, 'current_root_after': current_after,
    'current_root_all1798_exact': live_matches,
    'd28_to_6d3_only_paths': delta,
    'app_runtime_implementation_and_all_other_paths_unchanged_from_d28': True,
    'selected_archive': {'sha256': ARCHIVE, 'bytes': 277133, 'safe_regular_members': 10, 'input_records': 9, 'input_manifest_sha256': MANIFEST, 'durable_copy_byte_identical': True},
    'actual_top_level_commands': commands,
    'doctor': {'pass': 28, 'warning': 0, 'fail': 0, 'not_yet_applicable': 0},
    'verify_suite_ids': summary,
    'unit_TS_by_package': {p: int(n) for p, n, _ in unit_counts},
    'unit_TS_sum': 3937,
    'Python': {'actual_collected_unique_ids': 1653, 'matches_common1651_plus_posix2': True, 'passed': 1653, 'duration_seconds': 368.57},
    'desktop_native': {'actual_ids_per_mode': 77, 'same_exact_ids_all_three_modes': True, 'ignored_filtered_failed': 0, 'empty_main_and_doc_targets_each_mode': True},
    'browser_executions': [{'passed': int(n), 'reported_duration': d} for n, d in browser_summaries],
    'browser_counts_are_executions_not_disjoint_unique_cases': True,
    'contact_actual_JSON_expected': 62,
    'W13_default_performance': target_lines[0],
    'typecheck_scope': 'Turbo typecheck used existing cache replay; root tsc also ran. Unit tests and build explicitly --force. No all-tools-fresh compilation claim.',
    'limits': ['No outer invocation transcript or complete effective environment serialization.', 'Wrapper inherits ambient environment, prepends pinned Node24 PATH and clears four performance/artifact overrides; versions/probe paths and wrapper hash are retained.', 'No complete upfront dependency/native-binary image or new native GUI/app launch.', 'Full physical1798 source leaves omitted from selected archive; exact immutable Git objects and before/after SHA256 snapshots supply source recovery.', 'No hostedCI, cross-platform or milestone acceptance; no target20 GateA rerun.'],
}
(OUT / 'audit-results.json').write_text(json.dumps(result, indent=2) + '\n')
(OUT / 'input-hashes.json').write_text(json.dumps({'files': INPUTS}, indent=2, sort_keys=True) + '\n')
(OUT / 'source-object-binding.json').write_text(json.dumps({'head': HEAD, 'tree': TREE, 'tracked': [{**entries[p], **snapshot[p]} for p in ordered]}, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['result', 'source_paths', 'current_root_all1798_exact', 'unit_TS_sum']}))
