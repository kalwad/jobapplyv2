from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
import time

source = Path('/Users/tanishkalwad/jobapplyv2')
out = Path('/tmp/japp-w14-clean-owner-waiver-20261017')
expected = sys.argv[1]
assert re.fullmatch('[0-9a-f]{40}', expected)
assert not out.exists(), 'A fresh output directory is required'
out.mkdir()
proof = out / 'proof'
proof.mkdir()
root = out / 'clone'
env = os.environ.copy()
env['PATH'] = '/opt/homebrew/opt/node@24/bin:' + env['PATH']
env.update(
    JAPP_W13_PERFORMANCE_SAMPLES='20',
    JAPP_W14_REQUIRE_TARGET_PERFORMANCE='1',
    JAPP_W14_ARTIFACT_DIRECTORY=str(proof / 'w14'),
    JAPP_W14_W06_ARTIFACT_DIRECTORY=str(proof / 'mounted32'),
)
records = []

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def run(name, argv, cwd):
    print('RUN ' + name, flush=True)
    started = now()
    t = time.monotonic()
    with (proof / (name + '.log')).open('wb') as log:
        result = subprocess.run(argv, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT)
    b = (proof / (name + '.log')).read_bytes()
    record = {'name': name, 'argv': argv, 'cwd': str(cwd), 'started_at': started,
              'ended_at': now(), 'exit_code': result.returncode,
              'elapsed_seconds': time.monotonic() - t, 'log_bytes': len(b),
              'log_sha256': hashlib.sha256(b).hexdigest()}
    records.append(record)
    (proof / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if result.returncode:
        print(b.decode(errors='replace')[-9000:], flush=True)
    return result.returncode

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root).decode().strip()

def snapshot():
    files = []
    for name in subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0'):
        if name:
            b = (root / name).read_bytes()
            files.append({'path': name, 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain=v1'), 'tracked_files': files,
            'tracked_inventory_digest': hashlib.sha256(json.dumps(files, separators=(',', ':')).encode()).hexdigest(),
            'captured_at': now()}

command = {'outer_argv': sys.argv, 'source_repository': str(source), 'expected_head': expected,
           'wrapper_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'task_environment': {k: env[k] for k in ('JAPP_W13_PERFORMANCE_SAMPLES', 'JAPP_W14_REQUIRE_TARGET_PERFORMANCE', 'JAPP_W14_ARTIFACT_DIRECTORY', 'JAPP_W14_W06_ARTIFACT_DIRECTORY')},
           'started_at': now()}
(proof / 'wrapper-command.json').write_text(json.dumps(command, indent=2) + '\n')
steps = [
    ('clone', ['git', 'clone', '--no-hardlinks', '--no-checkout', str(source), str(root)], out),
    ('checkout', ['git', 'checkout', '--detach', expected], root),
    ('pnpm-install', ['pnpm', 'install', '--frozen-lockfile'], root),
    ('uv-sync', ['uv', 'sync', '--locked'], root),
    ('playwright-install', ['pnpm', 'exec', 'playwright', 'install', 'chromium'], root),
]
for name, argv, cwd in steps:
    code = run(name, argv, cwd)
    if code:
        (proof / 'completion.json').write_text(json.dumps({'stage': name, 'exit_code': code, 'ended_at': now()}, indent=2) + '\n')
        raise SystemExit(code)
before = snapshot()
assert before['head'] == expected and before['status'] == '', 'Exact clean committed source required'
(proof / 'before.json').write_text(json.dumps(before, indent=2) + '\n')
code = run('doctor', ['pnpm', 'doctor'], root)
if code == 0:
    code = run('aggregate', ['pnpm', 'verify'], root)
after = snapshot()
(proof / 'after.json').write_text(json.dumps(after, indent=2) + '\n')
completion = {'exit_code': code, 'head_unchanged': before['head'] == after['head'],
              'tree_unchanged': before['tree'] == after['tree'], 'status_before': before['status'],
              'status_after': after['status'],
              'tracked_inventory_unchanged': before['tracked_inventory_digest'] == after['tracked_inventory_digest'],
              'ended_at': now()}
(proof / 'completion.json').write_text(json.dumps(completion, indent=2) + '\n')
print(json.dumps(completion), flush=True)
raise SystemExit(code or int(not all([completion['head_unchanged'], completion['tree_unchanged'], completion['tracked_inventory_unchanged'], after['status'] == ''])))
