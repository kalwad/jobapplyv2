/** PREPARED ONLY. Never import/invoke before root explicitly declares full completion. */
import { readFileSync, readdirSync, lstatSync } from 'node:fs';
import { resolve, relative, isAbsolute, sep, join } from 'node:path';
import { createHash } from 'node:crypto';
import { gunzipSync } from 'node:zlib';
import { execFileSync } from 'node:child_process';

if (process.argv.length !== 3 || process.argv[2] !== '--after-explicit-root-completion') {
  throw new Error('EXPLICIT_ROOT_FULL_COMPLETION_REQUIRED_BEFORE_ANY_ARTIFACT_READ');
}
const ROOT = '/tmp/japp-w14-clean-owner-waiver-20261017/clone';
const SOURCE_REPOSITORY = '/Users/tanishkalwad/jobapplyv2';
const PREPARATION = '/tmp/japp-w14-6384-full-audit-preparation';
const DOCTOR_CORRECTION = '/tmp/japp-w14-clean-owner-waiver-20261017/doctor-correction';
const INPUT = '/tmp/japp-w14-clean-owner-waiver-20261017/proof';
const HEAD = '6384d98156ae198cd93d7b35d1bb28b501ed475e';
const TREE = 'd2c1fd5e50bbbd31a926cbf251d6140d11b9b9c4';
const WRAPPER = '042358ea0d122da2cb2c34b18066cc39d23de3563d552461d7abf84f9016828d';
const ALL_SUITES = ['toolchain','format','lint','typecheck','unit-ts','contract-gen','fixture-corpus','evaluation-corpus','contract','build','e2e-browser','w14-public-controlled','w14-public-contact-controlled','visual','python','rust','portability','traceability','status','integrity'];
const COUNT_KEYS = ['fields','ordinary_fields','sensitive_fields','honeypot_fields','unsupported_fields','ambiguous_fields','expected_abstentions','required_fields','optional_fields','expected_fills','expected_required_fills','attempted_fills','correct_fills','incorrect_fills','correct_required_fills','correct_abstentions','incorrect_abstentions','required_unresolved','required_reported','required_silent','sensitive_fills','honeypot_fills','catastrophic_option_errors','correct_options','persisted','reverted','persistence_unknown','site_accepted','site_rejected','site_unknown','physical_actions','duplicate_actions','navigation_activations','submission_activations'];
const MUTATION = new Set(['INPUT_VALUE','TEXTAREA_VALUE','SELECT_VALUE','INPUT_CHECKED','INPUT_FILES','SELECT_INDEX','ACTIVATION']);
const checks = [];
const sha = b => createHash('sha256').update(b).digest('hex');
const digest = b => 'sha256:' + sha(b);
function canonical(v) {
  if (Array.isArray(v)) return v.map(canonical);
  if (v && typeof v === 'object') return Object.fromEntries(Object.keys(v).sort().map(k => [k,canonical(v[k])]));
  if (typeof v === 'number' && !Number.isFinite(v)) throw new Error('NONFINITE_INPUT');
  return v;
}
const cjson = v => JSON.stringify(canonical(v));
const csha = v => digest(cjson(v));
const equal = (a,b) => cjson(a) === cjson(b);
function check(name, ok, observed = null) { checks.push({name, passed:ok === true, observed}); }
function bytes(base, name) {
  const path=resolve(base,name), rel=relative(base,path);
  if (!rel || rel.startsWith('..'+sep) || isAbsolute(rel)) throw new Error('UNSAFE_MEMBER:'+name);
  for (let p=path; p!==base; p=resolve(p,'..')) {
    const s=lstatSync(p);
    if (s.isSymbolicLink()) throw new Error('SYMLINK_REFUSED:'+p);
  }
  if (!lstatSync(path).isFile()) throw new Error('REGULAR_FILE_REQUIRED:'+path);
  return readFileSync(path);
}
const input = name => bytes(INPUT,name);
const json = name => JSON.parse(input(name).toString('utf8'));
function inventory(base, prefix='') {
  return readdirSync(join(base,prefix),{withFileTypes:true}).sort((a,b)=>a.name<b.name?-1:a.name>b.name?1:0).flatMap(e => {
    const name=prefix ? prefix+'/'+e.name : e.name;
    if (e.isSymbolicLink()) throw new Error('SYMLINK_REFUSED:'+name);
    if (e.isDirectory()) return inventory(base,name);
    const b=bytes(base,name); return [{path:name,bytes:b.length,sha256:sha(b)}];
  });
}
try {
if (lstatSync(INPUT).isSymbolicLink() || !lstatSync(INPUT).isDirectory()) throw new Error('SAFE_INPUT_DIRECTORY_REQUIRED');
const initialInventory=inventory(INPUT);
const before=json('before.json'), after=json('after.json'), completion=json('completion.json'), command=json('wrapper-command.json'), stages=json('commands.json');
const clean = s => s.head===HEAD && s.tree===TREE && s.status==='';
check('original_wrapper_exact_pinned_source',sha(readFileSync(PREPARATION+'/wrapper-source.py'))===WRAPPER&&command.wrapper_sha256===WRAPPER);
check('outer_wrapper_identity_and_four_task_flags',equal(command.outer_argv,['/tmp/japp-w14-clean-owner-waiver-wrapper-20261017.py',HEAD])&&command.source_repository===SOURCE_REPOSITORY&&command.expected_head===HEAD&&equal(command.task_environment,{JAPP_W13_PERFORMANCE_SAMPLES:'20',JAPP_W14_REQUIRE_TARGET_PERFORMANCE:'1',JAPP_W14_ARTIFACT_DIRECTORY:INPUT+'/w14',JAPP_W14_W06_ARTIFACT_DIRECTORY:INPUT+'/mounted32'}));
check('source_exact_clean_6384_clone_before_after',clean(before)&&clean(after));
check('tracked_arrays_equal_and_nonempty',Array.isArray(before.tracked_files)&&before.tracked_files.length>0&&equal(before.tracked_files,after.tracked_files),before.tracked_files?.length);
check('tracked_digests_recomputed',sha(JSON.stringify(before.tracked_files))===before.tracked_inventory_digest&&sha(JSON.stringify(after.tracked_files))===after.tracked_inventory_digest&&before.tracked_inventory_digest===after.tracked_inventory_digest);
check('closure_flags_head_tree_tracked_neutral',completion.head_unchanged===true&&completion.tree_unchanged===true&&completion.tracked_inventory_unchanged===true&&completion.status_before===''&&completion.status_after==='');
const expectedStages=[['clone',['git','clone','--no-hardlinks','--no-checkout',SOURCE_REPOSITORY,ROOT]],['checkout',['git','checkout','--detach',HEAD]],['pnpm-install',['pnpm','install','--frozen-lockfile']],['uv-sync',['uv','sync','--locked']],['playwright-install',['pnpm','exec','playwright','install','chromium']],['doctor',['pnpm','doctor']],['aggregate',['pnpm','verify']]];
check('exact_clone_locked_setup_builtin_doctor_and_full_stages',Array.isArray(stages)&&stages.length===7&&stages.every((row,i)=>row.name===expectedStages[i][0]&&equal(row.argv,expectedStages[i][1])&&row.cwd===(i===0?'/tmp/japp-w14-clean-owner-waiver-20261017':ROOT)),stages.map(row=>({name:row.name,argv:row.argv,cwd:row.cwd,exit_code:row.exit_code})));
check('all_original_stage_logs_hash_bytes_and_exit0',stages.every(row=>{const body=input(row.name+'.log');return row.exit_code===0&&body.length===row.log_bytes&&sha(body)===row.log_sha256;}));
const time=s=>Date.parse(s), aggregateStage=stages.find(row=>row.name==='aggregate');
check('closure_writer_timestamps_monotonic_not_aliases',Number.isFinite(time(command.started_at))&&time(command.started_at)<=time(stages[0].started_at)&&stages.every(row=>Number.isFinite(time(row.started_at))&&Number.isFinite(time(row.ended_at))&&time(row.started_at)<=time(row.ended_at))&&time(stages[4].ended_at)<=time(before.captured_at)&&time(before.captured_at)<=time(stages[5].started_at)&&time(aggregateStage.ended_at)<=time(after.captured_at)&&time(after.captured_at)<=time(completion.ended_at));
check('full_process_exit_zero',completion.exit_code===0,completion.exit_code);
// pnpm11's bare doctor is builtin; never relabel its success as repository doctor.
const doctorInputInventory=inventory(DOCTOR_CORRECTION);
const correctedDoctor=JSON.parse(bytes(DOCTOR_CORRECTION,'command.json').toString('utf8'));
const correctedDoctorLog=bytes(DOCTOR_CORRECTION,'repository-doctor.log');
check('separate_actual_repository_doctor_command',equal(correctedDoctor.argv,['pnpm','run','doctor'])&&correctedDoctor.cwd===ROOT&&correctedDoctor.exit_code===0&&typeof correctedDoctor.correction==='string',correctedDoctor);
check('separate_repository_doctor_raw_hash_and_summary',correctedDoctorLog.length===correctedDoctor.log_bytes&&sha(correctedDoctorLog)===correctedDoctor.log_sha256&&correctedDoctorLog.length===3226&&sha(correctedDoctorLog)==='6367e0a7a7b8d1c7d09d93d9aacd76b43461ba34a638d74a4dde74682911bc23'&&/27.*pass/i.test(correctedDoctorLog.toString('utf8')));
check('doctor_correction_timing_explicit_no_serial_order_claim',time(correctedDoctor.started_at)>=time(aggregateStage.started_at)&&time(correctedDoctor.started_at)<=time(correctedDoctor.ended_at),{started_at:correctedDoctor.started_at,ended_at:correctedDoctor.ended_at,scope:'Separate repository doctor overlapped aggregate static/typecheck per producer; no strict doctor-before-aggregate claim.'});
// Inspect immutable Git objects, never substitute a later working tree for the completed source.
const git=(...args)=>execFileSync('git',args,{cwd:ROOT,encoding:'utf8',timeout:30000}).trim();
check('immutable_commit_tree_identity',git('rev-parse',HEAD+'^{tree}')===TREE&&git('cat-file','-t',HEAD)==='commit');
const objectRows=execFileSync('git',['ls-tree','-r','-z',HEAD],{cwd:ROOT,timeout:30000,maxBuffer:16*1024*1024}).toString('utf8').split('\0').filter(Boolean).map(row=>{
  const tab=row.indexOf('\t'), header=row.slice(0,tab).split(' '), path=row.slice(tab+1);
  if(tab<0||header.length!==3||!['100644','100755'].includes(header[0])||header[1]!=='blob'||!/^[0-9a-f]{40}$/.test(header[2])||!path||isAbsolute(path)||path.split('/').some(p=>!p||p==='.'||p==='..')||/[\r\n\0]/.test(path))throw new Error('UNSAFE_IMMUTABLE_GIT_ENTRY');
  return {mode:header[0],object:header[2],path};
});
const sourcePaths=before.tracked_files.map(x=>x.path), objectPaths=objectRows.map(x=>x.path);
check('tracked_snapshot_rows_well_formed_unique',new Set(sourcePaths).size===sourcePaths.length&&before.tracked_files.every(x=>typeof x.path==='string'&&Number.isSafeInteger(x.bytes)&&x.bytes>=0&&/^[0-9a-f]{64}$/.test(x.sha256)));
const sorted=v=>[...v].sort((a,b)=>a<b?-1:a>b?1:0);
check('immutable_tree_exhaustive_snapshot_paths',equal(sorted(sourcePaths),sorted(objectPaths)),{snapshot_count:sourcePaths.length,immutable_tree_count:objectPaths.length});
const objectIds=[...new Set(objectRows.map(x=>x.object))];
const batch=execFileSync('git',['cat-file','--batch'],{cwd:ROOT,input:objectIds.join('\n')+'\n',timeout:120000,maxBuffer:512*1024*1024});
const blobs=new Map();let cursor=0,uniqueBlobBytes=0;
for(const id of objectIds){
  const newline=batch.indexOf(10,cursor);if(newline<0)throw new Error('GIT_BATCH_HEADER_TRUNCATED');
  const parts=batch.subarray(cursor,newline).toString('ascii').split(' '),length=Number(parts[2]);
  if(parts.length!==3||parts[0]!==id||parts[1]!=='blob'||!Number.isSafeInteger(length)||length<0)throw new Error('GIT_BATCH_HEADER_INVALID');
  cursor=newline+1;const body=batch.subarray(cursor,cursor+length);cursor+=length;
  if(body.length!==length||batch[cursor]!==10)throw new Error('GIT_BATCH_BODY_TRUNCATED');cursor++;
  if(createHash('sha1').update(Buffer.from('blob '+length+'\0')).update(body).digest('hex')!==id)throw new Error('GIT_BLOB_OBJECT_ID_MISMATCH');
  blobs.set(id,{body,bytes:length,sha256:sha(body)});uniqueBlobBytes+=length;
}
check('git_batch_complete_unique_objects',cursor===batch.length&&blobs.size===objectIds.length,{objects:objectIds.length,unique_blob_bytes:uniqueBlobBytes});
const objectsByPath=new Map(objectRows.map(r=>[r.path,blobs.get(r.object)])),sourceDrift=[];
let trackedBlobBytes=0;
for(const item of before.tracked_files){
  const blob=objectsByPath.get(item.path);if(blob)trackedBlobBytes+=blob.bytes;
  if(!blob||blob.bytes!==item.bytes||blob.sha256!==item.sha256)sourceDrift.push(item.path);
}
check('every_immutable_git_blob_matches_both_frozen_snapshots',sourceDrift.length===0&&equal(before.tracked_files,after.tracked_files),{tracked_files:sourcePaths.length,tracked_blob_bytes:trackedBlobBytes,drift:sourceDrift});
const bindings=JSON.parse(objectsByPath.get('e2e/extension/legacy-paired-options/source-bindings.json').body.toString('utf8'));
const runtime=bindings.candidate_runtime_sources.map(r=>({path:r.path,sha256:'sha256:'+objectsByPath.get(r.path).sha256}));
const runtimeBytes=bindings.candidate_runtime_sources.reduce((n,r)=>n+objectsByPath.get(r.path).bytes,0);
check('immutable_runtime_355_exact_revision9',runtime.length===355&&runtimeBytes===3371960&&equal(runtime,bindings.candidate_runtime_sources)&&csha(runtime)==='sha256:3b6c0e0c0950b03e3bb9e1f12b27bb8d385174c36fb4b68ef3345597aa8b3502',{files:runtime.length,bytes:runtimeBytes,digest:csha(runtime)});
check('immutable_revision9_lock_exact',objectsByPath.get('e2e/extension/legacy-paired-options/campaign.lock.json').sha256==='72a68f2929823583c878a20dc8c9b57414f65a5ca59cf21b144c5e1af6466a5a');
const log=input('aggregate.log').toString('utf8').replace(/\x1b\[[0-9;]*[A-Za-z]/g,'');
const summaries=log.split('== verification summary ==');
check('one_final_summary',summaries.length===2,summaries.length-1);
const final=summaries.at(-1);
const suiteRows=[...final.matchAll(/^([a-z][a-z0-9-]*)\s+(ACTIVE|NOT_YET_APPLICABLE|REQUIRED_MISSING)\s+(PASS|FAIL|NOT_YET_APPLICABLE|REQUIRED_MISSING)(?:\s|$)/gm)].map(m=>({id:m[1],state:m[2],result:m[3]}));
check('exact_twenty_declared_summary_rows',equal(suiteRows.map(r=>r.id),ALL_SUITES),suiteRows);
check('all_nineteen_active_suites_pass',suiteRows.filter(r=>r.state==='ACTIVE').length===19&&suiteRows.filter(r=>r.state==='ACTIVE').every(r=>r.result==='PASS'),suiteRows.filter(r=>r.state==='ACTIVE'&&r.result!=='PASS'));
check('visual_future_scope_not_promoted',suiteRows.find(r=>r.id==='visual')?.state==='NOT_YET_APPLICABLE'&&suiteRows.find(r=>r.id==='visual')?.result==='NOT_YET_APPLICABLE');
check('terminal_verifier_exit_zero',/^verification exit code: 0\s*$/m.test(final));
const commands=[...log.matchAll(/^\$ (.+)\r?\n([\s\S]*?)(?=^\$ |^== verification summary ==|$(?![\s\S]))/gm)].map(m=>({argv:m[1],body:m[2]}));
function onlyCommand(predicate,name) {
  const rows=commands.filter(r=>predicate(r.argv)); check(name+'_unique_command',rows.length===1,rows.map(r=>r.argv));
  return rows[0]?.body??'';
}
const unit=onlyCommand(s=>s.startsWith('pnpm exec turbo run test --force'),'unit_ts');
const units=[...unit.matchAll(/\bTests\s+(\d+) passed(?:\s+\((\d+)\))?/g)].map(m=>+m[1]);
check('unit_ts_3859',units.reduce((a,b)=>a+b,0)===3859,{total:units.reduce((a,b)=>a+b,0),summaries:units.length});
const browser=onlyCommand(s=>s==='pnpm exec playwright test','default_browser');
const browserPassed=[...browser.matchAll(/^\s*(\d+) passed\b/gm)].map(m=>+m[1]);
check('default_browser_242_ordinary_passes',equal(browserPassed,[242])&&!/^\s*\d+ (failed|flaky|skipped)\b/m.test(browser),{passed:browserPassed,nonpasses:[...browser.matchAll(/^\s*\d+ (failed|flaky|skipped).*$/gm)].map(m=>m[0].trim())});
for (const [file,expected] of [['extension-w14-native-validity.spec.ts',6],['extension-w14-focus-value.spec.ts',8]]) {
  const lines=browser.split('\n').filter(line=>line.includes(file+':')&&/^\s*[✓✔√✘×x]\s*\d+/.test(line));
  check('permanent_correction_'+file,lines.length===expected&&lines.every(line=>/^\s*[✓✔√]/.test(line)),{expected,lines});
}
const defaultLists=commands.filter(r=>r.argv==='pnpm exec playwright test --list');
check('default_browser_run_inventory_242',/Running 242 tests using 1 worker/.test(browser));
check('default_browser_listing_at_most_once',defaultLists.length<=1,defaultLists.length);
if(defaultLists.length===1) {
  check('default_browser_discovered_242',/Total: 242 tests in/.test(defaultLists[0].body));
} else {
  check('default_browser_listing_absent_after_command_failure',/^\s*[1-9]\d* failed\b/m.test(browser),{state:'NOT_EXECUTED_AFTER_BROWSER_COMMAND_FAILURE',reason:'verify.run_suite stops before discovery proofs after a nonzero command. This is not discovery PASS.'});
}
const controlled=[];
for (const [fragment,count] of [['public-research/playwright.config.ts',2],['public-contact/playwright.config.ts',62]]) {
  const body=onlyCommand(s=>s.startsWith('pnpm exec playwright test --config ')&&s.includes(fragment)&&!s.includes('--list'),'controlled_'+fragment.split('/')[0]);
  const passes=[...body.matchAll(/^\s*(\d+) passed\b/gm)].map(m=>+m[1]); controlled.push(...passes);
  check('controlled_normal_'+count,equal(passes,[count])&&!/^\s*\d+ (failed|flaky|skipped)\b/m.test(body),passes);
}
check('controlled_contact62_plus_separate_inspection2',equal(controlled,[2,62]),{inspection:controlled[0],contact:controlled[1],combined:controlled.reduce((a,b)=>a+b,0)});
const py=onlyCommand(s=>s.startsWith('uv run pytest ')&&!s.includes('--collect-only'),'python');
const pySummaries=[...py.matchAll(/^=+\s+(\d+) passed in ([0-9]+\.[0-9]+)s(?: \([0-9:]+\))?\s*=+$/gm)].map(m=>({passed:+m[1],seconds:+m[2],summary:m[0]}));
check('python_1492_ordinary_passes',pySummaries.length===1&&pySummaries[0].passed===1492&&!/\b(?:failed|skipped|xfailed|xpassed)\b/.test(pySummaries[0]?.summary??''),pySummaries);
const pyInventory=JSON.parse(objectsByPath.get('scripts/python-test-inventory.v1.json').body.toString('utf8'));
const common=pyInventory.common.node_ids,posix=pyInventory.posix_only_node_ids;
check('committed_python_common1490_posix2_exact_digest',common.length===1490&&pyInventory.common.count===1490&&sha(common.join('\n')+'\n')===pyInventory.common.sha256&&posix.length===2&&new Set([...common,...posix]).size===1492,{common:common.length,posix:posix});
const collectCommands=commands.filter(row=>row.argv.startsWith('uv run pytest ')&&row.argv.includes('--collect-only'));
const collectIds=(collectCommands[0]?.body??'').split('\n').map(row=>row.trim()).filter(row=>/^[^\s]+\.py::/.test(row));
check('actual_collected1492_exact_committed_no_skipped_cohort',collectCommands.length===1&&collectIds.length===1492&&new Set(collectIds).size===1492&&equal(sorted(collectIds),sorted([...common,...posix])),{commands:collectCommands.length,ids:collectIds.length});
function tagged(tag) {
  const rows=[...browser.matchAll(new RegExp('(?:^|\\n)'+tag+' (\\{[^\\n]+\\})','g'))].map(m=>JSON.parse(m[1]));
  check(tag+'_one_record',rows.length===1,rows.length); return rows[0];
}
const scaling=tagged('W13_SCALING');
const scalingRows=scaling?.rows??[];
const targetRows=scalingRows.filter(r=>r.control_count===128);
const samples=targetRows.map(r=>r.total_wall_clock_ms).sort((a,b)=>a-b);
const targetP95=samples[Math.ceil(samples.length*.95)-1]??null;
check('native128_twenty_samples',targetRows.length===20&&scalingRows.length===22,{samples:targetRows.length,totalRows:scalingRows.length});
check('native128_exact_physical_actions_and_zero_settle_scope',targetRows.length===20&&targetRows.every(r=>r.actions_attempted===128&&r.physical_actions_count===128&&r.settle_budget_ms===0&&r.evidence_scope==='LOWER_BOUND_NO_ASYNC_RERENDER_DELAY'));
check('native_scaling_bounded_scanner_work',scalingRows.every(r=>{const n=r.control_count,w=r.scanner_work;return r.physical_actions_count===n&&r.actions_attempted===n&&w.reresolution_calls>=4*n&&w.index_rebuilds===1&&w.index_hits>=4*n-1&&w.identity_pairs_examined===n&&w.candidate_enumerations<=3&&w.candidates_examined<=3*n&&w.descriptors_built===6*n;}));
check('native128_target_p95_1500',typeof targetP95==='number'&&targetP95<=1500,{p95_ms:targetP95,threshold_ms:1500,scope:'TARGET_MACHINE_LOWER_BOUND_HARNESS_VALIDATION'});
const targetAnnouncements=[...browser.matchAll(/(?:^|\n)W13_TARGET_P95 (\{[^\n]+\})/g)].map(m=>JSON.parse(m[1]));
check('native128_summary_matches_actual_assertion',targetP95<=1500 ? targetAnnouncements.length===1&&targetAnnouncements[0].samples===20&&targetAnnouncements[0].p95_ms===targetP95 : targetAnnouncements.length===0,{records:targetAnnouncements,absence_when_assertion_fails:'Raw W13_SCALING remains authoritative; absence never erases failure.'});
const compressed=input('w14/development-run.json.gz'), bundle=JSON.parse(gunzipSync(compressed).toString('utf8')), assessment=json('w14/assessment.json');
check('bundle_hash_and_bytes',assessment.compressed_bundle_digest===digest(compressed)&&assessment.compressed_bundle_bytes===compressed.length);
const coreAssessment={...assessment}; delete coreAssessment.compressed_bundle_digest; delete coreAssessment.compressed_bundle_bytes;
check('assessment_exact_embedded',equal(coreAssessment,bundle.assessment));
check('contact_no_gate_authority',assessment.authority==='NONE'&&assessment.gate_decision==='NOT_DECIDED'&&assessment.complete_gate_evidence===false);
check('contact_source_bound_6384_clean',bundle.source.commit===HEAD&&bundle.source.tree===TREE&&bundle.source.source_state==='CLEAN'&&bundle.source.status===''&&bundle.source.digest===csha(bundle.source.inventory)&&assessment.source_inventory_digest===bundle.source.digest);
const expectedContactSources=before.tracked_files.filter(x=>!x.path.startsWith('docs/evidence/')).map(x=>({path:x.path,digest:'sha256:'+x.sha256})).sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0);
check('contact_source_inventory_exact_frozen_source',equal(bundle.source.inventory,expectedContactSources));
check('contact_build_digest_internal',bundle.extension_build.digest===csha(bundle.extension_build.inventory)&&assessment.immutability.end_build_digest===bundle.extension_build.digest);
check('contact_source_build_declaration_neutrality',assessment.immutability.source_unchanged===true&&assessment.immutability.build_unchanged===true&&assessment.immutability.declarations_unchanged===true&&assessment.immutability.end_source_digest===bundle.source.digest);
check('contact_configuration_target_and_no_authority',bundle.configuration.target_performance_assertion_required===true&&bundle.configuration.settle_budget_ms===75&&bundle.configuration.rerender_delay_ms===20&&bundle.configuration.ai_enabled===false&&bundle.configuration.navigation_enabled===false&&bundle.configuration.submission_enabled===false&&bundle.configuration.application_tab_posture==='FOREGROUND');
check('contact_hardware_digest',bundle.runtime.hardware_digest===csha(bundle.runtime.hardware));
check('contact_hardware_target_M5',bundle.runtime.hardware.platform==='darwin'&&bundle.runtime.hardware.cpu_model==='Apple M5',bundle.runtime.hardware);
const cases=new Map(bundle.cases.map(c=>[c.oracle.case_id,c])); const rows=bundle.rows;
check('contact_exact200_unique_cases',cases.size===200&&bundle.cases.length===200&&rows.length===200&&new Set(rows.map(r=>r.case_id)).size===200&&rows.every(r=>cases.has(r.case_id)));
const totals=Object.fromEntries(COUNT_KEYS.map(k=>[k,0]));
let ordinaryCorrect=0,ordinaryAttempted=0,logical=0,native=0,rawActions=0,auditedActions=0,nativeActions=0,interactions=0;
const physical={sensitive_fills:0,honeypot_fills:0,catastrophic_option_errors:0,duplicate_actions:0,navigation_activations:0,submission_activations:0,paused_boundary_actions:0};
const preservation={expected:0,correct:0,violations:0,empty_abstention_violations:0};
const rowIssues=[];
const recordsById=new Map(bundle.canonical_runner.execution.records.map(r=>[r.case_id,r]));
const witnessesById=new Map(bundle.canonical_runner.execution.replay_witness.case_witnesses.map(w=>[w.case_id,w]));
function issue(id,condition,label) { if(!condition) rowIssues.push({case_id:id,issue:label}); }
for (const row of rows) {
  const id=row.case_id, entry=cases.get(id); if(!entry) continue;
  const {oracle,initial_oracle:initial}=entry, art=row.artifact, obs=row.observation, score=row.score;
  issue(id,row.measurement_state==='SCORED'&&row.measurement_issues.length===0&&art&&obs&&score&&row.preservation,'complete_live_measurement');
  if(!art||!obs||!score||!row.preservation) continue;
  logical+=oracle.fields.length; native+=obs.final.reduce((n,f)=>n+f.native_keys.length,0);
  issue(id,equal(obs.visibility,{before:{state:'visible',hidden:false},after:{state:'visible',hidden:false}}),'foreground_visibility');
  issue(id,score.format_version==='W13_SCORE_1'&&score.scorer_version==='1.0.0'&&row.preservation.format_version==='W14_PRESERVATION_SCORE_1'&&row.preservation.authority==='NONE','scorer_version_and_authority');
  issue(id,score.oracle_digest===csha(oracle)&&score.raw_digest===csha(art.candidate)&&score.physical_digest===csha(art.audit),'score_raw_oracle_hashes');
  issue(id,csha(entry.input)===oracle.profile_digest&&initial.oracle_digest===csha(oracle),'input_initial_oracle_bindings');
  const state=row.state_observation;
  issue(id,state&&state.initial_oracle_digest===csha(initial)&&state.candidate_digest===csha(art.candidate)&&state.physical_digest===csha(art.audit),'state_bindings');
  const keyList=oracle.fields.map(x=>x.key).sort();
  issue(id,[art.candidate.fields,art.audit.fields,initial.fields,state?.initial??[],state?.final??[],obs.initial,obs.final].every(fields=>fields.length===keyList.length&&new Set(fields.map(x=>x.key)).size===fields.length&&equal(fields.map(x=>x.key).sort(),keyList)),'exact_field_inventories');
  const record=recordsById.get(id), witness=witnessesById.get(id);
  issue(id,record?.case_digest===csha(entry.benchmarkCase)&&record?.artifact_report_digests.includes(csha(score))&&row.started_at===witness?.started_at&&row.ended_at===witness?.ended_at&&row.worksheet?.observed_at===witness?.ended_at&&record?.started_at===row.started_at&&record?.ended_at===row.ended_at,'canonical_case_score_and_live_timestamps');
  const count=Object.fromEntries(COUNT_KEYS.map(k=>[k,0])); const derived=[];
  for(const e of oracle.fields) {
    const f=art.candidate.fields.find(x=>x.key===e.key), a=art.audit.fields.find(x=>x.key===e.key), initialField=initial.fields.find(x=>x.key===e.key);
    if(!f||!a||!initialField) { issue(id,false,'field_inventory'); continue; }
    const acts=a.actions, attempted=acts.length>0, eligible=e.expected==='FILL'&&e.supported&&e.class==='ORDINARY';
    const allCorrect=eligible&&attempted&&acts.every(a=>a.value_digest===e.value_digest&&a.kind===(e.option?'OPTION':'FILL'));
    const persisted=f.persistence==='PERSISTED',accepted=f.site_acceptance==='ACCEPTED';
    const success=allCorrect&&persisted&&accepted&&f.observed_digest===e.value_digest&&f.status==='FILLED';
    const unresolved=e.required&&e.visible&&e.enabled&&!success;
    const reported=unresolved&&f.status==='UNRESOLVED'&&f.reason==='REQUIRED_UNRESOLVED'&&f.report_digest!==null;
    const primary=attempted?(success?'CORRECT_FILL':'INCORRECT_FILL'):unresolved&&eligible?(reported?'REQUIRED_UNRESOLVED_REPORTED':'REQUIRED_UNRESOLVED_SILENT'):e.expected==='ABSTAIN'&&f.status!=='FILLED'&&f.observed_digest===null?'CORRECT_ABSTENTION':'INCORRECT_ABSTENTION';
    derived.push({key:e.key,expected_class:e.class,required:e.required,supported:e.supported,expected:e.expected,persistence:f.persistence,site_acceptance:f.site_acceptance,primary,attempted,persisted,accepted,reason:f.reason,required_unresolved:unresolved,explicitly_reported:reported});
    count.fields++; if(e.class==='ORDINARY') count.ordinary_fields++; if(['SENSITIVE','PROHIBITED'].includes(e.class)) count.sensitive_fields++; if(e.class==='HONEYPOT')count.honeypot_fields++; if(e.class==='UNSUPPORTED')count.unsupported_fields++;if(e.class==='AMBIGUOUS')count.ambiguous_fields++;
    if(e.expected==='ABSTAIN')count.expected_abstentions++;count[e.required?'required_fields':'optional_fields']++;
    if(eligible){count.expected_fills++;if(e.required)count.expected_required_fills++;}if(attempted)count.attempted_fills++;
    const key={CORRECT_FILL:'correct_fills',INCORRECT_FILL:'incorrect_fills',CORRECT_ABSTENTION:'correct_abstentions',INCORRECT_ABSTENTION:'incorrect_abstentions'}[primary];if(key)count[key]++;
    if(success&&e.required)count.correct_required_fills++;if(unresolved){count.required_unresolved++;count[reported?'required_reported':'required_silent']++;}
    if(attempted&&['SENSITIVE','PROHIBITED'].includes(e.class))count.sensitive_fills++;if(attempted&&e.class==='HONEYPOT')count.honeypot_fills++;
    if(e.option&&acts.some(a=>a.kind==='OPTION'&&a.value_digest!==e.value_digest))count.catastrophic_option_errors++;if(e.option&&allCorrect)count.correct_options++;
    if(attempted){count[f.persistence==='PERSISTED'?'persisted':f.persistence==='REVERTED'?'reverted':'persistence_unknown']++;count[f.site_acceptance==='ACCEPTED'?'site_accepted':f.site_acceptance==='REJECTED'?'site_rejected':'site_unknown']++;}
    count.physical_actions+=acts.length;count.duplicate_actions+=Math.max(0,acts.length-1);
    if(e.class==='ORDINARY'&&e.supported&&attempted){ordinaryAttempted++;if(primary==='CORRECT_FILL')ordinaryCorrect++;}
    if(['SENSITIVE','PROHIBITED'].includes(e.class)&&attempted)physical.sensitive_fills++;if(e.class==='HONEYPOT'&&attempted)physical.honeypot_fills++;
    if(e.option&&acts.some(a=>a.value_digest!==e.value_digest))physical.catastrophic_option_errors++;physical.duplicate_actions+=Math.max(0,acts.length-1);if(entry.variant.expected.sessionBoundary)physical.paused_boundary_actions+=acts.length;
    if(e.expected==='ABSTAIN') {
      const correct=acts.length===0&&f.observed_digest===initialField.initial_digest&&f.status!=='FILLED';
      if(initialField.initial_digest!==null){preservation.expected++;preservation[correct?'correct':'violations']++;}else if(!correct)preservation.empty_abstention_violations++;
    }
    issue(id,state?.initial.find(x=>x.key===e.key)?.observed_digest===initialField.initial_digest&&state?.final.find(x=>x.key===e.key)?.observed_digest===f.observed_digest,'initial_final_raw_state');
  }
  count.navigation_activations=art.audit.navigation_activations;count.submission_activations=art.audit.submission_activations;
  issue(id,equal(derived,score.fields)&&equal(count,score.counts),'independent_full_field_classification_and_counts');
  for(const k of COUNT_KEYS)totals[k]+=count[k];
  physical.navigation_activations+=art.audit.navigation_activations;physical.submission_activations+=art.audit.submission_activations;
  rawActions+=obs.observed.meter.actions.length;auditedActions+=art.audit.fields.reduce((n,f)=>n+f.actions.length,0);
  const w=obs.native_witness; issue(id,w?.source==='CDP_EXTENSION_ISOLATED_REALM_NATIVE_1'&&w.coverage==='COMPLETE_INSTALLED_NATIVE_SURFACES'&&w.witnesses_digest===csha(w.witnesses),'native_witness_binding');
  if(w) {
    const acts=w.witnesses.filter(x=>MUTATION.has(x.surface));nativeActions+=acts.length;interactions+=w.witnesses.length-acts.length;
    issue(id,w.native_mutation_count===acts.length&&w.interaction_count===w.witnesses.length-acts.length,'native_witness_counts');
    for(const f of obs.final) {
      const nw=acts.filter(x=>f.native_keys.includes(x.key)), ev=obs.observed.meter.actions.filter(x=>x.key===f.key);
      issue(id,nw.length===ev.length&&nw.every((x,i)=>x.succeeded&&x.value_digest===csha(ev[i].value)&&(x.surface==='SELECT_VALUE'?ev[i].kind==='OPTION':ev[i].kind==='FILL')),'native_events_exact_physical_join');
    }
  }
}
check('contact_each_raw_score_and_witness_binding',rowIssues.length===0,rowIssues);
const rate=(n,d)=>({numerator:n,denominator:d,rate:d===0?null:n/d});
const measured={ordinary_attempted_precision:rate(ordinaryCorrect,ordinaryAttempted),required_ordinary_recall:rate(totals.correct_required_fills,totals.expected_required_fills),required_reporting:rate(totals.required_reported,totals.required_unresolved),observed_persistence:rate(totals.persisted,totals.attempted_fills)};
for(const [key,value] of Object.entries(measured))check('contact_recomputed_'+key,equal(value,assessment.metrics[key]),value);
check('contact_quantitative_thresholds',measured.ordinary_attempted_precision.rate>=.995&&measured.required_ordinary_recall.rate>=.97&&measured.required_reporting.rate===1&&measured.observed_persistence.rate>=.995,measured);
check('contact_exact_inventory_counts',logical===4020&&native===4060&&assessment.authored_logical_controls===logical&&assessment.observed_native_controls===native,{logical,native});
check('contact_preservation_recomputed90_and_no_violations',equal(preservation,{expected:90,correct:90,violations:0,empty_abstention_violations:0})&&equal(preservation,assessment.metrics.preservation),preservation);
check('contact_canonical_safety_counts_match',equal(assessment.metrics.counts,Object.fromEntries(['required_silent','sensitive_fills','honeypot_fills','catastrophic_option_errors','duplicate_actions'].map(k=>[k,totals[k]])))&&['required_silent','sensitive_fills','honeypot_fills','catastrophic_option_errors','duplicate_actions'].every(k=>totals[k]===0));
check('contact_physical_safety_recomputed_zero',Object.values(physical).every(v=>v===0)&&equal(physical,assessment.physical_safety_all_executed_cases),physical);
check('contact_no_orphan_or_unwitnessed_physical_actions',rawActions===auditedActions&&rawActions===nativeActions&&assessment.physical_safety_coverage.raw_physical_actions===rawActions&&assessment.physical_safety_coverage.audited_physical_actions===auditedActions&&assessment.physical_safety_coverage.orphan_physical_actions===0&&assessment.physical_safety_coverage.state==='OBSERVED'&&assessment.native_physical_witness.native_mutation_count===nativeActions&&assessment.native_physical_witness.interaction_count===interactions,{rawActions,auditedActions,nativeActions,interactions});
check('contact_exact_200_scored_observed_no_refusals',assessment.expected_cases===200&&assessment.recorded_cases===200&&assessment.metrics.scored_cases===200&&assessment.metrics.executed_cases===200&&assessment.metrics.refused_cases===0&&assessment.metrics.measurement_error_cases===0&&assessment.native_physical_witness.observed_cases===200&&assessment.measurement_refusals.length===0);
const times=rows.map(r=>r.observation.observed.scan_fill_duration_ms).sort((a,b)=>a-b),contactP95=times[Math.ceil(times.length*.95)-1];
check('contact200_timing_recomputed_in_separate_scope',times.every(t=>typeof t==='number'&&Number.isFinite(t)&&t>=0)&&times.length===200&&contactP95===assessment.metrics.full_settle_scan_fill_timing.p95_ms&&assessment.metrics.full_settle_scan_fill_timing.sample_count===200,{p95_ms:contactP95,samples:times.length,scope:'ONE_EXECUTION_PER_DIFFERENT_W12_PAGE_75MS_SETTLEMENT_20MS_RERENDER'});
check('contact200_timing_1500',contactP95<=1500,{p95_ms:contactP95});
const execution=json('w14/canonical-execution.json'), rendered=bundle.canonical_runner.report, report=json('w14/canonical-report.json'), manifest=json('w14/canonical-report-manifest.json'), autofill=json('w14/canonical-autofill-run-manifest.json');
check('execution_exact_embedded_and_200_complete_safety_passes',equal(execution,bundle.canonical_runner.execution)&&execution.records.length===200&&execution.records.every(r=>r.completeness_state==='COMPLETE'&&r.overall_outcome==='PASS'));
check('report_exact_embedded_and_projected_records',equal(manifest,rendered.manifest)&&input('w14/canonical-report.json').toString('utf8')===rendered.json&&input('w14/canonical-report.md').toString('utf8')===rendered.markdown&&input('w14/canonical-report.html').toString('utf8')===rendered.html&&equal(report.cases,execution.records));
for(const a of manifest.artifacts) {
  const ext={JSON:'json',MARKDOWN:'md',HTML:'html'}[a.format];const b=input('w14/canonical-report.'+ext);
  check('report_manifest_exact_'+a.format,a.digest===digest(b)&&a.byte_count===b.length);
}
check('autofill_manifest_exact_embedded_and_raw_hashes',equal(autofill,bundle.canonical_runner.manifest)&&autofill.case_count===200&&autofill.field_count===4020&&autofill.raw_result_digest===csha(rows.map(r=>r.artifact))&&autofill.field_score_digest===csha(rows.map(r=>r.score))&&autofill.execution_digest===csha(execution)&&autofill.extension_build_digest===bundle.extension_build.digest&&autofill.source_inventory_digest===bundle.source.digest);
check('canonical_manifest_binding_and_no_issues',assessment.canonical_runner.manifest_issues.length===0&&assessment.canonical_runner.report_manifest_digest===csha(manifest)&&assessment.canonical_runner.autofill_run_manifest_digest===csha(autofill));
for (const family of ['WORKDAY','GREENHOUSE','LEVER','ASHBY']) {
  const row=rows.find(r=>r.fixture_id===`W12-${family}-GROUPED-en-US-MY_INFORMATION`);
  check('family_grouped_contact9_'+family,equal(row?.score?.rates.required_recall,{numerator:9,denominator:9,rate:1})&&row?.score?.counts.sensitive_fills===0,row?.score?.rates.required_recall);
}
check('input_artifacts_unchanged_during_audit',equal(initialInventory,inventory(INPUT))&&equal(doctorInputInventory,inventory(DOCTOR_CORRECTION)));
check('mounted32_retention_directory_present_not_implicitly_accepted',lstatSync(INPUT+'/mounted32').isDirectory(),{scope:'Mounted32 raw semantics require the separate prepared independent mounted checker/report; directory presence is not execution PASS.'});
const output={format:'INDEPENDENT_W14_6384_CLEAN_CLONE_RESULT_AUDIT_1',authority:'NONE',input:INPUT,expected_head:HEAD,expected_tree:TREE,checks,all_checks_pass:checks.every(x=>x.passed),verification_exit_code:completion.exit_code,source_tracked_count:before.tracked_files.length,suite_rows:suiteRows,native128_target_p95_ms:targetP95,contact200_p95_ms:contactP95,contact_counts:totals,physical_safety:physical,artifact_inventory:initialInventory,scope_limitations:['Supplemental W14 evidence audit only; no formal W15/Gate A decision.','Historical source neutrality is checked against the exact immutable6384 clone Git tree and both frozen snapshots; later root changes are outside this run. Tracked count is derived from completed snapshots and exhaustive tree closure, never assumed.','Native12820 zero-settle samples are lower-bound harness validation, not full-settlement Gate A performance proof.','Contact20075ms settlement spans200 different synthetic W12 pages; it cannot replace native128 target timing.','Canonical runner PASS covers declared zero-tolerance safety counts; independent precision/recall/reporting/persistence checks are separate.','Preservation90/90 supplements immutable W13 classification; do not erase historical incorrect-abstention counts.','Native witness covers installed surfaces in the actual isolated extension realm; no claim for other realms, retained references, uninstalled APIs, closed shadow roots or live employer forms.','Contact build immutability is bound to retained before inventory and producer end digest; subsequent controlled suites rebuild variants, so current ignored dist is not a surrogate for the contact build.','The contact cohort excludes separately tested driver/iframe/shadow/repeater/navigation/soak features; no full corpus or compatibility claim.','Mounted32 raw review is a separate required audit component; this master checker does not silently count it as passed. Existing R9/730/1d proofs remain distinct historical anchors.','ADR-0006 waives owner holdout and per-W stopping; ADR-0007 waives only direct Simplify and executed public-form evidence. Numerical accuracy/safety/performance, legacy/other baselines, independent W15 and concrete owner decision remain binding.','Original bare pnpm doctor called the pnpm11 builtin. A separately retained pnpm run doctor is actual repository doctor; no strict serial doctor-before-aggregate order is claimed.']};
process.stdout.write(JSON.stringify(output,null,2)+'\n');
process.exitCode=output.all_checks_pass?0:1;

} catch (error) {
  process.stdout.write(JSON.stringify({format:'INDEPENDENT_W14_6384_CLEAN_CLONE_RESULT_AUDIT_1',authority:'NONE',input:INPUT,all_checks_pass:false,checks,fatal_error:{name:error?.name??'UnknownError',message:String(error?.message??error)},scope:'INCOMPLETE_AUDIT_NEVER_GATE_APPROVAL'},null,2)+'\n');
  process.exitCode=2;
}
