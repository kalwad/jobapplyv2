"""Prepared independent raw audit. Do not invoke before explicit run closure.

No product/archived code imports, subprocesses, Git queries or network calls.
Source parsing and raw recomputation are independent stdlib implementations.
"""
import argparse
from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import traceback
import unicodedata

HERE = Path(__file__).resolve().parent
ROOT = Path('/Users/tanishkalwad/jobapplyv2')
CHECKS = []


def check(name, condition, details=None):
    CHECKS.append({'name': name, 'pass': bool(condition), 'details': details})


def unique(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError('DUPLICATE_JSON_KEY:' + key)
        out[key] = value
    return out


def parse(body):
    return json.loads(body, object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def raw(path):
    if path.is_symlink() or not path.is_file():
        raise ValueError('REGULAR_NONLINK_INPUT_REQUIRED:' + str(path))
    return path.read_bytes()


def digest(body):
    return 'sha256:' + hashlib.sha256(body).hexdigest()


def compact(value, sort=True):
    return json.dumps(value, sort_keys=sort, ensure_ascii=False,
                      separators=(',', ':'), allow_nan=False).encode()


def canonical_digest(value):
    # Invoked only on JSON strings/booleans/integer declaration metadata and
    # path/digest inventories; never used to rewrite floating benchmark values.
    return digest(compact(value))


def normalize(value):
    value = unicodedata.normalize('NFKC', value or '').replace('ß', 'ss').replace('ẞ', 'ss')
    whitespace = r'[\t\n\v\f\r \u00a0\u1680\u2000-\u200a\u2028\u2029\u202f\u205f\u3000\ufeff]+'
    value = re.sub(whitespace, ' ', value)
    value = re.sub(r"[^A-Za-z0-9 .,:!?()'&+/@_-]", ' ', value)
    value = re.sub(whitespace, ' ', value).strip()
    value = re.sub(r'^[^A-Za-z0-9]+', '', value)[:512].strip()
    return value if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 .,:!?()'&+/@_-]{0,511}", value) else ''


def declarations():
    def text(name):
        return raw(HERE / 'source' / name).decode()
    producer = text('e2e/extension/extension-w14-w06.spec.ts')
    catalog_source = text('apps/mock-ats-lab/site/src/catalog/cases.ts')
    transitions_source = text('e2e/mock-ats-lab/support/expected-transitions.ts')
    provenance_block = re.search(r'const PROVENANCE = \{(.*?)\} as const;', catalog_source, re.S)[1]
    provenance = dict((key, json.loads(value)) for key, value in re.findall(
        r'(author|reviewer):\s*("(?:\\.|[^"\\])*")', provenance_block))
    catalog = []
    for case_id, title, route, surfaces in re.findall(
            r'fixtureCase\(\s*("(?:\\.|[^"\\])*")\s*,\s*("(?:\\.|[^"\\])*")\s*,\s*("(?:\\.|[^"\\])*")\s*,\s*\[(.*?)\]\s*,?\s*\)',
            catalog_source, re.S):
        catalog.append({'id': json.loads(case_id), 'title': json.loads(title),
                        'route': json.loads(route), 'surfaces': re.findall(r'"([^"\n]+)"', surfaces),
                        'provenance': provenance, 'syntheticData': True})
    facts_start = producer.index('const FACTS:')
    facts_block = producer[producer.index('= [', facts_start) + 2:producer.index('];', facts_start) + 1]
    facts = [dict((key, json.loads(value)) for key, value in re.findall(
        r'(concept|value|valueToken):\s*("(?:\\.|[^"\\])*")', body))
        for body in re.findall(r'\{([^{}]*)\}', facts_block)]
    contact_start = producer.index('const EXPECTED_CONTACT:')
    contact_block = producer[producer.index('= {', contact_start) + 2:producer.index('};', contact_start) + 1]
    contact = {route: dict((key, json.loads(value)) for key, value in re.findall(
        r'"([^"\n]+)":\s*("(?:\\.|[^"\\])*")', fields))
        for route, fields in re.findall(r'"([^"\n]+)":\s*\{([^{}]*)\}', contact_block)}
    transitions_block = transitions_source[transitions_source.index('{', transitions_source.index('export const EXPECTED_TRANSITIONS:')):]
    transitions_block = transitions_block[:transitions_block.rindex('}') + 1]
    transitions = parse(re.sub(r',\s*([}\]])', r'\1', transitions_block))
    expected = {'format_version': 'W14_W06_PREDECLARED_COHORT_1', 'authority': 'NONE',
                'catalog': catalog, 'contact': contact, 'facts': facts,
                'scenario_transitions': transitions}
    catalog_manifest = parse(raw(HERE / 'source/apps/mock-ats-lab/catalog.manifest.json'))
    catalog_serialization = {'catalogVersion': '1.0.0', 'schemaVersion': 1, 'cases': catalog}
    check('catalog_original_manifest_digest', hashlib.sha256(compact(catalog_serialization, sort=False)).hexdigest() == catalog_manifest['sha256'])
    check('source_expected_counts', len(catalog) == 32 and len({r['route'] for r in catalog}) == 16
          and len(facts) == 11 and len(transitions) == 32 and sum(map(len, transitions.values())) == 67)
    check('declared_positive_denominator_43_across_18_rows', sum(len(contact.get(r['route'], {})) for r in catalog) == 43
          and sum(bool(contact.get(r['route'])) for r in catalog) == 18)
    return expected


def audit(args):
    proof = Path(args.proof_dir)
    baseline = parse(raw(HERE / 'source-manifest.json'))
    before = parse(raw(Path(args.before)))
    after = parse(raw(Path(args.after)))
    completion = parse(raw(Path(args.completion)))
    check('closed_completion_record', isinstance(completion.get('ended_at'), str) and 'exit_code' in completion)
    for label, snapshot in [('before', before), ('after', after)]:
        check('exact_clean_source:' + label, snapshot.get('head') == baseline['expected_commit']
              and snapshot.get('tree') == baseline['expected_tree'] and snapshot.get('status') == '')
    before_files = {r['path']: r for r in before['tracked_files']}
    after_files = {r['path']: r for r in after['tracked_files']}
    for row in baseline['files']:
        body = raw(HERE / 'source' / row['path'])
        check('copied_source:' + row['path'], len(body) == row['bytes'] and digest(body) == 'sha256:' + row['sha256'])
        check('immutable_snapshot_source:' + row['path'],
              before_files.get(row['path'], {}).get('sha256') == row['sha256'] == after_files.get(row['path'], {}).get('sha256'))
    expected = declarations()
    predeclared_bytes = raw(proof / 'predeclared-cohort.json')
    compressed = raw(proof / 'mounted-run.json.gz')
    with gzip.GzipFile(fileobj=io.BytesIO(compressed)) as stream:
        decompressed = stream.read(64 * 1024 * 1024 + 1)
    if len(decompressed) > 64 * 1024 * 1024:
        raise ValueError('MOUNTED_RAW_SIZE_BOUND_EXCEEDED')
    bundle = parse(decompressed)
    assessment_bytes = raw(proof / 'assessment.json')
    external = parse(assessment_bytes)
    embedded = bundle['assessment']
    check('raw_gzip_byte_binding', external.get('compressed_bundle_digest') == digest(compressed))
    check('external_embedded_assessment_exact', {k: v for k, v in external.items() if k != 'compressed_bundle_digest'} == embedded)
    check('predeclared_expected_source_exact', parse(predeclared_bytes) == bundle['expected'] == expected)
    expected_digest = canonical_digest(expected)
    check('predeclared_expected_canonical_digest', bundle['expected_digest'] == expected_digest)
    check('run_and_assessment_scope', bundle['format_version'] == 'W14_W06_MOUNTED_CONTACT_RUN_1'
          and bundle['authority'] == embedded['authority'] == 'NONE'
          and embedded['format_version'] == 'W14_W06_MOUNTED_CONTACT_ASSESSMENT_1'
          and embedded['gate_decision'] == 'NOT_DECIDED' and embedded['complete_development_gate_evidence'] is False)
    check('exact_configuration', bundle['configuration'] == {
        'mounted_pages': True, 'body_replacement': False, 'artificial_rerender': False,
        'settle_budget_ms': 125, 'navigation_enabled': False, 'submission_enabled': False,
        'trace_mode': 'retain-on-failure'})
    source = bundle['source']
    check('producer_source_inventory_digest', source['digest'] == canonical_digest(source['files']))
    check('producer_source_anchor', source['commit'] == baseline['expected_commit'] and source['tree'] == baseline['expected_tree']
          and source['source_state'] == 'INVENTORY_SCOPED_NO_FROZEN_TREE_CLAIM')
    expected_source_paths = sorted(path for path in before_files if not path.startswith('docs/evidence/')
                                   and path != 'node_modules' and not path.endswith('/node_modules'))
    check('producer_exact_scoped_inventory_paths', [r['path'] for r in source['files']] == expected_source_paths)
    check('producer_inventory_matches_full_snapshots', all(r['digest'] == 'sha256:' + before_files.get(r['path'], {}).get('sha256', '')
          == 'sha256:' + after_files.get(r['path'], {}).get('sha256', '') for r in source['files']))
    check('producer_endpoint_flags', embedded['source_unchanged'] is True and embedded['build_unchanged'] is True)
    build = bundle['build']
    check('initial_build_inventory_bounded_unique_paths', isinstance(build, list) and bool(build)
          and len({r['path'] for r in build}) == len(build)
          and all(re.fullmatch(r'sha256:[0-9a-f]{64}', r['digest']) for r in build))
    rows = bundle['rows']
    catalog = expected['catalog']
    check('all_32_catalog_rows_exact_order', [r['fixture_id'] for r in rows] == [r['id'] for r in catalog])
    all_fields = []
    durations = []
    derived_rows = []
    for row, fixture in zip(rows, catalog):
        prefix = row['fixture_id'] + ':'
        check(prefix + 'catalog_binding', row['route'] == fixture['route'] and row['surfaces'] == fixture['surfaces']
              and row['expected_digest'] == expected_digest)
        transitions = [{'transition': v, 'state': 'NOT_EXERCISED_BY_CONTACT_ONLY_CAMPAIGN'}
                       for v in expected['scenario_transitions'][fixture['id']]]
        check(prefix + 'scenario_transition_nonexecution', row['scenario_transitions'] == transitions)
        cohort = expected['contact'].get(row['route'], {})
        scored = []
        candidate = row['candidate']
        if candidate is not None:
            duration = candidate['scan_fill_duration_ms']
            check(prefix + 'candidate_non_authoritative_finite_duration', candidate['authority'] == 'NONE'
                  and candidate['format_version'] == 'W14_MOUNTED_CONTACT_OBSERVATION_1'
                  and isinstance(duration, (int, float)) and duration >= 0 and duration < float('inf'))
            durations.append(duration)
        for frame in row['after']:
            check(prefix + 'frame_url_digest', frame['url_digest'] == digest(('frame-document-url-v1\0' + frame['url']).encode()))
            scans = [] if candidate is None else [r for r in candidate['frameResults']
                if r['scan']['frame_context']['document_url_digest'] == frame['url_digest']]
            check(prefix + 'unique_frame_scan_join:' + frame['url_digest'], len(scans) <= 1)
            scan = scans[0] if scans else None
            for field in frame['state']['fields']:
                matches = [] if scan is None else [d for d in scan['scan']['descriptors']
                    if normalize(d['label']['normalized_text']) == normalize(field['label'])]
                descriptor = matches[0] if len(matches) == 1 else None
                reconciliation = None if scan is None else scan['reconciliation']
                inventory = None
                if reconciliation is not None and reconciliation['status'] == 'RECONCILED':
                    inventory = next((item for item in reconciliation['inventory']['items']
                        if descriptor is not None and item['field_id'] == descriptor['field_id']), None)
                actions = [e for e in frame['state']['physical']['events'] if e['key'] in field['members']]
                before_frame = next((f for f in row['before'] if f['url_digest'] == frame['url_digest']), None)
                initial = None if before_frame is None else next((f for f in before_frame['state']['fields']
                    if f['key'] == field['key'] and f['shadow'] == field['shadow']), None)
                expectation = cohort.get(field['key']) if frame['url'] == 'http://127.0.0.1:4761' + row['route'] else None
                supported = expectation is not None
                item = dict(field)
                item.update(frame_url_digest=frame['url_digest'], supported_contact=supported,
                    expected_value_digest=None if expectation is None else canonical_digest(expectation),
                    final_value_digest=canonical_digest(field['value']),
                    initial_value_digest=None if initial is None else canonical_digest(initial['value']),
                    physical_actions=actions, scanner_matches=len(matches), descriptor=descriptor,
                    reconciliation_item=inventory,
                    correct_contact_fill=supported and field['value'] == expectation and len(actions) == 1
                        and inventory is not None and inventory['category'] == 'VERIFIED_FILLED',
                    unsupported_write=not supported and len(actions) > 0,
                    unsupported_value_changed=not supported and initial is not None and initial['value'] != field['value'],
                    required_unreported=field['required'] and not field['disabled']
                        and (inventory is None or inventory['category'] != 'VERIFIED_FILLED')
                        and not (inventory is not None and inventory.get('required') is True
                                 and inventory.get('visible') and inventory.get('enabled')),
                    scanner_gap=len(matches) != 1)
                scored.append(item)
        check(prefix + 'entire_scored_projection_recomputed', row['scored'] == scored)
        missing = [key for key in cohort if not any(f['key'] == key and f['supported_contact'] for f in scored)]
        check(prefix + 'missing_cohort_exact_and_empty', row['missing_cohort_controls'] == missing == [])
        state = ('MEASUREMENT_ERROR' if row['error'] is not None else 'REQUIRED_REPORTING_GAP'
                 if any(f['required_unreported'] for f in scored) else 'MISSING_EXPECTED_CONTROL'
                 if missing else 'OBSERVED_UNSUPPORTED_ONLY' if not cohort else 'CONTACT_COHORT_SCORED')
        check(prefix + 'measurement_state', row['measurement_state'] == state)
        check(prefix + 'no_navigation_observed', row['final_url_unchanged'] is True
              and row['before'][0]['url'] == row['after'][0]['url'] == 'http://127.0.0.1:4761' + row['route'])
        all_fields.extend(scored)
        derived_rows.append({'fixture_id': row['fixture_id'], 'measurement_state': state,
                             'supported': sum(f['supported_contact'] for f in scored),
                             'observed_fields': len(scored)})
    safety = {
        'unsupported_writes': sum(f['unsupported_write'] for f in all_fields),
        'unsupported_value_changes': sum(f['unsupported_value_changed'] for f in all_fields),
        'duplicate_primary_events': sum(max(0, len(f['physical_actions']) - 1) for f in all_fields),
        'button_clicks': sum(f['state']['physical']['buttonClicks'] for r in rows for f in r['after']),
        'submissions': sum(f['state']['physical']['submissions'] for r in rows for f in r['after']),
    }
    counts = {
        'expected_catalog_cases': len(catalog), 'recorded_catalog_cases': len(rows),
        'expected_contact_controls': sum(f['supported_contact'] for f in all_fields),
        'correct_contact_controls': sum(f['correct_contact_fill'] for f in all_fields),
        'unreported_required_controls': sum(f['required_unreported'] for f in all_fields),
        'scanner_gaps': sum(f['scanner_gap'] for f in all_fields),
        'errors': sum(r['error'] is not None for r in rows), 'safety': safety,
    }
    check('all_assessment_counts_recomputed', all(embedded[k] == v for k, v in counts.items()), counts)
    check('producer_acceptance_requirements', counts['expected_contact_controls'] == counts['correct_contact_controls'] == 43
          and counts['errors'] == counts['scanner_gaps'] == counts['unreported_required_controls'] == 0
          and all(v == 0 for v in safety.values()))
    shadow_summary = None
    shadow_path = proof / 'shadow-required-gap.json'
    if shadow_path.exists():
        shadow = parse(raw(shadow_path))
        top = next((f for f in shadow['frames'] if f['frame_context']['is_top_frame']), None)
        descriptor = None if top is None else next((d for d in top['descriptors']
            if d['label']['normalized_text'] == 'Emergency contact name (required)'), None)
        decision = shadow['decision']
        reconciliation = shadow['reconciliation']
        check('standalone_shadow_required_nonfill_scope', shadow['authority'] == 'NONE'
              and shadow['fixture_id'] == 'MAL-SHD-001' and shadow['application_actions'] == 0
              and shadow['actual']['open_root'] is True and shadow['actual']['required'] is True
              and shadow['actual']['value'] == '' and top is not None and top['root_status'] == 'FOUND'
              and descriptor is not None and descriptor['required'] is True
              and decision is not None and decision['status'] == 'RESOLVED' and decision['resolution']['decision']['final_decision'] != 'FILL'
              and reconciliation is not None and reconciliation['status'] == 'RECONCILED'
              and reconciliation['inventory']['counts']['required_unresolved'] >= 1
              and reconciliation['inventory']['readiness'] == 'NOT_READY')
        shadow_summary = {'sha256': digest(raw(shadow_path)), 'independent_captures_claimed': 1,
                          'post_final_value_serialized': False}
    return {'scope': 'SUPPLEMENTAL_MOUNTED_CONTACT_RAW_AUDIT_NOT_FORMAL_W15',
        'authority': 'NONE', 'outer_aggregate_exit_code_descriptive_only': completion['exit_code'],
        'raw_inputs': [{'path': str(path), 'bytes': len(body), 'sha256': digest(body)} for path, body in [
            (proof / 'predeclared-cohort.json', predeclared_bytes), (proof / 'mounted-run.json.gz', compressed),
            (proof / 'assessment.json', assessment_bytes)]],
        'counts': counts, 'observed_field_occurrences': len(all_fields),
        'unsupported_field_occurrences': sum(not f['supported_contact'] for f in all_fields),
        'measurement_states': dict(Counter(r['measurement_state'] for r in derived_rows)),
        'derived_rows': derived_rows, 'scenario_transitions_exercised': 0,
        'single_row_scan_fill_duration_ms_descriptive': durations,
        'initial_build_inventory_digest': canonical_digest(build),
        'end_build_and_source_inventory_serialized': False, 'standalone_shadow': shadow_summary,
        'limitations': ['Primary DOM event/final-value observation is not native-setter-call instrumentation.',
            '32 catalog rows repeat16 routes and imply no67 scenario transition executions.',
            '11 synthetic contact facts differ from W12 ten-fact input.',
            '125ms settle/single-row timings are not native128 target20 p95 or Gate A performance proof.',
            'End source/build equality is producer-reported; full immutable source closure is audited separately.',
            'No whole-gate, architecture, ATS support, final submission or formal independent/owner decision claim.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ['proof-dir', 'before', 'after', 'completion', 'output']:
        parser.add_argument('--' + name, required=True)
    parser.add_argument('--confirm-completed-run', action='store_true', required=True)
    args = parser.parse_args()
    output = Path(args.output)
    if (not args.confirm_completed_run or not output.is_absolute() or output.exists() or output.is_symlink()
            or output.resolve().is_relative_to(ROOT) or output.resolve().is_relative_to(Path(args.proof_dir).resolve().parent)):
        raise ValueError('EXPLICIT_CLOSED_RELEASE_AND_FRESH_OUTSIDE_AUDIT_OUTPUT_REQUIRED')
    result = None
    failure = None
    try:
        result = audit(args)
    except Exception:
        failure = traceback.format_exc()
        check('audit_completed_without_structure_or_checker_error', False, failure)
    final = {'status': 'CLEAR' if all(r['pass'] for r in CHECKS) else 'FINDING',
             'checks_passed': sum(r['pass'] for r in CHECKS), 'checks_total': len(CHECKS),
             'checks': CHECKS, 'summary': result, 'checker_failure': failure,
             'checker_sha256': digest(raw(Path(__file__))), 'product_actions': 0, 'root_writes': 0}
    output.mkdir()
    (output / 'findings.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: final[k] for k in ['status', 'checks_passed', 'checks_total']}))
    return int(final['status'] != 'CLEAR')


if __name__ == '__main__':
    raise SystemExit(main())
