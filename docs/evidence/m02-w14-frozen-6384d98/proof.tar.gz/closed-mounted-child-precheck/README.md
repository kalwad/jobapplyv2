Derived preliminary audit computations from an inline Python stdlib tool call after root released the closed browser child payloads. These are not raw actor records and do not assert overall aggregate success, final source neutrality, a formal W15 review or a Gate A decision. The later complete mounted audit joins the actual before/after/completion records and independently checks the full projection.

The original actor files remain under the frozen proof's mounted32 directory. No product or archived script was imported or executed, and no raw input was changed.
