from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import tarfile

RUN = Path('/tmp/japp-w14-clean-owner-waiver-20261017')
OUT = Path('/tmp/japp-w14-frozen-6384d98-retained')
ROOTS = [
    ('frozen-full', RUN / 'proof'),
    ('doctor-correction', RUN / 'doctor-correction'),
    ('manual-inspection', RUN / 'manual-inspection'),
    ('independent-full-audit', Path('/tmp/japp-w14-6384-full-independent-audit')),
    ('independent-mounted-audit', Path('/tmp/japp-w14-6384-mounted-independent-audit')),
    ('full-audit-preparation', Path('/tmp/japp-w14-6384-full-audit-preparation')),
    ('mounted-audit-original', Path('/tmp/japp-mounted32-audit-preparation')),
    ('mounted-audit-corrected', Path('/tmp/japp-mounted32-audit-preparation-v2')),
    ('mounted-source-review-history', Path('/tmp/japp-mounted32-source-peer-review')),
    ('closed-mounted-child-precheck', Path('/tmp/japp-w14-6384-mounted-closed-child-precheck')),
    ('closed-browser-child-precheck', Path('/tmp/japp-w14-6384-browser-closed-child-precheck')),
]
assert not OUT.exists()
completion = json.loads((RUN / 'proof/completion.json').read_text())
assert completion['exit_code'] == 0
assert completion['head_unchanged'] and completion['tree_unchanged'] and completion['tracked_inventory_unchanged']
assert completion['status_before'] == completion['status_after'] == ''
for stage in json.loads((RUN / 'proof/commands.json').read_text()):
    assert stage['exit_code'] == 0
for _, root in ROOTS:
    assert root.is_dir(), root

payload = {}
def sha(b):
    return hashlib.sha256(b).hexdigest()
def add(name, body):
    p = PurePosixPath(name)
    assert not p.is_absolute() and '..' not in p.parts and name not in payload
    payload[name] = body

for prefix, root in ROOTS:
    for p in sorted(root.rglob('*')):
        assert not p.is_symlink(), p
        if '__pycache__' in p.parts:
            continue
        if p.is_file():
            add(prefix + '/' + p.relative_to(root).as_posix(), p.read_bytes())
add('source/executed-clean-clone-wrapper.py', Path('/tmp/japp-w14-clean-owner-waiver-wrapper-20261017.py').read_bytes())
add('source/prepare-full-auditor.py', Path('/tmp/japp-w14-prepare-6384-full-audit.py').read_bytes())
add('source/retention-builder.py', Path(__file__).read_bytes())
rows = [{'path': n, 'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(payload.items())]
add('retained-members.json', (json.dumps({'files': rows}, indent=2) + '\n').encode())
OUT.mkdir()
archive = OUT / 'proof.tar.gz'
with archive.open('wb') as f:
    with gzip.GzipFile(fileobj=f, mode='wb', filename='', mtime=0) as g:
        with tarfile.open(fileobj=g, mode='w', format=tarfile.PAX_FORMAT) as t:
            for n, b in sorted(payload.items()):
                info = tarfile.TarInfo(n)
                info.size = len(b)
                info.mode = 0o644
                info.mtime = 0
                t.addfile(info, io.BytesIO(b))
allrows = [{'path': n, 'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(payload.items())]
manifest = {
    'archive_path': 'proof.tar.gz', 'archive_sha256': sha(archive.read_bytes()),
    'archive_bytes': archive.stat().st_size, 'regular_members': len(allrows),
    'files': allrows,
    'scope': 'Actual clean6384 clone full verification with target20, contact200, mounted32 and independent raw audits. Original pnpm builtin doctor and explicit repository doctor correction are distinct. No W15 verdict or owner gate approval.',
}
(OUT / 'retention-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
with tarfile.open(archive, 'r:gz') as t:
    members = t.getmembers()
    assert len(members) == len(allrows)
    for member, row in zip(members, allrows):
        assert member.isfile() and member.name == row['path']
        b = t.extractfile(member).read()
        assert len(b) == row['bytes'] and sha(b) == row['sha256']
print(json.dumps({k: manifest[k] for k in ('archive_sha256', 'archive_bytes', 'regular_members')}, indent=2))
