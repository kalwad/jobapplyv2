"""Source preparation only. Never import or invoke the prepared audit here."""

import difflib
import hashlib
import json
from pathlib import Path

old = Path('/tmp/japp-w14-730-full-audit-preparation/audit-final.mjs')
out = Path('/tmp/japp-w14-6384-full-audit-preparation')
wrapper = Path('/tmp/japp-w14-clean-owner-waiver-wrapper-20261017.py')
if out.exists():
    raise RuntimeError('FRESH_PREPARATION_DIRECTORY_REQUIRED')
text = old.read_text()
wrapper_body = wrapper.read_bytes()
wrapper_sha = hashlib.sha256(wrapper_body).hexdigest()
out.mkdir()
(out / 'baseline-730-audit-source.mjs').write_bytes(old.read_bytes())
(out / 'wrapper-source.py').write_bytes(wrapper_body)
text = text.replace("const ROOT = '/Users/tanishkalwad/jobapplyv2';", "const ROOT = '/tmp/japp-w14-clean-owner-waiver-20261017/clone';\nconst SOURCE_REPOSITORY = '/Users/tanishkalwad/jobapplyv2';\nconst PREPARATION = '/tmp/japp-w14-6384-full-audit-preparation';\nconst DOCTOR_CORRECTION = '/tmp/japp-w14-clean-owner-waiver-20261017/doctor-correction';")
text = text.replace("'/tmp/japp-w14-concurrency-frozen-20261016'", "'/tmp/japp-w14-clean-owner-waiver-20261017/proof'")
text = text.replace('730c641a9855fc3e95620636314a28d0eee8439a', '6384d98156ae198cd93d7b35d1bb28b501ed475e').replace('7402873a081286dbddce5b93ed4db997fea4f24d', 'd2c1fd5e50bbbd31a926cbf251d6140d11b9b9c4').replace('ae42e5bf466dff2a1df91deec4747fe6af47e73ee44ad49dca3e53453b67e72d', wrapper_sha)
start = text.index("const before=json('before.json')")
end = text.index('// Inspect immutable Git objects', start)
text = text[:start] + '''const before=json('before.json'), after=json('after.json'), completion=json('completion.json'), command=json('wrapper-command.json'), stages=json('commands.json');
const clean = s => s.head===HEAD && s.tree===TREE && s.status==='';
check('original_wrapper_exact_pinned_source',sha(readFileSync(PREPARATION+'/wrapper-source.py'))===WRAPPER&&command.wrapper_sha256===WRAPPER);
check('outer_wrapper_identity_and_four_task_flags',equal(command.outer_argv,['/tmp/japp-w14-clean-owner-waiver-wrapper-20261017.py',HEAD])&&command.source_repository===SOURCE_REPOSITORY&&command.expected_head===HEAD&&equal(command.task_environment,{JAPP_W13_PERFORMANCE_SAMPLES:'20',JAPP_W14_REQUIRE_TARGET_PERFORMANCE:'1',JAPP_W14_ARTIFACT_DIRECTORY:INPUT+'/w14',JAPP_W14_W06_ARTIFACT_DIRECTORY:INPUT+'/mounted32'}));
check('source_exact_clean_6384_clone_before_after',clean(before)&&clean(after));
check('tracked_arrays_equal_and_nonempty',Array.isArray(before.tracked_files)&&before.tracked_files.length>0&&equal(before.tracked_files,after.tracked_files),before.tracked_files?.length);
check('tracked_digests_recomputed',sha(JSON.stringify(before.tracked_files))===before.tracked_inventory_digest&&sha(JSON.stringify(after.tracked_files))===after.tracked_inventory_digest&&before.tracked_inventory_digest===after.tracked_inventory_digest);
check('closure_flags_head_tree_tracked_neutral',completion.head_unchanged===true&&completion.tree_unchanged===true&&completion.tracked_inventory_unchanged===true&&completion.status_before===''&&completion.status_after==='');
const expectedStages=[['clone',['git','clone','--no-hardlinks','--no-checkout',SOURCE_REPOSITORY,ROOT]],['checkout',['git','checkout','--detach',HEAD]],['pnpm-install',['pnpm','install','--frozen-lockfile']],['uv-sync',['uv','sync','--locked']],['playwright-install',['pnpm','exec','playwright','install','chromium']],['doctor',['pnpm','doctor']],['aggregate',['pnpm','verify']]];
check('exact_clone_locked_setup_builtin_doctor_and_full_stages',Array.isArray(stages)&&stages.length===7&&stages.every((row,i)=>row.name===expectedStages[i][0]&&equal(row.argv,expectedStages[i][1])&&row.cwd===(i===0?'/tmp/japp-w14-clean-owner-waiver-20261017':ROOT)),stages.map(row=>({name:row.name,argv:row.argv,cwd:row.cwd,exit_code:row.exit_code})));
check('all_original_stage_logs_hash_bytes_and_exit0',stages.every(row=>{const body=input(row.name+'.log');return row.exit_code===0&&body.length===row.log_bytes&&sha(body)===row.log_sha256;}));
const time=s=>Date.parse(s), aggregateStage=stages.find(row=>row.name==='aggregate');
check('closure_writer_timestamps_monotonic_not_aliases',Number.isFinite(time(command.started_at))&&time(command.started_at)<=time(stages[0].started_at)&&stages.every(row=>Number.isFinite(time(row.started_at))&&Number.isFinite(time(row.ended_at))&&time(row.started_at)<=time(row.ended_at))&&time(stages[4].ended_at)<=time(before.captured_at)&&time(before.captured_at)<=time(stages[5].started_at)&&time(aggregateStage.ended_at)<=time(after.captured_at)&&time(after.captured_at)<=time(completion.ended_at));
check('full_process_exit_zero',completion.exit_code===0,completion.exit_code);
// pnpm11's bare doctor is builtin; never relabel its success as repository doctor.
const doctorInputInventory=inventory(DOCTOR_CORRECTION);
const correctedDoctor=JSON.parse(bytes(DOCTOR_CORRECTION,'command.json').toString('utf8'));
const correctedDoctorLog=bytes(DOCTOR_CORRECTION,'repository-doctor.log');
check('separate_actual_repository_doctor_command',equal(correctedDoctor.argv,['pnpm','run','doctor'])&&correctedDoctor.cwd===ROOT&&correctedDoctor.exit_code===0&&typeof correctedDoctor.correction==='string',correctedDoctor);
check('separate_repository_doctor_raw_hash_and_summary',correctedDoctorLog.length===correctedDoctor.log_bytes&&sha(correctedDoctorLog)===correctedDoctor.log_sha256&&correctedDoctorLog.length===3226&&sha(correctedDoctorLog)==='6367e0a7a7b8d1c7d09d93d9aacd76b43461ba34a638d74a4dde74682911bc23'&&/27.*pass/i.test(correctedDoctorLog.toString('utf8')));
check('doctor_correction_timing_explicit_no_serial_order_claim',time(correctedDoctor.started_at)>=time(aggregateStage.started_at)&&time(correctedDoctor.started_at)<=time(correctedDoctor.ended_at),{started_at:correctedDoctor.started_at,ended_at:correctedDoctor.ended_at,scope:'Separate repository doctor overlapped aggregate static/typecheck per producer; no strict doctor-before-aggregate claim.'});
''' + text[end:]
text = text.replace("check('python_1454_ordinary_passes',pySummaries.length===1&&pySummaries[0].passed===1454,pySummaries);", """check('python_1492_ordinary_passes',pySummaries.length===1&&pySummaries[0].passed===1492&&!/\\b(?:failed|skipped|xfailed|xpassed)\\b/.test(pySummaries[0]?.summary??''),pySummaries);
const pyInventory=JSON.parse(objectsByPath.get('scripts/python-test-inventory.v1.json').body.toString('utf8'));
const common=pyInventory.common.node_ids,posix=pyInventory.posix_only_node_ids;
check('committed_python_common1490_posix2_exact_digest',common.length===1490&&pyInventory.common.count===1490&&sha(common.join('\\n')+'\\n')===pyInventory.common.sha256&&posix.length===2&&new Set([...common,...posix]).size===1492,{common:common.length,posix:posix});
const collectCommands=commands.filter(row=>row.argv.startsWith('uv run pytest ')&&row.argv.includes('--collect-only'));
const collectIds=(collectCommands[0]?.body??'').split('\\n').map(row=>row.trim()).filter(row=>/^[^\\s]+\\.py::/.test(row));
check('actual_collected1492_exact_committed_no_skipped_cohort',collectCommands.length===1&&collectIds.length===1492&&new Set(collectIds).size===1492&&equal(sorted(collectIds),sorted([...common,...posix])),{commands:collectCommands.length,ids:collectIds.length});""")
text = text.replace("map(m=>({passed:+m[1],seconds:+m[2]}));", "map(m=>({passed:+m[1],seconds:+m[2],summary:m[0]}));")
text = text.replace('source_bound_730_clean','source_bound_6384_clean').replace('INDEPENDENT_W14_730_FULL_RESULT_AUDIT_1','INDEPENDENT_W14_6384_CLEAN_CLONE_RESULT_AUDIT_1').replace('exact immutable730 Git tree','exact immutable6384 clone Git tree')
text = text.replace("check('input_artifacts_unchanged_during_audit',equal(initialInventory,inventory(INPUT)));", "check('input_artifacts_unchanged_during_audit',equal(initialInventory,inventory(INPUT))&&equal(doctorInputInventory,inventory(DOCTOR_CORRECTION)));\ncheck('mounted32_retention_directory_present_not_implicitly_accepted',lstatSync(INPUT+'/mounted32').isDirectory(),{scope:'Mounted32 raw semantics require the separate prepared independent mounted checker/report; directory presence is not execution PASS.'});")
text = text.replace("'Public scored coverage, actual R9 comparison, Simplify, native current-platform aggregate and owner gate decision require their own evidence. R8 coordinator was never invoked and supplies no guard-refusal or actor observation.','Owner holdout and per-W stops alone are waived by ADR-0006.'", "'Mounted32 raw review is a separate required audit component; this master checker does not silently count it as passed. Existing R9/730/1d proofs remain distinct historical anchors.','ADR-0006 waives owner holdout and per-W stopping; ADR-0007 waives only direct Simplify and executed public-form evidence. Numerical accuracy/safety/performance, legacy/other baselines, independent W15 and concrete owner decision remain binding.','Original bare pnpm doctor called the pnpm11 builtin. A separately retained pnpm run doctor is actual repository doctor; no strict serial doctor-before-aggregate order is claimed.'")
(out / 'audit-final.mjs').write_text(text)
(out / 'source-adaptation.diff').write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),text.splitlines(True),fromfile='historical-730-audit',tofile='prepared-6384-clone-audit')))
(out / 'PLAN.md').write_text('Prepared source only; never import or invoke until root explicitly declares this full run closed.\n\n6384/d2c1 immutable clone Git blobs, wrapper/no-hardlinks locked setup and actual full command;1492 POSIX/common1490 exact collection;3859units/242browser/62controlled+2inspection;20target raw nearest-rank p95;200contact raw scoring/native witnesses/source/build/report/replay. Mounted32 semantics are separately prepared by fresh_safety_review and must be joined before final evidence acceptance. Raw failures remain failures; no product rerun is authorized by this checker. Original builtin pnpm doctor is distinct from separate pnpm run doctor correction, whose timing is not strict serial. Current original wrapper source is copied exactly; no active output or clone was read during preparation. Historical730/1d/R9 and ADR6/ADR7 scopes stay distinct. No W15/GateA verdict.\n')
rows=[{'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.iterdir()) if p.is_file()]
(out / 'source-manifest.json').write_text(json.dumps({'authority':'NONE','status':'PREPARED_SOURCE_ONLY_NOT_INVOKED_PENDING_SOURCE_REVIEW','self_excluded':'source-manifest.json','files':rows},indent=2)+'\n')
print(json.dumps({'directory':str(out),'auditor_sha256':hashlib.sha256((out/'audit-final.mjs').read_bytes()).hexdigest(),'wrapper_sha256':wrapper_sha,'manifest_sha256':hashlib.sha256((out/'source-manifest.json').read_bytes()).hexdigest()},indent=2))
