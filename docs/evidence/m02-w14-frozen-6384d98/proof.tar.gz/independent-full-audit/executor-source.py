"""Execute only independent read-only audit code after root's explicit closure."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import time

base = Path('/tmp/japp-w14-clean-owner-waiver-20261017/proof')
jobs = [
    ('full', Path('/tmp/japp-w14-6384-full-independent-audit'), [
        '/opt/homebrew/opt/node@24/bin/node',
        '/tmp/japp-w14-6384-full-audit-preparation/audit-final.mjs',
        '--after-explicit-root-completion',
    ]),
    ('mounted', Path('/tmp/japp-w14-6384-mounted-independent-audit'), [
        '/usr/bin/python3',
        '/tmp/japp-mounted32-audit-preparation-v2/audit-mounted32.py',
        '--proof-dir', str(base / 'mounted32'),
        '--before', str(base / 'before.json'),
        '--after', str(base / 'after.json'),
        '--completion', str(base / 'completion.json'),
        '--output', '/tmp/japp-w14-6384-mounted-independent-audit',
        '--confirm-completed-run',
    ]),
]
for _, out, _ in jobs:
    if out.exists():
        raise RuntimeError('FRESH_FIXED_OUTSIDE_AUDIT_OUTPUT_REQUIRED:' + str(out))

failed = False
for label, out, argv in jobs:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic()
    result = subprocess.run(argv, cwd='/tmp', stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    elapsed = time.monotonic() - tick
    if not out.exists():
        out.mkdir()
    (out / 'attempt-1.stdout').write_bytes(result.stdout)
    (out / 'attempt-1.stderr').write_bytes(result.stderr)
    source = Path(argv[1]).read_bytes()
    (out / ('attempt-1-source.mjs' if label == 'full' else 'attempt-1-source.py')).write_bytes(source)
    (out / 'executor-source.py').write_bytes(Path(__file__).read_bytes())
    record = {
        'scope': 'ACTUAL_READONLY_AUDIT_INVOCATION_AFTER_EXPLICIT_ROOT_FULL_CLOSURE',
        'authority': 'NONE', 'argv': argv, 'cwd': '/tmp',
        'started_at': started,
        'ended_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'elapsed_seconds': elapsed, 'exit_code': result.returncode,
        'source_sha256': hashlib.sha256(source).hexdigest(),
        'stdout_bytes': len(result.stdout), 'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
        'stderr_bytes': len(result.stderr), 'stderr_sha256': hashlib.sha256(result.stderr).hexdigest(),
        'product_reruns': 0, 'root_writes': 0,
    }
    (out / 'attempt-1-command.json').write_text(json.dumps(record, indent=2) + '\n')
    if label == 'full' and result.stdout:
        (out / 'attempt-1-findings.json').write_bytes(result.stdout)
    print(json.dumps({'audit': label, 'output': str(out), 'exit_code': result.returncode,
                      'stdout_bytes': len(result.stdout), 'stderr_bytes': len(result.stderr)}), flush=True)
    failed |= result.returncode != 0
raise SystemExit(int(failed))
