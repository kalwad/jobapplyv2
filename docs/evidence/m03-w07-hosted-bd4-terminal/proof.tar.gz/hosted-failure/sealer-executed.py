from pathlib import Path,PurePosixPath
import hashlib,json,shutil,stat,tarfile
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');P=E/'ci-bd4cffd';c=json.loads((P/'collector-closure.json').read_bytes());assert len(c['terminal_runs'])==5 and len(c['closed_jobs'])==13 and len(c['artifact_ids_retained'])==8
for source,name in [('collect-ci-bd4cffd.py','collector-executed.py'),('collect-ci-f5a05ba.py','collector-reference-f5a05ba.py'),('prepare-ci-bd4cffd-source.py','source-observer-executed.py'),('audit-ci-bd4cffd.py','data-auditor-executed.py'),('analyze-ci-bd4cffd-cases.py','case-observer-executed.py'),('observe-ci-bd4cffd-windows-python.py','windows-python-observer-executed.py'),('observe-ci-bd4cffd-windows-python-original-NOT-EXECUTED.py','windows-python-original-NOT-EXECUTED.py'),('observe-ci-bd4cffd-ubuntu-python.py','ubuntu-python-observer-executed.py'),('observe-ci-bd4cffd-ubuntu-visual.py','ubuntu-visual-observer-executed.py'),('observe-ci-bd4cffd-ubuntu-python-initial-scope-label.py','ubuntu-python-initial-scope-label.py'),('ci-bd4cffd-ubuntu-python-initial-scope-label.json','ubuntu-python-initial-scope-label.json')]:shutil.copy2(E/source,P/name)
for pattern in ['ci-bd4cffd-collector.*.log','ci-bd4cffd-data-audit.*.log','ci-bd4cffd-cases.*.log','ci-bd4cffd-windows-python.*.log','ci-bd4cffd-ubuntu-python*.log','ci-bd4cffd-ubuntu-visual.*.log']:
 for source in E.glob(pattern):shutil.copy2(source,P/source.name)
shutil.copy2(Path(__file__),P/'sealer-executed.py')
(P/'HANDOFF.md').write_text('''# Closed hosted bd4 CI — failures retained

Main CI40926988782 attempt1 is FAILURE. Each canonical platform passes19ACTIVE suites and fails Python. Mac15:1FAIL2623PASS954.62s; Ubuntu24.04:1FAIL2623PASS665.12s; Windows2025:2FAIL2620PASS1114.85s. All three fail the copied bytecode-cache fixture PORT-SRC-009. Windows also correctly refuses a fixture-generated backslash archive member packages\\windows-portable.zip. Product member/cache guards stay strong; later source corrections are not substituted into this run. The dependent package matrix is one actual skipped job123667601519. No portable Windows or Ubuntu GNOME package export exists.

API sourceS=bd4cffd7f61f99f77520e7dc522f852488cdd9d3; actual three canonical tested checkoutsM=fa044b9f37c59bbafece98c09e4bbad6d25337c3, parents4745149f4b5da7190b5b0c68753f8ec07bed572d andS. M differs fromS; exacttreeT=75d79ae7fc14e9a02c1f326e5376b16d74a7736e is shared. All2294 paths/OIDs/sizes/Git executable classes join actual API recursive trees and independently hashed immutable LOCAL Git blob bodies (516719623bytes). Individual API blob bodies were not all downloaded. Later local a7caf710/native zoom work is a separate epoch.

All five runs are terminal:main plus GNOMEprepare40926988770/GNOMElifecycle40926988781/Win11prepare40926988881/Win11lifecycle40926988866. The four auxiliary policy gates succeed as SKIP_NO_ROOT_REQUEST, with downstream source checks/download/VM skipped. No native source compile or download/install/VM credit follows. There are13actualjobs and8originalAPI/artifact archives. All168 API calls are GET, exit0/reaped/originalgroupsABSENT/no signals/stopreason; snapshots and raw commands/hashes remain. Official aggregate log ZIPs equal every non-skipped API job log. Exact API artifact digests/sizes, safe ZIP members/full attributes and retained bytes are bound. A loader diagnostic artifact205files is retained; it is not a curated portable package.

All platforms report doctor28; fresh uncached TS4006/15tasks; browser278+2+62+17. Actual native sets are316Windows/342Mac/338Ubuntu, each identical across3feature modes plus separate1+10; repeated modes are not unique case totals. Complete Python selection is2622common and same2additionalPOSIX cases. Twelve Bearer identities per platform collapse to opaque [*** raw lines:source-projected Counters match, but individual masked identities/status suffixes and masking mechanism stay unresolved. The original65537-byte oversized payload is unchanged; its new short-ID case is observed PASS by exact selection, complete counts and every nonpassing row naming other cases, not by a direct per-case status row. Prior f5a oversized-ID failures remain immutable.

Collector-owned data audit3824joins and case projection109checks pass AS RECORDED FAILURE. These are not new different independent reviews. The case method adapts the earlier f5a peer parser with provenance retained. Windows summary handling was corrected for failed-first totals before first execution; the original NOT-EXECUTED helper remains. An initial Ubuntu-only scope label typo is separately retained and corrected; outcomes/data did not change. Four Ubuntu visual spot checks are legible/unclipped; all33primary files19PNG14JSON/29unique and33attachmentaliases are bound. Other screenshots are retained without claiming individual visual inspection or pixel identity with local captures. Artifact names playwright-failure reflect aggregate failure while all browser suites pass.

Collector closed0 at19:02:24UTC, retaining the three actual terminal failures. No rerun/cancel/push, subject/artifact execution, native GUI/install/VM actor or canonical write occurred. No final post-success clean-worktree assertion is claimed on these failed jobs. No native Windows11/GNOME, M03 acceptance, release or finished-product credit follows.

Actual run: https://github.com/kalwad/jobapplyv2/actions/runs/40926988782
''')
rows=[]
for p in sorted(P.rglob('*')):
 if p.is_dir():continue
 assert not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)
 if p.name in {'MANIFEST.json','SEAL.json','proof.tar.gz'} and p.parent==P:continue
 b=p.read_bytes();rows.append({'path':str(p.relative_to(P)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'full_mode':p.lstat().st_mode})
(P/'MANIFEST.json').write_text(json.dumps({'scope':'Exact collector-owned raw GET/log/ZIP/artifact/data/source-observer evidence, as recorded failure; not new independent review/native credit.','files':rows},indent=2)+'\n')
with tarfile.open(P/'proof.tar.gz','w:gz') as t:
 for row in rows:t.add(P/row['path'],arcname=row['path'],recursive=False)
 t.add(P/'MANIFEST.json',arcname='MANIFEST.json',recursive=False)
with tarfile.open(P/'proof.tar.gz') as t:
 members=t.getmembers();assert len(members)==len(rows)+1 and all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in members)
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'full_mode':p.lstat().st_mode}
seal={'outcome':'CLOSED_FAILURE_RETAINED','handoff':pin(P/'HANDOFF.md'),'manifest':pin(P/'MANIFEST.json'),'proof':pin(P/'proof.tar.gz'),'regular_members':len(rows)+1,'data_joins':3824,'case_projection_checks':109,'no_subject_execution':True,'canonical_writes':0}
(P/'SEAL.json').write_text(json.dumps(seal,indent=2)+'\n');print(json.dumps(seal))
