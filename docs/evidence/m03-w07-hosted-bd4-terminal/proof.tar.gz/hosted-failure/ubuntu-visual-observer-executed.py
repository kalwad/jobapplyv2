from pathlib import Path
import hashlib,json,struct
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');P=E/'ci-bd4cffd';A=P/'artifacts/12922628385/contents-attempt-1'
files=[p for p in A.rglob('*') if p.is_file()];primary=[p for p in files if 'attachments' not in p.relative_to(A).parts];aliases=[p for p in files if 'attachments' in p.relative_to(A).parts]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();inspected={'shell-home-1120.png','shell-home-320.png','shell-diagnostics-1120.png','desktop-text-resize-200.png'};rows=[]
for p in sorted(primary):
 b=p.read_bytes();r={'path':str(p.relative_to(A)),'bytes':len(b),'sha256':sha(p),'full_mode':p.stat().st_mode,'matching_aliases':[str(q.relative_to(A)) for q in aliases if sha(q)==sha(p)]}
 if p.suffix=='.png':
  assert b[:8]==b'\x89PNG\r\n\x1a\n' and b[12:16]==b'IHDR';dims=struct.unpack('>II',b[16:24]);assert 1<=dims[0]<=4096 and 1<=dims[1]<=8192
  r['png_dimensions']=list(dims);r['visually_inspected']=p.name in inspected
 rows.append(r)
assert len(files)==66 and len(primary)==33 and len(aliases)==33 and all(any(sha(p)==sha(q) for q in primary) for p in aliases)
report={'scope':'Actual completed Ubuntu hosted browser evidence only; no native package/desktop/VM credit.','artifact_id':12922628385,'original_archive_sha256':sha(P/'artifacts/12922628385/attempt-1.zip'),'files':66,'primary_files':33,'primary_png':sum(p.suffix=='.png' for p in primary),'primary_json':sum(p.suffix=='.json' for p in primary),'duplicate_attachment_aliases':33,'primary_unique_byte_bodies':len(set(sha(p) for p in primary)),'visual_spot_check_count':4,'visual_spot_check':'Wide/narrow home, wide diagnostics and 200% text-resize diagnostics are legible, aligned and contain no visible clipping in the inspected full-page images. Browser mock/unavailable-service states remain explicit. Other15 PNGs retained and hash-bound, not individually visually inspected by this observer.','prior_local_png_identity':'No hosted primary PNG is byte-identical to any same-basename local bd4 PNG; platform rendering is distinct, so local screenshot identity is not transferred.','rows':rows}
(P/'ubuntu-visual-observation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='rows'}))
