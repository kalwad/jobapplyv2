"""Adapted read-only API/log/artifact collector; no artifact/subject execution.

Parent reference collect-ci-80e68ac.py remains unchanged. This version retains
the exact discovered three workflows, paginates finite metadata, records direct
GET child custody, canonical ZIP paths/full modes and immutable Git body joins.
"""
from pathlib import Path, PurePosixPath
import datetime,hashlib,json,os,re,signal,stat,subprocess,time,zipfile
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
BASE=E/'ci-f5a05ba';BASE.mkdir(exist_ok=False)
HEAD='f5a05bad78d8421a5c1e0094eb928fdbb464cdc7';TREE='aa9fbaa9addd16052eaeca6259852bc00bb03702'
RUNS={40914184628:'ci',40914184664:'prepare unreviewed GNOME dependency candidate',40914185229:'reviewed Ubuntu GNOME package lifecycle'}
REPO='repos/kalwad/jobapplyv2/'
receipts=[];closed_jobs=set();artifacts_done=set();artifact_attempts={};checkout_bindings={};previous={};terminal=set();failures=[]
def now():return datetime.datetime.now(datetime.UTC).isoformat()
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        while chunk:=stream.read(1024*1024):h.update(chunk)
    return h.hexdigest()
def dump(path,obj):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,indent=2)+'\n')
def group_state(pid):
    try:os.killpg(pid,0);return 'PRESENT'
    except ProcessLookupError:return 'ABSENT'
def api(endpoint,name,*,timeout=50,binary=False,max_bytes=32*1024*1024):
    target=BASE/name;target.parent.mkdir(parents=True,exist_ok=True);start=now();started=time.monotonic();signals=[];stop=None;code=None;child=None
    error=target.with_name(target.name+'.stderr')
    try:
        with target.open('xb') as output,error.open('xb') as stderr:
            child=subprocess.Popen(['gh','api',REPO+endpoint],stdout=output,stderr=stderr,start_new_session=True)
            try:
                while child.poll() is None:
                    if time.monotonic()-started>timeout:stop='TIMEOUT';break
                    if target.stat().st_size>max_bytes or error.stat().st_size>1024*1024:stop='OUTPUT_LIMIT';break
                    time.sleep(.1)
                if stop is not None:
                    try:os.killpg(child.pid,signal.SIGTERM);signals.append('SIGTERM')
                    except ProcessLookupError:pass
                    try:code=child.wait(timeout=5)
                    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);signals.append('SIGKILL');code=child.wait(timeout=5)
                else:code=child.wait(timeout=5)
            finally:
                if child.returncode is None:
                    try:os.killpg(child.pid,signal.SIGTERM);signals.append('SIGTERM')
                    except ProcessLookupError:pass
                    try:code=child.wait(timeout=5)
                    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);signals.append('SIGKILL');code=child.wait(timeout=5)
    except BaseException as exc:
        dump(BASE/'collector-exception.json',{'endpoint':endpoint,'name':name,'error_type':type(exc).__name__,'error':str(exc),'utc':now()});raise
    receipt={'endpoint':endpoint,'method':'GET','start_utc':start,'end_utc':now(),'exit_code':code,'path':name,'bytes':target.stat().st_size,'sha256':digest(target),'stderr_bytes':error.stat().st_size,'stderr_sha256':digest(error),'pid':child.pid,'pgid':child.pid,'child_reaped':child.returncode is not None,'group_after_wait':group_state(child.pid),'signals':signals,'stop_reason':stop}
    receipts.append(receipt);dump(BASE/'api-receipts.json',receipts)
    if code!=0 or stop is not None:return None
    if target.stat().st_size>max_bytes:return None
    if binary:return target
    try:return json.loads(target.read_text())
    except ValueError as exc:
        dump(target.with_name(target.name+'.parse-error.json'),{'error':str(exc),'raw_retained':True});return None
def paginated(endpoint,key,name,index):
    all_rows=[];total=None
    for page in range(1,11):
        data=api(endpoint+('&' if '?' in endpoint else '?')+f'per_page=100&page={page}',f'{name}/{index:03d}-p{page}.json')
        if data is None:return None
        if total is None:total=data['total_count']
        assert total<=1000,'finite API list bound'
        all_rows.extend(data[key])
        if len(all_rows)>=total:break
    assert len(all_rows)==total
    return {'total_count':total,key:all_rows}
def safe_unzip(path,target,*,max_total=1536*1024*1024,max_file=600*1024*1024):
    target.mkdir(parents=True,exist_ok=False);members=[];seen=set();total=0;started=time.monotonic()
    with zipfile.ZipFile(path) as archive:
        assert len(archive.infolist())<=12000,'member count bound'
        for item in archive.infolist():
            name=item.filename;pure=PurePosixPath(name);canonical=pure.as_posix()
            assert '\\' not in name and '\0' not in name and not pure.is_absolute() and '..' not in pure.parts and pure.parts and all(':' not in p for p in pure.parts),'unsafe ZIP path'
            assert name.rstrip('/')==canonical and canonical not in seen,'noncanonical/duplicate ZIP path';seen.add(canonical)
            mode=item.external_attr>>16;kind=stat.S_IFMT(mode);assert kind in (0,stat.S_IFREG,stat.S_IFDIR),'nonregular archive node'
            p=target/canonical
            if item.is_dir():assert kind in (0,stat.S_IFDIR);p.mkdir(parents=True,exist_ok=True);continue
            assert kind!=stat.S_IFDIR and item.file_size<=max_file,'single member/class bound';total+=item.file_size;assert total<=max_total,'expanded byte bound'
            p.parent.mkdir(parents=True,exist_ok=True)
            with archive.open(item) as src,p.open('xb') as out:
                size=0
                while chunk:=src.read(1024*1024):
                    assert time.monotonic()-started<120,'expanded archive wallclock bound';size+=len(chunk);assert size<=item.file_size;out.write(chunk)
            assert size==item.file_size
            members.append({'path':canonical,'bytes':size,'sha256':digest(p),'zip_mode':mode,'zip_create_system':item.create_system,'zip_external_attr':item.external_attr,'retained_full_mode':p.lstat().st_mode})
    return members
def source_join(tree):
    assert not tree['truncated']
    api_files={x['path']:x for x in tree['tree'] if x['type']=='blob'}
    return {'blob_count':len(api_files),'exact_paths':set(api_files)==set(immutable['files']),'all_oid_mode_size_equal':set(api_files)==set(immutable['files']) and all(api_files[p]['sha']==r['git_blob'] and api_files[p]['mode']==r['git_mode'] and api_files[p].get('size')==r['bytes'] for p,r in immutable['files'].items()),'local_bodies_SHA1_framed_SHA256_and_fullmodes':True}
def bind_checkout(job_id,path):
    raw=path.read_text(errors='replace');found=re.search(r'log -1 --format=%H\r?\n[^\r\n]*?\b([0-9a-f]{40})\s*\r?\n',raw)
    if not found:
        dump(BASE/f'checkout-unobserved/{job_id}.json',{'job_id':job_id,'reason':'official checkout hash line not observed; no checkout source assumption'});return
    commit=found.group(1)
    if commit not in checkout_bindings:
        info=api('git/commits/'+commit,'source-bindings/'+commit+'-commit.json')
        if info is None:return
        tree_id=info['tree']['sha'];tree=api('git/trees/'+tree_id+'?recursive=1','source-bindings/'+commit+'-tree.json')
        if tree is None:return
        checkout_bindings[commit]={'observed_checkout_commit':commit,'observed_in_jobs':[],'tree':tree_id,'same_tree_as_run_head':tree_id==TREE,'is_distinct_from_api_head':commit!=HEAD,'parents':[x['sha'] for x in info['parents']],'source_join':source_join(tree)}
    checkout_bindings[commit]['observed_in_jobs'].append(job_id);dump(BASE/'checkout-source-bindings.json',checkout_bindings)
    print(json.dumps({'checkout_binding':checkout_bindings[commit]}),flush=True)
def retention_manifests(target):
    verification=[]
    for manifest in target.rglob('manifest.json'):
        try:value=json.loads(manifest.read_text())
        except (UnicodeError,ValueError):continue
        if not isinstance(value,dict) or not isinstance(value.get('files'),dict):continue
        verified=[]
        for name,row in value['files'].items():
            q=PurePosixPath(name);assert isinstance(name,str) and not q.is_absolute() and '..' not in q.parts and q.as_posix()==name and '\\' not in name
            p=manifest.parent/name
            verified.append({'path':name,'present_regular':p.is_file() and not p.is_symlink(),'matches':p.is_file() and p.stat().st_size==row['bytes'] and digest(p)==row['sha256'],'full_mode':p.lstat().st_mode if p.exists() else None})
        verification.append({'manifest':manifest.relative_to(target).as_posix(),'declared_count':value.get('file_count'),'declared_bytes':value.get('bytes'),'verified_members':verified,'all_exact':all(x['present_regular'] and x['matches'] for x in verified)})
    return verification
def collect_artifacts(run,index):
    data=paginated(f'actions/runs/{run}/artifacts','artifacts',f'runs/{run}/artifact-lists',index)
    if data is None:return
    for artifact in data['artifacts']:
        identity=artifact['id'];attempt=artifact_attempts.get(identity,0)
        if identity in artifacts_done or artifact['expired'] or attempt>=3:continue
        artifact_attempts[identity]=attempt+1;folder=f'artifacts/{identity}';dump(BASE/f'{folder}/metadata.json',artifact)
        if artifact['size_in_bytes']>1536*1024*1024:
            dump(BASE/f'{folder}/not-downloaded.json',{'reason':'artifact exceeds finite bound','metadata':artifact});artifacts_done.add(identity);continue
        path=api(f'actions/artifacts/{identity}/zip',f'{folder}/attempt-{attempt+1}.zip',timeout=240,binary=True,max_bytes=1536*1024*1024)
        if path is None:continue
        target=BASE/f'{folder}/contents-attempt-{attempt+1}'
        try:
            members=safe_unzip(path,target);dump(BASE/f'{folder}/members-attempt-{attempt+1}.json',members);verification=retention_manifests(target);dump(BASE/f'{folder}/retention-verification-attempt-{attempt+1}.json',verification)
            artifacts_done.add(identity)
            retained={'artifact_id':identity,'run':run,'name':artifact['name'],'archive':str(path.relative_to(BASE)),'archive_bytes':path.stat().st_size,'archive_sha256':digest(path),'safe_regular_members':len(members),'retention_manifests_exact':all(x['all_exact'] for x in verification),'contents':str(target.relative_to(BASE))}
            dump(BASE/f'{folder}/closure.json',retained);print(json.dumps({'artifact_retained':retained}),flush=True)
            exports=[]
            for p in target.rglob('*'):
                if p.is_file() and (p.name=='windows-portable.zip' or p.name.endswith('.deb') or p.name.endswith('.AppImage')):exports.append({'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p),'full_mode':p.lstat().st_mode})
            if exports:dump(BASE/f'{folder}/package-export-candidates.json',{'artifact':retained,'files':exports,'scope':'Retained bytes only; no install, native run, release, or platform acceptance.'});print(json.dumps({'package_export_candidates':exports,'artifact_id':identity,'artifact_name':artifact['name']}),flush=True)
        except (OSError,ValueError,AssertionError,zipfile.BadZipFile) as exc:
            dump(BASE/f'{folder}/retention-error-attempt-{attempt+1}.json',{'metadata':artifact,'error_type':type(exc).__name__,'error':str(exc),'raw_zip_retained':True});print(json.dumps({'artifact_review_error':identity,'attempt':attempt+1,'error_type':type(exc).__name__,'error':str(exc)}),flush=True)

immutable_path=E/'ci-f5a05ba-immutable-git-source-sha256.json';immutable=json.loads(immutable_path.read_text());assert immutable['commit']==HEAD and immutable['tree']==TREE and immutable['blob_count']==2255
(BASE/'immutable-git-source-sha256.json').write_bytes(immutable_path.read_bytes())
(BASE/'collector-executed.py').write_bytes(Path(__file__).read_bytes());(BASE/'collector-reference-80e68ac.py').write_bytes((E/'collect-ci-80e68ac.py').read_bytes())
dump(BASE/'collector-context.json',{'runs':RUNS,'head':HEAD,'tree':TREE,'source_blobs':2255,'start_utc':now(),'scope':'READ_ONLY_GET_API_OFFICIAL_LOG_ARTIFACT_RETENTION; NO_CANONICAL_WRITES_OR_SUBJECT_EXECUTION','parent_collector_sha256':digest(E/'collect-ci-80e68ac.py'),'source_body_binding':'All2255 immutable local Git bytes/framedSHA1/SHA256/fullmodes, joined to exact API OID/mode/size inventory. API does not separately download all blob bodies.'})
head=api('git/commits/'+HEAD,'head-commit.json');assert head and head['sha']==HEAD and head['tree']['sha']==TREE
source=api('git/trees/'+TREE+'?recursive=1','head-tree.json');assert source and source_join(source)['all_oid_mode_size_equal']
dump(BASE/'immutable-source-api-join.json',source_join(source))
for index in range(181):
    for run_id,expected_name in RUNS.items():
        if run_id in terminal:continue
        folder=f'runs/{run_id}';run=api(f'actions/runs/{run_id}',f'{folder}/snapshots/{index:03d}-run.json');data=paginated(f'actions/runs/{run_id}/jobs','jobs',f'{folder}/snapshots/jobs',index)
        if run is None or data is None:continue
        assert run['head_sha']==HEAD and run['run_attempt']==1 and run['name']==expected_name
        jobs=data['jobs'];state=(run['status'],run['conclusion'],tuple((j['id'],j['name'],j['status'],j['conclusion'],next((s['number'] for s in j['steps'] if s['status']=='in_progress'),None)) for j in jobs))
        if state!=previous.get(run_id):print(json.dumps({'observed_utc':now(),'run':run_id,'name':expected_name,'status':run['status'],'conclusion':run['conclusion'],'jobs':[{'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'current_step':next((s['name'] for s in j['steps'] if s['status']=='in_progress'),None)} for j in jobs]}),flush=True);previous[run_id]=state
        new_closed=False
        for job in jobs:
            if job['status']!='completed' or job['id'] in closed_jobs:continue
            closed_jobs.add(job['id']);new_closed=True;dump(BASE/f'{folder}/closed-jobs/{job["id"]}.json',job)
            if job['conclusion']=='skipped':continue
            path=api(f'actions/jobs/{job["id"]}/logs',f'{folder}/closed-jobs/{job["id"]}.log',binary=True,max_bytes=64*1024*1024)
            if path is None:failures.append({'kind':'LOG_NOT_RETAINED','run':run_id,'job':job['id']});continue
            bind_checkout(job['id'],path);print(json.dumps({'closed_job_retained':job['id'],'run':run_id,'name':job['name'],'conclusion':job['conclusion'],'bytes':path.stat().st_size,'sha256':digest(path)}),flush=True)
            if job['conclusion']!='success':
                raw=path.read_text(errors='replace');tail=raw[raw.rfind('== verification summary =='):] if '== verification summary ==' in raw else raw[-16000:];(BASE/f'{folder}/closed-jobs/{job["id"]}-failure-excerpt.txt').write_text(tail);failures.append({'kind':'TERMINAL_JOB_FAILURE','run':run_id,'job':job['id'],'name':job['name'],'conclusion':job['conclusion']})
        if new_closed or run['status']=='completed':collect_artifacts(run_id,index)
        if run['status']=='completed':
            dump(BASE/f'{folder}/terminal-run.json',run);dump(BASE/f'{folder}/terminal-jobs.json',data)
            logs=api(f'actions/runs/{run_id}/logs',f'{folder}/official-logs.zip',timeout=120,binary=True,max_bytes=256*1024*1024)
            if logs is not None:
                try:members=safe_unzip(logs,BASE/f'{folder}/logs',max_total=256*1024*1024,max_file=64*1024*1024);dump(BASE/f'{folder}/log-members.json',members)
                except (OSError,ValueError,AssertionError,zipfile.BadZipFile) as exc:dump(BASE/f'{folder}/log-retention-error.json',{'error_type':type(exc).__name__,'error':str(exc)})
            terminal.add(run_id);print(json.dumps({'terminal_run':run_id,'name':expected_name,'conclusion':run['conclusion'],'jobs':len(jobs)}),flush=True)
        dump(BASE/'collector-progress.json',{'updated_utc':now(),'terminal_runs':sorted(terminal),'closed_jobs':sorted(closed_jobs),'artifact_ids_retained':sorted(artifacts_done),'failures':failures,'checkout_bindings':checkout_bindings})
    if len(terminal)==len(RUNS):
        dump(BASE/'collector-closure.json',{'end_utc':now(),'terminal_runs':sorted(terminal),'closed_jobs':sorted(closed_jobs),'artifact_ids_retained':sorted(artifacts_done),'checkout_bindings':checkout_bindings,'failures':failures,'no_subject_execution':True,'canonical_writes':0});print(json.dumps({'collector_terminal':True,'runs':len(terminal),'jobs':len(closed_jobs),'artifacts':len(artifacts_done),'failures':failures}),flush=True);break
    if index==180:dump(BASE/'collector-time-limit.json',{'end_utc':now(),'product_conclusion':'UNOBSERVED_NOT_ASSUMED','polls':181});break
    time.sleep(30)
