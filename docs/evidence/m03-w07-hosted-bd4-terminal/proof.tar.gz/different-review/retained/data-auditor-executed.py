"""Finite data-only closure audit; no package/subject imports or execution."""
from pathlib import Path,PurePosixPath
import hashlib,json,re,stat,zipfile
BASE=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/ci-bd4cffd')
HEAD='bd4cffd7f61f99f77520e7dc522f852488cdd9d3';TREE='75d79ae7fc14e9a02c1f326e5376b16d74a7736e'
checks=[]
def load(p):return json.loads(p.read_text())
def digest(p):
    value=hashlib.sha256()
    with p.open('rb') as stream:
        while chunk:=stream.read(1024*1024):value.update(chunk)
    return value.hexdigest()
def check(value,name):
    checks.append({'name':name,'pass':bool(value)})
    if not value:raise ValueError(name)
closure=load(BASE/'collector-closure.json');source=load(BASE/'immutable-git-source-sha256.json')
check(source['commit']==HEAD and source['tree']==TREE and source['blob_count']==len(source['files'])==2294 and source['all_git_blob_SHA1_framings_verified'],'exact immutable Git object inventory')
head=load(BASE/'head-commit.json');tree=load(BASE/'head-tree.json')
check(head['sha']==HEAD and head['tree']['sha']==tree['sha']==TREE and not tree['truncated'],'actual API headS/treeT')
api_blobs={r['path']:r for r in tree['tree'] if r['type']=='blob'}
check(set(api_blobs)==set(source['files']),'actual API/local exact2294 paths')
for path,row in source['files'].items():
    api=api_blobs[path]
    check(api['sha']==row['git_blob'] and api['mode']==row['git_mode'] and api['size']==row['bytes'] and row['full_mode']==(stat.S_IFREG|0o644 if row['git_mode']=='100644' else stat.S_IFREG|0o755),'actual immutable blob/encoded Git regular-executable class/size '+path)
for receipt in load(BASE/'api-receipts.json'):
    target=BASE/receipt['path'];error=target.with_name(target.name+'.stderr')
    check(receipt['method']=='GET' and receipt['bytes']==target.stat().st_size and receipt['sha256']==digest(target) and receipt['stderr_bytes']==error.stat().st_size and receipt['stderr_sha256']==digest(error),'actual GET raw byte commitments '+receipt['path'])
    check(receipt['child_reaped'] and receipt['group_after_wait']=='ABSENT','GET direct child custody '+receipt['path'])

jobs={};runs={};raw_outcomes=[];job_checkout={};canonical_merges=set()
for run_id in closure['terminal_runs']:
    folder=BASE/'runs'/str(run_id);run=load(folder/'terminal-run.json');data=load(folder/'terminal-jobs.json')
    check(run['id']==run_id and run['head_sha']==HEAD and run['run_attempt']==1 and run['status']=='completed','actual exact-run terminal result '+str(run_id))
    check(len(data['jobs'])==data['total_count'],'actual complete paginated job inventory '+str(run_id))
    runs[str(run_id)]={'name':run['name'],'conclusion':run['conclusion'],'event':run['event'],'url':run['html_url'],'head_sha':run['head_sha'],'jobs':[]}
    for job in data['jobs']:
        check(job['run_id']==run_id and job['status']=='completed','actual terminal job '+str(job['id']))
        jobs[job['id']]=job;runs[str(run_id)]['jobs'].append({k:job[k] for k in ['id','name','status','conclusion','started_at','completed_at']})
        path=folder/'closed-jobs'/f'{job["id"]}.log'
        check(job['conclusion']=='skipped' or path.is_file(),'actual non-skipped official job log '+str(job['id']))
        if path.exists():
            raw=path.read_text(errors='replace')
            checkout=re.search(r'log -1 --format=%H\r?\n[^\r\n]*?\b([0-9a-f]{40})\s*\r?\n',raw)
            if checkout:job_checkout[job['id']]=checkout.group(1)
            check(checkout is not None,'actual checkout observed in official job log '+str(job['id']))
            if run_id==40926988782 and checkout:canonical_merges.add(checkout.group(1))
            raw_outcomes.append({'job':job['id'],'name':job['name'],'conclusion':job['conclusion'],'checkout_observed':checkout.group(1) if checkout else None,'verification_summary':raw[raw.rfind('== verification summary =='):] if '== verification summary ==' in raw else None,'numeric_test_result_lines':[line for line in raw.splitlines() if re.search(r'\b\d+ passed\b|test result:|Test Files|\bTests\s+\d+|doctor.*(?:passed|checks)',line,re.I)]})

    # Official whole-run ZIP remains an independent raw log retention channel.
    archive=folder/'official-logs.zip';member_rows=load(folder/'log-members.json')
    with zipfile.ZipFile(archive) as z:
        members=[m for m in z.infolist() if not m.is_dir()]
        check(len(members)==len(member_rows),'actual official full-run log member count '+str(run_id))
        rows={r['path']:r for r in member_rows};check(len(rows)==len(member_rows),'actual distinct official log names '+str(run_id))
        for member in members:
            name=member.filename;pure=PurePosixPath(name);row=rows[name];retained=folder/'logs'/name
            check(not pure.is_absolute() and '..' not in pure.parts and pure.as_posix()==name and '\\' not in name and stat.S_IFMT(member.external_attr>>16) in (0,stat.S_IFREG),'actual official log safe member '+str(run_id)+':'+name)
            value=hashlib.sha256();size=0
            with z.open(member) as stream:
                while chunk:=stream.read(1024*1024):size+=len(chunk);value.update(chunk)
            check(size==row['bytes']==retained.stat().st_size and value.hexdigest()==row['sha256']==digest(retained) and row['zip_mode']==member.external_attr>>16 and row['retained_full_mode']==retained.lstat().st_mode,'actual official ZIP/log bytes/fullmode '+str(run_id)+':'+name)

# Both official channels must retain the same complete non-skipped job bytes.
for job_id,job in jobs.items():
    if job['conclusion']=='skipped':continue
    folder=BASE/'runs'/str(job['run_id']);jobhash=digest(folder/'closed-jobs'/f'{job_id}.log')
    matches=[r['path'] for r in load(folder/'log-members.json') if r['sha256']==jobhash]
    check(bool(matches),'official API job log equals complete aggregate ZIP member '+str(job_id))
bindings=load(BASE/'checkout-source-bindings.json')
for commit,binding in bindings.items():
    info=load(BASE/'source-bindings'/(commit+'-commit.json'));actual_tree=load(BASE/'source-bindings'/(commit+'-tree.json'))
    blobs={r['path']:r for r in actual_tree['tree'] if r['type']=='blob'}
    check(info['sha']==commit and info['tree']['sha']==binding['tree']==actual_tree['sha'] and not actual_tree['truncated'],'actual checkout commit/tree '+commit)
    check(binding['same_tree_as_run_head']==(actual_tree['sha']==TREE) and binding['is_distinct_from_api_head']==(commit!=HEAD),'preserve observed S versus M distinction '+commit)
    check(set(blobs)==set(source['files']) and all(blobs[p]['sha']==r['git_blob'] and blobs[p]['mode']==r['git_mode'] and blobs[p]['size']==r['bytes'] for p,r in source['files'].items()),'actual tested checkout full blob/mode projection '+commit)
    for job_id in binding['observed_in_jobs']:check(job_id in jobs,'checkout binding references actual terminal job '+str(job_id))

check(len(canonical_merges)==1,'one actual canonical tested/package checkout M')
merge=next(iter(canonical_merges));check(merge!=HEAD,'preserve actual canonical M distinct from APIheadS')
canonical_run=load(BASE/'runs/40926988782/terminal-run.json');pr=canonical_run['pull_requests'];check(len(pr)==1 and pr[0]['head']['sha']==HEAD,'actual PR headS metadata')
merge_info=load(BASE/'source-bindings'/(merge+'-commit.json'))
check([p['sha'] for p in merge_info['parents']]==[pr[0]['base']['sha'],HEAD],'actual tested mergeM direct parents base and S')
check(merge_info['tree']['sha']==TREE,'actual tested mergeM tree equals sourceT')
for job_id,commit in job_checkout.items():check(commit in bindings and job_id in bindings[commit]['observed_in_jobs'],'actual per-job checkout source binding '+str(job_id))

artifacts=[];exports=[]
for path in sorted((BASE/'artifacts').glob('*/closure.json')):
    data=load(path);folder=path.parent;metadata=load(folder/'metadata.json');archive=BASE/data['archive'];contents=BASE/data['contents']
    check(metadata['id']==data['artifact_id'] and metadata['workflow_run']['id']==data['run'] and metadata['workflow_run']['head_sha']==HEAD,'actual artifact API run/head binding '+str(data['artifact_id']))
    check(archive.stat().st_size==data['archive_bytes']==metadata['size_in_bytes'] and digest(archive)==data['archive_sha256'] and metadata['digest']=='sha256:'+data['archive_sha256'],'actual raw artifact/API archive digest/size '+str(data['artifact_id']))
    attempt=int(archive.stem.split('-')[-1]);members=load(folder/f'members-attempt-{attempt}.json')
    with zipfile.ZipFile(archive) as z:
        regular=[m for m in z.infolist() if not m.is_dir()]
        check(len(regular)==len(members)==data['safe_regular_members'],'actual archive member inventory '+str(data['artifact_id']))
        rows={m['path']:m for m in members}
        for member in regular:
            name=member.filename;pure=PurePosixPath(name);check(not pure.is_absolute() and '..' not in pure.parts and pure.as_posix()==name and '\\' not in name and stat.S_IFMT(member.external_attr>>16) in (0,stat.S_IFREG),'actual safe archive member '+name)
            value=hashlib.sha256();size=0
            with z.open(member) as stream:
                while chunk:=stream.read(1024*1024):size+=len(chunk);value.update(chunk)
            row=rows[name];retained=contents/name
            check(size==row['bytes']==retained.stat().st_size and value.hexdigest()==row['sha256']==digest(retained) and row['zip_mode']==member.external_attr>>16 and row['retained_full_mode']==retained.lstat().st_mode,'actual archive-to-retained byte/fullmode '+name)
    for verification in load(folder/f'retention-verification-attempt-{attempt}.json'):
        manifest_path=contents/verification['manifest'];manifest=load(manifest_path);declared=manifest['files']
        check(isinstance(declared,dict) and len(declared)==manifest['file_count'] and sum(r['bytes'] for r in declared.values())==manifest['bytes'],'actual curated manifest count/bytes '+verification['manifest'])
        actual_files={q.relative_to(manifest_path.parent).as_posix() for q in manifest_path.parent.rglob('*') if q.is_file()}
        check(actual_files==set(declared)|{manifest_path.name},'actual curated complete retained file set '+verification['manifest'])
        for name,row in declared.items():
            pure=PurePosixPath(name);member_path=manifest_path.parent/name
            check(not pure.is_absolute() and '..' not in pure.parts and pure.as_posix()==name and '\\' not in name and member_path.is_file() and not member_path.is_symlink() and member_path.stat().st_size==row['bytes'] and digest(member_path)==row['sha256'],'independent actual curated row '+name)
        check(verification['all_exact'],'collector curated match agrees with independent rows '+verification['manifest'])
    candidate=folder/'package-export-candidates.json'
    if candidate.exists():exports.extend(load(candidate)['files'])
    artifacts.append(data)

summary={'head':HEAD,'tree':TREE,'scope':'Collector-owned finite data audit, not a different independent review; GET metadata/official raw bytes and exact immutable local Git bodies/encoded Git executable class. No arbitrary OS permission mode, installed package/native GUI/platform acceptance or universal runtime closure.','runs':runs,'checkout_bindings':bindings,'actual_canonical_tested_merge':merge,'artifacts':artifacts,'export_candidates':exports,'raw_job_result_excerpts':raw_outcomes,'collector_failures':closure['failures'],'checks':checks,'pass_count':len(checks),'fail_count':0}
(BASE/'data-audit.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'pass_count':len(checks),'runs':len(runs),'jobs':len(jobs),'artifacts':len(artifacts),'exports':len(exports),'raw_collector_failures':closure['failures']}))
