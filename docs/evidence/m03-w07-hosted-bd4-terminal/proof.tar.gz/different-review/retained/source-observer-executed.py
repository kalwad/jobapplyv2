"""Read only immutable local Git objects; no checkout, fetch or subject import."""
from pathlib import Path
import hashlib,json,subprocess,time,os,datetime
ROOT=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
REPO=Path('/Users/tanishkalwad/jobapplyv2')
HEAD='bd4cffd7f61f99f77520e7dc522f852488cdd9d3'
TREE='75d79ae7fc14e9a02c1f326e5376b16d74a7736e'
start=time.monotonic()
raw=subprocess.check_output(['git','ls-tree','-r','-z','-l',HEAD],cwd=REPO,timeout=20)
entries=[]
for row in raw.split(b'\0')[:-1]:
    header,path=row.split(b'\t',1);mode,kind,oid,size=header.split()
    assert kind==b'blob' and mode in (b'100644',b'100755')
    entries.append((mode.decode(),oid.decode(),int(size),path.decode('utf-8')))
assert len(entries)==2294 and sum(e[2] for e in entries)<1024*1024*1024
tree=subprocess.check_output(['git','rev-parse',HEAD+'^{tree}'],cwd=REPO,timeout=10).decode().strip();assert tree==TREE
child=subprocess.Popen(['git','cat-file','--batch'],cwd=REPO,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
files={}
try:
    for mode,oid,size,path in entries:
        assert time.monotonic()-start<120
        child.stdin.write((oid+'\n').encode());child.stdin.flush()
        actual_oid,kind,actual_size=child.stdout.readline().split()
        assert actual_oid.decode()==oid and kind==b'blob' and int(actual_size)==size
        framing=hashlib.sha1(b'blob '+str(size).encode()+b'\0');sha256=hashlib.sha256();remaining=size
        while remaining:
            chunk=child.stdout.read(min(1024*1024,remaining));assert chunk
            remaining-=len(chunk);framing.update(chunk);sha256.update(chunk)
        assert child.stdout.read(1)==b'\n' and framing.hexdigest()==oid
        files[path]={'bytes':size,'git_blob':oid,'git_mode':mode,'full_mode':0o100644 if mode=='100644' else 0o100755,'sha256':sha256.hexdigest()}
    child.stdin.close();assert child.wait(timeout=10)==0
finally:
    if child.returncode is None:child.terminate();child.wait(timeout=10)
    child.stdout.close();child.stderr.close()
try:os.killpg(child.pid,0);group_after='PRESENT'
except ProcessLookupError:group_after='ABSENT'
assert group_after=='ABSENT'
packet={'scope':'Exact immutable local Git blob bodies, SHA1 framing, size, SHA256 and encoded Git regular/executable class; not arbitrary OS permission modes or a working-tree snapshot.','git_batch_custody':{'pid':child.pid,'pgid':child.pid,'reaped':child.returncode is not None,'exit_code':child.returncode,'group_after_wait':group_after,'signals':[],'ended_utc':datetime.datetime.now(datetime.UTC).isoformat()},'commit':HEAD,'tree':TREE,'blob_count':len(entries),'seconds':time.monotonic()-start,'all_git_blob_SHA1_framings_verified':True,'files':files}
out=ROOT/'ci-bd4cffd-immutable-git-source-sha256.json';out.write_text(json.dumps(packet,indent=2)+'\n')
print(json.dumps({'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'blob_count':len(entries),'source_bytes':sum(e[2] for e in entries)}))
