"""Safe independent data-review archive; original full packet is digest-bound."""
import gzip
import hashlib
import io
import json
import stat
import tarfile
from pathlib import Path, PurePosixPath

R=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/ci-bd4cffd-independent-review/v1')
def meta(p):
    s=p.lstat();assert stat.S_ISREG(s.st_mode)
    return {'bytes':s.st_size,'full_mode':s.st_mode,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
assert not any((R/name).exists() for name in ('MANIFEST.json','proof.tar.gz','SEAL.json'))
files=[p for folder in ('retained','history') for p in (R/folder).rglob('*') if p.is_file()]+[R/name for name in ('REVIEW.md','DATA-REVIEW.json','review_data.py','seal.py')]
rows=[{'path':p.relative_to(R).as_posix(),**meta(p)} for p in sorted(set(files))]
manifest={'verdict':'CLEAR_AS_RECORDED_FAILURE','files':rows,'scope':'own audit/report and selected original raw/source/metadata retained; all982 original full-packet members independently verified and bound by original proof/manifest digests, not re-exported as a second full original packet'}
(R/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');expected={r['path']:r for r in rows};expected['MANIFEST.json']={'path':'MANIFEST.json',**meta(R/'MANIFEST.json')}
with (R/'proof.tar.gz').open('wb') as output,gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as archive:
    for name,row in sorted(expected.items()):
        p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts
        data=(R/name).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=row['full_mode']&0o7777;info.mtime=0;info.type=tarfile.REGTYPE;archive.addfile(info,io.BytesIO(data))
with tarfile.open(R/'proof.tar.gz','r:gz') as archive:
    members=archive.getmembers();assert len(members)==len(expected)==len({m.name for m in members}) and {m.name for m in members}==set(expected)
    for m in members:
        assert m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts
        stream=archive.extractfile(m);assert stream is not None;data=stream.read();row=expected[m.name]
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'] and stat.S_IFREG|m.mode==row['full_mode']
seal={'verdict':'CLEAR_AS_RECORDED_FAILURE','review':meta(R/'REVIEW.md'),'data':meta(R/'DATA-REVIEW.json'),'manifest':meta(R/'MANIFEST.json'),'proof':meta(R/'proof.tar.gz'),'safe_regular_members':len(expected),'uncompressed_bytes':sum(r['bytes'] for r in expected.values()),'original_packet_unchanged':'all original declared bytes/fullmodes/proof hash verified; no original writes'}
(R/'SEAL.json').write_text(json.dumps(seal,indent=2)+'\n');print(json.dumps(seal))
