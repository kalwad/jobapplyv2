"""Independent finite retained-data review. No subject imports or execution."""
import ast
from collections import Counter
import hashlib
import json
import os
import re
import selectors
import shlex
import shutil
import stat
import subprocess
import tarfile
import time
import zipfile
from pathlib import Path, PurePosixPath

P=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/ci-bd4cffd')
R=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/ci-bd4cffd-independent-review/v1')
C=Path('/Users/tanishkalwad/jobapplyv2')
S='bd4cffd7f61f99f77520e7dc522f852488cdd9d3'
M='fa044b9f37c59bbafece98c09e4bbad6d25337c3'
T='75d79ae7fc14e9a02c1f326e5376b16d74a7736e'
BASE='4745149f4b5da7190b5b0c68753f8ec07bed572d'
checks=[]
def check(name,value,detail=None):
    checks.append({'name':name,'pass':bool(value),'detail':detail});assert value,(name,detail)
def load(path):return json.loads(path.read_bytes())
def stream_digest(stream,cap):
    h=hashlib.sha256();size=0
    while block:=stream.read(1024*1024):size+=len(block);assert size<=cap;h.update(block)
    return size,h.hexdigest()
def digest(path):
    with path.open('rb') as stream:return stream_digest(stream,128*1024*1024)[1]
def meta(path):
    info=path.lstat();assert stat.S_ISREG(info.st_mode),str(path)
    return {'bytes':info.st_size,'full_mode':info.st_mode,'sha256':digest(path)}
def safe(name,directory=False):
    if directory:name=name.rstrip('/')
    path=PurePosixPath(name)
    return bool(name and not path.is_absolute() and '..' not in path.parts and '\\' not in name and path.as_posix()==name)
def retain(relative):
    target=R/'retained'/relative;target.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(P/relative,target)

pins={'HANDOFF.md':'0ad9eba17d5bc4e2a284218b51725c60e1fe1192c8398cb1b89a00dce5ac04d7',
      'MANIFEST.json':'3978245ff5b60b8dd86940ddd5c841881b64391abe980bc086ed90291ae97707',
      'proof.tar.gz':'5ad76ebe7f1899e485ba57502e2e6b9fd2cbdb714387ab17c3090a55e774f5c7'}
for name,pin in pins.items():check('frozen pin '+name,digest(P/name)==pin)
manifest=load(P/'MANIFEST.json');rows=manifest['files'];declared={r['path']:r for r in rows}
check('981 unique declared regular files',len(declared)==len(rows)==981)
for name,row in declared.items():
    check('safe regular original '+name,safe(name))
    check('original exact bytes/fullmode '+name,meta(P/name)=={k:row[k] for k in ('bytes','full_mode','sha256')})
actual={str(p.relative_to(P)) for p in P.rglob('*') if p.is_file()}
check('complete retained packet file set',actual==set(declared)|{'MANIFEST.json','proof.tar.gz','SEAL.json'})
expected={**declared,'MANIFEST.json':{'path':'MANIFEST.json',**meta(P/'MANIFEST.json')}}
with tarfile.open(P/'proof.tar.gz','r:gz') as archive:
    members=archive.getmembers()
    check('982 unique exact regular proof set',len(members)==len({m.name for m in members})==982 and {m.name for m in members}==set(expected))
    for member in members:
        row=expected[member.name];check('proof safe regular '+member.name,safe(member.name) and member.isfile())
        source=archive.extractfile(member);assert source is not None
        size,pin=stream_digest(source,row['bytes'])
        check('proof original bytes/fullmode '+member.name,size==row['bytes'] and pin==row['sha256'] and stat.S_IFREG|member.mode==row['full_mode'])
seal=load(P/'SEAL.json')
check('seal honest failure and bindings',seal['outcome']=='CLOSED_FAILURE_RETAINED' and seal['regular_members']==982 and seal['proof']==meta(P/'proof.tar.gz') and seal['manifest']==meta(P/'MANIFEST.json') and seal['handoff']==meta(P/'HANDOFF.md') and seal['no_subject_execution'] and seal['canonical_writes']==0)

api=load(P/'api-receipts.json');check('168 unique GET recordings',len(api)==len({r['path'] for r in api})==168)
for row in api:
    path=P/row['path'];err=path.with_name(path.name+'.stderr')
    check('GET raw stdout/stderr commitments '+row['path'],safe(row['path']) and path.stat().st_size==row['bytes'] and digest(path)==row['sha256'] and err.stat().st_size==row['stderr_bytes'] and digest(err)==row['stderr_sha256'])
    check('GET actual finite closure '+row['path'],row['method']=='GET' and row['exit_code']==0 and row['child_reaped'] and row['pid']==row['pgid'] and row['group_after_wait']=='ABSENT' and not row['signals'] and row['stop_reason'] is None)
collector=load(P/'collector-closure.json')
check('collector closure5runs13jobs8artifacts',len(collector['terminal_runs'])==5 and len(collector['closed_jobs'])==13 and len(collector['artifact_ids_retained'])==8 and collector['no_subject_execution'] and collector['canonical_writes']==0)
jobs={};runs={};job_checkout={};log_channels=[]
for run_id in collector['terminal_runs']:
    folder=P/'runs'/str(run_id);run=load(folder/'terminal-run.json');j=load(folder/'terminal-jobs.json')
    check('actual terminal run '+str(run_id),run['id']==run_id and run['head_sha']==S and run['status']=='completed' and run['run_attempt']==1 and j['total_count']==len(j['jobs']))
    runs[run_id]={'name':run['name'],'conclusion':run['conclusion'],'event':run['event'],'jobs':[]}
    for job in j['jobs']:
        check('terminal job '+str(job['id']),job['id'] not in jobs and job['run_id']==run_id and job['status']=='completed')
        jobs[job['id']]=job;runs[run_id]['jobs'].append({'id':job['id'],'name':job['name'],'conclusion':job['conclusion']})
        if job['conclusion']=='skipped':continue
        path=folder/'closed-jobs'/f'{job["id"]}.log';text=path.read_text()
        check('actual non-skipped job log '+str(job['id']),str(path.relative_to(P)) in declared and meta(path)=={k:declared[str(path.relative_to(P))][k] for k in ('bytes','full_mode','sha256')})
        match=re.search(r'log -1 --format=%H\r?\n[^\r\n]*?\b([0-9a-f]{40})\s*\r?\n',text)
        check('observed exact job checkout '+str(job['id']),match is not None);job_checkout[job['id']]=match.group(1)
    archive=folder/'official-logs.zip';member_rows=load(folder/'log-members.json');member_map={r['path']:r for r in member_rows}
    with zipfile.ZipFile(archive) as zipped:
        entries=zipped.infolist();check('official ZIP unique complete members '+str(run_id),len({i.filename for i in entries})==len(entries))
        check('official ZIP all paths/types safe '+str(run_id),all(safe(i.filename,i.is_dir()) and (i.is_dir() or stat.S_IFMT(i.external_attr>>16) in (0,stat.S_IFREG)) for i in entries))
        files=[i for i in entries if not i.is_dir()]
        check('official exact log member inventory '+str(run_id),len(files)==len(member_rows)==len(member_map) and {m.filename for m in files}==set(member_map))
        for entry in files:
            row=member_map[entry.filename];retained=folder/'logs'/entry.filename
            with zipped.open(entry) as reader:size,pin=stream_digest(reader,row['bytes'])
            check('official ZIP/raw retained bytes/attributes '+str(run_id)+'/'+entry.filename,size==row['bytes']==retained.stat().st_size and pin==row['sha256']==digest(retained) and entry.external_attr>>16==row['zip_mode'] and retained.lstat().st_mode==row['retained_full_mode'])
    for job in j['jobs']:
        if job['conclusion']=='skipped':continue
        jobpin=digest(folder/'closed-jobs'/f'{job["id"]}.log')
        check('two official channels same full job '+str(job['id']),any(r['sha256']==jobpin for r in member_rows));log_channels.append(job['id'])
check('complete terminal job/closure IDs',set(jobs)==set(collector['closed_jobs']) and len(jobs)==13)
main=runs[40926988782]
check('main exactly3 failures+packageSKIP',main['conclusion']=='failure' and {j['id'] for j in main['jobs'] if j['conclusion']=='failure'}=={123635017411,123635017859,123635017964} and jobs[123667601519]['conclusion']=='skipped' and len(main['jobs'])==4)
for run_id,run in runs.items():
    if run_id==40926988782:continue
    checks_only=[j for j in run['jobs'] if j['conclusion']!='skipped']
    check('auxiliary success metadata-only/downstream skipped '+str(run_id),run['conclusion']=='success' and len(checks_only)==1 and checks_only[0]['name']=='authorize' and checks_only[0]['conclusion']=='success' and all(j['conclusion']=='skipped' for j in run['jobs'] if j['id']!=checks_only[0]['id']))
    raw=(P/'runs'/str(run_id)/'closed-jobs'/f'{checks_only[0]["id"]}.log').read_text()
    gate_artifacts=[load(path) for path in (P/'artifacts').glob('*/closure.json') if load(path)['run']==run_id]
    check('exact gate artifact association '+str(run_id),len(gate_artifacts)==1)
    gate=gate_artifacts[0];request=load(P/gate['contents']/'request.json')
    check('actual no-root-request skip gate '+str(run_id),request=={'enabled':'false','status':'SKIP_NO_ROOT_REQUEST'} and job_checkout[checks_only[0]['id']]==S and str(gate['artifact_id']) in raw)

artifacts=[];zip_file_total=0
for folder in sorted((P/'artifacts').iterdir()):
    close=load(folder/'closure.json');metadata=load(folder/'metadata.json');archive=P/close['archive'];contents=P/close['contents']
    check('artifact exact API identity/run/head '+folder.name,close['artifact_id']==int(folder.name)==metadata['id'] and metadata['workflow_run']['id']==close['run'] and metadata['workflow_run']['head_sha']==S)
    check('artifact original API digest/size '+folder.name,metadata['digest']=='sha256:'+digest(archive) and metadata['size_in_bytes']==archive.stat().st_size==close['archive_bytes'] and digest(archive)==close['archive_sha256'])
    member_rows=load(folder/'members-attempt-1.json');member_map={r['path']:r for r in member_rows}
    with zipfile.ZipFile(archive) as zipped:
        entries=zipped.infolist();files=[i for i in entries if not i.is_dir()]
        check('artifact unique safe all entries '+folder.name,len({i.filename for i in entries})==len(entries) and all(safe(i.filename,i.is_dir()) and (i.is_dir() or stat.S_IFMT(i.external_attr>>16) in (0,stat.S_IFREG)) for i in entries))
        check('artifact exact member set '+folder.name,len(files)==len(member_rows)==len(member_map)==close['safe_regular_members'] and {m.filename for m in files}==set(member_map))
        for entry in files:
            row=member_map[entry.filename];retained=contents/entry.filename
            with zipped.open(entry) as reader:size,pin=stream_digest(reader,row['bytes'])
            check('artifact bytes/original ZIP attributes/retained mode '+folder.name+'/'+entry.filename,size==row['bytes']==retained.stat().st_size and pin==row['sha256']==digest(retained) and entry.external_attr>>16==row['zip_mode'] and entry.create_system==row['zip_create_system'] and entry.external_attr==row['zip_external_attr'] and retained.lstat().st_mode==row['retained_full_mode'])
        zip_file_total+=len(files)
    actual_files={x.relative_to(contents).as_posix() for x in contents.rglob('*') if x.is_file()}
    check('artifact retained complete set '+folder.name,actual_files==set(member_map))
    for verified in load(folder/'retention-verification-attempt-1.json'):
        target=contents/verified['manifest'];curated=load(target);declared_rows=curated['files']
        check('curated row counts/bytes '+folder.name+'/'+verified['manifest'],len(declared_rows)==curated['file_count'] and sum(r['bytes'] for r in declared_rows.values())==curated['bytes'] and verified['all_exact'])
        check('curated exact member set '+folder.name+'/'+verified['manifest'],{x.relative_to(target.parent).as_posix() for x in target.parent.rglob('*') if x.is_file()}==set(declared_rows)|{target.name})
        for name,row in declared_rows.items():check('curated exact row '+folder.name+'/'+name,safe(name) and (target.parent/name).stat().st_size==row['bytes'] and digest(target.parent/name)==row['sha256'])
    artifacts.append(close)
check('actual8 artifact IDs exact',len(artifacts)==8 and {a['artifact_id'] for a in artifacts}==set(collector['artifact_ids_retained']))
check('no curated portable exports',not list((P/'artifacts').glob('*/package-export-candidates.json')) and jobs[123667601519]['conclusion']=='skipped' and all('portable' not in a['name'] and 'gnome-package' not in a['name'] for a in artifacts))
loader=next(a for a in artifacts if a['artifact_id']==12925210584)
check('loader diagnostic separately scoped205',loader['safe_regular_members']==205 and loader['name']=='windows-native-loader-'+M)

source=load(P/'immutable-git-source-sha256.json');api_head=load(P/'head-commit.json');api_tree=load(P/'head-tree.json')
check('exact S/T local body inventory metadata',source['commit']==S and source['tree']==T and source['blob_count']==len(source['files'])==2294 and source['all_git_blob_SHA1_framings_verified'] and api_head['sha']==S and api_head['tree']['sha']==api_tree['sha']==T and not api_tree['truncated'])
api_blobs={r['path']:r for r in api_tree['tree'] if r['type']=='blob'}
check('API exact2294 blob paths',set(api_blobs)==set(source['files']))
for name,row in source['files'].items():
    item=api_blobs[name]
    check('API/local blob/size/Git class '+name,row['git_blob']==item['sha'] and row['git_mode']==item['mode'] and row['bytes']==item['size'] and row['full_mode']==(stat.S_IFREG|0o755 if row['git_mode']=='100755' else stat.S_IFREG|0o644))
bindings=load(P/'checkout-source-bindings.json')
for commit,binding in bindings.items():
    info=load(P/'source-bindings'/(commit+'-commit.json'));tree=load(P/'source-bindings'/(commit+'-tree.json'));blobs={r['path']:r for r in tree['tree'] if r['type']=='blob'}
    check('actual checkout API commit/tree '+commit,info['sha']==commit and info['tree']['sha']==tree['sha']==binding['tree']==T and not tree['truncated'])
    check('actual checkout full source projection '+commit,set(blobs)==set(source['files']) and all(blobs[n]['sha']==r['git_blob'] and blobs[n]['mode']==r['git_mode'] and blobs[n]['size']==r['bytes'] for n,r in source['files'].items()))
    check('every observed checkout job bound '+commit,{j for j,c in job_checkout.items() if c==commit}==set(binding['observed_in_jobs']))
check('all3 tested checkout M not S',{job_checkout[j] for j in (123635017411,123635017859,123635017964)}=={M} and M!=S)
merge=load(P/'source-bindings'/(M+'-commit.json'))
check('actual merge parents base+S',[p['sha'] for p in merge['parents']]==[BASE,S])
run=load(P/'runs/40926988782/terminal-run.json')
check('actual PR head and base binding',len(run['pull_requests'])==1 and run['pull_requests'][0]['head']['sha']==S and run['pull_requests'][0]['base']['sha']==BASE)

# Fresh immutable local Git payload joins, bounded one retained reader. No
# artifact executes; encoded Git modes do not become arbitrary OS mode claims.
env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
tree_bytes=subprocess.check_output(['git','-C',str(C),'ls-tree','-rz',S],env=env,timeout=30)
objects=[]
for item in tree_bytes.split(b'\0'):
    if item:
        head,name=item.split(b'\t',1);mode,kind,oid=head.split();assert kind==b'blob';objects.append((name.decode(),mode.decode(),oid.decode()))
check('fresh immutable Git exact source set',{o[0] for o in objects}==set(source['files']))
requests=R/'retained/git-object-requests.txt';requests.write_text(''.join(o[2]+'\n' for o in objects))
selector=None;buffer=bytearray();error=bytearray();state='header';index=0;remaining=0;h256=None;h1=None;body=None;streamed=0
capture={'scripts/tests/test_ubuntu_gnome_signed_indexes.py','scripts/verification-suites.json','scripts/python-test-inventory.v1.json'}
start=time.monotonic();deadline=start+45
with requests.open('rb') as feed:
    child=subprocess.Popen(['git','-C',str(C),'cat-file','--batch'],env=env,stdin=feed,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    try:
        assert child.stdout is not None and child.stderr is not None
        selector=selectors.DefaultSelector()
        for pipe in (child.stdout,child.stderr):os.set_blocking(pipe.fileno(),False);selector.register(pipe,selectors.EVENT_READ)
        while selector.get_map():
            if time.monotonic()>=deadline:raise TimeoutError('local Git read deadline')
            for key,_ in selector.select(.05):
                data=os.read(key.fileobj.fileno(),1024*1024)
                if not data:selector.unregister(key.fileobj);continue
                if key.fileobj is child.stderr:error.extend(data);assert len(error)<=8192;continue
                streamed+=len(data);assert streamed<=sum(r['bytes'] for r in source['files'].values())+len(objects)*128
                buffer.extend(data)
                while buffer:
                    if state=='header':
                        newline=buffer.find(b'\n')
                        if newline<0:assert len(buffer)<256;break
                        header=bytes(buffer[:newline]);del buffer[:newline+1]
                        oid,kind,length=header.split();name,mode,expected=objects[index];remaining=int(length)
                        assert oid.decode()==expected and kind==b'blob' and remaining==source['files'][name]['bytes']
                        h256=hashlib.sha256();h1=hashlib.sha1(b'blob '+length+b'\0');body=bytearray() if name in capture else None;state='body'
                    if state=='body':
                        take=min(remaining,len(buffer));h256.update(buffer[:take]);h1.update(buffer[:take])
                        if body is not None:body.extend(buffer[:take]);assert len(body)<=8*1024*1024
                        del buffer[:take];remaining-=take
                        if remaining:break
                        state='newline'
                    if state=='newline':
                        if not buffer:break
                        assert buffer[0]==10;del buffer[0];name,mode,oid=objects[index];row=source['files'][name]
                        check('fresh local immutable body '+name,h256.hexdigest()==row['sha256'] and h1.hexdigest()==row['git_blob']==oid and mode==row['git_mode'])
                        if body is not None:
                            target=R/'retained/immutable-source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body)
                        index+=1;state='header'
        code=child.wait(timeout=max(.1,deadline-time.monotonic()))
    except BaseException:
        if child.poll() is None:child.kill()
        child.wait(timeout=5);raise
    finally:
        if selector is not None:selector.close()
        for pipe in (child.stdout,child.stderr):
            if pipe is not None:pipe.close()
try:os.killpg(child.pid,0);group='PRESENT_NO_POST_REAP_SIGNAL'
except ProcessLookupError:group='ABSENT'
check('fresh Git reader closure',code==0 and child.returncode is not None and group=='ABSENT' and index==2294 and state=='header' and not buffer and not error)
git_receipt={'argv':['git','-C',str(C),'cat-file','--batch'],'commit':S,'pid':child.pid,'pgid':child.pid,'exit_code':code,'reaped':True,'group':group,'signals':[],'seconds':time.monotonic()-start,'objects':index,'source_bytes':sum(r['bytes'] for r in source['files'].values()),'scope':'readonly LOCAL immutable bodies only, not separate downloads of all API blobs or current checkout neutrality'}
(R/'retained/git-read-closure.json').write_text(json.dumps(git_receipt,indent=2)+'\n')

inventory=load(P/'actual-source-python-inventory.json')
check('exact source catalog body',digest(P/'actual-source-python-inventory.json')==source['files']['scripts/python-test-inventory.v1.json']['sha256'] and inventory==load(R/'retained/immutable-source/scripts/python-test-inventory.v1.json'))
ids=inventory['common']['node_ids'];check('source2622 common+2POSIX',len(ids)==len(set(ids))==inventory['common']['count']==2622 and len(inventory['posix_only_node_ids'])==2 and hashlib.sha256(('\n'.join(ids)+'\n').encode()).hexdigest()==inventory['common']['sha256'])
fixture=(R/'retained/immutable-source/scripts/tests/test_ubuntu_gnome_signed_indexes.py').read_bytes()
check('65537 original payload and short ID exact source',b'pytest.param(b"x" * 65537, id="oversized-field")' in fixture and hashlib.sha256(fixture).hexdigest()=='b8a838a7c8d37a9674069e764cba0ad0f905616827e18322dee67120867045ad')
platforms={}
collected_report=load(P/'actual-suite-results.json')
for job_id,label,total,native,passed,failed,seconds in [(123635017411,'Mac15',2624,342,2623,1,'954.62'),(123635017859,'Ubuntu24.04',2624,338,2623,1,'665.12'),(123635017964,'Windows2025',2622,316,2620,2,'1114.85')]:
    original=(P/f'runs/40926988782/closed-jobs/{job_id}.log').read_text()
    log=re.sub(r'^\d{4}-\d\d-\d\dT\S+Z ','',original,flags=re.M);log=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',log);lines=log.splitlines()
    suite_rows=re.findall(r'^([a-z0-9-]+)[ \t]+ACTIVE[ \t]+(PASS|FAIL)[ \t]*(.*)$',log[log.rfind('== verification summary =='):],re.M)
    check(label+' actual19PASS PythonFAIL20ACTIVE',len(suite_rows)==20 and Counter(r[1] for r in suite_rows)=={'PASS':19,'FAIL':1} and next(r[0] for r in suite_rows if r[1]=='FAIL')=='python')
    check(label+' actual doctor28',re.search(r'^summary: 28 pass, 0 warning, 0 fail, 0 not-yet-applicable$',log,re.M) is not None)
    ci=next(i for i,l in enumerate(lines) if l.startswith('$ uv run pytest ') and '--collect-only' in l)
    ce=next(i for i in range(ci+1,len(lines)) if re.match(str(total)+r' tests collected',lines[i]))
    actual_ids=[l for l in lines[ci+1:ce] if re.match(r'^(scripts|services|packages)/.+::',l)]
    expected_ids=ids+([] if label=='Windows2025' else inventory['posix_only_node_ids'])
    opaque='services/orchestrator/tests/test_service_api.py::test_every_route_requires_session_auth[***'
    missing=set(expected_ids)-set(actual_ids)
    check(label+' exact source-bound opaque12 multiset',len(actual_ids)==total and len(missing)==actual_ids.count(opaque)==12 and all(n.startswith('services/orchestrator/tests/test_service_api.py::test_every_route_requires_session_auth[Bearer ') for n in missing) and Counter(opaque if n in missing else n for n in expected_ids)==Counter(actual_ids))
    ei=next(i for i in range(ce+1,len(lines)) if lines[i].startswith('$ uv run pytest ') and '--collect-only' not in lines[i])
    check(label+' actual same execution selection',[a for a in shlex.split(lines[ci][2:]) if a not in ('--collect-only','-q')]==shlex.split(lines[ei][2:]))
    py_summaries=[l for l in lines[ei:] if re.match(r'^=+ \d+ (?:passed|failed|errors?|skipped)(?:,| in)',l)]
    check(label+' one complete exact outcome summary',len(py_summaries)==1 and f'{failed} failed, {passed} passed in {seconds}s' in py_summaries[0])
    outcome={k:int(n) for n,k in re.findall(r'(\d+) (passed|failed|errors?|skipped|xfailed|xpassed|deselected)\b',py_summaries[0])}
    nonpassing=[l for l in lines if l.startswith(('FAILED ','ERROR '))]
    check(label+' complete outcome count no skips',sum(outcome.values())==total and outcome=={'failed':failed,'passed':passed} and len(nonpassing)==failed)
    check(label+' actual cache fixture fail',any('test_exact_windows11_island_and_inactive_workflows' in l and 'Linux bytecode cache differs from exact source compile' in l for l in nonpassing))
    if label=='Windows2025':check('Windows actual backslash fixture fail',any('test_original_curated_artifact_requires_complete_actual_source_and_success' in l and 'Safe portable relative member required' in l for l in nonpassing) and "name = 'packages\\\\windows-portable.zip'" in log and 'Microsoft Windows Server 2025' in log)
    target='scripts/tests/test_ubuntu_gnome_signed_indexes.py::test_duplicate_continuation_and_oversized_fields_refused[oversized-field]'
    check(label+' oversized target PASS only by complete accounting',actual_ids.count(target)==1 and all(target not in l for l in nonpassing) and passed+failed==total)
    start_ts=log.index('$ pnpm exec turbo run test --force --concurrency=2 -- --reporter=default');end_ts=log.index('$ pnpm generate:contracts --check',start_ts);ts=log[start_ts:end_ts]
    task_counts=[]
    for match in re.finditer(r'##\[group\](@japp/[^:]+):test\n(.*?)##\[endgroup\]',ts,re.S):
        counts=re.findall(r'^\s+Tests\s+(\d+) passed \(\1\)\s*$',match.group(2),re.M)
        check(label+' unique TS actual task summary '+match.group(1),len(counts)==1);task_counts.append((match.group(1),int(counts[0])))
    check(label+' fresh uncached TS4006/15',len(task_counts)==len({n for n,_ in task_counts})==15 and sum(n for _,n in task_counts)==4006 and 'Cached:    0 cached, 15 total' in ts)
    modes=[]
    for flags in ('',' --all-features',' --features tauri/custom-protocol'):
        command='$ cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml'+flags
        a=lines.index(command);b=next((i for i in range(a+1,len(lines)) if lines[i].startswith('$ ')),len(lines));section='\n'.join(lines[a+1:b])
        names=re.findall(r'^test (.+) \.\.\. ok$',section,re.M)
        check(label+' native exact unique per mode '+flags,len(names)==len(set(names))==native and f'test result: ok. {native} passed; 0 failed;' in section);modes.append(set(names))
    check(label+' same3 native sets, no triple unique count',modes[0]==modes[1]==modes[2])
    for cmd,count in [('$ cargo test --manifest-path services/native-host/Cargo.toml',1),('$ cargo test --locked --offline --manifest-path packages/contracts/test/contract/rust-harness/Cargo.toml',10)]:
        a=lines.index(cmd);b=next((i for i in range(a+1,len(lines)) if lines[i].startswith('$ ')),len(lines));section='\n'.join(lines[a+1:b]);names=re.findall(r'^test (.+) \.\.\. ok$',section,re.M)
        check(label+' separate native exact'+str(count),len(names)==len(set(names))==count and f'test result: ok. {count} passed; 0 failed;' in section)
    browser=[]
    for title,base,want in [('browser','pnpm exec playwright test',278),('public','pnpm exec playwright test --config e2e/extension/public-research/playwright.config.ts',2),('contact','pnpm exec playwright test --config e2e/extension/public-contact/playwright.config.ts --reporter=list,json',62),('visual','pnpm exec playwright test e2e/visual --output test-results/visual',17)]:
        execution='$ '+base+'\n';listing='$ '+base+' --list';a=log.index(execution);b=log.index(listing,a+len(execution));c=log.find('\n$ ',b+len(listing));c=len(log) if c<0 else c
        ran=re.findall(r'^  (?:ok|[✓✔])\s+\d+ (?:\[.*?\] › )?(?:e2e/)?(.+:\d+:\d+ › .+) \([\d.]+(?:ms|s|m)\)$',log[a:b],re.M)
        discovered=re.findall(r'^  (?:\[.*?\] › )?(.+:\d+:\d+ › .+)$',log[b:c],re.M)
        ran=[n.replace('\\','/').removeprefix('e2e/') for n in ran];discovered=[n.replace('\\','/').removeprefix('e2e/') for n in discovered]
        if title in ('public','contact'):ran=[n.split(':',1)[0].rsplit('/',1)[-1]+':'+n.split(':',1)[1] for n in ran]
        check(label+' actual distinct browser/list IDs '+title,len(ran)==len(set(ran))==len(discovered)==len(set(discovered))==want and set(ran)==set(discovered))
        summaries=[l.strip() for l in log[a:b].splitlines() if re.match(r'\s*'+str(want)+r' passed \(',l)]
        check(label+' actual browser summary '+title,len(summaries)==1);browser.append({'suite':title,'count':want,'summary':summaries[0]})
    retained=collected_report['jobs'][label]
    check(label+' collector projection matches own parsed outcomes',retained['actual_collection_count']==total and retained['pytest_actual_summary']==py_summaries[0] and retained['native_unique_per_mode']==native and retained['collection_node_ids']==actual_ids)
    platforms[label]={'job_id':job_id,'checkout':M,'conclusion':'failure','suite_pass':19,'suite_fail':'python','collection':total,'passed':passed,'failed':failed,'seconds':seconds,'failures':nonpassing,'opaque_raw_lines':12,'individual_masked_id_or_status_claim':False,'native_unique_per_each_of_same3_modes':native,'separate_native':[1,10],'TS4006_unique_tasks':15,'browser':browser,'oversized_target':'PASS_DERIVED_COMPLETE_ACCOUNTING_NO_DIRECT_STATUS_ROW'}

visual=load(P/'ubuntu-visual-observation.json');folder=P/'artifacts/12922628385/contents-attempt-1';visual_rows=visual['rows']
check('33visual primary rows19PNG14JSON29unique',len(visual_rows)==33 and sum(r['path'].endswith('.png') for r in visual_rows)==19 and sum(r['path'].endswith('.json') for r in visual_rows)==14 and len({r['sha256'] for r in visual_rows})==29)
aliases=[]
for row in visual_rows:
    check('actual visual primary hash/mode '+row['path'],meta(folder/row['path'])=={k:row[k] for k in ('bytes','full_mode','sha256')})
    for name in row['matching_aliases']:
        aliases.append(name);check('actual visual attachment alias '+name,digest(folder/name)==row['sha256'] and (folder/name).stat().st_size==row['bytes'])
check('33distinct attachment aliases',len(aliases)==len(set(aliases))==33)
check('collector visual scope honest4only',visual['visual_spot_check_count']==4 and 'Other15 PNGs' in visual['visual_spot_check'] and 'No hosted primary PNG is byte-identical' in visual['prior_local_png_identity'])

for name in ['HANDOFF.md','MANIFEST.json','SEAL.json','collector-closure.json','collector-context.json','api-receipts.json','head-commit.json','head-tree.json','pull-request-start.json','immutable-git-source-sha256.json','checkout-source-bindings.json','actual-source-python-inventory.json','ubuntu-python-observation.json','windows-python-observation.json','ubuntu-visual-observation.json','ubuntu-python-initial-scope-label.json']:
    retain(name)
for run_id in collector['terminal_runs']:
    for name in ['terminal-run.json','terminal-jobs.json','log-members.json']:retain(f'runs/{run_id}/{name}')
for job_id in (123635017411,123635017859,123635017964):retain(f'runs/40926988782/closed-jobs/{job_id}.log')
for path in (P/'source-bindings').glob('*.json'):retain(str(path.relative_to(P)))
for art in artifacts:
    for name in ('closure.json','metadata.json','members-attempt-1.json','retention-verification-attempt-1.json'):retain(f'artifacts/{art["artifact_id"]}/{name}')
report={'verdict':'CLEAR_AS_RECORDED_FAILURE','checks_passed':len(checks),'checks':checks,'subject_pins':{name:meta(P/name) for name in pins},'terminal_runs':runs,'actual_main_results':platforms,'GET_commands_closed':168,'actual_jobs':13,'artifact_archives':8,'artifact_regular_members':zip_file_total,'outer_proof_members':982,'source':{'S':S,'M':M,'base':BASE,'tree':T,'paths':2294,'local_bytes':git_receipt['source_bytes'],'API_body_limit':'API OID/mode/size metadata + fresh immutable LOCAL Git bodies, not all API blob bodies downloaded or current checkout full OS modes'},'own_git_reader':git_receipt,'source_findings':[],'limits':['all three main jobs failed Python; no post-success clean-worktree assertion','package job skipped; loader205 is diagnostic, not curated portable package or native GUI proof','four auxiliary success gates are SKIP_NO_ROOT_REQUEST with downstream skipped','12 opaque masked Bearer identities per platform only Counter projection; raw individual IDs/status/masking cause unresolved','oversized short ID passes by full count/nonpassing-row exhaustion, no direct raw status row','visual images hash-bound only in this different review; collector reported four spot checks, no new visual inspection claimed','no artifact/native/model execution, rerun/cancel/new downloads/VM/network/canonical modification']}
(R/'DATA-REVIEW.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'verdict':report['verdict'],'checks_passed':len(checks),'platforms':{k:{'passed':v['passed'],'failed':v['failed'],'seconds':v['seconds']} for k,v in platforms.items()},'source_objects':2294,'GET':168,'jobs':13,'artifacts':8}))
