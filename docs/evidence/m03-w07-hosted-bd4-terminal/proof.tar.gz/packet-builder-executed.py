from pathlib import Path, PurePosixPath
from datetime import UTC, datetime
import gzip, hashlib, io, json, stat, tarfile

E = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
S = E / 'ci-bd4cffd'
V = E / 'ci-bd4cffd-independent-review/v1'
O = E / 'm03-w07-hosted-bd4-terminal-packet/v1'
assert not O.exists()

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def row(p):
    s = p.lstat()
    assert stat.S_ISREG(s.st_mode) and not p.is_symlink()
    return {'bytes': s.st_size, 'sha256': sha(p), 'full_mode': s.st_mode}

pins = [
    (S/'HANDOFF.md', '0ad9eba17d5bc4e2a284218b51725c60e1fe1192c8398cb1b89a00dce5ac04d7'),
    (S/'MANIFEST.json', '3978245ff5b60b8dd86940ddd5c841881b64391abe980bc086ed90291ae97707'),
    (S/'proof.tar.gz', '5ad76ebe7f1899e485ba57502e2e6b9fd2cbdb714387ab17c3090a55e774f5c7'),
    (V/'REVIEW.md', '570fe90c1a021cc2003c6218994d323ea29d2120ce355fa9cefd008cdc15d0d1'),
    (V/'MANIFEST.json', 'b9a84661af3221ce09d13b8dbc0bdc4b1bc00eacb61365437723b8c87c169313'),
    (V/'proof.tar.gz', '45d69eff90eaa8aa7acf3ae7af5ce3f4f76ef8e20cfbbd74efb3fa3f625d4ea9'),
]
assert all(sha(p) == h for p, h in pins)
files = {}
omitted = []
verified = {}
for base, prefix in [(S, 'hosted-failure'), (V, 'different-review')]:
    members = json.loads((base/'MANIFEST.json').read_text())['files']
    for v in members:
        n = v['path']
        q = PurePosixPath(n)
        assert not q.is_absolute() and '..' not in q.parts and '\\' not in n
        p = base/n
        assert row(p) == {k: v[k] for k in ('bytes', 'sha256', 'full_mode')}
        if p.suffix.lower() in {'.zip', '.exe'}:
            omitted.append({'archive_path': prefix+'/'+n, 'source_path': str(p), **row(p), 'reason': 'Original downloaded ZIP or loader diagnostic executable body; remains in the sealed outside packet. Original metadata/member maps/raw logs are retained here.'})
        else:
            files[prefix+'/'+n] = p
    files[prefix+'/MANIFEST.json'] = base/'MANIFEST.json'
    verified[prefix] = len(members)

closure = json.loads((S/'collector-closure.json').read_text())
assert len(closure['terminal_runs']) == 5 and len(closure['closed_jobs']) == 13 and len(closure['artifact_ids_retained']) == 8
results = json.loads((S/'actual-suite-results.json').read_text())
assert all(v['pass'] for v in results['checks'])
O.mkdir(parents=True)
files['packet-builder-executed.py'] = Path(__file__)
rows = []
with (O/'proof.tar.gz').open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as archive:
            for n, p in sorted(files.items()):
                v = row(p)
                b = p.read_bytes()
                m = tarfile.TarInfo(n)
                m.size = len(b)
                m.mode = stat.S_IMODE(v['full_mode'])
                archive.addfile(m, io.BytesIO(b))
                rows.append({'path': n, 'source_path': str(p), 'mode': m.mode, **v})
seen = set()
by_name = {r['path']: r for r in rows}
with tarfile.open(O/'proof.tar.gz') as archive:
    for m in archive:
        assert m.isfile() and not m.islnk() and not m.issym() and m.name not in seen
        seen.add(m.name)
        v = by_name[m.name]
        f = archive.extractfile(m)
        assert f is not None
        b = f.read()
        assert len(b) == v['bytes'] and hashlib.sha256(b).hexdigest() == v['sha256'] and m.mode == v['mode']
        assert row(Path(v['source_path'])) == {k: v[k] for k in ('bytes', 'sha256', 'full_mode')}
assert seen == set(by_name)
def dump(n, obj):
    (O/n).write_text(json.dumps(obj, indent=2, sort_keys=True)+'\n')
dump('artifact.json', {'path': 'proof.tar.gz', 'mode': stat.S_IMODE((O/'proof.tar.gz').stat().st_mode), **row(O/'proof.tar.gz')})
dump('retention-manifest.json', {'members': rows, 'regular_members': len(rows), 'all_retained_bytes_full_modes_verified': True, 'full_source_packet_member_joins': verified, 'omitted_original_bodies': omitted, 'original_outside_seal_pins': [{'path': str(p), 'sha256': h} for p, h in pins], 'limitations': ['The complete original archive/ZIP/loader bodies remain outside only, with their exact commitments and metadata retained; this compact packet is not a complete copy of them.', 'Immutable Git bodies were joined by the different reviewer; this packet retains the maps and receipts, not every historical Git blob body.', 'No retained artifact is executed by this builder.']})
dump('summary.json', {'utc': datetime.now(UTC).isoformat(), 'result': 'FAILURE', 'source': 'bd4cffd7f61f99f77520e7dc522f852488cdd9d3', 'actual_main_checkout': 'fa044b9f37c59bbafece98c09e4bbad6d25337c3', 'exact_shared_tree': '75d79ae7fc14e9a02c1f326e5376b16d74a7736e', 'source_paths': 2294, 'main_run': 40926988782, 'attempt': 1, 'main_platforms': {'windows-2025': {'ACTIVE_PASS': 19, 'ACTIVE_FAIL': ['python'], 'python_pass': 2620, 'python_fail': 2, 'python_seconds': 1114.85, 'native_same_ids_each_three_modes': 316}, 'ubuntu-24.04': {'ACTIVE_PASS': 19, 'ACTIVE_FAIL': ['python'], 'python_pass': 2623, 'python_fail': 1, 'python_seconds': 665.12, 'native_same_ids_each_three_modes': 338}, 'macos-15': {'ACTIVE_PASS': 19, 'ACTIVE_FAIL': ['python'], 'python_pass': 2623, 'python_fail': 1, 'python_seconds': 954.62, 'native_same_ids_each_three_modes': 342}}, 'doctor_each': 28, 'typescript_each': {'passes': 4006, 'fresh_tasks': 15}, 'browser_each': [278, 2, 62, 17], 'native_separate_each': [1, 10], 'dependent_package_job': {'id': 123667601519, 'conclusion': 'skipped', 'curated_exports': 0}, 'auxiliary_policy': 'Four successful metadata policy runs record SKIP_NO_ROOT_REQUEST; source-check/download/VM actors skipped.', 'collector_closure': closure, 'different_review': {'verdict': 'CLEAR_AS_RECORDED_FAILURE', 'joins': 9722, 'report_sha256': sha(V/'REVIEW.md'), 'manifest_sha256': sha(V/'MANIFEST.json')}, 'scope': 'Actual immutable hosted failure only. Later correction, native Windows11/defaultGNOME, package export, milestone or release credit is absent.'})
(O/'README.md').write_text('''# Hosted bd4 terminal failure\n\nActual CI40926988782/attempt1 is FAILURE on all three canonical platforms:19ACTIVE suites pass and Python fails. macOS15 records2623PASS/1FAIL954.62s; Ubuntu24.04 records2623PASS/1FAIL665.12s; WindowsServer2025 records2620PASS/2FAIL1114.85s. All fail the copied-bytecode isolation fixture. Windows also refuses a fixture-generated backslash archive member. The original strict guards remain unchanged in this run. Later corrections do not change these outcomes.\n\nDoctor28, fresh uncached TypeScript4006/15tasks, browser278+2+62+17 and native342Mac/338Ubuntu/316Windows same IDs each of three modes plus separate1/10 pass. Twelve masked raw Python identities per platform remain opaque; exact source-bound multiset accounting is not individual raw identification. The oversized65537-byte short-ID case PASS is derived from complete selection/outcome accounting, not a direct status line.\n\nActual tested mergefa044b9 differs from API sourcebd4cffd but shares exact tree75d79ae7 and2294 path/OID/size/executable-class bindings. The different reviewer separately joins516719623 immutable LOCAL Git body bytes; individual API blob bodies were not all downloaded. Five runs/13jobs/eight artifacts/168GET calls are closed. The actual dependent package job123667601519 is SKIPPED: there is no curated Windows portable or Ubuntu GNOME package export. Four auxiliary successes are metadata-only SKIP_NO_ROOT_REQUEST, with source/download/VM actors skipped.\n\nDifferent9722 joins clear the finite record AS_RECORDED_FAILURE. This compact packet retains raw logs, API/case/source maps, original browser image bodies and different-review data with exact byte/full-mode archive verification. Original downloaded ZIPs and loader executable bodies remain in the pinned sealed outside packet; their metadata/member commitments are retained here and every omitted body is enumerated. The original complete76,391,685-byte archive is not duplicated into the repository. No native Windows11/defaultGNOME, corrected aggregate PASS, milestone acceptance, visual-baseline approval or finished-product claim follows.\n\nActual run: https://github.com/kalwad/jobapplyv2/actions/runs/40926988782\n''')
print(json.dumps({'path': str(O), 'members': len(rows), 'omitted_bodies': len(omitted), 'artifact': json.loads((O/'artifact.json').read_text())}))
