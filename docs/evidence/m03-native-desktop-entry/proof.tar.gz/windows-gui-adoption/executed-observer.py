from pathlib import Path
import datetime
import hashlib
import json
import os
import stat
import subprocess

E=Path(__file__).parent;R=Path('/Users/tanishkalwad/jobapplyv2')
P=E/'windows-gui-subsystem-preparation/v1';O=E/'windows-gui-subsystem-canonical-adoption-v1'
assert hashlib.sha256((P/'SOURCE.json').read_bytes()).hexdigest()=='7d03ceea68ba681982f97e73364d5a27fc1de0b0e2b0662b5cbe9a20a36dda68'
assert hashlib.sha256((E/'windows-gui-subsystem-independent-review/v1/manifest.json').read_bytes()).hexdigest()=='d0ded0b520693d1eec8298a2d10b58ebe0520a9def5cd30047dc8ab5139b7741'
assert hashlib.sha256((E/'windows-gui-subsystem-independent-review/v1/REVIEW.md').read_bytes()).hexdigest()=='aa3f14b3fb02879d44b1494c84e3ee85cab6ad849e50d9737c341989178ade72'
assert subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)==' M apps/desktop/src-tauri/src/lib.rs\n'
assert hashlib.sha256((R/'apps/desktop/src-tauri/src/lib.rs').read_bytes()).hexdigest()=='53ce147f3cf175371eefafdfc296363d8cf57f928f4609f35a527fb84a08b4f9'
assert json.loads((E/'native-quit-menu-canonical-focus-v1/closure.json').read_text())['all_five_commands_closed_zero']
source=json.loads((P/'SOURCE.json').read_text())
for row in source['refs']:
    path=R/row['path'];body=path.read_bytes();info=path.lstat()
    assert stat.S_ISREG(info.st_mode) and len(body)==row['bytes'] and stat.S_IMODE(info.st_mode)==row['mode'] and hashlib.sha256(body).hexdigest()==row['sha256'] and body==(P/'reference'/row['path']).read_bytes()
path=R/source['canonical_path'];assert path.read_bytes()==(P/'before-main.rs').read_bytes()
assert hashlib.sha256((P/'after-main.rs').read_bytes()).hexdigest()==source['after_sha256']=='85d95119a4ebcfeb4122020a8d33a0e62eb9e850721a53c64b0fd07e5807bce3'
O.mkdir()
def dump(name,value):(O/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def snap():
    files={}
    for raw in subprocess.check_output(['git','ls-files','-z'],cwd=R).split(b'\0'):
        if not raw:continue
        p=R/os.fsdecode(raw);info=p.lstat();assert stat.S_ISREG(info.st_mode);body=p.read_bytes()
        files[os.fsdecode(raw)]={'bytes':len(body),'mode':stat.S_IMODE(info.st_mode),'sha256':hashlib.sha256(body).hexdigest()}
    runtime={};base=R/'apps/desktop/src-tauri/runtime-payload'
    for p in sorted(base.rglob('*')):
        info=p.lstat()
        if stat.S_ISDIR(info.st_mode):continue
        assert stat.S_ISREG(info.st_mode);body=p.read_bytes()
        runtime[p.relative_to(base).as_posix()]={'bytes':len(body),'mode':stat.S_IMODE(info.st_mode),'sha256':hashlib.sha256(body).hexdigest()}
    return {'source':files,'runtime':runtime,'status':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=R,text=True).strip()}
before=snap();dump('before.json',before);(O/'preimage.rs').write_bytes(path.read_bytes());(O/'executed-observer.py').write_bytes(Path(__file__).read_bytes())
path.write_bytes((P/'after-main.rs').read_bytes())
after=snap();dump('after.json',after)
changed=[name for name,row in before['source'].items() if after['source'][name]!=row]
assert changed==[source['canonical_path']]
assert before['runtime']==after['runtime'] and before['head']==after['head'] and before['tree']==after['tree']
assert after['status']==' M apps/desktop/src-tauri/src/lib.rs\n M apps/desktop/src-tauri/src/main.rs\n'
dump('APPLIED.json',{'observed_utc':datetime.datetime.now(datetime.UTC).isoformat(),'changed':changed,'inventory_source_files':2255,'remaining2254_source_and40_runtime_bytes_fullmodes_equal':True,'head_tree_unchanged':True,'source_sha256':'7d03ceea68ba681982f97e73364d5a27fc1de0b0e2b0662b5cbe9a20a36dda68','after_sha256':source['after_sha256'],'scope':'source-derived Windows development GUI fix, no observed current hosted PE failure or corrected native PE/GUI pass'})
print(json.dumps({'adopted':changed,'status':after['status']}))
