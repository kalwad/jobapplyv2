from pathlib import Path
import datetime,hashlib,json,os,signal,stat,subprocess,time
R=Path('/Users/tanishkalwad/jobapplyv2');O=Path(__file__).parent/'native-desktop-entry-canonical-focus-v1';O.mkdir(exist_ok=False)
def dump(n,x):(O/n).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def snap():
 rows={}
 for raw in subprocess.check_output(['git','ls-files','-z'],cwd=R).split(b'\0'):
  if not raw:continue
  p=R/os.fsdecode(raw);s=p.lstat();assert stat.S_ISREG(s.st_mode)
  b=p.read_bytes();rows[os.fsdecode(raw)]={'bytes':len(b),'mode':stat.S_IMODE(s.st_mode),'sha256':hashlib.sha256(b).hexdigest()}
 runtime={}
 base=R/'apps/desktop/src-tauri/runtime-payload'
 for p in sorted(base.rglob('*')):
  st=p.lstat()
  if stat.S_ISDIR(st.st_mode):continue
  assert stat.S_ISREG(st.st_mode)
  b=p.read_bytes();runtime[p.relative_to(base).as_posix()]={'bytes':len(b),'mode':stat.S_IMODE(st.st_mode),'sha256':hashlib.sha256(b).hexdigest()}
 return {'runtime':runtime,'files':rows,'status':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=R,text=True).strip()}
before=snap();dump('before.json',before);(O/'executed-wrapper.py').write_bytes(Path(__file__).read_bytes())
env=dict(os.environ);env['PATH']='/opt/homebrew/opt/node@24/bin:/Users/tanishkalwad/.local/share/uv/python/cpython-3.12.13-macos-aarch64-none/bin:'+env['PATH']
cmds=[['cargo', 'fmt', '--manifest-path', 'apps/desktop/src-tauri/Cargo.toml', '--', '--check'], ['cargo', 'clippy', '--locked', '--manifest-path', 'apps/desktop/src-tauri/Cargo.toml', '--all-targets', '--all-features', '--', '-D', 'warnings'], ['uv', 'run', '--no-sync', '--offline', 'python', 'scripts/verify.py', '--suite', 'rust'], ['uv', 'run', '--no-sync', '--offline', 'python', 'scripts/check_portability.py', '--quiet'], ['uv', 'run', '--no-sync', '--offline', 'python', 'scripts/verify.py', '--suite', 'integrity']]
results=[]
for i,argv in enumerate(cmds):
 start=time.monotonic();sigs=[];timeout=False
 with (O/f'{i+1:02}.stdout').open('wb') as out,(O/f'{i+1:02}.stderr').open('wb') as err:
  p=subprocess.Popen(argv,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
  try:code=p.wait(timeout=180)
  except subprocess.TimeoutExpired:
   timeout=True
   for sig in [signal.SIGTERM,signal.SIGKILL]:
    if p.poll() is not None:break
    try:os.killpg(p.pid,sig);sigs.append(sig.name)
    except ProcessLookupError:pass
    try:p.wait(timeout=2)
    except subprocess.TimeoutExpired:pass
   code=p.wait(timeout=5)
 try:os.killpg(p.pid,0);group='PRESENT_AFTER_REAP_NO_SIGNAL'
 except ProcessLookupError:group='ABSENT'
 row={'argv':argv,'exit_code':code,'seconds':time.monotonic()-start,'timeout':timeout,'signals':sigs,'reaped':p.returncode is not None,'group':group};results.append(row);dump('results.json',results);print(json.dumps(row),flush=True)
 if code or group!='ABSENT':break
after=snap();dump('after.json',after);closure={'end_observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_five_commands_closed_zero':len(results)==5 and all(x['exit_code']==0 and x['group']=='ABSENT' and not x['timeout'] and not x['signals'] for x in results),'source_bytes_fullmodes_status_head_tree_equal':before==after,'tracked_files':len(before['files']),'runtime_files':len(before['runtime'])};dump('closure.json',closure);print(json.dumps(closure),flush=True)
raise SystemExit(0 if all(closure[k] for k in ['all_five_commands_closed_zero','source_bytes_fullmodes_status_head_tree_equal']) else 1)
