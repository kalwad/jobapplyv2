from pathlib import Path
import datetime
import hashlib
import io
import json
import stat
import tarfile

E=Path(__file__).parent
O=E/'m03-native-desktop-entry-evidence-v1';O.mkdir()
files={}
def add(path,name):
    assert stat.S_ISREG(path.lstat().st_mode) and name not in files
    files[name]=path
def tree(directory,prefix):
    for p in sorted(directory.rglob('*')):
        if p.is_dir() and not p.is_symlink():continue
        add(p,prefix+'/'+p.relative_to(directory).as_posix())
tree(E/'m03-native-quit-menu-evidence-v1','prior-reviewed-quit-menu')
tree(E/'windows-gui-subsystem-preparation/v1','windows-gui-source')
tree(E/'windows-gui-subsystem-independent-review/v1','windows-gui-independent')
tree(E/'windows-gui-subsystem-canonical-adoption-v1','windows-gui-adoption')
for p in sorted((E/'native-desktop-entry-canonical-focus-v1').iterdir()):
    if p.is_file() and not p.is_symlink():add(p,'canonical-two-file-focus/'+p.name)
add(Path(__file__),'observer/package-executed.py')
rows=[]
with tarfile.open(O/'proof.tar.gz','w:gz') as archive:
    for name,path in sorted(files.items()):
        info=path.lstat();body=path.read_bytes();m=tarfile.TarInfo(name);m.size=len(body);m.mode=stat.S_IMODE(info.st_mode);archive.addfile(m,io.BytesIO(body));rows.append({'path':name,'source_path':str(path),'bytes':len(body),'mode':m.mode,'sha256':hashlib.sha256(body).hexdigest()})
with tarfile.open(O/'proof.tar.gz','r:gz') as archive:
    members=archive.getmembers();assert len(members)==len(rows)
    for m,row in zip(members,rows,strict=True):
        f=archive.extractfile(m);assert f is not None
        body=f.read();p=Path(row['source_path'])
        assert m.isfile() and m.name==row['path'] and m.mode==row['mode'] and len(body)==row['bytes'] and hashlib.sha256(body).hexdigest()==row['sha256'] and body==p.read_bytes() and stat.S_IMODE(p.stat().st_mode)==row['mode']
def dump(name,value):(O/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
proof=O/'proof.tar.gz'
dump('artifact.json',{'path':proof.name,'bytes':proof.stat().st_size,'sha256':hashlib.sha256(proof.read_bytes()).hexdigest()})
dump('retention-manifest.json',{'members':rows,'regular_members':len(rows),'all_original_archive_bytes_fullmodes_join':True,'omissions':['Whole2255 canonical/runtime40 bodies and compiled outputs. Exact finite source/pinned primary references, raw focused commands and full endpoint commitments retained.','Nested original Quit packet declares its earlier direct-formatter receipt and full-body omissions.']})
focus=E/'native-desktop-entry-canonical-focus-v1'
closure=json.loads((focus/'closure.json').read_text());results=json.loads((focus/'results.json').read_text())
assert closure['all_five_commands_closed_zero'] and closure['source_bytes_fullmodes_status_head_tree_equal'] and len(results)==5
dump('summary.json',{'created_utc':datetime.datetime.now(datetime.UTC).isoformat(),'scope':'REVIEWED_NATIVE_QUIT_AND_WINDOWS_DEBUG_GUI_SOURCE_ADOPTED_AND_CANONICALLY_CHECKED_NOT_FOREIGN_GUI','quit_source':'11c396773be1d2086b4a5002404a546ff50fb38c89e6af4be427bfc7cb45dbef','quit_afterimage':'53ce147f3cf175371eefafdfc296363d8cf57f928f4609f35a527fb84a08b4f9','windows_gui_source':'7d03ceea68ba681982f97e73364d5a27fc1de0b0e2b0662b5cbe9a20a36dda68','windows_gui_afterimage':'85d95119a4ebcfeb4122020a8d33a0e62eb9e850721a53c64b0fd07e5807bce3','windows_gui_independent_manifest':'d0ded0b520693d1eec8298a2d10b58ebe0520a9def5cd30047dc8ab5139b7741','canonical_focus':{'commands':results,'closure':closure,'rust_same_unique_cases_each_three_modes':342},'actual_current_hosted_PE_subsystem_failure_observed':False,'corrected_actual_windows_PE_native_gui_or_acceptance_credit':False})
(O/'README.md').write_text('''# Native Quit entry and Windows development GUI subsystem

The immutable nested packet retains the reviewed custom Windows/Ubuntu File→Quit
entry, unchanged common shutdown owner, actual guarded lib.rs adoption and first
five-command canonical Rust/strict check. macOS default menu remains unchanged.

One further reviewed main.rs header fixes a source-derived development mismatch:
the pinned native packaging path calls TauriCLI2.12.3 build--debug, while the old
GUI subsystem attribute applies only without debug assertions. The unchanged
Windows inspector requires appPE GUI2 and refuses console3. Pinned CLI source,
project profile/manifest/curated environment and primary Rust/Cargo docs show no
declared override. This is source evidence, not an observed current hosted PE
failure; a future runner's ambient Cargo config is not claimed inventoried.

The corrected attribute selects the GUI subsystem for normal Windows builds in
both debug and release, excludes cfg(test) harnesses and leaves non-Windows
behavior unchanged. No PE inspector/test, packaging stage, schema, dependency or
timeout is relaxed. Existing actual Windows build/PE and desktop oracles must
validate its result; macOS source checks cannot supply those native observations.

Different narrow source review CLEAR binds SOURCE7d03ceea… and exact six held
preimages/four additional references; primary provenance and raw finite joins
remain. Root guarded-adopts main.rs after the prior Quit checks, changing only
that path within the2255-source inventory; remaining2254/runtime40 bytes/full
modes and HEAD/tree stay equal. Canonical combined five-command check then
passes Cargo format, strict all-targets/all-features Clippy, registered Rust
suite22.077607s (342same unique IDs each of three modes plus separate1/10), whole
portability and integrity. All five children closed0/reaped/groupsABSENT/no
signals/timeouts,2255source/runtime40 bytes/full modes/two-path dirty status/
HEAD-tree endpoints equal. Exact actual argv/stdout/stderr/maps/closures retained.

Original selected/archive bytes/full modes join. Full canonical/runtime bodies
and compiled outputs stay outside with explicit commitments. Fresh corrected
full, actual Windows PE and Windows11/defaultGNOME GUI/accelerator/cleanup tests
still follow. No later-source full pass, native desktop, platform certification,
M03 completion, final visual baseline or release readiness is inferred.
''')
print(json.dumps({'directory':str(O),'members':len(rows),'proof':json.loads((O/'artifact.json').read_text())}))
