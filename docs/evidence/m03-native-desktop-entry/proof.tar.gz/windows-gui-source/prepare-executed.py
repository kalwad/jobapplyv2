from pathlib import Path
import hashlib
import json
import subprocess

E=Path(__file__).parent
R=Path('/Users/tanishkalwad/jobapplyv2')
O=E/'windows-gui-subsystem-preparation/v1'
O.mkdir(parents=True)
relative='apps/desktop/src-tauri/src/main.rs'
body=(R/relative).read_bytes()
before=b'#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]'
after=b'#![cfg_attr(all(target_os = "windows", not(test)), windows_subsystem = "windows")]'
assert body.count(before)==1
(O/'before-main.rs').write_bytes(body)
(O/'after-main.rs').write_bytes(body.replace(before,after))
refs=[relative,'scripts/native_package_pipeline.py','scripts/windows_package.py','scripts/tests/test_windows_package.py','apps/desktop/src-tauri/Cargo.toml','apps/desktop/src-tauri/build.rs']
rows=[]
for rel in refs:
    source=R/rel;data=source.read_bytes();target=O/'reference'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    rows.append({'path':rel,'bytes':len(data),'mode':source.stat().st_mode & 0o7777,'sha256':hashlib.sha256(data).hexdigest()})
(O/'SOURCE.json').write_text(json.dumps({'schema':'WINDOWS_GUI_SUBSYSTEM_PREPARATION_V1','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),'canonical_path':relative,'before_sha256':hashlib.sha256(body).hexdigest(),'after_sha256':hashlib.sha256((O/'after-main.rs').read_bytes()).hexdigest(),'refs':rows,'scope':'Source-derived debug console mismatch: pipeline uses --debug; static inspector requires GUI subsystem2 for app. Actual current hosted package has not reached a retained final verdict; no actual PE failure claimed.'},indent=2)+'\n')
(O/'prepare-executed.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'source_sha256':hashlib.sha256((O/'SOURCE.json').read_bytes()).hexdigest(),'after_sha256':hashlib.sha256((O/'after-main.rs').read_bytes()).hexdigest()}))
