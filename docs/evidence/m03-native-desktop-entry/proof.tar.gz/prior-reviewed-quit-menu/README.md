# Explicit native Quit menu and unchanged shutdown owner

Pinned Tauri2.12.4 creates its default native menu automatically only on macOS.
The reviewed helper returns before changing that macOS menu. Windows/Ubuntu
receive one ordinary File→Quit item and Ctrl+Q, with a fixed native event ID
routed to the existing ManagedService.request_shutdown. It does not invoke the
framework predefined Quit behavior; authority withdrawal, common6.05s budget,
cleanup-failure retry and final exit remain owned by the existing coordinator.
The helper body stays type-checked by the common Mac build as well. No renderer
IPC permission, navigation/security policy, dependency or schema changes.

Different source review is CLEAR at exact SOURCE11c39677…/after53ce147f…;
12 finite source/reference bodies, six canonical preimages and five pinned
framework bodies join. Root guarded-adopts exactly one lib.rs after actual
cleanf5a full closes. The source inventory has2255files: one changes, remaining
2254 and40runtime bodies/full modes stay equal. A raw adoption field name
all_other2255_source_runtime40 refers to the inventory, not2255 extra files.

Actual canonical five commands all exit0: Cargo format, strict all-targets/
all-features Clippy, the registered Rust verification suite (342identicalunique
cases in each of three modes plus separate native-host1/contract10), whole
portability and integrity. Rust suite27.680062s. All children reaped/groupsABSENT,
no signals/timeouts; all2255source/runtime40 bytes/full modes/one-path dirty
status/HEAD-tree endpoints agree. This is actual type/compile/test evidence on
macOS, not Windows/Ubuntu UI activation or accelerator behavior. Fresh full and
native target validation still follow before work-package acceptance.

Selected preimages/afterimage/pinned API/shutdown source, honest initial helper
history, independent source review, actual canonical adoption and raw focused
receipts remain byte/full-mode exact. Whole canonical/runtime bodies, compiled
outputs and uncaptured early direct-formatter receipts are explicitly omitted.
No foreign GUI, final visual baseline, support certification or release credit.
