"""Close the inert packager receipt and bind small historical CI records explicitly."""
from pathlib import Path, PurePosixPath
from datetime import datetime, UTC
import gzip, hashlib, io, json, stat, tarfile
E=Path(__file__).resolve().parent
H=E/'m03-package-and-authorizer-evidence-preparation/v1'
O=H/'after/docs/evidence/m03-package-and-authorizer-corrections'
def pin(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink();b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':stat.S_IMODE(s.st_mode),'full_mode':s.st_mode}
def load(p):return json.loads(p.read_text())
def dump(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n');p.chmod(0o644)
def safe(n):p=PurePosixPath(n);return bool(n and not p.is_absolute() and '..' not in p.parts and '\\' not in n and p.as_posix()==n)
assert not (H/'SEAL.json').exists()
receipt=load(H/'packaging-receipt.json')
assert receipt['exit_code']==0 and receipt['reaped'] and receipt['group_after_wait']=='ABSENT' and receipt['script_before']==receipt['script_after'] and not receipt['signals'] and not receipt['timeout']
history=H/'history/initial-inert-build';history.mkdir()
for name in ('SOURCE.json','AFTERIMAGES.json','QA.json','HANDOFF.md','MANIFEST.json'):
 p=H/name;d=history/name;d.write_bytes(p.read_bytes());d.chmod(pin(p)['mode'])
for p in O.iterdir():
 d=history/'after'/p.name;d.parent.mkdir(exist_ok=True);d.write_bytes(p.read_bytes());d.chmod(pin(p)['mode'])
rows=load(O/'retention-manifest.json')['members']
files={r['path']:Path(r['origin']) for r in rows}
origins=load(H/'SOURCE.json')['original_inputs']
CI=E/'ci-f3a1c6f-independent-review/v1'
C=E/'full437-ci-f3-compact-evidence-preparation/v1/after/docs/evidence/m03-w07-ci-f3-terminal'
selected=[(CI/'REVIEW.md','historical-f3-CI/review.md'),(CI/'package-record-review.json','historical-f3-CI/package-record-review.json')]
for name in ('README.md','artifact.json','summary.json','retention-manifest.json'):
 selected.append((C/name,'historical-f3-CI/compact-parent/'+name))
for rel in ('raw-collector/artifacts/12938240486/contents-attempt-1/pipeline/10-tauri-package.result.json','raw-collector/runs/40956683963/closed-jobs/123763607069.json','raw-collector/runs/40956683963/closed-jobs/123763607069.log'):
 selected.append((CI/rel,'historical-f3-CI/'+rel))
assert pin(CI/'REVIEW.md')['sha256']=='c7862436e9b217c6edeadc5b75090ad193aa5802004595a39764c5039c7d573f'
assert load(C/'artifact.json')['sha256']=='9d919d8502487e43f5f26473ed53e31535c4c222885514f4630610f8ea279ba3'
win=load(selected[-3][0]);assert win['exit_code']==0 and win['success'] is False and win['containment']['terminated_job'] is True
for p,name in selected:
 assert safe(name) and name not in files
 r=pin(p);files[name]=p;origins[str(p)]=r
for p,name in [(H/'packaging-receipt.json','preparation/packaging-receipt.json'),(H/'packaging.stdout.log','preparation/packaging.stdout.log'),(E/'run-package-authorizer-packaging-v1.py','preparation/run-packaging.py'),(Path(__file__),'preparation/finalize-packaging.py')]:
 files[name]=p;origins[str(p)]=pin(p)
external={'historical_f3_CI':{'compact_parent_absolute_path':str(C),'proof_sha256':'9d919d8502487e43f5f26473ed53e31535c4c222885514f4630610f8ea279ba3','proof_bytes':5943844,'full_original_review_parent_absolute_path':str(CI),'full_parent_proof_sha256':'9158eefac41c3e0d66f02d6d6ec76084005247a12299f7460ca855a17c24231a','full_parent_proof_bytes':517312791,'scope':'Small raw Windows result/API/job log and parent text inventories retained here; parent proofs/original ZIP/binary bodies remain at exact outside parents, not embedded again.'}}
facts=load(H/'PACKET-FACTS.json');facts['external_historical_parents']=external
dump(H/'PACKET-FACTS.json',facts)
source=load(H/'SOURCE.json');source['original_inputs']=origins;source['finalization_utc']=datetime.now(UTC).isoformat();source['closed_inert_packaging_child']=receipt;source['historical_CI_pin_addition']='Before final seal, explicit small original Windows CI records and complete compact-parent inventories were added. Initial unsealed build bytes remain outside under history/initial-inert-build; no frozen source/peer parent was changed.'
dump(H/'SOURCE.json',source)
members=[]
with (O/'proof.tar.gz').open('wb') as out,gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as t:
 for name,p in sorted(files.items()):
  r=pin(p);b=p.read_bytes();m=tarfile.TarInfo(name);m.size=len(b);m.mode=r['mode'];m.mtime=0;t.addfile(m,io.BytesIO(b));members.append({'path':name,'origin':str(p),**r})
assert (O/'proof.tar.gz').stat().st_size<50*1024*1024
joins=0
with tarfile.open(O/'proof.tar.gz','r:gz') as t:
 ms=t.getmembers();assert len(ms)==len(members)==len({m.name for m in ms})
 for m,r in zip(ms,members,strict=True):
  b=t.extractfile(m).read();assert m.isfile() and safe(m.name) and m.name==r['path'] and len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'] and m.mode==r['mode'] and pin(Path(r['origin']))=={k:r[k] for k in ('bytes','sha256','mode','full_mode')};joins+=1
for p,r in origins.items():assert pin(Path(p))==r;joins+=1
dump(O/'artifact.json',{'path':'proof.tar.gz',**pin(O/'proof.tar.gz')})
ret=load(O/'retention-manifest.json');ret['members']=members;ret['regular_members']=len(members);ret['external_historical_parents']=external;dump(O/'retention-manifest.json',ret)
summary=load(O/'summary.json');summary['facts']=facts;summary['packaging']['proof_members']=len(members);summary['packaging']['original_input_endpoints']=len(origins);summary['packaging']['finalization_joins']=joins;summary['packaging']['closed_owned_packaging_child']=receipt;dump(O/'summary.json',summary)
readme=(O/'README.md').read_text();readme=readme.replace('Original R request','Original R request')
readme += '\nSmall original Windows job/API/result records and complete compact-parent inventories bind the historical CI statement directly. The existing compact CI parent is retained at `'+str(C)+'` (proof SHA `9d919d8502487e43f5f26473ed53e31535c4c222885514f4630610f8ea279ba3`); the 517,312,791-byte full review proof remains outside at `'+str(CI)+'/proof.tar.gz` (SHA `9158eefac41c3e0d66f02d6d6ec76084005247a12299f7460ca855a17c24231a`). Their large original ZIP and binary bodies are not embedded here.\n'
(O/'README.md').write_text(readme)
after={p.name:pin(p) for p in sorted(O.iterdir())};assert len(after)==5
dump(H/'AFTERIMAGES.json',{'target':'docs/evidence/m03-package-and-authorizer-corrections','files':after})
qa=load(H/'QA.json');qa['original_input_endpoints']=len(origins);qa['packet_regular_members']=len(members);qa['proof']=pin(O/'proof.tar.gz');qa['finalization_joins']=joins;qa['closed_owned_packaging_child']=receipt;dump(H/'QA.json',qa)
(H/'HANDOFF.md').write_text(f'''Five exact afterimages ready under after/docs/evidence/m03-package-and-authorizer-corrections. Final proof {after['proof.tar.gz']['bytes']} bytes/{len(members)} safe regular members; seven nested proofs bind 6,256 original safe members. Initial 19,495 inert checks plus {joins} finalization joins; {len(origins)} original body/full-mode endpoints equal. Owned inert build child PID5430/PGID5430 exit0/reaped/groupABSENT/no signals/timeouts; outer/finalizer tool interpreter numeric custody not separately retained. All source/peer parents unchanged. Explicit original integrity FAIL/diff UNRUN then one-D stage and only two successor PASS checks; no transferred full/CI/Windows/native/model/milestone acceptance. Historical f3 raw result/metadata and compact-parent inventories added before seal; initial unsealed build bytes retained under history. Root alone may adopt these five metadata files.\n''')
for p in H.rglob('*'):
 if p.is_file():assert stat.S_ISREG(p.lstat().st_mode) and not p.is_symlink()
manifest={p.relative_to(H).as_posix():pin(p) for p in sorted(H.rglob('*')) if p.is_file() and p.name not in ('MANIFEST.json','SEAL.json')}
dump(H/'MANIFEST.json',{'files':manifest,'scope':'Finite sealed outside preparation; only five afterimages proposed for canonical adoption.'})
seal={'created_utc':datetime.now(UTC).isoformat(),'pins':{n:pin(H/n) for n in ('SOURCE.json','AFTERIMAGES.json','QA.json','HANDOFF.md','MANIFEST.json')},'afterimages':after,'safe_regular_proof_members':len(members),'nested_safe_regular_members':6256,'original_endpoints':len(origins),'initial_inert_checks':19495,'finalization_joins':joins}
dump(H/'SEAL.json',seal)
print(json.dumps(seal))
