"""Gather only already sealed finite source/review parents; no live focus conclusion."""
from pathlib import Path,PurePosixPath
from datetime import datetime,UTC
import hashlib,json,stat,tarfile
E=Path(__file__).resolve().parent;H=E/'m03-package-and-authorizer-evidence-preparation/v1';H.mkdir(parents=True,exist_ok=False)
parents=[('source-windows-job-v2',E/'windows-package-job-drain-preparation/v2','SOURCE.json','c38ee31b9d401cc9db4057b2d37bce7790d9be753e129afb64e22386f6ad5793','cd9395e2509c605173fc830ad9681a7d4694fc8ddfa87e262c70f0508811130e'),('source-authorizers-v1',E/'authorizer-live-pr-head-correction/v1','SOURCE.json','ac4a86cba1c29ea604d31a09f323c75c7d7865ed61a55db6ecb19c47a000fd67','902ac448186073b21f62be2dd8ad202ca8dd3dc4d37bbc70a4ca12415faa897b'),('source-loader-pin',E/'windows-package-job-drain-preparation/v2-integration-pin','SOURCE.json','62286b109344c0b5a6f236594e7967c2260cf997ea866020ebfd23e58f6d4b0f','0c206aafb15e0ad6a8432568f1888bc37d1e1466eebf19e5c734344146c6eaf1'),('peer-windows-job-v2',E/'windows-package-job-drain-independent-review/v2','REVIEW.md','e7a25f9faddd2833829d6591b3ce6a12d815d66c2ac4f6226b952c6501cdd058',None),('peer-authorizers-v1',E/'authorizer-live-pr-head-independent-review/v1','REVIEW.md','688ac7c56b8500d727f72d440bc5ecc2c15ea95fba96d7640e0426ca59b0980c',None),('peer-loader-pin',E/'windows-package-job-drain-independent-review/v2-integration-pin','REVIEW.md','686951ea61f88e06d264ba52b474e6eab0a3c0602de876b49a45c60a19164144','5a546a9ed8170e95d8e579a8378974633962f84ed4ed783cd079efe52d1379d3')]
def pin(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink();b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'full_mode':s.st_mode,'mode':stat.S_IMODE(s.st_mode)}
def safe(n):return bool(n and not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and '\\' not in n and PurePosixPath(n).as_posix()==n)
rows=[];nested=[]
for label,root,key,expected,proof in parents:
 assert pin(root/key)['sha256']==expected
 if proof:assert pin(root/'proof.tar.gz')['sha256']==proof
 for p in sorted(root.iterdir()):
  if not p.is_file():continue
  r=pin(p);dest=H/'retained'/label/p.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes());dest.chmod(r['mode']);assert pin(dest)==r and pin(p)==r
  rows.append({'path':str(dest.relative_to(H)),'origin':str(p),**r})
 with tarfile.open(root/'proof.tar.gz','r:gz') as tar:
  members=tar.getmembers();assert 1<=len(members)<=5000 and len(members)==len({m.name for m in members}) and sum(m.size for m in members)<=128*1024*1024
  inventory=[]
  for m in members:
   assert m.isfile() and safe(m.name) and m.size<=32*1024*1024;b=tar.extractfile(m).read();p=root/m.name;r=pin(p)
   assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'] and m.mode==r['mode']
   inventory.append({'path':m.name,'bytes':len(b),'archive_mode':m.mode,'original_full_mode':r['full_mode'],'sha256':r['sha256']})
  nested.append({'label':label,'origin':str(root/'proof.tar.gz'),'proof':pin(root/'proof.tar.gz'),'safe_regular_members':len(members),'uncompressed_bytes':sum(m.size for m in members),'all_original_body_fullmode_joins':True,'members':inventory})
(H/'GATHERED.json').write_text(json.dumps({'utc':datetime.now(UTC).isoformat(),'parents':rows,'nested_archives':nested,'focus_or_actual_adoption_verdict':None,'scope':'Only frozen source/peer parents gathered. Must await root pin/focus closure and SDK actualCLEAR before packet sealing.'},indent=2)+'\n')
(H/'PREDECLARED.md').write_text('''One compact five-file packet targetdocs/evidence/m03-package-and-authorizer-corrections. Preserve sealed source/peer parents, oldRfailedmetadata/requestretention, rootreaderfailure and exact guarded adoptions. Awaitactual rootfocusclosure and SDKdifferentactualCLEAR beforeseal. Planned2378logical/2880POSIX is not observedPASS. No canonical/Git/API/native/model action or fullcurrentGit/runtimebinary bodies. Finite nestedproof/member/sourcefullmode joins and explicit omissions.
''')
print(json.dumps({'parents':len(parents),'top_records':len(rows),'nested_safe_members':sum(r['safe_regular_members'] for r in nested),'bytes':sum(r['bytes'] for r in rows),'focus_verdict':None}))
