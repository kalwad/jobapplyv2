from pathlib import Path
from datetime import datetime, UTC
import hashlib, json, os, subprocess, sys, time
E=Path(__file__).resolve().parent
script=E/'build-package-authorizer-evidence-v1.py'
H=E/'m03-package-and-authorizer-evidence-preparation/v1'
before={'bytes':script.stat().st_size,'sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'full_mode':script.stat().st_mode}
start=datetime.now(UTC).isoformat();t=time.monotonic()
with (H/'packaging.stdout.log').open('xb') as out:
    p=subprocess.Popen([sys.executable,'-I','-S','-B',str(script)],stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,start_new_session=True,cwd=E)
    pid=p.pid;pgid=os.getpgid(pid);code=p.wait()
try:
    os.killpg(pgid,0);group='PRESENT'
except ProcessLookupError:group='ABSENT'
after={'bytes':script.stat().st_size,'sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'full_mode':script.stat().st_mode}
r={'argv':[sys.executable,'-I','-S','-B',str(script)],'script_before':before,'script_after':after,'pid':pid,'pgid':pgid,'exit_code':code,'reaped':p.returncode is not None,'group_after_wait':group,'signals':[],'timeout':False,'start_utc':start,'end_utc':datetime.now(UTC).isoformat(),'seconds':time.monotonic()-t,'scope':'Owned inert packaging child only; outer tool interpreter custody not separately retained.'}
(H/'packaging-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
assert before==after and code==0 and group=='ABSENT'
