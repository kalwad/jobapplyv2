from pathlib import Path,PurePosixPath
import datetime,hashlib,json,stat,subprocess,zipfile
E=Path(__file__).parent;R=Path('/Users/tanishkalwad/jobapplyv2');P=E/'gnome-download-only-f3-readiness/v1';O=E/'gnome-download-only-root-release/v1'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True,timeout=30).strip()
def save(n,v):(O/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
assert sha(P/'SOURCE.json')=='528ea24c56fe1f59ece77c8f4d991d8c20cb79bd006aec8ef84c3e3c1f95e553'
assert sha(P/'MANIFEST.json')=='49099d6842d75cb333b158075e7120d2739f64e9af66d1725f8ffad2eb3a919e'
checks=0
for name,m in read(P/'MANIFEST.json')['files'].items():
 p=P/name;s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_size==m['bytes'] and s.st_mode==m['full_mode'] and sha(p)==m['sha256'];checks+=1
request_source=P/'after/.github/gnome/requests/download-only.json';q=read(request_source)
assert sha(request_source)=='9a88dac3505493f5f3da76db91e477d483591e2d6177419d86316447acbffffe'
assert git('rev-parse','HEAD')==q['request_parent_sha']=='4378627d13317f4488f1e8c5d9264cb5b85b853d' and git('status','--porcelain')==''
assert read(E/'full-4378627/closure.json')['all_commands_exit_zero']
assert sha(E/'clean-full-4378627-independent-review/v1/REVIEW.md')=='6c0526795c3d9b28e710e20673fb8a5bc5d5653dfb9a3885b99e55902d075ab2'
a=read(O/'fresh-artifact.json');run=read(O/'fresh-run.json');pr=read(O/'fresh-pr.json');pin=q['artifact']
assert a['id']==int(pin['artifact_id']) and a['expired'] is False and a['digest']=='sha256:'+pin['digest_sha256'] and a['name']=='gnome-package-input-'+q['package_build_sha']
assert run['id']==int(pin['run_id']) and run['run_attempt']==int(pin['run_attempt']) and run['status']=='completed' and run['conclusion']=='failure' and run['head_sha']==q['expected_source_sha'] and run['event']=='pull_request' and run['path']=='.github/workflows/ci.yml'
assert all(run[k]['id']==1312360079 and run[k]['full_name']=='kalwad/jobapplyv2' for k in ('repository','head_repository'))
assert len(run['pull_requests'])==1 and run['pull_requests'][0]['number']==1 and run['pull_requests'][0]['head']['sha']==q['expected_source_sha']
assert pr['state']=='open' and pr['head']['sha']==q['expected_source_sha'] and pr['head']['ref']==q['head_branch'] and pr['base']['ref']=='main' and pr['head']['repo']['id']==pr['base']['repo']['id']==1312360079
assert a['workflow_run']['id']==run['id'] and a['workflow_run']['head_sha']==q['expected_source_sha']
assert datetime.datetime.fromisoformat(a['expires_at'].replace('Z','+00:00'))>datetime.datetime.now(datetime.UTC)
A=E/'ci-f3a1c6f/artifacts/12937890723';D=A/'contents-attempt-1'
assert sha(A/'attempt-1.zip')==pin['digest_sha256'] and sha(D/'export.json')==pin['export_sha256']
with zipfile.ZipFile(A/'attempt-1.zip') as z:
 ms=z.infolist();assert len(ms)==9 and len({m.filename for m in ms})==9
 for m in ms:
  pp=PurePosixPath(m.filename);assert not pp.is_absolute() and '..' not in pp.parts and not m.is_dir() and stat.S_ISREG(m.external_attr>>16)
  dest=D/m.filename;assert z.read(m)==dest.read_bytes() and (m.external_attr>>16)==dest.stat().st_mode;checks+=1
ex=read(D/'export.json');assert ex['expected_head']==q['package_build_sha'] and ex['build_git_binding']=={'head':q['package_build_sha'],'tree':q['source_tree_sha']}
immutable=E/'ci-f3a1c6f/immutable-git-source-sha256.json';assert sha(immutable)=='4ab7ec940114f598574d5d09c242bb6dc8f0968562174fac45428e74fbadd528'
source=read(immutable)['files'];assert len(source)==2348 and ex['shipping_source_projection']=={n:m['sha256'] for n,m in source.items()};checks+=2348
for n,m in ex['files'].items():
 p=D/n;s=p.stat();assert s.st_size==m['bytes'] and stat.S_IMODE(s.st_mode)==m['mode'] and sha(p)==m['sha256'];checks+=1
for n in ('.github/workflows/ubuntu-gnome-prepare.yml','.github/workflows/ubuntu-gnome-lifecycle.yml','scripts/linux_gnome/ubuntu_gnome_request.py','scripts/linux_gnome/ubuntu_gnome_process.py','scripts/linux_gnome/ubuntu_gnome_platform.py'):
 assert sha(R/n)==source[n]['sha256'];checks+=1
assert git('merge-base','--is-ancestor',q['expected_source_sha'],q['request_parent_sha'])==''
target=R/'.github/gnome/requests/download-only.json';assert not target.exists()
save('root-review.json',{'utc':datetime.datetime.now(datetime.UTC).isoformat(),'checks':checks,'request':q,'fresh_GETs':{'scope':'Three root tool-observed ghapi GET commands each exited0; no independent numeric child custody claimed','files':{n:sha(O/n) for n in ('fresh-artifact.json','fresh-run.json','fresh-pr.json')}},'scope':'Root separately joins exact prospective request, completed actual failure-valued CI provenance, actual Ubuntu export/source/ZIP/modes and current clean parent. DOWNLOAD_ONLY only; candidate remains UNREVIEWED; no install/VM or platform acceptance.'})
target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(request_source.read_bytes());target.chmod(0o644)
(O/'adoption-executed.py').write_bytes(Path(__file__).read_bytes());assert sha(target)==sha(request_source)
save('adoption.json',{'utc':datetime.datetime.now(datetime.UTC).isoformat(),'request_path':str(target.relative_to(R)),'sha256':sha(target),'parent':git('rev-parse','HEAD'),'git_status':git('status','--porcelain'),'scope':'One request file adopted. Git commit/push and actual workflow validation remain separate; no subject actor.'})
print(json.dumps({'checks':checks,'adopted_request':str(target),'sha256':sha(target)}))
