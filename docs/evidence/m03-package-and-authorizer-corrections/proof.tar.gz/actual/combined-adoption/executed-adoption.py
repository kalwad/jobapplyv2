from pathlib import Path, PurePosixPath
import datetime, hashlib, json, os, stat, subprocess, sys, tarfile

E=Path(__file__).parent;R=Path('/Users/tanishkalwad/jobapplyv2')
W=E/'windows-package-job-drain-preparation/v2';A=E/'authorizer-live-pr-head-correction/v1'
O=E/'package-and-authorizer-canonical-adoption/v1'
assert len(sys.argv)==5
reviews=[(Path(sys.argv[1]),sys.argv[2]),(Path(sys.argv[3]),sys.argv[4])]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def rec(p):
    p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode)
    return {'bytes':s.st_size,'full_mode':s.st_mode,'sha256':sha(p)}
def check(p,m):
    a=rec(p)
    for k in ('bytes','full_mode','sha256'):
        if k in m:assert a[k]==m[k],(str(p),k,a[k],m[k])
    return a
def git(*a):return subprocess.check_output(['git','--no-optional-locks',*a],cwd=R,timeout=30).decode().strip()
def snap():
    names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=R,timeout=30).split(b'\0')
    rt=R/'apps/desktop/src-tauri/runtime-payload'
    return {'source':{os.fsdecode(n):rec(R/os.fsdecode(n)) for n in names if n},'runtime':{p.relative_to(rt).as_posix():rec(p) for p in sorted(rt.rglob('*')) if not p.is_dir()},'status':git('status','--porcelain','--untracked-files=all'),'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'index_sha256':sha(R/'.git/index')}
def save(n,v):(O/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
checks=0
for p,h in reviews:
    assert p.is_absolute() and p.is_relative_to(E) and sha(p)==h
    assert p.read_text().startswith('# CLEAR:');checks+=1
archives=[]
for base,sourcepin,proofpin in [(W,'c38ee31b9d401cc9db4057b2d37bce7790d9be753e129afb64e22386f6ad5793','cd9395e2509c605173fc830ad9681a7d4694fc8ddfa87e262c70f0508811130e'),(A,'ac4a86cba1c29ea604d31a09f323c75c7d7865ed61a55db6ecb19c47a000fd67','902ac448186073b21f62be2dd8ad202ca8dd3dc4d37bbc70a4ca12415faa897b')]:
    assert sha(base/'SOURCE.json')==sourcepin and sha(base/'proof.tar.gz')==proofpin
    rows=read(base/'SOURCE.json')['files']
    for n,m in rows.items():
        pp=PurePosixPath(n);assert not pp.is_absolute() and '..' not in pp.parts
        check(base/n,m);checks+=1
    expected={**rows,'SOURCE.json':rec(base/'SOURCE.json')}
    with tarfile.open(base/'proof.tar.gz','r:gz') as tf:
        members=tf.getmembers();assert len(members)==len(expected);seen=set()
        for member in members:
            pp=PurePosixPath(member.name)
            assert member.isfile() and not pp.is_absolute() and '..' not in pp.parts and member.name not in seen
            seen.add(member.name);m=expected[member.name];b=tf.extractfile(member).read()
            assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256'] and member.mode==stat.S_IMODE(m['full_mode']);checks+=1
    archives.append({'source':str(base),'source_sha256':sourcepin,'proof_sha256':proofpin,'safe_regular_members':len(expected)})
selected={}
for base,mapping in [(W,read(W/'ADOPTION.json')['selection']),(A,read(A/'ADOPTION.json')['paths'])]:
    for n,m in mapping.items():
        if n=='scripts/python-test-inventory.v1.json':continue
        assert n not in selected
        p=R/n
        if m['before'] is None:assert not p.exists()
        else:check(p,m['before'])
        check(base/m['afterimage'],m['after']);selected[n]=base/m['afterimage'];checks+=2
assert len(selected)==7
catalog='scripts/python-test-inventory.v1.json';original=read(R/catalog)
assert sha(R/catalog)=='0ba8f7d59ae923cd689e4b9ede780dc588ef1047ea2478426f0f540fefcef31b'
native_ids=read(W/'NEW-NODE-IDS.json');auth_ids=(A/'NEW-TEST-IDS.txt').read_text().splitlines()
assert len(native_ids)==len(set(native_ids))==30 and len(auth_ids)==len(set(auth_ids))==32
old=original['common']['node_ids'];added=native_ids+auth_ids
assert len(old)==2815 and len(set(added))==62 and not set(old)&set(added)
native_catalog=read(W/'project'/catalog)
assert native_catalog['posix_only_node_ids']==original['posix_only_node_ids']
assert native_catalog['common']['node_ids']==sorted(old+native_ids)
combined=json.loads(json.dumps(original));ids=sorted(old+added)
combined['common']={'count':len(ids),'sha256':hashlib.sha256(('\n'.join(ids)+'\n').encode()).hexdigest(),'node_ids':ids}
assert len(ids)==2877 and len(combined['posix_only_node_ids'])==2
before=snap();assert len(before['source'])==2375 and len(before['runtime'])==40
assert before['head']=='c930c86c83d478b3048d4cc80abd1346065e2e0d'
O.mkdir(parents=True,exist_ok=False);save('before.json',before);save('composed-catalog.json',combined)
(O/'composed-catalog.json').chmod(stat.S_IMODE((R/catalog).stat().st_mode));selected[catalog]=O/'composed-catalog.json'
save('root-review.json',{'utc':datetime.datetime.now(datetime.UTC).isoformat(),'checks':checks,'peer_reviews':[{'path':str(p),'sha256':h} for p,h in reviews],'archives':archives,'selected':{n:rec(p) for n,p in selected.items()},'new_common_IDs':added,'scope':'Root read both production deltas and focused tests, independently verifies frozen source/proof/preimages and exact additive catalog composition. Thirty Win32-fake plus32 pure metadata IDs; no native/API/VM activation or current full acceptance.'})
(O/'executed-adoption.py').write_bytes(Path(__file__).read_bytes())
for n,p in selected.items():
    target=R/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes());target.chmod(stat.S_IMODE(p.stat().st_mode))
after=snap();save('after.json',after)
assert len(after['source'])==2378 and after['runtime']==before['runtime']
assert all(after[k]==before[k] for k in ('head','tree','index_sha256'))
assert {n:v for n,v in before['source'].items() if n not in selected}=={n:v for n,v in after['source'].items() if n not in selected}
assert all(after['source'][n]==rec(p) for n,p in selected.items())
closure={'utc':datetime.datetime.now(datetime.UTC).isoformat(),'checks':checks,'selected':8,'new_files':3,'logical_before':2375,'logical_after':2378,'old2815common_and2POSIX_preserved':True,'added_common':62,'current_common':2877,'current_POSIX':2879,'unselected2370_sources_fullmodes_unchanged':True,'runtime40_fullmodes_unchanged':True,'HEAD_tree_index_unchanged':True,'scope':'Working-tree source adoption only; focused execution/full CI/actual Windows/native release remain pending.'}
save('closure.json',closure);print(json.dumps(closure),flush=True)
