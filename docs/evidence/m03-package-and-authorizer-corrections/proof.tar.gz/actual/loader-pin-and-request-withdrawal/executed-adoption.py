from pathlib import Path, PurePosixPath
import datetime, hashlib, json, os, stat, subprocess, sys, tarfile

E=Path(__file__).parent;R=Path('/Users/tanishkalwad/jobapplyv2')
P=E/'windows-package-job-drain-preparation/v2-integration-pin'
O=E/'package-loader-pin-canonical-adoption/v1'
retired='.github/gnome/requests/download-only.json'
assert len(sys.argv)==3;peer=Path(sys.argv[1]);peerpin=sys.argv[2]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def rec(p):
    s=p.lstat();assert stat.S_ISREG(s.st_mode)
    return {'bytes':s.st_size,'full_mode':s.st_mode,'sha256':sha(p)}
def check(p,m):
    a=rec(p)
    for k in ('bytes','full_mode','sha256'):
        if k in m:assert a[k]==m[k],(str(p),k)
def git(*a):return subprocess.check_output(['git','--no-optional-locks',*a],cwd=R,timeout=30).decode().strip()
def snap(withdrawn=False):
    names=[os.fsdecode(n) for n in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=R,timeout=30).split(b'\0') if n]
    deleted=[os.fsdecode(n) for n in subprocess.check_output(['git','ls-files','--deleted','-z'],cwd=R,timeout=30).split(b'\0') if n]
    assert deleted==([retired] if withdrawn else [])
    rt=R/'apps/desktop/src-tauri/runtime-payload'
    return {'source':{n:rec(R/n) for n in names if not (withdrawn and n==retired)},'guarded_retired_tracked_path':retired if withdrawn else None,'runtime':{p.relative_to(rt).as_posix():rec(p) for p in sorted(rt.rglob('*')) if not p.is_dir()},'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'index_sha256':sha(R/'.git/index'),'status':git('status','--porcelain','--untracked-files=all')}
def save(n,v):(O/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
assert sha(peer)==peerpin and peer.read_text().startswith('# CLEAR:')
assert sha(P/'SOURCE.json')=='62286b109344c0b5a6f236594e7967c2260cf997ea866020ebfd23e58f6d4b0f'
assert sha(P/'proof.tar.gz')=='0c206aafb15e0ad6a8432568f1888bc37d1e1466eebf19e5c734344146c6eaf1'
files=read(P/'SOURCE.json')['files'];checks=3
for n,m in files.items():check(P/n,m);checks+=1
expected={**files,'SOURCE.json':rec(P/'SOURCE.json')}
with tarfile.open(P/'proof.tar.gz','r:gz') as tf:
    ms=tf.getmembers();assert len(ms)==len(expected)==106;seen=set()
    for member in ms:
        pp=PurePosixPath(member.name);assert member.isfile() and not pp.is_absolute() and '..' not in pp.parts and member.name not in seen
        seen.add(member.name);m=expected[member.name];b=tf.extractfile(member).read()
        assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256'] and member.mode==stat.S_IMODE(m['full_mode']);checks+=1
mapping=read(P/'ADOPTION.json')['selection'];assert len(mapping)==2
for n,m in mapping.items():
    if m['before'] is None:assert not (R/n).exists()
    else:check(R/n,m['before'])
    check(P/m['afterimage'],m['after']);checks+=2
oldpin='7371248344a87e537cb66cd8ef4650fb521440088be1bd75573dcf3ee5960b1d';newpin='19bf1ae0eec2f1511703f3ff9e97de14b289a1f67d64c36a2e5bf52e616b86b2'
ci='scripts/native_package_ci.py';new_ci=P/mapping[ci]['afterimage']
assert (R/ci).read_bytes().count(oldpin.encode())==1 and new_ci.read_bytes().replace(newpin.encode(),oldpin.encode())==(R/ci).read_bytes()
assert sha(R/'scripts/_native_package_process.py')==newpin
request=rec(R/retired);assert request['sha256']=='9a88dac3505493f5f3da76db91e477d483591e2d6177419d86316447acbffffe' and request['full_mode']==33188
catalog='scripts/python-test-inventory.v1.json';before_catalog=read(R/catalog);ids=before_catalog['common']['node_ids']
extra=read(P/'ADOPTION.json')['new_node_ids'];assert len(ids)==2877 and len(extra)==1 and not set(extra)&set(ids)
combined=json.loads(json.dumps(before_catalog));all_ids=sorted(ids+extra)
combined['common']={'count':2878,'sha256':hashlib.sha256(('\n'.join(all_ids)+'\n').encode()).hexdigest(),'node_ids':all_ids}
assert len(combined['posix_only_node_ids'])==2
before=snap();assert len(before['source'])==2378 and len(before['runtime'])==40
O.mkdir(parents=True,exist_ok=False);save('before.json',before);save('composed-catalog.json',combined)
(O/'retired-root-request.json').write_bytes((R/retired).read_bytes());(O/'retired-root-request.json').chmod(stat.S_IMODE(request['full_mode']));check(O/'retired-root-request.json',request)
save('root-review.json',{'utc':datetime.datetime.now(datetime.UTC).isoformat(),'checks':checks,'peer':{'path':str(peer),'sha256':peerpin},'retired_request':{'path':retired,'retained_body':str(O/'retired-root-request.json'),**request},'old_request_commit':'c930c86c83d478b3048d4cc80abd1346065e2e0d','scope':'Constant-only package-loader integration plus one actual sibling-import regression; no helper budget/run/native call. Withdraw failed R authorization from new inactive source without changing immutable R/evidence or protected-source policy. New request must bind fresh source/package.'})
(O/'executed-adoption.py').write_bytes(Path(__file__).read_bytes())
for n,m in mapping.items():
    target=R/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((P/m['afterimage']).read_bytes());target.chmod(stat.S_IMODE(m['after']['full_mode']))
(R/catalog).write_bytes((O/'composed-catalog.json').read_bytes());(R/retired).unlink()
after=snap(True);save('after.json',after)
selected=set(mapping)|{catalog,retired};assert len(selected)==4
assert len(after['source'])==2378 and after['runtime']==before['runtime']
assert all(after[k]==before[k] for k in ('head','tree','index_sha256'))
assert {n:v for n,v in before['source'].items() if n not in selected}=={n:v for n,v in after['source'].items() if n not in selected}
for n,m in mapping.items():check(R/n,m['after'])
closure={'utc':datetime.datetime.now(datetime.UTC).isoformat(),'checks':checks,'selected_paths':4,'logical_before':2378,'logical_after':2378,'new_test_files':1,'withdrawn_failed_request':retired,'retired_body_fullmode_verified_before_unlink':True,'only_expected_tracked_deletion':True,'unselected2375_sources_fullmodes_unchanged':True,'runtime40_fullmodes_unchanged':True,'HEAD_tree_index_unchanged':True,'old2877common_and2POSIX_preserved':True,'new_common':2878,'new_POSIX':2880,'scope':'Scoped source integration/withdrawal only; canonical focus/currentCI/native outcomes pending.'}
save('closure.json',closure);print(json.dumps(closure),flush=True)
