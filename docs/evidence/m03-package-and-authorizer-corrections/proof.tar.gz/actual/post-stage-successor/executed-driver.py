from pathlib import Path
import datetime,hashlib,json,os,signal,stat,subprocess,time
E=Path(__file__).parent;R=Path('/Users/tanishkalwad/jobapplyv2')
O=E/'package-authorizer-post-stage-checks/v1';O.mkdir(parents=True,exist_ok=False)
retired='.github/gnome/requests/download-only.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rec(p):
    s=p.lstat();assert stat.S_ISREG(s.st_mode)
    return {'bytes':s.st_size,'full_mode':s.st_mode,'sha256':sha(p)}
def git(*a):return subprocess.check_output(['git','--no-optional-locks',*a],cwd=R,timeout=30).decode().strip()
def names(*a):return [os.fsdecode(n) for n in subprocess.check_output(['git',*a,'-z'],cwd=R,timeout=30).split(b'\0') if n]
def snap(staged=False):
    paths=names('ls-files','--cached','--others','--exclude-standard');deleted=names('ls-files','--deleted')
    assert deleted==([] if staged else [retired]) and retired not in names('ls-files','--others','--exclude-standard')
    rt=R/'apps/desktop/src-tauri/runtime-payload'
    return {'source':{n:rec(R/n) for n in paths if n!=retired},'runtime':{p.relative_to(rt).as_posix():rec(p) for p in sorted(rt.rglob('*')) if not p.is_dir()},'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'index_sha256':sha(R/'.git/index'),'status':git('status','--porcelain','--untracked-files=all')}
def now():return datetime.datetime.now(datetime.UTC).isoformat()
def save(n,v):(O/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
retained=E/'package-loader-pin-canonical-adoption/v1/retired-root-request.json'
assert rec(retained)['sha256']=='9a88dac3505493f5f3da76db91e477d483591e2d6177419d86316447acbffffe' and not (R/retired).exists()
prior=json.loads((E/'package-and-authorizer-canonical-focus/v1/after.json').read_bytes());before=snap()
assert all(before[k]==prior[k] for k in before) and len(before['source'])==2378
assert subprocess.check_output(['git','diff','--cached','--name-status','-z'],cwd=R,timeout=30)==b''
save('before.json',before);(O/'executed-driver.py').write_bytes(Path(__file__).read_bytes());records=[]
env=dict(os.environ);env['PATH']='/opt/homebrew/opt/node@24/bin:'+env['PATH']
def run(name,argv,budget=180):
    tick=time.monotonic();start=now();expired=False;sigs=[]
    with (O/(name+'.log')).open('wb') as out:
        p=subprocess.Popen(argv,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
        try:code=p.wait(timeout=budget)
        except subprocess.TimeoutExpired:
            expired=True
            for sig in (signal.SIGTERM,signal.SIGKILL):
                if p.poll() is None:
                    try:os.killpg(p.pid,sig);sigs.append(sig.name)
                    except ProcessLookupError:pass
            code=p.wait(timeout=10)
    try:os.killpg(p.pid,0);group='PRESENT_NO_POST_REAP_SIGNAL'
    except ProcessLookupError:group='ABSENT'
    row={'name':name,'argv':argv,'pid':p.pid,'pgid':p.pid,'start_utc':start,'end_utc':now(),'seconds':time.monotonic()-tick,'exit_code':code,'reaped':p.returncode is not None,'group':group,'timeout':expired,'signals':sigs}
    records.append(row);save('commands.json',records);print(json.dumps(row),flush=True);assert code==0 and not expired and group=='ABSENT'
run('stage-exact-withdrawal',['git','add','--',retired],30)
staged=snap(True);save('after-stage.json',staged)
assert subprocess.check_output(['git','diff','--cached','--name-status','-z'],cwd=R,timeout=30)==b'D\0'+retired.encode()+b'\0'
assert all(staged[k]==before[k] for k in ('source','runtime','head','tree')) and staged['index_sha256']!=before['index_sha256']
run('integrity',['uv','run','--no-sync','--offline','python','scripts/verify.py','--suite','integrity'])
run('diff-check-combined',['git','diff','--check','HEAD'])
after=snap(True);save('after.json',after);assert after==staged
closure={'utc':now(),'logical_source':2378,'runtime':40,'same_bodies_fullmodes_HEAD_tree_as_prior_eight_PASS_checks':True,'only_index_transition':'stage exact guarded failed R request deletion','staged_diff_exactly_one_D':retired,'post_stage_checks_source_runtime_HEAD_tree_index_status_equal':True,'stage_and_two_successors_closed_zero_reaped_groups_absent':True,'prior_focus_integrity_FAILURE_preserved':True,'prior_successful_checks':8,'successor_checks':2,'scope':'Eight prior successful source/collection checks plus two post-stage integrity/diff checks on identical source/runtime bodies, with explicit one-entry index transition. No all-ten one-epoch claim/current aggregate/native/platform acceptance.'}
save('closure.json',closure);print(json.dumps(closure),flush=True)
