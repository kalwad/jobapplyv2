from pathlib import Path
import datetime, hashlib, json, os, signal, stat, subprocess, time

R=Path('/Users/tanishkalwad/jobapplyv2');E=Path(__file__).parent
O=E/'package-and-authorizer-canonical-focus/v1';O.mkdir(parents=True,exist_ok=False)
def row(p):
    s=p.lstat();assert stat.S_ISREG(s.st_mode)
    return {'bytes':s.st_size,'full_mode':s.st_mode,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def git(*a):return subprocess.check_output(['git','--no-optional-locks',*a],cwd=R,timeout=30).decode().strip()
def snap():
    names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=R,timeout=30).split(b'\0')
    retired='.github/gnome/requests/download-only.json'
    deleted=subprocess.check_output(['git','ls-files','--deleted','-z'],cwd=R,timeout=30).split(b'\0')
    assert [os.fsdecode(n) for n in deleted if n]==[retired]
    retained=E/'package-loader-pin-canonical-adoption/v1/retired-root-request.json'
    assert row(retained)['sha256']=='9a88dac3505493f5f3da76db91e477d483591e2d6177419d86316447acbffffe'
    rt=R/'apps/desktop/src-tauri/runtime-payload'
    return {'source':{os.fsdecode(n):row(R/os.fsdecode(n)) for n in names if n and os.fsdecode(n)!=retired},'guarded_retired_tracked_path':retired,'runtime':{p.relative_to(rt).as_posix():row(p) for p in sorted(rt.rglob('*')) if not p.is_dir()},'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'index_sha256':hashlib.sha256((R/'.git/index').read_bytes()).hexdigest(),'status':git('status','--porcelain','--untracked-files=all')}
def now():return datetime.datetime.now(datetime.UTC).isoformat()
def save(n,v):(O/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
before=snap();assert len(before['source'])==2378 and len(before['runtime'])==40
save('before.json',before);(O/'executed-driver.py').write_bytes(Path(__file__).read_bytes())
env=dict(os.environ);env['PATH']='/opt/homebrew/opt/node@24/bin:'+env['PATH'];records=[]
def run(name,args,budget=180):
    start=now();tick=time.monotonic();sigs=[];expired=False
    with (O/(name+'.log')).open('wb') as out:
        child=subprocess.Popen(args,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
        try:code=child.wait(timeout=budget)
        except subprocess.TimeoutExpired:
            expired=True
            for sig in (signal.SIGTERM,signal.SIGKILL):
                if child.poll() is None:
                    try:os.killpg(child.pid,sig);sigs.append(sig.name)
                    except ProcessLookupError:pass
            code=child.wait(timeout=10)
    try:os.killpg(child.pid,0);group='PRESENT_NO_POST_REAP_SIGNAL'
    except ProcessLookupError:group='ABSENT'
    r={'name':name,'argv':args,'cwd':str(R),'pid':child.pid,'pgid':child.pid,'start_utc':start,'end_utc':now(),'seconds':time.monotonic()-tick,'exit_code':code,'reaped':child.returncode is not None,'group':group,'timeout':expired,'signals':sigs}
    records.append(r);save('commands.json',records);print(json.dumps(r),flush=True)
    assert code==0 and not expired and group=='ABSENT'
u=['uv','run','--no-sync','--offline']
sources=['scripts/_native_package_process.py','scripts/native_package_ci.py','scripts/linux_gnome/ubuntu_gnome_request.py','scripts/windows11/windows11_request.py']
new_tests=['scripts/tests/test_native_package_job_drain.py','scripts/tests/test_native_package_helper_pin.py','scripts/tests/test_ubuntu_gnome_request_live_head.py','scripts/tests/test_windows11_request_live_head.py']
focused=sorted(new_tests+['scripts/tests/'+n for n in ('test_native_package_pending_owner.py','test_native_package_inputs.py','test_ci_native_package.py','test_windows_package.py','test_windows_builder.py','test_linux_package.py','test_ubuntu_gnome_request.py','test_windows11_request.py')])
selected=sources+focused
assert not (R/'.github/gnome/requests/download-only.json').exists()
passed=False
try:
    run('ruff',u+['ruff','check','--config','pyproject.toml',*selected])
    run('format',u+['ruff','format','--check','--config','pyproject.toml',*selected])
    run('mypy-linux',u+['mypy','--config-file','pyproject.toml','--platform','linux',*selected])
    # The helper's existing Linux SIGKILL annotations are not a Windows body.
    # Dynamic held-Win32 and pure metadata fixtures remain explicitly checked.
    run('mypy-win32-fixtures',u+['mypy','--config-file','pyproject.toml','--platform','win32',*new_tests,'scripts/tests/test_native_package_pending_owner.py'])
    run('prettier',['pnpm','exec','prettier','--check','scripts/python-test-inventory.v1.json'])
    run('focused-python',u+['pytest','-c','pyproject.toml','--rootdir=.','--confcutdir=.','-o','addopts=','--strict-config','--strict-markers','--disable-plugin-autoload','-p','no:cacheprovider','--basetemp',str(O/'pytest-temp'),'-q',*focused])
    run('collection',u+['pytest','-c','pyproject.toml','--rootdir=.','--confcutdir=.','-o','addopts=','--strict-config','--strict-markers','--disable-plugin-autoload','-p','no:cacheprovider','--collect-only','-q','services/orchestrator/tests','scripts/tests'])
    inventory=json.loads((R/'scripts/python-test-inventory.v1.json').read_bytes());expected=inventory['common']['node_ids']+inventory['posix_only_node_ids']
    actual=[line.strip() for line in (O/'collection.log').read_text().splitlines() if line.startswith(('services/orchestrator/tests/','scripts/tests/')) and '::' in line]
    assert len(actual)==len(set(actual))==len(expected)==2880 and set(actual)==set(expected)
    save('collection-join.json',{'count':len(actual),'exact_catalog_identity_set':True,'common':2878,'POSIX_only':2,'all_previous_IDs_retained':True,'scope':'Collection only, not full execution'})
    run('portability',u+['python','scripts/check_portability.py','--quiet'])
    run('integrity',u+['python','scripts/verify.py','--suite','integrity'])
    run('diff-check',['git','diff','--check'])
    passed=True
finally:
    after=snap();save('after.json',after)
    closure={'utc':now(),'source_count':len(before['source']),'runtime_count':40,'all_source_runtime_fullmodes_status_HEAD_tree_index_equal':before==after,'commands':len(records),'all_ten_closed_zero':passed and len(records)==10 and all(r['exit_code']==0 and r['reaped'] and r['group']=='ABSENT' and not r['timeout'] and not r['signals'] for r in records),'scope':'Focused and collection/quality checks only. Actual Win32/native/VM and fresh aggregate/CI remain separate.'}
    save('closure.json',closure);print(json.dumps(closure),flush=True);assert before==after
raise SystemExit(0 if passed else 1)
