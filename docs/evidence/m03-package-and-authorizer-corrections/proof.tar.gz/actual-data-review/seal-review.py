from pathlib import Path,PurePosixPath
import hashlib,json,stat,tarfile
R=Path(__file__).resolve().parent
def pin(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode)
 return {'bytes':s.st_size,'full_mode':s.st_mode,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def write(name,value):(R/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
for x in json.loads((R/'retained-inputs.json').read_bytes()):
 p=R/x['retained'];assert pin(p)=={k:x[k] for k in ['bytes','full_mode','sha256']}
reports=[json.loads((R/n).read_bytes()) for n in ['adoption-data-review.json','focus-epochs-data-review.json','successor-data-review.json']]
assert sum(r['checks'] for r in reports)==6012 and all(all(row['pass'] for row in r['rows']) for r in reports)
write('data-review.json',{'verdict':'CLEAR_SCOPED_ACTUAL_ADOPTION_AND_DISTINCT_FOCUS_EPOCHS','checks':6012,'reports':{n:{'checks':r['checks'],'status':r['status']} for n,r in zip(['adoption-data-review.json','focus-epochs-data-review.json','successor-data-review.json'],reports)},'logical_source':2378,'runtime':40,'catalog_POSIX':2880,'catalog_common':2878,'first_focus':{'successful_commands':8,'failed_integrity':1,'diff_not_executed':True},'successor':{'stage_exact_deletion':True,'integrity':0,'combined_diff':0,'intentional_index_transition':True},'owners':{'records':12,'all_reaped':True,'groups':'ABSENT','signals':[],'timeouts':False},'authorship':'Authorizer source authored by reviewer; this verdict covers actual data only. Different source peer reports retained.','scope':'No aggregate/currentCI/native/platform/model/milestone acceptance. Original failures preserved.'})
excluded={'SOURCE.json','MANIFEST.json','SEAL.json','proof.tar.gz'}
files={p.relative_to(R).as_posix():pin(p) for p in sorted(R.rglob('*')) if p.is_file() and p.name not in excluded}
write('SOURCE.json',{'files':files,'file_count_excluding_source':len(files),'scope':'Independent standard-library retained-data review; original source authorship and finite execution epochs disclosed.','archive_mode_rule':'Every member is a regular file; full S_IFREG|tar mode equals indexed full_mode.'})
indexed={**files,'SOURCE.json':pin(R/'SOURCE.json')}
write('MANIFEST.json',{'files':indexed,'file_count':len(indexed),'review_sha256':pin(R/'REVIEW.md')['sha256'],'checks':6012})
members={**indexed,'MANIFEST.json':pin(R/'MANIFEST.json')}
with tarfile.open(R/'proof.tar.gz','w:gz') as archive:
 for name in sorted(members):archive.add(R/name,arcname=name,recursive=False)
with tarfile.open(R/'proof.tar.gz') as archive:
 seen=set()
 for m in archive.getmembers():
  p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts and m.name not in seen;seen.add(m.name)
  body=archive.extractfile(m).read();r=members[m.name]
  assert len(body)==r['bytes'] and hashlib.sha256(body).hexdigest()==r['sha256'] and stat.S_IFREG|m.mode==r['full_mode']
 assert seen==set(members)
write('SEAL.json',{'SOURCE':pin(R/'SOURCE.json'),'REVIEW':pin(R/'REVIEW.md'),'MANIFEST':pin(R/'MANIFEST.json'),'proof':pin(R/'proof.tar.gz'),'safe_regular_members':len(members),'total_member_bytes':sum(r['bytes'] for r in members.values()),'checks':6012})
print((R/'SEAL.json').read_text())
