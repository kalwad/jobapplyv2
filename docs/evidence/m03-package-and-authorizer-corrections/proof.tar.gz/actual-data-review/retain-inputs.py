from pathlib import Path
import hashlib,json,shutil,stat
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
R=Path(__file__).resolve().parent
names=['package-and-authorizer-canonical-adoption/v1','package-loader-pin-canonical-adoption/v1','package-and-authorizer-canonical-focus/v1','package-authorizer-post-stage-checks/v1']
records=[]
def retain(source,target):
 s=source.lstat();assert stat.S_ISREG(s.st_mode) and s.st_size<=3_000_000
 body=source.read_bytes();target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():assert target.read_bytes()==body and target.stat().st_mode==s.st_mode
 else:target.write_bytes(body);target.chmod(stat.S_IMODE(s.st_mode))
 records.append({'original':str(source),'retained':target.relative_to(R).as_posix(),'bytes':len(body),'full_mode':s.st_mode,'sha256':hashlib.sha256(body).hexdigest()})
for name in names:
 source=E/name
 for f in sorted(source.iterdir()):
  if f.is_dir():continue
  retain(f,R/'retained'/name/f.name)
for name in ['adopt-package-and-authorizer-fixes-root-v1.py','adopt-package-and-authorizer-fixes-root-v2.py','package-authorizer-root-reader-v1-failure.json']:
 retain(E/name,R/'retained/root-reader-history'/name)
for name in ['windows-package-job-drain-independent-review/v2/REVIEW.md','windows-package-job-drain-independent-review/v2-integration-pin/REVIEW.md','authorizer-live-pr-head-independent-review/v1/REVIEW.md']:
 retain(E/name,R/'retained/source-peers'/name)
(R/'retained-inputs.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'retained_regular_inputs':len(records),'bytes':sum(r['bytes'] for r in records)}))
