from pathlib import Path,PurePosixPath
import ast,hashlib,json,stat,tarfile
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');P=E/'package-and-authorizer-canonical-adoption/v1';R=Path(__file__).resolve().parent
def pin(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode)
 return {'bytes':s.st_size,'full_mode':s.st_mode,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def load(p):return json.loads(p.read_bytes())
rows=[]
def check(name,okay):rows.append({'name':name,'pass':bool(okay)});assert okay,name
before=load(P/'before.json');after=load(P/'after.json');root=load(P/'root-review.json');closure=load(P/'closure.json');selected=root['selected']
check('source-counts',len(before['source'])==2375 and len(after['source'])==2378)
check('runtime40',len(before['runtime'])==40 and before['runtime']==after['runtime'])
for field in ['head','tree','index_sha256']:check('adoption-neutral-'+field,before[field]==after[field])
check('head-R',before['head']=='c930c86c83d478b3048d4cc80abd1346065e2e0d')
check('eight-selected',len(selected)==8)
new=set(after['source'])-set(before['source']);changed={n for n in before['source'] if before['source'][n]!=after['source'].get(n)}
check('only-selected-changes',new|changed==set(selected) and len(new)==3 and len(changed)==5)
for name,row in before['source'].items():
 if name not in selected:check('unselected:'+name,after['source'][name]==row)
for name,row in selected.items():check('selected-postimage:'+name,after['source'][name]==row)
def status(value):return {line.split(maxsplit=1)[1]:line.split(maxsplit=1)[0] for line in value.splitlines()}
oldstatus=status(before['status']);newstatus=status(after['status'])
check('status-unselected-equal',{n:v for n,v in oldstatus.items() if n not in selected}=={n:v for n,v in newstatus.items() if n not in selected})
for name in selected:check('status-selected:'+name,newstatus[name]==('??' if name in new else 'M'))
for report in root['peer_reviews']:check('different-peer-report:'+report['path'],pin(Path(report['path']))['sha256']==report['sha256'])
archives=[]
for item in root['archives']:
 base=Path(item['source']);check('source-pin:'+str(base),pin(base/'SOURCE.json')['sha256']==item['source_sha256']);check('proof-pin:'+str(base),pin(base/'proof.tar.gz')['sha256']==item['proof_sha256'])
 source=load(base/'SOURCE.json');entries=source['files'];expected={**entries,'SOURCE.json':pin(base/'SOURCE.json')}
 with tarfile.open(base/'proof.tar.gz') as archive:
  seen=set()
  for member in archive.getmembers():
   path=PurePosixPath(member.name);check('archive-safe:'+str(base)+':'+member.name,member.isfile() and not path.is_absolute() and '..' not in path.parts and member.name not in seen)
   seen.add(member.name);body=archive.extractfile(member).read();record=expected[member.name]
   check('archive-record:'+str(base)+':'+member.name,len(body)==record['bytes'] and hashlib.sha256(body).hexdigest()==record['sha256'] and (stat.S_IFREG|member.mode)==record['full_mode'])
  check('archive-members:'+str(base),seen==set(expected) and len(seen)==item['safe_regular_members'])
 archives.append({'path':str(base),'SOURCE':pin(base/'SOURCE.json'),'proof':pin(base/'proof.tar.gz')})
for dirname,key in [('windows-package-job-drain-preparation/v2','selection'),('authorizer-live-pr-head-correction/v1','paths')]:
 base=E/dirname
 for name,item in load(base/'ADOPTION.json')[key].items():
  if name=='scripts/python-test-inventory.v1.json':continue
  check('candidate-source-to-adoption:'+name,pin(base/item['afterimage'])==selected[name])
  if item['before'] is None:check('new-before-absent:'+name,name not in before['source'])
  else:check('existing-before-exact:'+name,before['source'][name]==item['before'])
catalog=load(P/'composed-catalog.json');oldcatalog=load(E/'windows-package-job-drain-preparation/v2/before/scripts/python-test-inventory.v1.json') if (E/'windows-package-job-drain-preparation/v2/before/scripts/python-test-inventory.v1.json').exists() else None
# The native candidate retains the unchanged2815 common ancestry separately.
native_catalog=load(E/'windows-package-job-drain-preparation/v2/project/scripts/python-test-inventory.v1.json');native=load(E/'windows-package-job-drain-preparation/v2/NEW-NODE-IDS.json');auth=(E/'authorizer-live-pr-head-correction/v1/NEW-TEST-IDS.txt').read_text().splitlines()
allids=catalog['common']['node_ids'];prior=[n for n in native_catalog['common']['node_ids'] if n not in native]
check('old-and-additive-counts',len(prior)==2815 and len(native)==30 and len(auth)==32 and len(allids)==2877 and len(set(allids))==2877)
check('all-old-IDs-retained',set(prior)<=set(allids))
check('exact62-additions',set(allids)-set(prior)==set(native+auth)==set(root['new_common_IDs']))
check('exact-original-two-POSIX',catalog['posix_only_node_ids']==native_catalog['posix_only_node_ids'] and len(catalog['posix_only_node_ids'])==2)
check('catalog-body-digest',catalog['common']['sha256']==hashlib.sha256(('\n'.join(allids)+'\n').encode()).hexdigest())
check('catalog-postimage',pin(P/'composed-catalog.json')==selected['scripts/python-test-inventory.v1.json'])
first=E/'adopt-package-and-authorizer-fixes-root-v1.py';second=E/'adopt-package-and-authorizer-fixes-root-v2.py'
check('reader-only-predicate-fix',first.read_text().replace("assert 'CLEAR_SCOPED' in p.read_text();checks+=1","assert p.read_text().startswith('# CLEAR:');checks+=1")==second.read_text())
check('exact-executed-v2',pin(second)==pin(P/'executed-adoption.py'))
failed=load(E/'package-authorizer-root-reader-v1-failure.json');check('initial-reader-failure-no-writes',failed['tool_exit']==1 and failed['canonical_writes']==0 and failed['original_script_preserved'])
tree=ast.parse(first.read_bytes());assert_lines=[n.lineno for n in ast.walk(tree) if isinstance(n,ast.Assert) and 'CLEAR_SCOPED' in ast.unparse(n.test)];mkdir_lines=[n.lineno for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='mkdir']
check('failed-assert-precedes-any-mkdir',min(assert_lines)<min(mkdir_lines))
check('closure-math',closure['selected']==8 and closure['logical_before']==2375 and closure['logical_after']==2378 and closure['added_common']==62 and closure['current_POSIX']==2879 and closure['runtime40_fullmodes_unchanged'] and closure['HEAD_tree_index_unchanged'])
result={'status':'PASS_FINITE_ADOPTION_DATA_ONLY_FOCUS_PENDING','checks':len(rows),'rows':rows,'adoption':str(P),'before_HEAD':before['head'],'after_HEAD':after['head'],'selected':selected,'catalog_before':2817,'catalog_after':2879,'archives':archives,'authorship':'Reviewer authored authorizerdelta; factual actual-data scope only, independent Gnome source-peer retained.','scope':'Root working-tree adoption facts only; no focused/full/native/CI/Windows/VM/model success inferred. Later coordinator and focus epochs remain separate.'}
(R/'adoption-data-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in {'rows','selected','archives'}}))
