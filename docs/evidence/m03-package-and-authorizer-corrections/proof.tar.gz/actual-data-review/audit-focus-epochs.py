from pathlib import Path, PurePosixPath
import ast, hashlib, json, stat, tarfile

E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
R=Path(__file__).resolve().parent
A=E/'package-and-authorizer-canonical-adoption/v1'
P=E/'package-loader-pin-canonical-adoption/v1'
F=E/'package-and-authorizer-canonical-focus/v1'
N=E/'windows-package-job-drain-preparation/v2-integration-pin'
retired='.github/gnome/requests/download-only.json'
rows=[]
def load(p):return json.loads(p.read_bytes())
def pin(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode)
 return {'bytes':s.st_size,'full_mode':s.st_mode,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def check(name,okay):
 rows.append({'name':name,'pass':bool(okay)})
 assert okay,name
def status(text):return {line.split(maxsplit=1)[1]:line.split(maxsplit=1)[0] for line in text.splitlines()}

prior=load(A/'after.json');before=load(P/'before.json');after=load(P/'after.json')
for key in ['source','runtime','head','tree','index_sha256','status']:check('phase-exact-prior-endpoint:'+key,before[key]==prior[key])
mapping=load(N/'ADOPTION.json');selection=mapping['selection'];selected=set(selection)|{retired,'scripts/python-test-inventory.v1.json'}
check('four-path-phase',len(selected)==4 and len(selection)==2)
check('source-counts',len(before['source'])==len(after['source'])==2378)
check('new-and-retired-names',set(after['source'])-set(before['source'])=={'scripts/tests/test_native_package_helper_pin.py'} and set(before['source'])-set(after['source'])=={retired})
for name,value in before['source'].items():
 if name not in selected:check('phase-unselected:'+name,after['source'][name]==value)
for name,value in selection.items():
 check('phase-preimage:'+name,before['source'].get(name)==value['before'])
 check('phase-postimage:'+name,after['source'][name]==value['after']==pin(N/value['afterimage']))
for key in ['runtime','head','tree','index_sha256']:check('phase-neutral:'+key,before[key]==after[key])
check('phase-runtime40',len(after['runtime'])==40)
check('retired-exact-original',pin(P/'retired-root-request.json')==before['source'][retired] and before['source'][retired]['sha256']=='9a88dac3505493f5f3da76db91e477d483591e2d6177419d86316447acbffffe')
check('retired-guard-only',before['guarded_retired_tracked_path'] is None and after['guarded_retired_tracked_path']==retired)
oldstatus=status(before['status']);newstatus=status(after['status'])
check('phase-status-unselected',{n:v for n,v in oldstatus.items() if n not in selected}=={n:v for n,v in newstatus.items() if n not in selected})
check('phase-status-selected',{n:newstatus[n] for n in selected}=={retired:'D','scripts/native_package_ci.py':'M','scripts/python-test-inventory.v1.json':'M','scripts/tests/test_native_package_helper_pin.py':'??'})
catalog=load(P/'composed-catalog.json');previous=load(A/'composed-catalog.json')
ids=catalog['common']['node_ids'];oldids=previous['common']['node_ids'];extra=mapping['new_node_ids']
check('exact-one-new-catalog-ID',len(extra)==1 and len(ids)==len(set(ids))==2878 and set(ids)-set(oldids)==set(extra) and set(oldids)<=set(ids))
check('old-POSIX-exact',catalog['posix_only_node_ids']==previous['posix_only_node_ids'] and len(catalog['posix_only_node_ids'])==2)
check('catalog-hash-and-postimage',catalog['common']['sha256']==hashlib.sha256(('\n'.join(ids)+'\n').encode()).hexdigest() and pin(P/'composed-catalog.json')==after['source']['scripts/python-test-inventory.v1.json'])
root=load(P/'root-review.json');check('different-pin-peer',pin(Path(root['peer']['path']))['sha256']==root['peer']['sha256']=='686951ea61f88e06d264ba52b474e6eab0a3c0602de876b49a45c60a19164144')
check('pin-candidate-SOURCE',pin(N/'SOURCE.json')['sha256']=='62286b109344c0b5a6f236594e7967c2260cf997ea866020ebfd23e58f6d4b0f')
check('pin-candidate-proof',pin(N/'proof.tar.gz')['sha256']=='0c206aafb15e0ad6a8432568f1888bc37d1e1466eebf19e5c734344146c6eaf1')
expected={**load(N/'SOURCE.json')['files'],'SOURCE.json':pin(N/'SOURCE.json')}
with tarfile.open(N/'proof.tar.gz') as archive:
 seen=set()
 for member in archive.getmembers():
  path=PurePosixPath(member.name);check('pin-archive-safe:'+member.name,member.isfile() and not path.is_absolute() and '..' not in path.parts and member.name not in seen)
  seen.add(member.name);body=archive.extractfile(member).read();record=expected[member.name]
  check('pin-archive-record:'+member.name,len(body)==record['bytes'] and hashlib.sha256(body).hexdigest()==record['sha256'] and stat.S_IFREG|member.mode==record['full_mode'])
 check('pin-archive-members',seen==set(expected) and len(seen)==106)

fb=load(F/'before.json');fa=load(F/'after.json');commands=load(F/'commands.json');fc=load(F/'closure.json')
check('focus-exact-adoption-endpoint',fb==after)
check('focus-whole-endpoints-equal',fb==fa)
check('focus2378-runtime40',len(fb['source'])==2378 and len(fb['runtime'])==40)
names=['ruff','format','mypy-linux','mypy-win32-fixtures','prettier','focused-python','collection','portability','integrity']
check('actual-nine-command-order',[c['name'] for c in commands]==names)
for i,c in enumerate(commands):
 check('owned-command-closure:'+c['name'],c['exit_code']==(0 if i<8 else 1) and c['reaped'] and c['group']=='ABSENT' and not c['signals'] and not c['timeout'] and c['cwd']=='/Users/tanishkalwad/jobapplyv2' and c['pid']==c['pgid'] and c['seconds']>=0)
 check('actual-command-order:'+c['name'],c['start_utc']<=c['end_utc'] and (i==0 or commands[i-1]['end_utc']<=c['start_utc']))
check('focus-failure-not-relabelled',fc['commands']==9 and fc['all_ten_closed_zero'] is False and fc['all_source_runtime_fullmodes_status_HEAD_tree_index_equal'])
check('actual-focused-343','343 passed in 1.57s' in (F/'focused-python.log').read_text())
actual=[s.strip() for s in (F/'collection.log').read_text().splitlines() if s.startswith(('scripts/tests/','services/orchestrator/tests/')) and '::' in s]
check('actual2880-exact-catalog',len(actual)==len(set(actual))==2880 and set(actual)==set(ids+catalog['posix_only_node_ids']))
check('mypy16-and5','Success: no issues found in 16 source files' in (F/'mypy-linux.log').read_text() and 'Success: no issues found in 5 source files' in (F/'mypy-win32-fixtures.log').read_text())
integrity=(F/'integrity.log').read_text();check('actual-integrity-specific-failure',"tracked text source cannot be read: "+retired in integrity and 'verification exit code: 1' in integrity)
driver=(F/'executed-driver.py').read_text();tree=ast.parse(driver)
check('driver-deleted-exact-guard',"assert [os.fsdecode(n) for n in deleted if n]==[retired]" in driver and "if n and os.fsdecode(n)!=retired" in driver and "9a88dac3505493f5f3da76db91e477d483591e2d6177419d86316447acbffffe" in driver)
check('no-unexecuted-diff-result',not (F/'diff-check.log').exists())
check('driver-sources-tests-scoped',"'scripts/native_package_ci.py'" in driver and "'scripts/tests/test_native_package_helper_pin.py'" in driver and "'test_ci_native_package.py'" in driver)
result={'status':'PASS_FINITE_RECORDED_FOCUS_FAILURE_SUCCESSOR_PENDING','checks':len(rows),'rows':rows,'phase':str(P),'focus':str(F),'command_results':[{k:c[k] for k in ['name','exit_code','seconds','pid','pgid','reaped','group','signals','timeout']} for c in commands],'catalog_count':2880,'common':2878,'POSIX_only':2,'authorship':'Reviewer authored the authorizer delta; independent Gnome source reviews are retained. This audit covers new actual adoption/command and endpoint data only.','scope':'Eight successful code/collection checks plus one genuine integrity failure; no all-ten success, aggregate/full/currentCI/native/Windows/package credit. Successor staged-deletion and integrity/diff remain pending.'}
(R/'focus-epochs-data-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in {'rows','command_results'}}))
