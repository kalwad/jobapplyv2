from pathlib import Path
import ast,hashlib,json,stat
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');R=Path(__file__).resolve().parent
P=E/'package-authorizer-post-stage-checks/v1';F=E/'package-and-authorizer-canonical-focus/v1';retired='.github/gnome/requests/download-only.json'
def load(p):return json.loads(p.read_bytes())
rows=[]
def check(name,okay):rows.append({'name':name,'pass':bool(okay)});assert okay,name
before=load(P/'before.json');staged=load(P/'after-stage.json');after=load(P/'after.json');prior=load(F/'after.json');commands=load(P/'commands.json');closure=load(P/'closure.json')
check('successor-exact-prior-endpoint',all(before[k]==prior[k] for k in before))
check('source2378-runtime40',len(before['source'])==2378 and len(before['runtime'])==40)
for key in ['source','runtime','head','tree']:check('staging-same-entire-map:'+key,before[key]==staged[key])
check('intentional-index-transition',before['index_sha256']=='bf4b1e0626447bb853ddfb1660f51ef3e0dd73215749b4e06bfe904b9c366cb0' and staged['index_sha256']=='f3f72ad7b20a02c8b7acaa4d6b742bb2ac5c1664e52648af4fde2a07853b4086' and before['index_sha256']!=staged['index_sha256'])
check('status-only-deletion-column-transition',before['status'].splitlines()[0]=='D '+retired and staged['status'].splitlines()[0]=='D  '+retired and before['status'].splitlines()[1:]==staged['status'].splitlines()[1:])
check('post-stage-entire-endpoint-equal',after==staged)
check('three-actual-owned-command-order',[c['name'] for c in commands]==['stage-exact-withdrawal','integrity','diff-check-combined'])
check('only-exact-path-staged',commands[0]['argv']==['git','add','--',retired])
check('successor-integrity-original-argv',commands[1]['argv']==load(F/'commands.json')[-1]['argv'])
check('combined-staged-unstaged-diff-argv',commands[2]['argv']==['git','diff','--check','HEAD'])
for i,c in enumerate(commands):
 check('successor-child:'+c['name'],c['exit_code']==0 and c['reaped'] and c['group']=='ABSENT' and not c['signals'] and not c['timeout'] and c['pid']==c['pgid'] and c['seconds']>=0)
 check('successor-order:'+c['name'],c['start_utc']<=c['end_utc'] and (i==0 or commands[i-1]['end_utc']<=c['start_utc']))
check('focus-closes-before-stage',load(F/'closure.json')['utc']<commands[0]['start_utc'])
check('successor-integrity-genuine-PASS','integrity      ACTIVE               PASS' in (P/'integrity.log').read_text() and 'verification exit code: 0' in (P/'integrity.log').read_text())
check('stage-and-diff-no-errors',(P/'stage-exact-withdrawal.log').read_bytes()==b'' and (P/'diff-check-combined.log').read_bytes()==b'')
driver=(P/'executed-driver.py').read_text();ast.parse(driver)
check('exact-prior-empty-index-assertion',"assert subprocess.check_output(['git','diff','--cached','--name-status','-z'],cwd=R,timeout=30)==b''" in driver)
check('exact-post-one-D-index-assertion',"assert subprocess.check_output(['git','diff','--cached','--name-status','-z'],cwd=R,timeout=30)==b'D\\0'+retired.encode()+b'\\0'" in driver)
check('exact-retired-source-guard',"9a88dac3505493f5f3da76db91e477d483591e2d6177419d86316447acbffffe" in driver and "assert deleted==([] if staged else [retired])" in driver)
check('successor-no-validator-change',before['source']['scripts/verify.py']==staged['source']['scripts/verify.py']==prior['source']['scripts/verify.py'])
check('closure-honest-scope',closure['prior_focus_integrity_FAILURE_preserved'] and closure['prior_successful_checks']==8 and closure['successor_checks']==2 and closure['post_stage_checks_source_runtime_HEAD_tree_index_status_equal'] and closure['staged_diff_exactly_one_D']==retired and 'No all-ten one-epoch claim' in closure['scope'])
inputs={}
for d in [E/'package-and-authorizer-canonical-adoption/v1',E/'package-loader-pin-canonical-adoption/v1',F,P]:
 for p in sorted(d.iterdir()):
  if p.is_dir():continue
  s=p.lstat();check('regular-input:'+str(p),stat.S_ISREG(s.st_mode));inputs[str(p)]={'bytes':s.st_size,'full_mode':s.st_mode,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
result={'status':'CLEAR_FINITE_ACTUAL_ADOPTION_AND_SEPARATE_FOCUS_EPOCHS','checks':len(rows),'rows':rows,'input_bindings':inputs,'before_index':before['index_sha256'],'after_index':staged['index_sha256'],'source_count':2378,'runtime_count':40,'successful_code_checks':8,'successor_checks':2,'recorded_failed_integrity':True,'owner_records':12,'authorship':'Reviewer authored authorizer delta; this is factual actual-data review. Independent Gnome source peer remains required and retained.','scope':'Original focus8PASS+integrityFAIL is preserved. Exact one-entry staged deletion intentionally changes index/status only; identical code/runtime bodies then pass integrity and combined diff. No all-ten-one-epoch, aggregate/currentCI/native/Windows package, GNOME export or milestone success.'}
(R/'successor-data-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in {'rows','input_bindings'}}))
