from pathlib import Path
from types import SimpleNamespace
import importlib.util,json
R=Path(__file__).resolve().parent;HELPER=R/'subject/project/scripts/_native_package_process.py';rows=[]
for late_time in [0.1,14.999,15.0,16.0]:
 spec=importlib.util.spec_from_file_location('own_job_probe',HELPER);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 clock=SimpleNamespace(value=0.0);active_calls=[];closed=[];forced=[];settle_deadlines=[]
 module.time=SimpleNamespace(monotonic=lambda:clock.value,sleep=lambda seconds:setattr(clock,'value',clock.value+seconds))
 exact_settle=module._WindowsJob.settle
 class Capture:
  def __init__(self,out,err):
   Path(out).write_bytes(b'');Path(err).write_bytes(b'');self.writers=[1,2];self.overflow=SimpleNamespace(is_set=lambda:False)
  def start(self):pass
  def close_parent_writers(self):self.writers=[]
  def finish(self):return {'captured_bytes':0,'discarded_bytes':0,'overflow':False,'errors':[],'readers_closed':True}
 class Job:
  def __init__(self,*args):
   self.process=801;self.job=802;self.assigned=True;self.inherited=[];self.pid=801;self.tid=803;self.k=SimpleNamespace(TerminateJobObject=self.terminate,TerminateProcess=self.terminate)
  def poll(self):return 0
  def active(self):
   active_calls.append(clock.value)
   if len(active_calls)==1:return 1
   if len(active_calls)==2:clock.value=late_time
   return 0
  def terminate(self,handle,code):forced.append((handle,code));return 1
  def _ok(self,value):assert value
  def settle(self,deadline,*,allow_natural_drain=True):
   settle_deadlines.append({'deadline':deadline,'allow_natural_drain':allow_natural_drain,'entered':clock.value});return exact_settle(self,deadline,allow_natural_drain=allow_natural_drain)
  def close(self):closed.append(self.job);self.job=0;self.process=None
 module._Capture=Capture;module._WindowsJob=Job;module._runtime_platform=lambda:'win32';stem=R/'qa'/('boundary-'+str(late_time));caught=None
 try:result=module.run([str(R/'NEVER_EXECUTED')],cwd=R,env={},stem=stem,seconds=100.0,deadlines={'work_deadline':100.0,'cleanup_deadline':115.0})
 except (TimeoutError,RuntimeError) as error:caught=type(error).__name__;result=None
 record=json.loads(stem.with_suffix('.result.json').read_text()) if False else json.loads(Path(str(stem)+'.result.json').read_text());rows.append({'clock_after':clock.value,'original_work_deadline':100.0,'actual_supplied_settle_deadlines':settle_deadlines,'run_returncode':result.returncode if result else None,'caught':caught,'deadline_met':record['containment'].get('job_cleanup_deadline_met'),'retained_closed':record['containment'].get('all_job_members_closed'),'record_success':record['success'],'force_calls':forced,'closed_handles':closed,'record_seconds_elapsed':record['seconds_elapsed'],'scope':'Exact source run/settle; fake process/Job/capture/clock only; no WinAPI/child/native actor'})
(R/'boundary-control-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
for row in rows:
 assert row['record_success'] is (row['clock_after']<15)
 assert row['retained_closed'] is True
 assert row['deadline_met'] is (row['clock_after']<15)
 assert row['actual_supplied_settle_deadlines'][0]['deadline']==row['actual_supplied_settle_deadlines'][1]['deadline']==15
 assert not row['force_calls']
for value in [True,False]:assert module._containment({'job_cleanup_deadline_met':value})['job_cleanup_deadline_met'] is value
assert module._containment({})=={}
for value in [0,1,None,'true',[],{}]:
 try:module._containment({'job_cleanup_deadline_met':value})
 except ValueError:pass
 else:raise AssertionError(('invalidBoolean',value))
for now,expected in [(14.999,True),(15,False),(16,False)]:
 clock.value=now;job=Job();job.process=None
 receipt=exact_settle(job,15)
 assert receipt['job_cleanup_deadline_met'] is expected and receipt['no_process_created'] is True
print('four exact-run boundary pairs, 9 receipt-type controls, 3 no-process fences PASS')
