from pathlib import Path, PurePosixPath
import ast, copy, hashlib, json, stat, tarfile
R=Path(__file__).parent;E=R.parent.parent;S=E/'windows-package-job-drain-preparation/v2';V=E/'windows-package-job-drain-preparation/v1';C=R/'subject';checks=[]
def check(label,value):
 if not value:raise AssertionError(label)
 checks.append(label)
def load(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def meta(p):
 s=p.lstat();check('regular '+str(p),stat.S_ISREG(s.st_mode));b=p.read_bytes();return {'bytes':len(b),'sha256':sha(b),'full_mode':s.st_mode}
def subset(row):return {k:row[k] for k in ['bytes','sha256','full_mode']}
check('exact supplied SOURCE',sha((S/'SOURCE.json').read_bytes())=='c38ee31b9d401cc9db4057b2d37bce7790d9be753e129afb64e22386f6ad5793')
check('exact supplied HANDOFF',sha((S/'HANDOFF.json').read_bytes())=='354676a7912b3201309e8c779899ab1c068caf74460ba707c8110a52b97ef958')
check('exact supplied manifest',sha((S/'MANIFEST.json').read_bytes())=='6143f566a369035f47d95f974f9563fe96588a902af21c38904d13a61138cdc3')
files=load(S/'SOURCE.json')['files']
for n,row in files.items():
 check('subject '+n,meta(S/n)==subset(row));check('independent copy '+n,meta(C/n)==subset(row))
man=load(S/'MANIFEST.json');check('SOURCE metadata',meta(S/'SOURCE.json')==subset(man['SOURCE']));check('proof metadata',meta(S/'proof.tar.gz')==subset(man['proof']))
with tarfile.open(S/'proof.tar.gz','r:gz') as t:
 members=t.getmembers();names=[m.name for m in members];check('archive exact unique safe set',len(names)==len(set(names))==man['safe_regular_members']==135 and set(names)==set(files)|{'SOURCE.json'})
 for m in members:
  p=PurePosixPath(m.name);check('safe archive '+m.name,m.isfile() and not p.is_absolute() and '..' not in p.parts and m.name==p.as_posix());b=t.extractfile(m).read();check('archive body/mode '+m.name,b==(S/m.name).read_bytes() and m.mode==stat.S_IMODE((S/m.name).stat().st_mode))
for n,row in load(V/'SOURCE.json')['files'].items():check('immutable parent '+n,meta(V/n)==subset(row))
ad=load(S/'ADOPTION.json');check('exact4paths',set(ad['selection'])=={'scripts/_native_package_process.py','scripts/tests/test_native_package_pending_owner.py','scripts/tests/test_native_package_job_drain.py','scripts/python-test-inventory.v1.json'})
for n,row in ad['selection'].items():
 check('guarded after '+n,meta(S/row['afterimage'])==row['after'])
 if row['before'] is not None:check('guarded before '+n,meta(S/'before'/n)==row['before'])
 else:check('new path absent before',not (S/'before'/n).exists())
old=(S/'before/scripts/_native_package_process.py').read_text();new=(S/'project/scripts/_native_package_process.py').read_text();a=ast.parse(old);b=ast.parse(new)
def member(tree,name):return next(n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==name)
for n in ['Containment','_containment','run']:
 newnode=member(b,n);b.body[b.body.index(newnode)]=copy.deepcopy(member(a,n))
oldcls=member(a,'_WindowsJob');newcls=member(b,'_WindowsJob');n=member(newcls,'settle');newcls.body[newcls.body.index(n)]=copy.deepcopy(member(oldcls,'settle'));check('all AST outside4 scoped definitions exact',ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False))
current=ast.parse(new);before_run=member(a,'run');after_run=member(current,'run')
def linux(run):return next(n.body for n in ast.walk(run) if isinstance(n,ast.If) and isinstance(n.test,ast.Compare) and any(isinstance(c,ast.Constant) and c.value=='linux' for c in n.test.comparators))
check('original Linux body exact',ast.dump(ast.Module(body=linux(before_run),type_ignores=[]),include_attributes=False)==ast.dump(ast.Module(body=linux(after_run),type_ignores=[]),include_attributes=False))
def conjuncts(run):return next(n.value.values for n in ast.walk(run) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ok' for t in n.targets))
check('original success conjunctions preserved',[ast.dump(x) for x in conjuncts(before_run)]==[ast.dump(x) for x in conjuncts(after_run) if 'job_cleanup_deadline_met' not in ast.unparse(x)])
pin=sha(new.encode());oldpin=sha(old.encode());check('old7 tests exact except pin',(S/'project/scripts/tests/test_native_package_pending_owner.py').read_text().replace(pin,oldpin)==(S/'before/scripts/tests/test_native_package_pending_owner.py').read_text())
oldtest=(V/'project/scripts/tests/test_native_package_job_drain.py').read_text();newtest=(S/'project/scripts/tests/test_native_package_job_drain.py').read_text()
for n in ast.parse(oldtest).body:
 if isinstance(n,(ast.FunctionDef,ast.ClassDef)):check('v1 test/helper exact AST '+n.name,ast.dump(n,include_attributes=False)==ast.dump(member(ast.parse(newtest),n.name),include_attributes=False))
check('v1 test prefix bytes preserved except added import',newtest.split('@pytest.mark.parametrize("delay"')[0].replace('from contextlib import suppress\n','').rstrip()==oldtest.rstrip())
check('exact old helper negative', (S/'control-v1/scripts/_native_package_process.py').read_bytes()==(V/'project/scripts/_native_package_process.py').read_bytes())
check('exact final test negative', (S/'control-v1/scripts/tests/test_native_package_job_drain.py').read_bytes()==newtest.encode())
base=load(S/'before/scripts/python-test-inventory.v1.json');final=load(S/'project/scripts/python-test-inventory.v1.json');ids=load(S/'NEW-NODE-IDS.json');check('30 unique additions',len(ids)==len(set(ids))==30)
check('all original IDs retained and30new',final['common']['node_ids']==sorted(base['common']['node_ids']+ids));check('original2POSIX',final['posix_only_node_ids']==base['posix_only_node_ids'] and len(final['posix_only_node_ids'])==2);check('count2845+2projected',final['common']['count']==len(final['common']['node_ids'])==2845);check('inventory digest',final['common']['sha256']==sha(('\n'.join(final['common']['node_ids'])+'\n').encode()))
expected_fail={'late-query-red','exact-v1-late-red','strict-first'};phases={};runtime=None
for q in sorted((S/'qa').iterdir()):
 if not(q/'receipt.json').is_file():continue
 r=load(q/'receipt.json');before=load(q/'before.json');after=load(q/'after.json');check(q.name+'neutral',r['source_equal'] and before==after);check(q.name+'closed',r['reaped'] and r['group']=='ABSENT' and r['signals']==[]);check(q.name+'expected code',r['exit_code']==int(q.name in expected_fail));phases[q.name]=r
 for n,row in r['streams'].items():check(q.name+'raw '+n,meta(q/n)==row)
 check(q.name+'source4',before['canonical_selected']=={n:meta(S/'before'/n) for n in ['pyproject.toml','scripts/_native_package_process.py','scripts/tests/test_native_package_pending_owner.py','scripts/python-test-inventory.v1.json']});check(q.name+'runtime40',len(before['runtime'])==40)
 if runtime is None:runtime=before['runtime']
 check(q.name+'same runtime40',runtime==before['runtime'])
check('14 retained author owners',len(phases)==14)
for q in ['final-actual','final-list','strict-final','format-final','mypy-host-final','mypy-win32-fixtures-final','finite-audit']:
 proposal=load(S/'qa'/q/'before.json')['proposal']
 for n,row in proposal.items():
  allowed=[meta(S/'project'/n)]
  if n=='scripts/python-test-inventory.v1.json':allowed.append(meta(V/'project'/n))
  check(q+'exact execution input '+n,row in allowed)
check('host Mypy exact3 scope','Success: no issues found in 3 source files' in (S/'qa/mypy-host-final/stdout').read_text());check('Win32 fixtures exact2 scope','Success: no issues found in 2 source files' in (S/'qa/mypy-win32-fixtures-final/stdout').read_text())
def nodeids(p):return sorted(x.strip() for x in p.read_text().splitlines() if x.startswith('scripts/tests/') and '::' in x)
listed=nodeids(S/'qa/final-list/stdout');check('37 exact catalog IDs',len(listed)==len(set(listed))==37 and set(ids)<=set(listed) and set(listed)<=set(final['common']['node_ids']));check('37 actual PASS','37 passed' in (S/'qa/final-actual/stdout').read_text());check('own37 actualPASS','37 passed' in (R/'qa/fresh37/stdout').read_text());check('own37 collection exact',nodeids(R/'qa/fresh37-collection/stdout')==listed)
for name,row in load(S/'RETAINED-RESULTS.json').items():
 p=S/name;check('retained case '+name,len(p.read_bytes())==row['bytes'] and sha(p.read_bytes())==row['sha256']);r=load(p)
 if name.startswith('retained-results/final-actual/') and name.endswith('-slow.result.json'):check('late/timely facts '+name,r['success']==r['containment']['job_cleanup_deadline_met']==(r['seconds_elapsed']<15) and r['containment']['all_job_members_closed'] is True and r['containment']['terminated_job'] is False)
 if name.startswith('retained-results/exact-v1-late-red/'):check('original exact v1 false admission',r['success'] is True and r['seconds_elapsed']>=16 and r['containment']['terminated_job'] is False)
for q in ['fresh37','fresh37-collection','original-counterexample','boundary-controls']:
 r=load(R/'qa'/q/'receipt.json');check('own '+q+'closed0/neutral',r['exit_code']==0 and r['reaped'] and r['group']=='ABSENT' and not r['signals'] and not r['timeout'] and r['source_endpoints_equal'])
check('own original probe corrected',load(R/'probe-results.json')[1]['record_success'] is False)
(R/'DATA.json').write_text(json.dumps({'status':'CLEAR_SCOPED_V2_SOURCE_AND_INERT_DATA','checks':len(checks),'labels':checks,'author_owners':len(phases),'own_owners':4,'subject_indexed':len(files),'archive_members':135,'actual_fresh_cases':37,'projected_only_total':2847},indent=2)+'\n');print(json.dumps({'checks':len(checks),'status':'CLEAR','author_owners':len(phases),'own_owners':4}))
