from pathlib import Path
from types import SimpleNamespace
import importlib.util,json
R=Path(__file__).resolve().parent;HELPER=R/'subject/project/scripts/_native_package_process.py';rows=[]
for late_time in [0.1,16.0]:
 spec=importlib.util.spec_from_file_location('own_job_probe',HELPER);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 clock=SimpleNamespace(value=0.0);active_calls=[];closed=[];forced=[];settle_deadlines=[]
 module.time=SimpleNamespace(monotonic=lambda:clock.value,sleep=lambda seconds:setattr(clock,'value',clock.value+seconds))
 exact_settle=module._WindowsJob.settle
 class Capture:
  def __init__(self,out,err):
   Path(out).write_bytes(b'');Path(err).write_bytes(b'');self.writers=[1,2];self.overflow=SimpleNamespace(is_set=lambda:False)
  def start(self):pass
  def close_parent_writers(self):self.writers=[]
  def finish(self):return {'captured_bytes':0,'discarded_bytes':0,'overflow':False,'errors':[],'readers_closed':True}
 class Job:
  def __init__(self,*args):
   self.process=801;self.job=802;self.assigned=True;self.inherited=[];self.pid=801;self.tid=803;self.k=SimpleNamespace(TerminateJobObject=self.terminate,TerminateProcess=self.terminate)
  def poll(self):return 0
  def active(self):
   active_calls.append(clock.value)
   if len(active_calls)==1:return 1
   if len(active_calls)==2:clock.value=late_time
   return 0
  def terminate(self,handle,code):forced.append((handle,code));return 1
  def _ok(self,value):assert value
  def settle(self,deadline,*,allow_natural_drain=True):
   settle_deadlines.append({'deadline':deadline,'allow_natural_drain':allow_natural_drain,'entered':clock.value});return exact_settle(self,deadline,allow_natural_drain=allow_natural_drain)
  def close(self):closed.append(self.job);self.job=0;self.process=None
 module._Capture=Capture;module._WindowsJob=Job;module._runtime_platform=lambda:'win32';stem=R/'qa'/('probe-'+str(late_time));result=module.run([str(R/'NEVER_EXECUTED')],cwd=R,env={},stem=stem,seconds=100.0,deadlines={'work_deadline':100.0,'cleanup_deadline':115.0});record=json.loads(stem.with_suffix('.result.json').read_text()) if False else json.loads(Path(str(stem)+'.result.json').read_text());rows.append({'clock_after':clock.value,'original_work_deadline':100.0,'actual_supplied_settle_deadlines':settle_deadlines,'run_returncode':result.returncode,'record_success':record['success'],'force_calls':forced,'closed_handles':closed,'record_seconds_elapsed':record['seconds_elapsed'],'scope':'Exact source run/settle; fake process/Job/capture/clock only; no WinAPI/child/native actor'})
(R/'probe-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
assert rows[0]['record_success'] is True
assert rows[1]['record_success'] is False,'Natural drain query returned after original supplied15s settle bound yet run grants success'
