from pathlib import Path
from copy import deepcopy
import importlib.util,json,sys
R=Path(__file__).parent;P=R/'subject/after';T=P/'scripts/tests';sys.path.insert(0,str(T));rows=[]
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
for family in ['ubuntu_gnome','windows11']:
 tests=load('own_'+family,T/('test_'+family+'_request.py'))
 for case in ['source-edge','current-request-edge','unrelated-edge','ancestor-but-not-request-edge','stale-parent','uncommitted-request','old-source-new-decoder','workflow-source-drift','wrong-pr-base-repo','wrong-run-head','wrong-artifact-owner','wrong-digest','early-artifact','expired-artifact','source-repo-drift','two-pr-edges']:
  folder=R/'control-inputs'/family/case;folder.mkdir(parents=True);module=tests.module.__wrapped__();h=tests.harness.__wrapped__(folder,module);h['run']['pull_requests'][0]['head']['sha']=h['event']['pull_request']['head']['sha'];git=h['git'];expect=True;skip=False
  if case=='source-edge':h['run']['pull_requests'][0]['head']['sha']=h['request']['expected_source_sha']
  elif case=='current-request-edge':pass
  else:
   expect=False
   if case in {'unrelated-edge','ancestor-but-not-request-edge'}:h['run']['pull_requests'][0]['head']['sha']=('f' if case=='unrelated-edge' else 'b')*40
   elif case=='stale-parent':
    skip=True
    def git(root,*args):return b'a'*40+b' '+b'f'*40 if args[0]=='rev-list' else h['git'](root,*args)
   elif case=='uncommitted-request':
    def git(root,*args):return b'{}' if args[0]=='show' and args[1].endswith(module.REQUESTS[module.DOWNLOAD]) else h['git'](root,*args)
   elif case=='old-source-new-decoder':(h['context'].control/module.PROTECTED[2]).write_bytes((P/'scripts'/('linux_gnome' if family=='ubuntu_gnome' else 'windows11')/(family+'_request.py')).read_bytes())
   elif case=='workflow-source-drift':(h['context'].workflow_source/module.PROTECTED[2]).write_bytes(b'changed workflow decoder')
   elif case=='wrong-pr-base-repo':h['run']['pull_requests'][0]['base']['repo']['id']+=1
   elif case=='wrong-run-head':h['run']['head_sha']='f'*40
   elif case=='wrong-artifact-owner':h['metadata']['workflow_run']['head_sha']='f'*40
   elif case=='wrong-digest':h['metadata']['digest']='sha256:'+'0'*64
   elif case=='early-artifact':h['metadata']['created_at']='2026-10-28T09:59:59Z'
   elif case=='expired-artifact':h['metadata']['expired']=True
   elif case=='source-repo-drift':h['run']['head_repository']={**h['run']['head_repository'],'id':0}
   elif case=='two-pr-edges':h['run']['pull_requests'].append(deepcopy(h['run']['pull_requests'][0]))
  caught=None;result=None
  try:result=module.decode(h['context'],h['event'],git,h['fetch'])
  except ValueError as e:caught=str(e)
  accepted=result is not None and result.get('enabled')=='true';assert accepted==expect,(family,case,result,caught)
  if skip:assert result['status']=='SKIP_STALE_ROOT_REQUEST_PARENT'
  if case in ['stale-parent','uncommitted-request','old-source-new-decoder','workflow-source-drift']:assert not any(isinstance(x,str) for x in h['calls'])
  if accepted:assert result['proof']['artifact_metadata']['head_sha']==h['request']['expected_source_sha'] and result['proof']['authorization_head_sha']==h['event']['pull_request']['head']['sha'] and result['proof']['install_vm_product_actors']==0
  rows.append({'family':family,'case':case,'accepted':accepted,'error':caught,'status':result.get('status') if result else None,'metadata_fetches':sum(isinstance(x,str) for x in h['calls'])})
(R/'control-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'pure_controls':len(rows),'all_pass':True,'network_or_Git_calls':0}))
