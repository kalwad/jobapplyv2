from pathlib import Path,PurePosixPath
import ast,hashlib,json,stat,tarfile
R=Path(__file__).parent;E=R.parent.parent;S=E/'authorizer-live-pr-head-correction/v1';C=R/'subject';checks=[]
def check(n,v):
 if not v:raise AssertionError(n)
 checks.append(n)
def load(p):return json.loads(p.read_text())
def digest(b):return hashlib.sha256(b).hexdigest()
def meta(p):
 s=p.lstat();check('regular '+str(p),stat.S_ISREG(s.st_mode));b=p.read_bytes();return {'bytes':len(b),'sha256':digest(b),'full_mode':s.st_mode}
check('suppliedSOURCE',digest((S/'SOURCE.json').read_bytes())=='ac4a86cba1c29ea604d31a09f323c75c7d7865ed61a55db6ecb19c47a000fd67');check('suppliedHANDOFF',digest((S/'HANDOFF.md').read_bytes())=='d064ff0d7163f36249a7506e5e158acd26946c72f48468373cb9a7a63efd4253');check('suppliedMANIFEST',digest((S/'MANIFEST.json').read_bytes())=='bfc5902ef40eab5253513683130ed871a3ca665131c27af36b3bbef5279ec78f')
source=load(S/'SOURCE.json');files=source['files'];manifest=load(S/'MANIFEST.json')
for n,row in files.items():check('subjectbytes/mode '+n,meta(S/n)==row);check('copybytes/mode '+n,meta(C/n)==row)
for key,n in [('SOURCE','SOURCE.json'),('HANDOFF','HANDOFF.md'),('proof','proof.tar.gz')]:check('manifest '+key,meta(S/n)==manifest[key])
with tarfile.open(S/'proof.tar.gz','r:gz') as t:
 ms=t.getmembers();names=[m.name for m in ms];check('safe302uniquemembers',len(names)==len(set(names))==302==manifest['safe_regular_members'] and set(names)==set(files)|{'SOURCE.json'})
 for m in ms:
  p=PurePosixPath(m.name);check('safe '+m.name,m.isfile() and not p.is_absolute() and '..' not in p.parts and m.name==p.as_posix());check('archivebytes/mode '+m.name,t.extractfile(m).read()==(S/m.name).read_bytes() and m.mode==stat.S_IMODE((S/m.name).stat().st_mode))
pre=load(S/'PREIMAGES.json');changed={'scripts/linux_gnome/ubuntu_gnome_request.py','scripts/windows11/windows11_request.py'}
for n,row in pre.items():
 check('preimage '+n,meta(S/'before'/n)==row)
 if n not in changed:check('unchanged dependency '+n,meta(S/'after'/n)==row)
for n in changed:
 a=(S/'before'/n).read_text();b=(S/'after'/n).read_text();prefix='''def artifact_metadata(
    request: dict[str, Any], fetch: FETCH, *, authorization_head: str | None = None
) -> dict[str, Any]:
    # Only decode supplies a head after all current authorization checks pass.
    # Standalone metadata callers retain the original source-only requirement.
    allowed_pr_heads = {request["expected_source_sha"]}
    if authorization_head is not None:
        allowed_pr_heads.add(hexadecimal(authorization_head, 40))
'''
 inverse=b.replace(prefix,'def artifact_metadata(request: dict[str, Any], fetch: FETCH) -> dict[str, Any]:\n').replace('prs[0]["head"]["sha"] not in allowed_pr_heads','prs[0]["head"]["sha"] != request["expected_source_sha"]').replace('artifact_metadata(request, fetch, authorization_head=head)','artifact_metadata(request, fetch)');check('exact inverse bytes all source '+n,inverse==a)
 old=ast.parse(a);new=ast.parse(b)
 def named(t):return {x.name:x for x in t.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
 x=named(old);y=named(new);check('same defs '+n,set(x)==set(y))
 for name in x:
  if name not in {'artifact_metadata','decode'}:check('unmodified definition '+n+':'+name,ast.dump(x[name])==ast.dump(y[name]))
 decode=y['decode'];calls=[x for x in ast.walk(decode) if isinstance(x,ast.Call) and isinstance(x.func,ast.Name) and x.func.id=='artifact_metadata'];check('only contextual call '+n,len(calls)==1 and len(calls[0].keywords)==1 and calls[0].keywords[0].arg=='authorization_head' and isinstance(calls[0].keywords[0].value,ast.Name) and calls[0].keywords[0].value.id=='head')
 check('protected guards before contextual call '+n,next(x.lineno for x in ast.walk(decode) if isinstance(x,ast.Call) and isinstance(x.func,ast.Name) and x.func.id=='protected_sources')<calls[0].lineno)
for name in ['test_ubuntu_gnome_request.py','test_windows11_request.py']:check('whole original tests '+name,(S/'before/scripts/tests'/name).read_bytes()==(S/'after/scripts/tests'/name).read_bytes())
for name in ['test_ubuntu_gnome_request_live_head.py','test_windows11_request_live_head.py']:
 def bodies(p):return {x.name:ast.dump(ast.Module(body=x.body,type_ignores=[])) for x in ast.parse(p.read_text()).body if isinstance(x,ast.FunctionDef)}
 check('testsfirst assertions exact '+name,bodies(S/'before/scripts/tests'/name)==bodies(S/'after/scripts/tests'/name))
ad=load(S/'ADOPTION.json');check('4path source only/nocatalog',len(ad['paths'])==4 and ad['catalog_changes'] is False)
for n,row in ad['paths'].items():
 check('afterguard '+n,meta(S/row['afterimage'])==row['after'])
 if row['before'] is not None:check('beforeguard '+n,meta(S/'before'/n)==row['before'])
 else:check('new nonexistent original '+n,n not in pre)
for variant in ['mutant-no-context','mutant-no-pr-head-guard']:
 for p in (S/'after/scripts').rglob('*.py'):
  name=p.relative_to(S/'after');expected=p.read_bytes()
  if name.as_posix() in changed:
   if variant=='mutant-no-context':expected=expected.replace(b'metadata = artifact_metadata(request, fetch, authorization_head=head)',b'metadata = artifact_metadata(request, fetch)')
   else:expected=expected.replace(b'            or prs[0]["head"]["sha"] not in allowed_pr_heads\n',b'')
  check('exact mutant '+variant+':'+str(name),(S/variant/name).read_bytes()==expected)
phases={};expected_bad={'authoritative-mypy-win32','behavioral-red','exact-old-decode-red','final-ruff','first-format','first-ruff','mutant-no-context','mutant-no-pr-head-guard','original-host-code-win32-type-scope'}
for q in sorted((S/'qa').iterdir()):
 if not(q/'receipt.json').is_file():continue
 r=load(q/'receipt.json');phases[q.name]=r;check(q.name+'directchildclosure',r['reaped'] and r['group']=='ABSENT' and not r['signals'] and not r['timeout']);check(q.name+'expected status',r['exit_code']==int(q.name in expected_bad));a=load(q/'before.json');b=load(q/'after.json')
 if r['endpoints_equal']:check(q.name+'same endpoints',a==b)
 else:check(q.name+'only own cache map drift',{n:v for n,v in a.items() if '/.ruff_cache/' not in n}=={n:v for n,v in b.items() if '/.ruff_cache/' not in n})
check('20closed authorowners',len(phases)==20)
for q in source['QA_authoritative']:
 r=phases[q];check('authoritative0 '+q,r['exit_code']==0 and r['endpoints_equal'])
 for n,row in load(S/'qa'/q/'before.json').items():check(q+'actual source/input '+n,meta(S/n)==row)
check('156 actualpure','156 passed' in (S/'qa/authoritative-pytest/stdout').read_text());check('strict hostLinux4scope','Success: no issues found in 4 source files' in (S/'qa/authoritative-mypy-linux/stdout').read_text())
for q,text in [('exact-old-decode-red','2 failed, 30 deselected'),('mutant-no-context','2 failed, 154 passed'),('mutant-no-pr-head-guard','6 failed, 150 passed')]:check('raw negative '+q,text in (S/'qa'/q/'stdout').read_text())
for q in ['authoritative-mypy-win32','original-host-code-win32-type-scope']:check('wrong foreign scope same6errors '+q,'Found 6 errors in 4 files' in (S/'qa'/q/'stdout').read_text())
def ids(p):return sorted(x for x in p.read_text().splitlines() if x.startswith('scripts/tests/') and '::' in x)
old=(S/'FOCUSED-OLD-TEST-IDS.txt').read_text().splitlines();new=(S/'NEW-TEST-IDS.txt').read_text().splitlines();check('124old32new disjoint',len(old)==len(set(old))==124 and len(new)==len(set(new))==32 and not(set(old)&set(new)));check('156 exact collection',ids(S/'qa/authoritative-collection/stdout')==sorted(old+new));check('own156 exactcollection',ids(R/'qa/fresh156-collection/stdout')==sorted(old+new));check('own156pass','156 passed' in (R/'qa/fresh156/stdout').read_text())
api=load(S/'retained-api-reproduction.json');check('own retainedreplay exact',load(R/'retained-api-own.json')==api);check('raw edge alone',api['raw_changes']==['/pull_requests/0/head/sha']);check('R actualfailure',api['actual_request_result']=={'enabled':'false','status':'METADATA_GATE_FAILED','error_type':'ValueError'})
F=S/'retained-actual-failure';a=load(F/'fresh-run.json');b=load(F/'original-run-after-request.json')
def diffs(a,b,p=''):
 if type(a)!=type(b):return[p]
 if isinstance(a,dict):return [p+'keys'] if set(a)!=set(b) else [d for n in a for d in diffs(a[n],b[n],p+'/'+n)]
 if isinstance(a,list):return[p+'length'] if len(a)!=len(b) else [d for i,(x,y) in enumerate(zip(a,b)) for d in diffs(x,y,p+'/'+str(i))]
 return [] if a==b else[p]
check('independent raw exact one edge',diffs(a,b)==['/pull_requests/0/head/sha']);check('immutable S stillsame',a['head_sha']==b['head_sha']==api['immutable_source']);check('actual edge orientation',a['pull_requests'][0]['head']['sha']==api['immutable_source'] and b['pull_requests'][0]['head']['sha']==api['validated_request_head_from_retained_control_checkout'])
rows=load(R/'control-results.json');check('own32 guards',len(rows)==32 and sum(x['accepted'] for x in rows)==4)
for q in ['fresh156','fresh156-collection','independent-controls','retained-api-replay']:
 r=load(R/'qa'/q/'receipt.json');check('own '+q+'closed0/neutral',r['exit_code']==0 and r['reaped'] and r['group']=='ABSENT' and not r['signals'] and not r['timeout'] and r['source_endpoints_equal'])
(R/'DATA.json').write_text(json.dumps({'verdict':'CLEAR_SCOPED_TWO_AUTHORIZER_SOURCE_AND_INERT_DATA','checks':len(checks),'labels':checks,'subject_files':len(files),'archive_members':len(ms),'author_owners':len(phases),'own_owners':4,'fresh_cases':156,'own_controls':32,'no_current_canonical_or_hosted_activation_claim':True},indent=2)+'\n');print(json.dumps({'checks':len(checks),'verdict':'CLEAR','source_files':len(files)}))
