from pathlib import Path
import hashlib,json,os,subprocess,sys,time
R=Path(__file__).resolve().parent;Q=R/'qa'/sys.argv[1];Q.mkdir();args=sys.argv[2:]
def snapshot():return {str(p.relative_to(R/'subject/after')):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'full_mode':p.stat().st_mode,'bytes':p.stat().st_size} for p in sorted((R/'subject/after').rglob('*')) if p.is_file()}
before=snapshot();(Q/'before.json').write_text(json.dumps(before,indent=2)+'\n');(Q/'observer.py').write_bytes(Path(__file__).read_bytes());env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','HOME':str(Q),'TMPDIR':str(Q),'PYTHONDONTWRITEBYTECODE':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1'};start=time.monotonic();signals=[];timeout=False
with (Q/'stdout').open('xb') as out,(Q/'stderr').open('xb') as err:
 c=subprocess.Popen(args,cwd=R/'subject/after',env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
 try:code=c.wait(timeout=30)
 except subprocess.TimeoutExpired:
  timeout=True
  if c.poll() is None:c.kill();signals.append('OWN_LIVE_SIGKILL')
  code=c.wait(timeout=2)
try:os.killpg(c.pid,0);group='PRESENT'
except ProcessLookupError:group='ABSENT'
after=snapshot();(Q/'after.json').write_text(json.dumps(after,indent=2)+'\n');receipt={'argv':args,'exit_code':code,'pid':c.pid,'reaped':c.returncode is not None,'group':group,'signals':signals,'timeout':timeout,'seconds':time.monotonic()-start,'source_endpoints_equal':before==after};(Q/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));raise SystemExit(code)
