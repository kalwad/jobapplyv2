from pathlib import Path
import gzip,hashlib,json,stat,tarfile
O=Path(__file__).parent
excluded={'__pycache__','.pytest_cache','.ruff_cache','.mypy_cache'}
files=set()
for root in ['project','before','context','fixtures']:
 for p in (O/root).rglob('*'):
  if p.is_file() and not any(x in excluded for x in p.parts): files.add(p)
for phase in (O/'qa').iterdir():
 for name in ['before.json','after.json','receipt.json','wrapper-executed.py','stdout','stderr']:
  p=phase/name
  if p.is_file():files.add(p)
 for p in phase.rglob('native-owner-*.json'):files.add(p)
for p in O.iterdir():
 if p.is_file() and p.name not in {'SOURCE.json','MANIFEST.json','proof.tar.gz'}:files.add(p)
def meta(p):
 s=p.lstat()
 if not stat.S_ISREG(s.st_mode):raise ValueError('nonregular proof')
 b=p.read_bytes()
 return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'full_mode':s.st_mode,'archive_mode':stat.S_IMODE(s.st_mode)}
source={'files':{p.relative_to(O).as_posix():meta(p) for p in sorted(files)},'file_count_excluding_source':len(files),'scope':'two-path coordinatorpin and actual siblingloader regression; no native functions invoked','omitted':['private Mypy/tool caches and home','QA synthetic temporary test files: source/argv/raw streams/maps/receipts retained','whole canonical source/runtime bodies and full Git endpoints: only selected4source/runtime40 endpoint maps retained','no nativeWindows execution or original artifact wholeZIP body'],'archive_mode_rule':'safe regular members, exact permissions and S_IFREG; full modes in map'}
(O/'SOURCE.json').write_text(json.dumps(source,indent=2)+'\n')
files.add(O/'SOURCE.json')
with (O/'proof.tar.gz').open('wb') as raw:
 with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w',format=tarfile.PAX_FORMAT) as archive:
   for p in sorted(files):
    entry=archive.gettarinfo(str(p),arcname=p.relative_to(O).as_posix())
    if not entry.isfile():raise ValueError('nonregular archive')
    entry.uid=entry.gid=0;entry.uname=entry.gname='';entry.mtime=0
    with p.open('rb') as body:archive.addfile(entry,body)
manifest={'SOURCE':meta(O/'SOURCE.json'),'proof':meta(O/'proof.tar.gz'),'safe_regular_members':len(files),'uncompressed_bytes':sum(p.stat().st_size for p in files)}
(O/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(O/'proof.tar.gz','r:gz') as archive:
 members=archive.getmembers()
 assert len(members)==len(files)
 for m in members:
  assert m.isfile() and m.name and not m.name.startswith('/') and '..' not in Path(m.name).parts
  expected=meta(O/m.name);body=archive.extractfile(m).read()
  assert len(body)==expected['bytes'] and hashlib.sha256(body).hexdigest()==expected['sha256'] and m.mode==expected['archive_mode']
print(json.dumps({'SOURCE':manifest['SOURCE']['sha256'],'HANDOFF':meta(O/'HANDOFF.json')['sha256'],'manifest':meta(O/'MANIFEST.json')['sha256'],'proof':manifest['proof']['sha256'],'members':len(files),'bytes':manifest['uncompressed_bytes']}))
