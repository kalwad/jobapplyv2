"""Exercise the actual coordinator import guard, never invoke native helper functions."""
from pathlib import Path
import hashlib,importlib.machinery,importlib.util,json,shutil,sys,types
from unittest import mock
O=Path(__file__).parent
scenario,label=sys.argv[1:]
assert scenario in {'accepted','tampered-before','tampered-during','occupied'}
root=O/'fixtures'/label;root.mkdir(parents=True,exist_ok=False)
ci_path=root/'native_package_ci.py';helper_path=root/'_native_package_process.py';shutil.copyfile(O/'project/scripts/native_package_ci.py',ci_path);shutil.copyfile(O/'context/_native_package_process.py',helper_path)
helper_name='_japp_native_package_ci_process';ci_name='_japp_pin_control_ci';assert helper_name not in sys.modules and ci_name not in sys.modules
spec=importlib.util.spec_from_file_location(ci_name,ci_path);assert spec is not None and spec.loader is not None;ci=importlib.util.module_from_spec(spec);sys.modules[ci_name]=ci;spec.loader.exec_module(ci)
original=helper_path.read_bytes();pin=hashlib.sha256(original).hexdigest()
if scenario=='tampered-before':helper_path.write_bytes(original+b'\n# own changed fixture\n')
sentinel=types.ModuleType(helper_name)
if scenario=='occupied':sys.modules[helper_name]=sentinel
original_exec=importlib.machinery.SourceFileLoader.exec_module
def execute(loader,module):
 original_exec(loader,module)
 if scenario=='tampered-during' and module.__name__==helper_name:helper_path.write_bytes(original+b'\n# own changed during fixture import\n')
error=None;loaded=None
try:
 with mock.patch.object(importlib.machinery.SourceFileLoader,'exec_module',execute),mock.patch('subprocess.Popen',side_effect=AssertionError('NO_SUBJECT_PROCESS')):
  try:loaded=ci.load_process_helper()
  except ValueError as caught:error=str(caught)
 observed={'scenario':scenario,'expected_helper_sha256':pin,'coordinator_constant':ci.PROCESS_HELPER_SHA,'loaded':loaded is not None,'error':error,'native_functions_invoked':False,'helper_body_after_sha256':hashlib.sha256(helper_path.read_bytes()).hexdigest()}
 print(json.dumps(observed))
 if scenario=='accepted':assert error is None and loaded is not None and ci.PROCESS_HELPER_SHA==pin
 elif scenario=='tampered-before':assert error=='Reviewed process helper changed before import' and helper_name not in sys.modules
 elif scenario=='tampered-during':assert error=='Native command helper changed during import' and helper_name in sys.modules
 else:assert error=='Native command helper module name occupied' and sys.modules[helper_name] is sentinel
finally:
 sys.modules.pop(helper_name,None);sys.modules.pop(ci_name,None)
