from pathlib import Path
import ast,difflib,hashlib,json,stat
O=Path(__file__).parent;checks=[]
def check(n,v):
 if not v:raise AssertionError(n)
 checks.append(n)
def meta(p):
 s=p.lstat();check('regular '+str(p),stat.S_ISREG(s.st_mode));b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'full_mode':s.st_mode}
old=(O/'before/scripts/native_package_ci.py').read_text();new=(O/'project/scripts/native_package_ci.py').read_text();pin=meta(O/'context/_native_package_process.py')['sha256'];beforepin='7371248344a87e537cb66cd8ef4650fb521440088be1bd75573dcf3ee5960b1d';check('constant-only exact byteinverse',new.replace(pin,beforepin)==old and new.count(pin)==1);check('constant-only exact ASTinverse',ast.dump(ast.parse(new.replace(pin,beforepin)),include_attributes=False)==ast.dump(ast.parse(old),include_attributes=False));check('helper exact v2 sibling',(O/'project/scripts/_native_package_process.py').read_bytes()==(O/'context/_native_package_process.py').read_bytes());check('v2 helper exact authoritative',pin=='19bf1ae0eec2f1511703f3ff9e97de14b289a1f67d64c36a2e5bf52e616b86b2')
phases={}
for q in sorted((O/'qa').iterdir()):
 if not(q/'receipt.json').exists():continue
 r=json.loads((q/'receipt.json').read_text());check(q.name+' custody',r['reaped'] and r['group']=='ABSENT' and not r['signals']);check(q.name+' selected endpoints',r['source_equal'] and json.loads((q/'before.json').read_text())==json.loads((q/'after.json').read_text()));check(q.name+'runtime40',len(json.loads((q/'before.json').read_text())['runtime'])==40)
 for n,row in r['streams'].items():check(q.name+'raw'+n,meta(q/n)==row)
 phases[q.name]=r['exit_code']
for name in ['authentic-fixed','before-tamper','during-tamper','occupied-name','permanent-fixed','strict','format','mypy-host','mypy-win32','permanent-list']:check(name+'PASS',phases[name]==0)
check('permanent actualoldpinRED',phases['permanent-test-old-pin-red']==1 and 'Reviewed process helper changed before import' in (O/'qa/permanent-test-old-pin-red/stdout').read_text());check('actualonecasePASS','1 passed' in (O/'qa/permanent-fixed/stdout').read_text());ids=[s for s in (O/'qa/permanent-list/stdout').read_text().splitlines() if s.startswith('scripts/')];check('oneactualID',ids==['scripts/tests/test_native_package_helper_pin.py::test_current_coordinator_loads_the_exact_sibling_helper'])
for name,expected in [('authentic-fixed',None),('before-tamper','Reviewed process helper changed before import'),('during-tamper','Native command helper changed during import'),('occupied-name','Native command helper module name occupied')]:
 r=json.loads((O/'qa'/name/'stdout').read_text());check(name+'actualguard',r['error']==expected and r['loaded']==(expected is None) and r['native_functions_invoked'] is False)
pre=json.loads((O/'PREIMAGES.json').read_text());selection={};patch=''
for name in ['scripts/native_package_ci.py','scripts/tests/test_native_package_helper_pin.py']:
 selection[name]={'before':pre.get(name),'afterimage':'project/'+name,'after':meta(O/'project'/name)};a=(O/'before'/name).read_text().splitlines(True) if (O/'before'/name).exists() else [];b=(O/'project'/name).read_text().splitlines(True);patch+=''.join(difflib.unified_diff(a,b,fromfile='a/'+name,tofile='b/'+name))
(O/'ADOPTION.json').write_text(json.dumps({'selection':selection,'must_be_absent':['scripts/tests/test_native_package_helper_pin.py'],'context_only':['scripts/_native_package_process.py','pyproject.toml'],'new_node_ids':ids,'catalog':'root composes onecase additively; no catalogfork here'},indent=2)+'\n');(O/'correction.patch').write_text(patch);(O/'DATA.json').write_text(json.dumps({'checks':len(checks),'labels':checks,'prior_QA_owners':phases,'scope':'actualsourceguard/import only; no helper budget/run/nativefunctions called'},indent=2)+'\n');print(json.dumps({'checks':len(checks),'prior_QA':len(phases),'adoption':2,'newIDs':ids}))
