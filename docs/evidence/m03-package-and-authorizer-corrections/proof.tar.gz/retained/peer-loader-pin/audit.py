from pathlib import Path,PurePosixPath
import ast,hashlib,json,stat,tarfile
R=Path(__file__).parent;E=R.parent.parent;S=E/'windows-package-job-drain-preparation/v2-integration-pin';C=R/'subject';checks=[]
def check(n,v):
 if not v:raise AssertionError(n)
 checks.append(n)
def load(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def meta(p):
 s=p.lstat();check('regular '+str(p),stat.S_ISREG(s.st_mode));b=p.read_bytes();return {'bytes':len(b),'sha256':sha(b),'full_mode':s.st_mode}
def fields(row):return {k:row[k] for k in ['bytes','sha256','full_mode']}
check('SOURCEpin',sha((S/'SOURCE.json').read_bytes())=='62286b109344c0b5a6f236594e7967c2260cf997ea866020ebfd23e58f6d4b0f');check('HANDOFFpin',sha((S/'HANDOFF.json').read_bytes())=='ebd9275d18531e0383cef1b480c2e7ec0f3751eb4256bf50e62aa684c6ae4754');check('MANIFESTpin',sha((S/'MANIFEST.json').read_bytes())=='97cf496a98397c3b959be211853df13e45d9e1baeb09447de36791b15875f533')
files=load(S/'SOURCE.json')['files'];manifest=load(S/'MANIFEST.json')
for n,row in files.items():check('exactsubject '+n,meta(S/n)==fields(row));check('exactcopy '+n,meta(C/n)==fields(row))
for k,n in [('SOURCE','SOURCE.json'),('proof','proof.tar.gz')]:check('manifest '+k,meta(S/n)==fields(manifest[k]))
with tarfile.open(S/'proof.tar.gz','r:gz') as t:
 ms=t.getmembers();names=[m.name for m in ms];check('106safeuniqueregular',len(names)==len(set(names))==manifest['safe_regular_members']==106 and set(names)==set(files)|{'SOURCE.json'})
 for m in ms:
  p=PurePosixPath(m.name);check('safename '+m.name,m.isfile() and not p.is_absolute() and '..' not in p.parts and m.name==p.as_posix());check('archivebytes/mode '+m.name,t.extractfile(m).read()==(S/m.name).read_bytes() and m.mode==stat.S_IMODE((S/m.name).stat().st_mode))
old=(S/'before/scripts/native_package_ci.py').read_text();new=(S/'project/scripts/native_package_ci.py').read_text();oldpin='7371248344a87e537cb66cd8ef4650fb521440088be1bd75573dcf3ee5960b1d';pin='19bf1ae0eec2f1511703f3ff9e97de14b289a1f67d64c36a2e5bf52e616b86b2'
check('oneconstantcompletebyteinverse',new.count(pin)==1 and new.replace(pin,oldpin)==old);check('fullASTinverse',ast.dump(ast.parse(new.replace(pin,oldpin)))==ast.dump(ast.parse(old)));check('exactreviewedhelpercontext',sha((S/'context/_native_package_process.py').read_bytes())==pin and (S/'context/_native_package_process.py').read_bytes()==(S/'project/scripts/_native_package_process.py').read_bytes()==(E/'windows-package-job-drain-preparation/v2/project/scripts/_native_package_process.py').read_bytes())
ad=load(S/'ADOPTION.json');check('twoexactpaths',set(ad['selection'])=={'scripts/native_package_ci.py','scripts/tests/test_native_package_helper_pin.py'});node='scripts/tests/test_native_package_helper_pin.py::test_current_coordinator_loads_the_exact_sibling_helper';check('oneID/no catalogfork',ad['new_node_ids']==[node] and not list((S/'project').rglob('*inventory*')))
for n,row in ad['selection'].items():
 check('afterguard '+n,meta(S/row['afterimage'])==row['after'])
 if row['before'] is not None:check('beforeguard '+n,meta(S/'before'/n)==row['before'])
 else:check('newabsentbefore '+n,not(S/'before'/n).exists())
phases={};runtime=None
for q in sorted((S/'qa').iterdir()):
 if not(q/'receipt.json').is_file():continue
 r=load(q/'receipt.json');a=load(q/'before.json');b=load(q/'after.json');phases[q.name]=r;check(q.name+'closure',r['reaped'] and r['group']=='ABSENT' and r['signals']==[]);check(q.name+'neutral',r['source_equal'] and a==b);check(q.name+'runtime40',len(a['runtime'])==40)
 if runtime is None:runtime=a['runtime']
 check(q.name+'sameruntime',runtime==a['runtime'])
 for n,row in r['streams'].items():check(q.name+'raw '+n,meta(q/n)==row)
 check(q.name+'expected code',r['exit_code']==int(q.name in {'old-pin-red','permanent-test-old-pin-red'}))
check('13authorowners',len(phases)==13)
for q in ['permanent-fixed','permanent-list','strict','format','mypy-host','mypy-win32','finite-audit']:
 for n,row in load(S/'qa'/q/'before.json')['proposal'].items():check(q+'sourcebinding '+n,meta(S/'project'/n)==row)
check('permanenttestsamefinalbytesunderoldpin',load(S/'qa/permanent-test-old-pin-red/before.json')['proposal']['scripts/tests/test_native_package_helper_pin.py']==meta(S/'project/scripts/tests/test_native_package_helper_pin.py'))
check('oldpinactualRED','Reviewed process helper changed before import' in (S/'qa/permanent-test-old-pin-red/stdout').read_text() and '1 failed' in (S/'qa/permanent-test-old-pin-red/stdout').read_text());check('fixed1PASS','1 passed' in (S/'qa/permanent-fixed/stdout').read_text())
for q,expected in [('authentic-fixed',None),('before-tamper','Reviewed process helper changed before import'),('during-tamper','Native command helper changed during import'),('occupied-name','Native command helper module name occupied')]:
 r=load(S/'qa'/q/'stdout');check(q+'actualcontrol',r['error']==expected and r['loaded']==(expected is None) and r['native_functions_invoked'] is False)
for q in ['mypy-host','mypy-win32']:check(q+'strictnew1file','Success: no issues found in 1 source file' in (S/'qa'/q/'stdout').read_text())
def ids(p):return [x for x in p.read_text().splitlines() if x.startswith('scripts/') and '::' in x]
check('authoroneID',ids(S/'qa/permanent-list/stdout')==[node]);check('ownoneID',ids(R/'qa/exact-collection/stdout')==[node]);check('own1PASS','1 passed' in (R/'qa/actual-loader/stdout').read_text());check('6owncontrols',len(load(R/'control-results.json'))==6)
for q in ['actual-loader','exact-collection','independent-controls']:
 r=load(R/'qa'/q/'receipt.json');check('own '+q+'closed0neutral',r['exit_code']==0 and r['reaped'] and r['group']=='ABSENT' and not r['signals'] and not r['timeout'] and r['source_endpoints_equal'])
(R/'DATA.json').write_text(json.dumps({'verdict':'CLEAR_SCOPED_COORDINATOR_PIN_AND_REGISTERED_LOADER_REGRESSION','checks':len(checks),'labels':checks,'author_owners':13,'own_owners':3,'own_controls':6,'actual_fresh_registered_cases':1,'subject_files':len(files),'archive_members':106,'no_actual_native_or_whole_integration_claim':True},indent=2)+'\n');print(json.dumps({'checks':len(checks),'verdict':'CLEAR'}))
