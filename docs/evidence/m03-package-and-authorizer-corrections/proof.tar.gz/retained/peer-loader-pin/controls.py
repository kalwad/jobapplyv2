from pathlib import Path
from types import ModuleType
from unittest.mock import patch
import importlib.machinery,importlib.util,json,sys
R=Path(__file__).parent;S=R/'subject';rows=[];helper_name='_japp_native_package_ci_process'
def load(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
original_exec=importlib.machinery.SourceFileLoader.exec_module
def prohibited(*a,**k):raise AssertionError('NO_BUDGET_RUN_OR_PROCESS')
for scenario in ['exact','old-pin','before-tamper','during-tamper','occupied']:
 D=R/'control-inputs'/scenario;D.mkdir(parents=True);p=D/'native_package_ci.py';hp=D/'_native_package_process.py';p.write_bytes((S/('before' if scenario=='old-pin' else 'project')/'scripts/native_package_ci.py').read_bytes());hp.write_bytes((S/'context/_native_package_process.py').read_bytes());module=load('own_ci_'+scenario.replace('-','_'),p);sentinel=ModuleType(helper_name)
 if scenario=='before-tamper':hp.write_bytes(hp.read_bytes()+b'\n# own inert changed bytes\n')
 if scenario=='occupied':sys.modules[helper_name]=sentinel
 def execute(loader,m):
  original_exec(loader,m)
  if m.__name__==helper_name:
   for n in ['budget','_validate_budget','run']:setattr(m,n,prohibited)
   if scenario=='during-tamper':hp.write_bytes(hp.read_bytes()+b'\n# own during import mutation\n')
 error=None;result=None
 try:
  with patch.object(importlib.machinery.SourceFileLoader,'exec_module',execute),patch('subprocess.Popen',prohibited):
   try:result=module.load_process_helper()
   except ValueError as e:error=str(e)
  assert (result is not None)==(scenario=='exact')
  if scenario in ['before-tamper','old-pin']:assert error=='Reviewed process helper changed before import' and helper_name not in sys.modules
  if scenario=='during-tamper':assert error=='Native command helper changed during import'
  if scenario=='occupied':assert error=='Native command helper module name occupied' and sys.modules[helper_name] is sentinel
  rows.append({'scenario':scenario,'loaded':result is not None,'error':error,'native_or_budget_or_run_calls':0})
 finally:sys.modules.pop(helper_name,None);sys.modules.pop(module.__name__,None)
tests=load('own_permanent_test',S/'project/scripts/tests/test_native_package_helper_pin.py');cn='_japp_native_package_ci_pin_test';old_ci=ModuleType(cn);old_helper=ModuleType(helper_name);sys.modules[cn]=old_ci;sys.modules[helper_name]=old_helper
try:
 def execute(loader,m):
  original_exec(loader,m)
  if m.__name__==helper_name:
   for n in ['budget','_validate_budget','run']:setattr(m,n,prohibited)
 with patch.object(importlib.machinery.SourceFileLoader,'exec_module',execute),patch('subprocess.Popen',prohibited):tests.test_current_coordinator_loads_the_exact_sibling_helper()
 assert sys.modules[cn] is old_ci and sys.modules[helper_name] is old_helper
 rows.append({'scenario':'permanent-test-restores-existing-modules','loaded':True,'no_native_run_process':True,'exact_prior_objects_restored':True})
finally:sys.modules.pop(cn,None);sys.modules.pop(helper_name,None)
(R/'control-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'independent_controls':len(rows),'all_pass':True}))
