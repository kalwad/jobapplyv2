from pathlib import Path
import ast,copy,difflib,hashlib,json,stat
O=Path(__file__).parent;V=O.parent/'v1';checks=[]
def check(n,v):
 if not v:raise AssertionError(n)
 checks.append(n)
def meta(p):
 s=p.lstat();check('regular '+str(p),stat.S_ISREG(s.st_mode));b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'full_mode':s.st_mode}
parent=json.loads((V/'SOURCE.json').read_text())['files']
for name,row in parent.items():check('v1 frozen '+name,meta(V/name)=={k:row[k] for k in ['bytes','sha256','full_mode']})
original=(O/'before/scripts/_native_package_process.py').read_text();current=(O/'project/scripts/_native_package_process.py').read_text();a=ast.parse(original);b=ast.parse(current)
def member(tree,name,kind):return next(n for n in tree.body if isinstance(n,kind) and n.name==name)
for name,kind in [('Containment',ast.ClassDef),('_containment',ast.FunctionDef),('run',ast.FunctionDef)]:
 old=member(a,name,kind);new=member(b,name,kind);b.body[b.body.index(new)]=copy.deepcopy(old)
a_cls=member(a,'_WindowsJob',ast.ClassDef);b_cls=member(b,'_WindowsJob',ast.ClassDef);old=member(a_cls,'settle',ast.FunctionDef);new=member(b_cls,'settle',ast.FunctionDef);b_cls.body[b_cls.body.index(new)]=copy.deepcopy(old);check('all AST outside four scoped custody/receipt definitions exact',ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False))
newtree=ast.parse(current);oldrun=member(a,'run',ast.FunctionDef);newrun=member(newtree,'run',ast.FunctionDef)
def linuxbranch(run):
 for n in ast.walk(run):
  if isinstance(n,ast.If) and isinstance(n.test,ast.Compare) and any(isinstance(c,ast.Constant) and c.value=='linux' for c in n.test.comparators):return n.body
 raise AssertionError('Linux branch absent')
check('entire original Linux launch branch exact',ast.dump(ast.Module(body=linuxbranch(oldrun),type_ignores=[]),include_attributes=False)==ast.dump(ast.Module(body=linuxbranch(newrun),type_ignores=[]),include_attributes=False))
def ok_values(run):return next(n.value.values for n in ast.walk(run) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ok' for t in n.targets))
oldok=ok_values(oldrun);newok=ok_values(newrun);newok=[n for n in newok if 'job_cleanup_deadline_met' not in ast.unparse(n)];check('all original success conjuncts retained exact',[ast.dump(n,include_attributes=False) for n in oldok]==[ast.dump(n,include_attributes=False) for n in newok])
pin=hashlib.sha256(current.encode()).hexdigest();oldpin=hashlib.sha256(original.encode()).hexdigest();check('seven original test bodies byteexact except pin',(O/'project/scripts/tests/test_native_package_pending_owner.py').read_text().replace(pin,oldpin)==(O/'before/scripts/tests/test_native_package_pending_owner.py').read_text())
oldtests=ast.parse((V/'project/scripts/tests/test_native_package_job_drain.py').read_text());newtests=ast.parse((O/'project/scripts/tests/test_native_package_job_drain.py').read_text());newdefs={n.name:n for n in newtests.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
for n in oldtests.body:
 if isinstance(n,(ast.FunctionDef,ast.ClassDef)):check('all v1 helper/assertion AST exact '+n.name,ast.dump(n,include_attributes=False)==ast.dump(newdefs[n.name],include_attributes=False))
check('exact final control source in oldv1negativecopy',(O/'control-v1/scripts/tests/test_native_package_job_drain.py').read_bytes()==(O/'project/scripts/tests/test_native_package_job_drain.py').read_bytes());check('negative helper exact heldv1',(O/'control-v1/scripts/_native_package_process.py').read_bytes()==(V/'project/scripts/_native_package_process.py').read_bytes())
base=json.loads((O/'before/scripts/python-test-inventory.v1.json').read_text());final=json.loads((O/'project/scripts/python-test-inventory.v1.json').read_text());new=json.loads((O/'NEW-NODE-IDS.json').read_text());check('all2815common plus30new exact',final['common']['node_ids']==sorted(base['common']['node_ids']+new));check('30new unique',len(new)==len(set(new))==30);check('2845common',final['common']['count']==2845);check('twoPOSIX exact',final['posix_only_node_ids']==base['posix_only_node_ids'] and len(final['posix_only_node_ids'])==2);check('catalog digest',final['common']['sha256']==hashlib.sha256(('\n'.join(final['common']['node_ids'])+'\n').encode()).hexdigest())
phases={}
for q in sorted((O/'qa').iterdir()):
 if not(q/'receipt.json').is_file():continue
 r=json.loads((q/'receipt.json').read_text());check(q.name+' closure',r['reaped'] and r['group']=='ABSENT' and not r['signals']);check(q.name+' endpoints',r['source_equal'] and json.loads((q/'before.json').read_text())==json.loads((q/'after.json').read_text()));check(q.name+'runtime40',len(json.loads((q/'before.json').read_text())['runtime'])==40)
 for n,row in r['streams'].items():check(q.name+'raw'+n,meta(q/n)==row)
 phases[q.name]=r['exit_code']
for label in ['final-actual','final-list','strict-final','format-final','mypy-host-final','mypy-win32-fixtures-final']:check(label+' PASS',phases[label]==0)
check('37actualpass','37 passed' in (O/'qa/final-actual/stdout').read_text());check('v1 genuinely late acceptedRED',phases['exact-v1-late-red']==1 and 'CompletedProcess' in (O/'qa/exact-v1-late-red/stdout').read_text())
index=json.loads((O/'RETAINED-RESULTS.json').read_text());slow=[]
for name,row in index.items():
 p=O/name;check('retained result body '+name,meta(p)['sha256']==row['sha256']);r=json.loads(p.read_text())
 if name.startswith('retained-results/final-actual/') and name.endswith('-slow.result.json'):slow.append(r)
 if name.startswith('retained-results/exact-v1-late-red/') and name.endswith('-slow.result.json'):check('actual v1 false admission16s',r['success'] is True and r['seconds_elapsed']>=16 and r['containment']['terminated_job'] is False)
check('eight slow controls retained',len(slow)==8);check('fourlate denied/four timely admitted',sum(r['success'] for r in slow)==4)
for r in slow:check('closure retained while deadline checked',r['containment']['all_job_members_closed'] and not r['containment']['terminated_job'] and r['containment']['job_cleanup_deadline_met']==r['success'])
pre=json.loads((O/'PREIMAGES.json').read_text());selection={};patch=''
for name in ['scripts/_native_package_process.py','scripts/tests/test_native_package_pending_owner.py','scripts/tests/test_native_package_job_drain.py','scripts/python-test-inventory.v1.json']:
 selection[name]={'before':pre.get(name),'afterimage':'project/'+name,'after':meta(O/'project'/name)};old=(O/'before'/name).read_text().splitlines(True) if (O/'before'/name).exists() else [];new=(O/'project'/name).read_text().splitlines(True);patch+=''.join(difflib.unified_diff(old,new,fromfile='a/'+name,tofile='b/'+name))
(O/'ADOPTION.json').write_text(json.dumps({'selection':selection,'must_be_absent':['scripts/tests/test_native_package_job_drain.py'],'context_only':['pyproject.toml'],'whole_inventory':'2847 composed only; actual37selected'},indent=2)+'\n');(O/'correction.patch').write_text(patch);(O/'DATA.json').write_text(json.dumps({'checks':len(checks),'labels':checks,'prior_QA_owners':phases,'parent_v1_files_verified':len(parent),'scope':'fake heldWin32 flow only, unchanged historicalfailure/causeunknown'},indent=2)+'\n');print(json.dumps({'checks':len(checks),'prior_QA':len(phases),'parent_v1_files':len(parent),'actual':37,'new_vs_original':30,'new_vs_v1':10}))
