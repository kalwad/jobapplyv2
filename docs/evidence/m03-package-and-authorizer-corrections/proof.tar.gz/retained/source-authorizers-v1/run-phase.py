from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,sys,time
R=Path(__file__).resolve().parent
label,stage,*argv=sys.argv[1:];cwd=R/stage;q=R/'qa'/label;q.mkdir(parents=True,exist_ok=False)
def snapshot():
 return {p.relative_to(R).as_posix():{'bytes':p.stat().st_size,'full_mode':p.stat().st_mode,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for root in [R/'before',R/'after',*(p for p in R.glob('mutant-*') if p.is_dir())] for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and (p.suffix == '.py' or p.name == 'pyproject.toml')}
before=snapshot();(q/'before.json').write_text(json.dumps(before,indent=2)+'\n')
env={'PATH':'/Users/tanishkalwad/jobapplyv2/.venv/bin:/usr/bin:/bin','LANG':'C','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1','MYPYPATH':str(cwd/'scripts/linux_gnome')+':'+str(cwd/'scripts/windows11'),'UV_CACHE_DIR':str(R/'work/uv-cache')}
start=time.monotonic();signals=[];timeout=False
with (q/'stdout').open('xb') as out,(q/'stderr').open('xb') as err:
 p=subprocess.Popen(argv,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
 try:code=p.wait(timeout=90)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(p.pid,signal.SIGKILL);signals.append('SIGKILL');code=p.wait(timeout=3)
try:os.killpg(p.pid,0);group='PRESENT'
except ProcessLookupError:group='ABSENT'
after=snapshot();(q/'after.json').write_text(json.dumps(after,indent=2)+'\n')
receipt={'argv':argv,'cwd':str(cwd),'env':env,'pid':p.pid,'exit_code':code,'reaped':p.returncode is not None,'group':group,'signals':signals,'timeout':timeout,'seconds':time.monotonic()-start,'endpoints_equal':before==after,'utc':datetime.datetime.now(datetime.UTC).isoformat(),'scope':'Own pure request fixtures/injected API+git data only; no network/native/VM/GI/model/canonical action.'}
(q/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');(q/'executed-runner.py').write_bytes(Path(__file__).read_bytes())
assert before==after and group=='ABSENT' and not signals and not timeout
print(json.dumps(receipt));raise SystemExit(code)
