from pathlib import Path
import ast,datetime,difflib,hashlib,json,stat,tarfile
R=Path(__file__).resolve().parent;C=Path('/Users/tanishkalwad/jobapplyv2')
def pin(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode)
 return {'bytes':s.st_size,'full_mode':s.st_mode,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def load(p):return json.loads(p.read_bytes())
checks=[]
def check(name,yes):checks.append({'name':name,'pass':bool(yes)});assert yes,name
pre=load(R/'PREIMAGES.json');adoption=load(R/'ADOPTION.json')
changed={'scripts/linux_gnome/ubuntu_gnome_request.py','scripts/windows11/windows11_request.py'}
for name,row in pre.items():
 check('sealed-preimage:'+name,pin(R/'before'/name)==row)
 if name not in changed:check('unchanged-component:'+name,pin(R/'after'/name)==row)
for name in changed:
 before=ast.parse((R/'before'/name).read_bytes());after=ast.parse((R/'after'/name).read_bytes())
 old={node.name:node for node in before.body if isinstance(node,(ast.FunctionDef,ast.ClassDef))};new={node.name:node for node in after.body if isinstance(node,(ast.FunctionDef,ast.ClassDef))}
 check('same-definitions:'+name,set(old)==set(new))
 for item,node in old.items():
  if item not in {'decode','artifact_metadata'}:check('exact-unrelated-AST:'+name+':'+item,ast.dump(node)==ast.dump(new[item]))
 olddecode=ast.unparse(old['decode']);newdecode=ast.unparse(new['decode']).replace('artifact_metadata(request, fetch, authorization_head=head)','artifact_metadata(request, fetch)')
 check('only-decode-call-delta:'+name,olddecode==newdecode)
 check('exact-protected-source-guard:'+name,ast.dump(old['protected_sources'])==ast.dump(new['protected_sources']))
for name in ['test_ubuntu_gnome_request.py','test_windows11_request.py']:
 check('whole-old-test-bytes:'+name,(R/'before/scripts/tests'/name).read_bytes()==(R/'after/scripts/tests'/name).read_bytes())
for name in ['test_ubuntu_gnome_request_live_head.py','test_windows11_request_live_head.py']:
 def bodies(p):return {n.name:ast.dump(ast.Module(body=n.body,type_ignores=[])) for n in ast.parse(p.read_bytes()).body if isinstance(n,ast.FunctionDef)}
 check('tests-first-body-oracles-exact:'+name,bodies(R/'before/scripts/tests'/name)==bodies(R/'after/scripts/tests'/name))
for variant in ['mutant-no-context','mutant-no-pr-head-guard']:
 for p in (R/'after/scripts').rglob('*.py'):
  name=p.relative_to(R/'after');expected=p.read_bytes()
  if name.as_posix() in changed:
   if variant=='mutant-no-context':expected=expected.replace(b'metadata = artifact_metadata(request, fetch, authorization_head=head)',b'metadata = artifact_metadata(request, fetch)')
   else:expected=expected.replace(b'            or prs[0]["head"]["sha"] not in allowed_pr_heads\n',b'')
  check('mutant-only-delta:'+variant+':'+name.as_posix(),(R/variant/name).read_bytes()==expected)
qa={}
for q in sorted((R/'qa').iterdir()):
 if not (q/'receipt.json').exists():continue
 row=load(q/'receipt.json');qa[q.name]=row
 check('QA-owned-closure:'+q.name,row['reaped'] and row['group']=='ABSENT' and row['signals']==[] and not row['timeout'])
 before=load(q/'before.json');after=load(q/'after.json')
 if row['endpoints_equal']:check('QA-equal-map:'+q.name,before==after)
 else:
  clean=lambda value:{k:v for k,v in value.items() if '/.ruff_cache/' not in k}
  check('initial-guard-included-only-cache-drift:'+q.name,clean(before)==clean(after))
for label in ['authoritative-pytest','authoritative-collection','authoritative-ruff','authoritative-format','authoritative-mypy-linux','authoritative-retained-api']:
 check('authoritative-zero:'+label,qa[label]['exit_code']==0 and qa[label]['endpoints_equal'])
 for name,row in load(R/'qa'/label/'before.json').items():check('final-source-binding:'+label+':'+name,pin(R/name)==row)
check('actual156','156 passed' in (R/'qa/authoritative-pytest/stdout').read_text())
check('behavioral-old-RED','2 failed, 30 deselected' in (R/'qa/exact-old-decode-red/stdout').read_text())
check('no-context-control','2 failed, 154 passed' in (R/'qa/mutant-no-context/stdout').read_text())
check('no-head-guard-control','6 failed, 150 passed' in (R/'qa/mutant-no-pr-head-guard/stdout').read_text())
for label in ['authoritative-mypy-win32','original-host-code-win32-type-scope']:
 check('wrong-foreign-type-scope-retained:'+label,'Found 6 errors in 4 files' in (R/'qa'/label/'stdout').read_text())
ids=(R/'NEW-TEST-IDS.txt').read_text().splitlines();oldids=(R/'FOCUSED-OLD-TEST-IDS.txt').read_text().splitlines()
check('exact-additive-ID-count',len(ids)==len(set(ids))==32 and len(oldids)==124 and not set(ids)&set(oldids))
check('four-adoption-paths',len(adoption['paths'])==4 and not adoption['catalog_changes'])
for name,row in adoption['paths'].items():check('adoption-pin:'+name,pin(R/row['afterimage'])==row['after'])
for name in changed:check('current-canonical-selected-preimage-only:'+name,pin(C/name)==pre[name])
api=load(R/'retained-api-reproduction.json');check('actual-only-mutable-edge',api['raw_changes']==['/pull_requests/0/head/sha'])
check('actual-R-still-failure',api['actual_request_result']=={'enabled':'false','status':'METADATA_GATE_FAILED','error_type':'ValueError'})
patch=[]
for name,row in adoption['paths'].items():
 before=(R/'before'/name).read_text() if row['before'] else ''
 after=(R/row['afterimage']).read_text()
 patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(R/'ADOPTION.patch').write_text(''.join(patch))
(R/'DATA.json').write_text(json.dumps({'pass':True,'checks':len(checks),'rows':checks,'QA':qa,'old_tests':124,'additive_tests':32,'total_focused':156,'no_subject_network_VM_native_model_Git_calls':True,'scope':'Own pure fake git/API metadata tests and existing fake custody controls. Selected canonical input file reads only; no whole canonical epoch claim.'},indent=2)+'\n')
included=[]
for p in sorted(R.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(R)
 if any(part in {'work','.ruff_cache','__pycache__'} for part in rel.parts):continue
 if len(rel.parts)==1 and rel.name in {'SOURCE.json','MANIFEST.json','proof.tar.gz'}:continue
 included.append(p)
source={'schema':'TWO_AUTHORIZER_MUTABLE_PR_EDGE_CORRECTION_V1','status':'FROZEN_SOURCE_ONLY_PENDING_DIFFERENT_REVIEW','files':{p.relative_to(R).as_posix():pin(p) for p in included},'canonical_afterimages':adoption['paths'],'new_test_IDs':ids,'old_test_bodies':'Both original complete files byte-exact','QA_authoritative':['authoritative-pytest','authoritative-collection','authoritative-ruff','authoritative-format','authoritative-mypy-linux','authoritative-retained-api'],'actual_pure_tests':156,'old':124,'added':32,'original_R_outcome':'FAILURE_METADATA_ONLY_NO_CANDIDATE','immutable_source':api['immutable_source'],'authorization_request_head':api['validated_request_head_from_retained_control_checkout'],'activation_requires_fresh_source_and_package':True,'canonical_catalog_modified':False,'scope':'No canonical write/network/VM/download/model/native actor. Existing pure fixture functions inject git/API/process effects.','utc':datetime.datetime.now(datetime.UTC).isoformat()}
(R/'SOURCE.json').write_text(json.dumps(source,indent=2)+'\n')
with tarfile.open(R/'proof.tar.gz','w:gz') as archive:
 for p in included+[R/'SOURCE.json']:archive.add(p,arcname=p.relative_to(R).as_posix(),recursive=False)
with tarfile.open(R/'proof.tar.gz') as archive:
 members=archive.getmembers();assert all(p.isfile() and not p.name.startswith('/') and '..' not in Path(p.name).parts for p in members)
manifest={'SOURCE':pin(R/'SOURCE.json'),'HANDOFF':pin(R/'HANDOFF.md'),'proof':pin(R/'proof.tar.gz'),'safe_regular_members':len(members),'data_checks':len(checks),'all_QA_owners_closed':len(qa),'scope':'Caches/work omitted; exact source/raw/failure/history retained.'}
(R/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({**manifest,'MANIFEST':pin(R/'MANIFEST.json')}))
