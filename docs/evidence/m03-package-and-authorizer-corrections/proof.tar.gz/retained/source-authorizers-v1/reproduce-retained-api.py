from pathlib import Path
import hashlib,importlib.util,json,sys
R=Path(__file__).resolve().parent;F=R/'retained-actual-failure'
before=json.loads((F/'fresh-run.json').read_bytes());after=json.loads((F/'original-run-after-request.json').read_bytes());artifact=json.loads((F/'fresh-artifact.json').read_bytes())
request=json.loads((F/'request-metadata/git-002.stdout').read_bytes())
head=(F/'request-metadata/git-001.stdout').read_text().strip()
def differences(a,b,path=''):
 if type(a) is not type(b):return [path]
 if isinstance(a,dict):
  if set(a)!=set(b):return [path+'/<keys>']
  return [s for key in a for s in differences(a[key],b[key],path+'/'+key)]
 if isinstance(a,list):
  if len(a)!=len(b):return [path+'/<length>']
  return [s for i,(x,y) in enumerate(zip(a,b,strict=True)) for s in differences(x,y,path+'/'+str(i))]
 return [] if a==b else [path]
delta=differences(before,after)
assert delta==['/pull_requests/0/head/sha']
assert before['head_sha']==after['head_sha']==request['expected_source_sha']==request['artifact']['run_head_sha']
assert before['pull_requests'][0]['head']['sha']==request['expected_source_sha']
assert after['pull_requests'][0]['head']['sha']==head
results=[]
for stage in ['before','after']:
 folder=R/stage/'scripts/linux_gnome';sys.path.insert(0,str(folder))
 name='retained_'+stage;spec=importlib.util.spec_from_file_location(name,folder/'ubuntu_gnome_request.py');assert spec and spec.loader
 module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
 for api in ['before','after']:
  run=before if api=='before' else after
  def fetch(path):return run if '/runs/' in path else artifact
  for context in ([None] if stage=='before' else [None,head]):
   error=None;result=None
   try:
    result=module.artifact_metadata(request,fetch,authorization_head=context) if context is not None else module.artifact_metadata(request,fetch)
   except ValueError as caught:error=str(caught)
   expected=api=='before' or (stage=='after' and context==head)
   assert (result is not None)==expected
   if result is not None:assert result['head_sha']==request['expected_source_sha']
   results.append({'module':stage,'API_snapshot':api,'authorization_context':context,'accepted':result is not None,'error':error,'immutable_run_source':run['head_sha']})
result={'raw_changes':delta,'immutable_source':request['expected_source_sha'],'validated_request_head_from_retained_control_checkout':head,'actual_request_result':json.loads((F/'request-metadata/request.json').read_bytes()),'pure_metadata_controls':results,'historical_scope':'Exact retained current API/request metadata reproduces the original PR-head guard refusal; the job retained only ValueError and did not retain its API response or full exception message. Other historical hidden ValueError causes are not ruled out. No corrected hosted request success is claimed. Windows has synthetic controls only.','API_or_Git_or_VM_calls':0}
(R/'retained-api-reproduction.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
