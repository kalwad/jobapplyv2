"""Inert compact packaging of closed source/review and actual-data epochs."""
from pathlib import Path, PurePosixPath
from datetime import datetime, UTC
import gzip, hashlib, io, json, stat, tarfile

E = Path(__file__).resolve().parent
H = E / 'm03-package-and-authorizer-evidence-preparation/v1'
O = H / 'after/docs/evidence/m03-package-and-authorizer-corrections'
assert not O.exists()

def sha(b): return hashlib.sha256(b).hexdigest()
def pin(p):
    s = p.lstat()
    assert stat.S_ISREG(s.st_mode) and not p.is_symlink(), str(p)
    b = p.read_bytes()
    return {'bytes': len(b), 'sha256': sha(b), 'mode': stat.S_IMODE(s.st_mode), 'full_mode': s.st_mode}
def load(p): return json.loads(p.read_text())
def dump(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    p.chmod(0o644)
def safe(n):
    p = PurePosixPath(n)
    return bool(n and not p.is_absolute() and '..' not in p.parts and '\\' not in n and p.as_posix() == n)

checks = 0
def check(v, why):
    global checks
    assert v, why
    checks += 1

inputs = {}
files = {}
def add(p, name):
    check(safe(name) and name not in files, 'member identity: ' + name)
    r = pin(p)
    files[name] = p
    inputs[str(p)] = r
    return r
def top(root, prefix):
    for p in sorted(root.iterdir()):
        if p.is_file(): add(p, prefix + '/' + p.name)

gather = load(H / 'GATHERED.json')
for r in gather['parents']:
    p = H / r['path']
    expected = {k:r[k] for k in ('bytes','sha256','mode','full_mode')}
    check(pin(p) == pin(Path(r['origin'])) == expected, 'frozen source/peer top-level bytes/modes')
    inputs[r['origin']] = expected
    add(p, r['path'])

nested = []
for r in gather['nested_archives']:
    root = Path(r['origin']).parent
    p = root / 'proof.tar.gz'
    check(pin(p) == r['proof'], 'frozen nested proof pin')
    with tarfile.open(p, 'r:gz') as t:
        ms = t.getmembers()
        check(len(ms) == r['safe_regular_members'] and len(ms) == len({m.name for m in ms}), 'nested membership')
        for m, old in zip(ms, r['members'], strict=True):
            check(m.isfile() and safe(m.name) and m.name == old['path'], 'safe nested regular member')
            b = t.extractfile(m).read()
            src = root / m.name
            rpin = pin(src)
            check(len(b) == old['bytes'] == rpin['bytes'] and sha(b) == old['sha256'] == rpin['sha256'] and m.mode == old['archive_mode'] == rpin['mode'] and rpin['full_mode'] == old['original_full_mode'], 'nested body/full-mode original join')
            inputs[str(src)] = rpin
    nested.append(r)
for n in ('GATHERED.json','PREDECLARED.md','gather-reader-correction.json'):
    add(H/n, 'preparation/'+n)
for p in sorted((H/'history').rglob('*')):
    if p.is_file(): add(p,'preparation/history/'+p.relative_to(H/'history').as_posix())

A = E/'package-and-authorizer-canonical-adoption/v1'
P = E/'package-loader-pin-canonical-adoption/v1'
F = E/'package-and-authorizer-canonical-focus/v1'
S = E/'package-authorizer-post-stage-checks/v1'
V = E/'package-and-authorizer-canonical-independent-review/v1'
for root,label in ((A,'actual/combined-adoption'),(P,'actual/loader-pin-and-request-withdrawal'),(F,'actual/focus-before-index-stage'),(S,'actual/post-stage-successor'),(V,'actual-data-review')):
    top(root,label)
for name in ('package-authorizer-root-reader-v1-failure.json','adopt-package-and-authorizer-fixes-root-v1.py','adopt-package-and-authorizer-fixes-root-v2.py','adopt-package-loader-pin-root-v1.py','stage-retired-request-and-check-root-v1.py','gather-package-authorizer-packet-v1.py'):
    add(E/name,'root-and-packaging-drivers/'+name)
add(Path(__file__), 'root-and-packaging-drivers/'+Path(__file__).name)

R = E/'gnome-download-only-root-release/v1'
for name in ('adoption-executed.py','adoption.json','fresh-artifact.json','fresh-pr.json','fresh-run.json','new-head-runs-initial.json','original-run-after-request.json','root-review.json','actual-prepare-first.log','actual-request-metadata.zip'):
    add(R/name,'historical-failed-request-R/'+name)
for p in sorted((R/'actual-request-metadata').rglob('*')):
    if p.is_file(): add(p, 'historical-failed-request-R/actual-request-metadata/'+p.relative_to(R/'actual-request-metadata').as_posix())

check(pin(V/'REVIEW.md')['sha256'] == '7eb896f7d59e06eb9d1766c2a51ee7ae273f31f3a685f90b39e49fc9ea57b9a3', 'actual review pin')
check(pin(V/'SOURCE.json')['sha256'] == 'a16ecdd5f60eef329b76d5664db072ea98aae9de063f5f58020d83f2a04193f7', 'actual source pin')
check(pin(V/'MANIFEST.json')['sha256'] == '9bc809a6c578278bd93141b069008dc8839923320bdfcf234b9caef5c227637f', 'actual review manifest pin')
check(pin(V/'proof.tar.gz')['sha256'] == 'bf53e6506221c99a8d669251251b9bc46f07e029d58035781ea0edd7bace0f14', 'actual review proof pin')
with tarfile.open(V/'proof.tar.gz','r:gz') as t:
    ms = t.getmembers()
    check(len(ms)==58 and len(ms)==len({m.name for m in ms}), 'SDK proof membership')
    nr = []
    for m in ms:
        check(m.isfile() and safe(m.name), 'SDK safe regular member')
        b=t.extractfile(m).read(); p=V/m.name; r=pin(p)
        check(len(b)==r['bytes'] and sha(b)==r['sha256'] and m.mode==r['mode'], 'SDK original byte/mode join')
        inputs[str(p)]=r
        nr.append({'path':m.name,'bytes':len(b),'sha256':sha(b),'archive_mode':m.mode,'original_full_mode':r['full_mode']})
    nested.append({'label':'actual-data-review','origin':str(V/'proof.tar.gz'),'proof':pin(V/'proof.tar.gz'),'safe_regular_members':len(ms),'uncompressed_bytes':sum(m.size for m in ms),'all_original_body_fullmode_joins':True,'members':nr})

ac, pc, fc, sc = [load(x/'closure.json') for x in (A,P,F,S)]
check(ac['checks']==888 and ac['selected']==8 and ac['logical_before']==2375 and ac['logical_after']==2378 and ac['added_common']==62, 'combined adoption facts')
check(pc['checks']==218 and pc['logical_before']==pc['logical_after']==2378 and pc['new_POSIX']==2880 and pc['new_common']==2878, 'loader adoption facts')
check(fc['commands']==9 and not fc['all_ten_closed_zero'] and fc['source_count']==2378 and fc['runtime_count']==40, 'original focus failure')
check(sc['prior_successful_checks']==8 and sc['successor_checks']==2 and sc['prior_focus_integrity_FAILURE_preserved'] and sc['stage_and_two_successors_closed_zero_reaped_groups_absent'], 'distinct successor scope')
cmd1, cmd2 = load(F/'commands.json'), load(S/'commands.json')
check(len(cmd1)==9 and [x['exit_code'] for x in cmd1]==[0]*8+[1], 'eight PASS and genuine ninth FAIL')
check(len(cmd2)==3 and [x['exit_code'] for x in cmd2]==[0]*3, 'stage plus two checks')
for c in cmd1+cmd2:
    check(c['pid']>0 and c['pgid']>0 and c['reaped'] and c['group']=='ABSENT' and not c['signals'] and not c['timeout'], '12 explicit owner closures')
check('343 passed in 1.57s' in (F/'focused-python.log').read_text(), 'focused actual summary')
check(load(F/'collection-join.json')['count']==2880 and load(F/'collection-join.json')['exact_catalog_identity_set'], 'actual catalog equality')
check('tracked text source cannot be read' in (F/'integrity.log').read_text(), 'initial integrity raw failure')
check('diff' not in [x['name'] for x in cmd1], 'initial diff unrun')
check(cmd2[0]['argv']==['git','add','--','.github/gnome/requests/download-only.json'] and cmd2[2]['argv']==['git','diff','--check','HEAD'], 'exact index mutation and combined diff')
fb, fa, sb, sa, se=[load(p) for p in (F/'before.json',F/'after.json',S/'before.json',S/'after-stage.json',S/'after.json')]
for key in ('source','runtime','head','tree','index_sha256','status'):
    check(fb[key]==fa[key], 'first epoch neutral '+key)
for key in ('source','runtime','head','tree'):
    check(fa[key]==sb[key]==sa[key]==se[key], 'same bodies across index stage '+key)
check(sb['index_sha256']!=sa['index_sha256'] and sa==se, 'explicit index-only epoch transition')
check(len(fa['source'])==2378 and len(fa['runtime'])==40, 'finite source/runtime scope')
check(pin(P/'retired-root-request.json')['sha256']=='9a88dac3505493f5f3da76db91e477d483591e2d6177419d86316447acbffffe', 'exact retired request bytes')
request=load(R/'actual-request-metadata/request.json')
check(request=={'enabled':'false','status':'METADATA_GATE_FAILED','error_type':'ValueError'}, 'original opaque request failure')
vd=load(V/'data-review.json')
check(vd['checks']==6012 and vd['verdict']=='CLEAR_SCOPED_ACTUAL_ADOPTION_AND_DISTINCT_FOCUS_EPOCHS' and vd['owners']['records']==12, 'finite SDK actual review')
cat=load(P/'composed-catalog.json')
check(cat['common']['count']==len(cat['common']['node_ids'])==2878 and len(cat['posix_only_node_ids'])==2, 'final catalog shape')

scope = {
 'source_only_controls': {'windows_job_v2':{'passed':37,'new_vs_canonical':30},'authorizers':{'passed':156,'new_vs_canonical':32},'loader_pin':{'passed':1,'new_vs_canonical':1}},
 'combined_adoption':ac,'loader_pin_adoption':pc,
 'first_focus':{'closure':fc,'commands':cmd1,'successful_commands':8,'integrity_exit':1,'diff':'NOT_EXECUTED','python_passed':343,'python_seconds':1.57,'collection':2880},
 'successor':{'closure':sc,'commands':cmd2,'scope':'Exact one-D stage, then integrity and combined diff; not ten PASS commands in one index epoch.'},
 'actual_review':{'verdict':vd['verdict'],'checks':6012,'authorship':vd['authorship'],'review':pin(V/'REVIEW.md'),'manifest':pin(V/'MANIFEST.json'),'proof':pin(V/'proof.tar.gz')},
 'historical_request_R':{'head':'c930c86c83d478b3048d4cc80abd1346065e2e0d','actual_status':request,'retired_body':pin(P/'retired-root-request.json'),'cause_scope':'Pure reproduction establishes the mutable PR-head false refusal; original actual opaque ValueError has no full exception/API response and does not establish sole causality.'},
 'historical_windows_package':{'source':'f3a1c6f7ad62161c682d92f842003fd018c5eec1','actual':'FAILURE','direct_tauri_exit':0,'terminated_job':True,'cause':'UNKNOWN; source correction does not establish historical root cause or a corrected actual Windows result.'},
 'code_epoch':{'head':fa['head'],'tree':fa['tree'],'logical_sources':2378,'runtime_files':40,'catalog_common':2878,'catalog_POSIX':2880,'index_before':sb['index_sha256'],'index_after':sa['index_sha256']},
 'no_transferred_qualification':['new aggregate/full PASS','fresh hosted CI PASS','corrected actual Windows package','native Windows/GNOME acceptance','model qualification','Gate/milestone/release acceptance'],
 'custody_scope':'12 explicit child owners across the two focus epochs. Root direct adoption tool and this inert packaging tool have no separately retained numeric interpreter owner; no ownership is inferred from tool success.',
 'omissions':['No full current Git/source or runtime binary payload bodies; complete retained byte/full-mode maps identify the finite epochs.','Disposable pytest/cache/temporary projections are omitted; all executed commands, authoritative raw logs, before/after maps, catalog and retired request bytes are retained.','Original historical full/CI binary bodies and large archives remain in their already sealed outside packets; this packet does not duplicate them or claim a new result.','No read-only partial current-CI snapshot is needed or included; original request failure and source/data epochs remain separately bounded.']
}
dump(H/'PACKET-FACTS.json',scope)
dump(H/'NESTED-ARCHIVES.json',{'count':len(nested),'safe_regular_members':sum(x['safe_regular_members'] for x in nested),'archives':nested})
for name in ('PACKET-FACTS.json','NESTED-ARCHIVES.json'): add(H/name,'preparation/'+name)
dump(H/'SOURCE.json',{'created_utc':datetime.now(UTC).isoformat(),'scope':'Inert copied/frozen original evidence only; no canonical access or actor execution.','original_inputs':inputs,'nested_safe_regular_members':sum(x['safe_regular_members'] for x in nested)})
add(H/'SOURCE.json','preparation/SOURCE.json')
O.mkdir(parents=True)
members=[]
with (O/'proof.tar.gz').open('xb') as output, gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as t:
    for name,p in sorted(files.items()):
        r=pin(p);b=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(b);info.mode=r['mode'];info.mtime=0;t.addfile(info,io.BytesIO(b))
        members.append({'path':name,'origin':str(p),**r})
check((O/'proof.tar.gz').stat().st_size<50*1024*1024,'compact proof bound')
with tarfile.open(O/'proof.tar.gz','r:gz') as t:
    ms=t.getmembers();check(len(ms)==len(members)==len({m.name for m in ms}),'packet unique count')
    for m,r in zip(ms,members,strict=True):
        b=t.extractfile(m).read();check(m.isfile() and safe(m.name) and m.name==r['path'] and len(b)==r['bytes'] and sha(b)==r['sha256'] and m.mode==r['mode'] and pin(Path(r['origin']))=={k:r[k] for k in ('bytes','sha256','mode','full_mode')},'packet original body/full-mode join')
for p,r in inputs.items(): check(pin(Path(p))==r,'final frozen input endpoint')

dump(O/'artifact.json',{'path':'proof.tar.gz',**pin(O/'proof.tar.gz')})
dump(O/'retention-manifest.json',{'regular_members':len(members),'members':members,'nested_archives':{'count':len(nested),'safe_regular_members':sum(x['safe_regular_members'] for x in nested),'inventory_in_proof':'preparation/NESTED-ARCHIVES.json'},'all_original_body_fullmodes_verified':True,'omissions':scope['omissions']})
dump(O/'summary.json',{'created_utc':datetime.now(UTC).isoformat(),'outcome':'SCOPED_SOURCE_CORRECTIONS_ADOPTED_FOCUSED_CHECKS_ACROSS_TWO_INDEX_EPOCHS','facts':scope,'packaging':{'inert_checks':checks,'original_input_endpoints':len(inputs),'proof_members':len(members),'nested_members':sum(x['safe_regular_members'] for x in nested),'canonical_mutation':False,'new_API_or_runtime_actor':False}})
(O/'README.md').write_text('''# Package and authorizer source corrections

The reviewed Windows Job v2, live-PR-head authorizer and coordinator helper pin were adopted into the working tree at historical HEAD `c930c86c83d478b3048d4cc80abd1346065e2e0d`. The two guarded source adoptions retain 2,378 source bodies and all 40 runtime byte/full-mode pins. The catalog preserves all old IDs and adds 30 Job controls, 32 authorizer controls and one loader control: 2,878 common plus two POSIX IDs. Source/fake checks record 37 Job, 156 authorizer and one loader test passing; different source reviews are retained.

The original focus remains failed. Eight checks pass, including 343 focused tests in 1.57 seconds and exact 2,880-ID collection; integrity then exits one because the tracked failed request was removed but not staged, and diff never runs. A separate successor stages exactly that one deletion, then integrity and `git diff --check HEAD` pass on identical source/runtime bodies, HEAD and tree. This is eight earlier successful checks plus two successor checks across an explicit index transition. It is not ten passing commands in one epoch. All twelve command children are reaped, groups absent, with no signals or timeouts. Linux Mypy covers 16 files and Win32 Mypy covers five fixture files; portability passes. The different factual actual-data review is clear after 6,012 joins and discloses its authorizer-source authorship.

Historical failures remain separate. The older f3 Windows package has Tauri exit zero but `terminated_job=true`, so the strict wrapper records failure; its actual cause remains unknown. The original R request reports `METADATA_GATE_FAILED`/opaque `ValueError` before download or native activity. A pure reproduction establishes the mutable PR-head authorization defect, without proving that it was the sole cause of that opaque historical failure. The exact 904-byte failed request is retained under SHA `9a88dac3505493f5f3da76db91e477d483591e2d6177419d86316447acbffffe` and is withdrawn; a future request requires fresh protected source and package authority.

This compact proof contains seven sealed source/review proofs, complete nested member/body/mode inventories, root adoption and focus drivers, raw command logs, before/after maps, catalogs, request retention and initial reader/focus failures. Disposable temporary trees and full Git/runtime binary payload bodies are omitted explicitly. The original outside parent paths and hashes remain available in the inventories. No canonical/API/native/model action was performed by this packager; tool interpreter custody is not inferred. No new full-suite, hosted CI, actual corrected Windows package, native GNOME/Windows, model, gate, milestone or release success follows. Formal progress remains 39/300 with M03-W07 in progress.
''')
(O/'README.md').chmod(0o644)
after={p.name:pin(p) for p in sorted(O.iterdir())}
check(set(after)=={'README.md','artifact.json','proof.tar.gz','retention-manifest.json','summary.json'},'five exact afterimages')
dump(H/'AFTERIMAGES.json',{'target':'docs/evidence/m03-package-and-authorizer-corrections','files':after})
dump(H/'QA.json',{'inert_checks':checks,'original_input_endpoints':len(inputs),'packet_regular_members':len(members),'nested_safe_regular_members':sum(x['safe_regular_members'] for x in nested),'proof':pin(O/'proof.tar.gz'),'all_source_origins_fullmode_endpoints_equal':True,'subject_actor_execution':False,'canonical_writes':False,'tool_interpreter_numeric_owner':'NOT_SEPARATELY_RETAINED','initial_gather_count_assumption_failure_retained':True,'source_review_and_actual_review_authorship_scopes_retained':True})
(H/'HANDOFF.md').write_text(f'''Five exact afterimages are ready under after/docs/evidence/m03-package-and-authorizer-corrections. proof.tar.gz is {after['proof.tar.gz']['bytes']} bytes, {len(members)} safe regular members; seven nested proofs bind {sum(x['safe_regular_members'] for x in nested)} original safe regular members. {checks} inert checks and {len(inputs)} original body/full-mode endpoint joins pass. No canonical/subject/API/native/runtime action. Exact old failures and the one-index-D successor epoch remain explicit; no new full/native/CI qualification. Root alone may adopt these five metadata files after review. Source/AFTERIMAGES/QA bind inputs and exact outputs; disposable projections/binary Git/runtime bodies are omitted explicitly.\n''')
manifest={}
for p in sorted(H.rglob('*')):
    if p.is_file() and p.name!='MANIFEST.json':manifest[p.relative_to(H).as_posix()]=pin(p)
dump(H/'MANIFEST.json',{'files':manifest,'scope':'Finite sealed outside preparation, five canonical-style afterimages only.'})
print(json.dumps({'path':str(H),'checks':checks,'members':len(members),'nested_members':sum(x['safe_regular_members'] for x in nested),'inputs':len(inputs),'afterimages':after,'pins':{n:pin(H/n) for n in ('SOURCE.json','AFTERIMAGES.json','QA.json','HANDOFF.md','MANIFEST.json')}}))
