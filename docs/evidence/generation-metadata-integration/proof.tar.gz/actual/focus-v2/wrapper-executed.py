from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import stat
import subprocess
import time

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
OUT = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/generation-metadata-integrated/focus-v2')
OUT.mkdir(exist_ok=False)
adoption = json.loads((OUT.parent / 'adoption.json').read_text())
paths = [r['path'] for r in adoption['changes']]
tests = [p for p in paths if '/tests/' in p]

def snapshot():
    raw = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=ROOT)
    result = {}
    for name in sorted(set(os.fsdecode(p) for p in raw.split(b'\0') if p)):
        p = ROOT / name
        info = p.lstat()
        assert stat.S_ISREG(info.st_mode), name
        result[name] = {'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
    return result

before = snapshot()
(OUT / 'before.json').write_text(json.dumps(before, indent=2, sort_keys=True) + '\n')
(OUT / 'wrapper-executed.py').write_bytes(Path(__file__).read_bytes())
(OUT / 'context.json').write_text(json.dumps({'start_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()}, indent=2) + '\n')
env = dict(os.environ)
env['PATH'] = '/opt/homebrew/opt/node@24/bin:' + env['PATH']
env['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
env['PYTHONDONTWRITEBYTECODE'] = '1'
uv = ['uv', 'run', '--no-sync', '--offline']
commands = [
    ('ruff', uv + ['ruff', 'check', *paths], 60),
    ('format', uv + ['ruff', 'format', '--check', *paths], 60),
    ('mypy', uv + ['mypy', '--cache-dir', str(OUT / 'mypy-cache'), *paths], 60),
    ('tests', uv + ['pytest', '-q', '-o', 'cache_dir=' + str(OUT / 'pytest-cache'), '--basetemp', str(OUT / 'pytest-temp'), *tests], 60),
    ('collection', uv + ['pytest', '--collect-only', '-q', '-o', 'cache_dir=' + str(OUT / 'collection-cache')], 60),
]
results = []
for name, argv, budget in commands:
    start = time.monotonic()
    signals = []
    timeout = False
    with (OUT / (name + '.log')).open('wb') as log:
        child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = child.wait(timeout=budget)
        except subprocess.TimeoutExpired:
            timeout = True
            for sig in (signal.SIGTERM, signal.SIGKILL):
                try:
                    os.killpg(child.pid, sig)
                    signals.append(sig.name)
                except ProcessLookupError:
                    pass
                if sig == signal.SIGTERM:
                    time.sleep(1)
            code = child.wait(timeout=10)
    try:
        os.killpg(child.pid, 0)
        group = 'PRESENT_AFTER_DIRECT_CHILD_REAP; NO_POST_REAP_SIGNAL'
    except ProcessLookupError:
        group = 'ABSENT'
    row = {'name': name, 'argv': argv, 'exit_code': code, 'timeout': timeout, 'seconds': time.monotonic() - start, 'direct_child_reaped': child.returncode is not None, 'observed_group': group, 'outer_cleanup_signals': signals}
    results.append(row)
    (OUT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    if code or group != 'ABSENT':
        break
after = snapshot()
(OUT / 'after.json').write_text(json.dumps(after, indent=2, sort_keys=True) + '\n')
closure = {'end_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'source_count': len(before), 'source_unchanged': before == after, 'executed_phases': len(results), 'all_pass': len(results) == len(commands) and all(r['exit_code'] == 0 and not r['timeout'] and r['observed_group'] == 'ABSENT' for r in results)}
(OUT / 'closure.json').write_text(json.dumps(closure, indent=2) + '\n')
print(json.dumps(closure), flush=True)
raise SystemExit(0 if closure['all_pass'] and before == after else 1)
