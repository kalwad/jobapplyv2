# Generation v6 narrow source and actual-data review

**CLEAR_FOR_SCOPED_V6_INTEGRATION.** The exact one-line header correction resolves v5 review note `GEN-HTTP-001`. No blocking finding remains in this delta/data review. This is an independent read-only review by `/root/desktop_shell_harness_review` on 2026-10-28; it ran no subject import, test, browser, model or native actor and made no canonical writes.

The reviewed v5 baseline is independently cleared with the retained nonblocking header note. Its selected manifest SHA-256 is `e7c8371c68a73c0fb7792515089d3f056a54e8ddd4b4a71e455519f1b3fa08ca`. I checked that earlier review's four retained payloads, its exact v5 manifest/patch binding and all82 recorded passing data checks. I then checked all25 v5 and29 v6 selected manifest members against actual lengths/hashes.

The v6 selected manifest is `6a55a4d3c09c7c743bcb237f7841244b49a522d01004419b06f69e1b75d7e189`. The complete12-addition patch is `683c900d7cb28e2e4edbaad1cb97396a8e8e3a0b9e1a27430864fef1943eee32`; the two-path delta is `823a91037d316eb429ca555215c9790308afee071fbf711e8364c3e25dc43f6c`. Both patches independently rebuild byte-for-byte from the afterimages. All ten other v5 afterimages, including all six prior test files, remain byte-identical.

The only production change is `value.decode("ascii").strip()` to `value.decode("ascii").strip(" \t")` in `_headers`. Reverting that argument reproduces the exact v5 transport bytes/AST. The existing control-character rejection still follows decoding/trimming, so VT, FF, FS, GS, RS and US at either value edge remain visible to the refusal check. Valid SP/HTAB optional whitespace still trims. No HTTP route, destination, resource ceiling, cancellation, deadline, candidate schema, audit or release policy changes.

The new test declares exactly six forbidden controls × two edges and three positive SP/HTAB cases. It uses the existing deterministic transport/body fixtures and checks PROTOCOL refusal plus socket abort; positives check exact body and abort. The retained negative source and final new test have identical non-import AST and identical import identities; their only change is import ordering. The initial one-error Ruff I001 result is preserved separately by the matching first-run hash.

| Retained actual result | Independent verification |
|---|---|
| Exact v5 production plus new tests:12failed,3passed in0.15s, exit1 | Original transport/test hashes match. All12distinct failure IDs are exactly the malformed-control combinations, each reports DID NOT RAISE; the three valid-OWS cases passed. |
| Corrected v6:119collected,119ordinary passing cases in0.20s | Raw collection IDs/hash exactly match the record; all104prior IDs remain an unchanged prefix, with exactly15new header cases. No skipped/xfail outcome is substituted. |
| Strict Ruff, format, strict Mypy, collection and tests | All five recorded commands exit0 with no timeout. Raw logs match recorded lengths/hashes. Formatting reports12files; Mypy reports12source files. |
| Frozen actor inputs | All15selected source/config hashes match before/after, current subject and final export. The recorded wrapper uses pinned Python3.12.13 with `-I -S -B`, asserts derivative module origins, bounds each command30s and keeps caches in that owned derivative. |

`CHECKS.json` records all71independent passing checks and exact input hashes; `audit.py` is the read-only verifier. This review checks retained measured data rather than relaunching actors during the W11 browser campaign.

Integration remains limited to the candidate-generation boundary. V6 does not establish a completed M05 work package, a qualified/locked model, native runtime digest verification, factual/atomic-claim verification, Gate B acceptance or release permission. The previously reviewed single-event-loop/trusted-adapter cancellation contract remains unchanged.
