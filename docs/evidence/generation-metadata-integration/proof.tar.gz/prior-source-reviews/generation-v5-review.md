# Independent final generation-boundary review

Decision: **CLEAR for scoped integration, with one nonblocking parser note**.
Subject: `generation-review/v5/final-after/`, source patch SHA-256
`4866fb7e63eec13ab3e47a8ea3382df6068653847c4af4bb9a61de7e2bb91317`.
This is an internal candidate boundary, not M05-W03, M05 or product completion.

I inspected all five implementation modules and six test modules, the final
runner/export source, HANDOFF, SOURCE_PLAN, VALIDATION and ORACLES. The 82
independent data checks in CHECKS.json pass: all 11 adoption afterimages equal
the actual validated subject and exact patch; all 14 input/config projections
remain equal; all five retained final command logs match their recorded hashes
and exit zero; collection has 104 unique IDs and execution reports 104 PASS.
The original 99 IDs retain their exact order. An independent AST comparison
preserves all 178 assertion predicates and original test names/parameter cases.
The five added cases exercise actual owned synthetic loopback HTTP, including
fixed, chunked and EOF bodies and peer closure after cancel/disconnect.

The typed operation/content/audit split preserves the candidate-only boundary.
Cancellation remains sticky at admission and publication; original cancellation
survives synchronous close failure. Open and each read retain their original
absolute idle interval inside the one total deadline, including synchronous
overruns and malformed-output repair. A returned stream enters unconditional
close handling before any post-open admission refusal. No partial candidate
result is published. Ordinary supported transport/asyncio timeout behavior does
not erase a caller cancellation count.

The cancellation conclusion assumes the declared one-event-loop, trusted
in-process adapter contract: adapters do not explicitly manipulate another
owner's Task cancellation counters. I considered an erase-and-replace counter
example requiring an adapter to uncancel the client's request, then swallow a
new caller cancel. That is outside this contract, is not reachable from the
current LocalOllamaTransport or remote output, and is not a blocking finding.
The pinned Python 3.12 timeout implementation was read as source: its normal
timeout scope removes its own delivered count. No subject reproduction was run.

HTTP uses a literal IPv4 loopback host, numeric addressing, fixed `/api/chat`,
explicit framing limits and no URL/proxy/redirect/credential facility. Closed
strict JSON/schema checks, duplicate-member rejection, model identity, bounded
frames/content, allowed evidence membership and one schema-only repair remain
present. These establish reference membership, not factual support. The fake
external seam requires explicit opt-in and synthetic context. Results retain
`release_permitted=False`, pending atomic-claim verification and unverified
runtime digest. No route, secure store, qualified model, prompt loader or live
Ollama/model acceptance is supplied by this slice.

Nonblocking source note GEN-HTTP-001: transport.py:67 calls unrestricted
`value.decode("ascii").strip()` before validating control characters. A header
such as `Content-Type: \x0bapplication/x-ndjson` loses its leading vertical tab
and is accepted; the same applies to trailing vertical-tab/form-feed whitespace.
Use `strip(" \t")` so unsupported C0 controls survive until rejection, with
small parser counterexamples. This is source reasoning, not an executed failure.
It does not change the fixed destination, closed framing or candidate/release
authority, so it does not block this scoped integration.

This reviewer performed source reads, AST/data comparisons and file hash joins
only: no subject imports, tests, network/model/native actors or canonical edits.
Canonical integration still needs its own full collection/inventory update and
relevant repository verification; no derivative PASS transfers automatically.
