from pathlib import Path
import json, hashlib, zipfile, csv, io, base64, stat
REPO=Path('/Users/tanishkalwad/jobapplyv2')
BASE=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
B=BASE/'generation-metadata-integrated'
OUT=BASE/'generation-metadata-integrated-independent-review'
sha=lambda x:hashlib.sha256(x).hexdigest()
def audit_wheel(path,source_root=None,namespace='orchestrator'):
 with zipfile.ZipFile(path) as z:
  infos=z.infolist();names=[i.filename for i in infos]
  assert len(names)==len(set(names))
  assert all(not Path(n).is_absolute() and '..' not in Path(n).parts and '\\' not in n for n in names)
  assert all(not i.is_dir() and stat.S_IFMT(i.external_attr>>16) in [0,stat.S_IFREG] for i in infos)
  package={n:z.read(n) for n in names if n.startswith(namespace+'/')};metadata=namespace+'-0.0.1.dist-info/'
  assert all(n.startswith(namespace+'/') or n in {metadata+'METADATA',metadata+'WHEEL',metadata+'RECORD'} or n.startswith(metadata+'licenses/') and n.endswith(('.txt','.md')) for n in names)
  wheel_text=z.read(metadata+'WHEEL').decode();assert 'Root-Is-Purelib: true' in wheel_text and 'Tag: py3-none-any' in wheel_text
  rows=list(csv.reader(io.StringIO(z.read(metadata+'RECORD').decode())));assert {row[0] for row in rows}==set(names)
  checked=0
  for n,h,s in rows:
   if n==metadata+'RECORD':assert not h and not s;continue
   data=z.read(n);assert int(s)==len(data);assert h=='sha256='+base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b'=').decode();checked+=1
  source_match=None
  if source_root is not None:
   current={str(p.relative_to(source_root)):p.read_bytes() for p in (source_root/namespace).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
   assert current==package;source_match=True
  return {'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'package_files':len(package),'package_python_files':sum(n.endswith('.py')for n in package),'zip_members':len(names),'record_hash_rows_checked':checked,'restricted_pure_surface':True,'source_package_bytes_match':source_match,'metadata_sha256':sha(z.read(metadata+'METADATA')),'package_sha256':{n:sha(data)for n,data in package.items()}}
report=[audit_wheel(B/name)for name in ['orchestrator-wheel-before.whl','wheel-build/orchestrator-0.0.1-py3-none-any.whl','v3-wheel-before.whl','wheel-build-v3/orchestrator-0.0.1-py3-none-any.whl']]
report.append(audit_wheel(REPO/'packaging/native-project-wheels/orchestrator-0.0.1-py3-none-any.whl',REPO/'services/orchestrator/src'))
report.append(audit_wheel(REPO/'packaging/native-project-wheels/japp_contracts-0.0.1-py3-none-any.whl',REPO/'packages/contracts/generated/python/src','japp_contracts'))
(OUT/'wheel-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'wheel_objects':len(report),'record_hash_rows':sum(x['record_hash_rows_checked']for x in report),'source_matches':sum(x['source_package_bytes_match']is True for x in report)}))
