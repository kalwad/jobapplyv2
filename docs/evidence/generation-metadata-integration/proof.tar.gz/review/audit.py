from pathlib import Path
import json,hashlib,re,subprocess,tomllib,zipfile
REPO=Path('/Users/tanishkalwad/jobapplyv2')
BASE=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
B=BASE/'generation-metadata-integrated'
OUT=BASE/'generation-metadata-integrated-independent-review'
checks=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
def check(name,value,detail=None):
 checks.append({'check':name,'pass':bool(value),'detail':detail})
 if not value: raise AssertionError(name)
def read(name):return json.loads((B/name).read_text())
adoption=read('adoption.json'); initial={r['path']:r for r in adoption['changes']};final={p:dict(row)for p,row in initial.items()}
for row in read('v3-adoption.json')['changes']:
 check('v3-original-preimage:'+row['path'],initial[row['path']]['sha256']==row['before_sha256'])
 final[row['path']]={'path':row['path'],'sha256':row['after_sha256'],'bytes':row['after_bytes']}
check('exact17-adopted-source-paths',len(initial)==len(final)==17)
for p,row in final.items():
 data=(REPO/p).read_bytes();check('current-final-source:'+p,len(data)==row['bytes'] and sha(data)==row['sha256'])
generation_after=BASE/'generation-review/v6/final-after'
metadata_after=BASE/'model-runtime-source/revisions/v3/after'
for path,row in final.items():
 reviewed=(generation_after if '/generation/' in path or '/test_generation_' in path else metadata_after)/path
 check('reviewed-afterimage-to-current:'+path,reviewed.read_bytes()==(REPO/path).read_bytes())
phases=[]; snapshots={};collection_ids={};focus_ids={}
for version,expected_count,expected_phases in [('focus-v1',None,4),('focus-v2',202,5),('focus-v3',224,5)]:
 before=read(version+'/before.json');after=read(version+'/after.json');snapshots[version]=before;closure=read(version+'/closure.json');results=read(version+'/results.json');context=read(version+'/context.json')
 check(version+':reference-head',context['head']=='35b46287dc754a5987d653490ab49f978647ca26')
 check(version+':full-source-byte-mode-endpoints',before==after and len(before)==closure['source_count'],{'source_files':len(before)})
 check(version+':expected-closure',closure['executed_phases']==expected_phases and closure['all_pass']==(version!='focus-v1') and closure['source_unchanged'])
 check(version+':phase-count',len(results)==expected_phases)
 targets=set(initial)
 for result in results:
  name=result['name'];argv=result['argv'];phases.append({'version':version,**result})
  check(version+':argv-prefix:'+name,argv[:4]==['uv','run','--no-sync','--offline'])
  check(version+':ownership:'+name,result['direct_child_reaped'] and result['observed_group']=='ABSENT' and not result['timeout'] and not result['outer_cleanup_signals'])
  check(version+':exit:'+name,result['exit_code']==(2 if version=='focus-v1' and name=='tests' else 0))
  if name in ['ruff','format','mypy']:
   check(version+':all17-targets:'+name,{x for x in argv if x in targets}==targets)
  if name=='tests':check(version+':all9-focus-files',{x for x in argv if x.endswith('.py')}=={p for p in targets if '/tests/' in p})
 for name,text in [('ruff','All checks passed!'),('format','17 files already formatted'),('mypy','Success: no issues found in 17 source files')]:
  check(version+':inner-'+name,(B/version/(name+'.log')).read_text().strip()==text)
 expected_sources=final if version=='focus-v3' else initial
 for p,row in expected_sources.items():check(version+':source-binding:'+p,before[p]['sha256']==row['sha256'] and before[p]['bytes']==row['bytes'])
 if version=='focus-v1':
  log=(B/version/'tests.log').read_text();check('first-actual-five-import-errors',log.count("E   ModuleNotFoundError: No module named 'services'")==5 and log.rstrip().endswith('5 errors in 0.17s'))
 else:
  log=(B/version/'tests.log').read_text();check(version+':ordinary-pass-summary',re.search(rf'^{expected_count} passed in [0-9.]+s$',log,re.M) is not None and not re.search(r'\b(?:failed|skipped|xfailed|xpassed|ERROR)\b',log))
  cache=read(version+'/pytest-cache/v/cache/nodeids');focus_ids[version]=set(cache);check(version+':focus-nodeids',len(cache)==len(set(cache))==expected_count)
  lines=[x.strip()for x in (B/version/'collection.log').read_text().splitlines()if x.strip()];summary=lines.pop();count=int(re.fullmatch(r'(\d+) tests collected in [0-9.]+s',summary)[1]);check(version+':raw-collection-distinct',len(lines)==len(set(lines))==count)
  collection_ids[version]=set(lines);check(version+':focus-ids-in-full-collection',set(cache)<=set(lines))
check('v1-v2-only-config-changed',[p for p in sorted(snapshots['focus-v1'])if snapshots['focus-v1'][p]!=snapshots['focus-v2'][p]]==['pyproject.toml'])
old_config=subprocess.check_output(['git','show','35b46287dc754a5987d653490ab49f978647ca26:pyproject.toml'],cwd=REPO)
new_config=(REPO/'pyproject.toml').read_bytes();check('config-before-exact-reference',sha(old_config)==snapshots['focus-v1']['pyproject.toml']['sha256']);check('config-after-exact-tested',sha(new_config)==snapshots['focus-v2']['pyproject.toml']['sha256']==snapshots['focus-v3']['pyproject.toml']['sha256'])
a=tomllib.loads(old_config.decode());b=tomllib.loads(new_config.decode());old_options=a['tool']['pytest']['ini_options'];new_options=b['tool']['pytest']['ini_options'];check('only-semantic-config-change',old_options['pythonpath']==['packages/contracts/generated/python/src'] and new_options['pythonpath']==['.','packages/contracts/generated/python/src']);old_options['pythonpath']=new_options['pythonpath'];check('all-other-config-and-strictness-unchanged',a==b)
pytest_source=REPO/'.venv/lib/python3.12/site-packages/_pytest/config/__init__.py';pytest_text=pytest_source.read_text();check('pytest-config-relative-root-source', 'return [dp / x for x in input_values]' in pytest_text and 'self.inipath.parent' in pytest_text and 'for path in reversed(self.getini("pythonpath")):' in pytest_text and 'sys.path.insert(0, str(path))' in pytest_text)
inv={name:read(name)for name in ['inventory-before.json','inventory-after.json','v3-inventory-before.json','v3-inventory-after.json']}
for name,value in inv.items():
 ids=value['common']['node_ids'];check(name+':canonical-common-list',ids==sorted(ids) and len(ids)==len(set(ids))==value['common']['count'] and sha(('\n'.join(ids)+'\n').encode())==value['common']['sha256'])
 check(name+':exact-posix-pair',value['posix_only_node_ids']==inv['inventory-before.json']['posix_only_node_ids'] and len(value['posix_only_node_ids'])==2)
check('initial-inventory-equals-reference',json.loads(subprocess.check_output(['git','show','35b46287dc754a5987d653490ab49f978647ca26:scripts/python-test-inventory.v1.json'],cwd=REPO))==inv['inventory-before.json'])
check('v2-inventory-join',inv['inventory-after.json']==inv['v3-inventory-before.json'])
for version,name,count in [('focus-v2','inventory-after.json',2062),('focus-v3','v3-inventory-after.json',2084)]:
 value=inv[name];ids=set(value['common']['node_ids'])|set(value['posix_only_node_ids']);check(version+':raw-collection-to-inventory',ids==collection_ids[version] and len(ids)==count)
check('all1858-old-common-identities-retained',set(inv['inventory-before.json']['common']['node_ids'])<=set(inv['v3-inventory-after.json']['common']['node_ids']))
check('v2-added202-exact-focus',set(inv['inventory-after.json']['common']['node_ids'])-set(inv['inventory-before.json']['common']['node_ids'])==focus_ids['focus-v2'])
check('v3-added22-exact-runtime-delta',len(focus_ids['focus-v3']-focus_ids['focus-v2'])==22 and focus_ids['focus-v2']<=focus_ids['focus-v3'] and all('/test_runtime_metadata.py::'in x for x in focus_ids['focus-v3']-focus_ids['focus-v2']))
check('final-canonical-inventory-exact',json.loads((REPO/'scripts/python-test-inventory.v1.json').read_text())==inv['v3-inventory-after.json'])
wheels=json.loads((OUT/'wheel-audit.json').read_text());wmap={Path(x['path']).name+':'+str(Path(x['path']).parent):x for x in wheels};check('original-wheel-hash-chain',[x['sha256']for x in wheels[:5]]==['6ef4e59987a42d0a4b34d9bb8507537616e7d83913133b2d5a55bbb83b5e6052','448a9a641d3b68df57cd6b060ba0ac38c510c0404e62c549b497b3b462ca52ae','448a9a641d3b68df57cd6b060ba0ac38c510c0404e62c549b497b3b462ca52ae','cdc50bdbc6e7edd3be54e4dfe0dd82f1fc3546399858f2c36a878d9ce17a108a','cdc50bdbc6e7edd3be54e4dfe0dd82f1fc3546399858f2c36a878d9ce17a108a'])
check('wheel-project-metadata-unchanged',len({x['metadata_sha256']for x in wheels[:5]})==1)
check('wheel-old10-package-files-preserved',all(wheels[4]['package_sha256'][p]==h for p,h in wheels[0]['package_sha256'].items()))
check('wheel-v3-only-one-package-member-changed',[p for p,h in wheels[1]['package_sha256'].items()if wheels[4]['package_sha256'][p]!=h]==['orchestrator/runtime/metadata.py'])
for p,row in initial.items():
 if '/src/orchestrator/'in p:
  name='orchestrator/'+p.split('/src/orchestrator/',1)[1];check('v2-built-wheel-source:'+name,wheels[1]['package_sha256'][name]==row['sha256'])
for p,row in final.items():
 if '/src/orchestrator/'in p:
  name='orchestrator/'+p.split('/src/orchestrator/',1)[1];check('v3-built-and-adopted-wheel-source:'+name,wheels[3]['package_sha256'][name]==row['sha256']==wheels[4]['package_sha256'][name])
check('final-wheels-both-current-source-match',all(x['source_package_bytes_match'] for x in wheels[4:]))
lock=json.loads((REPO/'packaging/native-project-wheels.json').read_text());check('final-wheel-lock-matches-actual-files',lock['orchestrator']['sha256']==wheels[4]['sha256'] and lock['contracts']['sha256']==wheels[5]['sha256']);check('contracts-wheel-and-lock-unchanged',read('native-project-wheels-before.json')['contracts']==read('v3-wheel-lock-before.json')['contracts']==lock['contracts'])
receipt=read('v3-wheel-adoption.json');check('v3-build-log-and-receipt',receipt['build_exit_code']==0 and receipt['build_stdout_stderr']=='wheel-build-v3.log' and 'Successfully built' in (B/'wheel-build-v3.log').read_text() and receipt['source_match']['wheel_sha256']==wheels[3]['sha256']);check('no-runtime-payload-rebuild-claimed',receipt['no_runtime_payload_rebuild'] and read('wheel-adoption.json')['runtime_rebuilt']==False)
summary={'scope':'CLEAR_SOURCE_BOUND_INTEGRATED_FOCUS_COLLECTION_AND_PURE_WHEEL_DATA','check_count':len(checks),'passed':sum(x['pass']for x in checks),'canonical_writes':0,'reruns_imports_native_or_model_actors':0,'focus_v1':{'actual_import_collection_errors':5,'pytest_exit':2,'source_files':2026},'focus_v2':{'ordinary_passes':202,'full_collected':2062,'common_inventory':2060,'source_files':2026},'focus_v3':{'ordinary_passes':224,'full_collected':2084,'common_inventory':2082,'source_files':2031},'original_common_ids_retained':1858,'posix_only_unchanged':2,'observed_direct_children':14,'direct_children_reaped_and_groups_absent':14,'outer_cleanup_signals':0,'final_wheel_sha256':wheels[4]['sha256'],'contracts_wheel_sha256':wheels[5]['sha256'],'first_wheel_serializer_error':'REPORTED_OBSERVER_BOOKKEEPING_FAILURE_ONLY_RAW_NOT_RETAINED','tool_output_only_24_pass_checks':'OMITTED_FROM_DURABLE_PROOF','current_whole_tree_transfer':False,'states':{'M03-W06':'IN_PROGRESS','M03':'IN_PROGRESS','verified':38,'M05':'NOT_STARTED','release':'NOT_READY'}}
(OUT/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n');(OUT/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');(OUT/'phase-audit.json').write_text(json.dumps(phases,indent=2)+'\n');print(json.dumps(summary,indent=2))
