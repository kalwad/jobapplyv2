from pathlib import Path
import hashlib,json,os,subprocess,time
ROOT=Path('/Users/tanishkalwad/jobapplyv2')
OUT=Path('/tmp/japp-w14-build-result-affected-20261016')
assert not OUT.exists()
NODE='/opt/homebrew/opt/node@24/bin/node'
ENV=os.environ.copy();ENV['PATH']=str(Path(NODE).parent)+os.pathsep+ENV['PATH']
ENV['PLAYWRIGHT_JSON_OUTPUT_NAME']=str(OUT/'results.json')
SPECS=['extension-w14-result-ownership-peer.spec.ts','extension-w14-independent-undo-hash.spec.ts','extension-w14-native-validity.spec.ts','extension-w14-independent-extra.spec.ts','extension-w14-focus-value.spec.ts']
ARGV=['pnpm','exec','playwright','test',*['e2e/extension/'+n for n in SPECS],'--trace','on','--output',str(OUT/'artifacts'),'--reporter=list,json']
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT).decode().strip()
def capture():
 rows=[]
 for name in subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0'):
  if name:
   b=(ROOT/name).read_bytes();rows.append({'path':name,'bytes':len(b),'sha256':sha(b)})
 return {'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain=v1'),'tracked_files':rows,'tracked_digest':sha(json.dumps(rows,separators=(',',':')).encode()),'captured_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
def write(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n')
BEFORE=capture()
assert BEFORE['head']=='fc48930fd880795f72972fd97e2e69d68e636855'
assert BEFORE['status']=='M apps/extension/src/driver-engine.ts'
assert sha((ROOT/'apps/extension/src/driver-engine.ts').read_bytes())=='22071b77f7610b315dc58f51275d3703f895c92f5f6c919f2efbbd275a312557'
OUT.mkdir();write('before.json',BEFORE)
write('command.json',{'argv':ARGV,'cwd':str(ROOT),'node_path':NODE,'script_sha256':sha(Path(__file__).read_bytes()),'task_environment':{'PLAYWRIGHT_JSON_OUTPUT_NAME':ENV['PLAYWRIGHT_JSON_OUTPUT_NAME']},'runtime_digest':'sha256:3b6c0e0c0950b03e3bb9e1f12b27bb8d385174c36fb4b68ef3345597aa8b3502','started_at':BEFORE['captured_at']})
with (OUT/'run.log').open('wb') as stream:code=subprocess.run(ARGV,cwd=ROOT,env=ENV,stdout=stream,stderr=subprocess.STDOUT).returncode
AFTER=capture();write('after.json',AFTER)
build=[]
for p in sorted((ROOT/'apps/extension/dist/chrome-mv3').rglob('*')):
 if p.is_file():
  b=p.read_bytes();build.append({'path':p.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':sha(b)})
write('built-extension-after.json',build)
result={'exit_code':code,'head_unchanged':BEFORE['head']==AFTER['head'],'source_unchanged':BEFORE['tracked_files']==AFTER['tracked_files'],'status_unchanged':BEFORE['status']==AFTER['status'],'ended_at':AFTER['captured_at'],'built_extension_observation':'AFTER_FRESH_GLOBAL_SETUP_AND_TESTS'}
write('completion.json',result);print(json.dumps(result),flush=True)
raise SystemExit(code if all(result[k] for k in ['head_unchanged','source_unchanged','status_unchanged']) else 2)
