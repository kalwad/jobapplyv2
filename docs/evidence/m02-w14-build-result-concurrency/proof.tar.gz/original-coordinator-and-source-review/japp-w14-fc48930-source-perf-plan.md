# Read-only performance diagnosis preparation — fc48930

Revision: `fc48930fd880795f72972fd97e2e69d68e636855`. Root remained frozen during this review. No source patch, build, browser, profiler, benchmark rerun or process interference was performed.

## What the retained run proves

Source: the complete `W13_SCALING` console line in `/tmp/japp-w14-focus-frozen-20261016/aggregate.log`. Its SHA256 is `351b6ea96d7a74270516d1193da949fbb7178ece1c5e4f4d2551d68a4358957d`. Exact22 rows plus derived observations are saved in `/tmp/japp-w14-fc48930-source-perf-observations.json`. The current failure trace was not retained before a later controlled suite removed default outputs; this report does not claim to have inspected one.

The20 native128 samples have wall min1190.388584ms, median1327.6112085ms, p95 **1527.943333ms**, max1537.971667ms. The original1500ms assertion fails by27.943333ms. Page CDP TaskDuration is480.454–617.227ms (median566.209ms); cumulative scanner time is81.419–111.159ms (median96.605ms).

Every sample has exactly512 fresh resolutions,768 descriptors, one identity-index rebuild,511 index hits, zero index invalidations, three candidate enumerations and128 identity pairs. There is no observed variable work-count/index-recovery explosion. Each sample records249744 topology host checks, but topology's measured total is17.948–25.651ms. That large count alone does not establish the dominant wall-time cause or enough savings to meet the target.

The benchmark times initial scan,128 real W09 approvals/transaction construction, four sequential batches of32 W10 actions, and final complete W11 reconciliation. CDP page TaskDuration excludes some Node/controller/service-worker/IPC work. Scanner timers overlap and include awaited regions; they are not disjoint CPU accounting. Subtracting either timer from wall time cannot identify hashing, timers or transport as the residual cause. The largest wall sample is not the largest page-task sample. Variance is present, but it does not invalidate the failure or authorize rerunning until passing.

## Concrete source work and narrow candidates

1. **Native acceptance witness reads an unused message on accepted controls.** `drivers/driver-dom.ts:117–128` captures/compares `validationMessage` unconditionally. `readSiteAcceptance` consumes it only inside `willValidate && !validity.valid`. A correctness-preserving candidate retains both scalar snapshots for every native source, then captures/compares the message only for that exact rejection branch. Any final willValidate/valid change must fail before the conditional message comparison. Thus valid→invalid races still refuse and invalid→invalid message drift remains observed. Source establishes redundant native getter calls; their timing impact is unmeasured. No native acceptance source or final fence may be removed.

2. **Same element is inspected twice within one acceptance call.** For default native candidates the scanner's members include the anchor, and callers pass `[anchor,...members]`. `readSiteAcceptance` currently loops over both while native witness capture already deduplicates. Identity deduplication confined to one synchronous acceptance read can preserve every distinct source, rejection precedence and message ordering. It must not cache acceptance across awaits. Again, call duplication is concrete; timing benefit is not measured.

3. **Scanner descriptor construction serially awaits independent immutable hashes.** `field-scanner.ts:941–1033` has independent string-derived fingerprint/label work around dependent address identity. This is a possible later scheduling candidate, not the preferred first correction: preserve all live DOM reads, all768 descriptor builds, all512 resolutions, original seed/output bytes, final index/root checks and current option snapshot behavior. Do not cache a descriptor or ownership/visibility decision across awaits. No scanner patch is proposed here.

4. **Driver result metadata has seven independent immutable hash operations.** The separate state-model reviewer owns the requested one-file proposal using bounded seven-way scheduling, allSettled and original-order unwrap. Peer review should verify exact seeds/output structure, exact original rejection identity/precedence, all final publication/property/validity/index fences after the aggregate, and no changed await in the native mutation path. Parallel scheduling changes cache-touch/completion order and may wait for later jobs on a rejection; it cannot be called timing-equivalent. No timing benefit is established until a controlled comparison. No duplicate patch was authored by this reviewer.

### Exact buildResult proposal peer review

Read-only peer review completed on `/tmp/japp-w14-build-result-concurrency/build-result-concurrency.patch`, SHA256 `3857cd00eac7fe638a7133ce7dc60c6191e1beaaa5dfb40db5604e59c00874c5`. Its preimage SHA256 `9fc5287957ad148aad2cc449244427c9a2d731470dd267088396b534ed340ed4` matches the frozen root file; afterimage SHA256 is `b6d3b937e5b62704e6f389e92227653dd42f3fb701baf6de9b6f427d121d887d`.

No source-level safety/output defect was found. The diff contains only a private raw-reason unwrap helper and `buildResult` metadata scheduling/assignment. The seven jobs are result ID, driver ID, attempt ID, idempotency key, intended evidence, immediate evidence and settled evidence. Each exact seed/input and output field order remains unchanged. All helpers are async, so their thrown reasons become outcomes; allSettled installs handlers for every job, then source-order unwrap selects the same earliest original rejection identity rather than whichever job finishes first. Per-build concurrency is exactly seven; no new cache/budget exists.

EXECUTE and UNDO final native property/validity, option/ownership and index/revision checks remain after the awaited result aggregate. A held idempotency hash still prevents that aggregate from completing even if other jobs finish earlier. W11 publication fences are unmodified. No async work was moved into the physical mutation or final synchronous fence.

This is successful-output/source-equivalence review, not a proof of identical failure timing: all seven jobs now start, and an early original-slot rejection waits for the remaining jobs before propagating. Completion/eviction scheduling can differ while cache limits remain unchanged. Focused byte/seed, multiple-rejection reason precedence, immutable hash-pause/native-validity regressions and actual timing are still required. No typecheck, tests, runtime execution or patch application was performed by this peer reviewer.

## Keep unchanged

Keep the1500ms threshold,8/32/128 workloads,20 target samples, physical128 actions, full required inventory, cache1024/512KiB/4096 limits, all load-bearing live resolutions and all final native validity/property/ownership/option fences. Keep the zero-settle asynchronous task/yield: removing it would change the workload and pending-handler semantics. Do not cache topology/visibility/ownership across an await; eventless attachShadow, CSS and native constraint changes require their existing fresh coverage. The newly fixed setCustomValidity race must not return.

ADR-0005's safety/measurement constraints remain relevant historical guidance; it is not a new waiver or an instruction to reuse an exhausted correction budget. This diagnosis proposes no threshold or compatibility change.

## Bounded follow-up after root releases the frozen run

Review one concrete pure-work change first. Retain this failed run and exact source binding. In an isolated checkout, verify exact byte/seed agreement plus original-order rejection behavior and rerun immutable native-validity/property/hash-pause regressions and existing error-clearing positives. Only after correctness checks and explicit quiet-window coordination, compare the same fixed workload and complete affected canonical regression. Record all results, including failures; do not use repeated runs to select a passing sample. If measured timing attribution is needed, add bounded external diagnostic phase timings rather than replacing the canonical timer or claiming a cause from aggregate counters.
