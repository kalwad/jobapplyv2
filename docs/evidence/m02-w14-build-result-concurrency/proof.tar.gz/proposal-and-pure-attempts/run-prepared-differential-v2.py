from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys

root = Path('/tmp/japp-w14-build-result-concurrency')
repo = Path('/Users/tanishkalwad/jobapplyv2')
number = 1
while (root / f'attempt-{number:03d}.json').exists():
    number += 1
attempt = f'attempt-{number:03d}'
source_paths = [
    'apps/extension/src/driver-engine.ts',
    'apps/extension/src/driver-evidence.ts',
    'apps/extension/src/driver-protocol.ts',
    'apps/extension/src/semantic-identity.ts',
]
artifact_paths = [
    'driver-engine.preimage.ts',
    'driver-engine.corrected-afterimage.ts',
    'validate-build-result-differential-v2.mjs',
    'proposal-manifest-v2.json',
    'run-prepared-differential-v2.py',
]
def digest(path):
    return 'sha256:' + hashlib.sha256(path.read_bytes()).hexdigest()
def sources():
    return [{'path': str(repo / path), 'digest': digest(repo / path)} for path in source_paths]
def artifacts():
    return [{'path': str(root / path), 'digest': digest(root / path)} for path in artifact_paths]
record = {
    'scope': 'PURE_METADATA_DIFFERENTIAL_ONLY',
    'authority': 'NONE',
    'attempt': attempt,
    'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'root_source_before': sources(),
    'proposal_artifacts_before': artifacts(),
    'stdout_path': str(root / f'{attempt}.stdout.log'),
    'stderr_path': str(root / f'{attempt}.stderr.log'),
}
code = 1
try:
    node = shutil.which('node')
    if node is None:
        raise RuntimeError('NODE_UNAVAILABLE')
    version = subprocess.check_output([node, '--version'], text=True).strip()
    record['node_path'] = node
    record['node_version'] = version
    if not version.startswith('v24.'):
        raise RuntimeError('NODE24_REQUIRED')
    if record['root_source_before'][0]['digest'] != digest(root / 'driver-engine.corrected-afterimage.ts'):
        raise RuntimeError('ROOT_CORRECTED_SOURCE_MISMATCH')
    env = os.environ.copy()
    env['JAPP_W14_ALLOW_DIFFERENTIAL_EXECUTION'] = '1'
    command = [node, str(root / 'validate-build-result-differential-v2.mjs')]
    record['command'] = command
    with (root / f'{attempt}.stdout.log').open('w') as out, (root / f'{attempt}.stderr.log').open('w') as err:
        result = subprocess.run(command, cwd=root, env=env, stdout=out, stderr=err, timeout=60)
    code = result.returncode
    record['exit_code'] = code
except Exception as error:
    record['execution_error'] = str(error)
    record['exit_code'] = code
finally:
    record['ended_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    record['root_source_after'] = sources()
    record['proposal_artifacts_after'] = artifacts()
    record['root_sources_unchanged'] = record['root_source_before'] == record['root_source_after']
    record['proposal_artifacts_unchanged'] = record['proposal_artifacts_before'] == record['proposal_artifacts_after']
    report = root / 'differential-report.json'
    record['differential_report_digest'] = digest(report) if report.exists() else None
    (root / f'{attempt}.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'attempt': attempt, 'node_version': record.get('node_version'), 'exit_code': code,
                      'root_sources_unchanged': record['root_sources_unchanged'],
                      'proposal_artifacts_unchanged': record['proposal_artifacts_unchanged'],
                      'record': str(root / f'{attempt}.json')}, indent=2))
sys.exit(code)
