/** Pure metadata differential only; prepared outside the repository.
 * No production exports/hooks, browser proof or canonical-contract proof.
 * Run only after the frozen verification ends and the root releases it.
 */
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

if (process.env.JAPP_W14_ALLOW_DIFFERENTIAL_EXECUTION !== "1") {
  throw new Error("W14_DIFFERENTIAL_EXECUTION_NOT_RELEASED");
}
const directory = dirname(fileURLToPath(import.meta.url));
const manifestBytes = readFileSync(join(directory, "proposal-manifest-corrected.json"));
const manifest = JSON.parse(manifestBytes.toString("utf8"));
const taskRequire = createRequire(join(manifest.repository_root, "package.json"));
const ts = taskRequire("typescript");
const sha = (value) => `sha256:${createHash("sha256").update(value).digest("hex")}`;
for (const artifact of manifest.artifacts) {
  assert.equal(sha(readFileSync(join(directory, artifact.path))), artifact.digest);
}

function extract(source, filename, name) {
  const ast = ts.createSourceFile(filename, source, ts.ScriptTarget.ES2023, true);
  const functions = ast.statements.filter(
    (statement) => ts.isFunctionDeclaration(statement) && statement.name?.text === name,
  );
  assert.equal(functions.length, 1, `exactly one private ${name}`);
  assert.equal(functions[0].modifiers?.some(
    (modifier) => modifier.kind === ts.SyntaxKind.ExportKeyword,
  ) ?? false, false, `${name} must remain private`);
  return functions[0].getText(ast);
}
const preimage = readFileSync(join(directory, "driver-engine.preimage.ts"), "utf8");
const afterimage = readFileSync(join(directory, "driver-engine.corrected-afterimage.ts"), "utf8");
const originalBody = extract(preimage, "preimage.ts", "buildResult");
const proposedBody = [
  extract(afterimage, "afterimage.ts", "unwrapResultHash"),
  extract(afterimage, "afterimage.ts", "buildResult"),
].join("\n");
function compile(body) {
  const compiled = ts.transpileModule(body, {
    compilerOptions: { target: ts.ScriptTarget.ES2023, module: ts.ModuleKind.None },
    reportDiagnostics: true,
  });
  assert.equal((compiled.diagnostics ?? []).filter(
    (item) => item.category === ts.DiagnosticCategory.Error,
  ).length, 0, "isolated function syntax must transpile");
  // The extracted private function stays isolated in this test-only closure.
  // No export or hook is added to either production source file.
  return new Function(
    "stableSemanticId", "evidenceFromObservation", "synthesizeOutcome",
    "isCanonicalDriverResult", `${compiled.outputText}\nreturn buildResult;`,
  );
}
const factories = { original: compile(originalBody), proposed: compile(proposedBody) };

function stableId(prefix, seed) {
  const alphabet = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
  let value = BigInt(`0x${createHash("sha256").update(seed).digest("hex").slice(0, 32)}`);
  let body = "";
  for (let i = 0; i < 26; i++) {
    body = alphabet[Number(value & 31n)] + body;
    value >>= 5n;
  }
  return `${prefix}_${body}`;
}
function evidence(observation) {
  return {
    semantic_digest: sha(["driver-value-v1", observation.family, ...observation.parts].join("\0")),
    presence: observation.presence,
  };
}
function freezeDeep(value) {
  if (value !== null && typeof value === "object") {
    for (const member of Object.values(value)) freezeDeep(member);
    Object.freeze(value);
  }
  return value;
}
const observations = {
  text: { family: "TEXT", parts: ["Synthetic metadata"], presence: "PRESENT_REDACTED" },
  empty: { family: "TEXT", parts: [""], presence: "EMPTY" },
  option: { family: "OPTION", parts: [sha("Synthetic option")], presence: "PRESENT_REDACTED" },
};
function inputFor(operation = "EXECUTE", rejectedSite = false, recovery = false) {
  return freezeDeep({
    transaction: {
      transaction_id: "transaction_00000000000000000000000001",
      address: { session_id: "session_00000000000000000000000001", observed_dom_generation: 3 },
      correlation_id: "cor_00000000000000000000000001",
      decision: { decision_id: "decision_00000000000000000000000001" },
    },
    operation,
    driverKey: "TEXT_INPUT_V1",
    resolution: "UNIQUE",
    preconditions: { visible: true, enabled: true, generation_matched: true, policy_permitted: true },
    intended: observations.text,
    immediate: rejectedSite ? observations.empty : observations.text,
    settled: recovery ? observations.option : observations.text,
    siteAcceptance: rejectedSite ? "REJECTED" : "ACCEPTED",
    validationMessageDigests: rejectedSite ? [sha("Synthetic rejection")] : [],
    conditionalFieldIds: [],
    settledGeneration: 3,
    phase: { fixture: "PURE_METADATA_ONLY" },
    attemptedAt: "2026-10-16T12:00:00.000Z",
    durationMs: 42,
    ...(recovery ? { recovery: { attempted: true, restored: false, evidence_digest: sha("Synthetic recovery") } } : {}),
  });
}
// Identical immutable injected synthesis data on both sides. This is not the
// actual outcome synthesizer or a canonical-validator test.
const synthesis = freezeDeep({
  outcome: "VERIFIED", persistence_verified: true, safe_retry_allowed: false,
  reason_codes: ["SYNTHETIC_METADATA_REASON"],
});
const unhandled = [];
const onUnhandled = (reason) => unhandled.push(reason);
process.on("unhandledRejection", onUnhandled);
const turn = () => new Promise((resolve) => setImmediate(resolve));
const prefixStage = { result: 0, driver: 1, attempt: 2, idem: 3 };

async function runOne(version, input, rejected, reasons) {
  const jobs = new Map();
  const calls = [];
  let evidenceStage = 4;
  let validatorCalls = 0;
  const queue = (stage, helper, argumentsValue, value) => {
    assert(stage >= 0 && stage < 7, "seven-job bound");
    assert(!jobs.has(stage), "each metadata job is unique");
    let resolveJob;
    let rejectJob;
    const promise = new Promise((resolve, reject) => { resolveJob = resolve; rejectJob = reject; });
    calls.push({ stage, helper, arguments: structuredClone(argumentsValue), value });
    jobs.set(stage, { resolve: resolveJob, reject: rejectJob, value });
    assert(jobs.size <= 7, "never more than seven jobs");
    return promise;
  };
  const build = factories[version](
    (prefix, seed) => queue(prefixStage[prefix], "stableSemanticId", { prefix, seed }, stableId(prefix, seed)),
    (observation) => queue(evidenceStage++, "evidenceFromObservation", observation, evidence(observation)),
    (phase) => { assert.deepEqual(phase, input.phase); return synthesis; },
    (result) => { validatorCalls++; assert.equal(typeof result, "object"); return true; },
  );
  let terminal = null;
  const completion = build(input).then(
    (value) => { terminal = { state: "FULFILLED", value }; return terminal; },
    (reason) => { terminal = { state: "REJECTED", reason }; return terminal; },
  );
  const settle = (stage) => {
    const job = jobs.get(stage);
    assert(job, `job${stage} exists`);
    if (rejected.has(stage)) job.reject(reasons[stage]);
    else job.resolve(job.value);
  };
  if (version === "proposed") {
    assert.equal(jobs.size, 7, "all seven start before the first wait");
    assert.equal(terminal, null, "aggregate initially pending");
    for (let stage = 6; stage >= 1; stage--) {
      settle(stage); // A higher-index rejection deliberately completes first.
      await turn();
      assert.equal(terminal, null, "aggregate remains pending until its final outstanding job");
    }
    settle(0);
  } else {
    for (let stage = 0; stage < 7; stage++) {
      assert.equal(jobs.size, stage + 1, "reference awaits in original order");
      settle(stage);
      await turn();
      if (rejected.has(stage)) break;
    }
  }
  const outcome = await completion;
  await turn(); // Allow any secondary unhandled rejection to become observable.
  assert.equal(validatorCalls, rejected.size === 0 ? 1 : 0);
  return { outcome, calls, validatorCalls, jobCount: jobs.size };
}
function reasonFixture() {
  return [new Error("synthetic stage0"), { stage: 1 }, null, undefined,
    Symbol("synthetic stage4"), 5, "synthetic stage6"];
}
function propertyOrder(result) {
  return { root: Object.keys(result), action_attempt: Object.keys(result.action_attempt) };
}
const checks = { success_cases: 0, single_rejections: 0, pair_rejections: 0, all_seven_rejections: 0 };
try {
  for (const input of [inputFor(), inputFor("UNDO", true), inputFor("EXECUTE", true, true)]) {
    const original = await runOne("original", input, new Set(), []);
    const proposed = await runOne("proposed", input, new Set(), []);
    assert.equal(original.outcome.state, "FULFILLED");
    assert.equal(proposed.outcome.state, "FULFILLED");
    assert.equal(JSON.stringify(proposed.outcome.value), JSON.stringify(original.outcome.value), "full success JSON bytes");
    assert.deepEqual(propertyOrder(proposed.outcome.value), propertyOrder(original.outcome.value));
    assert.deepEqual(proposed.calls, original.calls, "helper inputs, seeds and outputs are identical");
    checks.success_cases++;
  }
  const profiles = [];
  for (let i = 0; i < 7; i++) profiles.push({ kind: "single_rejections", indices: [i] });
  for (let i = 0; i < 7; i++) for (let j = i + 1; j < 7; j++) {
    profiles.push({ kind: "pair_rejections", indices: [i, j] });
  }
  profiles.push({ kind: "all_seven_rejections", indices: [0, 1, 2, 3, 4, 5, 6] });
  for (const profile of profiles) {
    const rejected = new Set(profile.indices);
    const reasons = reasonFixture();
    const first = Math.min(...profile.indices);
    const original = await runOne("original", inputFor(), rejected, reasons);
    const proposed = await runOne("proposed", inputFor(), rejected, reasons);
    assert.equal(original.outcome.state, "REJECTED");
    assert.equal(proposed.outcome.state, "REJECTED");
    assert(Object.is(original.outcome.reason, reasons[first]), "reference exact raw rejection identity");
    assert(Object.is(proposed.outcome.reason, reasons[first]), "proposed exact lowest-original-index identity");
    assert.equal(original.jobCount, first + 1, "reference stops issuing work at its first rejection");
    assert.equal(proposed.jobCount, 7, "proposed issues exactly seven bounded pure jobs");
    assert.deepEqual(proposed.calls.slice(0, original.calls.length), original.calls, "common helper calls agree");
    checks[profile.kind]++;
  }
  assert.deepEqual(unhandled, [], "secondary rejected jobs are all handled");
  const report = {
    scope: "PURE_METADATA_DIFFERENTIAL_ONLY",
    authority: "NONE",
    result: "PASS",
    checks,
    proposal_manifest_digest: sha(manifestBytes),
    extracted_original_digest: sha(originalBody),
    extracted_proposed_digest: sha(proposedBody),
    canonical_contract_validation: "NOT_EXECUTED",
    browser_validation: "NOT_EXECUTED",
    performance_validation: "NOT_EXECUTED",
    limitations: ["Injected pure helpers; no live DOM, actual canonical validator or browser proof.",
      "AllSettled intentionally changes failure latency and started work; only eventual reason identity/precedence is compared."],
  };
  writeFileSync(join(directory, "differential-report.json"), JSON.stringify(report, null, 2) + "\n");
  process.stdout.write(JSON.stringify(report, null, 2) + "\n");
} finally {
  process.off("unhandledRejection", onUnhandled);
}
