import {createRequire} from 'node:module';
import {readFileSync} from 'node:fs';
const taskRequire=createRequire('/Users/tanishkalwad/jobapplyv2/package.json');
const ts=taskRequire('typescript');
const path='/tmp/japp-w14-build-result-concurrency/driver-engine.preimage.ts';
const text=readFileSync(path,'utf8');
const ast=ts.createSourceFile(path,text,ts.ScriptTarget.ES2023,true);
const node=ast.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text==='buildResult');
for(const module of [ts.ModuleKind.None,ts.ModuleKind.ESNext]) {
 const result=ts.transpileModule(node.getText(ast),{compilerOptions:{target:ts.ScriptTarget.ES2023,module},reportDiagnostics:true});
 process.stdout.write(JSON.stringify({typescript:ts.version,module,diagnostics:result.diagnostics.map(d=>({code:d.code,message:ts.flattenDiagnosticMessageText(d.messageText,'\n')}))})+'\n');
}
