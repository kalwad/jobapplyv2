from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
CLONE = BASE / "clone"
PROOF = BASE / "proof"
NODE = "/opt/homebrew/opt/node@24/bin/node"
PNPM = "/opt/homebrew/opt/node@24/bin/pnpm"
HEAD = "507a7687b004937fbf0dc48e5e80a35d30fe9b6e"
TREE = "235bc696fb37e887b5efa817039276a775a18e2e"
OVERLAY = "e2e/extension/extension-benchmark.spec.ts"
OVERLAY_SHA = "92e46d94bfd84c7e29c6f7c6ce4a8ffb44de9a2c5e9f86c95828cb190806a166"
RUNTIME = "sha256:3b6c0e0c0950b03e3bb9e1f12b27bb8d385174c36fb4b68ef3345597aa8b3502"
TITLE = "W13 L: total scan and re-resolution scaling includes work outside W11"
ENV = dict(os.environ)
ENV["PATH"] = "/opt/homebrew/opt/node@24/bin:" + ENV.get("PATH", "")
ENV["JAPP_W13_PERFORMANCE_SAMPLES"] = "20"
ENV["PLAYWRIGHT_JSON_OUTPUT_NAME"] = str(PROOF / "results.json")
ARGV = [PNPM, "exec", "playwright", "test", OVERLAY, "--grep", TITLE, "--reporter=line,json"]


def now() -> str:
    return dt.datetime.now(dt.UTC).isoformat()


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def save(name: str, value: object) -> None:
    (PROOF / name).write_text(json.dumps(value, indent=2) + "\n")


def capture(argv: list[str]) -> str:
    return subprocess.check_output(argv, cwd=CLONE, env=ENV, text=True).strip()


def sources() -> dict:
    paths = subprocess.check_output(["git", "ls-files", "-z"], cwd=CLONE).split(b"\0")
    files = []
    for raw in paths:
        if not raw:
            continue
        rel = raw.decode()
        data = (CLONE / rel).read_bytes()
        files.append({"path": rel, "bytes": len(data), "sha256": digest(data)})
    return {
        "at": now(),
        "head": capture(["git", "rev-parse", "HEAD"]),
        "tree": capture(["git", "rev-parse", "HEAD^{tree}"]),
        "status_porcelain": capture(["git", "status", "--porcelain=v1"]),
        "diff_binary": capture(["git", "diff", "--binary"]),
        "files": files,
        "total_bytes": sum(item["bytes"] for item in files),
    }


def verify_sources(value: dict) -> None:
    assert value["head"] == HEAD
    assert value["tree"] == TREE
    assert value["status_porcelain"] == "M " + OVERLAY, value["status_porcelain"]
    assert next(item["sha256"] for item in value["files"] if item["path"] == OVERLAY) == OVERLAY_SHA
    patch = Path("/tmp/japp-m02-w15-native128-diagnosis/native128-phase-observation.patch").read_bytes()
    subprocess.run(["git", "apply", "--reverse", "--check", "-"], input=patch, cwd=CLONE, check=True)


def runtime() -> dict:
    code = "import {captureRuntimeInventory} from './e2e/extension/legacy-paired-options/runtime-inventory.ts'; console.log(JSON.stringify(captureRuntimeInventory(process.cwd())));"
    value = json.loads(capture([NODE, "--input-type=module", "-e", code]))
    assert value["digest"] == RUNTIME
    assert len(value["files"]) == 355
    assert value["total_bytes"] == 3371960
    return value


def built() -> dict:
    result = {"at": now(), "scope": "Actual build-output endpoints; before is absent in fresh clone. Canonical Playwright global setup builds production and invalid-ACK variants before the test.", "directories": {}}
    for rel in ["apps/extension/dist/chrome-mv3", "apps/extension/dist/invalid-ack/chrome-mv3", "apps/mock-ats-lab/dist"]:
        target = CLONE / rel
        files = []
        if target.exists():
            for path in sorted(target.rglob("*")):
                if path.is_file():
                    data = path.read_bytes()
                    files.append({"path": path.relative_to(CLONE).as_posix(), "bytes": len(data), "sha256": digest(data)})
        result["directories"][rel] = {"exists": target.exists(), "files": files, "total_bytes": sum(item["bytes"] for item in files)}
    return result


def tools() -> dict:
    result = {
        "at": now(),
        "node": capture([NODE, "--version"]),
        "node_exec_path": capture([NODE, "-p", "process.execPath"]),
        "pnpm": capture([PNPM, "--version"]),
        "playwright": capture([PNPM, "exec", "playwright", "--version"]),
        "python": sys.version,
        "platform": platform.platform(),
        "machine": platform.machine(),
    }
    assert result["node"] == "v24.18.0"
    assert result["pnpm"] == "11.17.0"
    assert result["playwright"] == "Version 1.62.0"
    for rel in ["pnpm-lock.yaml", "node_modules/.pnpm/lock.yaml"]:
        data = (CLONE / rel).read_bytes()
        result[rel] = {"bytes": len(data), "sha256": digest(data)}
    return result


def rows_from_log() -> dict:
    raw = (PROOF / "run.log").read_bytes()
    lines = [line for line in raw.splitlines(keepends=True) if b"W13_SCALING " in line]
    assert len(lines) == 1, len(lines)
    (PROOF / "W13_SCALING-exact-line.log").write_bytes(lines[0])
    text = lines[0].decode()
    value, _ = json.JSONDecoder().raw_decode(text[text.index("W13_SCALING ") + len("W13_SCALING "):])
    rows = value["rows"]
    save("all-phase-rows.json", rows)
    native = [row for row in rows if row["control_count"] == 128]
    assert len(rows) == 22 and len(native) == 20
    for row in native:
        assert row["actions_attempted"] == row["physical_actions_count"] == 128
        assert row["scanner_work"]["reresolution_calls"] == 512
        assert row["scanner_work"]["descriptors_built"] == 768
        assert row["settle_budget_ms"] == 0
        assert abs(sum(row["phase_wall_clock_ms"].values()) - row["total_wall_clock_ms"]) < 0.000001
    ordered = sorted(enumerate(native, 1), key=lambda pair: pair[1]["total_wall_clock_ms"])
    p95_sample, p95 = ordered[18]
    return {"scope": "DIAGNOSTIC_OVERLAY_ONLY; does not replace original507a full FAIL or decide Gate A; no retry", "sample_count": 20, "rank": 19, "p95_sample": p95_sample, "p95_ms": p95["total_wall_clock_ms"], "threshold_ms": 1500, "threshold_pass": p95["total_wall_clock_ms"] <= 1500, "p95_phase_wall_clock_ms": p95["phase_wall_clock_ms"], "raw_line_bytes": len(lines[0]), "raw_line_sha256": digest(lines[0]), "all_rows_retained": len(rows)}


def discover() -> dict:
    argv = ARGV[:-1] + ["--list", "--reporter=json"]
    env = dict(ENV)
    env.pop("PLAYWRIGHT_JSON_OUTPUT_NAME", None)
    result = subprocess.run(argv, cwd=CLONE, env=env, capture_output=True)
    (PROOF / "discovery.stdout.json").write_bytes(result.stdout)
    (PROOF / "discovery.stderr.log").write_bytes(result.stderr)
    save("discovery-command.json", {"at": now(), "argv": argv, "cwd": str(CLONE), "exit_code": result.returncode, "scope": "Canonical --list skips global setup/build/browser"})
    value = json.loads(result.stdout)
    matches = []
    def visit(suites):
        for suite in suites:
            for spec in suite.get("specs", []):
                matches.append({"file": spec.get("file"), "title": spec["title"], "tests": len(spec.get("tests", []))})
            visit(suite.get("suites", []))
    visit(value["suites"])
    summary = {"at": now(), "exit_code": result.returncode, "matches": matches, "total_specs": len(matches), "total_tests": sum(item["tests"] for item in matches)}
    save("discovery-summary.json", summary)
    assert result.returncode == 0 and len(matches) == 1 and matches[0]["title"] == TITLE and summary["total_tests"] == 1, summary
    return summary


def run() -> int:
    release = json.loads((BASE / "parent-release.json").read_text())
    assert release["parent_explicit_release"] is True
    discovery = json.loads((PROOF / "discovery-summary.json").read_text())
    assert discovery["exit_code"] == 0 and discovery["total_specs"] == discovery["total_tests"] == 1
    assert discovery["matches"][0]["title"] == TITLE
    assert not (PROOF / "invocation-started.json").exists(), "ONE_INVOCATION_ONLY"
    before = sources()
    verify_sources(before)
    save("before-sources.json", before)
    save("before-runtime.json", runtime())
    save("before-tools.json", tools())
    save("before-build.json", built())
    save("command.json", {"at": now(), "argv": ARGV, "cwd": str(CLONE), "environment": {key: ENV[key] for key in ["PATH", "JAPP_W13_PERFORMANCE_SAMPLES", "PLAYWRIGHT_JSON_OUTPUT_NAME"]}, "trace_policy": "Original retain-on-failure; no trace override", "parent_release": release})
    save("invocation-started.json", {"at": now(), "one_invocation_only": True})
    started = time.monotonic()
    proc = subprocess.Popen(ARGV, cwd=CLONE, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    with (PROOF / "run.log").open("wb") as log:
        assert proc.stdout is not None
        for line in proc.stdout:
            log.write(line)
            log.flush()
            if b"W13_SCALING " not in line:
                sys.stdout.buffer.write(line)
                sys.stdout.buffer.flush()
    exit_code = proc.wait()
    save("completion.json", {"at": now(), "exit_code": exit_code, "duration_s": time.monotonic() - started})
    # Retain native test artifacts immediately, before any possible later
    # Playwright invocation can clear its default output directory.
    source_artifacts = CLONE / "test-results"
    if source_artifacts.exists():
        shutil.copytree(source_artifacts, PROOF / "native-test-results")
    artifact_files = []
    for path in sorted((PROOF / "native-test-results").rglob("*")):
        if path.is_file():
            data = path.read_bytes()
            artifact_files.append({"path": path.relative_to(PROOF).as_posix(), "bytes": len(data), "sha256": digest(data)})
    save("native-artifact-retention.json", {"at": now(), "files": artifact_files})
    after = sources()
    save("after-sources.json", after)
    save("after-runtime.json", runtime())
    save("after-tools.json", tools())
    save("after-build.json", built())
    verify_sources(after)
    assert before["files"] == after["files"]
    assert before["diff_binary"] == after["diff_binary"]
    summary = rows_from_log()
    summary["child_exit_code"] = exit_code
    summary["tracked_source_overlay_unchanged"] = True
    save("diagnostic-summary.json", summary)
    print(json.dumps(summary, indent=2), flush=True)
    return exit_code


parser = argparse.ArgumentParser()
parser.add_argument("--prepare", action="store_true")
parser.add_argument("--run-after-parent-release", action="store_true")
args = parser.parse_args()
PROOF.mkdir(exist_ok=True)
if args.prepare:
    prepared = sources()
    verify_sources(prepared)
    save("prepared-sources.json", prepared)
    save("prepared-runtime.json", runtime())
    save("prepared-tools.json", tools())
    save("prepared-build.json", built())
    save("prepared-plan.json", {"at": now(), "argv": ARGV, "cwd": str(CLONE), "source_only": True, "browser_build_actors": 0, "release_required": True})
    discovery = discover()
    print("PREPARED_ONLY: source overlay/tools/runtime bound; exactly one existing W13 L test discovered; no build or browser launched.", flush=True)
elif args.run_after_parent_release:
    sys.exit(run())
else:
    parser.error("select --prepare or --run-after-parent-release")
