# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-benchmark.spec.ts >> W13 L: total scan and re-resolution scaling includes work outside W11
- Location: e2e/extension/extension-benchmark.spec.ts:61:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 1500
Received:    1644.6497500000005
```

# Test source

```ts
  113 |       };
  114 |     };
  115 |     const before = await metrics();
  116 |     const started = performance.now();
  117 |     const top = foundTopFrame(await scanFrames(harness));
  118 |     expect(top.descriptors).toHaveLength(count);
  119 |     const scanCompleted = performance.now();
  120 |     const transactions = [];
  121 |     for (const [i, descriptor] of top.descriptors.entries()) {
  122 |       const transaction = await approvedTransaction(
  123 |         descriptor,
  124 |         `w13-scaling-${String(count)}-${String(i)}`,
  125 |         { kind: "TEXT", text: "Synthetic W13" },
  126 |       );
  127 |       // Minimum accepted settle budget isolates a LOWER BOUND on scanning
  128 |       // cost. Final fresh reconciliation still checks every persisted value.
  129 |       transactions.push({ ...transaction, settle: { budget_ms: 0 } });
  130 |     }
  131 |     const planningCompleted = performance.now();
  132 |     for (let i = 0; i < transactions.length; i += 32) {
  133 |       const outcome = await dynExecute(harness, transactions.slice(i, i + 32));
  134 |       for (const item of outcome.items) {
  135 |         expect(item.status).toBe("EXECUTED");
  136 |         if (item.status === "EXECUTED") {
  137 |           expect(item.result.outcome).toBe("VERIFIED");
  138 |         }
  139 |       }
  140 |     }
  141 |     const executionCompleted = performance.now();
  142 |     const outcome = reconciled(
  143 |       await dynReconcile(harness, top.frame_context.frame_id),
  144 |     );
  145 |     const completed = performance.now();
  146 |     const elapsed = completed - started;
  147 |     const after = await metrics();
  148 |     expect(outcome.inventory.counts.verified_filled).toBe(count);
  149 |     const work = outcome.snapshot.scanner_work;
  150 |     expect(work).toBeDefined();
  151 |     if (work === undefined) throw new Error("total scanner work missing");
  152 |     expect(work.reresolution_calls).toBeGreaterThanOrEqual(4 * count);
  153 |     // Complete identity capture is shared only while observer revision and
  154 |     // context remain current. Four live target resolutions still run/control.
  155 |     expect(work.index_rebuilds).toBe(1);
  156 |     expect(work.index_hits).toBeGreaterThanOrEqual(4 * count - 1);
  157 |     expect(work.identity_pairs_examined).toBe(count);
  158 |     expect(work.candidate_enumerations).toBeLessThanOrEqual(3);
  159 |     expect(work.candidates_examined).toBeLessThanOrEqual(3 * count);
  160 |     expect(work.descriptors_built).toBe(6 * count);
  161 |     const physicalActions = Number(
  162 |       await harness.page.locator("html").getAttribute("data-physical-fills"),
  163 |     );
  164 |     expect(physicalActions).toBe(count);
  165 |     expect(outcome.snapshot.actions_executed).toBe(count);
  166 |     rows.push({
  167 |       control_count: count,
  168 |       actions_attempted: outcome.snapshot.actions_executed,
  169 |       physical_actions_count: physicalActions,
  170 |       total_wall_clock_ms: elapsed,
  171 |       phase_wall_clock_ms: {
  172 |         scan_and_descriptor_assertion: scanCompleted - started,
  173 |         approved_transaction_planning: planningCompleted - scanCompleted,
  174 |         execution_and_result_assertions: executionCompleted - planningCompleted,
  175 |         final_reconciliation: completed - executionCompleted,
  176 |       },
  177 |       scanner_work: work,
  178 |       w11_scan_duration_ms: outcome.snapshot.total_scan_duration_ms,
  179 |       w11_reconciliation_duration_ms:
  180 |         outcome.snapshot.last_reconciliation_duration_ms,
  181 |       w11_root_scans: outcome.snapshot.root_rescans,
  182 |       w11_subtree_scans: outcome.snapshot.affected_subtree_scans,
  183 |       cpu_source: "CHROMIUM_CDP_PERFORMANCE_TASK_DURATION_MAIN_PAGE",
  184 |       task_duration_delta_s: after.task_duration_s - before.task_duration_s,
  185 |       heap_source: "CHROMIUM_CDP_PERFORMANCE_JS_HEAP_USED_SIZE_MAIN_PAGE",
  186 |       heap_before_bytes: before.heap_used_bytes,
  187 |       heap_after_bytes: after.heap_used_bytes,
  188 |       settle_budget_ms: 0,
  189 |       evidence_scope: "LOWER_BOUND_NO_ASYNC_RERENDER_DELAY",
  190 |       browser_product: browserVersion.product,
  191 |       browser_revision: browserVersion.revision,
  192 |     });
  193 |     await cdp.detach();
  194 |     await harness.page.close();
  195 |     await harness.controller.close();
  196 |   }
  197 |   const samples = rows
  198 |     .filter((row) => row.control_count === 128)
  199 |     .map((row) => row.total_wall_clock_ms)
  200 |     .sort((a, b) => a - b);
  201 |   const p95 = samples[Math.ceil(0.95 * samples.length) - 1];
  202 |   // Retain all raw observations even when the target assertion fails. This
  203 |   // reporting occurs after every timed sample; it cannot change the budget.
  204 |   console.log(
  205 |     `W13_SCALING ${JSON.stringify({ labels: ["DEVELOPMENT", "HARNESS_VALIDATION", "NOT_GATE_A_FINAL_EVIDENCE"], rows })}`,
  206 |   );
  207 |   await testInfo.attach("w13-total-scan-scaling", {
  208 |     body: JSON.stringify(rows, null, 2),
  209 |     contentType: "application/json",
  210 |   });
  211 |   if (sampleCount === 20) {
  212 |     expect(process.platform).toBe("darwin");
> 213 |     expect(p95).toBeLessThanOrEqual(1500);
      |                 ^ Error: expect(received).toBeLessThanOrEqual(expected)
  214 |   }
  215 |   console.log(
  216 |     `W13_TARGET_P95 ${JSON.stringify({ samples: samples.length, p95_ms: p95, threshold_ms: 1500, settle_budget_ms: 0, scope: "TARGET_MACHINE_LOWER_BOUND_HARNESS_VALIDATION" })}`,
  217 |   );
  218 | });
  219 | 
  220 | test("W13 J: overlapping delayed repeater operations perform one physical click", async ({
  221 |   extensionContext,
  222 |   extensionId,
  223 |   serviceWorker,
  224 | }) => {
  225 |   const harness = await openHarness(
  226 |     extensionContext,
  227 |     extensionId,
  228 |     serviceWorker,
  229 |     "/native/",
  230 |   );
  231 |   await setFixture(
  232 |     harness,
  233 |     `<form data-japp-application-root="true">
  234 |     <section data-japp-repeater="work">
  235 |       <label for="repeat">First name</label>
  236 |       <input id="repeat" data-japp-repeater-controller="true">
  237 |       <button type="button" data-japp-repeater-action="ADD">Add employment</button>
  238 |     </section>
  239 |   </form>`,
  240 |   );
  241 |   await harness.page.evaluate(() => {
  242 |     document.documentElement.dataset.physicalClicks = "0";
  243 |     document.querySelector("button")?.addEventListener("click", () => {
  244 |       document.documentElement.dataset.physicalClicks = String(
  245 |         Number(document.documentElement.dataset.physicalClicks) + 1,
  246 |       );
  247 |       setTimeout(() => {
  248 |         const item = document.createElement("div");
  249 |         item.dataset.jappRepeaterItem = "true";
  250 |         item.dataset.jappItemLabel = "Synthetic employment";
  251 |         document.querySelector("section")?.append(item);
  252 |       }, 30);
  253 |     });
  254 |   });
  255 |   const top = foundTopFrame(await scanFrames(harness));
  256 |   const descriptor = descriptorByLabel(top.descriptors, "First name");
  257 |   const transaction = await buildTransaction(
  258 |     descriptor,
  259 |     { kind: "REPEATER_ADD", item_label: "Synthetic employment" },
  260 |     await fillDecision(descriptor, "w13-repeater-overlap"),
  261 |     "w13-repeater-overlap",
  262 |   );
  263 |   const outcomes = await Promise.all([
  264 |     dynExecute(harness, [transaction]),
  265 |     dynExecute(harness, [{ ...transaction }]),
  266 |   ]);
  267 |   expect(outcomes).toHaveLength(2);
  268 |   expect(
  269 |     await harness.page.locator("html").getAttribute("data-physical-clicks"),
  270 |   ).toBe("1");
  271 | });
  272 | 
  273 | test("W13 K: required control beyond capacity cannot receive a complete readiness proof", async ({
  274 |   extensionContext,
  275 |   extensionId,
  276 |   serviceWorker,
  277 | }) => {
  278 |   const harness = await openHarness(
  279 |     extensionContext,
  280 |     extensionId,
  281 |     serviceWorker,
  282 |     "/generic/basic",
  283 |   );
  284 |   const controls = Array.from(
  285 |     { length: 513 },
  286 |     (_, index) =>
  287 |       `<label for="field${String(index)}">Field ${String(index)}</label><input id="field${String(index)}" name="field${String(index)}" ${index === 512 ? "required" : ""}>`,
  288 |   ).join("");
  289 |   await setFixture(
  290 |     harness,
  291 |     `<form data-japp-application-root="true">${controls}</form>`,
  292 |   );
  293 |   const frames = await scanFrames(harness);
  294 |   const top = frames.find((frame) => frame.frame_context.is_top_frame);
  295 |   expect(top).toBeDefined();
  296 |   if (top === undefined) throw new Error("top frame unavailable");
  297 |   expect(top.root_status).toBe("CAPACITY_EXCEEDED");
  298 |   expect(top.descriptors).toHaveLength(0);
  299 |   const outcome = await dynReconcile(harness, top.frame_context.frame_id);
  300 |   expect(outcome.status).toBe("CAPACITY_EXCEEDED");
  301 |   expect("inventory" in outcome).toBe(false);
  302 | });
  303 | 
  304 | test("W13 K: observation beginning over capacity requires a complete recovery scan", async ({
  305 |   extensionContext,
  306 |   extensionId,
  307 |   serviceWorker,
  308 | }) => {
  309 |   test.setTimeout(120_000);
  310 |   const harness = await openHarness(
  311 |     extensionContext,
  312 |     extensionId,
  313 |     serviceWorker,
```