# Native128 diagnosis handoff

Read `source-hypothesis-and-phase-plan.md` first. This is a source-only diagnosis plus closed-row inspection, not a Gate A verdict or performance fix.

- Source: clean507a768/tree235bc6; nine exact preimages and source hashes in `source-binding.json`.
- Actual failed row proof: exact copied closed stdout and provenance under `closed-failure/`; independently derived checks in `closed-failure-summary.json`.
- Proposal: `native128-phase-observation.patch` and `proposal/e2e/extension/extension-benchmark.spec.ts`. Diagnostic only; not integrated, built, typechecked or executed.
- Current conclusion: p95 fails1662.986499999999ms; all native128 physical-work invariants hold. Cause remains UNPROVEN. Original trace is unavailable, so phases must be observed before choosing a runtime change.
- No root mutation, build, browser, test, legacy actor, cache-bound change or sealed R9 change was performed by this agent.
