# M02-W15 native128 bounded source diagnosis

Source binding: clean HEAD `507a7687b004937fbf0dc48e5e80a35d30fe9b6e`, tree `235bc696fb37e887b5efa817039276a775a18e2e`. Nine exact preimages and their hashes are retained in `source-binding.json` and `preimages/`.

The parent supplied the closed default-browser failure observation: native128 target20 p95 `1662.986499999999` ms against unchanged `1500` ms; 241 other default-browser cases passed. The full wrapper was still active when diagnosis began. This report does not independently attest the raw value until the parent releases the closed artifacts for inspection. The same runtime digest `3b6c0e0c0950b03e3bb9e1f12b27bb8d385174c36fb4b68ef3345597aa8b3502` appeared in earlier passing runs. Neither identical source nor a later pass establishes the reason for this failure. Cause remains **UNPROVEN**.

## Contract and scope

M02-W15 is the sole active package; W14 is VERIFIED and M00/M01 ACCEPTED. Gate A requires generic scan/fill p95 <=1500 ms and all safety thresholds. Accepted ADR-0006 waives hidden owner holdout and per-package stopping; ADR-0007 waives direct Simplify/public-form execution only. Independent review, native/controlled verification, live authority and numerical thresholds remain. This agent authors a bounded diagnosis or correction; it supplies no final Gate A verdict.

No build, browser, target rerun, legacy campaign, extension-management action, large-select undo probe or root mutation has run. Sealed R9 actors and locked sources remain untouched. No sample, wait, threshold, fixture, expected truth, hash-cache bound, re-resolution count or publication witness changes are proposed.

## Bounded execution path

`e2e/extension/extension-benchmark.spec.ts:61` includes all of these operations inside its total wall interval:

1. Actual MV3 `scanFrames` RPC, plus descriptor-count assertion.
2. Sequential `approvedTransaction` for every descriptor. It calls W09 `resolveFieldDecision` in the Node test process, then constructs the transaction. W09 currently awaits two independent metadata digests sequentially before a decision ID that depends on both.
3. Four sequential `dynExecute` RPC batches of 32 for native128. Each transaction passes the dynamic duplicate guard, all driver preflight/before-write/settlement re-resolutions and publication witnesses; transactions execute serially.
4. Actual MV3 final `dynReconcile`, including one root scan and fresh persisted observations, followed by the existing total end timestamp.

The CDP task/heap metrics represent the main page, whereas the total also includes the controller/service worker RPC path and Node planning. Main-page CPU alone cannot attribute the total.

`scanner_work` already measures per-purpose live resolution durations, index rebuild/matching, descriptor building and scan durations. `snapshot.last_reconciliation_duration_ms` exists in the dynamic engine, although this test currently retains only W11 scan duration and aggregate scanner_work. The result-metadata path already issues seven immutable computations through `Promise.allSettled`, unwraps in old order, and keeps execute/undo publication witnesses after the join. Reworking that join without measurements is unjustified.

## Evidence-first phase plan

1. Inspect only the already-closed test-specific native128 attachment/trace after the parent identifies/releases it. Retain exact bytes/hashes. Do not inspect the still-active full-proof directory.
2. Parse trace `before`/`after` events for each `runtimeMessage` controller evaluation. Classify request wire `type` or equivalent discriminant; pair exact call IDs. The closed trace can provide scan RPC, all four execution RPCs and reconciliation RPC durations. Use call boundaries to derive the planning gap and execution assertion gaps, labeling them trace-derived rather than product instrumentation.
3. Reconcile every row's control count, physical actions, 512 resolutions, 768 descriptors, index rebuild/hits and p95 rank19. Compare existing scanner phase counters with total and RPC durations. Inspect all 20 observations, preserving the slowest and failed sample. Do not choose only a fast run or replace the failed p95.
4. If trace gaps or counters remain ambiguous, propose a test-only timestamp patch in an outside copy of `extension-benchmark.spec.ts`. Four boundary timestamps partition the unchanged timed interval into scan, planning, execution (including existing assertions) and reconcile. Retain each execution batch duration and existing W11 reconciliation duration. Preserve the original `started`/end boundary, <=1500 assertion, 20 samples, fixture, zero-settle budget, actual action/resolution/descriptor checks and row order. This adds observation only; it is not a performance correction or final proof.
5. Before any new browser/build/target actor, obtain the parent's explicit release after the current full wrapper closes. Any actor then runs once under a source-bound wrapper; failures remain retained. Avoid retry-to-green.

## Candidate hypotheses, without attribution

- Wall/CPU drift may originate in MV3 execution, scan/reconcile DOM work, Node W09 planning, RPC/scheduling or a combination. Existing total cannot distinguish these.
- A bounded two-digest join inside W09 `assembleDecision` could remove one serialized asynchronous metadata wait per field while retaining identical seed bytes and decision dependency order. It is a source opportunity, not evidence that W09 caused this regression. It must preserve first-old rejection identity, structural/semantic validators and avoid snapshotting mutable descriptor properties at a different authority boundary without justification. A pure deferred-digest differential plus meaningful mutation/rejection negatives would precede implementation.
- Scanner descriptor hashing is interleaved with live DOM reads and guarded by revision/target checks. Broad concurrency or cached descriptor authority would create safety obligations and is not the first bounded correction.
- Reconciliation item IDs are immutable after evidence capture but involve occurrence ordering and counter side effects; changing their scheduling requires exact-order/rejection tests and preserved final coverage/property witnesses. No source change is currently justified there.

## Closed-row observations and retained trace limitation

The parent released an exact closed copy of `W13_SCALING` stdout, 42109 bytes, SHA-256 `35938f8d63a94e6b0386263eb721bb85edd402ea1fca997ad04d1c7e956097bb`. Its 22 rows contain 20 native128 samples. This agent independently parsed every row. Rank19 is sample4 at `1662.986499999999` ms; the maximum is sample1 at `1763.8219169999993` ms. Seven samples exceed1500 ms; median is `1466.981812500002` ms. Every native128 row retains128 attempted/physical actions,512 live resolutions (128 each preflight/preaction/settle/reconcile),768 descriptors, one index rebuild,511 hits, zero invalidations, three enumerations and384 candidates.

Across all20 rows, measured scanner total is91.589–126.610 ms and main-page CDP task duration is615.913–784.143 ms. At the p95 sample, those values are117.899 ms and666.445 ms. These counters overlap; subtracting them from one another would be invalid. Neither records full Node planning or controller/worker RPC and scheduling cost. They do not identify a cause.

The parent reported that the original default-browser trace/screenshot printed in stdout are no longer retained after the later controlled Playwright invocations. Only `.last-run.json` remains in the shared output location. No trace RPC metric has been derived, and no failure trace recovery or reproduction is claimed. The shared-output source explanation is pending the parent's separate verification. Raw closed copies, provenance, hashes and the derived summary are retained in `closed-failure/` and `closed-failure-summary.json`.

## Source-only peer finding

A narrow read-only child review identified a material constraint on the W09 proposal: `assembleDecision` serializes the full descriptor after awaiting the address digest. A naive two-digest join would read it earlier, and shallow TypeScript readonly does not establish deep external immutability. Existing tests prove that the resolver does not modify input, not that callers cannot modify it during the await. Defer that pair without a stable-input contract or explicit reviewed semantics.

The helper's synthetic-record ID and correlation ID hash immutable primitive strings independently, but running them concurrently still starts unused work when the first stage fails and requires preserving failure precedence through record-set construction. This is a possible preparation optimization, not an attributed performance cause and not a chosen runtime correction.

## Decision at this checkpoint

Preserve failure and measure phases. `native128-phase-observation.patch` is an outside, UNEXECUTED diagnostic-only proposal with exact preimage/afterimage hashes in `proposal-manifest.json`. It adds three boundary clocks to partition the existing interval and retains the already-existing W11 reconciliation duration in each raw row. It changes no threshold, sample count, wait, expected result, fixture, safety assertion or core runtime source. Its extra clock calls have small unmeasured overhead that remains included in total time. No runtime/performance correction has been made.

The original trace cannot supply the missing phase attribution. After the parent releases browser/build actors, one source-bound diagnostic invocation can establish scan/planning/execution/reconcile wall phases under the unchanged total threshold. A runtime correction should follow that evidence and be limited to one demonstrably independent metadata subpath, with test-first equivalence/rejection checks and complete required regression. Any failed diagnostic result stays retained; no retry-to-green is authorized by this plan.
