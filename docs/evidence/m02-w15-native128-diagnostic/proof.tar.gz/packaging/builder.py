"""Package explicit review inputs; never grants gate or owner authority."""
from pathlib import Path, PurePosixPath
import argparse
import gzip
import hashlib
import io
import json
import os
import stat
import tarfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encode(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()


def regular(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError("Only regular explicit source files are accepted: " + str(path))
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), "rb") as stream:
        opened = os.fstat(stream.fileno())
        data = stream.read()
        after = os.fstat(stream.fileno())
    signature = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    if signature(before) != signature(opened) or signature(opened) != signature(after):
        raise ValueError("Source changed during reading: " + str(path))
    return data


def member_name(name):
    p = PurePosixPath(name)
    if p.is_absolute() or str(p) != name or ".." in p.parts or "\\" in name:
        raise ValueError("Unsafe archive member: " + name)
    if not name or any(ord(c) < 32 or ord(c) == 127 for c in name):
        raise ValueError("Invalid archive member: " + name)
    return name


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("A new output directory is required")
    config_bytes = regular(args.inputs)
    config = json.loads(config_bytes)
    payload = {}
    entries = []
    for row in config["files"]:
        name = member_name(row["member"])
        if name in payload or name.startswith("packaging/"):
            raise ValueError("Duplicate or reserved member: " + name)
        b = regular(Path(row["source"]))
        if len(b) != row["bytes"] or digest(b) != row["sha256"]:
            raise ValueError("Explicit input commitment differs: " + name)
        if len(b) > 134217728:
            raise ValueError("Oversized member: " + name)
        payload[name] = b
        entries.append(dict(member=name, bytes=len(b), sha256=digest(b)))
    if sum(len(b) for b in payload.values()) > 536870912:
        raise ValueError("Review pack exceeds capacity")
    # Caller metadata is documentary. Original source records, review and the
    # actual owner decision determine authority; packaging infers none of them.
    index = dict(format="M02_W15_DOCUMENTARY_REVIEW_PACK_1", authority="NONE",
                 owner_decision="PENDING", gate_state="IN_PROGRESS",
                 candidate=config["candidate"], result_references=config["result_references"],
                 scope_notes=config["scope_notes"], files=entries)
    payload["packaging/review-index.json"] = encode(index)
    payload["packaging/inputs.json"] = config_bytes
    payload["packaging/builder.py"] = regular(Path(__file__))
    files = [dict(path=n, bytes=len(b), sha256=digest(b)) for n, b in sorted(payload.items())]
    payload["retained-members.json"] = encode(files)
    args.output.mkdir(parents=True)
    archive = args.output / "proof.tar.gz"
    with archive.open("xb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w") as t:
                for n, b in sorted(payload.items()):
                    info = tarfile.TarInfo(n)
                    info.size, info.mtime, info.mode = len(b), 0, 0o644
                    t.addfile(info, io.BytesIO(b))
    with tarfile.open(archive) as t:
        members = t.getmembers()
        if len(members) != len(payload) or len({m.name for m in members}) != len(payload):
            raise ValueError("Archive inventory differs")
        for m in members:
            member_name(m.name)
            if not m.isfile() or t.extractfile(m).read() != payload[m.name]:
                raise ValueError("Archive byte comparison failed: " + m.name)
    for row in config["files"]:
        if regular(Path(row["source"])) != payload[row["member"]]:
            raise ValueError("Input changed during packaging: " + row["member"])
    b = archive.read_bytes()
    manifest = dict(archive_sha256=digest(b), archive_bytes=len(b),
                    regular_members=len(payload), files=files,
                    exhaustive_comparison="PASS", authority="NONE",
                    owner_decision="PENDING", gate_state="IN_PROGRESS")
    (args.output / "retention-manifest.json").write_bytes(encode(manifest))
    (args.output / "review-index.json").write_bytes(encode(index))
    print(json.dumps({k: v for k, v in manifest.items() if k != "files"}))


if __name__ == "__main__":
    main()
