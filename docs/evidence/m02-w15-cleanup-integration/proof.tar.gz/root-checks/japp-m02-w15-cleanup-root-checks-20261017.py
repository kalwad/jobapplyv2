from pathlib import Path
import subprocess,os,time,datetime,hashlib,json,sys
root=Path('/Users/tanishkalwad/jobapplyv2')
out=Path('/tmp/japp-m02-w15-cleanup-root-checks-20261017');out.mkdir()
env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@24/bin:'+env['PATH']
steps=[('status',['uv','run','python','scripts/validate_status.py']),('traceability',['pnpm','traceability:check']),('extension-unit',['pnpm','--filter','@japp/extension','test']),('typecheck',['pnpm','typecheck']),('lint',['pnpm','exec','eslint','e2e/extension/public-contact/contact-harness.ts','e2e/extension/public-research/inspection-harness.ts','apps/extension/test/m02-w14/evaluation-resource-cleanup.test.ts']),('format',['pnpm','exec','prettier','--check','e2e/extension/public-contact/contact-harness.ts','e2e/extension/public-research/inspection-harness.ts','apps/extension/test/m02-w14/evaluation-resource-cleanup.test.ts']),('test-policy',['node','scripts/check-ts-test-policy.mjs','apps/extension/test/m02-w14/evaluation-resource-cleanup.test.ts']),('diff',['git','diff','--check'])]
records=[]
for name,argv in steps:
 print('RUN '+name,flush=True);start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 with (out/(name+'.log')).open('wb') as f:r=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 b=(out/(name+'.log')).read_bytes();record=dict(name=name,argv=argv,cwd=str(root),started_at=start,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=r.returncode,elapsed_seconds=time.monotonic()-t,log_bytes=len(b),sha256=hashlib.sha256(b).hexdigest());records.append(record)
 (out/'commands.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),records=records),indent=2)+'\n');print(json.dumps(record),flush=True)
 print(b.decode(errors='replace')[-1500:],flush=True)
 if r.returncode:sys.exit(r.returncode)
