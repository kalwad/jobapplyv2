from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import shutil
import tarfile

source = Path(__file__).resolve().parent
destination = Path("/tmp/japp-w14-1d490d-ci-retained")
destination.mkdir(exist_ok=True)
archive = destination / "1d490d-ci-evidence.tar.gz"
assert not archive.exists(), "Do not overwrite sealed evidence"
members = []
for path in sorted(source.rglob("*")):
    assert not path.is_symlink()
    if not path.is_file():
        continue
    name = path.relative_to(source).as_posix()
    pure = PurePosixPath(name)
    assert not pure.is_absolute() and ".." not in pure.parts and "\\" not in name
    data = path.read_bytes()
    members.append({"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
embedded = {"format": "regular-member-sha256-v1", "self_excluded": ["members.json"], "members": members}
embedded_bytes = (json.dumps(embedded, indent=2) + "\n").encode()
(destination / "members.json").write_bytes(embedded_bytes)
all_members = members + [{"path": "members.json", "bytes": len(embedded_bytes), "sha256": hashlib.sha256(embedded_bytes).hexdigest()}]
with archive.open("xb") as raw:
    with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.USTAR_FORMAT) as tar:
            for record in all_members:
                data = embedded_bytes if record["path"] == "members.json" else (source / record["path"]).read_bytes()
                assert len(data) == record["bytes"] and hashlib.sha256(data).hexdigest() == record["sha256"]
                info = tarfile.TarInfo(record["path"])
                info.size = len(data)
                info.mtime = 0
                info.mode = 0o644
                info.uid = info.gid = 0
                info.uname = info.gname = ""
                tar.addfile(info, io.BytesIO(data))
expected = {m["path"]: m for m in all_members}
seen = set()
with tarfile.open(archive, "r:gz") as tar:
    for member in tar:
        name = member.name
        pure = PurePosixPath(name)
        assert member.isfile() and not member.issym() and not member.islnk()
        assert not pure.is_absolute() and ".." not in pure.parts and "\\" not in name
        assert name not in seen and name in expected
        seen.add(name)
        extracted = tar.extractfile(member)
        assert extracted is not None
        data = extracted.read()
        assert member.size == len(data) == expected[name]["bytes"]
        assert hashlib.sha256(data).hexdigest() == expected[name]["sha256"]
assert seen == set(expected)
archive_bytes = archive.read_bytes()
manifest = {"format": "ci-retention-v1", "created_at": datetime.now(timezone.utc).isoformat(),
            "repository": "kalwad/jobapplyv2", "run_id": 38984225730,
            "head": "1d490d1230b443c31fd4a9d8732064552affe149",
            "tested_merge": "d8de57146b6ef183cf6229701e5089c904175ce9",
            "tree": "ac98b18d71fffc6cc0ff7fc07ccd32ccda8133d9",
            "archive": {"name": archive.name, "bytes": len(archive_bytes), "sha256": hashlib.sha256(archive_bytes).hexdigest()},
            "regular_member_count": len(all_members), "payload_bytes": sum(m["bytes"] for m in all_members),
            "regular_members": all_members,
            "embedded_index": {"path": "members.json", "self_excluded_from_embedded_index": True,
                               "included_in_outer_regular_members": True, "bytes": len(embedded_bytes),
                               "sha256": hashlib.sha256(embedded_bytes).hexdigest()},
            "validation": {"all_regular_members_re_read": True, "every_size_and_sha256_verified": True,
                           "no_absolute_or_parent_paths": True, "no_links_or_duplicate_members": True,
                           "source_tree_dependencies_builds_caches_included": False}}
(destination / "retention-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
for name in ["REPORT.md", "summary.json"]:
    shutil.copyfile(source / name, destination / name)
print(json.dumps({key: manifest[key] for key in ["archive", "regular_member_count", "payload_bytes", "embedded_index", "validation"]}, indent=2))
