# Retrieval and scope notes

All evidence requests were read-only GitHub connector or `gh api` GET operations for repository kalwad/jobapplyv2, exact run38984225730 or exact final head1d490d1230b443c31fd4a9d8732064552affe149. Status polling used sensible backoff, generally one to three minutes while unchanged. Each terminal raw job log and final job API was downloaded once. No CI retry, rerun or cancellation occurred.

All requested final source responses succeeded. Seven decoded snapshots are checked against their Git blob SHA-1 identifiers and response sizes; source-files.json records SHA-256 hashes. The declared Python capability inventory is preserved as an exact source snapshot and compared against every collected node ID, including parameter IDs containing whitespace.

GitHub Git Data commit metadata, root tree metadata and root tree byte preimage are included. The bundle is not a complete repository clone. It retains complete available public job stdout/stderr and complete final aggregate/pytest summaries for all three platforms. Prior d99/918/fc runs remain separate archives; their historical outcomes are not relabelled.

CI one-sample native128 measurements are separate from the local 20-sample target campaign. No later revision is covered. An ordinary successful CI run is not a gate-owner decision, independent project approval, or packaged product certification.
