from pathlib import Path
import datetime, hashlib, json, stat, tarfile, tomllib
E=Path(__file__).parent
P=E/'m03-w11-native-zoom-preparation/v1'
O=E/'m03-w11-native-zoom-root-review/v1'
O.mkdir(parents=True,exist_ok=False)
R=Path('/Users/tanishkalwad/jobapplyv2')
checks=[]
def check(name,condition,detail=None):
    checks.append({'name':name,'pass':bool(condition),'detail':detail})
    assert condition,name
def sha(b):return hashlib.sha256(b).hexdigest()
src=json.loads((P/'SOURCE.json').read_text())
check('subject SOURCE seal',sha((P/'SOURCE.json').read_bytes())=='4f000271d56c3f344c369e13701c3361526cbceea0ed52cd99aacb05577bbb58')
for name,row in src['files'].items():
    p=P/name;s=p.lstat();b=p.read_bytes()
    check('member '+name,stat.S_ISREG(s.st_mode) and len(b)==row['bytes'] and sha(b)==row['sha256'] and oct(stat.S_IMODE(s.st_mode))==row['mode'])
for name in ['apps/desktop/src-tauri/tauri.conf.json','apps/desktop/src-tauri/capabilities/main-shell.json','apps/desktop/src-tauri/src/diagnostics/tests/tauri.rs']:
    check('canonical preimage '+name,(R/name).read_bytes()==(P/'before'/name).read_bytes())
conf0=json.loads((P/'before/apps/desktop/src-tauri/tauri.conf.json').read_text())
conf1=json.loads((P/'after/apps/desktop/src-tauri/tauri.conf.json').read_text())
check('only one declared native main window',len(conf1['app']['windows'])==1 and conf1['app']['windows'][0]['label']=='main')
check('new native flag true',conf1['app']['windows'][0].pop('zoomHotkeysEnabled') is True)
check('all other native config equal',conf1==conf0)
cap0=json.loads((P/'before/apps/desktop/src-tauri/capabilities/main-shell.json').read_text())
cap1=json.loads((P/'after/apps/desktop/src-tauri/capabilities/main-shell.json').read_text())
check('only one appended core permission',cap1['permissions']==cap0['permissions']+['core:webview:allow-set-webview-zoom'])
cap1.pop('description');cap0.pop('description');cap1['permissions'].pop()
check('all other caller-context capability fields equal',cap1==cap0)
t0=(P/'before/apps/desktop/src-tauri/src/diagnostics/tests/tauri.rs').read_text()
t1=(P/'after/apps/desktop/src-tauri/src/diagnostics/tests/tauri.rs').read_text()
check('no removed tests',t0.count('#[test]')==t1.count('#[test]')==4)
check('real ACL resolved artifacts used',all(x in t1 for x in ['Resolved::resolve(&acl, capabilities, Target::current())','runtime_authority!(acl, resolved)','get_ipc_response']))
check('new actual command authorized and denied from remote/other caller',t1.count('"plugin:webview|set_webview_zoom"')==2 and '(&other, local_app_origin())' in t1 and '(&window, "https://private.example/secret")' in t1)
check('unlisted sensitive core denials added',all(x in t1 for x in ['"plugin:webview|webview_close"','"plugin:webview|create_webview_window"']))
check('original application manifest and unlisted dispatch guard retained',all(x in t1 for x in ['assert!(resolved.has_app_acl)','assert_eq!(UNLISTED_CALLS.load(std::sync::atomic::Ordering::SeqCst), 0)','"arbitrary_http"','"UNSAFE_REGISTERED_COMMAND_REACHED"']))
sdk=json.loads((P/'sdk-source.json').read_text())
lock=(R/'apps/desktop/src-tauri/Cargo.lock').read_bytes()
check('Cargo.lock exact finite reference',len(lock)==sdk['Cargo_lock']['bytes'] and sha(lock)==sdk['Cargo_lock']['sha256'])
packages={(x['name'],x['version']):x for x in tomllib.loads(lock.decode())['package']}
archives={}
for i,row in enumerate(sdk['sources']):
    key=(row['crate'],row['version']); info=packages[key]
    check('SDK lock pin '+str(i),info['checksum']==row['Cargo_lock_package_checksum'])
    p=Path(row['path']);b=p.read_bytes()
    check('SDK body '+str(i),len(b)==row['file']['bytes'] and sha(b)==row['file']['sha256'])
    check('SDK source excerpt '+str(i),'\n'.join(b.decode().splitlines()[row['line_start']-1:row['line_end']])==row['excerpt'])
    crate=f'{key[0]}-{key[1]}'
    if key not in archives:
        archive=Path('/Users/tanishkalwad/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f')/(crate+'.crate')
        check('SDK registry archive pin '+crate,sha(archive.read_bytes())==info['checksum'])
        archives[key]=archive
    rel=p.relative_to(Path('/Users/tanishkalwad/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f')/crate)
    with tarfile.open(archives[key],'r:gz') as tar:
        member=tar.getmember(crate+'/'+rel.as_posix())
        check('SDK archive selected member '+str(i),member.isfile() and tar.extractfile(member).read()==b)
check('no claim of rendering in mock', 'fn set_zoom(&self, scale_factor: f64) -> Result<()> {\n    Ok(())' in '\n'.join(x['excerpt'] for x in sdk['sources']))
report={'schema':'japp-source-only-native-zoom-review-v1','observed_utc':datetime.datetime.now(datetime.UTC).isoformat(),'subject':str(P),'subject_source_sha256':sha((P/'SOURCE.json').read_bytes()),'reviewer':'root; different from native_integration_review author','verdict':'CLEAR_SOURCE_ONLY; compile and native acceptance pending','checks':checks,'actual_commands_or_gui':False,'limits':['No compile, ACL command execution, build, 200 percent native rendering, VoiceOver or cross-platform acceptance in this review.','Built-in zoom permission limits caller context; optional target label has no independent argument scope. Current product declares only main and denies creating other windows.','Mock set_zoom returns success without rendering; later ACL tests prove authorization only.','Later root adoption must recheck all three preimages and run the existing resolved ACL suite and native modes before any UI claim.']}
(O/'data-review.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
(O/'reviewer-executed.py').write_bytes(Path(__file__).read_bytes())
(O/'REVIEW.md').write_text('''# Native zoom source review\n\nCLEAR for the finite source proposal, subject to fresh compilation and native validation. Root is different from the author. The source changes the existing main window configuration and appends one built-in permission. It preserves the old four permissions, application command manifest, local caller restriction, CSP and all other configuration. The existing resolved-ACL tests exercise the actual dispatcher with a valid zoom value and remote/other-window denials; they retain the old unlisted command and service assertions. No test is removed.\n\nSelected SDK bodies were independently joined to registry archive members and Cargo.lock checksums. The pinned framework defaults page-zoom hotkeys off. On macOS/Linux the flag injects its main-frame zoom polyfill, which invokes the core zoom command; Windows forwards the flag to WebView2. This supports the proposed correction to the observed missing native keyboard zoom. The built-in permission restricts caller context, and does not restrict the optional target-label argument. Current product configuration has only main and denies creating more windows.\n\nThis review executes no compiler, renderer, native UI or command dispatcher. Mock set_zoom returns success without rendering. Actual 200 percent rendering, reset, keyboard access and readability on all seven routes remain required after fresh build; no W11 or accessibility acceptance follows from this source review. All writes are outside the canonical checkout during the clean aggregate freeze.\n''')
rows=[]
for p in sorted(O.iterdir()):
    if p.is_file():
        b=p.read_bytes();rows.append({'path':p.name,'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(p.stat().st_mode)})
(O/'MANIFEST.json').write_text(json.dumps({'members':rows},indent=2,sort_keys=True)+'\n')
print(json.dumps({'checks':len(checks),'verdict':report['verdict'],'data_sha256':sha((O/'data-review.json').read_bytes()),'review_sha256':sha((O/'REVIEW.md').read_bytes()),'manifest_sha256':sha((O/'MANIFEST.json').read_bytes())}))
