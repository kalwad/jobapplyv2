from pathlib import Path
import datetime,hashlib,json,marshal,os,shutil,signal,stat,subprocess,time
R=Path('/Users/tanishkalwad/jobapplyv2');O=Path(__file__).parent;A=O/'actual';A.mkdir();PY=R/'.venv/bin/python';BASE=json.loads((O.parent.parent/'full-bd4cffd/before.json').read_text())
def row(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode);return {'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'full_mode':s.st_mode,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def dump(n,v):(A/n).write_text(json.dumps(v,indent=2)+'\n')
def snapshot():
 return {'source':{n:row(R/n) for n in BASE['source']},'runtime':{n:row(R/'apps/desktop/src-tauri/runtime-payload'/n) for n in BASE['runtime']},'status':subprocess.check_output(['git','status','--porcelain=v1'],cwd=R).decode(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=R).decode().strip()}
before=snapshot();dump('before.json',before)
inputs={}
for f in sorted((R/'scripts/windows11/__pycache__').iterdir()):
 raw=f.read_bytes();code=marshal.loads(raw[16:]);source=R/'scripts/windows11'/(f.name.split('.')[0]+'.py');expected=compile(source.read_bytes(),str(source),'exec',dont_inherit=True,optimize=0);inputs[f.name]={'body':row(f),'embedded_co_filename':code.co_filename,'origin_source':str(source),'source':row(source),'origin_marshaled_code_exact':raw[16:]==marshal.dumps(expected)}
dump('actual-origin-cache.json',inputs)
commands=[]
def run(label,argv,cwd,expected=0):
 env={'PATH':'/usr/bin:/bin:/usr/sbin:/sbin','HOME':str(O/'owned-home'),'TMPDIR':str(O/'owned-temp'),'PYTHONDONTWRITEBYTECODE':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','LC_ALL':'C.UTF-8','MYPY_CACHE_DIR':str(O/'mypy-cache')}
 for d in ('owned-home','owned-temp'):(O/d).mkdir(exist_ok=True)
 t=time.monotonic();child=subprocess.Popen(argv,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);sent=[];timeout=False
 try:out,err=child.communicate(timeout=50)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(child.pid,signal.SIGTERM);sent.append('SIGTERM')
  try:out,err=child.communicate(timeout=3)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);sent.append('SIGKILL');out,err=child.communicate(timeout=3)
 (A/(label+'.stdout')).write_bytes(out);(A/(label+'.stderr')).write_bytes(err)
 try:os.killpg(child.pid,0);group='PRESENT'
 except ProcessLookupError:group='ABSENT'
 receipt={'label':label,'argv':[str(v) for v in argv],'cwd':str(cwd),'environment':env,'pid':child.pid,'pgid':child.pid,'exit_code':child.returncode,'expected_exit_code':expected,'elapsed_seconds':time.monotonic()-t,'direct_child_reaped':child.poll() is not None,'group_after_reap':group,'signals':sent,'timeout':timeout,'stdout_sha256':hashlib.sha256(out).hexdigest(),'stderr_sha256':hashlib.sha256(err).hexdigest()};commands.append(receipt);dump('commands.json',commands);assert child.returncode==expected and group=='ABSENT' and not sent and not timeout
 return out
failed=None
try:
 red=O/'projection/red';fixed=O/'projection/fixed';test='scripts/tests/test_windows11_isolation.py';sel=['-B','-m','pytest','-c','pyproject.toml',test,'-p','no:cacheprovider']
 r=run('01-origin-cache-relocation-RED',[str(PY),*sel,'--basetemp',str(O/'red-temp'),'-q'],red,1);assert b'1 failed, 13 passed' in r and b'cache differs from exact source compile' in r
 f=run('02-fixed-and-negative-controls',[str(PY),*sel,'--basetemp',str(O/'fixed-temp'),'-q'],fixed);assert b'17 passed' in f
 old=run('03-original-collection',[str(PY),*sel,'--collect-only','-q'],red);new=run('04-fixed-collection',[str(PY),*sel,'--collect-only','-q'],fixed)
 oldids=[l for l in old.decode().splitlines() if l.startswith(test+'::')];newids=[l for l in new.decode().splitlines() if l.startswith(test+'::')];assert len(oldids)==14 and len(newids)==17 and set(oldids)<=set(newids)
 added=json.loads((O/'catalog-additions.json').read_text())['new_common_ids'];assert set(newids)-set(oldids)==set(added)
 dump('collection.json',{'old':oldids,'new':newids,'added':added,'all_original_ids_retained':True})
 run('05-ruff-check',[str(PY),'-B','-m','ruff','check','--config',str(R/'pyproject.toml'),str(O/'after'/test)],O)
 run('06-ruff-format',[str(PY),'-B','-m','ruff','format','--check','--config',str(R/'pyproject.toml'),str(O/'after'/test)],O)
 run('07-mypy-win32',[str(PY),'-B','-m','mypy','--config-file',str(R/'pyproject.toml'),'--platform','win32','--no-incremental','--cache-dir',str(O/'mypy-cache-win32'),str(O/'after'/test)],O)
except BaseException as e:failed={'type':type(e).__name__,'message':str(e)}
finally:
 after=snapshot();dump('after.json',after);dump('closure.json',{'end_utc':datetime.datetime.now(datetime.UTC).isoformat(),'source_count':len(before['source']),'runtime_count':len(before['runtime']),'source_runtime_status_HEAD_tree_equal':before==after,'all_owned_children_reaped_groups_absent':all(r['direct_child_reaped'] and r['group_after_reap']=='ABSENT' and not r['signals'] and not r['timeout'] for r in commands),'actual_commands':len(commands),'failure':failed,'RED_is_retained_observed_fixture_failure':True,'no_product_native_browser_network_actor':True});print(json.dumps({'commands':len(commands),'failure':failed,'endpoint_equal':before==after}))
if failed:raise SystemExit(1)
