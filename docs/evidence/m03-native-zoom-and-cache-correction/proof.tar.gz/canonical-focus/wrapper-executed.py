from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import stat
import subprocess
import time

E=Path(__file__).parent;R=Path('/Users/tanishkalwad/jobapplyv2');O=E/'native-zoom-bytecode-canonical-focus-v1';O.mkdir()
def dump(n,x):(O/n).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def row(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode);b=p.read_bytes()
 return {'bytes':len(b),'mode':stat.S_IMODE(s.st_mode),'sha256':hashlib.sha256(b).hexdigest()}
def snap():
 raw=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=R)
 files={os.fsdecode(n):row(R/os.fsdecode(n)) for n in sorted(set(raw.split(b'\0'))-{b''})}
 base=R/'apps/desktop/src-tauri/runtime-payload'
 runtime={p.relative_to(base).as_posix():row(p) for p in sorted(base.rglob('*')) if not p.is_dir()}
 return {'files':files,'runtime':runtime,'status':subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=R,text=True),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=R,text=True).strip()}
assert json.loads((E/'full-bd4cffd/closure.json').read_text())['all_commands_exit_zero'] is False
assert (E/'native-zoom-and-bytecode-canonical-adoption-v1/ADOPTED.json').is_file()
before=snap();adopted=json.loads((E/'native-zoom-and-bytecode-canonical-adoption-v1/after.json').read_text());assert before['files']==adopted['source'] and before['runtime']==adopted['runtime'] and len(before['files'])==2294
dump('before.json',before);(O/'wrapper-executed.py').write_bytes(Path(__file__).read_bytes())
env=dict(os.environ);env['PATH']='/opt/homebrew/opt/node@24/bin:/Users/tanishkalwad/.local/share/uv/python/cpython-3.12.13-macos-aarch64-none/bin:'+env['PATH'];env['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1';env['PYTHONDONTWRITEBYTECODE']='1'
prefix=['uv','run','--no-sync','--offline']
tests=['scripts/tests/test_windows11_inputs.py','scripts/tests/test_windows11_request.py','scripts/tests/test_windows11_isolation.py','scripts/tests/test_windows11_resources.py','scripts/tests/test_ubuntu_gnome_signed_indexes.py','scripts/tests/test_ci_workflow.py']
commands=[
 ['cargo','fmt','--manifest-path','apps/desktop/src-tauri/Cargo.toml','--','--check'],
 ['cargo','clippy','--locked','--manifest-path','apps/desktop/src-tauri/Cargo.toml','--all-targets','--all-features','--','-D','warnings'],
 prefix+['python','scripts/verify.py','--suite','rust'],
 prefix+['ruff','check','--config','pyproject.toml','scripts/check_portability.py','scripts/windows11','scripts/tests'],
 prefix+['ruff','format','--check','--config','pyproject.toml','scripts/check_portability.py','scripts/windows11','scripts/tests'],
 prefix+['mypy','--config-file','pyproject.toml','--platform','linux','scripts/check_portability.py','scripts/windows11',*tests],
 prefix+['mypy','--config-file','pyproject.toml','--platform','win32',*tests],
 ['pnpm','exec','prettier','--check','.github/windows11','.github/workflows/windows11-native-prepare.yml','.github/workflows/windows11-native-lifecycle.yml','package.json','scripts/python-test-inventory.v1.json','scripts/verification-suites.json','apps/desktop/src-tauri/tauri.conf.json','apps/desktop/src-tauri/capabilities/main-shell.json'],
 prefix+['pytest','-c','pyproject.toml','--strict-config','--strict-markers','-p','no:cacheprovider','--basetemp',str(O/'pytest-temp'),'-q',*tests],
 prefix+['pytest','-c','pyproject.toml','--strict-config','--strict-markers','-p','no:cacheprovider','--collect-only','-q','services/orchestrator/tests','scripts/tests'],
 prefix+['python','scripts/check_portability.py','--quiet'],
 prefix+['python','scripts/verify.py','--suite','integrity'],
]
results=[]
for i,argv in enumerate(commands,1):
 start=time.monotonic();timed_out=False;sent=[]
 with (O/f'{i:02}.stdout').open('wb') as out,(O/f'{i:02}.stderr').open('wb') as err:
  p=subprocess.Popen(argv,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
  try:code=p.wait(timeout=180)
  except subprocess.TimeoutExpired:
   timed_out=True
   for sig in [signal.SIGTERM,signal.SIGKILL]:
    if p.poll() is not None:break
    try:os.killpg(p.pid,sig);sent.append(sig.name)
    except ProcessLookupError:pass
    try:p.wait(timeout=2)
    except subprocess.TimeoutExpired:pass
   code=p.wait(timeout=5)
 try:os.killpg(p.pid,0);group='PRESENT_AFTER_REAP'
 except ProcessLookupError:group='ABSENT'
 result={'argv':argv,'exit_code':code,'seconds':time.monotonic()-start,'timeout':timed_out,'signals':sent,'reaped':p.returncode is not None,'group':group,'stdout':row(O/f'{i:02}.stdout'),'stderr':row(O/f'{i:02}.stderr')};results.append(result);dump('results.json',results);print(json.dumps(result),flush=True)
 if code or group!='ABSENT' or timed_out or sent:break
after=snap();dump('after.json',after)
closure={'end_utc':datetime.datetime.now(datetime.UTC).isoformat(),'all_twelve_commands_closed_zero':len(results)==12 and all(r['exit_code']==0 and r['group']=='ABSENT' and not r['timeout'] and not r['signals'] for r in results),'source_runtime_bytes_fullmodes_status_head_tree_equal':before==after,'source_count':len(before['files']),'runtime_count':len(before['runtime'])}
dump('closure.json',closure);print(json.dumps(closure),flush=True)
raise SystemExit(0 if closure['all_twelve_commands_closed_zero'] and closure['source_runtime_bytes_fullmodes_status_head_tree_equal'] else 1)
