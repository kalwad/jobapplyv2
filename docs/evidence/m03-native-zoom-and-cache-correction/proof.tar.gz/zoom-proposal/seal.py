from pathlib import Path
import json,hashlib,stat,difflib,tomllib,datetime,tarfile
B=Path(__file__).parent;R=Path('/Users/tanishkalwad/jobapplyv2');C=Path('/Users/tanishkalwad/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f')
def row(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink();return {'bytes':s.st_size,'mode':oct(stat.S_IMODE(s.st_mode)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
lock=tomllib.loads((R/'apps/desktop/src-tauri/Cargo.lock').read_text());packages={p['name']:p for p in lock['package'] if p['name'] in {'tauri','tauri-utils','tauri-runtime-wry','wry'}}
specs=[('tauri','src/webview/mod.rs',1110,1128),('tauri','src/manager/webview.rs',577,600),('tauri','src/webview/scripts/zoom-hotkey.js',1,44),('tauri','src/webview/plugin.rs',51,105),('tauri','src/webview/plugin.rs',117,124),('tauri','src/ipc/authority.rs',458,489),('tauri','src/test/mock_runtime.rs',591,597),('tauri-utils','src/config.rs',2187,2198),('tauri-utils','src/config.rs',2445,2454),('tauri-runtime-wry','src/lib.rs',4739,4747),('wry','src/webview2/mod.rs',634,642)]
rows=[]
for package,name,start,end in specs:
 p=packages[package];root=C/(package+'-'+p['version']);file=root/name;body=file.read_bytes()
 archive=C.parents[1]/'cache'/C.name/(package+'-'+p['version']+'.crate')
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==p['checksum']
 with tarfile.open(archive,'r:gz') as tar:
  member=tar.getmember(package+'-'+p['version']+'/'+name)
  assert member.isfile() and tar.extractfile(member).read()==body
 lines=body.decode().splitlines()
 rows.append({'crate':package,'version':p['version'],'Cargo_lock_package_checksum':p['checksum'],'path':str(file),'file':row(file),'line_start':start,'line_end':end,'excerpt':'\n'.join(lines[start-1:end])})
dump(B/'sdk-source.json',{'scope':'Pinned primary implementation; local cached .crate archive SHA256 matches Cargo.lock and selected regular member bytes equal SDK source; no runtime execution','Cargo_lock':row(R/'apps/desktop/src-tauri/Cargo.lock'),'sources':rows})
paths=sorted(p.relative_to(B/'after').as_posix() for p in (B/'after').rglob('*') if p.is_file());assert len(paths)==3
old_conf=json.loads((B/'before/apps/desktop/src-tauri/tauri.conf.json').read_bytes());new_conf=json.loads((B/'after/apps/desktop/src-tauri/tauri.conf.json').read_bytes());assert new_conf['app']['windows'][0].pop('zoomHotkeysEnabled') is True and old_conf==new_conf
oldcap=json.loads((B/'before/apps/desktop/src-tauri/capabilities/main-shell.json').read_bytes());newcap=json.loads((B/'after/apps/desktop/src-tauri/capabilities/main-shell.json').read_bytes());assert newcap['permissions']==oldcap['permissions']+['core:webview:allow-set-webview-zoom'];newcap.pop('description');oldcap.pop('description');newcap['permissions'].pop();assert newcap==oldcap
adopt=[];patch=[]
for name in paths:
 before=B/'before'/name;after=B/'after'/name;assert row(before)==row(R/name);adopt.append({'path':name,'operation':'replace','before':row(before),'after':row(after)});patch.extend(difflib.unified_diff(before.read_text().splitlines(True),after.read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(B/'correction.patch').write_text(''.join(patch));dump(B/'ADOPTION.json',{'targets':adopt,'scope':'later separate W11 source proposal, not current S2','unchanged_historical_W01_fixture':row(R/'apps/desktop/src-tauri/tests/fixtures/w01-main-shell.json'),'source_only_semantic_checks':{'only_main_zoom_flag':True,'old4_permissions_preserved_exactly':True,'single_zoom_permission_added':True,'CSP_devCSP_and_all_other_config_exact':True,'capability_main_local_remote_policy_exact':True},'actual_checks':['standalone rustfmt --edition2024 on proposed tauri.rs returned0','explicit root .prettierrc formatting applied to proposed JSON only'],'pending':['compile and existing actual resolved-ACL tests after normal generated ACL regeneration','actual native200% readable usable routes/keyboard/reset/lifecycle'],'limits':['no compile/build/GUI/native actor','built-in command caller-context scope is not independent target-label argument scope']})
selected=[p for p in sorted(B.rglob('*')) if p.is_file() and p.name not in {'SOURCE.json','HANDOFF.json','seal.py','prepare.py'}]
source={'schema':'japp-m03-w11-native-zoom-source-preparation-v1','sealed_utc':datetime.datetime.now(datetime.UTC).isoformat(),'files':{p.relative_to(B).as_posix():row(p) for p in selected},'targets':3,'no_canonical_writes':True,'no_actor_or_build':True};dump(B/'SOURCE.json',source)
dump(B/'HANDOFF.json',{'SOURCE':row(B/'SOURCE.json'),'ADOPTION':row(B/'ADOPTION.json'),'patch':row(B/'correction.patch'),'targets':3,'native_zoom_validation':'PENDING after separate review/adoption; no200%claim','state_promotion':False})
print(json.dumps({'SOURCE':row(B/'SOURCE.json'),'HANDOFF':row(B/'HANDOFF.json'),'ADOPTION':row(B/'ADOPTION.json'),'patch':row(B/'correction.patch')},indent=2))
