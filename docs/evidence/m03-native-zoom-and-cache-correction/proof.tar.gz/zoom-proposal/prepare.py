from pathlib import Path
import json,shutil,difflib,hashlib,stat,datetime
B=Path(__file__).parent;R=Path('/Users/tanishkalwad/jobapplyv2')
paths=['apps/desktop/src-tauri/tauri.conf.json','apps/desktop/src-tauri/capabilities/main-shell.json','apps/desktop/src-tauri/src/diagnostics/tests/tauri.rs']
for n in paths:
 for folder in ('before','after'):
  p=B/folder/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/n,p)
p=B/'after'/paths[0];v=json.loads(p.read_bytes());assert len(v['app']['windows'])==1 and v['app']['windows'][0]['label']=='main';v['app']['windows'][0]['zoomHotkeysEnabled']=True;p.write_text(json.dumps(v,indent=2)+'\n')
p=B/'after'/paths[1];v=json.loads(p.read_bytes());v['description']='Read app versions and finite native local service diagnostics, and allow native page zoom from the local main window.';v['permissions'].append('core:webview:allow-set-webview-zoom');p.write_text(json.dumps(v,indent=2)+'\n')
p=B/'after'/paths[2];s=p.read_text();needle='    assert_eq!(cancel["payload"]["outcome"], "ALREADY_FINISHED");';assert s.count(needle)==1;s=s.replace(needle,needle+'''
    // Exercise the real resolved core ACL with the framework's mock dispatcher.
    // This proves local authorization; it does not measure actual native zoom.
    let zoom = get_ipc_response(
        &window,
        request(
            "plugin:webview|set_webview_zoom",
            local_app_origin(),
            InvokeBody::Json(json!({"value": 2.0})),
        ),
    )
    .unwrap()
    .deserialize::<Value>()
    .unwrap();
    assert!(zoom.is_null());
    for cmd in ["plugin:webview|webview_close", "plugin:webview|create_webview_window"] {
        assert!(get_ipc_response(&window, request(cmd, local_app_origin(), InvokeBody::Json(json!({})))).is_err());
    }
''');needle='''    }
}
#[test]
fn actual_command_rejects_extra_top_level_fields_and_raw_payload()''';assert s.count(needle)==1;s=s.replace(needle,'''    }
    for (caller, origin) in [
        (&other, local_app_origin()),
        (&window, "https://private.example/secret"),
    ] {
        assert!(get_ipc_response(
            caller,
            request("plugin:webview|set_webview_zoom", origin, InvokeBody::Json(json!({"value": 2.0}))),
        ).is_err());
    }
}
#[test]
fn actual_command_rejects_extra_top_level_fields_and_raw_payload()''');s=s.replace('''            "allow-cancel-service-request"
''','''            "allow-cancel-service-request",
            "core:webview:allow-set-webview-zoom"
''');p.write_text(s)
# Author proposal only; no compilation or build. Formatting will use standalone rustfmt.
