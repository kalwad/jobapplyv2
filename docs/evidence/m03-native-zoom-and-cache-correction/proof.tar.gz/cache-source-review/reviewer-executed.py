from pathlib import Path
import ast,datetime,hashlib,json,re,stat
E=Path(__file__).parent;P=E/'windows11-bytecode-fixture-preparation/v1';R=Path('/Users/tanishkalwad/jobapplyv2');O=E/'windows11-bytecode-fixture-root-review/v1';O.mkdir(parents=True)
checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def check(n,v):
 checks.append({'name':n,'pass':bool(v)});assert v,n
def bodyrow(p):
 s=p.lstat();b=p.read_bytes();return {'bytes':len(b),'mode':stat.S_IMODE(s.st_mode),'full_mode':s.st_mode,'sha256':sha(b)}
check('subject SOURCE pin',sha((P/'SOURCE.json').read_bytes())=='a76937a0fe0cf3500237fc5b8e4d55a6570ba910af704a5d109e1575ff9323a6')
check('subject MANIFEST pin',sha((P/'MANIFEST.json').read_bytes())=='9518b703f9587b7a571f4a829bb39e2e005ddce585213bf91d5b4db076255a63')
manifest=json.loads((P/'MANIFEST.json').read_text());source=json.loads((P/'SOURCE.json').read_text())
for r in manifest['files']:
 p=P/r['path'];check('member '+r['path'],stat.S_ISREG(p.lstat().st_mode) and not p.is_symlink() and bodyrow(p)=={k:r[k] for k in ['bytes','mode','full_mode','sha256']})
check('exact two target paths',{r['path'] for r in source['changes']}=={'scripts/tests/test_windows11_isolation.py','scripts/python-test-inventory.v1.json'})
for r in source['changes']:
 n=r['path'];check('canonical preimage '+n,bodyrow(R/n)==r['before']);check('retained before '+n,bodyrow(P/'before'/n)==r['before']);check('retained after '+n,bodyrow(P/'after'/n)==r['after'])
check('production checker exact unchanged',bodyrow(R/'scripts/check_portability.py')==source['production_checker'])
n='scripts/tests/test_windows11_isolation.py';old=ast.parse((P/'before'/n).read_text());new=ast.parse((P/'after'/n).read_text())
oldtests={x.name:ast.dump(x,include_attributes=False) for x in old.body if isinstance(x,ast.FunctionDef) and x.name.startswith('test_')};newtests={x.name:ast.dump(x,include_attributes=False) for x in new.body if isinstance(x,ast.FunctionDef) and x.name.startswith('test_')}
for name,a in oldtests.items():check('original test AST '+name,newtests[name]==a)
check('one additive test function',set(newtests)-set(oldtests)=={'test_generated_bytecode_requires_exact_local_source'})
new.body=[x for x in new.body if not (isinstance(x,ast.FunctionDef) and x.name=='test_generated_bytecode_requires_exact_local_source') and not (isinstance(x,ast.Import) and len(x.names)==1 and x.names[0].name=='py_compile')]
fixture=next(x for x in new.body if isinstance(x,ast.FunctionDef) and x.name=='island');calls=[x for x in ast.walk(fixture) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and isinstance(x.func.value,ast.Name) and x.func.value.id=='shutil' and x.func.attr=='copytree'];changed=calls[0]
check('exact cache projection omission AST',ast.dump(changed.keywords[0].value,include_attributes=False)==ast.dump(ast.parse('shutil.ignore_patterns("__pycache__")',mode='eval').body,include_attributes=False) and len(changed.keywords)==1 and changed.keywords[0].arg=='ignore');changed.keywords=[]
check('whole original module AST otherwise unchanged',ast.dump(old,include_attributes=False)==ast.dump(new,include_attributes=False))
oldcat=json.loads((P/'before/scripts/python-test-inventory.v1.json').read_text());newcat=json.loads((P/'after/scripts/python-test-inventory.v1.json').read_text());o=oldcat['common']['node_ids'];a=newcat['common']['node_ids'];add=source['actual_collection']['new_cases']
check('catalog sorted unique additive three',len(a)==2625 and a==sorted(set(a)) and set(a)-set(o)==set(add) and len(add)==3)
for ident in o:check('old common ID retained '+ident,ident in a)
for obj in [oldcat,newcat]:
 ids=obj['common']['node_ids'];expected=obj['common']['sha256'];check('canonical common ID digest '+str(len(ids)),sha(('\n'.join(ids)+'\n').encode())==expected)
newcat['common']=oldcat['common'];check('all other catalog fields unchanged',newcat==oldcat)
cmds=json.loads((P/'actual/commands.json').read_text());check('exact seven owned commands',len(cmds)==7)
for c in cmds:
 check('owned closure '+c['label'],c['exit_code']==c['expected_exit_code'] and c['direct_child_reaped'] and c['group_after_reap']=='ABSENT' and not c['timeout'] and c['signals']==[])
check('truthful expected RED',(P/'actual/01-origin-cache-relocation-RED.stdout').read_text().count('1 failed, 13 passed')==1 and cmds[0]['exit_code']==1)
check('corrected 17 actual',(P/'actual/02-fixed-and-negative-controls.stdout').read_text().count('17 passed')==1 and cmds[1]['exit_code']==0)
oldids=set(re.findall(r'^scripts/tests/test_windows11_isolation\.py::[^\r\n]+$',(P/'actual/03-original-collection.stdout').read_text(),re.M));newids=set(re.findall(r'^scripts/tests/test_windows11_isolation\.py::[^\r\n]+$',(P/'actual/04-fixed-collection.stdout').read_text(),re.M))
check('actual 14 to17 collection exact',len(oldids)==14 and len(newids)==17 and oldids<=newids and newids-oldids==set(add))
check('unchanged canonical guard endpoints',json.loads((P/'actual/before.json').read_text())==json.loads((P/'actual/after.json').read_text()))
c=json.loads((P/'actual/closure.json').read_text());check('actual guard closure',c['source_count']==2294 and c['runtime_count']==40 and c['source_runtime_status_HEAD_tree_equal'] and c['all_owned_children_reaped_groups_absent'] and c['failure'] is None)
report={'observed_utc':datetime.datetime.now(datetime.UTC).isoformat(),'verdict':'CLEAR_SOURCE_AND_RETAINED_FOCUS; fresh canonical integration pending','reviewer':'root; different from native_integration_review author','checks':checks,'subject_source_sha256':sha((P/'SOURCE.json').read_bytes()),'scope':'Two-path test fixture/catalog correction; no production or oracle weakening; original bd4 aggregate remains failed.','fresh_test_execution_in_this_review':False}
(O/'data-review.json').write_text(json.dumps(report,indent=2)+'\n');(O/'reviewer-executed.py').write_bytes(Path(__file__).read_bytes())
(O/'REVIEW.md').write_text('''# Windows11 fixture correction review\n\nCLEAR for the two-path fixture/catalog proposal and its retained focused evidence. Root is different from the author. The only original-behavior change omits generated __pycache__ from the inert source fixture projection. Every old test function, payload and assertion is AST-identical; after removing the one new import/test and this one keyword, the complete old module AST is identical. The exact production cache validator and allowed source set remain unchanged.\n\nThe three new cases first accept bytecode compiled from the actual fixture destination, then require refusal of relocated, payload-modified or flags-modified caches. They compile the inert guard as data, without importing or executing it. The additive catalog retains all2622old common and the unchanged two POSIX identities, adding only the three actual collected cases:2625common/2627POSIX projected.\n\nOriginal cold/full and outside RED remain failures. Actual retained focused17PASS, strict Ruff/format and selected Windows-target Mypy pass; seven child closures include the expected RED exit1 and six exits0, with reaped children/groupsABSENT/no signals/timeouts. Source2294/runtime40/full-mode/status/HEAD-tree endpoints agree. Initial wrong old-case count and outside Ruff-path observer errors are retained. This review performs data/source checks only; root still needs guarded adoption, fresh canonical focused validation and a new clean full run. No later result transfers into bd4.\n''')
rows=[]
for p in sorted(O.iterdir()):
 if p.is_file():
  r=bodyrow(p);rows.append({'path':p.name,**r})
(O/'MANIFEST.json').write_text(json.dumps({'files':rows},indent=2)+'\n')
print(json.dumps({'checks':len(checks),'verdict':report['verdict'],'review_sha256':sha((O/'REVIEW.md').read_bytes()),'manifest_sha256':sha((O/'MANIFEST.json').read_bytes())}))
