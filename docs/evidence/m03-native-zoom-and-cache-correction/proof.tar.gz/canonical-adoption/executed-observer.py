from pathlib import Path
import datetime,hashlib,json,os,stat,subprocess
E=Path(__file__).parent;R=Path('/Users/tanishkalwad/jobapplyv2');Z=E/'m03-w11-native-zoom-preparation/v1';B=E/'windows11-bytecode-fixture-preparation/v1';O=E/'native-zoom-and-bytecode-canonical-adoption-v1'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
def row(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink();b=p.read_bytes();return {'bytes':len(b),'mode':stat.S_IMODE(s.st_mode),'sha256':sha(b)}
def snap():
 paths=subprocess.check_output(['git','ls-files','-z'],cwd=R).split(b'\0');files={os.fsdecode(n):row(R/os.fsdecode(n)) for n in paths if n};base=R/'apps/desktop/src-tauri/runtime-payload';runtime={p.relative_to(base).as_posix():row(p) for p in sorted(base.rglob('*')) if not p.is_dir() or p.is_symlink()};idx=R/'.git/index';return {'source':files,'runtime':runtime,'status':git('status','--porcelain'),'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'index':{'sha256':sha(idx.read_bytes()),'mtime_ns':idx.stat().st_mtime_ns}}
assert git('rev-parse','HEAD')=='bd4cffd7f61f99f77520e7dc522f852488cdd9d3' and git('status','--porcelain')==''
assert sha((E/'full-bd4cffd-independent-review/REVIEW.md').read_bytes())=='c342e00247937a30ac7c843454cbdafb213c0ee9f97dd73a1d280b1ba0b07086'
c=json.loads((E/'full-bd4cffd/closure.json').read_text());assert c['all_commands_exit_zero'] is False and c['source_count']==2294 and c['runtime_count']==40 and c['git_status_before']==c['git_status_after']=='' and all(c[k] for k in ['source_bytes_modes_unchanged','runtime_bytes_modes_unchanged','commit_and_tree_equal_at_end_observation'])
assert sha((Z/'SOURCE.json').read_bytes())=='4f000271d56c3f344c369e13701c3361526cbceea0ed52cd99aacb05577bbb58'
assert sha((B/'SOURCE.json').read_bytes())=='a76937a0fe0cf3500237fc5b8e4d55a6570ba910af704a5d109e1575ff9323a6'
assert sha((E/'m03-w11-native-zoom-root-review/v1/REVIEW.md').read_bytes())=='bad9791a461aea7864cbb48af881c186b3961d86d57ac04b7f3168a13bc03b76'
assert sha((E/'windows11-bytecode-fixture-root-review/v1/REVIEW.md').read_bytes())=='04d8858a05b481ab66343aaf045ab50f4d749b3c80a445708b163bdaa11caa9e'
for n,pin in json.loads((Z/'SOURCE.json').read_text())['files'].items():assert row(Z/n)=={'bytes':pin['bytes'],'mode':int(pin['mode'],8),'sha256':pin['sha256']}
for pin in json.loads((B/'MANIFEST.json').read_text())['files']:assert row(B/pin['path'])=={k:pin[k] for k in ['bytes','mode','sha256']}
changes={n:Z for n in ['apps/desktop/src-tauri/tauri.conf.json','apps/desktop/src-tauri/capabilities/main-shell.json','apps/desktop/src-tauri/src/diagnostics/tests/tauri.rs']};changes.update({n:B for n in ['scripts/tests/test_windows11_isolation.py','scripts/python-test-inventory.v1.json']})
before=snap();prior=json.loads((E/'full-bd4cffd/after.json').read_text());assert before['source']==prior['source'] and before['runtime']==prior['runtime'] and len(before['source'])==2294
for n,p in changes.items():assert row(R/n)==row(p/'before'/n)
assert not O.exists();O.mkdir();(O/'before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n');(O/'executed-observer.py').write_bytes(Path(__file__).read_bytes())
for n,p in changes.items():
 dest=O/'preimages'/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((R/n).read_bytes());dest.chmod((R/n).stat().st_mode&0o777)
 (R/n).write_bytes((p/'after'/n).read_bytes());assert row(R/n)==row(p/'after'/n)
after=snap();assert set(after['source'])==set(before['source']) and all(after['source'][n]==before['source'][n] for n in before['source'] if n not in changes)
assert all(after[k]==before[k] for k in ['runtime','head','tree','index'])
raw=subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True);assert set(raw.splitlines())=={' M '+n for n in changes}
(O/'after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n')
r={'observed_utc':datetime.datetime.now(datetime.UTC).isoformat(),'replacements':list(changes),'source_files':len(before['source']),'runtime_files':len(before['runtime']),'all_unselected_bytes_full_modes_unchanged':True,'runtime_index_HEAD_tree_unchanged':True,'prior_full_result':'FAILURE19PASS1PythonFAIL; immutable and independently reviewed','current_canonical_focus_build_gui':'PENDING'}
(O/'ADOPTED.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
