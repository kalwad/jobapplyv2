"""Finite retained-data/image metadata joins only; no current state or actors."""
from pathlib import Path
import json,hashlib,stat,re,datetime
B=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/m03-w11-macos-accessibility/v1');O=Path(__file__).parent
def jpeg_dimensions(path):
 data=path.read_bytes();assert data[:2]==b'\xff\xd8' and data[-2:]==b'\xff\xd9';offset=2
 for _ in range(1000):
  assert data[offset]==255
  while data[offset]==255:offset+=1
  marker=data[offset];offset+=1
  if marker in (0xd8,0xd9) or 0xd0<=marker<=0xd7:continue
  size=int.from_bytes(data[offset:offset+2],'big');assert size>=2 and offset+size<=len(data)
  if marker in (0xc0,0xc1,0xc2,0xc3,0xc5,0xc6,0xc7,0xc9,0xca,0xcb,0xcd,0xce,0xcf):
   return (int.from_bytes(data[offset+5:offset+7],'big'),int.from_bytes(data[offset+3:offset+5],'big'))
  offset+=size
 raise ValueError('No finite JPEG dimensions')
checks=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def row(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink();return {'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'sha256':sha(p)}
def check(n,v):checks.append({'name':n,'pass':bool(v)})
source=json.loads((B/'SOURCE.json').read_bytes());check('expected sealed source pin',sha(B/'SOURCE.json')=='058ed34c726acd249b6c9620d45c8ed3650db56b3fabc79d271b2e15c90da34d')
actual={p.relative_to(B).as_posix():row(p) for p in B.rglob('*') if p.is_file() and p.name!='SOURCE.json'}
check('complete finite regular source selection',set(actual)==set(source['files']))
for n,v in source['files'].items():check('retained body/bytes/mode '+n,actual[n]==v)
before=dict(actual)
post=json.loads((B/'post-ui-identity.json').read_bytes());build=json.loads((B/'original-app-build-source.json').read_bytes());prior=json.loads((B/'original-app-prior-observation.json').read_bytes());front=post['frontend14_equal_original_app_build_source']
check('declared historical43 post/prior maps exact',len(post['app_files'])==len(prior['app_files'])==43 and post['app_files']==prior['app_files'])
for n,v in post['app_files'].items():check('declared app43 fullmode '+n, v==prior['app_files'][n] and v['mode'] in {0o644,0o755})
check('historical build commit retained honestly',build['commit']==post['historical_app_build_commit']=='204bc06a374631f4b40d4fc382f573a77ef9242a' and build['tree']==post['historical_app_build_tree']=='5b5bfeda09b60654adce335e0e21cd9ad056e120')
check('prior GUI map later than build references9872',prior['head']=='9872acaf6191ce77fd1c077ef27ea972b71b8315' and prior['tree']=='f2d982dfe441ca6a98c2f9ae2862c3efd1e4373a' and prior['recorded_utc']<'2026-10-29T17:31:16Z')
check('post source context explicitly oldf5a twoM',post['current_head']=='f5a05bad78d8421a5c1e0094eb928fdbb464cdc7' and post['current_tree']=='aa9fbaa9addd16052eaeca6259852bc00bb03702' and set(post['current_status'].splitlines())=={' M apps/desktop/src-tauri/src/lib.rs',' M apps/desktop/src-tauri/src/main.rs'})
check('retained frontend complete14 selected rows',len(front)==14 and all(n.startswith(('apps/desktop/src/','packages/ui/src/')) for n in front))
for n,v in front.items():check('actual retained frontend14 versus originalbuild '+n,row(B/'frontend-reference'/n)==v==build['source'][n])
# Physical mode/body joins on supplied snapshots are not a re-read of historical app bytes.
texts={p.name:p.read_text() for p in B.glob('*.ax.txt')};events=json.loads((B/'events.json').read_bytes());images=[]
check('17AX trees/diffs plus8JPEGs and1terminalerror',len(texts)==17 and len(list(B.glob('*.jpg')))==8 and (B/'18-after-native-quit.error.txt').is_file())
check('actual first diagnostic capture is a diff',texts['01-diagnostics.ax.txt'].startswith('The following is a diff'))
nav=['Home','Jobs','Tracker','Documents / Resumes','Profile','Settings','Diagnostics']
surfaces=[('Diagnostics','diagnostics','02-tab.ax.txt','01-diagnostics.jpg'),('Home','home','05-home.ax.txt','05-home.jpg'),('Jobs','jobs','06-jobs.ax.txt','06-jobs.jpg'),('Tracker','tracker','07-tracker.ax.txt','07-tracker.jpg'),('Documents / Resumes','documents','08-documents.ax.txt','08-documents.jpg'),('Profile','profile','09-profile.ax.txt','09-profile.jpg'),('Settings','settings','10-settings.ax.txt','10-settings.jpg')]
for label,slug,ax,img in surfaces:
 text=texts[ax];body=text.split('The focused UI element is')[0]
 check('fullAX local destination/oneh1 '+label,'URL: tauri://localhost#'+slug in body and len(re.findall(r'^\s*\d+ heading .+, Value: 1$',body,re.M))==1 and 'heading '+label+', Value: 1' in body)
 check('fullAX named nav/skip/footer '+label, all('link '+n+', Value: tauri://localhost#' in body for n in nav) and 'link Skip to main content' in body and 'No application submission is available in this build.' in body)
 if label not in {'Home','Diagnostics'}:check('truthful business unavailable '+label,'not available in this build.' in body)
 for name in [img]:
  fmt="JPEG";size=jpeg_dimensions(B/name)
  images.append({'file':name,'format':fmt,'pixels':list(size),'sha256':sha(B/name),'viewed_by_reviewer':True})
  check('native JPEG format/dimensions '+name,fmt=='JPEG' and size==(2240,1520))
fmt='JPEG';size=jpeg_dimensions(B/'15-cmd-plus-content.jpg')
images.append({'file':'15-cmd-plus-content.jpg','format':fmt,'pixels':list(size),'sha256':sha(B/'15-cmd-plus-content.jpg'),'viewed_by_reviewer':True})
check('eighth JPEG probe format/dimensions',fmt=='JPEG' and size==(2240,1520))
def focused(name):return texts[name].split('The focused UI element is ')[-1].strip()
check('Tab observed Checkagain focus',focused('02-tab.ax.txt')=='41 button Check again')
check('Return observed localservice focus',focused('03-enter-refresh.ax.txt')=='29 heading Local service, Value: 2')
stamps=[]
for n in ('02-tab.ax.txt','03-enter-refresh.ax.txt'):
 stamps.append(datetime.datetime.fromisoformat(re.search(r'\b2026-10-29T[0-9:.]+Z',texts[n]).group(0).replace('Z','+00:00')))
check('actual CheckedAt advances on recordedReturn',stamps[1]>stamps[0] and 'Ready' in texts['03-enter-refresh.ax.txt'] and 'text 0.0.1' in texts['03-enter-refresh.ax.txt'] and 'text 1.0.0' in texts['03-enter-refresh.ax.txt'])
check('ShiftTab observedDiagnosticslink',focused('04-shift-tab.ax.txt')=='14 link Diagnostics, Value: tauri://localhost#diagnostics')
check('reverseTab observedskiplink',focused('16-keyboard-skip-focus.ax.txt')=='3 link Skip to main content, Value: tauri://localhost#desktop-main')
check('skipReturn observedmaincontainer',focused('17-keyboard-skip-applied.ax.txt')=='16 container')
check('View menu only ToggleFullScreen',all('Toggle Full Screen' in texts[n] and '0 View' in texts[n] for n in ('11-view-menu.ax.txt','12-menu-dismissed.ax.txt','13-cmd-plus.ax.txt')) and not any('Zoom' in texts[n] for n in ('11-view-menu.ax.txt','12-menu-dismissed.ax.txt','13-cmd-plus.ax.txt')))
check('content Cmdplus AX exactly unchanged',texts['15-cmd-plus-content.ax.txt']==texts['10-settings.ax.txt'])
check('nativeQuit is actualAXerror only',(B/'18-after-native-quit.error.txt').read_text().strip()=='Error: Computer Use server error -10005: App quit')
check('17 labelled events ordered',len(events)==17 and all(a['utc']<b['utc'] for a,b in zip(events,events[1:])))
for event in events:
 stem=event['capture'];filename=stem+'.txt' if stem.endswith('.error') else stem+'.ax.txt'
 check('labelled event has actualcapture '+stem,(B/filename).is_file())
check('menu12 has no invented eventtimestamp',not any(e['capture']=='12-menu-dismissed' for e in events))
after={p.relative_to(B).as_posix():row(p) for p in B.rglob('*') if p.is_file() and p.name!='SOURCE.json'};check('finite retained data endpoints unchanged',before==after)
report={'scope':'DIFFERENT_NATIVE_MAC_AX_RETAINED_DATA_REVIEW_ONLY','verdict':'CLEAR_AS_RECORDED_LIMITED_OBSERVATIONS' if all(c['pass'] for c in checks) else 'HOLD','checks':checks,'passed':sum(c['pass'] for c in checks),'total':len(checks),'SOURCE':row(B/'SOURCE.json'),'input_files':before,'images_actually_viewed':images,'keyboard_checked_at':[s.isoformat() for s in stamps],'surface_count':7,'app43_join':'declared historical post/prior snapshot rows equal, not independent historical live-byte remeasurement','frontend14_join':'actual retained copied source bytes/fullmodes equal historical build and post map; not current bd4 source read','reviewer_zoom_authorship':'Authored proposal. No independent verdict on its code; source references/test plan only','limits':['No separately retained initial getApp/Starting output','Diagnostic01 is diff; full Diagnostic02 used with earlier01JPEG; not same-instant pair','Menu12 AX has no explicit event timestamp; menu-open probes cannot establish shortcutdelivery','No fresh entry build/prelaunch/continuousprocess/lifecycle/orphancleanup','No actual native200percent or directzoompercentage; JPEGpixels are not pagezoom','No VoiceOver or actualscreenreader output','No currentcanonical/native actor or statepromotion']}
(O/'actual-data-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'verdict':report['verdict'],'passed':report['passed'],'total':len(checks),'failed':[c['name'] for c in checks if not c['pass']],'viewed_images':len(images)},indent=2));assert all(c['pass'] for c in checks)
