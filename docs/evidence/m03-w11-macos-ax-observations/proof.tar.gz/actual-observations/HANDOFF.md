# Native macOS shell accessibility observations

Outside-only M03-W11 preparation during the owner-authorized larger batch;
M03-W07 remains the sole formal IN_PROGRESS package. No new implementation,
baseline approval, VoiceOver narration, certification or complete accessibility
PASS is asserted. Root used only CUA against the exact owned development app.
No global app/browser/screen/credential inventory was requested.

The first getApp call launched in the background if needed and showed Starting;
that initial tool output is not separately retained as a raw file. Subsequent
actual AX strings/images are written in their CUA calls, with executed capture
helper and event labels. 01 is an AX diff, later captures explicitly request
full trees. Seven surfaces are individually captured and visually inspected:
Home, Jobs, Tracker, Documents/Resumes, Profile, Settings and Diagnostics. They
retain named navigation, one level-one destination heading, truthful unavailable
business states and the no-submission footer. Native version/service values are
observed, including Ready and actual CheckedAt advancement on keyboard Return.
Tab reaches Check again; Shift+Tab returns to Diagnostics. Eight reverse steps
from the Settings heading reach Skip to main content, and Return moves focus to
the main container. These are native AX/keyboard observations, not a claim that
a human screen-reader user or VoiceOver read every item.

Native View offers Toggle Full Screen only. An Escape and first Cmd+plus probe
leave that menu open; its observed Cancel secondary action closes it. A separate
content-active Cmd+plus probe shows no visible zoom change. No shortcut delivery
or percentage is attested and no 200-percent native PASS is inferred. Existing
controlled-browser 200-percent/reflow tests remain separate. These limitations
must be resolved or explicitly assessed in the final W11 accessibility review.

Native Cmd+Q is followed by actual CUA error App quit. This records window/app
closure, not a new process-tree/listener/orphan cleanup measurement. Original
scoped M03-W06 lifecycle evidence remains independently bound and separate.

The later post-UI identity observation finds all43 app files/full modes exactly
equal to the retained prior native GUI app. All14 shipping desktop/shared-UI
sources exactly equal the original app-build input snapshot. This is not a fresh
app build at current HEAD and supplies no current native-lib/Windows entry
validation. No immediate prelaunch/before-after source closure was collected for
this UI session. Original app build source map and previous app observation are
retained with their dates rather than relabeled as new endpoints. Screenshot
bodies are retained as returned JPEGs, with no format conversion or pixel edits.

Independent source/data/accessibility/visual review and any additional required
native/assistive technology checks remain pending. All canonical governance,
package/gate and baseline rows remain unchanged by this preparation.
