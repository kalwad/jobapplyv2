from pathlib import Path
import datetime
import hashlib
import json
import os
import stat
import subprocess

E = Path(__file__).parent
R = Path('/Users/tanishkalwad/jobapplyv2')
O = E / 'm03-w11-macos-accessibility/v1'
A = E / 'mac-package-refreshed/launch space 应用/Desktop App.app'

def row(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode)
    body = path.read_bytes()
    return {'bytes': len(body), 'mode': stat.S_IMODE(info.st_mode), 'sha256': hashlib.sha256(body).hexdigest()}

def dump(name, value):
    (O / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

old_start = E / 'mac-package-refreshed/fresh-native-gui-9872/start-observation.json'
old_build = E / 'mac-package-refreshed/app-build-before.json'
prior = json.loads(old_start.read_text())
app = {p.relative_to(A).as_posix(): row(p) for p in sorted(A.rglob('*')) if not p.is_dir()}
assert len(app) == 43 and app == prior['app_files']
build = json.loads(old_build.read_text())
source = {}
for prefix in ['apps/desktop/src', 'packages/ui/src']:
    for p in sorted((R / prefix).rglob('*')):
        if p.is_dir():
            continue
        name = p.relative_to(R).as_posix()
        source[name] = row(p)
        assert source[name] == build['source'][name]
        target = O / 'frontend-reference' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(p.read_bytes())
        os.chmod(target, source[name]['mode'])
assert len(source) == 14
(O / 'original-app-build-source.json').write_bytes(old_build.read_bytes())
(O / 'original-app-prior-observation.json').write_bytes(old_start.read_bytes())
dump('post-ui-identity.json', {
    'observed_utc': datetime.datetime.now(datetime.UTC).isoformat(),
    'boundary': 'Post-UI observation only; no immediate prelaunch or before/after source snapshot is claimed',
    'app_path': str(A), 'app_files': app,
    'post_app_equals_original_prior43_fullmodes': True,
    'frontend14_equal_original_app_build_source': source,
    'historical_app_build_commit': build['commit'],
    'historical_app_build_tree': build['tree'],
    'current_head': subprocess.check_output(['git','rev-parse','HEAD'], cwd=R, text=True).strip(),
    'current_tree': subprocess.check_output(['git','rev-parse','HEAD^{tree}'], cwd=R, text=True).strip(),
    'current_status': subprocess.check_output(['git','status','--porcelain'], cwd=R, text=True),
    'scope': 'Historical native app/current identical14 frontend sources; current native entry/library changes were not built into this app'
})
(O / 'observer-executed.py').write_bytes(Path(__file__).read_bytes())
(O / 'HANDOFF.md').write_text('''# Native macOS shell accessibility observations

Outside-only M03-W11 preparation during the owner-authorized larger batch;
M03-W07 remains the sole formal IN_PROGRESS package. No new implementation,
baseline approval, VoiceOver narration, certification or complete accessibility
PASS is asserted. Root used only CUA against the exact owned development app.
No global app/browser/screen/credential inventory was requested.

The first getApp call launched in the background if needed and showed Starting;
that initial tool output is not separately retained as a raw file. Subsequent
actual AX strings/images are written in their CUA calls, with executed capture
helper and event labels. 01 is an AX diff, later captures explicitly request
full trees. Seven surfaces are individually captured and visually inspected:
Home, Jobs, Tracker, Documents/Resumes, Profile, Settings and Diagnostics. They
retain named navigation, one level-one destination heading, truthful unavailable
business states and the no-submission footer. Native version/service values are
observed, including Ready and actual CheckedAt advancement on keyboard Return.
Tab reaches Check again; Shift+Tab returns to Diagnostics. Eight reverse steps
from the Settings heading reach Skip to main content, and Return moves focus to
the main container. These are native AX/keyboard observations, not a claim that
a human screen-reader user or VoiceOver read every item.

Native View offers Toggle Full Screen only. An Escape and first Cmd+plus probe
leave that menu open; its observed Cancel secondary action closes it. A separate
content-active Cmd+plus probe shows no visible zoom change. No shortcut delivery
or percentage is attested and no 200-percent native PASS is inferred. Existing
controlled-browser 200-percent/reflow tests remain separate. These limitations
must be resolved or explicitly assessed in the final W11 accessibility review.

Native Cmd+Q is followed by actual CUA error App quit. This records window/app
closure, not a new process-tree/listener/orphan cleanup measurement. Original
scoped M03-W06 lifecycle evidence remains independently bound and separate.

The later post-UI identity observation finds all43 app files/full modes exactly
equal to the retained prior native GUI app. All14 shipping desktop/shared-UI
sources exactly equal the original app-build input snapshot. This is not a fresh
app build at current HEAD and supplies no current native-lib/Windows entry
validation. No immediate prelaunch/before-after source closure was collected for
this UI session. Original app build source map and previous app observation are
retained with their dates rather than relabeled as new endpoints. Screenshot
bodies are retained as returned JPEGs, with no format conversion or pixel edits.

Independent source/data/accessibility/visual review and any additional required
native/assistive technology checks remain pending. All canonical governance,
package/gate and baseline rows remain unchanged by this preparation.
''')
files = {}
for p in sorted(O.rglob('*')):
    if p.is_dir():
        continue
    files[p.relative_to(O).as_posix()] = row(p)
dump('SOURCE.json', {'scope': 'NATIVE_AX_KEYBOARD_OBSERVATIONS_REQUIRE_INDEPENDENT_REVIEW_NOT_FINAL_W11', 'files': files})
print(json.dumps({'directory': str(O), 'source_sha256': hashlib.sha256((O/'SOURCE.json').read_bytes()).hexdigest(), 'files': len(files), 'app_files': len(app), 'unchanged_frontend_sources': len(source)}))
