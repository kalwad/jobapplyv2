from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/Users/tanishkalwad/jobapplyv2'); out=Path('/tmp/japp-w14-python-918dedb-20261016'); env=os.environ.copy(); env['PATH']='/opt/homebrew/opt/node@24/bin:'+env['PATH']
def git(*args): return subprocess.check_output(['git',*args],cwd=root).decode().strip()
def snap():
 files=[]
 for name in subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0'):
  if not name: continue
  b=(root/name).read_bytes(); files.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 return {'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain=v1'),'files':files,'inventory_digest':hashlib.sha256(json.dumps(files,separators=(',',':')).encode()).hexdigest(),'time':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
a=snap(); assert a['head']=='918dedb3fc379e1fc19cf6ef54bbefa1110b35d3' and not a['status']; (out/'before.json').write_text(json.dumps(a,indent=2)+'\n'); (out/'command.json').write_text(json.dumps({'argv':['pnpm','test:python'],'cwd':str(root),'node_path':'/opt/homebrew/opt/node@24/bin/node','started_at':a['time']},indent=2)+'\n')
with (out/'python.log').open('wb') as f: result=subprocess.run(['pnpm','test:python'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
b=snap(); (out/'after.json').write_text(json.dumps(b,indent=2)+'\n'); s={'exit_code':result.returncode,'head_unchanged':a['head']==b['head'],'status_before':a['status'],'status_after':b['status'],'tracked_inventory_unchanged':a['inventory_digest']==b['inventory_digest'],'ended_at':b['time']}; (out/'completion.json').write_text(json.dumps(s,indent=2)+'\n'); print(json.dumps(s),flush=True); raise SystemExit(result.returncode)
