# D CI retained-data review

**CLEAR_AS_RECORDED_FAILURE.** The retained terminal evidence for source `7f7902f7249b7e8c6e4075a9af34491318000484` is internally consistent. Main run `40974739781` failed on macOS `unit-ts`; Windows and Ubuntu each passed all20 active verification suites. Native packaging was skipped and there are **no curated package exports**.

The finite audit passed **17231 joins**, covering five attempt1 runs,13 jobs, five official artifact ZIPs, official log ZIPs,2383 immutable source entries, raw checkout observations, catalog projection, original API/collector custody and retained file hashes/full modes. The compact proof pins566 external original files (28,641,854bytes) without duplicating the originals.

| Actual host | Doctor | Active suites | Python | Fresh TypeScript unit groups | Browser groups | Native Rust sets |
|---|---|---|---|---|---|---|
| Windows2025 |28PASS|20PASS|2878PASS,877.60s|4006PASS|278+2+62+17PASS|3×316same case membership, plus1+10|
| macOS15 |28PASS|19PASS/1FAIL(`unit-ts`)|2880PASS,839.89s|3408PASS/1FAIL/597SKIP,4006planned|278+2+62+17PASS|3×342same case membership, plus1+10|
| Ubuntu24.04 |28PASS|20PASS|2880PASS,714.22s|4006PASS|278+2+62+17PASS|3×338same case membership, plus1+10|

The Mac task prints four failed suites and one failed infrastructure test, all with `ADAPTER_EXIT_NONZERO`. The exact five failures and all15 fresh unit summaries are retained in PLATFORMS.json. The historical child environment and child Rust stderr are not exposed. The separate Turbo/RUSTUP_HOME controlled reproduction and source review are pinned as supporting correction evidence; this review does not infer an exclusive historical cause from it. The later passing contract/Rust steps do not erase the earlier TypeScript task failure.

All actual Python collection node IDs equal the exact source catalog after one explicit GitHub masking projection. Each platform has12 authentication parameter IDs collapsed to the same `[***` suffix. Every other ID matches directly, including the unchanged oversized payload case with explicit `oversized-field` ID; the two POSIX-only IDs are absent on Windows and present on the other hosts. Individual masked identities cannot be recovered. The logs give complete collection and all-pass aggregate results, rather than separately printed per-case execution statuses. The reported TypeScript totals similarly do not claim every individual case identity.

The main jobs actually checked out merge `a82b28a464258bd36623cd4235fca194e141019b`, with parents base `4745149f4b5da7190b5b0c68753f8ec07bed572d` and sourceD. Both merge and source API trees equal `6a3ab8cf182e565b68737933ecc70d1099b8b656`; every blob OID, Git executable class and size matches the original immutable local source map. All four auxiliary authorizers directly checked out sourceD and published `SKIP_NO_ROOT_REQUEST`; downstream download/VM/source-check jobs were skipped. Those metadata successes are not platform or package validation.

The original owned local Git reader's framed SHA1/SHA256 body proof and map are reused. This review independently joins the2383 API/tree/map entries and retained ls-tree bytes, but does not reread the682,234,730-byte raw batch stream or download API blob bodies again. Git regular/executable classes are distinct from arbitrary target operating-system permissions. Retained artifact/log files are checked with their actual full modes.

There are131 retained GET owners:128 exited0 and three early metadata requests exited1 with explicit TLS handshake timeout and empty stdout. All131 were reaped with absent groups, no signals or stop reason; subsequent snapshots supply the complete terminal records. The original outer collector PID/PGID10986 exited0 after2546.522847s, was reaped with EOF/absent group/no signals. Collector exit0 attests retained collection completion, not main CI success. No HTTP-call cancellation/rerun/dispatch/download/install/VM/native or canonical write was performed by this review.

The five official artifact ZIPs contain four metadata-only request receipts and the Mac Playwright failure retention. The single unexpanded package job `123815737232` is skipped with no runner. There is no Windows portable or Ubuntu GNOME export to authorize from D.

All source acceptance is scoped to these historical bytes and observed build-host checks. This grants no packaged Windows11/default GNOME acceptance, GUI usability, service descendant custody, model qualification or milestone advance. Root's later canonical Turbo/document edits are outside this historical comparison. The reviewer authored the earlier immutable source reader/config reuse and some preexisting fixture IDs; the Turbo correction was authored and independently reviewed by other agents.

Own reader errors are retained in history: interrupted CPU-heavy exploratory regex, wrong catalog-key assumption, Rust summary token mistake, and the initial inherited all-GET-exit0 assertion. Only these readers were corrected; original subject/collector evidence was unchanged.
