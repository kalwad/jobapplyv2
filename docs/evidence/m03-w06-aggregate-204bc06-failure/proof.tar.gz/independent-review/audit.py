from pathlib import Path
import hashlib,json,re,stat
base=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');src=base/'full-204bc06';out=Path(__file__).parent
load=lambda n:json.loads((src/n).read_text())
before=load('before.json');after=load('after.json');context=load('context.json');closure=load('closure.json');results=load('results.json')
immutable=json.loads((base/'ci-204bc06/immutable-git-source-sha256.json').read_text())
macafter=json.loads((base/'mac-package-refreshed/app-build-after.json').read_text())
checks=[]
def check(name,value,detail=None):
 checks.append({'name':name,'pass':bool(value),'detail':detail});assert value,(name,detail)
check('Context exact204bc commit and tree',context['commit']==immutable['commit'] and context['tree']==immutable['tree'])
check('2070source endpoints exact',len(before['source'])==len(after['source'])==2070 and before['source']==after['source'])
check('40runtime fullmode endpoints exact',len(before['runtime'])==len(after['runtime'])==40 and before['runtime']==after['runtime'])
check('Both clean Gitstatus endpoints',before['git_status']==after['git_status']=='')
check('Source membership exact immutable Git',set(before['source'])==set(immutable['files']))
for path,item in before['source'].items():
 binding=immutable['files'][path]
 check('Immutable source body '+path,item['bytes']==binding['bytes'] and item['sha256']==binding['sha256'] and bool(item['mode']&0o111)==(binding['git_mode']=='100755'))
check('Runtime exact independently reviewed refreshed app-build baseline',before['runtime']==macafter['runtime'])
check('Closure accurately reports failure and unchanged endpoints',closure['source_count']==2070 and closure['runtime_count']==40 and closure['source_bytes_modes_unchanged'] and closure['runtime_bytes_modes_unchanged'] and not closure['all_commands_exit_zero'])
check('Exactly doctor and aggregate outer commands',[r['argv'] for r in results]==[['pnpm','run','doctor'],['pnpm','verify']])
check('Actual exit codes0/1',[r['exit_code'] for r in results]==[0,1])
for r in results:
 check('Natural closed group '+r['name'],not r['timeout'] and r['direct_child_reaped'] and r['observed_group']=='ABSENT' and r['outer_cleanup_signals']==[] and r['seconds']>0)
doctor=(src/'doctor.log').read_text();log=(src/'verify.log').read_text()
check('Doctor retained28PASSzero warning/failure','summary: 28 pass, 0 warning, 0 fail, 0 not-yet-applicable' in doctor)
section=log.split('== verification summary ==\n')[-1]
rows=re.findall(r'^(\S+)[ \t]+(ACTIVE)[ \t]+(PASS|FAIL)[ \t]*(.*)$',section,re.M)
check('Twenty unique active suite verdicts',len(rows)==20 and len({r[0] for r in rows})==20)
check('18PASS2FAIL solely Python/integrity',sum(r[2]=='PASS' for r in rows)==18 and [(r[0],r[2]) for r in rows if r[2]=='FAIL']==[('python','FAIL'),('integrity','FAIL')])
reason='dynamic pytest collection hook registration is forbidden in services/orchestrator/tests/test_runtime_metadata.py'
check('Both exact failure diagnostics',section.count('  - '+reason)==2)
check('Aggregate exit diagnostic failure','verification exit code: 1' in section)
commands=re.findall(r'^\$ (.*)$',log,re.M)
check('No Python collection or execution command in refused aggregate',not any('pytest' in c for c in commands))
unit=log.split('$ pnpm exec turbo run test --force --concurrency=2 -- --reporter=default\n')[1].split('$ pnpm generate:contracts --check')[0]
counts=re.findall(r'^(@japp/[^:]+):test:\s+Tests\s+(\d+) passed \(\d+\)',unit,re.M)
check('Fifteen unit package results sum4006',len(counts)==15 and len(dict(counts))==15 and sum(int(c) for _,c in counts)==4006)
check('Fifteen fresh Turbo test tasks','Tasks:    15 successful, 15 total' in unit and 'Cached:    0 cached, 15 total' in unit and 'cache hit' not in unit)
check('Actual browser278 terminal ordinary pass','  278 passed (9.0m)' in log)
check('Actual dedicated visual17 terminal ordinary pass','  17 passed (7.3s)' in log)
native_modes=[]
for suffix in ['', ' --all-features',' --features tauri/custom-protocol']:
 command='$ cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml'+suffix
 start=log.index(command+'\n');end=log.find('\n$ ',start+len(command));piece=log[start:end if end!=-1 else None]
 names=re.findall(r'^test (\S+) \.\.\. ok$',piece,re.M)
 check('Native342 unique actual cases '+(suffix or 'default'),len(names)==len(set(names))==342 and 'test result: ok. 342 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in piece)
 native_modes.append({'argv':command[2:].split(),'passed':342,'names':names,'names_sha256':hashlib.sha256(('\n'.join(sorted(names))+'\n').encode()).hexdigest()})
check('Native three feature-mode actual ID sets equal',len({r['names_sha256'] for r in native_modes})==1)
visual=json.loads((src/'retained-visual/retention.json').read_text());visualfiles=visual['files']
check('Retained visual paths regular and exact',all((p:=src/'retained-visual'/f['path']).is_file() and not p.is_symlink() and len(p.read_bytes())==f['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256'] for f in visualfiles))
check('Original metadata preimage matches reviewed fixture cause',before['source']['services/orchestrator/tests/test_runtime_metadata.py']['sha256']=='2c08041a85861075602f0c88eee789bc294a6d1b4ec42d1dc7ddeb9702cf9cb0')
report={'scope':'INDEPENDENT_RETAINED_FAILED_LOCAL_AGGREGATE_DATA_REVIEW_NO_RETROACTIVE_PYTHON_OR_FULL_PASS','verdict':'CLEAR_AS_ACCURATELY_RECORDED_FAILURE','passed_checks':len(checks),'checks':checks,'commit':context['commit'],'tree':context['tree'],'start_utc':context['start_utc'],'end_utc':closure['end_utc'],'actual_results':results,'aggregate_suites':[{'suite':r[0],'state':r[1],'result':r[2]} for r in rows],'unit_package_counts':{k:int(v) for k,v in counts},'ordinary_unit_passed':4006,'browser_passed':278,'dedicated_visual_passed':17,'native_modes':native_modes,'python_execution':'NOT_RUN_PREFLIGHT_REFUSED_BEFORE_COLLECTION','source_files':2070,'runtime_files':40,'retained_visual_files':len(visualfiles),'limits':['No complete Vitest per-case ID channel','Source-neutrality endpoints do not prove every intermediate state','Rust test PASS is not packaged GUI or desktop-native foreign-OS acceptance','Separate focused fixture correction is later evidence; original aggregate remains failed']}
(out/'actual-data-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in {'checks','native_modes','aggregate_suites','unit_package_counts'}},indent=2))
