# W14 text/date focus-value correction proposal

This is an unapplied two-file source proposal outside the active checkout. Root remains the sole writer. The author has run no tests, build, or browser; independent peer review and actual GREEN are still required.

The independent actual MV3 probe at `/tmp/japp-w14-value-focus-red8-20261016` has four unchanged controls passing and four focus safety negatives failing in 13.9 seconds: text/date, execute/undo each loses the newer page-world focus edit and reports `VERIFIED` / `ACCEPTED`. All thirteen recorded source/runtime/build/tool bindings match before and after, with the 355-file runtime digest `sha256:c3757409d0e43b12e517eae863e4985d8a509273dd45b86f59a5bfb8478cc89c`. Each page edit has zero MutationObserver records, followed by one extension native setter. Exact raw proof hashes are in the source manifest.

The shared `writeText` synchronous mutation callback snapshots live `host.value` immediately before `host.focus()`. After page focus handlers return, a changed native value throws `NativeValueChangedDuringFocusError` before the extension's sole native setter. The existing post-focus target identity, visibility and enabled checks remain intact. The same callback covers native text and date execute and undo, with no new await.

Execute previously marked the attempt before entering driver code to ensure mandatory recovery after a possible partial mutation. The engine now recognizes only this typed pre-write value refusal from the exact built-in text/date driver objects. For that precise no-extension-value-write condition it clears `actionPerformed`, so the existing catch skips automatic restoration, skips retained undo, and returns `undoAvailable: false`. The result remains the existing honest action failure with unknown acceptance. Every generic error, structural focus refusal, and possible partial mutation retains the existing recovery and undo behavior unchanged. The explicit driver-object reference check prevents a different or injected driver from suppressing recovery by merely throwing the exported marker.

Undo needs no recovery exemption: its existing callback error path already refuses verification without performing automatic restoration; its record was consumed before attempting restoration. No new undo authority is granted by the value refusal.

No schema, protocol, reason code, ordinary precondition field, driver inventory, fixture, test, or public gate state changes. The former asynchronous engine witness draft remains unexecuted historical material and is excluded. Second-descriptor-await instrumentation timeouts provide no product RED for that separate hypothesis.

The former one-file focus patch is preserved byte-for-byte under `/tmp/japp-w14-undo-focus-fix-proposal`; source review showed it did not safely handle execute's automatic recovery, so it must not be integrated alone. This replacement adds only the trusted typed refusal and narrow recovery exemption.

Review files:

- `focus-value-fix.patch`: exact two-file proposal.
- `preimages/`: exact original source bytes from clean base `918dedb3fc379e1fc19cf6ef54bbefa1110b35d3`.
- `proposed/`: complete proposed source bytes.
- `source-manifest.json`: file hashes, patch hash, immutable RED bindings and execution status.

Patch SHA: `sha256:3adbcf83e27327c1fe2293cc197c80ce22286cca50a1c7c665a1e1b1f6950177`.

Required independent GREEN: rerun the exact eight-case probe unchanged; the four unchanged controls must still verify, and all four focus interventions must preserve the newer value with zero extension native setter and zero extension input/change events during the refused operation. Execute focus refusal must expose no undo authority. Generic/partial-mutation recovery must remain covered by existing relevant regression checks. A passing focused probe alone would not establish full-suite or Gate A approval.
