# W14 text/date focus native-value guard proposal

This is a one-file source-only proposal outside the active checkout. It has not been applied, tested, built, or run in a browser by this author. Root remains the sole writer.

The independent actual MV3 probe, as relayed by root, confirmed that a synchronous focus handler can change a text or date native value without a MutationObserver record. The original driver then overwrote that newer value and reported undo `VERIFIED`. The unchanged text/date controls passed. The second-descriptor-await probes timed out because their semanticDigest instrumentation was memoized; they establish no product RED.

The proposed shared `writeText` callback records the live native `host.value` immediately before `host.focus()`. After synchronous page focus handlers return, the existing post-focus identity, visibility and enabled refusal check also requires that value to remain equal. The guard runs immediately before the native setter with no await. A mismatch throws the existing callback error path before the setter, preserving the page's newer value and preventing a falsely verified restoration. This shared function covers text and native date execute and undo. No public API, engine behavior, schema, reason code, or test is changed.

The earlier engine-level asynchronous witness draft at `/tmp/japp-w14-undo-value-fix-proposal` is preserved as unexecuted historical material. It is excluded from this patch and should not be integrated based on this focus RED. Any asynchronous race remains a separate unproven source concern.

Files:

- `preimage.ts`: exact original production source bytes.
- `proposed/apps/extension/src/drivers/text-like-drivers.ts`: complete proposed source.
- `undo-focus-fix.patch`: reviewable patch.
- `source-manifest.json`: exact hashes, scope and execution state.

Base commit: `918dedb3fc379e1fc19cf6ef54bbefa1110b35d3`.
Preimage SHA: `sha256:d39682b692f372d91279a130b73b614afdde6bb1ef0da62f06fb6a7e63e5c316`.
Proposed source SHA: `sha256:72a7ccf5be79f473ec451981f85f96fb48d67c9c83278e8a4feee0cc5712a517`.
Patch SHA: `sha256:28b6b7bb2035b59afe0acc8501bf91d6f1144be871cee2ba41ddc50e534b3478`.

The next necessary evidence is the independent reproducer's actual focus RED/GREEN using the same successful baseline and focus intervention. No GREEN result is claimed here.
