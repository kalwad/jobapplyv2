"""Read-only terminal oldCI joins; no artifact/subject execution or imports."""
from pathlib import Path,PurePosixPath
import hashlib,json,re,stat,zipfile
B=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/ci-07eb77b');O=Path(__file__).parent;checks=[]
load=lambda n:json.loads((B/n).read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
def check(n,v):checks.append({'name':n,'pass':bool(v)})
run=load('terminal-run.json');jobs=load('terminal-jobs.json')['jobs'];closure=load('collector-closure.json');immutable=load('immutable-git-source-sha256.json');bindings=load('checkout-source-bindings.json');logs=load('log-members.json');merge='1a0e7819a597f43d0c2c3a602c237c87fefc7d21';head='07eb77bd4dde2cd41e867cc7512bae28f1a721b8';tree='eadbd0d66cacc8561c4a3925b8aed907f5f7f8fd'
check('fixed attempt1 TERMINAL FAILURE',run['id']==40803470877 and run['head_sha']==head and run['run_attempt']==1 and run['status']=='completed'and run['conclusion']=='failure')
check('three canonical failures and one package skip',len(jobs)==4 and all(j['status']=='completed'for j in jobs)and sum(j['conclusion']=='failure'for j in jobs)==3 and sum(j['conclusion']=='skipped'for j in jobs)==1)
pin=bindings[merge];check('actual merge exact2182tree and head parent',pin['same_tree_as_run_head']and pin['tree']==tree==immutable['tree']and pin['blob_count']==2182==immutable['blob_count']and head in pin['parents']and immutable['commit']==head)
api={r['path']:r for r in load('head-tree.json')['tree']if r['type']=='blob'};check('immutable Git OID mode size API join',set(api)==set(immutable['files'])and all(api[p]['sha']==r['git_blob']and api[p]['mode']==r['git_mode']and api[p]['size']==r['bytes']for p,r in immutable['files'].items()))
results=[]
for job in jobs:
 if job['conclusion']=='skipped':check('package job actually skipped','native development package'in job['name']);continue
 identity=job['id'];raw=(B/f'closed-jobs/{identity}.log').read_bytes();plain='\n'.join(re.sub(r'^\d{4}-\d\d-\d\dT[^ ]+ ','',x)for x in raw.decode().splitlines());plain=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',plain)
 checkout=re.search(r'log -1 --format=%H\n[^\n]*?\b([0-9a-f]{40})\s*\n',plain);check('actual checkout '+str(identity),checkout is not None and checkout.group(1)==merge)
 check('complete official job log equality '+str(identity),any(r['bytes']==len(raw)and r['sha256']==sha(raw)and r['path'].endswith(job['name']+'.txt')for r in logs))
 section=plain.split('== verification summary ==\n')[-1];rows=re.findall(r'^(\S+)[ \t]+ACTIVE[ \t]+(PASS|FAIL)',section,re.M);failures={'python','portability'}|({'e2e-browser'}if'macos'in job['name']else set())
 check('exact actual suite failures '+str(identity),len(rows)==len({r[0]for r in rows})==20 and {r[0]for r in rows if r[1]=='FAIL'}==failures)
 python_pass=2138 if'windows'in job['name']else 2140;py=re.search(r'^=+ 1 failed, '+str(python_pass)+r' passed in ([\d.]+)s[^\n]*=+$',plain,re.M)
 check('actual Python counts and same exact oracle '+str(identity),py is not None and'FAILED scripts/tests/test_portability.py::test_real_repository_passes_the_policy'in plain)
 fragment="FAIL: PORT-SRC-001 [scripts/native_package_ci.py]: hard-coded POSIX system path '/bin' in runtime literal '/bin/Hostx64/x64/dumpbin.exe'"
 check('same exact portability construction failure '+str(identity),fragment in plain)
 unit=plain.split('$ pnpm exec turbo run test --force --concurrency=2 -- --reporter=default\n')[1].split('$ pnpm generate:contracts --check')[0];totals=re.findall(r'^(?:@japp/[^:]+:test:)?[ \t]+Tests[ \t]+(\d+) passed \(\d+\)',unit,re.M)
 check('actual4006TS15fresh '+str(identity),len(totals)==15 and sum(map(int,totals))==4006 and'Cached:    0 cached, 15 total'in unit)
 native=316 if'windows'in job['name']else 342 if'macos'in job['name']else 338;check('native three modes PASS '+str(identity),len(re.findall(r'^test result: ok\. '+str(native)+r' passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;',plain,re.M))==3)
 if'macos'in job['name']:
  browser=plain.split('$ pnpm exec playwright test\n')[1].split('\n$ ')[0]
  check('Mac actual277browserPASS1FAIL',re.search(r'^  1 failed$',browser,re.M)is not None and'  277 passed (16.3m)'in browser)
  check('exact Mac persistence rollback failure',all(x in browser for x in ['extension-drivers.spec.ts:616:1','Expected: "FAILED"','Received: "VERIFIED"','expect(rollback.result.outcome).toBe("FAILED")','extension-drivers.spec.ts:653:35']))
 else:check('actual browser278PASS '+str(identity),re.search(r'^  278 passed \(',plain,re.M)is not None)
 results.append({'id':identity,'name':job['name'],'passed_suites':20-len(failures),'failed_suites':sorted(failures),'python_passed':python_pass,'python_failed':1,'python_seconds':float(py.group(1))if py else None,'unit_ts':4006,'native_each_three_modes':native,'raw_log_bytes':len(raw),'raw_log_sha256':sha(raw)})
artifacts=json.loads(sorted((B/'artifact-lists').glob('*.json'))[-1].read_bytes())['artifacts'];records=[]
for artifact in artifacts:
 identity=artifact['id'];p=B/f'artifacts/{identity}.zip';members=load(f'artifacts/{identity}-members.json');digest=sha(p.read_bytes())
 check('exact artifact API digest '+str(identity),artifact['size_in_bytes']==p.stat().st_size and artifact['digest']=='sha256:'+digest and not artifact['expired'])
 with zipfile.ZipFile(p)as archive:
  regular={r.filename.replace('\\','/'):r for r in archive.infolist()if not r.is_dir()};check('all safe unique artifact paths '+str(identity),len(regular)==len(members)and set(regular)=={r['path']for r in members}and all(not PurePosixPath(n).is_absolute()and'..'not in PurePosixPath(n).parts and stat.S_IFMT(r.external_attr>>16)in(0,stat.S_IFREG)for n,r in regular.items()))
  for row in members:
   retained=B/f'artifacts/{identity}-contents'/row['path'];body=retained.read_bytes();check('retained artifact '+str(identity)+'/'+row['path'],retained.is_file()and not retained.is_symlink()and len(body)==row['bytes']and sha(body)==row['sha256'])
 records.append({'id':identity,'name':artifact['name'],'bytes':p.stat().st_size,'sha256':digest,'safe_regular_members':len(members)})
check('all four artifacts and three jobs retained',len(records)==4 and set(closure['downloaded_artifacts'])=={r['id']for r in records}and len(closure['downloaded_jobs'])==3 and closure['run_status']=='completed'and closure['run_conclusion']=='failure'and closure['no_subject_execution']and closure['canonical_writes']==0)
mac_members=load('artifacts/12868823468-members.json')
check('Mac artifact only later visuals, browser failure attachments absent',len(mac_members)==66 and all(r['path'].startswith('visual/')for r in mac_members)and not any('trace.zip'in r['path']or'error-context'in r['path']or'test-failed'in r['path']for r in mac_members))
report={'scope':'INDEPENDENT_FIXED07EB_TERMINAL_CI_FAILURE_DATA_REVIEW','verdict':'CLEAR_AS_RECORDED_MAC17_3_UBUNTU_WINDOWS18_2_PACKAGES_SKIPPED','checks':checks,'passed_checks':sum(c['pass']for c in checks),'total_checks':len(checks),'run':run['id'],'run_url':run['html_url'],'head':head,'tree':tree,'actual_merge':merge,'source_files':2182,'jobs':results,'artifacts':records,'native_packages':'SKIPPED','limits':['Macbrowser failure expectedFAILED/actualVERIFIED is separate from SDK path policy refusal and uncorrected by one-line path change','Windows loader diagnostic artifact is not native-package acceptance','Local full80e68 PASS and later fixed CI remain separate evidence','No downloaded subject execution, nativeGUI/foreign desktop/milestone/release credit']}
(O/'actual-data-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'passed':report['passed_checks'],'total':len(checks),'failures':[c['name']for c in checks if not c['pass']],'jobs':results,'artifacts':records},indent=2));assert all(c['pass']for c in checks)
