# Fixed Turbo log retention source review

One narrow P2 reporting finding: initialize task rows as UNOBSERVED/PENDING, then mark ABSENT only after explicit missing-directory/log observation. Currently a present oversized, nonregular, unreadable or permission-refused log leaves its row ABSENT in the correctly INCOMPLETE partial manifest. The strict global failure is preserved; this is a false row-level absence claim, not a false overallPASS. The author and root received the minimal correction direction.

Other13 bounded source/hash checks pass. The delta adds only three functions and one call to the previously cleared2f228 diagnostic; exact removal restores the entire prior source. Fifteen literal paths match selected current package metadata. Reads preserve raw bytes with1MiB+1 detection,8MiB total, existing directory/file reparse refusal and Windows read-sharing constraints. New output is strict/fresh, refusal keeps a failed prefix, declared versions are separate from actual tool evidence, and no workflow/helper/command/timeout change is included.

Six mocked file-fixture source cases remain UNEXECUTED. No PowerShell, test, native/compiler, subject import, cache/image scan, root write or actual Windows validation occurred. Typecheck cause remains UNOBSERVED; logs may support later diagnosis, not fabricate it.
