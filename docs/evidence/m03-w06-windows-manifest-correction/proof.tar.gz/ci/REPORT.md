# Immutable c4f hosted CI evidence

Run 39201246849 attempt 1: **FAILURE**. Actual source c4f7d9ca6df70f3d7f8a8f8d10806453e69687e6, content tree b7b7bbcf7d508309bd6c3e511bb924a0ad2338d3;1924 blobs,21 selected source blobs and all370 Git tree objects authenticated.

- macos-15: job 117894478795 success; aggregate 20/20 ACTIVE PASS, exit 0; Python {'passed': 1689} (661.73s); native mode passed-case counts [183, 183, 183].
- windows-2025: job 117894478955 failure; aggregate 18/20 ACTIVE PASS, exit 1; Python {'passed': 1687} (1024.69s); native mode passed-case counts [None, None, None].
- ubuntu-24.04: job 117894478959 success; aggregate 20/20 ACTIVE PASS, exit 0; Python {'passed': 1689} (604.18s); native mode passed-case counts [182, 182, 182].

Windows failed two canonical suites: typecheck child exit1 with no exact compiler diagnostic retained, and desktop bin-test linking exit101 with CVTRES CVT1100 duplicate MANIFEST type/name1/language0x0409 plus LINK LNK1123. The retained link command includes resource.lib and the added /MANIFEST:EMBED and /MANIFESTINPUT arguments. No successful Windows native test run, later feature modes or final build is claimed. This differs from the historical entrypoint failure; its deeper PE/import/export cause remains unproved.

Windows step26 also failed: Get-Item received a joined string of three git.exe paths. The actual diagnostic artifact is DIAGNOSTIC_INCOMPLETE, source:null, images:[] and tools:[]; no PE or loader witness was produced. The separately named Playwright failure artifact contains ten visual PNGs; all browser batches passed. The tracked-clean workflow step28 passed on macOS/Ubuntu and was SKIPPED on Windows after failure.

All3 TypeScript unit blocks passed4006; defaultbrowser262, controlledinspection2, controlledcontact62 and visual3 passed on eachhost. Contract-only745 passed on eachhost. Native case-name sets match across all three completed modes per POSIX host; macOS has183 and Ubuntu182, with one explicit macOS-only observed case recorded in the supplemental JSON. Windows native counts are null because default compilation failed before a successful case-summary; null is not a passing zero catalog.

Default native128 observations contain exactly one zero-settle sample each: macOS2813.963542ms, Windows1458.312200ms and Ubuntu1441.200449ms. These are not target20 threshold results. Development200 stdout aggregate p95 values (1675.252875/1002.460300/925.119444ms, respectively) have separate75ms-settle/20ms-rerender scope. Raw per-case replay files are not present in this official log/artifact packet and are not reconstructed.

The full machine derivation retains exact per-suite/browser/native-command summaries and raw line references, checkout commits/tree joins, doctor results, final build and actual workflow step24–29 outcomes. Explicit child exits are distinguished from completion inferred through the stop-on-nonzero verifier. Visible masked Python ID multisets are compared without reconstructing hidden identity.

Only actually listed exact-run failure artifacts are captured; missing/expired output is not reconstructed. This is hosted CI on its advertised runners. It does not certify Windows11 or Ubuntu desktop/GUI/install behavior, explain the original failed PE/import/export cause, prove skipped diagnostic scripts, transfer a later local full result, or establish milestone/gate approval. CI timing is its own default observation, not a20-sample target campaign.

All raw/API/source/log bytes are retained with exhaustive safe-member hashes. The current canonical root was neither read nor mutated for this evidence. Earlier CI failures remain historical, without silent rebinding.
