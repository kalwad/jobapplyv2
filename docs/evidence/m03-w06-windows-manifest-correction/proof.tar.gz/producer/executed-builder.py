from pathlib import Path
import argparse,hashlib,json,stat,tarfile,gzip,io
ap=argparse.ArgumentParser();ap.add_argument('--log-source',required=True);ap.add_argument('--log-review',required=True);ap.add_argument('--ps-sha256',required=True);args=ap.parse_args()
B=Path('/private/tmp/japp-m03-w06-windows-correction-retained-v2-20261019');B.mkdir(mode=0o700)
roots={'ci':Path('/private/tmp/japp-m03-w06-hosted-ci-c4f7d9c-20261019-retained'),'core-source':Path('/private/tmp/japp-m03-w06-windows-manifest-correction-source-20261019'),'core-review':Path('/private/tmp/japp-m03-w06-windows-manifest-correction-independent-review-20261019'),'log-source':Path(args.log_source),'log-review':Path(args.log_review),'log-v2-source':Path('/private/tmp/japp-m03-w06-typecheck-log-retention-source-v2-20261019'),'log-v2-review':Path('/private/tmp/japp-m03-w06-typecheck-log-retention-independent-review-v2-20261019'),'local-rust':Path('/private/tmp/japp-m03-w06-windows-manifest-local-rust-20261019')}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(n,v):
 with (B/n).open('x') as f:f.write(json.dumps(v,indent=2,sort_keys=True)+'\n')
assert (roots['ci']/'proof.tar.gz').stat().st_size==7320211
assert sha((roots['ci']/'proof.tar.gz').read_bytes())=='1022a4e4fd04cbfc419d724750fad4a603438a01d2133b4587bb4a137178d41a'
assert (roots['log-review']/'REVIEW.md').is_file()
assert sha((roots['log-source']/'proposal/scripts/windows-native-loader-diagnostics.ps1').read_bytes())==args.ps_sha256
records={};payload={}
for label,root in roots.items():
 assert root.is_dir() and not root.is_symlink()
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink()
  if p.is_dir():continue
  st=p.lstat();assert stat.S_ISREG(st.st_mode) and st.st_size<20*1024*1024
  raw=p.read_bytes();assert len(raw)==st.st_size
  name=label+'/'+p.relative_to(root).as_posix();payload[name]=(raw,stat.S_IMODE(st.st_mode));records[name]={'bytes':len(raw),'sha256':sha(raw),'mode':stat.S_IMODE(st.st_mode)}
producer=Path(__file__).read_bytes();payload['producer/executed-builder.py']=(producer,0o644);records['producer/executed-builder.py']={'bytes':len(producer),'sha256':sha(producer),'mode':0o644}
assert sum(v['bytes'] for v in records.values())<32*1024*1024
with (B/'proof.tar.gz').open('xb') as stream:
 with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT) as tf:
   for name,(raw,mode) in sorted(payload.items()):
    ti=tarfile.TarInfo(name);ti.size=len(raw);ti.mode=mode;ti.mtime=0;tf.addfile(ti,io.BytesIO(raw))
seen={}
with tarfile.open(B/'proof.tar.gz','r:gz') as tf:
 for member in tf:
  assert member.isreg() and not member.name.startswith('/') and '..' not in Path(member.name).parts and member.name not in seen
  raw=tf.extractfile(member).read();seen[member.name]={'bytes':len(raw),'sha256':sha(raw),'mode':member.mode}
assert seen==records
write('retention-manifest.json',{'schema_version':1,'files':records,'member_count':len(records),'payload_bytes':sum(v['bytes'] for v in records.values()),'all_regular_safe_unique_hash_readback_equal':True})
result=json.loads((roots['local-rust']/'rust-result.json').read_text());assert result['exit_code']==0
summary={'work_package':'M03-W06','state':'IN_PROGRESS','verified_packages':38,'total_packages':300,'base_head':'5b6def96f4b38ecbfd9c9add1cb22db7d0fe15e7','evaluated_ci':{'run_id':39201246849,'attempt':1,'head':'c4f7d9ca6df70f3d7f8a8f8d10806453e69687e6','tree':'b7b7bbcf7d508309bd6c3e511bb924a0ad2338d3','verdict':'FAILURE','macos':'20/20PASS','ubuntu':'20/20PASS','windows':'18/20PASS;typecheckFAILcauseUNOBSERVED;RustduplicateRT_MANIFESTlinkFAIL','windows_diagnostics':'FAILURE joinedGitpaths;noPEimages','original_ci_archive_sha256':'1022a4e4fd04cbfc419d724750fad4a603438a01d2133b4587bb4a137178d41a'},'source_correction':{'build_rs_sha256':'48b13d593001ac39af9393160910d2675be869a6d28ec219b84b7a16c21a123c','ps1_sha256':args.ps_sha256,'scope':'MSVConly once-owned manifest;firstApplicationpath;bounded existing fixed Turbo tasklogs;unchanged workflow/failurepolicy/resources/XML'},'local_component':{'command':['pnpm','verify','--suite','rust'],'command_exit':0,'seconds':result['elapsed_seconds'],'native_cases_each_of_three_modes':232,'registry_commands':15,'source1956_runtime40_unchanged':True,'owned_group_gone_reaped_no_cleanup_signals':True,'observer_wrapper_exit':1,'observer_error':'stale expected6 footer vs actual1;originalpreserved;derivedreconciliation;no test rerun'},'remaining':'freshclean doctor/all20,current Windows CI and actualPS,GUI/LaunchServices/nativepackagevalidation;oldentrypointcauseunproved;noM03/gate/releaseacceptance'}
write('summary.json',summary)
archive=(B/'proof.tar.gz').read_bytes();write('artifact.json',{'path':'proof.tar.gz','bytes':len(archive),'sha256':sha(archive),'retention_manifest_sha256':sha((B/'retention-manifest.json').read_bytes()),'scope':'Exact immutable priorCI failure plus reviewed source correction and actuallocalRust commandPASS/observerfooterFAIL;noWindows/full20 acceptance'})
readme=['# Windows manifest correction checkpoint','The prior c4f hosted run remains FAILURE: macOS and Ubuntu pass20/20; Windows passes18/20, fails typecheck without a captured compiler diagnostic, and fails linking with duplicate RT_MANIFEST/CVT1100/LNK1123. Its diagnostic fails on joined Git executable paths before any PE inspection. Original CI archive bytes remain unchanged under ci/.','The correction disables only Tauri\'s default MSVC manifest so the existing linker-owned Common Controls6 manifest is emitted once. Icon/version resources, command policy and non-MSVC defaults remain. The existing failure-only PowerShell script binds the first Application image and retains only15 fixed typecheck log paths within1MiB/log and8MiBtotal bounds. It reruns no task and changes no workflow or failure policy. Sparse source reviews and original findings are retained. PowerShell fixture cases remain unexecuted.','Actual macOS pnpm verify --suite rust exits0: all15 commands,232 tests in each3 modes, root1956/runtime40 unchanged, owned group gone/reaped without cleanup signals. The observer wrapper exits1 because a copied footer still expected six commands; exactly one was planned/executed. Original wrapper/raw/closure remain; separate derived reconciliation reports that bookkeeping error without a rerun.','W06 remains IN_PROGRESS,38/300 VERIFIED. Fresh clean full validation, native Windows and actualPS, GUI/LaunchServices/package certification and original entrypoint-cause investigation remain pending. No original failed result is relabeled and no milestone/gate/release acceptance follows.','The finite archive retains raw officialCI/API/artifact/source bindings, source proposals/reviews and local component receipts. Physical native/tool/runtime/cache images are omitted. Every outer member is a unique safe regular file with exact byte/hash readback.']
(B/'README.md').write_text('\n\n'.join(readme)+'\n')
print(json.dumps({'output':str(B),'archive_bytes':len(archive),'archive_sha256':sha(archive),'members':len(records)}))
