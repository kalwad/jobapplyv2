# Typecheck log partial-row correction

CLEAR for TYPECHECK-RETENTION-ROW-001:10/10 bounded source checks, no material finding. Each selected row now begins PENDING; only explicit missing-directory or missing-log branches assign ABSENT. Present/refused/uninspected rows therefore remain PENDING in the existing strict INCOMPLETE failed prefix.

Reversing exactly these three statements restores the reviewedv2 PS bytes. Fixed15 paths,1MiB/8MiB caps, raw reads, reparse/share/fresh-output guards, source/command/deadline/inspection scope and core2f228 preimage are unchanged. Every prior counterproof source line remains; four additions assert PENDING for oversized/nonregular/total-bound refusal. Originalv2 finding and proposal stay immutable.

All six fixtures remain UNEXECUTED. No PowerShell, subject import, test, compiler, native actor, cache/image or canonical action occurred. No actual retained task log, typecheck diagnosis, Windows manifest/runtime result or acceptance is inferred.
