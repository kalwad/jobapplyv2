# Windows source correction — not executed

The closed run 39201246849 failed Windows default bin-test linking with CVT1100 duplicate MANIFEST name 1 / language 0x0409 and LNK1123. Its command contains Tauri resource.lib and the added general /MANIFEST:EMBED plus /MANIFESTINPUT. This is the observed cause of that link failure; it is not a newly observed entrypoint failure. Windows typecheck also exited 1, but its complete log supplies no TS error or task footer. Its cause remains unobserved. The original Windows 18/20 verdict and all raw evidence remain unchanged.

## Narrow afterimages

`build.rs` computes the existing Windows+MSVC predicate once. Only there it selects tauri-build2.7.3's documented `WindowsAttributes::new_without_app_manifest()`. Tauri still generates icon/version resources, the command-policy AppManifest remains intact, and the existing linker arguments embed the unchanged CommonControls6 XML for final executables, including the lib test harness. Non-MSVC targets retain Tauri defaults and receive no new linker arguments. No Cargo dependency/lock, runtime, service, production test body, workflow, command, timeout, matrix or acceptance policy changes.

Pinned Tauri source shows the default WindowsAttributes owns a manifest; `new_without_app_manifest` sets only that field to None relative to its normal defaults. Tauri passes it into tauri-winres only when Some; tauri-winres emits RT_MANIFEST only when a manifest is present. The pinned embed-resource compile path sends resource.lib to bin targets when the package has src/main.rs. This explains both the duplicate bin-test resource and why simply deleting the added linker manifest would fail to cover the lib unit-test harness. The correction chooses one manifest producer for MSVC instead of dropping CommonControls6.

`scripts/windows-native-loader-diagnostics.ps1` selects the first ApplicationInfo in PowerShell command resolution order, validates its absolute path and regular-file binding, then passes exactly that string into the existing pre/post-bound command invoker. It never joins candidate paths. Existing diagnostic budgets, strict errors, static-only PE inspection and failure-only approved artifact path are unchanged.

## Counterexamples and later validation

`counterproofs/application-resolution.tests.ps1` extracts the actual resolver function through PowerShell AST and mocks discovery/binding. Five cases cover the observed three-candidate Git result, one valid candidate, no candidate, relative candidate, and a rejected binding. These source tests are UNEXECUTED. Exact later argv: `pwsh -NoLogo -NoProfile -NonInteractive -File <counterproof-path> -Subject <proposed-diagnostic-path>` on native Windows. No tool/image is launched by the mocked tests.

Actual Windows canonical Cargo default/allfeatures/dependency-only tests plus the final build remain required to establish emitted manifest/link/runtime outcomes. They have not run against this proposal. The existing original XML is unchanged; no synthetic static test is presented as an actual PE manifest witness. No GUI/package certification credit follows from this source correction.

A separate additive proposal will retain existing fixed-name Turbo typecheck logs into the same approved failure artifact. No typecheck code fix or rerun is part of this packet.

## Primary references

- Microsoft /MANIFEST (embedded RT_MANIFEST and executable resource ID 1): https://learn.microsoft.com/en-us/cpp/build/reference/manifest-create-side-by-side-assembly-manifest?view=msvc-170
- Microsoft /MANIFESTINPUT (merge supplied input into embedded manifest): https://learn.microsoft.com/en-us/cpp/build/reference/manifestinput-specify-manifest-input?view=msvc-170
- Cargo build script link-argument scope: https://doc.rust-lang.org/cargo/reference/build-scripts.html
- Pinned local tauri-build2.7.3 / tauri-winres0.3.6 / embed-resource3.0.12 excerpts and whole-file bindings are retained under primary-source/.

No subject import, test, compiler, PowerShell, native process, CI operation or canonical write occurred during source preparation.
