# SOURCE-ONLY counterexamples. Run later in native PowerShell, no image execution.
param([Parameter(Mandatory = $true)][string] $Subject)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$tokens = $null
$errors = $null
$ast = [Management.Automation.Language.Parser]::ParseFile($Subject, [ref]$tokens, [ref]$errors)
if ($errors.Count -ne 0) { throw 'Subject PowerShell parse failed' }
$definitions = @($ast.FindAll({ param($node)
    $node -is [Management.Automation.Language.FunctionDefinitionAst] -and
    $node.Name -eq 'Resolve-ApplicationPath'
}, $false))
if ($definitions.Count -ne 1) { throw 'Expected the actual single resolver definition' }
. ([scriptblock]::Create($definitions[0].Extent.Text))
$script:candidates = @()
$script:bound = @()
$script:refuseBinding = $false
function Get-Command([string] $Name, [string] $CommandType, [string] $ErrorAction) {
    if ($Name -ne 'git' -or $CommandType -ne 'Application' -or $ErrorAction -ne 'Stop') {
        throw 'Resolver widened command discovery'
    }
    $script:candidates
}
function File-Binding([string] $Path) {
    $script:bound += $Path
    if ($script:refuseBinding) { throw 'Synthetic reparse/nonregular refusal' }
    [pscustomobject]@{ path = $Path; sha256 = ('a' * 64); bytes = 1 }
}
function Assert-Equal([object] $Actual, [object] $Expected) {
    if ($Actual -cne $Expected) { throw "Expected <$Expected>, observed <$Actual>" }
}
function Assert-Refused([scriptblock] $Action) {
    $refused = $false
    try { & $Action } catch { $refused = $true }
    if (-not $refused) { throw 'Expected refusal' }
}
function Candidate([string] $Source) {
    [pscustomobject]@{ CommandType = 'Application'; Source = $Source }
}
# A real runner exposed these three candidates. Only its first resolution may bind.
$script:candidates = @(
    (Candidate 'C:\Program Files\Git\bin\git.exe'),
    (Candidate 'C:\Program Files\Git\cmd\git.exe'),
    (Candidate 'C:\Program Files\Git\ucrt64\bin\git.exe'))
Assert-Equal (Resolve-ApplicationPath 'git') $script:candidates[0].Source
Assert-Equal $script:bound.Count 1
Assert-Equal $script:bound[0] $script:candidates[0].Source
$script:candidates = @((Candidate 'D:\one\git.exe'))
Assert-Equal (Resolve-ApplicationPath 'git') 'D:\one\git.exe'
$script:candidates = @()
Assert-Refused { Resolve-ApplicationPath 'git' }
$script:candidates = @((Candidate 'relative\git.exe'))
Assert-Refused { Resolve-ApplicationPath 'git' }
$script:candidates = @((Candidate 'D:\unsafe\git.exe'))
$script:refuseBinding = $true
Assert-Refused { Resolve-ApplicationPath 'git' }
Write-Output '5 resolver counterexamples PASS (mocked command discovery and file binding only)'
