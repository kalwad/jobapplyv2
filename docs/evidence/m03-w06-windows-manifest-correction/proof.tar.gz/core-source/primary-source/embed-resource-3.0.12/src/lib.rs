=== source lines 405-457 ===
/// `parameters` are a list of macros to define (directly or via [`ParamsMacros`]), in standard `NAME`/`NAME=VALUE` format,
/// [`ParamsIncludeDirs`], or [`ParamsMacrosAndIncludeDirs`].
///
/// # Examples
///
/// In your build script, assuming the crate's name is "checksums":
///
/// ```rust,no_run
/// extern crate embed_resource;
///
/// fn main() {
///     // Compile and link checksums.rc
///     embed_resource::compile("checksums.rc", embed_resource::NONE);
/// }
/// ```
pub fn compile<T: AsRef<Path>,
               Ms: AsRef<OsStr>,
               Mi: IntoIterator<Item = Ms>,
               Is: AsRef<OsStr>,
               Ii: IntoIterator<Item = Is>,
               P: Into<ParameterBundle<Ms, Mi, Is, Ii>>>(
    resource_file: T, parameters: P)
    -> CompilationResult {
    let (prefix, out_dir, out_file) = try_compile_impl!(compile_impl(resource_file.as_ref(), parameters.into()));
    let hasbins = fs::read_to_string("Cargo.toml")
        .unwrap_or_else(|err| {
            eprintln!("Couldn't read Cargo.toml: {}; assuming src/main.rs or S_ISDIR(src/bin/)", err);
            String::new()
        })
        .parse::<TomlTable>()
        .unwrap_or_else(|err| {
            eprintln!("Couldn't parse Cargo.toml: {}; assuming src/main.rs or S_ISDIR(src/bin/)", err);
            TomlTable::new()
        })
        .contains_key("bin") || (Path::new("src/main.rs").exists() || Path::new("src/bin").is_dir());
    eprintln!("Final verdict: crate has binaries: {}", hasbins);

    if hasbins && rustc_version::version().expect("couldn't get rustc version") >= rustc_version::Version::new(1, 50, 0) {
        println!("cargo:rustc-link-arg-bins={}", out_file);
    } else {
        // Cargo pre-0.51.0 (rustc pre-1.50.0) compat
        // Only links to the calling crate's library
        println!("cargo:rustc-link-search=native={}", out_dir);
        println!("cargo:rustc-link-lib=dylib={}", prefix);
    }
    CompilationResult::Ok
}

/// Likewise, but only for select binaries.
///
/// Only available since rustc 1.55.0, does nothing before.
///
/// # Examples
