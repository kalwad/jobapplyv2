=== source lines 308-393 ===
  }
}

/// Attributes used on Windows.
#[allow(dead_code)]
#[derive(Debug)]
pub struct WindowsAttributes {
  window_icon_path: Option<PathBuf>,
  /// Whether to statically link the Visual C++ runtime into the application binary on Windows MSVC targets
  static_vc_runtime: Option<bool>,
  /// A string containing an [application manifest] to be included with the application on Windows.
  ///
  /// Defaults to:
  /// ```text
  #[doc = include_str!("windows-app-manifest.xml")]
  /// ```
  ///
  /// ## Warning
  ///
  /// if you are using tauri's dialog APIs, you need to specify a dependency on Common Control v6 by adding the following to your custom manifest:
  /// ```text
  ///  <dependency>
  ///    <dependentAssembly>
  ///      <assemblyIdentity
  ///        type="win32"
  ///        name="Microsoft.Windows.Common-Controls"
  ///        version="6.0.0.0"
  ///        processorArchitecture="*"
  ///        publicKeyToken="6595b64144ccf1df"
  ///        language="*"
  ///      />
  ///    </dependentAssembly>
  ///  </dependency>
  /// ```
  ///
  /// [application manifest]: https://learn.microsoft.com/en-us/windows/win32/sbscs/application-manifests
  app_manifest: Option<String>,
  /// A series of strings containing additional .rc content to be appended to the generated resource file on Windows.
  append_rc_content: Vec<String>,
}

impl Default for WindowsAttributes {
  fn default() -> Self {
    Self::new()
  }
}

impl WindowsAttributes {
  /// Creates the default attribute set.
  pub fn new() -> Self {
    Self {
      static_vc_runtime: None,
      app_manifest: Some(include_str!("windows-app-manifest.xml").into()),
      window_icon_path: None,
      append_rc_content: Vec::new(),
    }
  }

  /// Creates the default attribute set without the default app manifest.
  #[must_use]
  pub fn new_without_app_manifest() -> Self {
    Self {
      app_manifest: None,
      window_icon_path: None,
      static_vc_runtime: None,
      append_rc_content: Vec::new(),
    }
  }

  /// Sets the icon to use as the application icon and default window icon.
  /// It must be in `ico` format.
  ///
  /// If not set, we will search for a `.ico` from the `bundle > icon` in your tauri config file, then `icons/icon.ico`.
  #[must_use]
  pub fn window_icon_path<P: AsRef<Path>>(mut self, window_icon_path: P) -> Self {
    self
      .window_icon_path
      .replace(window_icon_path.as_ref().into());
    self
  }

  /// Sets whether to statically link the Visual C++ runtime into the application binary on Windows MSVC targets.
  ///
  /// If unset, this is read from `build > windows > staticVCRuntime` in the Tauri configuration.
  #[must_use]
  pub fn static_vc_runtime(mut self, static_vc_runtime: bool) -> Self {
=== source lines 480-507 ===
    Self::default()
  }

  /// Sets the [`WindowsAttributes`], the Windows-specific options of the build script.
  ///
  /// They are used to configure the [application manifest], the application icon, additional
  /// `.rc` content and the static linking of the Visual C++ runtime.
  /// Setting them has no effect when compiling for other platforms.
  ///
  /// # Examples
  ///
  /// ```rust,no_run
  /// let attributes = tauri_build::Attributes::new().windows_attributes(
  ///   tauri_build::WindowsAttributes::new()
  ///     .window_icon_path("icons/icon.ico")
  ///     .static_vc_runtime(true),
  /// );
  /// tauri_build::try_build(attributes).expect("failed to run tauri-build");
  /// ```
  ///
  /// [application manifest]: https://learn.microsoft.com/en-us/windows/win32/sbscs/application-manifests
  #[must_use]
  pub fn windows_attributes(mut self, windows_attributes: WindowsAttributes) -> Self {
    self.windows_attributes = windows_attributes;
    self
  }

  /// Set the glob pattern to be used to find the capabilities.
=== source lines 788-826 ===
      "cargo:rustc-env=IPHONEOS_DEPLOYMENT_TARGET={}",
      config.bundle.ios.minimum_system_version
    );
  }

  if target_triple.contains("windows") {
    use semver::Version;
    use tauri_winres::{VersionInfo, WindowsResource};

    let window_icon_path = attributes
      .windows_attributes
      .window_icon_path
      .unwrap_or_else(|| {
        // icon paths in the config are relative to the config file
        config_root.join(
          config
            .bundle
            .icon
            .iter()
            .find(|i| i.ends_with(".ico"))
            .map(AsRef::as_ref)
            .unwrap_or("icons/icon.ico"),
        )
      });

    let mut res = WindowsResource::new();

    if let Some(manifest) = attributes.windows_attributes.app_manifest {
      res.set_manifest(&manifest);
    }

    for content in attributes.windows_attributes.append_rc_content {
      res.append_rc_content(&content);
    }

    if let Some(version_str) = &config.version {
      if let Ok(v) = Version::parse(version_str) {
        let version = to_winres_version(&v);
        res.set_version_info(VersionInfo::FILEVERSION, version);
