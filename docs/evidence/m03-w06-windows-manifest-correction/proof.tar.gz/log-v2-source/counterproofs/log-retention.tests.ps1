# UNEXECUTED source counterexamples; later run in native Windows PowerShell.
param([Parameter(Mandatory = $true)][string] $Subject)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$tokens = $null; $errors = $null
$ast = [Management.Automation.Language.Parser]::ParseFile($Subject, [ref]$tokens, [ref]$errors)
if ($errors.Count -ne 0) { throw 'Subject PowerShell parse failed' }
foreach ($name in @('Write-Record', 'Read-DiagnosticBytes', 'Get-OptionalDiagnosticItem', 'Retain-TypecheckLogs')) {
    $definitions = @($ast.FindAll({ param($node)
        $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $name
    }, $false))
    if ($definitions.Count -ne 1) { throw "Expected one actual function: $name" }
    . ([scriptblock]::Create($definitions[0].Extent.Text))
}
function Assert-True([bool] $Value) { if (-not $Value) { throw 'Counterexample assertion failed' } }
function Assert-Refused([scriptblock] $Action) {
    $refused = $false
    try { & $Action | Out-Null } catch { $refused = $true }
    if (-not $refused) { throw 'Expected retention refusal' }
}
$owned = Join-Path ([IO.Path]::GetTempPath()) ('japp-typecheck-log-fixture-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $owned | Out-Null
try {
    function Case-Root([string] $Name) {
        $root = Join-Path $owned $Name
        New-Item -ItemType Directory -Path $root | Out-Null
        [IO.File]::WriteAllText((Join-Path $root '.nvmrc'), '24.14.0')
        [IO.File]::WriteAllText((Join-Path $root 'package.json'), '{"packageManager":"pnpm@11.9.0"}')
        $root
    }
    function Put-Log([string] $Root, [string] $Package, [byte[]] $Bytes) {
        $directory = Join-Path $Root "$Package/.turbo"
        New-Item -ItemType Directory -Path $directory -Force | Out-Null
        [IO.File]::WriteAllBytes((Join-Path $directory 'turbo-typecheck.log'), $Bytes)
    }
    function Output-Root([string] $Root) {
        $output = Join-Path $Root 'output'
        New-Item -ItemType Directory -Path $output | Out-Null
        $output
    }
    # 1. Exact existing bytes and 14 missing logs stay distinct; no test verdict.
    $root = Case-Root 'exact'
    $bytes = [byte[]]@(84,83,32,101,114,114,111,114,13,10)
    Put-Log $root 'apps/desktop' $bytes
    $output = Output-Root $root
    $report = Retain-TypecheckLogs $root $output
    Assert-True ($report.status -eq 'RETENTION_COMPLETE_NOT_A_TEST_VERDICT')
    Assert-True (@($report.tasks | Where-Object status -eq 'RETAINED').Count -eq 1)
    Assert-True (@($report.tasks | Where-Object status -eq 'ABSENT').Count -eq 14)
    $actual = [IO.File]::ReadAllBytes((Join-Path $output 'typecheck-tasks/task-001.log'))
    Assert-True ([Convert]::ToHexString($actual) -eq [Convert]::ToHexString($bytes))
    # 2. Unrelated task/root files do not enter the finite artifact.
    [IO.File]::WriteAllText((Join-Path $root 'apps/desktop/.turbo/turbo-test.log'), 'unrelated')
    [IO.File]::WriteAllText((Join-Path $root 'unrelated-sensitive-name'), 'not selected')
    $secondOutput = Join-Path $root 'second-output'
    New-Item -ItemType Directory -Path $secondOutput | Out-Null
    $null = Retain-TypecheckLogs $root $secondOutput
    Assert-True (@(Get-ChildItem -LiteralPath (Join-Path $secondOutput 'typecheck-tasks') -File).Count -eq 2)
    # 3. An existing output child is refused rather than reused.
    Assert-Refused { Retain-TypecheckLogs $root $output }
    # 4. Oversized logs fail without partial/truncated log evidence.
    $root = Case-Root 'oversized'
    Put-Log $root 'apps/desktop' ([byte[]]::new(1048577))
    $output = Output-Root $root
    Assert-Refused { Retain-TypecheckLogs $root $output }
    Assert-True (@(Get-ChildItem -LiteralPath (Join-Path $output 'typecheck-tasks') -Filter '*.log').Count -eq 0)
    $partial = Get-Content -LiteralPath (Join-Path $output 'typecheck-tasks/manifest.json') -Raw | ConvertFrom-Json
    Assert-True ($partial.status -eq 'INCOMPLETE')
    # 5. A directory with the fixed log name is not accepted as a file.
    $root = Case-Root 'nonregular'
    New-Item -ItemType Directory -Path (Join-Path $root 'apps/desktop/.turbo/turbo-typecheck.log') -Force | Out-Null
    $output = Output-Root $root
    Assert-Refused { Retain-TypecheckLogs $root $output }
    # 6. A ninth 1MiB log exceeds the 8MiB total bound; retained prefix stays failed.
    $root = Case-Root 'total'
    foreach ($package in @('apps/desktop', 'apps/extension', 'apps/mock-ats-lab',
        'packages/ats-adapters', 'packages/contracts', 'packages/domain',
        'packages/evaluation-baselines', 'packages/evaluation-corpus', 'packages/evaluation-runner')) {
        Put-Log $root $package ([byte[]]::new(1048576))
    }
    $output = Output-Root $root
    Assert-Refused { Retain-TypecheckLogs $root $output }
    $partial = Get-Content -LiteralPath (Join-Path $output 'typecheck-tasks/manifest.json') -Raw | ConvertFrom-Json
    Assert-True ($partial.status -eq 'INCOMPLETE' -and $partial.total_bytes -eq 8388608)
    Assert-True (@(Get-ChildItem -LiteralPath (Join-Path $output 'typecheck-tasks') -Filter '*.log').Count -eq 8)
    Write-Output '6 fixed-log retention counterexamples PASS (owned disposable files only)'
}
finally { [IO.Directory]::Delete($owned, $true) }
