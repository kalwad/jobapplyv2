# Actual507a retained synthetic-image inspection

Root opened the fresh completed-run contact PNG with tools.view_image. The public-synthetic/research-only/not-certified guest banner, populated synthetic contact/address controls, blank unsupported controls and unselected sensitive/consent controls are visible. Static Next is visible; the pixels prove no click. Exact image SHA256 8cbae9fe1ecf8469db1f01ec2a94992f0dd116b0dbd3b1ae841e34c2ea0c730b.

The full507a run failed native128 p95. This one contact-image inspection does not alter that failure or replace its unavailable original failure screenshot. It is not a user study, accessibility certification, owner visual approval or Gate A decision.
