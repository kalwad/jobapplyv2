from __future__ import annotations

import ast
import hashlib
import json
import re
import subprocess
from pathlib import Path

PROPOSAL = Path('/tmp/japp-owner-evidence-waiver-machine')
GOVERNANCE = Path('/tmp/japp-owner-external-waiver')
ROOT = Path('/Users/tanishkalwad/jobapplyv2')
OUT = Path('/tmp/japp-owner-evidence-waiver-independent-machine-review')
checks = []

def check(name, ok, details=None):
    checks.append({'name': name, 'pass': bool(ok), 'details': details})

def sha(data):
    return hashlib.sha256(data).hexdigest()

manifest = json.loads((PROPOSAL / 'proposal-manifest.json').read_bytes())
patch = (PROPOSAL / 'owner-evidence-waiver-machine.patch').read_bytes()
check('exact_sealed_patch', len(patch) == 30458 and sha(patch) == 'f4e48ee180f6cfff3105857449b2e8ff578ceb2d11299fd09037511c1f399f38')
check('governance_binding', sha((GOVERNANCE / 'governance-proposal.patch').read_bytes()) == manifest['governance_patch_sha256'] == 'a9c9a959a983491ce7b08a9f7748b24e6baa2e14a0d84bb3fcb9b9b0cade79f3')
paths = ['scripts/validate_status.py', 'scripts/tests/test_validate_status.py', 'scripts/python-test-inventory.v1.json']
check('exact_three_path_scope', [item['path'] for item in manifest['files']] == paths)
before = {}
after = {}
for item in manifest['files']:
    path = item['path']
    before[path] = subprocess.check_output(['git', '-C', str(ROOT), 'show', f"{manifest['base_head']}:{path}"])
    after[path] = (PROPOSAL / 'tree' / path).read_bytes()
    check(f'git_preimage:{path}', len(before[path]) == item['before_bytes'] and sha(before[path]) == item['before_sha256'])
    check(f'proposal_afterimage:{path}', len(after[path]) == item['after_bytes'] and sha(after[path]) == item['after_sha256'])

lines = patch.decode().splitlines(keepends=True)
pos = 0
replayed = {}
while pos < len(lines):
    if not lines[pos].startswith('--- a/'):
        raise ValueError(f'Unexpected patch line {pos}')
    path = lines[pos][6:].rstrip('\n')
    pos += 1
    if lines[pos] != f'+++ b/{path}\n':
        raise ValueError('Unexpected patch target')
    pos += 1
    original = before[path].decode().splitlines(keepends=True)
    output = []
    cursor = 0
    while pos < len(lines) and not lines[pos].startswith('--- a/'):
        hunk = re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n', lines[pos])
        if not hunk:
            raise ValueError(f'Unexpected hunk {pos}')
        old_start = int(hunk[1]) - 1
        old_count = int(hunk[2] or '1')
        new_count = int(hunk[4] or '1')
        output.extend(original[cursor:old_start])
        cursor = old_start
        consumed = produced = 0
        pos += 1
        while pos < len(lines) and not lines[pos].startswith(('@@ ', '--- a/')):
            line = lines[pos]
            if line[0] in ' -':
                if original[cursor] != line[1:]:
                    raise ValueError(f'Preimage context mismatch {path}:{cursor + 1}')
                cursor += 1
                consumed += 1
            if line[0] in ' +':
                output.append(line[1:])
                produced += 1
            pos += 1
        if (consumed, produced) != (old_count, new_count):
            raise ValueError('Hunk counts differ')
    output.extend(original[cursor:])
    replayed[path] = ''.join(output).encode()
    check(f'in_memory_patch_replay:{path}', replayed[path] == after[path])
check('exact_patch_paths', list(replayed) == paths)

old_test = ast.parse(before[paths[1]])
new_test = ast.parse(after[paths[1]])
dump = lambda node: ast.dump(node, include_attributes=False)
check('all_original_test_ast_nodes_preserved', all(dump(a) == dump(b) for a, b in zip(old_test.body, new_test.body, strict=False)) and len(new_test.body) > len(old_test.body))
old_asserts = [dump(n) for n in ast.walk(old_test) if isinstance(n, ast.Assert)]
old_functions = [n.name for n in old_test.body if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
check('original_315_assertions_and_128_tests', len(old_asserts) == 315 and len(old_functions) == 128)
old_validator = ast.parse(before[paths[0]])
new_validator = ast.parse(after[paths[0]])
old_functions_map = {n.name: n for n in old_validator.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
new_functions_map = {n.name: n for n in new_validator.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
changed = [name for name, node in old_functions_map.items() if dump(node) != dump(new_functions_map[name])]
check('only_expected_existing_functions_changed', changed == ['_gate_d_metric_problems', 'check_gates'], changed)
unchanged = manifest['holdout_and_remaining_pass_check_functions_ast_unchanged']
check('existing_holdout_and_gate_pass_checks_unchanged', all(dump(old_functions_map[name]) == dump(new_functions_map[name]) for name in unchanged), unchanged)
literal_constants = {}
for node in new_validator.body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        try:
            literal_constants[node.targets[0].id] = ast.literal_eval(node.value)
        except (ValueError, TypeError):
            pass
gov_text = (GOVERNANCE / 'afterimages/docs/DECISIONS.md').read_text(encoding='utf-8')
heading = literal_constants['OWNER_EVIDENCE_SCOPE_WAIVER_HEADING']
owner_row = literal_constants['OWNER_EVIDENCE_SCOPE_WAIVER_OWNER_ROW']
section = gov_text.split(heading + '\n', 1)[1]
section = re.split(r'^##(?:#)? ', section, maxsplit=1, flags=re.MULTILINE)[0]
authority = literal_constants['OWNER_EVIDENCE_SCOPE_WAIVER_PREIMAGE_DOMAIN'] + (owner_row + '\n' + heading + '\n' + section.rstrip('\n') + '\n').encode()
check('accepted_owner_preimage_digest_exact', 'sha256:' + sha(authority) == manifest['accepted_owner_record_digest'] == 'sha256:fc1529b286c358c36557e810e105d63a4cca6366b3fad913dee38dba4395df02')
for suffix in ['APPROVAL', 'DECISION', 'SCOPE']:
    value = literal_constants[f'OWNER_EVIDENCE_SCOPE_WAIVER_{suffix}']
    check(f'authority_constant_exact:{suffix}', section.splitlines().count(value) == 1)

old_inventory = json.loads(before[paths[2]])
new_inventory = json.loads(after[paths[2]])
old_nodes = old_inventory['common']['node_ids']
new_nodes = new_inventory['common']['node_ids']
added = sorted(set(new_nodes) - set(old_nodes))
check('inventory_preserves_all_prior_nodes', set(old_nodes) <= set(new_nodes) and len(old_nodes) == 1452)
check('inventory_exact_38_new_waiver_cases', len(added) == 38 and all(n.startswith('scripts/tests/test_validate_status.py::test_owner_evidence_waiver_') for n in added), added)
check('inventory_sort_count_digest', new_nodes == sorted(set(new_nodes)) and len(new_nodes) == new_inventory['common']['count'] == 1490 and sha(('\n'.join(new_nodes) + '\n').encode()) == new_inventory['common']['sha256'])
check('posix_cohort_and_format_unchanged', new_inventory['posix_only_node_ids'] == old_inventory['posix_only_node_ids'] and len(new_inventory['posix_only_node_ids']) == 2 and new_inventory['schema_version'] == old_inventory['schema_version'] and new_inventory['normalization_version'] == old_inventory['normalization_version'])
contract_paths = subprocess.check_output(['git', '-C', str(ROOT), 'ls-files', 'packages/contracts']).decode().splitlines()
check('all_358_contract_files_byte_unchanged', len(contract_paths) == 358 and all((PROPOSAL / 'tree' / path).read_bytes() == (PROPOSAL / 'red-tree' / path).read_bytes() for path in contract_paths))
red_log = (PROPOSAL / 'before-focused-final.log').read_text()
green_log = (PROPOSAL / 'after-focused-final.log').read_text()
check('actual_final_two_before_regressions_retained', '2 failed, 237 deselected in 0.41s' in red_log and 'assert 0 == 1' in red_log and 'AssertionError: assert []' in red_log)
check('actual_focused_38_green_retained', '38 passed, 201 deselected in 3.33s' in green_log)
check('same_new_test_source_red_green', (PROPOSAL / 'red-tree' / paths[1]).read_bytes() == after[paths[1]])
check('red_runs_original_validator', (PROPOSAL / 'red-tree' / paths[0]).read_bytes() == before[paths[0]])
result = {'scope': 'Independent source/AST/hash/in-memory patch review; no product execution or test invocation', 'status': 'CLEAR' if all(item['pass'] for item in checks) else 'FINDING', 'checks_passed': sum(item['pass'] for item in checks), 'checks_total': len(checks), 'checks': checks, 'findings': []}
(OUT / 'machine-checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ['status', 'checks_passed', 'checks_total']}))
raise SystemExit(0 if result['status'] == 'CLEAR' else 1)
