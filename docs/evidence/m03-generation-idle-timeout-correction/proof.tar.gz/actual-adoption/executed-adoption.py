"""Apply exactly the reviewed client/new test and additive exact catalog."""
from pathlib import Path
import datetime,hashlib,json,os,stat,subprocess
E=Path(__file__).parent;R=Path('/Users/tanishkalwad/jobapplyv2')
P=E/'generation-idle-timeout-state-correction/v1'
V=E/'generation-idle-timeout-state-independent-review/v2-corrected'
O=E/'generation-idle-timeout-state-canonical-adoption/v1'
CLIENT='services/orchestrator/src/orchestrator/generation/client.py'
TEST='services/orchestrator/tests/test_generation_early_idle_timeout.py'
CAT='scripts/python-test-inventory.v1.json'
def sha(b):return hashlib.sha256(b).hexdigest()
def row(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink();b=p.read_bytes();return {'bytes':len(b),'full_mode':s.st_mode,'sha256':sha(b)}
def git(*args):return subprocess.check_output(['git','--no-optional-locks',*args],cwd=R,timeout=20).decode().strip()
def snap():
 names=subprocess.check_output(['git','--no-optional-locks','ls-files','--cached','--others','--exclude-standard','-z'],cwd=R,timeout=20).split(b'\0')
 return {'source':{os.fsdecode(n):row(R/os.fsdecode(n)) for n in names if n},'runtime':{p.relative_to(R/'apps/desktop/src-tauri/runtime-payload').as_posix():row(p) for p in sorted((R/'apps/desktop/src-tauri/runtime-payload').rglob('*')) if p.is_file()},'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain','--untracked-files=all'),'index':row(R/'.git/index')}
def dump(name,x):
 with (O/name).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
assert sha((P/'SOURCE.json').read_bytes())=='471d5e158acd818506ab65dbcd920bcf9029a7c4b888450c8ead6c4a5ac67466'
assert sha((V/'REVIEW.json').read_bytes())=='fc5387674a4575516ba93f46ce2f85a116858ccea799e654729694b64669e175'
full=json.loads((E/'full-f3a1c6f/closure.json').read_bytes())
assert full['all_commands_exit_zero'] and full['source_bytes_modes_unchanged'] and full['runtime_bytes_modes_unchanged'] and full['commit_and_tree_equal_at_end_observation'] and full['git_status_before']==full['git_status_after']==''
O.mkdir(parents=True,exist_ok=False);(O/'executed-adoption.py').write_bytes(Path(__file__).read_bytes())
before=snap();assert before['head']=='f3a1c6f7ad62161c682d92f842003fd018c5eec1' and before['tree']=='298ac93fe910d8917d3863d48e5f6c2621bf3f17' and before['status']=='' and len(before['source'])==2348 and len(before['runtime'])==40
assert before['source'][CLIENT]['sha256']=='661328686b629ea247bb5ab32b370074568ff68510b1f943eaf8ade0886c6b8e'
assert before['source'][CAT]['sha256']=='691537e00c2b306233b17cc77a6ed79d5c1122ca87d492f5b4adaf4b78a244db' and TEST not in before['source']
dump('before.json',before)
after_client=(P/'candidate'/CLIENT).read_bytes();after_test=(P/'candidate'/TEST).read_bytes()
assert sha(after_client)=='977e075952198cd3344ab61bb6a2dbd8f0625a8f175016371263832266c46a1e' and sha(after_test)=='795feee8175943f4375dcea0d6c2c0caac5f241d48696535e5fcf9de1864cb0b'
old_catalog=json.loads((R/CAT).read_bytes());catalog=json.loads((R/CAT).read_bytes());ids=json.loads((P/'new-test-node-ids.json').read_bytes())['node_ids']
assert len(ids)==len(set(ids))==29 and all(i.startswith(TEST+'::') for i in ids) and not set(ids)&set(catalog['common']['node_ids'])
all_ids=sorted(catalog['common']['node_ids']+ids)
catalog['common'].update(node_ids=all_ids,count=len(all_ids),sha256=sha(('\n'.join(all_ids)+'\n').encode()))
assert catalog['common']['count']==2815 and len(catalog['posix_only_node_ids'])==2 and old_catalog['posix_only_node_ids']==catalog['posix_only_node_ids'] and set(catalog['common']['node_ids'])-set(old_catalog['common']['node_ids'])==set(ids)
assert set(old_catalog['common']['node_ids'])<=set(all_ids)
after_catalog=(json.dumps(catalog,indent=2)+'\n').encode()
for name,body in [(CLIENT,after_client),(CAT,after_catalog),(TEST,after_test)]:
 old_path=R/name;target=O/'after'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body)
 if old_path.exists():
  backup=O/'before'/name;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(old_path.read_bytes());mode=stat.S_IMODE(old_path.stat().st_mode);old_path.write_bytes(body);old_path.chmod(mode)
 else:
  with old_path.open('xb') as f:f.write(body)
  old_path.chmod(0o644)
after=snap();dump('after.json',after)
assert len(after['source'])==2349 and set(after['source'])==set(before['source'])|{TEST}
changed=[n for n in before['source'] if before['source'][n]!=after['source'][n]]
assert set(changed)=={CLIENT,CAT}
assert before['runtime']==after['runtime'] and before['head']==after['head'] and before['tree']==after['tree'] and before['index']==after['index']
assert set(after['status'].splitlines())=={'M '+CLIENT,' M '+CAT,'?? '+TEST} or set(after['status'].splitlines())=={'M '+CAT,' M '+CLIENT,'?? '+TEST}
closure={'end_utc':datetime.datetime.now(datetime.UTC).isoformat(),'selected_existing_deltas':sorted(changed),'added_test':TEST,'source_count_before':2348,'source_count_after':2349,'unselected_2346_existing_sources_full_modes_unchanged':True,'runtime40_bytes_full_modes_unchanged':True,'head_tree_index_unchanged':True,'catalog_common_count':2815,'catalog_posix_total':2817,'all_2788_old_ids_retained':True,'new_ids':29,'manual_cache_mutations':0,'scope':'Guarded source/catalog adoption only, after full-f3 phase closed. Independent correction review and165 fresh synthetic cases do not transfer a full current-source or Windows PASS. No native/model/default/VM actor or formal acceptance. Tool exit observed separately; no independently retained outer Popen custody claimed.'}
dump('closure.json',closure);print(json.dumps(closure),flush=True)
