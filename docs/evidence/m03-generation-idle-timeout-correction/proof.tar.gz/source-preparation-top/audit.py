"""Finite source/raw/QA joins, no subject execution."""
from pathlib import Path
import ast,difflib,hashlib,json,re,shutil,stat
P=Path(__file__).resolve().parent;R=Path('/Users/tanishkalwad/jobapplyv2');C=P/'candidate'
CLIENT='services/orchestrator/src/orchestrator/generation/client.py';TEST='services/orchestrator/tests/test_generation_early_idle_timeout.py'
def row(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode)
 return {'bytes':s.st_size,'full_mode':s.st_mode,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def load(p):return json.loads(p.read_text())
def write(p,data):p.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
checks=[]
def check(name,yes):checks.append({'name':name,'passed':bool(yes)});assert yes,name
initial=load(P/'canonical-inputs.before.json');current={name:row(R/name) for name in initial}
check('finite15 canonical original endpoints exact',current==initial)
for name,value in initial.items():
 check('before exact bytes/fullmode '+name,row(P/'before'/name)==value)
 check('candidate only client changes '+name,name==CLIENT or row(C/name)==value)
check('only client changed',row(C/CLIENT)!=initial[CLIENT])
oldfiles={str(q.relative_to(P/'before')) for q in (P/'before').rglob('*') if q.is_file()}
newfiles={str(q.relative_to(C)) for q in C.rglob('*') if q.is_file()}
check('only one added test',newfiles-oldfiles=={TEST} and oldfiles<=newfiles)
for name in sorted(n for n in initial if '/tests/' in n):check('whole old test body '+name,row(C/name)==initial[name])
old=ast.parse((P/'before'/CLIENT).read_text());new=ast.parse((C/CLIENT).read_text())
def shape(n):return ast.dump(n,include_attributes=False)
def keyed(tree):return {n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
a,b=keyed(old),keyed(new)
check('only helper declaration added',set(b)-set(a)=={'_admit_idle'} and set(a)<=set(b))
for name in a:
 if name!='_consume':check('unchanged source declaration '+name,shape(a[name])==shape(b[name]))
check('module constants/imports exact',[shape(n) for n in old.body if not isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))]==[shape(n) for n in new.body if not isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))])
helper=b['_admit_idle'];check('active/deadline admission before expired refusal',ast.unparse(helper.body[0])=='_admit(deadline, active)' and ast.unparse(helper.body[1].test)=='timer.expired()')
first=ast.parse((P/'history/test-first-new-tests.py.txt').read_text());finaltests=ast.parse((C/TEST).read_text())
check('all original19 control bodies AST exact',[shape(n) for n in first.body]==[shape(n) for n in finaltests.body[:len(first.body)]])
collection=(P/'quality/sealed-final-collection/stdout').read_text();ids=[line for line in collection.splitlines() if line.startswith('services/') and '::' in line]
added=sorted(n for n in ids if n.startswith(TEST+'::'));oldids=[n for n in ids if not n.startswith(TEST+'::')]
check('actual165 IDs unique',len(ids)==len(set(ids))==165)
check('actual29 additive and136 old',len(added)==29 and len(oldids)==136)
shutil.copy2(R/'scripts/python-test-inventory.v1.json',P/'reference/python-test-inventory.v1.json')
catalog=load(P/'reference/python-test-inventory.v1.json');catalogids=set(catalog['common']['node_ids'])|set(catalog['posix_only_node_ids'])
check('exact old catalog2788 / no new IDs',len(catalogids)==2788 and set(oldids)<=catalogids and set(added).isdisjoint(catalogids))
write(P/'new-test-node-ids.json',{'count':29,'node_ids':added,'normalization':'sorted exact actual collected IDs; newline-terminated sha256','sha256':hashlib.sha256(('\n'.join(added)+'\n').encode()).hexdigest(),'old_catalog':row(P/'reference/python-test-inventory.v1.json'),'expected_future_total_only':2817,'no_canonical_catalog_write':True})
for name,record in load(P/'control-source-bindings.json').items():
 root=P/'controls'/name
 for relative in newfiles:
  check(name+' exact other source '+relative,relative==CLIENT or row(root/relative)==row(C/relative))
 check(name+' pinned client',row(root/CLIENT)['sha256']==record['client_sha256'])
check('old control client byte/fullmode exact',row(P/'controls/exact-old-source'/CLIENT)==initial[CLIENT])
raw=(C/CLIENT).read_text();guard='    if timer.expired():\n        raise GenerationFailure(ErrorCode.TIMEOUT)\n';close='            if timeout_failure is not None and isinstance(close_error, Exception):\n                raise timeout_failure from None\n'
check('expired mutant exact two line removal',(P/'controls/exact-final-no-expired-guard'/CLIENT).read_text()==raw.replace(guard,'',1))
check('close mutant exact two line removal',(P/'controls/exact-final-no-timeout-close-priority'/CLIENT).read_text()==raw.replace(close,'',1))
expected=raw
for timer in ('open','read'):
 indent='        ' if timer=='open' else '                '
 expected=expected.replace(f'except Exception:\n{indent}_admit_idle({timer}_deadline, {timer}_timer, active)',f'except Exception:\n{indent}_admit({timer}_deadline, active)',1)
check('raw mutant only two exception admissions',(P/'controls/exact-final-no-raw-expired-admission'/CLIENT).read_text()==expected)
receipts=[]
for q in sorted((P/'quality').glob('*/receipt.json')):
 value=load(q);receipts.append(value);directory=q.parent
 check('owned closed '+value['name'],value['reaped'] and value['group_after_wait']=='ABSENT' and value['signals']==[] and value['stop'] is None)
 check('retained outputs '+value['name'],row(directory/'stdout')==value['stdout'] and row(directory/'stderr')==value['stderr'])
 check('bounded source/canonical endpoints '+value['name'],load(directory/'source-before.json')==load(directory/'source-after.json') and load(directory/'canonical-before.json')==load(directory/'canonical-after.json')==initial)
 if value['name'].startswith('sealed-final-'):
  check('final command exact source '+value['name'],load(directory/'source-before.json')=={n:row(C/n) for n in sorted(newfiles)} and value['exit_code']==0)
expected_counts={'tests-first-red':(6,13),'close-error-tests-first-red':(3,23),'exact-old-source':(9,156),'exact-final-no-expired-guard':(9,156),'exact-final-no-raw-expired-admission':(3,162),'exact-final-no-timeout-close-priority':(3,162)}
for name,(fail,passed) in expected_counts.items():
 output=(P/'quality'/name/'stdout').read_text();check('actual counts '+name,f'{fail} failed, {passed} passed' in output)
check('final165 actual PASS','165 passed' in (P/'quality/sealed-final-pytest/stdout').read_text())
check('final strict13 files','Success: no issues found in 13 source files' in (P/'quality/sealed-final-mypy/stdout').read_text())
raw_log=load(P/'reference/windows-raw-log.json');check('original Windows raw unchanged',all(row(Path(raw_log['path']))[k]==raw_log[k] for k in ['bytes','full_mode','sha256']))
excerpt=(P/'reference/windows-python-failure-excerpt.log').read_text();check('actual Windows two DIDNOTRAISE + original failure summary',excerpt.count('E       Failed: DID NOT RAISE GenerationError')==2 and '3 failed, 2783 passed in 681.25s' in excerpt)
for name,item in load(P/'reference/python-runtime.json')['files'].items():check('pinned actual stdlib '+name,row(P/'reference'/('python312-'+name))==item)
(P/'delta.patch').write_text(''.join(difflib.unified_diff((P/'before'/CLIENT).read_text().splitlines(keepends=True),(C/CLIENT).read_text().splitlines(keepends=True),fromfile='a/'+CLIENT,tofile='b/'+CLIENT)))
write(P/'afterimages.json',{'canonical_afterimages_only':{CLIENT:{'before':initial[CLIENT],'after':row(C/CLIENT),'source':'candidate/'+CLIENT},TEST:{'before':None,'after':row(C/TEST),'source':'candidate/'+TEST}},'all_old_test_files_preserved':7,'all_old_generation_cases_preserved':136,'new_case_count':29,'catalog_extension':'new-test-node-ids.json; root regenerates after current full closure','no_canonical_write':True})
write(P/'canonical-inputs.after.json',current)
write(P/'data-review.json',{'passed':len(checks),'failed':0,'checks':checks,'owned_QA_children':len(receipts),'finite_canonical_components':15,'source_candidate_components':16,'all_old_generation_cases':136,'new_cases':29,'final_pass':165,'scope':'Author audit; not different review/native/Windows actual execution or current CI credit. Only finite source endpoints, no whole canonical epoch claim.'})
write(P/'quality-summary.json',{'receipts':receipts,'final_authoritative_labels':['sealed-final-pytest','sealed-final-ruff','sealed-final-format','sealed-final-mypy','sealed-final-collection'],'negative_controls':expected_counts,'all_source_and_original_test_bytes_retained':True})
print(json.dumps({'passed':len(checks),'failed':0,'owned_children':len(receipts),'client':row(C/CLIENT),'new_test':row(C/TEST)}))
