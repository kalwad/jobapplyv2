from pathlib import Path
import hashlib,json,stat,tarfile
P=Path(__file__).resolve().parent
def row(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink()
 return {'bytes':s.st_size,'full_mode':s.st_mode,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def write(name,obj):(P/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
excluded={'SOURCE.json','manifest.json','SEAL.json','proof.tar.gz'}
files={str(q.relative_to(P)):row(q) for q in sorted(P.rglob('*')) if q.is_file() and q.name not in excluded and not any(part.endswith('mypy-cache') or part=='__pycache__' for part in q.relative_to(P).parts)}
write('SOURCE.json',{'status':'FROZEN_SOURCE_PREPARATION_REQUIRES_DIFFERENT_REVIEW','files':files,'excluded':'Only disposable outside mypy-cache directories and any __pycache__; source, test bodies, raw receipts and histories retained.','archive_mode_scope':'Exact original physical regular modes, sizes and hashes preserved.'})
paths=sorted(files)+['SOURCE.json']
with tarfile.open(P/'proof.tar.gz','w:gz',format=tarfile.PAX_FORMAT) as t:
 for name in paths:t.add(P/name,arcname=name,recursive=False)
with tarfile.open(P/'proof.tar.gz','r:gz') as t:
 members=t.getmembers();assert len(members)==len(paths)==len(set(m.name for m in members))
 for m in members:
  assert m.isreg() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  r=row(P/m.name);assert m.size==r['bytes'] and (stat.S_IFREG|m.mode)==r['full_mode'] and hashlib.sha256(t.extractfile(m).read()).hexdigest()==r['sha256']
write('manifest.json',{'source':row(P/'SOURCE.json'),'handoff':row(P/'HANDOFF.json'),'afterimages':row(P/'afterimages.json'),'data':row(P/'data-review.json'),'proof':row(P/'proof.tar.gz'),'regular_members':len(paths),'safe_archive_bytes_full_modes_verified':True})
seal={'status':'FROZEN_FOR_DIFFERENT_REVIEW_NO_CANONICAL_ADOPTION','source':row(P/'SOURCE.json'),'handoff':row(P/'HANDOFF.json'),'manifest':row(P/'manifest.json'),'proof':row(P/'proof.tar.gz'),'regular_members':len(paths)}
write('SEAL.json',seal);print(json.dumps(seal,indent=2))
