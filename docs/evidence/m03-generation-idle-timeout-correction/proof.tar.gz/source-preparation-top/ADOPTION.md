Root review is required before canonical adoption. The only proposed afterimages are the two entries in afterimages.json:

- services/orchestrator/src/orchestrator/generation/client.py — replacement over the exact retained preimage.
- services/orchestrator/tests/test_generation_early_idle_timeout.py — new additive test module.

All other before/candidate/control files are dependency/test/evidence snapshots and are not proposed replacements. There is no catalog afterimage: root should extend the current catalog with the exact 29 recorded IDs and run actual collection after its active full run closes. No dependency, schema, prompt, provider default, transport, model lock or selected stack changes.

Rebase the client delta explicitly with the separate M05 normalization parent. Do not overwrite either reviewed feature wholesale. Recheck source preimages and strict scopes before adoption. No external provider, model pull, real Ollama/11434, native API, production service or workflow authorization is included.
