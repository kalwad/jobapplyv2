"""Owned bounded QA for outside synthetic generation source; no live provider."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,signal,stat,subprocess,time
P=Path(__file__).resolve().parent;R=Path('/Users/tanishkalwad/jobapplyv2')
def meta(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode)
 return {'bytes':s.st_size,'full_mode':s.st_mode,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def write(p,obj):p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def group(pid):
 try:os.killpg(pid,0);return 'PRESENT'
 except ProcessLookupError:return 'ABSENT'
def snapshot(root):return {str(q.relative_to(root)):meta(q) for q in sorted(root.rglob('*')) if q.is_file() and q.suffix in ('.py','.toml','.typed') and '__pycache__' not in q.parts}
parser=argparse.ArgumentParser();parser.add_argument('name');parser.add_argument('cwd',type=Path);parser.add_argument('expected',type=int);parser.add_argument('argv',nargs=argparse.REMAINDER);args=parser.parse_args();argv=args.argv
if argv and argv[0]=='--':argv=argv[1:]
Q=P/'quality'/args.name;Q.mkdir(exist_ok=False)
source_before=snapshot(args.cwd);canonical_names=json.loads((P/'canonical-inputs.before.json').read_text());canonical_before={name:meta(R/name) for name in canonical_names}
write(Q/'source-before.json',source_before);write(Q/'canonical-before.json',canonical_before)
env={**os.environ,'PYTHONPATH':str(args.cwd/'services/orchestrator/src')+os.pathsep+str(args.cwd),'PYTHONDONTWRITEBYTECODE':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1'}
env.pop('PYTEST_ADDOPTS',None)
start=time.monotonic();utc=datetime.datetime.now(datetime.UTC).isoformat();signals=[];stop=None;child=None
with (Q/'stdout').open('xb') as out,(Q/'stderr').open('xb') as err:
 child=subprocess.Popen(argv,cwd=args.cwd,env=env,stdout=out,stderr=err,start_new_session=True)
 try:
  while child.poll() is None:
   if time.monotonic()-start>60:stop='TIMEOUT';break
   if max((Q/'stdout').stat().st_size,(Q/'stderr').stat().st_size)>8*1024*1024:stop='OUTPUT_LIMIT';break
   time.sleep(.025)
  if stop is not None:
   try:os.killpg(child.pid,signal.SIGKILL);signals.append('SIGKILL')
   except ProcessLookupError:pass
  code=child.wait(timeout=3)
 finally:
  if child.poll() is None:
   try:os.killpg(child.pid,signal.SIGKILL);signals.append('SIGKILL')
   except ProcessLookupError:pass
   child.wait(timeout=3)
source_after=snapshot(args.cwd);canonical_after={name:meta(R/name) for name in canonical_names}
write(Q/'source-after.json',source_after);write(Q/'canonical-after.json',canonical_after)
receipt={'name':args.name,'argv':argv,'cwd':str(args.cwd),'start_utc':utc,'end_utc':datetime.datetime.now(datetime.UTC).isoformat(),'seconds':time.monotonic()-start,'exit_code':code,'expected_exit':args.expected,'pid':child.pid,'pgid':child.pid,'reaped':child.returncode is not None,'group_after_wait':group(child.pid),'signals':signals,'stop':stop,'source_endpoint_equal':source_before==source_after,'finite_canonical_endpoint_equal':canonical_before==canonical_after,'canonical_components':len(canonical_names),'source_components':len(source_before),'stdout':meta(Q/'stdout'),'stderr':meta(Q/'stderr'),'runner':meta(Path(__file__)),'environment_projection':{k:env[k] for k in ['PYTHONPATH','PYTHONDONTWRITEBYTECODE','PYTEST_DISABLE_PLUGIN_AUTOLOAD']},'scope':'Outside source/synthetic fixtures only; no external/live provider/model/daemon/native actor. Finite component endpoints, not whole canonical epoch.'}
write(Q/'receipt.json',receipt);print(json.dumps(receipt))
assert code==args.expected and receipt['reaped'] and receipt['group_after_wait']=='ABSENT' and not signals and stop is None and source_before==source_after and canonical_before==canonical_after
