from pathlib import Path
from datetime import UTC,datetime
import hashlib,json,stat,tarfile
H=Path(__file__).resolve().parent
def pin(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink();b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'full_mode':s.st_mode}
for r in json.loads((H/'retained-members.json').read_bytes()):
 expected={k:r[k] for k in ('bytes','sha256','full_mode')};assert pin(Path(r['source']))==pin(H/r['copy'])==expected
d=json.loads((H/'DATA.json').read_bytes());assert d['result']['data_joins']==4832 and d['result']['all_checks_pass'] and all(r['pass'] for r in d['checks'])
excluded={'manifest.json','proof.tar.gz','SEAL.json'}
files={p.relative_to(H).as_posix():pin(p) for p in sorted(H.rglob('*')) if p.is_file() and p.relative_to(H).as_posix() not in excluded}
m={'schema_version':1,'file_count':len(files),'bytes':sum(r['bytes'] for r in files.values()),'files':files,'scope':'Finite different closed adoption/focus actual-data review; all regular, manifest/proof/seal self-excluded. No later working-tree claim.'};(H/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
with tarfile.open(H/'proof.tar.gz','w:gz',compresslevel=6) as archive:
 for name in [*files,'manifest.json']:archive.add(H/name,arcname=name,recursive=False)
with tarfile.open(H/'proof.tar.gz','r:gz') as archive:
 members=archive.getmembers();assert len(members)==len(files)+1 and all(x.isfile() and not x.name.startswith('/') and '..' not in Path(x.name).parts for x in members)
 for member in members:
  stream=archive.extractfile(member);assert stream is not None;b=stream.read();r=pin(H/member.name);assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
s={'utc':datetime.now(UTC).isoformat(),'verdict':'CLEAR_FINITE_CANONICAL_ADOPTION_AND_FOCUS','REVIEW':pin(H/'REVIEW.md'),'DATA':pin(H/'DATA.json'),'findings':pin(H/'findings.json'),'manifest':pin(H/'manifest.json'),'proof':pin(H/'proof.tar.gz'),'indexed_regular_members':len(files),'safe_proof_regular_members':len(files)+1,'scope':'Exact historical adoption/focus only; no newfull/CI/native/model/gate/release acceptance.'};(H/'SEAL.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s))
