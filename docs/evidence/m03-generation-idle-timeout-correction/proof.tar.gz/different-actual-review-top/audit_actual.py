"""Finite inert actual adoption/focus data review; no subject execution."""
from pathlib import Path
from datetime import UTC, datetime
from copy import deepcopy
import hashlib
import json
import re
import stat

H = Path(__file__).resolve().parent
E = H.parents[1]
R = Path('/Users/tanishkalwad/jobapplyv2')
A = E / 'generation-idle-timeout-state-canonical-adoption/v1'
F = E / 'generation-idle-timeout-state-canonical-focus/v1'
P = E / 'generation-idle-timeout-state-correction/v1'
V = E / 'generation-idle-timeout-state-independent-review/v2-corrected'
FULL = E / 'clean-full-f3a1c6f-independent-review/v1'
CLIENT = 'services/orchestrator/src/orchestrator/generation/client.py'
TEST = 'services/orchestrator/tests/test_generation_early_idle_timeout.py'
CAT = 'scripts/python-test-inventory.v1.json'
checks = []
def sha(body): return hashlib.sha256(body).hexdigest()
def pin(path):
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode) and not path.is_symlink()
    return {'bytes': s.st_size, 'full_mode': s.st_mode, 'sha256': sha(path.read_bytes())}
def load(path): return json.loads(path.read_bytes())
def check(name, value):
    checks.append({'check': name, 'pass': bool(value)})
    assert value, name
def retain(source, relative):
    before = pin(source)
    target = H / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(source.read_bytes())
    target.chmod(stat.S_IMODE(before['full_mode']))
    check('retained copy exact:' + relative, pin(source) == before == pin(target))
    return {'source': str(source), 'copy': relative, **before}
assert (A / 'closure.json').is_file() and (F / 'closure.json').is_file()
copied = []
for root, prefix in [(A, 'retained/adoption'), (F, 'retained/focus')]:
    paths = [p for p in sorted(root.rglob('*')) if p.is_file()]
    check('finite closed parent count:' + str(root), len(paths) <= 100 and sum(p.stat().st_size for p in paths) < 16*1024*1024)
    for path in paths: copied.append(retain(path, prefix + '/' + path.relative_to(root).as_posix()))
for source, relative in [
    (P / 'SOURCE.json', 'retained/source-parent/SOURCE.json'),
    (P / 'new-test-node-ids.json', 'retained/source-parent/new-test-node-ids.json'),
    (P / 'candidate' / CLIENT, 'retained/source-parent/candidate/' + CLIENT),
    (P / 'candidate' / TEST, 'retained/source-parent/candidate/' + TEST),
    (P / 'candidate/pyproject.toml', 'retained/source-parent/pyproject.toml'),
    (V / 'REVIEW.json', 'retained/independent-source-review/REVIEW.json'),
    (V / 'SOURCE.json', 'retained/independent-source-review/SOURCE.json'),
    (FULL / 'immutable-git-source-sha256.json', 'retained/f3-full/immutable-source-map.json'),
    (FULL / 'final-source-runtime.json', 'retained/f3-full/final-source-runtime.json'),
    (FULL / 'manifest.json', 'retained/f3-full/manifest.json'),
    (FULL / 'REVIEW.md', 'retained/f3-full/REVIEW.md'),
]: copied.append(retain(source, relative))
(H / 'retained-members.json').write_text(json.dumps(copied, indent=2)+'\n')
check('source parent pin exact', pin(P / 'SOURCE.json')['sha256'] == '471d5e158acd818506ab65dbcd920bcf9029a7c4b888450c8ead6c4a5ac67466')
check('different source review pin exact', pin(V / 'REVIEW.json')['sha256'] == 'fc5387674a4575516ba93f46ce2f85a116858ccea799e654729694b64669e175')
check('f3 sealed full manifest pin exact', pin(FULL / 'manifest.json')['sha256'] == 'ec06f1fc9be90c4708133add2d3effeac7d9d8be9121f4999354f2e21744b3db')
full_manifest = load(FULL / 'manifest.json')
check('f3 final snapshot sealed member exact', pin(FULL / 'final-source-runtime.json') == full_manifest['files']['final-source-runtime.json'])
mapping = load(FULL / 'immutable-git-source-sha256.json')
before, after, ac = [load(A / name) for name in ('before.json', 'after.json', 'closure.json')]
physical = load(FULL / 'final-source-runtime.json')
check('adoption before fixed full epoch exact', before['source'] == physical['source'] and before['head'] == physical['head'] == mapping['commit'] and before['tree'] == physical['tree'] == mapping['tree'] and before['status'] == physical['status'] == '' and before['index'] == physical['index'])
for name, expected in mapping['files'].items():
    actual = before['source'][name]
    check('immutable2348 preimage:' + name, actual['bytes'] == expected['bytes'] and actual['sha256'] == expected['sha256'] and bool(actual['full_mode'] & 0o111) == (expected['git_mode'] == '100755'))
check('source exact addition only', len(before['source']) == 2348 and len(after['source']) == 2349 and set(after['source']) == set(before['source']) | {TEST})
changed = [name for name in before['source'] if before['source'][name] != after['source'][name]]
check('two existing selected changes exact', set(changed) == {CLIENT, CAT})
for name in sorted(set(before['source']) - {CLIENT, CAT}): check('unselected2346 body/fullmode preserved:' + name, before['source'][name] == after['source'][name])
check('adoption runtime40 unchanged', before['runtime'] == after['runtime'] and len(before['runtime']) == 40)
check('runtime before joins closed f3 snapshot', {'apps/desktop/src-tauri/runtime-payload/' + n: row for n, row in before['runtime'].items()} == physical['runtime'])
check('adoption head tree index neutral', before['head'] == after['head'] and before['tree'] == after['tree'] and before['index'] == after['index'])
for name in (CLIENT, CAT):
    check('retained exact preimage:' + name, pin(A / 'before' / name) == before['source'][name])
for name in (CLIENT, CAT, TEST): check('retained exact afterimage:' + name, pin(A / 'after' / name) == after['source'][name])
source_manifest = load(P / 'SOURCE.json')
source_review_manifest = load(V / 'SOURCE.json')
for name, expected_sha in [(CLIENT, '977e075952198cd3344ab61bb6a2dbd8f0625a8f175016371263832266c46a1e'), (TEST, '795feee8175943f4375dcea0d6c2c0caac5f241d48696535e5fcf9de1864cb0b')]:
    check('reviewed afterimage identity:' + name, pin(A / 'after' / name)['sha256'] == expected_sha and pin(P / 'candidate' / name) == source_manifest['files']['candidate/' + name] == source_review_manifest['files']['candidate/' + name] == after['source'][name])
check('client old exact pin', before['source'][CLIENT]['sha256'] == '661328686b629ea247bb5ab32b370074568ff68510b1f943eaf8ade0886c6b8e')
old = load(A / 'before' / CAT)
new = load(A / 'after' / CAT)
ids = load(P / 'new-test-node-ids.json')
check('new29 IDs source-bound', pin(P / 'new-test-node-ids.json') == source_manifest['files']['new-test-node-ids.json'] and len(ids['node_ids']) == len(set(ids['node_ids'])) == ids['count'] == 29 and all(node.startswith(TEST+'::') for node in ids['node_ids']) and sha(('\n'.join(ids['node_ids'])+'\n').encode()) == ids['sha256'])
check('old catalog exact immutable pin', pin(A / 'before' / CAT)['sha256'] == '691537e00c2b306233b17cc77a6ed79d5c1122ca87d492f5b4adaf4b78a244db')
expected = deepcopy(old)
nodes = sorted(old['common']['node_ids'] + ids['node_ids'])
expected['common'].update(node_ids=nodes, count=len(nodes), sha256=sha(('\n'.join(nodes)+'\n').encode()))
check('catalog only exact additive fields', new == expected and len(set(nodes)) == len(nodes) == 2815 and not set(old['common']['node_ids']) & set(ids['node_ids']))
old_all = set(old['common']['node_ids']) | set(old['posix_only_node_ids'])
new_all = set(new['common']['node_ids']) | set(new['posix_only_node_ids'])
check('all2788 old retained plus29 gives2817', len(old_all) == 2788 and old_all <= new_all and new_all-old_all == set(ids['node_ids']) and len(new_all) == 2817 and len(new['posix_only_node_ids']) == 2 and old['posix_only_node_ids'] == new['posix_only_node_ids'])
check('adoption closure exact counts/claims', ac['source_count_before'] == 2348 and ac['source_count_after'] == 2349 and set(ac['selected_existing_deltas']) == {CLIENT,CAT} and ac['added_test'] == TEST and ac['unselected_2346_existing_sources_full_modes_unchanged'] and ac['runtime40_bytes_full_modes_unchanged'] and ac['head_tree_index_unchanged'] and ac['new_ids'] == 29 and ac['manual_cache_mutations'] == 0)
fb, fa, fc = [load(F / name) for name in ('before.json','after.json','closure.json')]
check('focus before adoption after exact epoch', all(fb[key] == after[key] for key in ('source','runtime','head','tree','status')))
check('focus endpoints2349/runtime40/Git/status neutral', fb == fa and len(fb['source']) == 2349 and len(fb['runtime']) == 40 and fc['logical_source'] == 2349 and fc['runtime'] == 40 and fc['all_source_runtime_bytes_fullmodes_status_head_tree_equal'])
tests = sorted(name for name in after['source'] if name.startswith('services/orchestrator/tests/test_generation_') and name.endswith('.py'))
check('eight unchanged+new generation test files focused', len(tests) == 8 and TEST in tests)
u = ['uv','run','--no-sync','--offline']
gen = 'services/orchestrator/src/orchestrator/generation'
pytest = u+['pytest','-c','pyproject.toml','--rootdir=.','--confcutdir=.','-o','addopts=','--strict-config','--strict-markers','--disable-plugin-autoload','-p','no:cacheprovider']
commands = {
    'ruff':u+['ruff','check','--config','pyproject.toml',gen,*tests],
    'format':u+['ruff','format','--check','--config','pyproject.toml',gen,*tests],
    'mypy-services':u+['mypy','--config-file','pyproject.toml','services'],
    'mypy-win32':u+['mypy','--config-file','pyproject.toml','--platform','win32',gen,*tests],
    'prettier':['pnpm','exec','prettier','--check',CAT],
    'focused-python':pytest+['--basetemp',str(F/'pytest-temp'),'-q',*tests],
    'collection':pytest+['--collect-only','-q','services/orchestrator/tests','scripts/tests'],
    'portability':u+['python','scripts/check_portability.py','--quiet'],
    'integrity':u+['python','scripts/verify.py','--suite','integrity'],
    'diff-check':['git','diff','--check'],
}
rows = load(F / 'results.json')
check('ten exact ordered command names', [r['name'] for r in rows] == list(commands) and fc['commands'] == 10 and fc['all_ten_commands_closed_zero'])
last_end = datetime.fromisoformat(ac['end_utc'])
for row in rows:
    name = row['name']
    check('exact argv/cwd:'+name, row['argv'] == commands[name] and row['cwd'] == str(R))
    check('numeric child closure:'+name, row['exit_code'] == 0 and row['reaped'] and row['pid'] == row['pgid'] and row['group'] == 'ABSENT' and row['signals'] == [] and not row['timeout'])
    start,end = datetime.fromisoformat(row['start_utc']),datetime.fromisoformat(row['end_utc'])
    check('sequential truthful UTC:'+name, last_end <= start <= end)
    last_end=end
check('focus closure after final child', datetime.fromisoformat(fc['end_utc']) >= last_end)
pylog = (F/'focused-python.log').read_text()
check('actual165 terminal pass', re.search(r'(?m)^165 passed in 0\.24s$',pylog) is not None)
collection = (F/'collection.log').read_text().splitlines()
check('actual2817 collection footer', bool(re.fullmatch(r'2817 tests collected in [0-9.]+s',collection[-1])))
actual_nodes = [line for line in collection[:-1] if line]
check('all actual IDs exact2817 unique', len(actual_nodes) == len(set(actual_nodes)) == 2817 and set(actual_nodes) == new_all)
focused_nodes = [node for node in actual_nodes if node.split('::')[0] in tests]
check('focused file inventory165 includes all29new', len(focused_nodes) == 165 and set(ids['node_ids']) <= set(focused_nodes))
check('raw strict35 default services and13Win32 output', (F/'mypy-services.log').read_text() == 'Success: no issues found in 35 source files\n' and (F/'mypy-win32.log').read_text() == 'Success: no issues found in 13 source files\n')
check('default typing not falsely Linux', '--platform' not in commands['mypy-services'] and not re.search(r'(?m)^platform\s*=',(P/'candidate/pyproject.toml').read_text()))
check('raw ruff/format/prettier/portability', (F/'ruff.log').read_text() == 'All checks passed!\n' and (F/'format.log').read_text() == '13 files already formatted\n' and 'All matched files use Prettier code style!' in (F/'prettier.log').read_text() and (F/'portability.log').read_text() == 'PASS: portability policy validated\n')
integrity=(F/'integrity.log').read_text();tail=integrity[integrity.rindex('== verification summary =='):]
check('actual scoped integrity onlyPASS', re.findall(r'(?m)^(\S+)\s+ACTIVE\s+(PASS|FAIL)\s*$',tail) == [('integrity','PASS')] and 'verification exit code: 0' in tail and (F/'diff-check.log').read_bytes() == b'')
for row in copied: check('retained source final pins:'+row['copy'], pin(Path(row['source'])) == {k:row[k] for k in ('bytes','full_mode','sha256')})
result={'verdict':'CLEAR_FINITE_CANONICAL_ADOPTION_AND_FOCUS','utc':datetime.now(UTC).isoformat(),'data_joins':len(checks),'all_checks_pass':True,'source_before':2348,'source_after':2349,'unselected_existing_preserved':2346,'runtime_files_preserved':40,'old_catalog_ids_preserved':2788,'additive_new_ids':29,'actual_collection':2817,'windows_common_catalog':2815,'actual_focused_passed':165,'actual_focused_seconds':0.24,'actual_commands':10,'numeric_children_reaped_groups_ABSENT':10,'typing_scope':{'services':'default platform,35files','generation_and_tests':'explicitwin32,13files','Linux_target_receipt':False},'adoption_HEAD_tree_index_neutral':True,'focus_source_runtime_HEAD_tree_status_neutral':True,'focus_index_snapshot_present':False,'new_full_or_Windows_native_or_CI_PASS_inferred':False,'scope':'Closed historical adoption/focus snapshots only; no source re-author/replay or later canonical neutrality claim; original f3 CI remains separate.'}
(H/'DATA.json').write_text(json.dumps({'result':result,'checks':checks},indent=2)+'\n')
print(json.dumps(result))
