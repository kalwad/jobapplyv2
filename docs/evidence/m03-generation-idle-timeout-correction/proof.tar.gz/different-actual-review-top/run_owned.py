from pathlib import Path
from datetime import UTC, datetime
import hashlib,json,os,subprocess,sys,time
H=Path(__file__).resolve().parent
label=sys.argv[1];assert label.isascii() and label.replace('-','').isalnum()
Q=H/'qa'/label;Q.mkdir(parents=True,exist_ok=False)
source=H/'audit_actual.py';source_pin=hashlib.sha256(source.read_bytes()).hexdigest()
start=datetime.now(UTC).isoformat();tick=time.monotonic()
args=['/Users/tanishkalwad/.local/share/uv/python/cpython-3.12.13-macos-aarch64-none/bin/python3.12','-I','-S','-B',str(source)]
with (Q/'stdout.log').open('wb') as out,(Q/'stderr.log').open('wb') as err:
 child=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True,cwd=H);code=child.wait(timeout=55)
try:os.killpg(child.pid,0);group='PRESENT'
except ProcessLookupError:group='ABSENT'
row={'argv':args,'pid':child.pid,'pgid':child.pid,'exit_code':code,'reaped':child.returncode is not None,'group_after_wait':group,'signals':[],'timeouts':[],'start_utc':start,'end_utc':datetime.now(UTC).isoformat(),'seconds':time.monotonic()-tick,'own_source_sha256_before':source_pin,'own_source_sha256_after':hashlib.sha256(source.read_bytes()).hexdigest(),'scope':'Owned inert reviewer only; no subject tests/imports/native/model/network or canonical mutation.'}
(Q/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row));assert group=='ABSENT' and row['reaped'] and row['own_source_sha256_before']==row['own_source_sha256_after'];raise SystemExit(code)
