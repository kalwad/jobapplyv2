"""Independent finite source/data review and owned synthetic reproduction."""
from pathlib import Path, PurePosixPath
import ast, asyncio, datetime, hashlib, json, os, re, signal, stat, subprocess, tarfile, time

E=Path(__file__).parent
R=Path('/Users/tanishkalwad/jobapplyv2')
P=E/'generation-idle-timeout-state-correction/v1'
O=E/'generation-idle-timeout-state-independent-review/v1'
O.mkdir(parents=True,exist_ok=False)
(O/'executed-review.py').write_bytes(Path(__file__).read_bytes())
checks=[]; receipts=[]
def sha(body):return hashlib.sha256(body).hexdigest()
def row(path):
    s=path.lstat();assert stat.S_ISREG(s.st_mode) and not path.is_symlink()
    body=path.read_bytes();return {'bytes':len(body),'full_mode':s.st_mode,'sha256':sha(body)}
def dump(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def check(label,condition):
    assert condition,label
    checks.append(label)
for name,pin in {
    'SOURCE.json':'471d5e158acd818506ab65dbcd920bcf9029a7c4b888450c8ead6c4a5ac67466',
    'HANDOFF.json':'99f1567338f5afe3aa4da4223f2326a993d3be26da9bc51310c7ba91eac0a217',
    'manifest.json':'ca4acc7c753234d75b7e83d9067a0190a98d29dc0cde7149d322228f20eb4d20',
    'proof.tar.gz':'9fbc0ca20f55e555f3722690d2c3c86a0d4746cfa587e5b4d4d334333f4fcbbd',
}.items():check('fixed '+name,sha((P/name).read_bytes())==pin)
source=json.loads((P/'SOURCE.json').read_bytes())['files']
for name,expected in source.items():
    q=PurePosixPath(name)
    check('safe source '+name,bool(name) and not q.is_absolute() and '..' not in q.parts and '\\' not in name and q.as_posix()==name)
    check('source bytes/mode '+name,row(P/name)==expected)
with tarfile.open(P/'proof.tar.gz','r:gz') as archive:
    members=archive.getmembers()
    check('exact regular archive',len(members)==274 and len({m.name for m in members})==274 and {m.name for m in members}==set(source)|{'SOURCE.json'} and all(m.isfile() for m in members))
    for member in members:
        check('archive '+member.name,archive.extractfile(member).read()==(P/member.name).read_bytes() and (stat.S_IFREG|member.mode)==(P/member.name).stat().st_mode)
before_names=[n.removeprefix('before/') for n in source if n.startswith('before/')]
def canonical():
    files={n:row(R/n) for n in before_names}
    runtime={p.relative_to(R/'apps/desktop/src-tauri/runtime-payload').as_posix():row(p) for p in (R/'apps/desktop/src-tauri/runtime-payload').rglob('*') if p.is_file()}
    return {'selected_sources':files,'runtime':runtime,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=R,text=True),'index':row(R/'.git/index')}
canonical_before=canonical();dump(O/'canonical-before.json',canonical_before)
check('exact frozen canonical head',canonical_before['head']=='f3a1c6f7ad62161c682d92f842003fd018c5eec1' and canonical_before['tree']=='298ac93fe910d8917d3863d48e5f6c2621bf3f17' and canonical_before['status']=='')
check('selected canonical source count',len(before_names)==15 and len(canonical_before['runtime'])==40)
client='services/orchestrator/src/orchestrator/generation/client.py'
newtest='services/orchestrator/tests/test_generation_early_idle_timeout.py'
handoff=json.loads((P/'HANDOFF.json').read_bytes())
check('only two afterimages',set(handoff['canonical_afterimages_only'])=={client,newtest})
for name in before_names:
    check('actual canonical preimage '+name,row(R/name)==row(P/'before'/name))
    if name!=client:check('unchanged candidate '+name,(P/'candidate'/name).read_bytes()==(R/name).read_bytes() and row(P/'candidate'/name)==row(R/name))
check('new test absent canonical',not (R/newtest).exists())
shape=lambda n:ast.dump(n,include_attributes=False)
old=ast.parse((R/client).read_bytes());new=ast.parse((P/'candidate'/client).read_bytes())
old_decl={n.name:n for n in old.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
new_decl={n.name:n for n in new.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
check('only helper declaration added',set(new_decl)-set(old_decl)=={'_admit_idle'} and not set(old_decl)-set(new_decl))
for name in old_decl:
    if name!='_consume':check('unchanged declaration '+name,shape(old_decl[name])==shape(new_decl[name]))
check('imports/constants exact',[shape(n) for n in old.body if not isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))]==[shape(n) for n in new.body if not isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))])
ids=json.loads((P/'new-test-node-ids.json').read_bytes())['node_ids']
catalog=json.loads((R/'scripts/python-test-inventory.v1.json').read_bytes())
check('exact additive IDs',ids==sorted(set(ids)) and len(ids)==29 and ids==handoff['additive_test_node_ids'] and not set(ids)&set(catalog['common']['node_ids']) and catalog['common']['count']==2786 and len(catalog['posix_only_node_ids'])==2)
old_test_names=[n for n in before_names if '/tests/' in n]
check('seven unchanged old tests',len(old_test_names)==7)
for name in old_test_names:check('old test exact '+name,row(P/'before'/name)==row(P/'candidate'/name)==row(R/name))
qa=[n for n in source if n.endswith('/receipt.json')]
check('twenty two retained QA receipts',len(qa)==22)
for name in qa:
    receipt=json.loads((P/name).read_bytes());base=(P/name).parent
    check('closed custody '+name,receipt['reaped'] and receipt['group_after_wait']=='ABSENT' and receipt['signals']==[] and receipt['stop'] is None and receipt['exit_code']==receipt['expected_exit'] and receipt['finite_canonical_endpoint_equal'] and receipt['source_endpoint_equal'])
    for stream in ('stdout','stderr'):check('raw '+name+' '+stream,row(base/stream)==receipt[stream])
    check('retained runner '+name,any(v==receipt['runner'] for v in source.values()))
for phase,expected in {'sealed-final-pytest':'165 passed','exact-old-source':'9 failed, 156 passed','exact-final-no-expired-guard':'9 failed, 156 passed','exact-final-no-raw-expired-admission':'3 failed, 162 passed','exact-final-no-timeout-close-priority':'3 failed, 162 passed'}.items():
    check('actual retained summary '+phase,expected in (P/'quality'/phase/'stdout').read_text())

work=O/'candidate';work.mkdir()
for name in source:
    if name.startswith('candidate/'):
        dest=work/name.removeprefix('candidate/');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((P/name).read_bytes());dest.chmod(stat.S_IMODE((P/name).stat().st_mode))
launcher='''from pathlib import Path
import asyncio,hashlib,json,sys
import orchestrator.generation.client as client
import pytest
p=Path(client.__file__).resolve()
assert p==Path.cwd()/'services/orchestrator/src/orchestrator/generation/client.py'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='977e075952198cd3344ab61bb6a2dbd8f0625a8f175016371263832266c46a1e'
helper_checks=[]
original=client._monotonic
class Active:
    def __init__(self,cancel):self.cancel=cancel
    def require_live(self):
        helper_checks.append('active')
        if self.cancel:raise asyncio.CancelledError('independent pending cancellation')
class Timer:
    def __init__(self,expired):self.flag=expired;self.calls=0
    def expired(self):self.calls+=1;return self.flag
for sampled in (0.0,1.0,2.0):
    for expired in (False,True):
        for cancel in (False,True):
            client._monotonic=lambda:sampled
            timer=Timer(expired)
            try:client._admit_idle(1.0,timer,Active(cancel));outcome='live'
            except asyncio.CancelledError:outcome='cancelled'
            except client.GenerationFailure as error:assert error.code is client.ErrorCode.TIMEOUT;outcome='timeout'
            assert outcome==('cancelled' if cancel else 'timeout' if sampled>=1.0 or expired else 'live')
            assert timer.calls==(0 if cancel or sampled>=1.0 else 1)
client._monotonic=original
assert len(helper_checks)==12
print('INDEPENDENT_SOURCE_AND_12_ADMISSION_ORDER_CONTROLS_PASS',flush=True)
args=['-c','pyproject.toml','--rootdir=.','--confcutdir=.','-o','addopts=','--strict-config','--strict-markers','--disable-plugin-autoload','-p','no:cacheprovider','--basetemp',str(Path.cwd().parent/'pytest-temp'),'-q',*sys.argv[1:],'services/orchestrator/tests']
raise SystemExit(pytest.main(args))
'''
(O/'run-tests.py').write_text(launcher)
env=dict(os.environ);env.update(PYTHONPATH=str(work/'services/orchestrator/src')+':'+str(work),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
def run(name,extra):
    args=[str(R/'.venv/bin/python'),'-B',str(O/'run-tests.py'),*extra];start=datetime.datetime.now(datetime.UTC).isoformat();tick=time.monotonic();signals=[];expired=False
    with (O/(name+'.stdout')).open('xb') as out,(O/(name+'.stderr')).open('xb') as err:
        child=subprocess.Popen(args,cwd=work,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
        try:code=child.wait(timeout=60)
        except subprocess.TimeoutExpired:
            expired=True
            if child.poll() is None:
                try:os.killpg(child.pid,signal.SIGTERM);signals.append('SIGTERM')
                except ProcessLookupError:pass
            try:code=child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                if child.poll() is None:
                    try:os.killpg(child.pid,signal.SIGKILL);signals.append('SIGKILL')
                    except ProcessLookupError:pass
                code=child.wait(timeout=5)
    try:os.killpg(child.pid,0);group='PRESENT'
    except ProcessLookupError:group='ABSENT'
    receipt={'name':name,'argv':args,'cwd':str(work),'start_utc':start,'end_utc':datetime.datetime.now(datetime.UTC).isoformat(),'elapsed_seconds':time.monotonic()-tick,'pid':child.pid,'pgid':child.pid,'exit_code':code,'reaped':child.returncode is not None,'group_after_wait':group,'signals':signals,'timeout':expired,'stdout':row(O/(name+'.stdout')),'stderr':row(O/(name+'.stderr'))}
    receipts.append(receipt);dump(O/'receipts.json',receipts)
    check('fresh root owned '+name,code==0 and not expired and group=='ABSENT' and not signals)
run('generation-tests',[])
check('fresh exact 165 passes',re.search(r'^165 passed in ',(O/'generation-tests.stdout').read_text(),re.M) is not None)
run('generation-collection',['--collect-only'])
collected=sorted(line for line in (O/'generation-collection.stdout').read_text().splitlines() if line.startswith('services/orchestrator/tests/') and '::' in line)
old_ids=sorted(n for n in catalog['common']['node_ids'] if any(n.startswith(p+'::') for p in old_test_names))
check('fresh exact 136 old plus 29 IDs',len(old_ids)==136 and len(collected)==165 and collected==sorted(old_ids+ids))
canonical_after=canonical();dump(O/'canonical-after.json',canonical_after)
check('selected source/runtime40/Git/index endpoints neutral',canonical_before==canonical_after)
for name,expected in source.items():check('parent unchanged '+name,row(P/name)==expected)
report={'verdict':'CLEAR_SCOPED_IDLE_TIMEOUT_SOURCE_AND_SYNTHETIC_DATA','checks_passed':len(checks),'checks':checks,'fresh_generation_passes':165,'fresh_helper_controls_per_child':12,'fresh_children':len(receipts),'old_tests_exact':136,'additive_node_ids':29,'source_sha256':'471d5e158acd818506ab65dbcd920bcf9029a7c4b888450c8ead6c4a5ac67466','after_client_sha256':sha((P/'candidate'/client).read_bytes()),'scope':'Different finite source/data audit and fresh owned synthetic generation/loopback tests. Selected15 canonical sources/runtime40/Git/index endpoints only; not full canonical epoch. No native credential/model/user-daemon/default activation/Windows or historical clock evidence. Current canonical full remains separately in progress. Root did not author correction source or new regression tests.'}
dump(O/'REVIEW.json',report)
print(json.dumps({k:report[k] for k in ('verdict','checks_passed','fresh_generation_passes','fresh_children','additive_node_ids')}),flush=True)
