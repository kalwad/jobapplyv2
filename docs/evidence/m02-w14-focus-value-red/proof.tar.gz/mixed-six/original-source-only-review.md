# Focused independent runtime review at 918dedb

Reviewed 2026-10-16 22:08 UTC at exact HEAD `918dedb3fc379e1fc19cf6ef54bbefa1110b35d3`. The active checkout was clean before and after inspection. This is a source-only, read-only review. No tests, builds, browser sessions, declarations, or root files were changed or executed. It supplements the running platform CI; it is not a Gate A/W15 approval or an externally executed comparison.

## Finding: HIGH — undo can overwrite a newer value introduced during its final awaited re-resolution

Primary location: `apps/extension/src/driver-engine.ts:1421` (the check at `1359–1388` expires before the awaited re-resolution; the mutation follows at `1509`).

The engine observes the current value and compares it to `record.intendedObservation` once at lines 1359–1388. It then awaits `resolveFieldTarget` again at line 1421. That resolution builds a descriptor through multiple awaited WebCrypto digests (`field-scanner.ts:934–1028`), so a page task or user input can change the native value while it is pending. Descriptor identity does not include the current value: `attributeEvidence` at `field-scanner.ts:901–916` uses control kind, tag, role, type, name, autocomplete, placeholder, multiline and multiple only.

After the await, the action checks at lines 1453–1467 require unique driver, unchanged approved description, current semantic target, visibility and enabled state. They do not compare the current value to the value whose equality authorized undo. `driverContext.mutate` at lines 236–299 also checks ownership/option/generation/index/actionability, with no current-value predicate. For a text input, `textDriver.applyUndo` calls `writeText(host, payload, context)` (`text-like-drivers.ts:135–139`), and its final synchronous check after focus (`78–96`) likewise checks index/actionability only before setting the old payload.

Concrete trigger inferred from that complete source path:

1. Execute a text transaction with initial value `Prior`, intended value `Synthetic`, and retain undo.
2. Start undo. Allow its first current observation to see `Synthetic` and pass the equality condition.
3. During the second descriptor resolution's awaited digest, change the same live input's value to `Newer user/site edit` without changing ownership, attributes, option meaning, or topology. A native `.value` assignment can do this without a MutationObserver record; a normal user edit likewise need not change the value attribute.
4. Complete the descriptor resolution. Its address/current-target checks pass because current value is not address identity.
5. `applyUndo` writes `Prior`, losing the newer value. If the resulting field is accepted, the later post-write observations can publish `VERIFIED`.

The final native-property/publication witness at lines 1586–1590 is captured only after `applyUndo` has overwritten the newer value. It correctly protects the restored observation against *later* drift, but cannot reject the preceding lost-update race. The current `extension-w14-independent-extra.spec.ts` eventless undo probe pauses the final result hash after restoration, and the six native-validity probes likewise target final publication. They do not cover the pre-restoration race.

Requested correction: carry a synchronous primitive current-value/driver observation witness from the observation whose match authorizes undo into the first restoration mutation, and refuse that mutation if the value has drifted. Any awaited observation/re-resolution and synchronous focus handler must not expire the last value-preservation check. Keep existing identity/description/options/actionability/final-publication fences. Do not merely re-observe asynchronously and leave another gap before the native write. Repeater/native-editor witnesses need the same semantics where undo can overwrite a newer edit.

Suggested deterministic actual-MV3 regression, not executed in this review: instrument the second undo descriptor's digest after the first value observation has completed; edit the native value without events, release the digest, and assert the newer value is preserved with zero additional extension-native mutation and no `VERIFIED` undo. Pair this negative with an unchanged successful undo. A second variant can introduce drift in a synchronous focus handler to cover the final setter boundary.

Status: source-substantiated actionable finding, **not yet an executed reproduction or a native-platform result**. Root should reproduce and independently review a correction before closing it.

## Other inspected boundaries

No further substantiated finding is asserted here. The KI-0091 correction snapshots scalar `willValidate`, `validity.valid`, and `validationMessage`, includes the driver's native acceptance elements, and compares them synchronously after the result hashing. Existing value/checked/file/select properties and extra driver observation witnesses remain present. Execute and undo enforce the final DOM evidence revision. W11 freshly observes retained verified transactions, retains the native property witnesses through inventory hashing, and rejects changed evidence/topology before readiness publication. These observations establish only this limited source-review scope; they do not prove all runtime races absent or approve any package/gate.

## Inspected source bindings

| File | SHA-256 |
| --- | --- |
| apps/extension/src/driver-engine.ts | 749b00ac70478f94d8e78779e39f973475ba8d6ee003cb9a68ad1e3b623f2382 |
| apps/extension/src/drivers/driver-dom.ts | 8256c4ec3893d3f3e9671715c3f5f5b736f59f6600cdbaeb9d520d2068d695bc |
| apps/extension/src/drivers/text-like-drivers.ts | d39682b692f372d91279a130b73b614afdde6bb1ef0da62f06fb6a7e63e5c316 |
| apps/extension/src/dynamic-engine.ts | 92bd0ea7ece96eee82c879e274cf2c7a2e8b5f048d0a0f603c169c1ed283d125 |
| apps/extension/src/field-scanner.ts | 15d1dd3bc927de976539440511341fd6877e7c113fbbc093e54de21b9b6b6a5a |
| e2e/extension/extension-w14-native-validity.spec.ts | b0c3bcb6b93eee78ad1a45f001f1b33cead19e2c703093b515f9f34f037fed33 |
