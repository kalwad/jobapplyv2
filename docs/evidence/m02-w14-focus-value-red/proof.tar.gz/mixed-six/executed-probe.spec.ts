/** Independent actual-MV3 undo current-value preservation probes. */
import { installW14NativeWitness } from "./support/autofill-w14-native-witness.ts";
import { test, expect } from "./support/extension-test.ts";
import {
  openHarness,
  setFixture,
  scanFrames,
  foundTopFrame,
  descriptorByLabel,
  dynExecute,
  buildTransaction,
  runtimeMessage,
} from "./support/research-harness.ts";
import {
  buildApprovedRecordSet,
  resolveFieldDecision,
  stableSemanticId,
} from "../../packages/form-engine/src/index.ts";
import {
  buildUndoTabRequest,
  parseUndoTabResult,
} from "../../apps/extension/src/driver-protocol.ts";
import {
  firstDriverOutcome,
  recordIndependentEvidence as record,
} from "./support/independent-w14-evidence.ts";

function installSecondDescriptorPause(prefix: string): void {
  const host = globalThis as unknown as Record<string, unknown>;
  const subtle = crypto.subtle;
  const prior = Object.getOwnPropertyDescriptor(subtle, "digest");
  const nativeDigest = subtle.digest.bind(subtle);
  let release: (() => void) | undefined;
  const wait = new Promise<void>((resolve) => {
    release = resolve;
  });
  const gate = {
    reached: false,
    matchingCalls: 0,
    seeds: [] as string[],
    stack: "",
    release() {
      release?.();
    },
    restore() {
      release?.();
      if (prior === undefined) Reflect.deleteProperty(subtle, "digest");
      else Object.defineProperty(subtle, "digest", prior);
      Reflect.deleteProperty(host, "__JAPP_UNDO_VALUE_DESCRIPTOR_PAUSE__");
    },
  };
  host.__JAPP_UNDO_VALUE_DESCRIPTOR_PAUSE__ = gate;
  Object.defineProperty(subtle, "digest", {
    configurable: true,
    writable: true,
    value(
      algorithm: AlgorithmIdentifier,
      data: BufferSource,
    ): Promise<ArrayBuffer> {
      const native = nativeDigest(algorithm, data);
      const seed = new TextDecoder().decode(data);
      if (seed === prefix) {
        gate.matchingCalls += 1;
        gate.seeds.push(seed);
        if (gate.matchingCalls === 2) {
          gate.reached = true;
          gate.stack = new Error("second undo descriptor pause").stack ?? "";
          return native.then(async (digest) => {
            await wait;
            return digest;
          });
        }
      }
      return native;
    },
  });
}

const controls = [
  {
    type: "text",
    label: "First name",
    concept: "FIRST_NAME",
    prior: "Prior",
    intended: "Synthetic",
    newer: "Newer user edit",
  },
  {
    type: "date",
    label: "Earliest start date",
    concept: "EARLIEST_START_DATE",
    prior: "2020-01-01",
    intended: "2021-02-03",
    newer: "2022-03-04",
  },
] as const;

for (const control of controls) {
  for (const drift of [
    "unchanged",
    "second-descriptor-await",
    "focus-handler",
  ] as const) {
    test(`independent undo ${control.type} ${drift} preserves current value`, async ({
      extensionContext,
      extensionId,
      serviceWorker,
    }, info) => {
      test.setTimeout(45_000);
      const h = await openHarness(
        extensionContext,
        extensionId,
        serviceWorker,
        "/native/",
      );
      const witness = await installW14NativeWitness(
        extensionContext,
        h.page,
        extensionId,
      );
      let pending: ReturnType<typeof runtimeMessage> | undefined;
      try {
        await setFixture(
          h,
          `<form data-japp-application-root="true"><label for="target">${control.label}</label><input id="target" name="${control.concept}" type="${control.type}" aria-invalid="false" value="${control.prior}" required></form>`,
        );
        await h.page.evaluate(() => {
          const state = { input: 0, change: 0, focus: 0, blur: 0 };
          (window as unknown as Record<string, unknown>).__undoEventMeter =
            state;
          const input = document.querySelector("input");
          if (input === null) throw new Error("input absent");
          for (const name of ["input", "change", "focus", "blur"] as const)
            input.addEventListener(name, () => {
              state[name] += 1;
            });
        });
        const top = foundTopFrame(await scanFrames(h));
        const field = descriptorByLabel(top.descriptors, control.label);
        const seed = `independent-undo-race-${control.type}-${drift}`;
        const approval = await resolveFieldDecision({
          descriptor: field,
          records: buildApprovedRecordSet([
            {
              recordId: await stableSemanticId("record", seed),
              concept: control.concept,
              policy: "FILL_FROM_EXPLICIT_RECORD",
              confirmation: { state: "MISSING" },
              valueConfidence: 1,
            },
          ]),
          correlationId: await stableSemanticId("cor", seed),
        });
        if (
          approval.status !== "RESOLVED" ||
          approval.resolution.decision.final_decision !== "FILL"
        )
          throw new Error("actual W09 did not authorize fixture");
        const intended =
          control.type === "date"
            ? { kind: "DATE" as const, iso_date: control.intended }
            : { kind: "TEXT" as const, text: control.intended };
        const tx = await buildTransaction(
          field,
          intended,
          approval.resolution.decision,
          seed,
        );
        const execution = await dynExecute(h, [tx]);
        expect(firstDriverOutcome(execution)).toBe("VERIFIED");
        expect(await h.page.locator("#target").inputValue()).toBe(
          control.intended,
        );
        const beforeUndoNative = await witness.snapshot();
        const beforeUndoEvents = await h.page.evaluate(
          () => (window as unknown as Record<string, unknown>).__undoEventMeter,
        );
        if (drift === "second-descriptor-await") {
          await witness.session.send("Runtime.evaluate", {
            contextId: witness.contextId,
            expression: `(${installSecondDescriptorPause.toString()})(${JSON.stringify(`accessible-name-v1\0${control.label}`)})`,
          });
        } else if (drift === "focus-handler") {
          await h.page.evaluate((newer) => {
            const input = document.querySelector("input");
            if (input === null) throw new Error("input absent");
            input.addEventListener(
              "focus",
              () => {
                const before = input.value;
                const observer = new MutationObserver(() => undefined);
                observer.observe(document, {
                  subtree: true,
                  childList: true,
                  attributes: true,
                  characterData: true,
                });
                input.value = newer;
                const mutationRecords = observer.takeRecords().length;
                observer.disconnect();
                (window as unknown as Record<string, unknown>).__undoDrift = {
                  before,
                  after: input.value,
                  mutationRecords,
                  source: "page-world synchronous focus handler",
                };
              },
              { once: true },
            );
          }, control.newer);
        }
        pending = runtimeMessage(
          h.controller,
          buildUndoTabRequest(seed, h.tabId, {
            transaction_id: tx.transaction_id,
            address: tx.address,
            settle: { budget_ms: 75 },
          }),
        );
        let pause: unknown = null;
        if (drift === "second-descriptor-await") {
          await expect
            .poll(
              async () => {
                const response = await witness.session.send(
                  "Runtime.evaluate",
                  {
                    contextId: witness.contextId,
                    expression:
                      "globalThis.__JAPP_UNDO_VALUE_DESCRIPTOR_PAUSE__?.reached === true",
                    returnByValue: true,
                  },
                );
                return response.result.value;
              },
              { timeout: 5000 },
            )
            .toBe(true);
          await h.page.evaluate((newer) => {
            const input = document.querySelector("input");
            if (input === null) throw new Error("input absent");
            const before = input.value;
            const observer = new MutationObserver(() => undefined);
            observer.observe(document, {
              subtree: true,
              childList: true,
              attributes: true,
              characterData: true,
            });
            input.value = newer;
            const mutationRecords = observer.takeRecords().length;
            observer.disconnect();
            (window as unknown as Record<string, unknown>).__undoDrift = {
              before,
              after: input.value,
              mutationRecords,
              source: "page-world assignment during second descriptor digest",
            };
          }, control.newer);
          const response = await witness.session.send("Runtime.evaluate", {
            contextId: witness.contextId,
            expression:
              "({ reached: globalThis.__JAPP_UNDO_VALUE_DESCRIPTOR_PAUSE__.reached, matchingCalls: globalThis.__JAPP_UNDO_VALUE_DESCRIPTOR_PAUSE__.matchingCalls, seeds: globalThis.__JAPP_UNDO_VALUE_DESCRIPTOR_PAUSE__.seeds, stack: globalThis.__JAPP_UNDO_VALUE_DESCRIPTOR_PAUSE__.stack })",
            returnByValue: true,
          });
          pause = response.result.value;
          await witness.session.send("Runtime.evaluate", {
            contextId: witness.contextId,
            expression:
              "globalThis.__JAPP_UNDO_VALUE_DESCRIPTOR_PAUSE__.release()",
          });
        }
        const undo = parseUndoTabResult(await pending);
        pending = undefined;
        const physical = await h.page.evaluate(() => ({
          value: document.querySelector("input")?.value,
          drift:
            (window as unknown as Record<string, unknown>).__undoDrift ?? null,
          events: (window as unknown as Record<string, unknown>)
            .__undoEventMeter,
        }));
        const afterUndoNative = await witness.snapshot();
        await record(info, seed, {
          control,
          drift,
          field,
          tx,
          execution,
          undo,
          pause,
          physical,
          beforeUndoEvents,
          beforeUndoNative,
          afterUndoNative,
          browserVersion: extensionContext.browser()?.version(),
          serviceWorkerUrl: serviceWorker.url(),
        });
        expect(undo?.outcome.status).toBe("COMPLETED");
        if (undo?.outcome.status !== "COMPLETED")
          throw new Error("undo response absent");
        if (drift === "unchanged") {
          expect(undo.outcome.result.outcome).toBe("VERIFIED");
          expect(physical.value).toBe(control.prior);
          expect(
            afterUndoNative.native_mutation_count -
              beforeUndoNative.native_mutation_count,
          ).toBe(1);
        } else {
          expect(physical.drift).toMatchObject({
            before: control.intended,
            after: control.newer,
            mutationRecords: 0,
          });
          expect
            .soft(physical.value, "undo must preserve the newer edit")
            .toBe(control.newer);
          expect
            .soft(
              afterUndoNative.native_mutation_count -
                beforeUndoNative.native_mutation_count,
              "undo must not write over the newer edit",
            )
            .toBe(0);
          expect.soft(undo.outcome.result.outcome).not.toBe("VERIFIED");
        }
      } finally {
        await witness.session.send("Runtime.evaluate", {
          contextId: witness.contextId,
          expression:
            "globalThis.__JAPP_UNDO_VALUE_DESCRIPTOR_PAUSE__?.restore()",
        });
        await pending?.catch(() => undefined);
        await witness.dispose();
        await h.page.close();
        await h.controller.close();
      }
    });
  }
}
