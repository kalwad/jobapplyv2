# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w14-undo-value-race-independent.spec.ts >> independent undo text second-descriptor-await preserves current value
- Location: e2e/extension/extension-w14-undo-value-race-independent.spec.ts:104:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Test source

```ts
  138 |         const top = foundTopFrame(await scanFrames(h));
  139 |         const field = descriptorByLabel(top.descriptors, control.label);
  140 |         const seed = `independent-undo-race-${control.type}-${drift}`;
  141 |         const approval = await resolveFieldDecision({
  142 |           descriptor: field,
  143 |           records: buildApprovedRecordSet([
  144 |             {
  145 |               recordId: await stableSemanticId("record", seed),
  146 |               concept: control.concept,
  147 |               policy: "FILL_FROM_EXPLICIT_RECORD",
  148 |               confirmation: { state: "MISSING" },
  149 |               valueConfidence: 1,
  150 |             },
  151 |           ]),
  152 |           correlationId: await stableSemanticId("cor", seed),
  153 |         });
  154 |         if (
  155 |           approval.status !== "RESOLVED" ||
  156 |           approval.resolution.decision.final_decision !== "FILL"
  157 |         )
  158 |           throw new Error("actual W09 did not authorize fixture");
  159 |         const intended =
  160 |           control.type === "date"
  161 |             ? { kind: "DATE" as const, iso_date: control.intended }
  162 |             : { kind: "TEXT" as const, text: control.intended };
  163 |         const tx = await buildTransaction(
  164 |           field,
  165 |           intended,
  166 |           approval.resolution.decision,
  167 |           seed,
  168 |         );
  169 |         const execution = await dynExecute(h, [tx]);
  170 |         expect(firstDriverOutcome(execution)).toBe("VERIFIED");
  171 |         expect(await h.page.locator("#target").inputValue()).toBe(
  172 |           control.intended,
  173 |         );
  174 |         const beforeUndoNative = await witness.snapshot();
  175 |         const beforeUndoEvents = await h.page.evaluate(
  176 |           () => (window as unknown as Record<string, unknown>).__undoEventMeter,
  177 |         );
  178 |         if (drift === "second-descriptor-await") {
  179 |           await witness.session.send("Runtime.evaluate", {
  180 |             contextId: witness.contextId,
  181 |             expression: `(${installSecondDescriptorPause.toString()})(${JSON.stringify(`accessible-name-v1\0${control.label}`)})`,
  182 |           });
  183 |         } else if (drift === "focus-handler") {
  184 |           await h.page.evaluate((newer) => {
  185 |             const input = document.querySelector("input");
  186 |             if (input === null) throw new Error("input absent");
  187 |             input.addEventListener(
  188 |               "focus",
  189 |               () => {
  190 |                 const before = input.value;
  191 |                 const observer = new MutationObserver(() => undefined);
  192 |                 observer.observe(document, {
  193 |                   subtree: true,
  194 |                   childList: true,
  195 |                   attributes: true,
  196 |                   characterData: true,
  197 |                 });
  198 |                 input.value = newer;
  199 |                 const mutationRecords = observer.takeRecords().length;
  200 |                 observer.disconnect();
  201 |                 (window as unknown as Record<string, unknown>).__undoDrift = {
  202 |                   before,
  203 |                   after: input.value,
  204 |                   mutationRecords,
  205 |                   source: "page-world synchronous focus handler",
  206 |                 };
  207 |               },
  208 |               { once: true },
  209 |             );
  210 |           }, control.newer);
  211 |         }
  212 |         pending = runtimeMessage(
  213 |           h.controller,
  214 |           buildUndoTabRequest(seed, h.tabId, {
  215 |             transaction_id: tx.transaction_id,
  216 |             address: tx.address,
  217 |             settle: { budget_ms: 75 },
  218 |           }),
  219 |         );
  220 |         let pause: unknown = null;
  221 |         if (drift === "second-descriptor-await") {
  222 |           await expect
  223 |             .poll(
  224 |               async () => {
  225 |                 const response = await witness.session.send(
  226 |                   "Runtime.evaluate",
  227 |                   {
  228 |                     contextId: witness.contextId,
  229 |                     expression:
  230 |                       "globalThis.__JAPP_UNDO_VALUE_DESCRIPTOR_PAUSE__?.reached === true",
  231 |                     returnByValue: true,
  232 |                   },
  233 |                 );
  234 |                 return response.result.value;
  235 |               },
  236 |               { timeout: 5000 },
  237 |             )
> 238 |             .toBe(true);
      |              ^ Error: expect(received).toBe(expected) // Object.is equality
  239 |           await h.page.evaluate((newer) => {
  240 |             const input = document.querySelector("input");
  241 |             if (input === null) throw new Error("input absent");
  242 |             const before = input.value;
  243 |             const observer = new MutationObserver(() => undefined);
  244 |             observer.observe(document, {
  245 |               subtree: true,
  246 |               childList: true,
  247 |               attributes: true,
  248 |               characterData: true,
  249 |             });
  250 |             input.value = newer;
  251 |             const mutationRecords = observer.takeRecords().length;
  252 |             observer.disconnect();
  253 |             (window as unknown as Record<string, unknown>).__undoDrift = {
  254 |               before,
  255 |               after: input.value,
  256 |               mutationRecords,
  257 |               source: "page-world assignment during second descriptor digest",
  258 |             };
  259 |           }, control.newer);
  260 |           const response = await witness.session.send("Runtime.evaluate", {
  261 |             contextId: witness.contextId,
  262 |             expression:
  263 |               "({ reached: globalThis.__JAPP_UNDO_VALUE_DESCRIPTOR_PAUSE__.reached, matchingCalls: globalThis.__JAPP_UNDO_VALUE_DESCRIPTOR_PAUSE__.matchingCalls, seeds: globalThis.__JAPP_UNDO_VALUE_DESCRIPTOR_PAUSE__.seeds, stack: globalThis.__JAPP_UNDO_VALUE_DESCRIPTOR_PAUSE__.stack })",
  264 |             returnByValue: true,
  265 |           });
  266 |           pause = response.result.value;
  267 |           await witness.session.send("Runtime.evaluate", {
  268 |             contextId: witness.contextId,
  269 |             expression:
  270 |               "globalThis.__JAPP_UNDO_VALUE_DESCRIPTOR_PAUSE__.release()",
  271 |           });
  272 |         }
  273 |         const undo = parseUndoTabResult(await pending);
  274 |         pending = undefined;
  275 |         const physical = await h.page.evaluate(() => ({
  276 |           value: document.querySelector("input")?.value,
  277 |           drift:
  278 |             (window as unknown as Record<string, unknown>).__undoDrift ?? null,
  279 |           events: (window as unknown as Record<string, unknown>)
  280 |             .__undoEventMeter,
  281 |         }));
  282 |         const afterUndoNative = await witness.snapshot();
  283 |         await record(info, seed, {
  284 |           control,
  285 |           drift,
  286 |           field,
  287 |           tx,
  288 |           execution,
  289 |           undo,
  290 |           pause,
  291 |           physical,
  292 |           beforeUndoEvents,
  293 |           beforeUndoNative,
  294 |           afterUndoNative,
  295 |           browserVersion: extensionContext.browser()?.version(),
  296 |           serviceWorkerUrl: serviceWorker.url(),
  297 |         });
  298 |         expect(undo?.outcome.status).toBe("COMPLETED");
  299 |         if (undo?.outcome.status !== "COMPLETED")
  300 |           throw new Error("undo response absent");
  301 |         if (drift === "unchanged") {
  302 |           expect(undo.outcome.result.outcome).toBe("VERIFIED");
  303 |           expect(physical.value).toBe(control.prior);
  304 |           expect(
  305 |             afterUndoNative.native_mutation_count -
  306 |               beforeUndoNative.native_mutation_count,
  307 |           ).toBe(1);
  308 |         } else {
  309 |           expect(physical.drift).toMatchObject({
  310 |             before: control.intended,
  311 |             after: control.newer,
  312 |             mutationRecords: 0,
  313 |           });
  314 |           expect
  315 |             .soft(physical.value, "undo must preserve the newer edit")
  316 |             .toBe(control.newer);
  317 |           expect
  318 |             .soft(
  319 |               afterUndoNative.native_mutation_count -
  320 |                 beforeUndoNative.native_mutation_count,
  321 |               "undo must not write over the newer edit",
  322 |             )
  323 |             .toBe(0);
  324 |           expect.soft(undo.outcome.result.outcome).not.toBe("VERIFIED");
  325 |         }
  326 |       } finally {
  327 |         await witness.session.send("Runtime.evaluate", {
  328 |           contextId: witness.contextId,
  329 |           expression:
  330 |             "globalThis.__JAPP_UNDO_VALUE_DESCRIPTOR_PAUSE__?.restore()",
  331 |         });
  332 |         await pending?.catch(() => undefined);
  333 |         await witness.dispose();
  334 |         await h.page.close();
  335 |         await h.controller.close();
  336 |       }
  337 |     });
  338 |   }
```