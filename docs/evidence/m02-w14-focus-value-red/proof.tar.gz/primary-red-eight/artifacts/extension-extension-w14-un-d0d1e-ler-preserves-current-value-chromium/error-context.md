# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w14-undo-value-race-independent.spec.ts >> independent EXECUTE date focus-handler preserves current value
- Location: e2e/extension/extension-w14-undo-value-race-independent.spec.ts:50:7

# Error details

```
Error: execute must preserve the newer focus edit

expect(received).toBe(expected) // Object.is equality

Expected: "2022-03-04"
Received: "2021-02-03"
```

```
Error: execute must not overwrite or recover over the newer edit

expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 1
```

```
Error: expect(received).toMatchObject(expected)

- Expected  - 2
+ Received  + 2

  Object {
-   "change": 0,
-   "input": 0,
+   "change": 1,
+   "input": 1,
  }
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "VERIFIED"
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: false
Received: true
```

# Test source

```ts
  167 |                 );
  168 |           const completed = await pending;
  169 |           pending = undefined;
  170 |           const physical = await h.page.evaluate(() => ({
  171 |             value: document.querySelector("input")?.value,
  172 |             drift:
  173 |               (window as unknown as Record<string, unknown>).__undoDrift ??
  174 |               null,
  175 |             events: (window as unknown as Record<string, unknown>)
  176 |               .__undoEventMeter,
  177 |           }));
  178 |           const afterNative = await witness.snapshot();
  179 |           await record(info, seed, {
  180 |             control,
  181 |             operation,
  182 |             drift,
  183 |             field,
  184 |             tx,
  185 |             initialExecution,
  186 |             completed,
  187 |             physical,
  188 |             beforeEvents,
  189 |             beforeNative,
  190 |             afterNative,
  191 |             browserVersion: extensionContext.browser()?.version(),
  192 |             serviceWorkerUrl: serviceWorker.url(),
  193 |           });
  194 |           if (operation === "UNDO") {
  195 |             const undo = parseUndoTabResult(completed);
  196 |             expect(undo?.outcome.status).toBe("COMPLETED");
  197 |             if (undo?.outcome.status !== "COMPLETED")
  198 |               throw new Error("undo response absent");
  199 |             if (drift === "unchanged") {
  200 |               expect(undo.outcome.result.outcome).toBe("VERIFIED");
  201 |               expect(physical.value).toBe(control.prior);
  202 |               expect(
  203 |                 afterNative.native_mutation_count -
  204 |                   beforeNative.native_mutation_count,
  205 |               ).toBe(1);
  206 |             } else {
  207 |               expect(physical.drift).toMatchObject({
  208 |                 before: control.intended,
  209 |                 after: control.newer,
  210 |                 mutationRecords: 0,
  211 |               });
  212 |               expect
  213 |                 .soft(physical.value, "undo must preserve the newer edit")
  214 |                 .toBe(control.newer);
  215 |               expect
  216 |                 .soft(
  217 |                   afterNative.native_mutation_count -
  218 |                     beforeNative.native_mutation_count,
  219 |                   "undo must not write over the newer edit",
  220 |                 )
  221 |                 .toBe(0);
  222 |               expect.soft(undo.outcome.result.outcome).not.toBe("VERIFIED");
  223 |             }
  224 |           } else {
  225 |             const execution = completed as Awaited<
  226 |               ReturnType<typeof dynExecute>
  227 |             >;
  228 |             const outcome = firstDriverOutcome(execution);
  229 |             if (drift === "unchanged") {
  230 |               expect(outcome).toBe("VERIFIED");
  231 |               expect(physical.value).toBe(control.intended);
  232 |               expect(
  233 |                 afterNative.native_mutation_count -
  234 |                   beforeNative.native_mutation_count,
  235 |               ).toBe(1);
  236 |               expect(physical.events).toMatchObject({ input: 1, change: 1 });
  237 |             } else {
  238 |               expect(physical.drift).toMatchObject({
  239 |                 before: control.prior,
  240 |                 after: control.newer,
  241 |                 mutationRecords: 0,
  242 |               });
  243 |               expect
  244 |                 .soft(
  245 |                   physical.value,
  246 |                   "execute must preserve the newer focus edit",
  247 |                 )
  248 |                 .toBe(control.newer);
  249 |               expect
  250 |                 .soft(
  251 |                   afterNative.native_mutation_count -
  252 |                     beforeNative.native_mutation_count,
  253 |                   "execute must not overwrite or recover over the newer edit",
  254 |                 )
  255 |                 .toBe(0);
  256 |               expect
  257 |                 .soft(physical.events)
  258 |                 .toMatchObject({ input: 0, change: 0 });
  259 |               expect.soft(outcome).not.toBe("VERIFIED");
  260 |               const item = execution.items[0];
  261 |               expect
  262 |                 .soft(
  263 |                   item !== undefined &&
  264 |                     "undo_available" in item &&
  265 |                     item.undo_available,
  266 |                 )
> 267 |                 .toBe(false);
      |                  ^ Error: expect(received).toBe(expected) // Object.is equality
  268 |             }
  269 |           }
  270 |         } finally {
  271 |           await pending?.catch(() => undefined);
  272 |           await witness.dispose();
  273 |           await h.page.close();
  274 |           await h.controller.close();
  275 |         }
  276 |       });
  277 |     }
  278 |   }
  279 | }
  280 | 
```