"""Finite independent audit of retained outputs only. Never imports/runs product."""
from pathlib import Path
import hashlib,json,struct,re,datetime
BASE=Path(__file__).parent.parent
OUT=Path(__file__).parent
checks=[]
def check(name,condition,detail=None):
 checks.append({'name':name,'pass':bool(condition),'detail':detail})
def read(rel):return json.loads((BASE/rel).read_text())
def sha(data):return hashlib.sha256(data).hexdigest()
before=read('browser-v1/before.json');after=read('browser-v1/after.json');closure=read('browser-v1/closure.json');context=read('browser-v1/context.json');report=read('browser-v1/report.json');quality=read('quality-v2/results.json')
check('full source/runtime/status endpoints exactly equal',before==after)
check('source2004 and runtime40',len(before['source'])==2004 and len(before['runtime'])==40)
check('all source/runtime records preserve full mode/bytes/hash fields',all(set(row)=={'bytes','mode','sha256'} for table in [before['source'],before['runtime']] for row in table.values()))
check('quality six recorded commands all exit0 without timeout',len(quality)==6 and all(x['exit_code']==0 and not x['timeout'] for x in quality))
qb=read('quality-v2/source-before.json');qa=read('quality-v2/source-after.json')
check('quality before/after2004 equal actual browser projection',len(qb)==2004 and qb==qa==before['source'])
check('actual outer browser exit0/no timeout',closure['exit_code']==0 and closure['timeout'] is False)
check('direct child reaped observed group absent no cleanup signals',closure['direct_child_reaped'] and closure['observed_group']=='ABSENT' and closure['outer_cleanup_signals']==[])
check('raw before/after agrees with outer preservation result',closure['source_runtime_status_unchanged'] and closure['source_count']==2004 and closure['runtime_count']==40)
check('shipping assets preserved by inspected observer',closure['shipping_assets_unchanged'] is True)
check('renderer ten endpoint assets equal',len(context['renderer_assets_before'])==10 and context['renderer_assets_before']==closure['renderer_assets_after'])
check('shipping four assets exclude isolated renderer pages',len(context['shipping_assets'])==4 and 'catalog.html' not in context['shipping_assets'] and 'service.html' not in context['shipping_assets'])
check('renderer catalog and service pages are separate assets',all(p in context['renderer_assets_before'] for p in ['catalog.html','index.html','service.html']))
check('report stats32 expected zero skipped unexpected flaky errors',report['stats']['expected']==32 and all(report['stats'][k]==0 for k in ['skipped','unexpected','flaky']) and report['errors']==[])
executions=[]
def visit(suite):
 for s in suite.get('specs',[]):
  for t in s['tests']:
   executions.append({'id':s['id'],'title':s['title'],'file':s['file'],'status':t['status'],'results':[(r['status'],r['retry']) for r in t['results']]})
 for child in suite.get('suites',[]):visit(child)
for suite in report['suites']:visit(suite)
check('32 unique actual test IDs one passed attempt each',len(executions)==32 and len({x['id'] for x in executions})==32 and all(x['status']=='expected' and x['results']==[('passed',0)] for x in executions))
check('raw browser log reports32PASS',bool(re.search(r'^\s*32 passed \(10\.9s\)',(BASE/'browser-v1/browser.log').read_text(),re.M)))
frames=[];sources=[]
for p in sorted((BASE/'browser-v1/artifacts').glob('visual-desktop-catalog-*/*.json')):
 m=json.loads(p.read_text());png=p.with_suffix('.png');data=png.read_bytes();dims=struct.unpack('>II',data[16:24]);a=m['artifact'];s=m['source'];sources.append(s)
 okay=data[:8]==b'\x89PNG\r\n\x1a\n' and (a['bytes'],a['sha256'],a['png_width'],a['png_height'])==(len(data),sha(data),*dims) and a['filename']==png.name
 check('actualPNG artifact '+png.name,okay)
 check('capture source identity '+png.name,s['git_revision']==context['commit']=='35b46287dc754a5987d653490ab49f978647ca26' and s['git_tree']=='f0789de7f5c82f6931eebe489110fcb771130724' and s['selected_sources_match_revision'] is False and bool(s['selected_source_status']))
 filematch=all((x['bytes'],x['sha256'])==(before['source'][x['path']]['bytes'],before['source'][x['path']]['sha256']) for x in s['files'])
 check('capture20 source blobs equal frozen2004 '+png.name,len(s['files'])==20 and filematch and sha(json.dumps(s['files'],ensure_ascii=False,separators=(',',':')).encode())==s['source_sha256'])
 o=m['observed'];check('honest capture context '+png.name,m['state']=='CAPTURED_NOT_REVIEWED' and m['approval']=='NOT_APPROVED' and not m['frozen_design_system'] and m['actual_native_ipc'] is False and m['native_service_proven'] is False and o['device_scale_factor']==o['visual_scale']==1 and o['root_font_size']=='16px' and o['prefers_light'] and o['reduced_motion'] and m['requested_zoom_percent']==100 and m['requested_theme']=='light' and m['host']=={'platform':'darwin','architecture':'arm64'} and m['browser']=={'type':'chromium','version':'151.0.7922.34'})
 frames.append({'fixture':m['fixture_id'],'viewport':o['viewport'],'png_path':str(png.relative_to(BASE)),'metadata_path':str(p.relative_to(BASE)),'png_bytes':len(data),'sha256':sha(data),'dimensions':dims,'view_image_inspected_by_reviewer':True})
check('14 frames cover seven surfaces x2 actual viewport widths',len(frames)==14 and {x['fixture'] for x in frames}=={'shell-'+x for x in ['home','jobs','tracker','documents','profile','settings','diagnostics']} and all(sorted(x['viewport']['width'] for x in frames if x['fixture']==f)==[320,1120] for f in {x['fixture'] for x in frames}) and all(x['viewport']['height']==760 for x in frames))
check('all14 exact selected-source metadata records equal',all(x==sources[0] for x in sources))
check('first typecheck error retained distinct from corrected qualityPASS',read('quality-results.json')[-1]['exit_code']==2 and 'TS2353' in (BASE/'quality-2.log').read_text())
output={'scope':'READ_ONLY_RETAINED_DATA_AND14_VISUAL_REVIEW_NOT_DELEGATED_ACCEPTANCE','reviewed_utc':datetime.datetime.now(datetime.UTC).isoformat(),'reviewer':'/root/current_ci_repair','checks':checks,'clear':all(x['pass'] for x in checks),'checks_passed':sum(x['pass'] for x in checks),'source_count':2004,'runtime_count':40,'test_executions':executions,'captures':frames,'capture_source':sources[0],'shipping_assets':context['shipping_assets'],'renderer_assets':context['renderer_assets_before'],'original_failure':'quality-results.json root tsc exits2 with TS2353; corrected quality-v2 is a different completed observation','states':{'M03-W06':'IN_PROGRESS','M03-W11':'NOT_STARTED','M03':'IN_PROGRESS','verified':38,'release':'NOT_READY'},'limits':['Raw snapshots prove equal endpoints, not an exhaustive history of intermediate writes.','Outer observer reports direct child reaped and observed process group absent; no escaped-descendant proof.','Reference35b/treef078 is dirty for selected capture sources; frozen20-file source hash is authoritative for actual captured UI, not a clean35b product claim.','All observed captures are Chromium on macOS with synthetic version loader; Windows-like user-agent is a browser default, not native Windows evidence.','No owner/delegated visual approval, frozen tokens, final AB-11/AB-12 checklist PASS, comprehensive accessibility, task study, native IPC, live service or platform certification.']}
(OUT/'audit.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps({'clear':output['clear'],'checks_passed':output['checks_passed'],'checks':len(checks),'failed':[x for x in checks if not x['pass']]}))
