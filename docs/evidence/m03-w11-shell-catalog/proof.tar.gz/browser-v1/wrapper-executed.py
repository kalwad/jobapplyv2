from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import stat
import subprocess
import time

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
OUT = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/w11-actual/browser-v1')
OUT.mkdir(exist_ok=False)

def inventory(base):
    result = {}
    for path in sorted(base.rglob('*')):
        info = path.lstat()
        if stat.S_ISDIR(info.st_mode):
            continue
        assert stat.S_ISREG(info.st_mode), str(path)
        result[path.relative_to(base).as_posix()] = {'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    return result

def snapshot():
    raw = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=ROOT)
    result = {}
    for name in sorted(set(os.fsdecode(p) for p in raw.split(b'\0') if p)):
        path = ROOT / name
        info = path.lstat()
        assert stat.S_ISREG(info.st_mode), name
        result[name] = {'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    return {'source': result, 'runtime': inventory(ROOT / 'apps/desktop/src-tauri/runtime-payload'), 'git_status': subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=ROOT, text=True)}

before = snapshot()
(OUT / 'before.json').write_text(json.dumps(before, indent=2, sort_keys=True) + '\n')
(OUT / 'wrapper-executed.py').write_bytes(Path(__file__).read_bytes())
context = {'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(), 'start_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'shipping_assets': inventory(ROOT / 'apps/desktop/dist'), 'renderer_assets_before': inventory(ROOT / 'apps/desktop/dist-renderer')}
(OUT / 'context.json').write_text(json.dumps(context, indent=2) + '\n')
argv = ['pnpm', 'exec', 'playwright', 'test', 'e2e/desktop/shell.spec.ts', 'e2e/desktop/service-diagnostics.spec.ts', 'e2e/desktop/state-catalog.spec.ts', 'e2e/visual/desktop-shell.spec.ts', 'e2e/visual/desktop-catalog.spec.ts', '--output', str(OUT / 'artifacts'), '--reporter=list,json']
env = dict(os.environ)
env['PATH'] = '/opt/homebrew/opt/node@24/bin:' + env['PATH']
env['PLAYWRIGHT_JSON_OUTPUT_FILE'] = str(OUT / 'report.json')
start = time.monotonic()
signals = []
timeout = False
with (OUT / 'browser.log').open('wb') as log:
    child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        code = child.wait(timeout=600)
    except subprocess.TimeoutExpired:
        timeout = True
        for sig in (signal.SIGTERM, signal.SIGKILL):
            try:
                os.killpg(child.pid, sig)
                signals.append(sig.name)
            except ProcessLookupError:
                pass
            if sig == signal.SIGTERM:
                time.sleep(1)
        code = child.wait(timeout=10)
try:
    os.killpg(child.pid, 0)
    group = 'PRESENT_AFTER_DIRECT_CHILD_REAP; NO_POST_REAP_SIGNAL'
except ProcessLookupError:
    group = 'ABSENT'
after = snapshot()
(OUT / 'after.json').write_text(json.dumps(after, indent=2, sort_keys=True) + '\n')
closure = {'end_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'argv': argv, 'exit_code': code, 'timeout': timeout, 'seconds': time.monotonic() - start, 'direct_child_reaped': child.returncode is not None, 'observed_group': group, 'outer_cleanup_signals': signals, 'source_count': len(before['source']), 'runtime_count': len(before['runtime']), 'source_runtime_status_unchanged': before == after, 'shipping_assets_unchanged': context['shipping_assets'] == inventory(ROOT / 'apps/desktop/dist'), 'renderer_assets_after': inventory(ROOT / 'apps/desktop/dist-renderer')}
(OUT / 'closure.json').write_text(json.dumps(closure, indent=2) + '\n')
print(json.dumps(closure), flush=True)
raise SystemExit(0 if code == 0 and not timeout and group == 'ABSENT' and before == after and closure['shipping_assets_unchanged'] else 1)
