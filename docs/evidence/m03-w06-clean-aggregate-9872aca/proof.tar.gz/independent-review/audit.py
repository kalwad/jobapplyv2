from pathlib import Path
import hashlib,json,re,stat
base=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');src=base/'full-9872aca';out=Path(__file__).parent
load=lambda n:json.loads((src/n).read_text())
before=load('before.json');after=load('after.json');context=load('context.json');closure=load('closure.json');results=load('results.json')
immutable=json.loads((base/'ci-9872aca/immutable-git-source-sha256.json').read_text())
macafter=json.loads((base/'mac-package-refreshed/app-build-after.json').read_text())
checks=[]
def check(name,value,detail=None):
 checks.append({'name':name,'pass':bool(value),'detail':detail});assert value,(name,detail)
check('Context exact9872aca commit and tree',context['commit']==immutable['commit'] and context['tree']==immutable['tree'])
check('2141source endpoints exact',len(before['source'])==len(after['source'])==2141 and before['source']==after['source'])
check('40runtime fullmode endpoints exact',len(before['runtime'])==len(after['runtime'])==40 and before['runtime']==after['runtime'])
check('Both clean Gitstatus endpoints',before['git_status']==after['git_status']=='')
check('Source membership exact immutable Git',set(before['source'])==set(immutable['files']))
for path,item in before['source'].items():
 binding=immutable['files'][path]
 check('Immutable source body '+path,item['bytes']==binding['bytes'] and item['sha256']==binding['sha256'] and bool(item['mode']&0o111)==(binding['git_mode']=='100755'))
check('Runtime exact independently reviewed refreshed app-build baseline',before['runtime']==macafter['runtime'])
check('Closure accurately reports PASS and unchanged endpoints',closure['source_count']==2141 and closure['runtime_count']==40 and closure['source_bytes_modes_unchanged'] and closure['runtime_bytes_modes_unchanged'] and closure['all_commands_exit_zero'])
check('Exactly doctor and aggregate outer commands',[r['argv'] for r in results]==[['pnpm','run','doctor'],['pnpm','verify']])
check('Actual exit codes0/0',[r['exit_code'] for r in results]==[0,0])
for r in results:
 check('Natural closed group '+r['name'],not r['timeout'] and r['direct_child_reaped'] and r['observed_group']=='ABSENT' and r['outer_cleanup_signals']==[] and r['seconds']>0)
doctor=(src/'doctor.log').read_text();log=(src/'verify.log').read_text()
check('Doctor retained28PASSzero warning/failure','summary: 28 pass, 0 warning, 0 fail, 0 not-yet-applicable' in doctor)
section=log.split('== verification summary ==\n')[-1]
rows=re.findall(r'^(\S+)[ \t]+(ACTIVE)[ \t]+(PASS|FAIL)[ \t]*(.*)$',section,re.M)
check('Twenty unique active suite verdicts',len(rows)==20 and len({r[0] for r in rows})==20)
check('All20ACTIVE suites actual PASS',all(r[2]=='PASS' for r in rows))
check('Aggregate actual exit0 diagnostic','verification exit code: 0' in section and 'FAILURE ' not in section)
commands=re.findall(r'^\$ (.*)$',log,re.M)
# Pure trusted verifier helpers, exact source bytes bound above. No child actor.
import importlib.util,sys,shlex
sys.dont_write_bytecode=True
canonical=Path('/Users/tanishkalwad/jobapplyv2')
check('Executed verifier source still exact immutable9872',hashlib.sha256((canonical/'scripts/verify.py').read_bytes()).hexdigest()==immutable['files']['scripts/verify.py']['sha256'])
spec=importlib.util.spec_from_file_location('full9872_review_verify',canonical/'scripts/verify.py');verify=importlib.util.module_from_spec(spec);sys.modules[spec.name]=verify;spec.loader.exec_module(verify)
ctx=verify.Context(canonical,canonical/'scripts/verification-suites.json',canonical/'docs/PROJECT_STATUS.md')
registry=verify.load_registry(ctx.registry_path)
relatives=tuple(p.relative_to(canonical).as_posix() for p in verify._unskipped_test_paths(ctx,verify.PY_TEST_FILE_GLOBS,registry.allowed_skips))
inventory,reason=verify._load_python_test_inventory(ctx,relatives)
check('Committed exact POSIX2120 inventory',reason is None and inventory is not None and inventory.count==2120)
python_commands=[c for c in commands if c.startswith('uv run pytest ')]
check('Exactly real collection and execution argv',len(python_commands)==2 and tuple(shlex.split(python_commands[0]))==verify._canonical_pytest_command(relatives,collect_only=True) and tuple(shlex.split(python_commands[1]))==verify._canonical_pytest_command(relatives,collect_only=False))
collection=log.split('$ '+python_commands[0]+'\n')[1].split('\n$ ')[0]
ids,reason=verify._parse_pytest_collection_output(collection,relatives)
check('Actual collection all exact2120 IDs/digest',reason is None and ids==inventory.node_ids and verify._python_inventory_digest(ids)==inventory.sha256)
python_execution=log.split('$ '+python_commands[1]+'\n')[1].split('\n$ ')[0]
check('Actual ordinary2120PASS no failed/skipped/xfail summary',re.search(r'^=+ 2120 passed in 386\.47s \(0:06:26\) =+$',python_execution,re.M) is not None)
check('Both metadata corrections exercised83plus22 IDs',sum(i.startswith('services/orchestrator/tests/test_runtime_metadata') for i in ids)==105)
check('Browser278/publicinspection2/contact62/visual17 actual summaries',all(re.search(r'^  '+str(count)+r' passed \(',log,re.M) for count in [278,2,62,17]))
unit=log.split('$ pnpm exec turbo run test --force --concurrency=2 -- --reporter=default\n')[1].split('$ pnpm generate:contracts --check')[0]
counts=re.findall(r'^(@japp/[^:]+):test:\s+Tests\s+(\d+) passed \(\d+\)',unit,re.M)
check('Fifteen unit package results sum4006',len(counts)==15 and len(dict(counts))==15 and sum(int(c) for _,c in counts)==4006)
check('Fifteen fresh Turbo test tasks','Tasks:    15 successful, 15 total' in unit and 'Cached:    0 cached, 15 total' in unit and 'cache hit' not in unit)
check('Actual browser278 terminal ordinary pass','  278 passed (9.0m)' in log)
check('Actual dedicated visual17 terminal ordinary pass','  17 passed (7.4s)' in log)
native_modes=[]
for suffix in ['', ' --all-features',' --features tauri/custom-protocol']:
 command='$ cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml'+suffix
 start=log.index(command+'\n');end=log.find('\n$ ',start+len(command));piece=log[start:end if end!=-1 else None]
 names=re.findall(r'^test (\S+) \.\.\. ok$',piece,re.M)
 check('Native342 unique actual cases '+(suffix or 'default'),len(names)==len(set(names))==342 and 'test result: ok. 342 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in piece)
 native_modes.append({'argv':command[2:].split(),'passed':342,'names':names,'names_sha256':hashlib.sha256(('\n'.join(sorted(names))+'\n').encode()).hexdigest()})
check('Native three feature-mode actual ID sets equal',len({r['names_sha256'] for r in native_modes})==1)
visual=json.loads((src/'retained-visual/retention.json').read_text());visualfiles=visual['files']
check('Retained visual paths regular and exact',all((p:=src/'retained-visual'/f['path']).is_file() and not p.is_symlink() and len(p.read_bytes())==f['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256'] for f in visualfiles))
check('Corrected metadata fixture exact reviewed afterimage',before['source']['services/orchestrator/tests/test_runtime_metadata.py']['sha256']=='50b5e27e4076a60012e17f57f4b0b8a2f3a8777da87665f6436a9eecdd771add')
report={'scope':'INDEPENDENT_ACTUAL_CLEAN_LOCAL_FULL_AGGREGATE_9872_DATA_REVIEW_NOT_CI_OR_NATIVE_GUI_ACCEPTANCE','verdict':'CLEAR_LOCAL_FULL_AGGREGATE_PASS','passed_checks':len(checks),'checks':checks,'commit':context['commit'],'tree':context['tree'],'start_utc':context['start_utc'],'end_utc':closure['end_utc'],'actual_results':results,'aggregate_suites':[{'suite':r[0],'state':r[1],'result':r[2]} for r in rows],'unit_package_counts':{k:int(v) for k,v in counts},'ordinary_unit_passed':4006,'browser_passed':278,'dedicated_visual_passed':17,'native_modes':native_modes,'python_execution':'ACTUAL2120PASS386_47_SECONDS','python_inventory_sha256':inventory.sha256,'python_collection_ids':list(ids),'python_collection_argv':list(verify._canonical_pytest_command(relatives,collect_only=True)),'python_execution_argv':list(verify._canonical_pytest_command(relatives,collect_only=False)),'public_inspection_passed':2,'public_contact_controlled_passed':62,'source_files':2141,'runtime_files':40,'retained_visual_files':len(visualfiles),'limits':['No complete Vitest per-case ID channel','Source-neutrality endpoints do not prove every intermediate state','Rust test PASS is not packaged GUI or desktop-native foreign-OS acceptance','Starting HEAD/tree context retained; no immediate after-run HEAD/tree receipt retained','Current foreign CI and separate fresh native GUI are separate actual evidence']}
(out/'actual-data-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in {'checks','native_modes','aggregate_suites','unit_package_counts','python_collection_ids','python_collection_argv','python_execution_argv'}},indent=2))
