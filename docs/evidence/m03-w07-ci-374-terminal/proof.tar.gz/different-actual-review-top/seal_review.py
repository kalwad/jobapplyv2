"""Finite review seal; input pins checked, no canonical or collector writes."""
from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path
import stat
import tarfile

H = Path(__file__).resolve().parent
E = H.parents[1]
def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(1024*1024):
            h.update(chunk)
    return h.hexdigest()
def info(path):
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode) and not path.is_symlink()
    return {'bytes': s.st_size, 'sha256': sha(path), 'full_mode': s.st_mode}
def dump(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n')
retention = json.loads((H / 'collector-retention.json').read_bytes())
source = Path(retention['source'])
source_current = {p.relative_to(source).as_posix(): info(p) for p in sorted(source.rglob('*')) if p.is_file()}
assert source_current == retention['source_before'] == retention['source_after'] == retention['copy']
refs = [
    (E / 'ci-374b6fe-config.json', '808c01538d312447e0e89f5f85dfafc887ae774f14b3cde194a6551644968e38'),
    (E / 'clean-full-374b6fe-independent-review/v1/immutable-git-source-sha256.json', '60f2d16e4b16012462cd73a0bb591e9cf88587f3ff57fc2c3171c9b688dbf475'),
    (E / 'clean-full-374b6fe-independent-review/v1/immutable-python-test-inventory.v1.json', '691537e00c2b306233b17cc77a6ed79d5c1122ca87d492f5b4adaf4b78a244db'),
    (E / 'clean-full-374b6fe-independent-review/v1/REVIEW.md', '9be67b212180403bdb66cb51cec2065e8ed8a95c794b6af655945b3c06f82a31'),
    (E / 'clean-full-374b6fe-independent-review/v1/manifest.json', '6c869fd8b803dbdd00fa98d6d8048d62f37a4c16d869b62440a9c142e31defd8'),
    (E / 'clean-full-f3a1c6f-independent-review/v1/immutable-git-source-sha256.json', '4ab7ec940114f598574d5d09c242bb6dc8f0968562174fac45428e74fbadd528')
]
references = []
for path, expected in refs:
    pin = info(path)
    assert pin['sha256'] == expected
    references.append({'path': str(path), **pin})
dump(H / 'final-input-joins.json', {'utc': datetime.now(UTC).isoformat(), 'all793_parent_bytes_fullmodes_equal': True, 'parent_members': len(source_current), 'references': references, 'no_current_or_end_PR_head_requirement': True, 'scope': 'Frozen parent bytes and referenced immutable pins only. Current canonical source review belongs to separate new full packet.'})
excluded = {'manifest.json', 'proof.tar.gz', 'SEAL.json'}
files = {p.relative_to(H).as_posix(): info(p) for p in sorted(H.rglob('*')) if p.is_file() and p.relative_to(H).as_posix() not in excluded}
assert 800 <= len(files) <= 1000
manifest = {'schema_version': 1, 'file_count': len(files), 'bytes': sum(row['bytes'] for row in files.values()), 'files': files, 'scope': 'Finite independent original374 CI data-review packet. Every indexed file regular; manifest/proof/seal self-excluded.'}
dump(H / 'manifest.json', manifest)
with tarfile.open(H / 'proof.tar.gz', 'w:gz', compresslevel=6) as archive:
    for name in [*files, 'manifest.json']:
        archive.add(H / name, arcname=name, recursive=False)
with tarfile.open(H / 'proof.tar.gz', 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(files)+1 and all(item.isfile() and not item.name.startswith('/') and '..' not in Path(item.name).parts for item in members)
    for item in members:
        pin = info(H / item.name)
        stream = archive.extractfile(item)
        assert stream is not None
        body = stream.read()
        assert len(body) == pin['bytes'] and hashlib.sha256(body).hexdigest() == pin['sha256']
seal = {'utc': datetime.now(UTC).isoformat(), 'verdict': 'CONFIRMED_ACTUAL_CI_FAILURE_AND_PARTIAL_CANCELLATION', 'REVIEW': info(H / 'REVIEW.md'), 'findings': info(H / 'source-findings.json'), 'DATA': info(H / 'data-review.json'), 'manifest': info(H / 'manifest.json'), 'proof': info(H / 'proof.tar.gz'), 'indexed_regular_members': len(files), 'proof_safe_regular_members': len(files)+1, 'scope': 'Original source retained CI actual failure/cancellation only; no PASS/native/release/gate inference. All793 original collector files unchanged.'}
dump(H / 'SEAL.json', seal)
print(json.dumps(seal))
