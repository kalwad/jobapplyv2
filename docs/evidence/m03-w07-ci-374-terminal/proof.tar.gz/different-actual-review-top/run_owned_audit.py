"""Own/reap one finite inert review child; raw failures are retained."""
from pathlib import Path
from datetime import UTC, datetime
import hashlib
import json
import os
import subprocess
import sys
import time

H = Path(__file__).resolve().parent
label = sys.argv[1]
assert label.isascii() and label.replace('-', '').isalnum()
qa = H / 'qa' / label
qa.mkdir(parents=True, exist_ok=False)
lease_paths = [H / 'raw-collector/collector-closure.json', H / 'retained/immutable-source-map.json', H / 'retained/expected-catalog.json', H / 'audit_closed_ci.py']
def lease():
    return {str(p): {'bytes': p.stat().st_size, 'full_mode': p.lstat().st_mode, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in lease_paths}
before = lease()
args = ['/Users/tanishkalwad/.local/share/uv/python/cpython-3.12.13-macos-aarch64-none/bin/python3.12', '-I', '-S', '-B', str(H / 'audit_closed_ci.py')]
start = datetime.now(UTC).isoformat()
clock = time.monotonic()
with (qa / 'stdout.log').open('wb') as out, (qa / 'stderr.log').open('wb') as err:
    child = subprocess.Popen(args, cwd=H, stdin=subprocess.DEVNULL, stdout=out, stderr=err, start_new_session=True)
    code = child.wait(timeout=55)
try:
    os.killpg(child.pid, 0)
except ProcessLookupError:
    group = 'ABSENT'
else:
    group = 'PRESENT'
after = lease()
row = {'argv': args, 'pid': child.pid, 'pgid': child.pid, 'reaped': child.returncode is not None, 'exit_code': code, 'group_after_wait': group, 'signals': [], 'timeouts': [], 'start_utc': start, 'end_utc': datetime.now(UTC).isoformat(), 'seconds': time.monotonic()-clock, 'lease_before': before, 'lease_after': after, 'leased_inputs_equal': before == after, 'scope': 'Only review child is owned here; not collector owner/browser/native/test execution custody.'}
(qa / 'receipt.json').write_text(json.dumps(row, indent=2)+'\n')
print(json.dumps({k: row[k] for k in ('pid', 'exit_code', 'reaped', 'group_after_wait', 'seconds', 'leased_inputs_equal')}))
assert child.returncode is not None and group == 'ABSENT' and before == after
raise SystemExit(code)
