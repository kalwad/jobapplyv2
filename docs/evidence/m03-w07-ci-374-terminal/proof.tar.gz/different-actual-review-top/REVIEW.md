# Independent actual CI data review — original 374b6fe

Verdict: **CONFIRMED_ACTUAL_CI_FAILURE_AND_PARTIAL_CANCELLATION**. This run is not accepted as passing. The 10,295 successful data-consistency checks validate retained records; they do not waive test failures or turn cancelled work into execution evidence.

The review binds original source `374b6fe484b5dd82c4a7fa1d751a77369ec79431`, tree `a77820bb5430ec8bebcfb17c8010b0764011fabe`, its 2,338-file immutable body map, exact catalog, configured five workflows and attempt-1 run IDs. It does not require the current checkout or ending PR head to remain at this source. Root pushed a subsequent correction while this review was pending; that separate source/run is not reviewed here.

| Actual component | Retained outcome |
| --- | --- |
| Main run `40950984824` | API `cancelled` |
| Ubuntu verify `123718724049` | API `failure`; Python **1 failed, 2,787 passed in 684.62 s**; other 19 ACTIVE suites PASS |
| Windows verify `123718724454` | API `failure`; Python **3 failed, 2,783 passed in 681.25 s**; other 19 ACTIVE suites PASS |
| macOS verify `123718724628` | API `cancelled`; cancellation during Python; no terminal Python or full aggregate summary |
| Dependent package `123738677855` | Unexpanded matrix job API `cancelled`, no assigned runner; log GET returned retained HTTP404; no package export |
| Four auxiliary workflows | `authorize` success, explicit `enabled=false`/`SKIP_NO_ROOT_REQUEST` artifact, downstream jobs skipped; policy evidence only |

Both completed verification jobs fail `scripts/tests/test_ubuntu_gnome_boundaries.py::test_imports_do_not_load_platform_gi_or_spawn_actor`: the unchanged assertion expects terminal `finish`, but observes `shell_check_observe`. This agrees with the separately sealed local full failure for this same source.

Windows also fails the `open` and `read` parameters of `services/orchestrator/tests/test_generation_idle_deadline.py::test_suppressed_idle_timer_cancellation_still_refuses_success`, with `DID NOT RAISE GenerationError`. These are actual additional failures, not dismissed as flakes. This retained-data review establishes the observed failure; it does not claim a root cause or that a later fix passes Windows.

The retained main-job checkout is actual PR merge `d3541f5c9a7ae4f129b8df066fe26e31647bc210`, whose API commit parents are the configured base `4745149f4b5da7190b5b0c68753f8ec07bed572d` and original source. Its tree matches original source. Every retained tree blob path/OID/Git mode/size joins all 2,338 locally framed and hashed immutable bodies.

The original collector's four `CHECKOUT_SOURCE_BINDING_MISMATCH` labels remain unchanged. They are independently classified as an observer limitation: `bind_checkout` reads only the first checkout and unconditionally requires two merge parents. Each auxiliary `authorize` workflow explicitly first checks out PR head into `control`. Official logs show original source there, then the actual merge into `workflow-origin`, exactly matching the fixed workflow. A direct source commit legitimately has its normal single parent. Both source and merge trees join the same 2,338 files. This classification does not alter any product failure, cancellation or original raw record.

All three jobs retain their collection output. Ubuntu/macOS show 2,788 items, including the two POSIX-only catalog entries; Windows shows 2,786. Respectively 2,776 / 2,774 node IDs match directly, with 12 masked authorization parameter labels on each platform. Per-function multiplicities match the complete catalog. Those masked labels cannot establish individual parameter identity, and collection is not passing-case execution proof. Completed aggregate Python summaries and exact failed IDs are reported separately. macOS has no Python PASS/FAIL verdict.

The closed collector is copied as 793 regular files / 161,735,319 bytes, with source-before/copy/source-after bytes and full modes equal. All 124 retained read-only GET receipts join output and stderr hashes/sizes, ordering and child custody: all reaped, groups ABSENT, no signals or stop reasons; 123 exit0 and the one package-log404 exit1. All five retained run identities, all snapshots, all 13 terminal jobs and summary records join fixed original source/attempt/workflow. The seven official artifact digests match retained ZIPs. All 12 ZIPs (five official log archives and seven artifacts), 474 regular members, canonical paths, kinds, CRC-on-read, member bytes/hashes and retained full modes were independently checked. Windows PE images are retained inert diagnostic bytes only. Playwright artifact names reflect failure-triggered retention; this review makes no new screenshot/layout or native acceptance claim.

Root reports the newer push superseded this PR under the original workflow's cancellation policy and reports no manual cancellation. The retained API/logs directly show cancellation; they do not encode its initiator/reason. Root tool-observed collector PTY43752 CLOSED0, five runs / 13 jobs / seven artifacts. No independent numeric Popen PID/process-group receipt exists for the outer collector, so this review does not infer that custody from a PTY identifier. Internal GET-child receipts remain distinct.

Review source preparation independently read only the five original workflow Git blobs, verified their SHA1 object framing and SHA256 against the already frozen map, and closed/reaped that Git child with group ABSENT. Seventy-three fixed-workflow interpretation checks pass. Three owned inert audit children were reaped with groups ABSENT, no signals/timeouts and equal leased inputs. The first failed because the reviewer's own suite-name regex omitted digits in two `w14` IDs; its exact source and raw failure remain. The grammar was corrected without changing the 20-row / 19-PASS / Python-FAIL oracle. A second successful audit was preserved before adding all-snapshot/timeline joins and more explicit cancellation scope; the final audit also passes. This is observer history, not subject failure history.

No second collector, API refresh, rerun, network request, source import/test, native application, package install/run, unknown loader, model/runtime activation, canonical/cache/Git/ref mutation or release/gate claim occurred in this review. All original failure packets and immutable maps remain unchanged.
