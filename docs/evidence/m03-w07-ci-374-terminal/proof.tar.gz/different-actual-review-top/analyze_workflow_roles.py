"""Read fixed YAML data and source AST; no collector or workflow execution."""
from pathlib import Path
import ast
import hashlib
import json

import yaml

OUT = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/ci-374b6fe-independent-review/v1')
cfg = json.loads((OUT / 'retained/config.json').read_bytes())
records = []
checks = []
def check(label, value):
    checks.append({'check': label, 'pass': bool(value)})
    assert value, label

action = 'actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1'
control_ref = "${{ github.event_name == 'pull_request' && github.event.pull_request.head.sha || github.sha }}"
for expected in cfg['runs']:
    path = OUT / 'fixed-source' / expected['workflow_path']
    body = path.read_bytes()
    check(expected['workflow_path'] + ': hash', hashlib.sha256(body).hexdigest() == expected['workflow_sha256'])
    doc = yaml.load(body, Loader=yaml.BaseLoader)
    check(expected['workflow_path'] + ': name', doc['name'] == expected['name'])
    check(expected['workflow_path'] + ': read permissions', doc['permissions']['contents'] == 'read')
    jobs = []
    for job_id, job in doc['jobs'].items():
        checkouts = []
        for number, step in enumerate(job.get('steps', []), 1):
            if not step.get('uses', '').startswith('actions/checkout@'):
                continue
            check(expected['workflow_path'] + ':' + job_id + ': checkout pin', step['uses'] == action)
            values = step.get('with', {})
            check(expected['workflow_path'] + ':' + job_id + ': no credentials', values['persist-credentials'] == 'false')
            checkouts.append({'step_number': number, 'name': step.get('name'), 'action': step['uses'], 'ref': values.get('ref'), 'path': values.get('path'), 'fetch_depth': values.get('fetch-depth')})
        jobs.append({'id': job_id, 'name': job.get('name', job_id), 'needs': job.get('needs'), 'condition': job.get('if'), 'checkouts': checkouts, 'run_commands': [{'name': step.get('name'), 'run': step['run']} for step in job.get('steps', []) if step.get('run') in ('pnpm run doctor', 'pnpm verify')]})
    if expected['role'] == 'disabled_policy':
        authorize = next(row for row in jobs if row['id'] == 'authorize')
        check(expected['workflow_path'] + ': two authorize checkouts', len(authorize['checkouts']) == 2)
        a, b = authorize['checkouts']
        check(expected['workflow_path'] + ': exact direct control contract', a['ref'] == control_ref and a['path'] == 'control' and a['fetch_depth'] == '0')
        check(expected['workflow_path'] + ': distinct workflow-origin contract', b['ref'] == '${{ github.workflow_sha }}' and b['path'] == 'workflow-origin' and b['fetch_depth'] == '1')
        check(expected['workflow_path'] + ': downstream explicit guard', all(row['condition'] and "needs.authorize.outputs.enabled == 'true'" in row['condition'] for row in jobs if row['id'] != 'authorize'))
        check(expected['workflow_path'] + ': no superseded cancellation', doc['concurrency']['cancel-in-progress'] == 'false')
    else:
        check('main: exact two source jobs', {row['id'] for row in jobs} == {'verify', 'native_package_development'})
        check('main: PR default checkout', all(len(row['checkouts']) == 1 and row['checkouts'][0]['ref'] is None and row['checkouts'][0]['path'] is None and row['checkouts'][0]['fetch_depth'] == '0' for row in jobs))
        check('main: doctor and verify exact commands', next(row for row in jobs if row['id'] == 'verify')['run_commands'] == [{'name': 'Environment doctor (same command as local `pnpm run doctor`)', 'run': 'pnpm run doctor'}, {'name': 'Canonical aggregate verification (same command as local `pnpm verify`)', 'run': 'pnpm verify'}])
        check('main: downstream package depends verify', next(row for row in jobs if row['id'] == 'native_package_development')['needs'] == 'verify')
        check('main: superseded PR cancellation policy', doc['concurrency']['cancel-in-progress'] == "${{ github.ref != 'refs/heads/main' }}")
    records.append({'run': expected, 'concurrency': doc['concurrency'], 'jobs': jobs})

source = (OUT / 'retained/collector-prepared.py').read_text()
tree = ast.parse(source)
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'bind_checkout')
lines = source.splitlines(keepends=True)
extract = ''.join(lines[node.lineno-1:node.end_lineno])
check('collector: unconditional parent rule observed', "['parents']==[CONFIG['expected_base_commit'],HEAD]" in extract)
check('collector: only first checkout search', 'found=re.search(' in extract and 'finditer' not in extract and 'findall' not in extract)
check('collector: mismatch includes parent rule', "if not checkout_bindings[commit]['parents_match_start_PR_base_and_source']" in extract)
(OUT / 'workflow-role-analysis.json').write_text(json.dumps({'checks': checks, 'check_count': len(checks), 'all_pass': all(row['pass'] for row in checks), 'workflows': records, 'collector_bind_checkout': {'line': node.lineno, 'end_line': node.end_lineno, 'sha256': hashlib.sha256(extract.encode()).hexdigest(), 'source': extract}, 'posthoc_rules': {'aux_control': 'exact fixed source S/tree/full2338 source inventory; no synthetic merge-parent requirement', 'aux_workflow_origin': 'separate observed checkout, retain hash/path and workflow-source evidence; do not assume equals S', 'main_default_PR_checkout': 'actual merge with declared base and source parents, expected source tree/full inventory', 'superseded_run': 'actual terminal cancellation/failure/partial component results only; no conclusion from policy alone', 'native': 'authorization/data artifacts and source checks do not establish native execution or acceptance'}, 'scope': 'Prepared source interpretation only; actual terminal records and checkout logs not yet adjudicated.'}, indent=2)+'\n')
print(json.dumps({'checks': len(checks), 'all_pass': True, 'workflows': len(records), 'bind_checkout_lines': [node.lineno, node.end_lineno]}))
