"""Independent bounded retained CI data joins. Never executes subject bytes."""
from __future__ import annotations

from collections import Counter
from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import zipfile

H = Path(__file__).resolve().parent
R = H / 'raw-collector'
cfg = json.loads((H / 'retained/config.json').read_bytes())
immutable = json.loads((H / 'retained/immutable-source-map.json').read_bytes())
catalog = json.loads((H / 'retained/expected-catalog.json').read_bytes())
checks = []
def check(label, value, **details):
    row = {'check': label, 'pass': bool(value), **details}
    checks.append(row)
    assert value, row
def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()
def load(path):
    return json.loads(path.read_bytes())
def canonical_name(name):
    p = PurePosixPath(name)
    return bool(name and not p.is_absolute() and '..' not in p.parts and '\\' not in name and '\0' not in name and p.as_posix() == name.rstrip('/') and all(':' not in x for x in p.parts))
def clean_log(path):
    text = path.read_text(encoding='utf-8-sig', errors='replace')
    text = re.sub(r'(?m)^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d+Z ?', '', text)
    return re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', text)

check('config byte exact', (R / 'collector-config.json').read_bytes() == (H / 'retained/config.json').read_bytes())
check('source map byte exact', (R / 'immutable-git-source-sha256.json').read_bytes() == (H / 'retained/immutable-source-map.json').read_bytes())
check('catalog byte exact', (R / 'expected-catalog.json').read_bytes() == (H / 'retained/expected-catalog.json').read_bytes())
check('executed collector exact reviewed source', (R / 'collector-executed.py').read_bytes() == (H / 'retained/collector-prepared.py').read_bytes())
closure = load(R / 'collector-closure.json')
outcomes = load(R / 'terminal-outcomes.json')
check('five terminal runs exact', set(closure['terminal_runs']) == {r['id'] for r in cfg['runs']})
check('original failure arrays preserved', closure['failures'] == outcomes['failures'])
check('collector no subject execution/canonical writes declaration', closure['no_subject_execution'] is True and closure['canonical_writes'] == 0)

receipts = load(R / 'api-receipts.json')
for i, receipt in enumerate(receipts):
    label = f'APIreceipt{i}:{receipt["path"]}'
    path = R / receipt['path']
    error = path.with_name(path.name + '.stderr')
    check(label + ': GET', receipt['method'] == 'GET')
    check(label + ': output', path.stat().st_size == receipt['bytes'] and sha(path) == receipt['sha256'])
    check(label + ': stderr', error.stat().st_size == receipt['stderr_bytes'] and sha(error) == receipt['stderr_sha256'])
    check(label + ': owned child closure', receipt['child_reaped'] and receipt['group_after_wait'] == 'ABSENT' and receipt['signals'] == [] and receipt['stop_reason'] is None and receipt['pid'] == receipt['pgid'])
    check(label + ': time ordering', datetime.fromisoformat(receipt['start_utc']) <= datetime.fromisoformat(receipt['end_utc']))
api_failures = [r for r in receipts if r['exit_code'] != 0]
check('single unavailable dependent package log retained', len(api_failures) == 1 and api_failures[0]['endpoint'] == 'actions/jobs/123738677855/logs' and api_failures[0]['exit_code'] == 1 and 'HTTP 404' in (R / (api_failures[0]['path'] + '.stderr')).read_text())

def tree_join(tree):
    check('API tree complete:' + tree['sha'], tree['truncated'] is False)
    actual = {row['path']: row for row in tree['tree'] if row['type'] == 'blob'}
    check('API tree paths exact:' + tree['sha'], set(actual) == set(immutable['files']))
    for name, expected in immutable['files'].items():
        row = actual[name]
        check('API blob inventory:' + tree['sha'] + ':' + name, row['sha'] == expected['git_blob'] and row['mode'] == expected['git_mode'] and row['size'] == expected['bytes'])
    return len(actual)
head = load(R / 'head-commit.json')
check('API original fixed source/tree', head['sha'] == cfg['expected_source_commit'] and head['tree']['sha'] == cfg['expected_source_tree'])
tree_join(load(R / 'head-tree.json'))
pull = load(R / 'pull-request-start.json')
check('start PR original source/base/ref', pull['head']['sha'] == cfg['expected_source_commit'] and pull['base']['sha'] == cfg['expected_base_commit'] and pull['head']['ref'] == cfg['expected_head_ref'] and pull['base']['ref'] == cfg['expected_base_ref'])
source_bindings = {}
for path in sorted((R / 'source-bindings').glob('*-commit.json')):
    commit = load(path)
    identity = commit['sha']
    tree = load(path.with_name(identity + '-tree.json'))
    check('checkout commit/tree join:' + identity, tree['sha'] == commit['tree']['sha'] == cfg['expected_source_tree'])
    tree_join(tree)
    source_bindings[identity] = {'tree': tree['sha'], 'parents': [x['sha'] for x in commit['parents']], 'blob_count': len(immutable['files'])}
source_id = cfg['expected_source_commit']
merge_ids = [key for key, value in source_bindings.items() if value['parents'] == [cfg['expected_base_commit'], source_id]]
check('unique actual tested merge metadata', len(merge_ids) == 1)
merge_id = merge_ids[0]
check('original source direct ancestry retained', source_bindings[source_id]['parents'] == [parent['sha'] for parent in head['parents']])

archives = []
def audit_zip(path, destination, members):
    declared = {row['path']: row for row in members}
    rows = []
    with zipfile.ZipFile(path) as archive:
        infos = archive.infolist()
        check('ZIP finite count:' + str(path.relative_to(R)), len(infos) <= 12000)
        seen = set()
        total = 0
        for item in infos:
            name = item.filename
            check('ZIP canonical unique path:' + str(path.relative_to(R)) + ':' + name, canonical_name(name) and name.rstrip('/') not in seen)
            seen.add(name.rstrip('/'))
            mode = item.external_attr >> 16
            check('ZIP inert member kind:' + name, stat.S_IFMT(mode) in (0, stat.S_IFREG, stat.S_IFDIR))
            if item.is_dir():
                check('ZIP directory kind:' + name, stat.S_IFMT(mode) in (0, stat.S_IFDIR))
                continue
            total += item.file_size
            check('ZIP finite expansion:' + name, item.file_size <= 64 * 1024 * 1024 and total <= 512 * 1024 * 1024)
            body = archive.read(item)  # CRC is checked, bytes are never executed.
            actual = destination / name
            row = declared[name]
            check('ZIP member retained exact:' + name, len(body) == row['bytes'] == actual.stat().st_size and hashlib.sha256(body).hexdigest() == row['sha256'] == sha(actual))
            check('ZIP member mode metadata:' + name, row['zip_mode'] == mode and row['zip_create_system'] == item.create_system and row['zip_external_attr'] == item.external_attr and row['retained_full_mode'] == actual.lstat().st_mode)
            rows.append(name)
        check('ZIP all declared files accounted:' + str(path.relative_to(R)), set(rows) == set(declared))
    return {'path': str(path.relative_to(R)), 'bytes': path.stat().st_size, 'sha256': sha(path), 'regular_members': len(rows), 'total_uncompressed': total}
artifacts = []
for path in sorted((R / 'artifacts').glob('*/closure.json')):
    c = load(path)
    folder = path.parent
    metadata = load(folder / 'metadata.json')
    archive = R / c['archive']
    check('artifact metadata id/name/source:' + str(c['artifact_id']), metadata['id'] == c['artifact_id'] and metadata['name'] == c['name'] and metadata['workflow_run']['id'] == c['run'] and metadata['workflow_run']['head_sha'] == source_id)
    check('artifact ZIP closure exact:' + str(c['artifact_id']), sha(archive) == c['archive_sha256'] and archive.stat().st_size == c['archive_bytes'])
    # GitHub's digest is the upload archive digest. Retain any missing digest explicitly.
    check('artifact official digest exact:' + str(c['artifact_id']), metadata.get('digest') == 'sha256:' + sha(archive))
    members = load(folder / 'members-attempt-1.json')
    check('artifact closure member count:' + str(c['artifact_id']), len(members) == c['safe_regular_members'])
    a = audit_zip(archive, R / c['contents'], members)
    archives.append(a)
    artifacts.append({**c, 'official_digest': metadata.get('digest'), 'members_independently_joined': len(members)})
check('all seven retained artifacts exact', sorted(x['artifact_id'] for x in artifacts) == sorted(closure['artifact_ids_retained']) and len(artifacts) == 7)

jobs_seen = []
run_results = []
case_results = []
timeline = []
for expected in cfg['runs']:
    folder = R / 'runs' / str(expected['id'])
    run = load(folder / 'terminal-run.json')
    jobs = load(folder / 'terminal-jobs.json')['jobs']
    check('run exact original request:' + str(expected['id']), run['id'] == expected['id'] and run['head_sha'] == source_id and run['name'] == expected['name'] and run['path'] == expected['workflow_path'] and run['run_attempt'] == expected['attempt'] and run['event'] == 'pull_request' and run['status'] == 'completed')
    recorded = next(x for x in outcomes['runs'] if x['run_id'] == expected['id'])
    check('run summary metadata exact:' + str(expected['id']), recorded['API_conclusion'] == run['conclusion'] and [(j['id'], j['name'], j['status'], j['conclusion']) for j in jobs] == [(j['id'], j['name'], j['status'], j['conclusion']) for j in recorded['actual_jobs']])
    snapshots = []
    for sample in sorted((folder / 'snapshots').glob('*-run.json')):
        value = load(sample)
        check('every observed snapshot fixed request:' + str(sample.relative_to(R)), value['id'] == expected['id'] and value['head_sha'] == source_id and value['name'] == expected['name'] and value['path'] == expected['workflow_path'] and value['run_attempt'] == expected['attempt'] and value['event'] == 'pull_request')
        snapshots.append({'path': str(sample.relative_to(R)), 'status': value['status'], 'conclusion': value['conclusion'], 'updated_at': value['updated_at']})
    check('run snapshots retained:' + str(expected['id']), bool(snapshots))
    for listing in sorted((folder / 'snapshots/jobs').glob('*.json')):
        value = load(listing)
        check('finite one-page job list exact count:' + str(listing.relative_to(R)), value['total_count'] == len(value['jobs']) <= 100 and len({j['id'] for j in value['jobs']}) == len(value['jobs']))
        check('every observed job run bound:' + str(listing.relative_to(R)), all(j['run_id'] == expected['id'] and j['head_sha'] == source_id for j in value['jobs']))
    timeline.append({'run': expected['id'], 'snapshots': snapshots, 'started_at': run['run_started_at'], 'updated_at': run['updated_at'], 'terminal_conclusion': run['conclusion']})
    run_jobs = []
    for job in jobs:
        jid = job['id']
        jobs_seen.append(jid)
        check('closed job exact metadata:' + str(jid), load(folder / 'closed-jobs' / f'{jid}.json') == job and job['status'] == 'completed')
        log = folder / 'closed-jobs' / f'{jid}.log'
        checkout_rows = []
        if job['conclusion'] != 'skipped' and jid != 123738677855:
            check('actual non-skipped log retained:' + str(jid), log.is_file())
            text = clean_log(log)
            starts = list(re.finditer(r'(?m)^##\[group\]Run actions/checkout@[^\n]+', text))
            for index, match in enumerate(starts):
                block = text[match.start():starts[index+1].start() if index+1 < len(starts) else len(text)]
                hashes = re.findall(r'(?m)^.*log -1 --format=%H\n([0-9a-f]{40})\s*$', block)
                check('observed checkout unique HEAD hash:' + str(jid) + ':' + str(index), len(hashes) == 1)
                ref = re.search(r'(?m)^  ref: (.+)$', block)
                location = re.search(r'(?m)^  path: (.+)$', block)
                checkout_rows.append({'observed_commit': hashes[0], 'ref_parameter': ref.group(1) if ref else None, 'path_parameter': location.group(1) if location else None})
            if expected['role'] == 'disabled_policy':
                check('aux exact two observed checkout roles:' + str(jid), len(checkout_rows) == 2 and checkout_rows[0] == {'observed_commit': source_id, 'ref_parameter': source_id, 'path_parameter': 'control'} and checkout_rows[1] == {'observed_commit': merge_id, 'ref_parameter': merge_id, 'path_parameter': 'workflow-origin'})
            else:
                check('main exact default tested merge checkout:' + str(jid), len(checkout_rows) == 1 and checkout_rows[0]['observed_commit'] == merge_id)
                lines = text.splitlines()
                summaries = [line for line in lines if re.fullmatch(r'=+ \d+ failed, \d+ passed in [0-9.]+s(?: \([^\r\n]+\))? =+', line)]
                failed = [line[7:].split(' - ', 1)[0] for line in lines if line.startswith('FAILED ')]
                collection = [line for line in lines if re.match(r'^(scripts|services)/[^ ]+\.py::', line)]
                expected_ids = list(catalog['common']['node_ids']) + ([] if 'windows' in job['name'] else list(catalog['posix_only_node_ids']))
                actual_count = Counter(collection)
                expected_count = Counter(expected_ids)
                direct = sum((actual_count & expected_count).values())
                residual_actual = list((actual_count - expected_count).elements())
                residual_expected = list((expected_count - actual_count).elements())
                def stem(node): return node.split('[', 1)[0]
                check('collection total exact platform inventory:' + str(jid), len(collection) == len(expected_ids))
                check('collection function multiplicities exact:' + str(jid), Counter(map(stem, collection)) == Counter(map(stem, expected_ids)))
                check('all nonidentical collection labels are masked:' + str(jid), len(residual_actual) == len(residual_expected) and all('***' in node for node in residual_actual))
                component_rows = []
                if '== verification summary ==' in text:
                    tail = text[text.rindex('== verification summary =='):]
                    component_rows = re.findall(r'(?m)^([a-z][a-z0-9-]*)\s+ACTIVE\s+(PASS|FAIL)\s+', tail)
                    check('complete verification actual20 rows:' + str(jid), len(component_rows) == 20 and sum(value == 'PASS' for _, value in component_rows) == 19 and ('python', 'FAIL') in component_rows)
                case_results.append({'job_id': jid, 'name': job['name'], 'API_conclusion': job['conclusion'], 'collection_count': len(collection), 'expected_count': len(expected_ids), 'direct_exact_ID_count': direct, 'masked_residual_count': len(residual_actual), 'masked_observed_ids': residual_actual, 'possible_expected_ids_by_preserved_function_multiplicity': residual_expected, 'collection_is_execution_or_PASS_proof': False, 'python_terminal_summaries': summaries, 'exact_failed_ids': failed, 'actual_component_summary': component_rows, 'cancellation_line_observed': 'The operation was canceled.' in text, 'scope': 'Masked labels cannot authenticate individual parameter identity. Collection exact direct IDs and per-function multiplicity are separate from actual aggregate execution summary; no passing-case outcome invented.'})
        run_jobs.append({'id': jid, 'name': job['name'], 'conclusion': job['conclusion'], 'checkout_observations': checkout_rows})
    zip_path = folder / 'official-logs.zip'
    archives.append(audit_zip(zip_path, folder / 'logs', load(folder / 'log-members.json')))
    if expected['role'] == 'disabled_policy':
        check('aux policy jobs only success+skips:' + str(expected['id']), run['conclusion'] == 'success' and len([j for j in jobs if j['name'] == 'authorize' and j['conclusion'] == 'success']) == 1 and all(j['conclusion'] == 'skipped' for j in jobs if j['name'] != 'authorize'))
        policies = [a for a in artifacts if a['run'] == expected['id']]
        check('aux unique retained disabled request:' + str(expected['id']), len(policies) == 1)
        request = load(R / policies[0]['contents'] / 'request.json')
        check('aux explicit disabled request marker:' + str(expected['id']), request['enabled'] == 'false' and request['status'] == 'SKIP_NO_ROOT_REQUEST')
    run_results.append({'id': expected['id'], 'name': expected['name'], 'role': expected['role'], 'conclusion': run['conclusion'], 'jobs': run_jobs})
check('all thirteen terminal jobs exact', sorted(jobs_seen) == sorted(closure['closed_jobs']) and len(jobs_seen) == 13)
main = next(row for row in run_results if row['role'] == 'canonical')
check('main retained terminal cancel/failure dispositions', main['conclusion'] == 'cancelled' and {j['name']: j['conclusion'] for j in main['jobs']} == {'doctor + verify (ubuntu-24.04)': 'failure', 'doctor + verify (windows-2025)': 'failure', 'doctor + verify (macos-15)': 'cancelled', 'native development package (${{ matrix.os }})': 'cancelled'})
finish_id = 'scripts/tests/test_ubuntu_gnome_boundaries.py::test_imports_do_not_load_platform_gi_or_spawn_actor'
windows = next(row for row in case_results if 'windows' in row['name'])
ubuntu = next(row for row in case_results if 'ubuntu' in row['name'])
mac = next(row for row in case_results if 'macos' in row['name'])
check('Windows actual three failures exact', windows['exact_failed_ids'] == [finish_id, 'services/orchestrator/tests/test_generation_idle_deadline.py::test_suppressed_idle_timer_cancellation_still_refuses_success[open]', 'services/orchestrator/tests/test_generation_idle_deadline.py::test_suppressed_idle_timer_cancellation_still_refuses_success[read]'] and windows['python_terminal_summaries'] == ['================= 3 failed, 2783 passed in 681.25s (0:11:21) =================='])
check('Ubuntu actual sole finish failure exact', ubuntu['exact_failed_ids'] == [finish_id] and ubuntu['python_terminal_summaries'] == ['================== 1 failed, 2787 passed in 684.62s (0:11:24) =================='])
check('Mac cancellation remains incomplete not Python PASS/FAIL', mac['python_terminal_summaries'] == [] and mac['actual_component_summary'] == [] and mac['cancellation_line_observed'])
check('no package export candidates', all(not run['retained_package_export_candidates'] for run in outcomes['runs']))
mismatches = [row for row in closure['failures'] if row['kind'] == 'CHECKOUT_SOURCE_BINDING_MISMATCH']
check('four original aux observer mismatches preserved', len(mismatches) == 4 and {row['job'] for row in mismatches} == {123718724364, 123718725239, 123718724089, 123718724255} and all(row['observed_commit'] == source_id for row in mismatches))
result = {'utc': datetime.now(UTC).isoformat(), 'checks': checks, 'check_count': len(checks), 'all_data_checks_pass': all(row['pass'] for row in checks), 'source_commit': source_id, 'source_tree': cfg['expected_source_tree'], 'source_blobs': len(immutable['files']), 'actual_tested_merge_commit': merge_id, 'source_bindings': source_bindings, 'API_receipt_count': len(receipts), 'API_failed_receipts': api_failures, 'actual_runs': run_results, 'retained_run_timeline': timeline, 'case_scope': case_results, 'archives': archives, 'artifacts': artifacts, 'original_collector_failures': closure['failures'], 'role_aware_aux_mismatch_disposition': 'Four original collector labels are a first-checkout/unconditional-merge-parent observer defect. Observed direct control S and separate workflow-origin merge both source-bound. Labels remain unchanged in raw records.', 'product_conclusion': 'CONFIRMED_CI_FAILURES_AND_CANCELLATION_NOT_ALL_PASS', 'scope': 'Inert retained official API/log/archive evidence only. No API refresh, rerun, native/package/model/runtime activation, canonical mutation, passing-case identity guess, or current/end PR-head assertion. Actual failures not waived by successful data joins. Root reports superseding push under existing cancellation policy; retained API terminal state/log alone does not encode cancellation initiator/reason.'}
(H / 'data-review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('check_count', 'all_data_checks_pass', 'API_receipt_count', 'actual_tested_merge_commit', 'product_conclusion')}))
