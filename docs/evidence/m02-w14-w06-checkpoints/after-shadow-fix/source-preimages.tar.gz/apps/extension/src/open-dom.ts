// W14 supported open-shadow boundary. These helpers discover current DOM
// evidence; no node handle, root order or selector becomes durable identity.
// Closed roots and custom shadow widgets have no support claim.
export const MAX_OPEN_TREE_ELEMENTS = 16_384;
export const MAX_OPEN_SHADOW_ROOTS = 64;
export const MAX_OPEN_SHADOW_DEPTH = 8;

export type OpenTreeCapture =
  | {
      readonly status: "COMPLETE";
      readonly elements: readonly Element[];
      readonly shadowRoots: readonly ShadowRoot[];
    }
  | { readonly status: "CAPACITY_EXCEEDED" };

/** Physical DOM traversal, including each reachable open root exactly once.
 * Element/root/depth limits refuse the whole capture; never return a prefix. */
export function captureOpenTree(
  root: Element | Document | ShadowRoot,
): OpenTreeCapture {
  const elements: Element[] = [];
  const shadowRoots: ShadowRoot[] = [];
  const stack: { element: Element; depth: number }[] = [];
  function pushChildren(
    parent: Element | Document | ShadowRoot,
    depth: number,
  ): boolean {
    // Push in reverse physical order without allocating an unbounded child array.
    for (
      let element = parent.lastElementChild;
      element !== null;
      element = element.previousElementSibling
    ) {
      if (stack.length + elements.length >= MAX_OPEN_TREE_ELEMENTS)
        return false;
      stack.push({ element, depth });
    }
    return true;
  }
  if (root instanceof Element) stack.push({ element: root, depth: 0 });
  else if (!pushChildren(root, 0)) return { status: "CAPACITY_EXCEEDED" };
  while (stack.length > 0) {
    const item = stack.pop();
    if (item === undefined) break;
    elements.push(item.element);
    if (elements.length > MAX_OPEN_TREE_ELEMENTS)
      return { status: "CAPACITY_EXCEEDED" };
    if (!pushChildren(item.element, item.depth))
      return { status: "CAPACITY_EXCEEDED" };
    const shadow = item.element.shadowRoot;
    if (shadow !== null) {
      shadowRoots.push(shadow);
      if (
        shadowRoots.length > MAX_OPEN_SHADOW_ROOTS ||
        item.depth >= MAX_OPEN_SHADOW_DEPTH
      )
        return { status: "CAPACITY_EXCEEDED" };
      if (!pushChildren(shadow, item.depth + 1))
        return { status: "CAPACITY_EXCEEDED" };
    }
    if (stack.length + elements.length > MAX_OPEN_TREE_ELEMENTS)
      return { status: "CAPACITY_EXCEEDED" };
  }
  return { status: "COMPLETE", elements, shadowRoots };
}

export function composedParent(element: Element): Element | null {
  if (element.assignedSlot !== null) return element.assignedSlot;
  if (element.parentElement !== null) return element.parentElement;
  const root = element.getRootNode();
  return root instanceof ShadowRoot && root.mode === "open" ? root.host : null;
}

export function composedContains(parent: Element, child: Element): boolean {
  for (
    let current: Element | null = child;
    current !== null;
    current = composedParent(current)
  )
    if (current === parent) return true;
  return false;
}

export function composedClosest(
  element: Element,
  selector: string,
): Element | null {
  for (
    let current: Element | null = element;
    current !== null;
    current = composedParent(current)
  )
    if (current.matches(selector)) return current;
  return null;
}

/** IDREFs are local to the control's tree. Shadow IDs must never resolve
 * to unrelated document IDs or another root; duplicate local IDs abstain. */
export function localIdReference(
  element: Element,
  id: string,
): HTMLElement | null {
  const root = element.getRootNode();
  if (root instanceof Document) return root.getElementById(id);
  if (!(root instanceof ShadowRoot) || root.mode !== "open") return null;
  const matches = [...root.querySelectorAll<HTMLElement>("[id]")].filter(
    (node) => node.id === id,
  );
  return matches.length === 1 ? (matches[0] ?? null) : null;
}

export function hasAmbiguousLocalReference(
  element: Element,
  attribute: string,
): boolean {
  const root = element.getRootNode();
  if (!(root instanceof ShadowRoot)) return false;
  const ids = (element.getAttribute(attribute) ?? "")
    .split(/\s+/)
    .filter(Boolean);
  const capture = captureOpenTree(root);
  if (capture.status !== "COMPLETE") return true;
  return ids.some(
    (id) =>
      capture.elements.filter(
        (node) => node.getRootNode() === root && node.id === id,
      ).length > 1,
  );
}

export function sameOpenRoots(
  left: readonly ShadowRoot[],
  right: readonly ShadowRoot[],
): boolean {
  return (
    left.length === right.length && left.every((root, i) => root === right[i])
  );
}
