# Exact Python body executed through the tool's stdin heredoc; retained afterward.
from pathlib import Path
import hashlib,stat,json,py_compile,os,subprocess,datetime
R=Path('/Users/tanishkalwad/jobapplyv2');E=R.parent/'jobapplyv2-evidence/resume-20261028';P=E/'owned-cache-regeneration-preparation/v1';O=E/'owned-cache-regeneration-actual/v1';O.mkdir(parents=True)
rows=json.loads((P/'BEFORE.json').read_text())['records']
def row(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink() and s.st_uid==os.getuid() and s.st_nlink==1
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'full_mode':s.st_mode,'dev':s.st_dev,'ino':s.st_ino,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'uid':s.st_uid,'nlink':s.st_nlink}
def whole():
 names=[os.fsdecode(x) for x in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=R).split(b'\0') if x]
 return {'source':{n:row(R/n) for n in names},'runtime':{p.relative_to(R).as_posix():row(p) for p in sorted((R/'apps/desktop/src-tauri/runtime-payload').rglob('*')) if p.is_file()},'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=R,text=True)}
cachepaths=[R/'scripts/linux_gnome/__pycache__',R/'scripts/windows11/__pycache__']
def caches():return {p.relative_to(R).as_posix():row(p) for d in cachepaths for p in sorted(d.iterdir()) if p.is_file()}
for item in rows:
 assert row(R/item['source_path'])==item['source']
 assert row(R/item['cache_path'])==item['cache']
 assert item['header_stale'] is True
before=whole();prior=caches();(O/'before.json').write_text(json.dumps({'canonical':before,'caches':prior},indent=2)+'\n');actions=[]
for item in rows:
 source=R/item['source_path'];cache=R/item['cache_path'];copy=O/'retained-before'/item['cache_path'];copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(cache.read_bytes());os.chmod(copy,stat.S_IMODE(cache.lstat().st_mode));assert row(source)==item['source'] and row(cache)==item['cache']
 py_compile.compile(str(source),cfile=str(cache),dfile=str(source),doraise=True,optimize=0,invalidation_mode=py_compile.PycInvalidationMode.TIMESTAMP)
 after=row(cache);assert cache.read_bytes()[:16].hex()==item['current_source_expected_header_hex'];actions.append({'source':item['source_path'],'cache':item['cache_path'],'before':item['cache'],'after':after})
 (O/'actions.json').write_text(json.dumps(actions,indent=2)+'\n')
post=caches();allowed={x['cache_path'] for x in rows};assert set(post)==set(prior);assert all(post[n]==r for n,r in prior.items() if n not in allowed);assert before==whole()
(O/'closure.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.UTC).isoformat(),'exact_five_owned_stale_caches_regenerated':len(actions)==5,'other_cache_endpoints_equal':True,'canonical_source_runtime_git_endpoints_equal':True,'source_files':len(before['source']),'runtime_files':len(before['runtime']),'compiler':'CPython3.12.13 standard py_compile timestampflags0 optimize0 exactabsolute source filename; source notexecuted; oldbytes retained'},indent=2)+'\n');print('Regenerated exactly5owned known stale caches; all other caches and canonical/runtime/Git endpoints equal')
