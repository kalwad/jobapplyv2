Outside W09 functional correction v2, source only.

Start with `REVIEW.md`, then `ADOPTION-MAP.json`. `after/` contains every complete prospective source afterimage. `prospective-current.patch` compares against the retained current preimages; `corrections-vs-original.patch` isolates the fresh corrections and current FIFO composition from the exact donor. Five identical existing files in the map should be preserved without rewriting. Require all recorded existing SHA-256/modes and all addition-absence guards before adopting the 8 replacements and 19 additions. Do not apply over a drifting root.

`test-body-correspondence.json` records source-body equality, not execution. The original 91-case inventory is joined separately in `original-w09-oracle-preservation.json`. Current SDK source and exact OS-prefix observations are retained separately; they do not replace an actual app/SDK round-trip. Original native review findings and independently prepared probe correction remain intact in sibling folders.

The POSIX threat boundary is explicit in the source/review: private 0700 workspace, serialized in-process mutation and OS per-user isolation; hostile same-UID namespace mutation after verification is detected but cannot be atomically prevented by unlinkat. The regression source intentionally retains that counterproof. No fail-all POSIX fallback, weakened original assertion, placeholder implementation or M04 foundation/capsule integration is included.

Canonical writes/compilers/tests/native actors: zero. Root independent review and actual integrated validation are required; no milestone or release status is promoted.
