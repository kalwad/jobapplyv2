Independent read-only correspondence PASS. The separately implemented Rust token scanner compared complete test signatures/bodies while preserving string, character and raw literal content and ignoring only comments/formatting. All 182 donor test bodies and all 94 preimage test bodies in the 32-path integration are token-identical to current canonical source. No product code was executed.

All 238 case names from the prior actual runtime-preflight catalog remain in the actual v1 340-name native catalog. All 91 original W09 declaration names join exactly once to that actual catalog. This establishes collection/preservation; actual v1 execution still failed five newly added POSIX cleanup cases. Current corrected-source execution is separate and pending.

The audit and detailed correspondence are retained in audit-test-preservation.py and test-preservation-checks.json. The data SHA-256 is 7e7822ec7b614872e8df235a3e8b733f37767ca2b2b6247c405a53745297a9b1.
