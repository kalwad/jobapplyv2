from pathlib import Path
import hashlib,json,re,stat
B=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
R=Path('/Users/tanishkalwad/jobapplyv2')
O=B/'w09-native-independent-review'
F=B/'w09-current-integration-review/functional-correction-v2'
D=B/'w09-current-integration-review/darwin-namespace-settlement-v3'
V=B/'w09-native-actual-v2'
checks=[]
def ck(name,value,detail=None): checks.append({'name':name,'pass':bool(value),'detail':detail})
def j(p):return json.loads(p.read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
a=j(V/'before.json');z=j(V/'after.json');v1=j(B/'w09-native-actual-v1/before.json')
ck('Source/runtime/status/permission-mode endpoint equality',a==z)
ck('2055 source entries',len(a['source'])==2055)
ck('40 runtime entries',len(a['runtime'])==40)
ck('Source inventory hash/size/mode schemas',all(set(x)=={'bytes','mode','sha256'} and isinstance(x['bytes'],int) and isinstance(x['mode'],int) and len(x['sha256'])==64 for x in a['source'].values()))
ck('Runtime inventory hash/size/mode schemas',all(set(x)=={'bytes','mode','sha256'} and isinstance(x['bytes'],int) and isinstance(x['mode'],int) and len(x['sha256'])==64 for x in a['runtime'].values()))
ck('Dirty evaluated tree stated',bool(a['git_status'].strip()))
context=j(V/'context.json');closure=j(V/'closure.json');results=j(V/'results.json')
ck('Initial reference head35b',context['head']=='35b46287dc754a5987d653490ab49f978647ca26')
ck('Chronological actual timestamps',context['start_utc']<closure['end_utc'])
ck('Eleven planned/executed actual phases',len(results)==closure['executed_phases']==closure['planned_phases']==11)
ck('Closure reports allpass/neutrality',closure['all_pass'] and closure['source_runtime_status_modes_unchanged'])
expected=['format','default-compile','default-catalog','default-clippy','default-tests','all-features-clippy','all-features-tests','custom-protocol-clippy','custom-protocol-tests','windows-source-check','custom-protocol-build']
ck('Actual ordered phase names', [x['name'] for x in results]==expected)
for row in results:
    n=row['name'];p=V/(n+'.log')
    ck(n+' retained regular raw log',p.is_file() and stat.S_ISREG(p.lstat().st_mode))
    ck(n+' zero exit/no timeout/reaped/group absent/no signals',row['exit_code']==0 and not row['timeout'] and row['direct_child_reaped'] and row['observed_group']=='ABSENT' and not row['outer_cleanup_signals'])
    ck(n+' locked manifest command',row['argv'][:2]==['cargo','fmt'] or ('--locked' in row['argv'] and row['argv'][row['argv'].index('--manifest-path')+1]=='apps/desktop/src-tauri/Cargo.toml'))
    if n.endswith('clippy'):ck(n+' strict alltargets', '--all-targets' in row['argv'] and row['argv'][-3:]==['--','-D','warnings'])
cat=set(re.findall(r'^(\S+): test$',(V/'default-catalog.log').read_text(),re.M))
ck('342 unique actual defaultcatalog',len(cat)==342)
for mode in ['default','all-features','custom-protocol']:
    log=(V/(mode+'-tests.log')).read_text();pairs=re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)$',log,re.M)
    ck(mode+'342unique testcase outcomes',len(pairs)==342 and len({n for n,s in pairs})==342)
    ck(mode+'342pass no failed/ignored',all(s=='ok' for n,s in pairs) and '342 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in log)
    ck(mode+' exact actual catalognames', {n for n,s in pairs}==cat)
old=j(B/'runtime-preflight-fix/actual-focus/default-catalog.json')
ck('All238prior actual native casenames remain',len(old)==238 and set(old)<=cat)
inv=j(B/'w09-restoration/w09-declared-test-inventory.json')
names=[n for f in inv['files'] for n in f['new_declarations_not_collected']]
ck('All91originalW09 cases actual collected',len(names)==91 and all(sum(k.endswith('::'+n) for k in cat)==1 for n in names))
selectors=j(D/'HANDOFF.json')['focused_selectors']
ck('All7focused actual cases partofallthree suites',len(selectors)==7 and set(selectors)<=cat)
v1cat=set(re.findall(r'^(\S+): test$',(B/'w09-native-actual-v1/default-catalog.log').read_text(),re.M))
new=cat-v1cat
ck('Actual342 retainsall340 adds2',len(v1cat)==340 and v1cat<=cat and len(new)==2,sorted(new))
source_delta=sorted(k for k in set(a['source'])|set(v1['source']) if a['source'].get(k)!=v1['source'].get(k))
expected_delta=sorted(row['path'] for row in j(D/'HANDOFF.json')['paths'])
ck('Only2sealedDarwin files changed sincev1',source_delta==expected_delta,source_delta)
ck('Runtime40unchanged sincev1',a['runtime']==v1['runtime'])
ck('Dirty status same sincev1',a['git_status']==v1['git_status'])
mapdata=j(F/'ADOPTION-MAP.json');dmap={row['path']:row for row in j(D/'HANDOFF.json')['paths']}
retained=[]
for row in mapdata['afterimages']:
    rel=row['path'];p=(D/'after'/rel) if rel in dmap else (F/'after'/rel)
    ck('Actual evaluated pinned source '+rel,digest(p)==a['source'][rel]['sha256'] and p.stat().st_size==a['source'][rel]['bytes'])
    ck('Actual evaluated0600/0644 source mode '+rel,stat.S_IMODE(p.lstat().st_mode)==a['source'][rel]['mode'])
    retained.append({'path':rel,'retained_source':str(p),'bytes':p.stat().st_size,'sha256':digest(p),'mode':stat.S_IMODE(p.lstat().st_mode)})
protected=[]
for row in mapdata['protected_current_paths']:
    rel=row['path'];p=F/'protected-preimages'/rel
    ck('Protected source exact '+rel,digest(p)==a['source'][rel]['sha256'] and p.stat().st_size==a['source'][rel]['bytes'])
    protected.append({'path':rel,'retained_source':str(p),'bytes':p.stat().st_size,'sha256':digest(p),'mode':stat.S_IMODE(p.lstat().st_mode)})
# Confirm the read-only reviewed bodies remain the same exact evaluated bytes;
# future source work is not silently made part of this historical result.
current_projection=[]
for row in retained+protected:
    p=R/row['path'];same=p.is_file() and digest(p)==row['sha256']
    current_projection.append({'path':row['path'],'still_exact_at_review':same})
ck('All44evaluated/protected current projections still exact at review',all(x['still_exact_at_review'] for x in current_projection))
ck('Source guard tests in actual three modes',all(any(n.endswith('::'+case) for n in cat) for case in ['cancel_during_probe_verification_starts_no_native_create','deadline_during_probe_verification_starts_no_native_create','live_original_probe_permit_admits_one_prepared_create','observed_root_owned_var_alias_normalizes_only_the_system_prefix']))
ck('No check failures',all(x['pass'] for x in checks))
index={p.relative_to(V).as_posix():{'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(V.rglob('*')) if p.is_file()}
report={'scope':'INDEPENDENT_RETAINED_ACTUAL_NATIVE_DATA_REVIEW_NO_PRODUCT_EXECUTION','verdict':'CLEAR' if all(x['pass'] for x in checks) else 'HOLD','checks':checks,'actual_context':context,'actual_closure':closure,'source_projection':retained,'protected_projection':protected,'projection_still_exact_at_review':current_projection,'actual_receipt_index':index,'unverified':['Actual NativePaths::from_app current SDK data/cache/temp roundtrip','Native Windows/Ubuntu execution or target certification','Clean committed-source full-project validation','GUI/package validation after this production integration','M04storage/capsule or M05modelqualification'],'states':{'M03-W06':'IN_PROGRESS','M03-W09':'NOT_STARTED','M03':'IN_PROGRESS','verified':38,'release':'NOT_READY'}}
(O/'actual-data-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'verdict':report['verdict'],'checks':len(checks),'passed':sum(x['pass'] for x in checks),'failures':[x['name'] for x in checks if not x['pass']],'retained_receipts':len(index)}))
