from pathlib import Path
import hashlib, json, re
ROOT=Path('/Users/tanishkalwad/jobapplyv2')
BASE=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
OUT=BASE/'w09-native-independent-review'
PACK=BASE/'w09-current-integration-review/darwin-namespace-settlement-v3'
F=BASE/'w09-current-integration-review/functional-correction-v2'
checks=[]
def ck(name,condition,detail=None):
    checks.append({'name':name,'pass':bool(condition),'detail':detail})
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
h=json.loads((PACK/'HANDOFF.json').read_text())
ck('Sealed v3 handoff pin',sha(PACK/'HANDOFF.json')=='ded9820c501a6825b900de54ffc3236f4aa15f82148df5e311588b486c3c8672')
ck('Sealed correction patch pin',sha(PACK/'correction.patch')=='0ab42232eff2748f1136f1f6672d1619a27fa05af5601985ad90ad345b653e81')
for row in h['paths']:
    for variant in ['before','after']:
        p=PACK/variant/row['path']
        ck(f'{variant} bytes/hash {row["path"]}',p.stat().st_size==row[variant]['bytes'] and sha(p)==row[variant]['sha256'])
    ck('Canonical preimage '+row['path'],sha(ROOT/row['path'])==row['before']['sha256'])
for row in h['actual_first_failure_preserved']:
    p=Path(row['path']);ck('Retained original receipt '+p.parent.name+'/'+p.name,p.stat().st_size==row['bytes'] and sha(p)==row['sha256'])
v1=BASE/'w09-native-actual-v1'
a=json.loads((v1/'before.json').read_text());b=json.loads((v1/'after.json').read_text())
ck('v1 source/runtime/status/modes identical',a==b)
ck('v1 actual source count',len(a['source'])==2055)
ck('v1 actual runtime count',len(a['runtime'])==40)
results=json.loads((v1/'results.json').read_text())
ck('v1 five actual phases only',len(results)==5)
ck('v1 four preceding success receipts',[r['exit_code'] for r in results]==[0,0,0,0,101])
ck('v1 no timeout/cleanup all groups absent',all(not r['timeout'] and r['direct_child_reaped'] and r['observed_group']=='ABSENT' and not r['outer_cleanup_signals'] for r in results))
log=(v1/'default-tests.log').read_text()
parsed=re.findall(r'^test (\S+) \.\.\. (ok|FAILED)$',log,re.M)
ck('v1 340 unique actual results',len(parsed)==340 and len({n for n,s in parsed})==340)
ck('v1 335 pass five failures',sum(s=='ok' for n,s in parsed)==335 and sum(s=='FAILED' for n,s in parsed)==5)
ck('v1 all five failures local new cleanup cases',all('platform_adapters::posix_paths::cleanup_tests::' in n for n,s in parsed if s=='FAILED'))
cat=(v1/'default-catalog.log').read_text(); names=re.findall(r'^(\S+): test$',cat,re.M)
ck('v1 catalog/results exact',len(names)==340 and set(names)=={n for n,s in parsed})
for p in [F/'ADOPTION-MAP.json',F/'HANDOFF.json']:
    ck('Retained functional-v2 '+p.name,p.is_file())
m=json.loads((F/'ADOPTION-MAP.json').read_text())
ck('functional-v2 exact32 paths',len(m['afterimages'])==32)
for row in m['afterimages']:
    p=F/'after'/row['path']
    ck('functional-v2 afterimage pin '+row['path'],p.is_file() and sha(p)==row['after']['sha256'])
    ck('v1 snapshot bound to functional-v2 '+row['path'],a['source'][row['path']]['sha256']==row['after']['sha256'])
obs=json.loads((BASE/'w09-directory-unlink-observation-v3/observation.json').read_text())
ck('Actual APFS held directory nlink unchanged2',obs['before']['held']['nlink']==obs['after_unlink_original']['held']['nlink']==2)
ck('Actual APFS live rename updated held path',obs['live_original_moved_replacement_at_name']['fcntl']['F_GETPATH_NOFIRMLINK']['result'].endswith('/moved'))
ck('Actual APFS removed descriptor retained old path',obs['after_unlink_original']['fcntl']['F_GETPATH_NOFIRMLINK']['result'].endswith('/owned'))
ck('Actual APFS old owned name absent after removal',obs['after_unlink_original']['named_owned']['errno']==2)
ck('No static check failure',all(c['pass'] for c in checks))
(OUT/'source-data-checks.json').write_text(json.dumps({'scope':'INDEPENDENT_READ_ONLY_SOURCE_AND_RETAINED_DATA_REVIEW_NO_EXECUTION','checks':checks},indent=2)+'\n')
print(json.dumps({'checks':len(checks),'pass':sum(c['pass'] for c in checks),'fail':[c['name'] for c in checks if not c['pass']]}))
