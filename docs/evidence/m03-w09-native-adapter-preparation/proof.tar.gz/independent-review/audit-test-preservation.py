from pathlib import Path
import re,json,hashlib
BASE=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
OUT=BASE/'w09-native-independent-review'
F=BASE/'w09-current-integration-review/functional-correction-v2'
DONOR=BASE/'w09-restoration/verified-donor'
ROOT=Path('/Users/tanishkalwad/jobapplyv2')
def tokens(s):
    out=[];i=0
    while i<len(s):
        if s[i].isspace(): i+=1;continue
        if s.startswith('//',i):
            e=s.find('\n',i);i=len(s) if e<0 else e+1;continue
        if s.startswith('/*',i):
            depth=1;i+=2
            while depth:
                if s.startswith('/*',i): depth+=1;i+=2
                elif s.startswith('*/',i):depth-=1;i+=2
                else:i+=1
                if i>len(s): raise ValueError('comment')
            continue
        m=re.match(r'(?:b|c)?r(#+)?"',s[i:])
        if m:
            close='"'+(m.group(1) or '');e=s.find(close,i+len(m.group()))
            if e<0:raise ValueError('raw string')
            e+=len(close);out.append((s[i:e],i));i=e;continue
        m=re.match(r'(?:b|c)?"',s[i:])
        if m:
            e=i+len(m.group())
            while e<len(s):
                if s[e]=='\\':e+=2
                elif s[e]=='"': e+=1;break
                else:e+=1
            out.append((s[i:e],i));i=e;continue
        m=re.match(r"(?:b)?'(?:\\(?:[^ux]|x[0-9A-Fa-f]{2}|u\{[0-9A-Fa-f_]+\})|[^'\\\n])'",s[i:])
        if m:
            e=i+len(m.group());out.append((s[i:e],i));i=e;continue
        m=re.match(r'[A-Za-z_][A-Za-z_0-9]*|[0-9][A-Za-z_0-9]*',s[i:])
        if m:
            e=i+len(m.group());out.append((s[i:e],i));i=e;continue
        out.append((s[i],i));i+=1
    return out

def tests(s):
    ts=tokens(s);out={}
    for index,(v,pos) in enumerate(ts):
        if v!='#' or [x[0] for x in ts[index:index+4]]!=['#','[','test',']']:continue
        k=index+4
        # Optional extra cfg/attributes appear before the declaration.
        while ts[k][0]!='fn':
            k+=1
        name=ts[k+1][0];b=k+2
        while ts[b][0]!='{': b+=1
        e=b+1;depth=1
        while depth:
            if ts[e][0]=='{':depth+=1
            elif ts[e][0]=='}':depth-=1
            e+=1
        if name in out:raise ValueError('duplicate '+name)
        out[name]=[x[0] for x in ts[k:e]]
    return out

m=json.loads((F/'ADOPTION-MAP.json').read_text())
rows=[]
for row in m['afterimages']:
    rel=row['path']
    if not rel.endswith('.rs'):continue
    after=tests((ROOT/rel).read_text())
    for kind,path in [('donor',DONOR/rel),('current-preimage',F/'preimages'/rel)]:
        if not path.is_file():continue
        before=tests(path.read_text())
        for name,body in before.items():
            actual=after.get(name)
            rows.append({'source':kind,'path':rel,'test':name,'present':actual is not None,'identical_tokens':actual==body,'source_body_sha256':hashlib.sha256(json.dumps(body,ensure_ascii=False).encode()).hexdigest(),'actual_body_sha256':None if actual is None else hashlib.sha256(json.dumps(actual,ensure_ascii=False).encode()).hexdigest()})
oldcat=json.loads((BASE/'runtime-preflight-fix/actual-focus/default-catalog.json').read_text())
catlog=(BASE/'w09-native-actual-v1/default-catalog.log').read_text();cat=set(re.findall(r'^(\S+): test$',catlog,re.M))
# The earlier independently retained actual 238-name inventory uses names list.
print('old catalog type',type(oldcat).__name__)
print('old catalog keys',list(oldcat)[:6] if isinstance(oldcat,dict) else len(oldcat))
inv=json.loads((BASE/'w09-restoration/w09-declared-test-inventory.json').read_text())
new=[name for row in inv['files'] for name in row['new_declarations_not_collected']]
newjoins=[{'name':n,'matched_actual_names':sorted(k for k in cat if k.endswith('::'+n))} for n in new]
report={'scope':'INDEPENDENT_RUST_TEST_TOKEN_CORRESPONDENCE_AND_ACTUAL_CATALOG_JOIN_NO_PRODUCT_EXECUTION','lexer':'Read-only Rust token scanner preserves string/char/raw literal contents and removes comments/formatting only. Test fn signature and full balanced body compared.','rows':rows,'counts':{kind:sum(r['source']==kind for r in rows) for kind in ['donor','current-preimage']},'all_exact':all(r['identical_tokens'] for r in rows),'original91_actual_catalog_joins':newjoins,'all91_collected_exactly_once':len(newjoins)==91 and all(len(r['matched_actual_names'])==1 for r in newjoins)}
(OUT/'test-preservation-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'counts':report['counts'],'all_exact':report['all_exact'],'failures':[{'kind':r['source'],'path':r['path'],'name':r['test']} for r in rows if not r['identical_tokens']],'original91_catalog_once':report['all91_collected_exactly_once']}))
