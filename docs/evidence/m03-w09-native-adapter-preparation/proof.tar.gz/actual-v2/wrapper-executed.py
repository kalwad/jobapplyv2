from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import stat
import subprocess
import time

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
OUT = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/w09-native-actual-v2')
OUT.mkdir(exist_ok=False)
MANIFEST = 'apps/desktop/src-tauri/Cargo.toml'

def inventory():
    raw = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=ROOT)
    files = {}
    for name in sorted(set(os.fsdecode(p) for p in raw.split(b'\0') if p)):
        p = ROOT / name
        info = p.lstat()
        assert stat.S_ISREG(info.st_mode), name
        files[name] = {'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
    runtime = {}
    base = ROOT / 'apps/desktop/src-tauri/runtime-payload'
    for p in sorted(base.rglob('*')):
        info = p.lstat()
        if stat.S_ISDIR(info.st_mode):
            continue
        assert stat.S_ISREG(info.st_mode)
        runtime[p.relative_to(base).as_posix()] = {'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
    return {'source': files, 'runtime': runtime, 'git_status': subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=ROOT, text=True)}

before = inventory()
(OUT / 'before.json').write_text(json.dumps(before, indent=2, sort_keys=True) + '\n')
(OUT / 'wrapper-executed.py').write_bytes(Path(__file__).read_bytes())
(OUT / 'context.json').write_text(json.dumps({'start_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()}, indent=2) + '\n')
commands = [
    ('format', ['cargo', 'fmt', '--manifest-path', MANIFEST, '--', '--check'], 60),
    ('default-compile', ['cargo', 'test', '--manifest-path', MANIFEST, '--locked', '--lib', '--no-run'], 180),
    ('default-catalog', ['cargo', 'test', '--manifest-path', MANIFEST, '--locked', '--lib', '--', '--list'], 60),
]
for name, flags in [('default', []), ('all-features', ['--all-features']), ('custom-protocol', ['--features', 'custom-protocol'])]:
    commands.append((name + '-clippy', ['cargo', 'clippy', '--manifest-path', MANIFEST, '--locked', '--all-targets', *flags, '--', '-D', 'warnings'], 180))
    commands.append((name + '-tests', ['cargo', 'test', '--manifest-path', MANIFEST, '--locked', '--lib', *flags], 180))
commands.extend([
    ('windows-source-check', ['cargo', 'check', '--manifest-path', MANIFEST, '--locked', '--features', 'platform-adapter-source-check'], 180),
    ('custom-protocol-build', ['cargo', 'build', '--manifest-path', MANIFEST, '--locked', '--features', 'custom-protocol'], 180),
])
env = dict(os.environ)
env['PATH'] = '/opt/homebrew/opt/node@24/bin:' + env['PATH']
results = []
for name, argv, budget in commands:
    started = time.monotonic()
    signals = []
    timeout = False
    with (OUT / (name + '.log')).open('wb') as log:
        child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = child.wait(timeout=budget)
        except subprocess.TimeoutExpired:
            timeout = True
            for sig in (signal.SIGTERM, signal.SIGKILL):
                try:
                    os.killpg(child.pid, sig)
                    signals.append(sig.name)
                except ProcessLookupError:
                    pass
                if sig == signal.SIGTERM:
                    time.sleep(1)
            code = child.wait(timeout=10)
    try:
        os.killpg(child.pid, 0)
        group = 'PRESENT_AFTER_DIRECT_CHILD_REAP; NO_POST_REAP_SIGNAL'
    except ProcessLookupError:
        group = 'ABSENT'
    row = {'name': name, 'argv': argv, 'exit_code': code, 'timeout': timeout, 'seconds': time.monotonic() - started, 'direct_child_reaped': child.returncode is not None, 'observed_group': group, 'outer_cleanup_signals': signals}
    results.append(row)
    (OUT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    if code or group != 'ABSENT':
        break
after = inventory()
(OUT / 'after.json').write_text(json.dumps(after, indent=2, sort_keys=True) + '\n')
closure = {'end_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'source_count': len(before['source']), 'runtime_count': len(before['runtime']), 'source_runtime_status_modes_unchanged': before == after, 'executed_phases': len(results), 'planned_phases': len(commands), 'all_pass': len(results) == len(commands) and all(r['exit_code'] == 0 and not r['timeout'] and r['observed_group'] == 'ABSENT' for r in results)}
(OUT / 'closure.json').write_text(json.dumps(closure, indent=2) + '\n')
print(json.dumps(closure), flush=True)
raise SystemExit(0 if closure['all_pass'] and before == after else 1)
