from __future__ import annotations
import ast
import hashlib
import json
import re
import shutil
from pathlib import Path

base = Path('/tmp/japp-w14-windows-fixture-utf8')
ci = Path('/tmp/japp-w14-d99-ci')
validator = ast.parse((ci / 'd99-validate_status.py').read_text(encoding='utf-8'))
selected = []
for node in validator.body:
    if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id.startswith('OWNER_HOLDOUT_WAIVER_') for t in node.targets):
        selected.append(node)
    elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name) and node.target.id.startswith('OWNER_HOLDOUT_WAIVER_'):
        selected.append(node)
    elif isinstance(node, ast.FunctionDef) and node.name in {'_owner_holdout_waiver_preimage', '_owner_holdout_waiver_digest', '_owner_holdout_waived'}:
        selected.append(node)
namespace = {'Path': Path, 'hashlib': hashlib, 're': re}
exec(compile(ast.Module(body=selected, type_ignores=[]), '<exact d99 pure authority helper>', 'exec'), namespace)
heading = namespace['OWNER_HOLDOUT_WAIVER_HEADING']
digest = namespace['_owner_holdout_waiver_digest']
original = (ci / 'd99-DECISIONS.md').read_bytes()
repo = base / 'diagnostic-repo'
(repo / 'docs').mkdir(parents=True, exist_ok=True)
path = repo / 'docs/DECISIONS.md'
path.write_bytes(original)
initial_digest = digest(repo)
assert initial_digest == 'sha256:a76132ab96294a6e1b69c985ffd7f420ff6df96e3a121a579a734814c276647a'
rows = []
for encoding in ['cp1252', 'utf-8']:
    text = original.decode(encoding)
    heading_present = heading in text
    split_parts = len(text.split(heading, 1))
    changed = text.replace(heading + '\n', heading + '\n\n- Additional accepted-record context.\n', 1)
    path.write_bytes(changed.encode(encoding))
    own_digest = digest(repo)
    later = text.replace('## ADR template', '### ADR-9999 — Unrelated synthetic later decision\n\n- Status: PROPOSED\n\n## ADR template', 1)
    path.write_bytes(later.encode(encoding))
    later_digest = digest(repo)
    rejected = {}
    if heading_present:
        prefix, section = text.split(heading, 1)
        for state in ['PROPOSED', 'REJECTED', 'SUPERSEDED']:
            path.write_bytes((prefix + heading + section.replace('- Status: ACCEPTED', '- Status: ' + state, 1)).encode(encoding))
            rejected[state] = digest(repo) is None
    rows.append({'encoding_model': encoding, 'heading_present': heading_present, 'split_part_count': split_parts, 'own_record_replace_changed': changed != text, 'own_record_digest': own_digest, 'own_record_digest_changed': own_digest != initial_digest, 'unrelated_later_digest': later_digest, 'unrelated_later_preserved': later_digest == initial_digest, 'unaccepted_states_refused': rejected})
assert rows[0]['heading_present'] is False and rows[0]['split_part_count'] == 1
assert rows[0]['own_record_replace_changed'] is False and rows[0]['own_record_digest_changed'] is False
assert rows[0]['unrelated_later_digest'] is None
assert rows[1]['heading_present'] is True and rows[1]['own_record_digest_changed'] is True
assert rows[1]['unrelated_later_preserved'] is True and all(rows[1]['unaccepted_states_refused'].values())
result = {'scope': 'Pure deterministic encoding contrast using exact d99 production helper and DECISIONS preimage; not native Windows or pytest execution', 'source_decisions_sha256': hashlib.sha256(original).hexdigest(), 'initial_digest': initial_digest, 'rows': rows}
(base / 'cp1252-contrast.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
shutil.rmtree(repo)
