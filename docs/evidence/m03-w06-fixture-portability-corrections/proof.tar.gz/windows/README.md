One shared synthetic native path fixture now supplies fully qualified C:\ absolute virtual roots on Windows while preserving the exact prior POSIX roots. Only app_owner_tests.rs changes. All bytes from its first #[test] through the shared PathsProof remain exact, as does the entire Quit test file; no assertion, budget, skip, production guard or filesystem operation changes.

Actual immutable204bc06 Windows CI raw records300PASS/16FAIL, all16 at the same invalid fake-root construction. The exact original failure block is retained. This establishes a test setup failure scope, not a production defect.

Outside Mac validation passes fmt, compile, actual342-case catalog,12app-owner cases,15shared Quit cases and strict default all-targets Clippy. Six children are reaped/groups absent/zero cleanup signals. The2131-file documentary-dirty canonical baseline and all selected/protected/derivative/head/tree/status endpoints remain exact. This is not actual Windows validation; fresh CI is still required.

The earlier clean2070 observer precondition stop and the first outside missing-test-include compile failure remain retained separately. The latter was corrected only by adding an exact canonical error-catalog input to the outside projection. No canonical writes or milestone promotion occurred.
