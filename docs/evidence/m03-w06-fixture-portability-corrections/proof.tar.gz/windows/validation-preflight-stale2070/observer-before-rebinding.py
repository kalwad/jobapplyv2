import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import time

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
BASE = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/windows-native-path-fixture-repair-v1')
OUT = BASE / 'validation'
SOURCE = BASE / 'source'
TARGET = BASE / 'owned-target'
CRATE = SOURCE / 'apps/desktop/src-tauri'
RELATIVE = 'apps/desktop/src-tauri/src/service/platform_adapters/app_owner_tests.rs'
OUT.mkdir()

def record(path, name):
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode)
    data = path.read_bytes()
    return {'path': name, 'bytes': len(data), 'mode': stat.S_IMODE(s.st_mode), 'sha256': hashlib.sha256(data).hexdigest()}

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

inputs = json.loads((BASE / 'SOURCE-INPUTS.json').read_text())['files']
protected = json.loads(Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/w09-sdk-proof-preparation/PROTECTED-RUNTIME-AND-SHIPPING-before-reviewed-actor.json').read_text())['files']

def snapshot():
    def git(*args):
        return subprocess.check_output(['git', '-C', str(ROOT), *args]).decode().strip()
    names = sorted(set(subprocess.check_output(['git', '-C', str(ROOT), 'ls-files', '--cached', '--others', '--exclude-standard', '-z']).decode().split('\0')) - {''})
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'status': git('status', '--porcelain=v1', '--untracked-files=all'),
        'canonical': [record(ROOT / n, n) for n in names],
        'canonical_selected': [record(ROOT / row['path'], row['path']) for row in inputs],
        'derivative_selected': [record(SOURCE / row['path'], row['path']) for row in inputs],
        'protected': [record(ROOT / row['path'], row['path']) for row in protected]}

before = snapshot()
assert before['head'].startswith('204bc06') and before['tree'].startswith('5b5bfeda')
assert len(before['canonical']) == 2070 and before['status'] == ''
assert before['canonical_selected'] == inputs and before['protected'] == protected
changed = [a['path'] for a, b in zip(before['canonical_selected'], before['derivative_selected']) if a != b]
assert changed == [RELATIVE], changed
original = (BASE / 'before.rs').read_bytes()
afterimage = (SOURCE / RELATIVE).read_bytes()
assert original[original.index(b'#[test]'):] == afterimage[afterimage.index(b'#[test]'):]
assert not TARGET.exists()
TARGET.mkdir(mode=0o700)
save('before.json', before)
env = dict(os.environ)
env['CARGO_TARGET_DIR'] = str(TARGET)
commands = []

def run(label, argv, timeout):
    started = time.monotonic()
    signals = []
    reason = None
    stdout_path, stderr_path = OUT / (label + '.stdout.log'), OUT / (label + '.stderr.log')
    with stdout_path.open('wb') as stdout, stderr_path.open('wb') as stderr:
        child = subprocess.Popen([str(a) for a in argv], cwd=CRATE, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        pgid = os.getpgid(child.pid)
        assert pgid == child.pid
        print(json.dumps({'phase': label, 'pid': child.pid, 'pgid': pgid}), flush=True)
        while True:
            code = child.poll()
            if code is not None:
                break
            if time.monotonic() - started > timeout or stdout_path.stat().st_size + stderr_path.stat().st_size > 4194304:
                reason = 'TIMEOUT_OR_OUTPUT_CAP'
                os.killpg(pgid, signal.SIGTERM)
                signals.append('SIGTERM')
                until = time.monotonic() + 2
                while time.monotonic() < until:
                    code = child.poll()
                    if code is not None:
                        break
                    time.sleep(0.05)
                if code is None:
                    os.killpg(pgid, signal.SIGKILL)
                    signals.append('SIGKILL')
                    code = child.wait(timeout=5)
                break
            time.sleep(0.1)
    try:
        os.killpg(pgid, 0)
    except ProcessLookupError:
        group = 'ABSENT'
    else:
        group = 'EXISTS'
    row = {'label': label, 'argv': [str(a) for a in argv], 'cwd': str(CRATE), 'explicit_environment': {'CARGO_TARGET_DIR': str(TARGET)},
        'pid': child.pid, 'pgid': pgid, 'exit_code': code, 'elapsed_seconds': time.monotonic() - started, 'timeout_seconds': timeout, 'limit_reason': reason,
        'signals': signals, 'direct_child_reaped': child.returncode is not None, 'owned_group_after_reap': group,
        'stdout': record(stdout_path, stdout_path.name), 'stderr': record(stderr_path, stderr_path.name)}
    commands.append(row)
    save('commands.json', commands)
    assert code == 0 and reason is None and group == 'ABSENT', row
    return stdout_path

failure = None
binary_record = None
catalog = []
try:
    manifest = CRATE / 'Cargo.toml'
    run('01-fmt', ['cargo', 'fmt', '--manifest-path', manifest, '--', '--check'], 120)
    messages = run('02-compile', ['cargo', 'test', '--locked', '--manifest-path', manifest, '--lib', '--no-run', '--message-format=json'], 900)
    images = [json.loads(line) for line in messages.read_text().splitlines() if line.startswith('{')]
    paths = [Path(row['executable']) for row in images if row.get('reason') == 'compiler-artifact' and row.get('executable') and row.get('target', {}).get('name') == 'japp_desktop' and row.get('profile', {}).get('test')]
    assert len(paths) == 1, paths
    binary = paths[0]
    binary_record = record(binary, str(binary))
    raw = run('03-catalog', [binary, '--list'], 30)
    catalog = [line[:-6] for line in raw.read_text().splitlines() if line.endswith(': test')]
    assert len(catalog) == 342 and len(set(catalog)) == 342
    save('catalog.json', catalog)
    run('04-app-owner', [binary, 'service::platform_adapters::app_owner::tests::', '--test-threads=1'], 60)
    run('05-quit', [binary, 'service::quit::tests::', '--test-threads=1'], 60)
    run('06-strict-clippy', ['cargo', 'clippy', '--locked', '--manifest-path', manifest, '--all-targets', '--', '-D', 'warnings'], 900)
except Exception as error:
    failure = repr(error)
finally:
    after = snapshot()
    save('after.json', after)
    result = {'scope': 'ACTUAL_MAC_FOCUS_AND_STRICT_QUALITY_ON_ONE_TEST_ONLY_FIX_NOT_WINDOWS_EXECUTION', 'failure': failure,
        'before_after_exact_equal': before == after, 'canonical_files': len(before['canonical']), 'selected_inputs': len(inputs), 'protected_files': len(protected),
        'only_modified_derivative_source': changed, 'all_test_bodies_and_following_shared_fixture_bytes_exact': True,
        'catalog_cases': len(catalog), 'binary': binary_record, 'commands': len(commands),
        'all_commands_exit_zero': all(row['exit_code'] == 0 for row in commands), 'all_owned_groups_absent': all(row['owned_group_after_reap'] == 'ABSENT' for row in commands),
        'cleanup_signals': sum(len(row['signals']) for row in commands), 'production_edits': 0, 'canonical_writes': 0}
    save('result.json', result)
    print(json.dumps(result, indent=2), flush=True)
    assert failure is None and before == after, result
