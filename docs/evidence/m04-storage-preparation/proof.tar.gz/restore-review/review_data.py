"""Read-only evidence joins. No product imports, subprocesses or actors."""
from pathlib import Path
import hashlib, json, stat, re, datetime, ast
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
B=E/'m04-backup-preparation/v2'
O=Path(__file__).parent
checks=[]
def check(name, ok, details=None):
    checks.append({'name':name,'pass':bool(ok),'details':details})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snap(root):
    return {str(p.relative_to(root)):{'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode),'sha256':sha(p)} for d in ('proposal','stubs') for p in sorted((root/d).rglob('*')) if p.is_file()}
def load(p):return json.loads(p.read_text())
current=snap(B); final=load(B/'quality/restore-quality-third/results.json'); baseline=load(B/'BASELINE.json'); combined=load(B/'quality/combined-baseline/results.json'); mutant=B/'negative-control'; neg=load(mutant/'results.json'); control=snap(mutant)
check('current has 24 source/stub regular-file records',len(current)==24)
check('third phase reports exact before/after equality',final['before']==final['after'] and final['source_unchanged'])
for path,row in current.items():
    check('third before current exact bytes/hash/full mode '+path,final['before'].get(path)==row)
    check('third after current exact bytes/hash/full mode '+path,final['after'].get(path)==row)
check('baseline selected input count 22',len(baseline['inputs'])==22)
for row in baseline['inputs']:
    p=Path(row['source']);d=B/row['destination']
    check('baseline input/destination hash identity '+row['destination'],p.is_file() and sha(p)==row['sha256']==sha(d))
check('combined original snapshot has 22 entries',len(combined['before'])==22)
check('combined source unchanged',combined['before']==combined['after'] and combined['source_unchanged'])
for path,row in combined['after'].items():
    check('combined baseline retained current '+path,current.get(path)==row)
for tag,data in [('combined-baseline',combined),('restore-quality-third',final)]:
    check(tag+' exactly four strict phases',[x['name'] for x in data['commands']]==['ruff','format','mypy','pytest'])
    for command in data['commands']:
        name=command['name'];q=B/'quality'/tag
        check(tag+' closed clean '+name,command['exit_code']==0 and command['direct_child_reaped'] and command['observed_group']=='ABSENT' and not command['cleanup_signals'] and command['seconds']<40)
        for suffix in ('stdout','stderr'):
            check(tag+' raw '+name+'.'+suffix,sha(q/(name+'.'+suffix))==command[suffix+'_sha256'])
    summary=(B/'quality'/tag/'pytest.stdout').read_text()
    expected=144 if tag=='combined-baseline' else 156
    check(tag+' actual raw pytest summary',re.search(r'\b'+str(expected)+r' passed in [0-9.]+s\s*$',summary) is not None,summary.strip().splitlines()[-1])
check('mutant command failed closed expected pytest1',neg['exit_code']==1 and neg['direct_child_reaped'] and neg['observed_group']=='ABSENT' and not neg['cleanup_signals'])
check('mutant selected unchanged final tests',neg['test_bytes_identical'])
check('mutant reported before/after unchanged',neg['source_unchanged'] and neg['before']==neg['after'])
for path,row in control.items():
    check('mutant actual source before full mode/hash '+path,neg['before'].get(path)==row)
    check('mutant actual source after full mode/hash '+path,neg['after'].get(path)==row)
    if not path.endswith('/restore.py'):
        check('mutant nonrestore identical final '+path,current.get(path)==row)
restore='proposal/services/orchestrator/src/orchestrator/persistence/restore.py'
original=(B/restore).read_bytes(); changed=(mutant/restore).read_bytes()
needle=b'            actual != plan\n            or actual.conflicting_record_ids\n'
replacement=b'            actual.conflicting_record_ids\n'
check('mutant only removes preview equality guard',original.count(needle)==1 and original.replace(needle,replacement)==changed)
check('mutant SHA joins final and mutant',sha(B/restore)==neg['mutation_before_sha256'] and sha(mutant/restore)==neg['mutation_after_sha256'])
check('mutant config exact final',sha(B/'pyproject.toml')==sha(mutant/'pyproject.toml'))
negative_raw=(mutant/'pytest.stdout').read_text()
check('mutant exactly four expected missing-refusal failures',negative_raw.count('E       Failed: DID NOT RAISE StoreError')==4)
check('mutant exact 4 failed 152 deselected summary',re.search(r'4 failed, 152 deselected in [0-9.]+s\s*$',negative_raw) is not None)
expected_failures=['test_identical_import_is_idempotent_but_original_plan_cannot_be_replayed','test_stale_or_forged_target_plan_refuses_under_write_transaction[False]','test_stale_or_forged_target_plan_refuses_under_write_transaction[True]','test_changed_source_after_preview_cannot_be_applied']
for name in expected_failures:
    check('negative oracle failure '+name,('FAILED proposal/services/orchestrator/tests/test_restore.py::'+name) in negative_raw)
for path in (B/'proposal/services/orchestrator/tests').glob('test_*.py'):
    ast.parse(path.read_text())
newtree=ast.parse((B/'proposal/services/orchestrator/tests/test_restore.py').read_text())
new_cases=[]
for node in newtree.body:
    if isinstance(node,ast.FunctionDef) and node.name.startswith('test_'):
        count=1
        for decorator in node.decorator_list:
            if isinstance(decorator,ast.Call) and isinstance(decorator.func,ast.Attribute) and decorator.func.attr=='parametrize':
                count*=len(ast.literal_eval(decorator.args[1]))
        new_cases.append({'name':node.name,'cases':count,'line':node.lineno})
check('new tests have 12 expanded cases',sum(x['cases'] for x in new_cases)==12)
inputs=[]
for p in [B/'BASELINE.json',B/'PLAN.md',B/'pyproject.toml',B/'run_quality.py',B/'quality/combined-baseline/results.json',B/'quality/restore-quality-third/results.json',mutant/'results.json']+[B/x for x in current]:
    inputs.append({'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)})
for q in (B/'quality/combined-baseline',B/'quality/restore-quality-third',mutant):
    for p in sorted(q.glob('*.stdout'))+sorted(q.glob('*.stderr')):
        inputs.append({'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)})
result={'scope':'DIFFERENT_AGENT_READ_ONLY_SOURCE_AND_ACTUAL_DATA_REVIEW_NO_ACTORS','created_utc':datetime.datetime.now(datetime.UTC).isoformat(),'verdict':'CLEAR' if all(x['pass'] for x in checks) else 'FINDINGS','checks':checks,'checked_count':len(checks),'pass_count':sum(x['pass'] for x in checks),'source_current':current,'new_test_cases':new_cases,'bound_inputs':inputs,'source_manifest_present_at_review':(B/'SOURCE.json').exists(),'no_product_imports_or_actor_execution':True}
(O/'data-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'verdict':result['verdict'],'checks':len(checks),'failures':[x for x in checks if not x['pass']],'data_sha256':sha(O/'data-review.json')},indent=2))
