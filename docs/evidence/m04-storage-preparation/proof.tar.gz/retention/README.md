# Isolated table-scoped logical deletion preparation

Result: all **178 synthetic Python tests passed** in 1.08 seconds: all 156
inherited tests remain byte-identical and 22 new cases passed. Strict Ruff,
format checking and strict mypy also passed in the same `quality/full-first`
actor. Each of its four commands exited 0, its direct child was reaped, the
owned process group was observed absent, and no cleanup signal was needed.
The complete proposal/stub bytes and full file modes match at both endpoints.
This is outside-only preparation and supplies no formal M04 acceptance.

Run commands (all executed with the pinned CPython 3.12.13 root observer):

```text
python3.12 -I -S -B run_quality.py static-first ruff format mypy
python3.12 -I -S -B run_quality.py static-final ruff format mypy
python3.12 -I -S -B run_quality.py static-second ruff format mypy
python3.12 -I -S -B run_quality.py full-first
python3.12 -I -S -B run_control.py
```

The exact nested argv, durations, raw stdout/stderr hashes, actual exit codes,
PIDs, group observations, before/after snapshots and modes are retained under
`quality/` and `negative-controls/`. Actors use the existing isolated SQLCipher
venv and exact source path, read tooling from the existing Python 3.12 root
venv, and keep caches and temporary synthetic databases in this derivative.
Each command has a 40-second cap, followed by bounded owned-group cleanup if
needed. No timeout or cleanup signal occurred in any retained phase.

`static-first` passed before the final test-only additions. `static-final`
retains an actual single Ruff S608 failure in a test predicate that concatenated
a literal SQL prefix with one of two fixed test table names. The correction
parametrizes the two complete literal prefixes; production code and test
assertions did not change. `static-second` and the full final actor pass.
Historical test bodies are labelled recovered derivations and match their
recorded phase hashes exactly; they are not represented as original captures.
An initial manual formatter invocation lacked the tooling PYTHONPATH and
reported `No module named ruff`; the corrected manual invocation formatted only
the two new paths before the retained static actors.

Two negative controls copy the exact final source and all test bytes to new
synthetic roots. Removing only `actual != plan` makes all three
stale/forged/changed-request refusal tests fail: **3 FAILED, 175 deselected**.
Replacing only the category exemption clause with `and False` disables the
unknown-dependency branch and makes both relationship-refusal tests fail:
**2 FAILED, 176 deselected**. Both children exit 1 as intended, are reaped, have
absent groups, and leave their own source unchanged; final source is unchanged
across both controls. No test oracle is modified. `CONTROL-RESULTS.json` binds
the exact one-path deltas, raw logs and endpoint snapshots.

The factory, migrations, source/export/restore codec, artifact API, bounded
snapshot, SQLCipher integrity checks and transaction outcome/custody behavior
are inherited without modification. No schema migration or dependency change
is required. `BASELINE.json` binds the inherited 24 files to sealed restore-v2
SOURCE `27d2f618f9177fbee1255dea4d49745834fadf7e91597813828676d7a00493a4`.

The new API deletes logical rows from the owned encrypted database only.
`ALL_DATABASE_PRIVATE_ROWS` retains schema/migration metadata and does not mean
all user data on the device. Old encrypted pages, journals, snapshots, exported
backups, process copies, keys, logs and neighbouring filesystem material are
outside its erasure claim. Synthetic sentinel tests show that neighbouring
files and key-provider call counts remain unchanged during deletion; this is
neither a native secret-store certification nor secure byte-erasure evidence.

Selective requests refuse when both tables have data because current opaque
records do not establish artifact relationships. Explicit artifact deletion
when no records exist intentionally removes the selected rows and their
manual reference counts. It is not inferred garbage collection. Existing
explicit artifact release removes the row at zero references, as tested.
There are no timestamps or category identity beyond the known tables, so no
age-based retention policy or domain-category deletion is claimed. Future
domain schemas must add authoritative relationships before relaxing refusal.

No real user data, credential store, key-file fallback, OS deletion, native
startup, renderer endpoint, HTTP API, installed-wheel check, Windows/Ubuntu
actor, UI activation, canonical change or package-completion claim occurs.
