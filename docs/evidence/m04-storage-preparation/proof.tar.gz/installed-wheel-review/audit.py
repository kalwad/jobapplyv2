"""Read-only retained files, wheel, installed origins and closure joins; no imports/DB opens."""
from pathlib import Path, PurePosixPath
import base64, csv, hashlib, io, json, stat, tarfile, zipfile

E = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
B = E/'m04-installed-wheel-preparation/v2'
OUT = Path(__file__).parent
checks = []
def check(name, value):
    checks.append({'name': name, 'pass': bool(value)})
def sha(data): return hashlib.sha256(data).hexdigest()
def load(name): return json.loads((B/name).read_bytes())
def fingerprint(path):
    st = path.lstat()
    assert stat.S_ISREG(st.st_mode)
    return {'bytes': st.st_size, 'mode': stat.S_IMODE(st.st_mode), 'sha256': sha(path.read_bytes())}

check('sealed SOURCE identity', sha((B/'SOURCE.json').read_bytes()) == '3990c33638f66139611f8c1135726e30b952975eeff6f750965797245f6c58da')
source = load('SOURCE.json')
check('51 selected sealed files', len(source['files']) == 51)
for row in source['files']:
    check('sealed '+row['path'], fingerprint(B/row['path']) == {k: row[k] for k in ('bytes','mode','sha256')})
handoff = load('HANDOFF.json')
check('exact proof pin', sha((B/'proof.tar.gz').read_bytes()) == handoff['proof_sha256'] == '33ff3b4c0568dc84cd9498c47cfe49b6ccda1394fdca3d8316a3e7f25add6fe5')
with tarfile.open(B/'proof.tar.gz') as archive:
    members = archive.getmembers()
    expected = {r['path']: r for r in source['files']}
    expected['SOURCE.json'] = {'bytes': (B/'SOURCE.json').stat().st_size, 'sha256': sha((B/'SOURCE.json').read_bytes())}
    check('52 unique safe regular proof members', len(members) == len(expected) == 52 and len({m.name for m in members}) == 52 and all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in members) and {m.name for m in members} == set(expected))
    for member in members:
        body = archive.extractfile(member).read(); row = expected[member.name]
        check('proof '+member.name, len(body) == row['bytes'] and sha(body) == row['sha256'])

inputs = load('INPUTS.json')['inputs']; before = load('actual-v1/before.json'); after = load('actual-v1/after.json')
check('29 selected source/derivative inputs', len(inputs) == 29 and len(before) == 58)
check('full endpoint metadata equal', before == after)
for row in inputs:
    check('selected original/derivative '+row['destination'], all(fingerprint(p) == before[str(p)] and before[str(p)]['bytes'] == row['bytes'] and before[str(p)]['sha256'] == row['sha256'] for p in (Path(row['source']), B/row['destination'])))
check('19 canonical including pyproject, 9 restore overlay, 1 probe', sum('/jobapplyv2/services/' in r['source'] for r in inputs) == 19 and sum('/m04-backup-preparation/v2/' in r['source'] for r in inputs) == 9 and sum(r['destination'] == 'installed-probe.py' for r in inputs) == 1)
check('sealed restore source pin', sha((E/'m04-backup-preparation/v2/SOURCE.json').read_bytes()) == source['sealed_restore_source_sha256'] == '27d2f618f9177fbee1255dea4d49745834fadf7e91597813828676d7a00493a4')
wheel = B/'dist/orchestrator-0.0.1-py3-none-any.whl'; inventory = load('actual-v1/wheel-inventory.json'); site = B/'venv/lib/python3.12/site-packages'
check('exact wheel pin', sha(wheel.read_bytes()) == source['wheel_sha256'] == handoff['wheel_sha256'] == '7dcbaefb28f62aee9f41a54c34e54fe30805cc61e6b07ab33316187656295998')
with zipfile.ZipFile(wheel) as archive:
    names = archive.namelist()
    check('unique safe regular wheel members', len(names) == len(set(names)) and all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and not n.endswith('/') and stat.S_IFMT(archive.getinfo(n).external_attr >> 16) in (0, stat.S_IFREG) for n in names))
    package = {n: archive.read(n) for n in names if n.startswith('orchestrator/')}
    project = {p.relative_to(B/'project/src').as_posix(): p.read_bytes() for p in (B/'project/src/orchestrator').rglob('*') if p.is_file()}
    check('27 exact package files', len(package) == 27 and package == project)
    check('all package inventory joins', inventory['package_files'] == {n: {'bytes':len(d), 'sha256':sha(d)} for n,d in package.items()})
    for name, body in package.items():
        target = site/name
        check('installed body '+name, target.is_file() and not target.is_symlink() and target.read_bytes() == body)
    record = next(n for n in names if n.endswith('.dist-info/RECORD'))
    records = list(csv.reader(io.StringIO(archive.read(record).decode())))
    check('complete unique RECORD names', len(records) == len(names) and {r[0] for r in records} == set(names))
    for name, digest, size in records:
        check('RECORD '+name, (not digest and not size and name == record) or (digest == 'sha256='+base64.urlsafe_b64encode(hashlib.sha256(archive.read(name)).digest()).rstrip(b'=').decode() and size == str(len(archive.read(name)))))
check('all three installed SQL resources exact', {n for n in package if n.endswith('.sql')} == {f'orchestrator/persistence/schemas/{i:03}.sql' for i in (1,2,3)})
native = E/'m04-sqlcipher-foundation/provenance/sqlcipher3-0.6.4-cp312-cp312-macosx_11_0_arm64.whl'
check('selected native wheel pin', sha(native.read_bytes()) == '1607fe61ddcd0a9731a062735e84f997515c0f2503ac158d57564e13b0799d9e')
with zipfile.ZipFile(native) as archive:
    for name in archive.namelist():
        if name.startswith('sqlcipher3/') and not name.endswith('/'):
            check('installed native wheel body '+name, (site/name).is_file() and not (site/name).is_symlink() and (site/name).read_bytes() == archive.read(name))

results = load('actual-v1/results.json')
check('four actual ordered commands', [r['name'] for r in results] == ['wheel-build','venv','install','probe'])
for row in results:
    check('actual closed '+row['name'], row['exit_code'] == 0 and not row['timeout'] and row['child_reaped'] and row['observed_group'] == 'ABSENT' and not row['cleanup_signals'] and 0 <= row['seconds'] < row['budget_seconds'])
    for stream in ('stdout','stderr'):
        check('raw '+row['name']+'.'+stream, sha((B/'actual-v1'/(row['name']+'.'+stream)).read_bytes()) == row[stream+'_sha256'])
check('offline build and explicit no-deps installation', '--offline' in results[0]['argv'] and '--offline' in results[1]['argv'] and '--offline' in results[2]['argv'] and '--no-deps' in results[2]['argv'])
check('exact isolated installed probe invocation', results[3]['argv'] == [str(B/'venv/bin/python'),'-I','-B',str(B/'installed-probe.py')])
check('same wrapper retained', (B/'run-executed.py').read_bytes() == (B/'actual-v1/wrapper-executed.py').read_bytes())
probe = load('actual-v1/probe.stdout')
check('observed installed synthetic resource/restore result', probe['python'] == '3.12.13' and probe['schema_resources'] == 3 and probe['installed_only_import_origins'] and probe['encrypted_export_load_wrongkey_refusal'] and probe['restore_reopen_revisions_refcounts_idempotence'] and probe['no_canonical_dependency_runtime_or_native_keystore_activation'])
closure = load('actual-v1/closure.json'); exitseen = load('actual-v1/exit-observation.json')
check('closure and exit endpoints', closure['inputs'] == exitseen['inputs'] == 29 and closure['original_and_derivative_bytes_modes_unchanged'] and closure['all_commands_exit_zero'] and exitseen['original_and_derivative_bytes_modes_unchanged'] and exitseen['completed_commands'] == 4 and exitseen['all_four_commands_exit_zero'])
stderr = (B/'actual-v1/probe.stderr').read_text()
output = {'scope':'Read-only retained-data/source audit; no subject imports, actors, credential APIs or DB opens', 'checks':checks, 'passed':sum(c['pass'] for c in checks), 'total':len(checks), 'nonblocking_wording_note':'README mentions retained SQLCipher wrong-key diagnostics; actual probe.stderr contains only two SyntaxWarning notices from compact1and syntax. The observed wrong-key refusal is asserted by probe source/exit0/stdout, not a retained SQLCipher diagnostic line.', 'raw_probe_stderr_contains_syntaxwarning': 'SyntaxWarning' in stderr}
(OUT/'checks.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({'passed':output['passed'],'total':output['total'],'failures':[c['name'] for c in checks if not c['pass']]}))
assert all(c['pass'] for c in checks)
