"""Read-only retained-evidence reconciliation; never imports proposal code."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import stat
import tarfile
import io

ROOT = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/m04-retention-preparation/v1')
OUT = Path(__file__).parent
EXPECTED_SOURCE = 'ad860c05bef99f6bd9992674171c88bc1373aa1c2fe6b9df2975e29712c3c335'
EXPECTED_PROOF = '32a7f1e15163c4ef26577855156d182f7eaec472aba9ea0f6bdf75054a0f6808'
RELPY = 'proposal/services/orchestrator/src/orchestrator/persistence/retention.py'
RELTEST = 'proposal/services/orchestrator/tests/test_retention.py'
checks = []

def sha(body):
    return hashlib.sha256(body).hexdigest()

def add(name, condition):
    checks.append({'name': name, 'matched': bool(condition)})

def desc(path):
    meta = path.lstat()
    if not stat.S_ISREG(meta.st_mode):
        raise ValueError('non-regular input: ' + str(path))
    return {'bytes': meta.st_size, 'mode': stat.S_IMODE(meta.st_mode), 'sha256': sha(path.read_bytes())}

def safe(rel):
    path = PurePosixPath(rel)
    return bool(rel) and str(path) == rel and not path.is_absolute() and '..' not in path.parts and '\\' not in rel

def describe_rel(rel, root=ROOT):
    if not safe(rel):
        raise ValueError('unsafe input member: ' + rel)
    path = root / rel
    for parent in path.parents:
        if parent == root:
            break
        if not stat.S_ISDIR(parent.lstat().st_mode):
            raise ValueError('non-directory parent: ' + str(parent))
    return desc(path)

def read_json(rel, root=ROOT):
    return json.loads((root / rel).read_bytes())

def snapshot(root=ROOT):
    result = {}
    for folder in ['proposal', 'stubs']:
        for path in sorted((root / folder).rglob('*')):
            if path.is_file() or path.is_symlink():
                rel = path.relative_to(root).as_posix()
                result[rel] = describe_rel(rel, root)
    return result

source_body = (ROOT / 'SOURCE.json').read_bytes()
proof_body = (ROOT / 'proof.tar.gz').read_bytes()
source = json.loads(source_body)
handoff = read_json('HANDOFF.json')
inputs_before = {rel: desc(ROOT / rel) for rel in ['SOURCE.json', 'proof.tar.gz', 'HANDOFF.json', 'RETAINED-CHECKS.json']}
add('requested SOURCE hash', sha(source_body) == EXPECTED_SOURCE == handoff['source_sha256'])
add('requested proof hash', sha(proof_body) == EXPECTED_PROOF == handoff['proof_sha256'])
add('proof length joins handoff', len(proof_body) == handoff['proof_bytes'])
expected = {}
for row in source['files']:
    rel = row['path']
    add('unique safe SOURCE path ' + rel, safe(rel) and rel not in expected)
    expected[rel] = {k: row[k] for k in ['bytes', 'mode', 'sha256']}
    add('current full metadata ' + rel, describe_rel(rel) == expected[rel])
add('SOURCE count joins handoff', len(expected) == len(source['files']) == handoff['source_records'] == 122)
omit = {'SOURCE.json', 'HANDOFF.json', 'RETAINED-CHECKS.json', 'proof.tar.gz'}
excluded_parts = {'cache', 'artifacts', 'pytest-tmp', '__pycache__', '.pytest_cache', '.ruff_cache'}
universe = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if (p.is_file() or p.is_symlink()) and p.relative_to(ROOT).as_posix() not in omit and not excluded_parts.intersection(p.relative_to(ROOT).parts)}
add('SOURCE exhaustive retained universe', universe == set(expected))
archive_expected = {**expected, 'SOURCE.json': desc(ROOT / 'SOURCE.json')}
members = []
seen = set()
with tarfile.open(fileobj=io.BytesIO(proof_body), mode='r:gz') as archive:
    for member in archive:
        rel = member.name
        member_safe = safe(rel) and member.isreg() and not member.issym() and not member.islnk() and rel not in seen and rel in archive_expected
        add('archive safe unique regular ' + rel, member_safe)
        if not member_safe:
            raise ValueError('invalid archive member')
        body = archive.extractfile(member).read()
        actual = {'bytes': len(body), 'mode': member.mode, 'sha256': sha(body)}
        add('archive full metadata ' + rel, actual == archive_expected[rel])
        seen.add(rel)
        members.append({'path': rel, **actual})
add('archive exhaustive membership', seen == set(archive_expected))
add('archive count and uncompressed bytes join handoff', len(members) == handoff['proof_members'] == 123 and sum(x['bytes'] for x in members) == handoff['proof_uncompressed_bytes'] == 870319)

current = snapshot()
baseline = read_json('BASELINE.json')
base = ROOT.parent.parent / 'm04-backup-preparation' / 'v2'
base_source_body = (base / 'SOURCE.json').read_bytes()
base_entries = {row['path']: {k: row[k] for k in ['bytes', 'mode', 'sha256']} for row in json.loads(base_source_body)['files']}
add('inherited baseline sealed SOURCE hash', sha(base_source_body) == baseline['source_manifest_sha256'] == '27d2f618f9177fbee1255dea4d49745834fadf7e91597813828676d7a00493a4')
for rel, metadata in baseline['selected_exact_files'].items():
    add('baseline full metadata and sealed prior join ' + rel, metadata == current.get(rel) == base_entries.get(rel) == describe_rel(rel, base))
add('exact two additions and no inherited omissions', set(current) - set(baseline['selected_exact_files']) == {RELPY, RELTEST} and set(baseline['selected_exact_files']) <= set(current) and len(current) == 26)
prior_log = 'quality/restore-quality-third/pytest.stdout'
prior_result = 'quality/restore-quality-third/results.json'
add('prior actual pytest raw log sealed join', describe_rel(prior_log, base) == base_entries[prior_log] and (base / prior_log).read_text().rstrip().endswith('156 passed in 0.98s') and baseline['base_test_count_actual_prior'] == 156)
add('prior final result sealed join', describe_rel(prior_result, base) == base_entries[prior_result])

phase_summaries = []
for phase in ['static-first', 'static-final', 'static-second', 'full-first']:
    folder = ROOT / 'quality' / phase
    result = read_json('results.json', folder)
    add('phase unchanged endpoints ' + phase, result['before'] == result['after'] and result['source_unchanged'] is True)
    for rel, metadata in result['before'].items():
        alternate = 'historical-source/' + phase + '/test_retention.py' if rel == RELTEST and phase in ['static-first', 'static-final'] else rel
        add('phase current or labelled historical body ' + phase + ' ' + rel, describe_rel(alternate) == metadata)
    rows = []
    for command in result['commands']:
        name = command['name']
        for stream in ['stdout', 'stderr']:
            add('phase raw ' + phase + ' ' + name + ' ' + stream, sha((folder / (name + '.' + stream)).read_bytes()) == command[stream + '_sha256'])
        add('phase recorded closure ' + phase + ' ' + name, command['direct_child_reaped'] is True and command['observed_group'] == 'ABSENT' and command['cleanup_signals'] == [] and 0 <= command['seconds'] < 40)
        add('phase exact source argv ' + phase + ' ' + name, command['argv'][0] == '/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/m04-sqlcipher-foundation/.venv/bin/python' and str(ROOT / 'proposal/services/orchestrator') in ' '.join(command['argv']))
        py = '/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/m04-sqlcipher-foundation/.venv/bin/python'
        package = ROOT / 'proposal/services/orchestrator'
        exact_argv = {
            'ruff': [py, '-m', 'ruff', 'check', '--config', str(ROOT / 'pyproject.toml'), str(package)],
            'format': [py, '-m', 'ruff', 'format', '--check', '--config', str(ROOT / 'pyproject.toml'), str(package)],
            'mypy': [py, '-m', 'mypy', '--strict', '--config-file', str(ROOT / 'pyproject.toml'), '--cache-dir', str(ROOT / 'cache/mypy'), str(package / 'src'), str(package / 'tests')],
            'pytest': [py, '-m', 'pytest', '-c', str(ROOT / 'pyproject.toml'), str(package / 'tests'), '-q', '--basetemp', str(folder / 'pytest-tmp')],
        }
        add('phase full argv equality ' + phase + ' ' + name, command['argv'] == exact_argv[name])
        rows.append({k: command[k] for k in ['name', 'argv', 'exit_code', 'seconds', 'owned_pid', 'direct_child_reaped', 'observed_group', 'cleanup_signals', 'stdout_sha256', 'stderr_sha256']})
    want = [('ruff', 1)] if phase == 'static-final' else [('ruff', 0), ('format', 0), ('mypy', 0)] + ([('pytest', 0)] if phase == 'full-first' else [])
    add('phase exact commands and exit outcomes ' + phase, [(x['name'], x['exit_code']) for x in rows] == want)
    phase_summaries.append({'phase': phase, 'commands': rows})
full = read_json('quality/full-first/results.json')
add('full actor endpoint matches current input', full['before'] == full['after'] == current)
add('full raw pytest summary', (ROOT / 'quality/full-first/pytest.stdout').read_text().rstrip().endswith('178 passed in 1.08s'))
add('full raw Ruff outcome', (ROOT / 'quality/full-first/ruff.stdout').read_text() == 'All checks passed!\n')
add('full raw format outcome', (ROOT / 'quality/full-first/format.stdout').read_text() == '18 files already formatted\n')
add('full raw mypy outcome', (ROOT / 'quality/full-first/mypy.stdout').read_text() == 'Success: no issues found in 18 source files\n')
add('historical failed Ruff outcome preserved', 'S608 Possible SQL injection' in (ROOT / 'quality/static-final/ruff.stdout').read_text() and 'Found 1 error.' in (ROOT / 'quality/static-final/ruff.stdout').read_text())

controls = read_json('CONTROL-RESULTS.json')
add('control parent current endpoints', controls['parent_before'] == controls['parent_after'] == current and controls['parent_unchanged'] is True)
control_summaries = []
for row in controls['controls']:
    name = row['control']
    folder = ROOT / 'negative-controls' / name
    add('aggregate equals individual control ' + name, read_json('CONTROL.json', folder) == row)
    mutant = snapshot(folder)
    add('control unchanged current endpoints ' + name, row['before'] == row['after'] == mutant and row['source_unchanged'] is True)
    changed = sorted(rel for rel in current if mutant.get(rel) != current[rel])
    add('control only expected path delta ' + name, set(mutant) == set(current) and changed == row['changed_paths'] == [RELPY])
    parent_text = (ROOT / RELPY).read_text()
    add('control exact single-clause mutation ' + name, parent_text.count(row['old_clause']) == 1 and (folder / RELPY).read_text() == parent_text.replace(row['old_clause'], row['new_clause']))
    add('control exact final parent hash ' + name, row['exact_final_parent_sha256'] == current[RELPY]['sha256'])
    for stream in ['stdout', 'stderr']:
        add('control raw hash ' + name + ' ' + stream, sha((folder / ('pytest.' + stream)).read_bytes()) == row[stream + '_sha256'])
    failures = 3 if name == 'preview-binding' else 2
    deselected = 178 - failures
    raw = (folder / 'pytest.stdout').read_text()
    add('control actual exact failures ' + name, raw.count('\nFAILED ') == failures and f'{failures} failed, {deselected} deselected' in raw and row['expected_failures'] == failures and row['exit_code'] == 1 and row['expected_control_observed'] is True)
    add('control recorded cleanup closure ' + name, row['direct_child_reaped'] is True and row['observed_group'] == 'ABSENT' and row['cleanup_signals'] == [] and row['timed_out'] is False and 0 <= row['seconds'] < 40)
    add('control mutant argv target ' + name, str(folder / 'proposal/services/orchestrator/tests') in row['argv'] and row['keyword'] in row['argv'])
    add('control full argv equality ' + name, row['argv'] == ['/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/m04-sqlcipher-foundation/.venv/bin/python', '-m', 'pytest', '-c', str(ROOT / 'pyproject.toml'), str(folder / 'proposal/services/orchestrator/tests'), '-q', '-k', row['keyword'], '--basetemp', str(folder / 'pytest-tmp')])
    control_summaries.append({k: v for k, v in row.items() if k not in ['before', 'after']})
retained = read_json('RETAINED-CHECKS.json')
add('author reconciliation record hash and count', sha((ROOT / 'RETAINED-CHECKS.json').read_bytes()) == handoff['retained_check_sha256'] and len(retained['checks']) == retained['total'] == retained['passed'] == handoff['retained_check_count'] == 573 and retained['all_pass'] is True and all(x['pass'] for x in retained['checks']))
inputs_after = {rel: desc(ROOT / rel) for rel in inputs_before}
add('review input manifests unchanged endpoints', inputs_after == inputs_before)
add('review sealed entries unchanged endpoints', all(describe_rel(rel) == metadata for rel, metadata in expected.items()))
result = {
    'scope': 'INDEPENDENT_READ_ONLY_SOURCE_AND_RETAINED_EVIDENCE_REVIEW_NOT_NEW_PRODUCT_TESTS_OR_M04_ACCEPTANCE',
    'root': str(ROOT), 'source_sha256': sha(source_body), 'proof_sha256': sha(proof_body),
    'source_records': len(expected), 'proof_members': len(members), 'proof_uncompressed_bytes': sum(x['bytes'] for x in members),
    'reviewed_production_file': {'path': RELPY, **current[RELPY]},
    'prior_selected_files': len(baseline['selected_exact_files']), 'current_selected_files': len(current),
    'inputs_before': inputs_before, 'inputs_after': inputs_after,
    'retained_actor_phases': phase_summaries, 'negative_controls': control_summaries,
    'reconciliation_count': len(checks), 'matched_count': sum(x['matched'] for x in checks),
    'all_matched': all(x['matched'] for x in checks), 'reconciliations': checks,
    'archive_members': members,
    'product_test_execution_by_this_reviewer': False,
    'proposal_import_by_this_reviewer': False, 'canonical_writes_by_this_reviewer': False,
    'native_actors_network_or_signals_by_this_reviewer': False,
    'actionable_findings': [],
}
(OUT / 'review-data.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['scope', 'source_sha256', 'proof_sha256', 'source_records', 'proof_members', 'prior_selected_files', 'current_selected_files', 'reconciliation_count', 'matched_count', 'all_matched', 'actionable_findings']}, indent=2))
if not result['all_matched']:
    print(json.dumps([x for x in checks if not x['matched']], indent=2))
    raise SystemExit(1)
