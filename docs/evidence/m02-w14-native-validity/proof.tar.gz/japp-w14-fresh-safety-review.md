# Supplemental fresh W14 safety source audit

Revision: d99c5921338984d6727a0a81bc38d7c628b41199 (PR #1).
Reviewer role: fresh source reviewer, no implementation authorship. This is supplemental M02-W14 review, not the M02-W15 start, final Gate A independent acceptance, or owner approval.

## Current result

One P1 local defect is confirmed by actual MV3 reproduction: late native constraint-validation drift publishes stale VERIFIED/READY evidence. No other new defect was found in the inspected ownership/option/description-clearing/collision paths. Initial source inspection was read-only. After parent cleared isolated heavy work, a fresh managed outside worktree at exact d99c592 performed the reproduction. No source/index/build/test/ignored-output write occurred in the root checkout, which remained frozen.

## Confirmed P1: final property witness omits native validity

Status: RUNTIME-CONFIRMED. Priority P1 because a current native site rejection receives VERIFIED and W11 READY credit.

Relevant source:

- apps/extension/src/drivers/driver-dom.ts:100-143: captureNativePropertyWitness snapshots value/checked, files and selection/selected label/text, but no native constraint-validation reading.
- apps/extension/src/drivers/driver-dom.ts:225-267: readSiteAcceptance relies on willValidate, validity.valid and validationMessage.
- apps/extension/src/driver-engine.ts:1149-1159,1225-1253: execute captures the limited witness, reads acceptance, awaits result metadata hashes, and checks the limited witness plus DOM evidence currentness.
- apps/extension/src/driver-engine.ts:1586-1596,1628-1655: undo follows the same path.
- apps/extension/src/dynamic-engine.ts:1106-1125,1308-1339: W11 observes acceptance, hashes evidence/inventory metadata, and rechecks the same limited property witness.

A page can call input.setCustomValidity('late rejection') while final hashing awaits. The operation changes native validity and validationMessage while retaining value, checked, DOM tree, attributes and text. Actual real-extension execution shows every current final fence passes while earlier ACCEPTED evidence remains in the result. This is a narrower extension of the KI-0083 publication issue, not an accuracy-threshold dispute. It does not depend on private page/framework internals or mutable expected answers.

Existing retained regressions cover value-property drift (extension-w14-independent-extra.spec.ts and extension-w14-inventory-property.spec.ts) and DOM aria-invalid drift (extension-w14-independent-undo-hash.spec.ts). The latter mutates an attribute and is caught by the DOM evidence revision; it does not exercise setCustomValidity.

## Exact isolated reproduction proposal

Run only after root explicitly clears heavy work, from an outside checkout at the exact reviewed revision; keep root source, index, build and ignored artifacts untouched. Preserve exact before/after source/build inventories and record actual outputs.

1. Reuse the existing real MV3 fixture and content-realm native crypto.subtle.digest wrapper from extension-w14-independent-extra.spec.ts. Keep the same required native text input, immutable approved transaction, full 75ms settlement and result-hash pause. Add fresh correlation/transaction seeds to avoid memoized metadata hashes.
2. For EXECUTE, pause at w10-idempotency-v1\0<transaction id>\0EXECUTE after settlement; observe the intended value. In the page realm install a temporary MutationObserver, call input.setCustomValidity('Late synthetic site rejection'), collect observer.takeRecords().length, then disconnect. Record value, validity.valid, validity.customError, willValidate, validationMessage and aria-invalid before/after. Release the native hash gate and capture the exact driver result, undo_available and native observer snapshot.
3. For UNDO, first complete an unchanged VERIFIED execute. Pause at the corresponding UNDO metadata seed after restoration to Prior, perform the same setCustomValidity operation, release, and capture exact undo result and physical validity. The prior value must be nonempty so this is specifically a new custom rejection, not required-empty validation.
4. For W11, execute once and obtain a READY baseline. Reuse extension-w14-inventory-property.spec.ts's final w11-inventory-v1\0 gate, call setCustomValidity during the pause, release, then capture the paused publication and a fresh reconciliation. Require zero mutation records and unchanged value. A stale RECONCILED/READY paused result contrasted with fresh NOT_READY would confirm the defect.
5. For each path retain an unchanged positive control with the same pause/release and no site mutation: execute remains VERIFIED and offers the existing reversible undo; undo remains VERIFIED with Prior restored; W11 remains RECONCILED/READY.
6. Before a fix, the three negative assertions should require no VERIFIED result or READY inventory and should fail if this source reasoning is correct. Retain those failures unchanged. After the minimal fix rerun exact negatives and positives, then the existing ownership, selected-option, value-property, composite-clearing, collision and native-witness regressions. Do not weaken thresholds, fixture oracles or original assertions.

## Minimal fix direction if confirmed

Extend the existing bounded synchronous property witness for every native input, textarea and select with inert primitive snapshots of the exact native acceptance inputs: willValidate, validity.valid and validationMessage. Read primitive values, not the live ValidityState object. Compare them synchronously in the returned witness. Preserve current value/checked/files/select/driver-specific checks and the DOM index, topology, option and exact component-description fences. This reuses the existing stale-publication refusal paths and preserves V1 result grammar, outcome/reason synthesis and numeric thresholds. Do not dispatch checkValidity/reportValidity or any page event, perform a new hash, or add a new await in the final fence. Review native acceptanceElements beyond anchor/members (e.g. native status elements when returned by a driver) so every native acceptance surface is included or has an explicit extra witness.

## Inspected scope and evidence

Read CLAUDE.md; relevant immutable master sections 1.5, 2.3 Gate A, 5.11, 5.13 and M02; current status/gate/decision material including accepted ADR-0006. M00/M01 accepted and W01-W13 verified satisfy W14 prerequisites; W15 remains NOT_STARTED. ADR-0006 waives hidden owner holdout and per-W stopping only.

Inspected W13-to-current source changes in driver-engine, driver contract/DOM/mutation guard, choice/text/widget drivers, field scanner, option meaning cache, semantic identity, dynamic engine/classifier and validation description; inspected representative actual-MV3 tests for native/ARIA stale meanings, execute/undo/result/inventory drift, exact composite clearing and physical collision reporting. Traced original W09 option snapshot binding, repeated post-await semantic checks, synchronous final mutation boundary and text focus recheck; exact selected meaning is retained while unselected option-window changes can remain read-only evidence. Exact error clearing retains reference/root/help/ownership/role/classes and permits only previously observed rejected error text to become empty. Physical inventory keys use elements only to count current observations, distinct occurrence IDs remain report-only, and collisions classify each required member unresolved with NOT_READY rather than choosing a target.

Compared retained functional-corrections after-source/review and collision summary (twelve RECONCILED/NOT_READY snapshots containing two required unresolved members with distinct report IDs), selected-semantics README and versioned-semantics PROOF with source. No diff from W13 anchor was reported for the original V1 emitter/catalog/generated semantic runtimes or evaluation-corpus source; the additive gate waiver uses separately named V2 artifacts. This read-only review does not independently replay the retained traces or certify all archive hashes; fresh_evidence_audit owns corpus/metrics reconciliation.

The independent public harness child report is /tmp/japp-w14-fresh-public-source-review.md: no new concrete defect in literal labels, read-only startup acquisition, strict closure, snapshot-union/public accounting or lifecycle boundaries. It verifies the historical acquisition archive and current reviewed harness equality while maintaining zero public actions/scored rows. No actual public scored accuracy or Simplify comparison can be inferred from structural inspection or refusals. Corrected native Windows confirmation and final full root verification remain pending. Owner holdout is waived, not executed or passed.


## Actual reproduction, 2026-10-16

Fresh app-managed worktree: /Users/tanishkalwad/.codex/worktrees/w14-native-validity-review/jobapplyv2. The earlier attached review worktree had extensive unexplained historical edits and was preserved untouched. Frozen offline install resolves workspace dependencies inside the new worktree. Node24.18.0, pnpm11.17.0, Playwright1.62.0, bundled Chromium151.0.7922.34, actual ManifestV3 background service worker and content-isolated native witness were observed.

Exact independent test source: e2e/extension/extension-w14-native-validity-fresh.spec.ts, SHA25665f51576a891624843b7eb443150496814af46610c4810e754ab7050be0e3dbe. Six unchanged tests comprise EXECUTE/UNDO/W11 with and without late native rejection. The expected safety assertions require no VERIFIED result or READY inventory after the rejection; they were not tailored to current behavior.

First run: three positives PASS, three negatives FAIL. Both execute and undo return VERIFIED/site_acceptance=ACCEPTED while physical validity.valid=false, customError=true, validationMessage='Late synthetic site rejection', same value and zero MutationObserver records. Execute still returns undo_available=true. W11 publishes RECONCILED/READY, and an immediate fresh reconciliation returns NOT_READY. Native values are Synthetic (execute/W11) and Prior (undo). All six observations use actual browser service workers. Raw /tmp/japp-w14-validity-before-summary.json, before-results.json, before.log and before-artifacts retain evidence and failure traces. Its early runtime snapshot was taken after command dispatch; that provenance limit is disclosed.

A second fresh sealed RED run closes that binding gap without modifying the six probes or cleaning first artifacts. /tmp/japp-w14-validity-sealed-red-before.json and sealed-red-after.json independently invoke canonical captureRuntimeInventory before dispatch and after completion. All355 declared runtime files, the probe, all six built-extension files, HEAD/status, toolchain, invocation and environment are identical at both endpoints. Source digest sha256:7671a04ad0c5f542a0526be208f61b5fafa6ae72e0f4d31acf71d6133f091557; built-extension inventory digest eb54c017bc91ea1dca963e3d6ec5dcc6bd0684e910fdee2345f4d748815f7cb1. /tmp/japp-w14-validity-sealed-red-binding.json records all_equal=true. The sealed run again gives3 PASS/3 FAIL, with no skips/flaky outcomes. All first artifacts remain unchanged.

Executed sealed command, cwd outside worktree:
PATH=/opt/homebrew/opt/node@24/bin:$PATH PLAYWRIGHT_JSON_OUTPUT_NAME=/tmp/japp-w14-validity-sealed-red-results.json pnpm exec playwright test e2e/extension/extension-w14-native-validity-fresh.spec.ts --trace on --output /tmp/japp-w14-validity-sealed-red-artifacts --reporter=list,json > /tmp/japp-w14-validity-sealed-red.log 2>&1

Separate implementation agent prepared a two-file correction, which this fresh reviewer inspected and independently replayed outside root. The scoped local defect is fixed in that outside candidate; root integration and a complete affected frozen aggregate remain required.


## Independent after-fix review

Inspected exact patch /tmp/japp-w14-native-validity-fix/NATIVE-VALIDITY-DELTA.patch (SHA25656382908665d5fd4c8543df701b67498b3f222bafc768164a15607755b0d21e8). It changes only driver-dom.ts and driver-engine.ts. Primitive native acceptance snapshots cover bounded unique native anchor/member and driver acceptanceElements controls. The initial input bound and union bound remain129; over-capacity refuses. Existing value/files/select/extra-driver, semantic ownership/option, exact description and DOM evidence fences are preserved. Final callbacks perform property comparisons with no new await, events, writes, hash or tree walk. Schema/outcome/reason synthesis is unchanged.

Applying only this exact patch to the outside d99 worktree yields6/6 PASS on the byte-identical independent probes, with0 skip/flaky outcomes. Late rejection produces NEEDS_REVIEW for execute/undo and ROOT_UNRESOLVED for the paused W11 inventory, followed by NOT_READY. Unchanged positives remain VERIFIED/VERIFIED/READY. Green pre/post full355 runtime, probe, built-extension, HEAD/status, toolchain, template invocation and environment equality all pass. Green runtime sha256:c3757409d0e43b12e517eae863e4985d8a509273dd45b86f59a5bfb8478cc89c; green build inventory be3d8669a529e697c566dcdd9d38774012d1cf27fd7b540e78f1dd760066737b. Exact artifacts and scopes are in sealed-green files and red-green-summary.json. Before source versus fixed source differs exactly at the two declared paths.

Adjacent unchanged real-MV3 publication, option-meaning, native witness, composite-clearing and ownership regressions pass29/29. Original raw probe remains byte-identical. Its e2e TypeScript check passes; typed ESLint identifies four standalone style findings (boolean template interpolation twice, non-null assertion twice), retained honestly. A separate integration-ready regression copy resolves them with String(boolean), preserving seed strings, and explicit null narrowing; every safety assertion is unchanged. Its four-hunk derivation diff is retained. Clean probe SHA256b0c3bcb6b93eee78ad1a45f001f1b33cead19e2c703093b515f9f34f037fed33; typed ESLint and e2e TypeScript pass; the clean copy independently passes6/6 in actual MV3 with0 skip/flaky and equal pre/post full runtime, both probe hashes, build and toolchain. No original failure artifact was deleted or overwritten.

Capture metadata distinction: the reusable capture helper stores a generic raw-probe invocation template. The integration run retains that template field rather than rewriting the original capture; authoritative per-run exact argv/config is in each Playwright results.json. An invocation annotation explicitly records the clean copy command and this distinction. No different test was executed under the raw probe's hash.

Scoped verdict: the confirmed local native-validity publication defect has a reviewed and independently reproduced outside correction. Root integration and final complete affected verification are pending; this report does not approve M02-W14/W15/GateA. Public scored coverage, normal-user Simplify comparison, corrected native Windows confirmation and final independent GateA decision remain external limitations. Holdout is waived, never executed/passed. Root source/index/build/test/ignored outputs were never changed by this reviewer.
