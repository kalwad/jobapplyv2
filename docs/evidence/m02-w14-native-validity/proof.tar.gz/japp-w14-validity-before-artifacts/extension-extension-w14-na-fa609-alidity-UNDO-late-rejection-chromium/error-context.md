# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w14-native-validity-fresh.spec.ts >> fresh native validity UNDO late rejection
- Location: e2e/extension/extension-w14-native-validity-fresh.spec.ts:75:5

# Error details

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "VERIFIED"
```

# Test source

```ts
  126 |               ? runtimeMessage(
  127 |                   h.controller,
  128 |                   buildUndoTabRequest("fresh-native-validity-undo", h.tabId, {
  129 |                     transaction_id: tx.transaction_id,
  130 |                     address: tx.address,
  131 |                     settle: { budget_ms: 75 },
  132 |                   }),
  133 |                 )
  134 |               : dynReconcile(h, top.frame_context.frame_id);
  135 |         pending = operationPromise;
  136 |         await expect
  137 |           .poll(
  138 |             async () => {
  139 |               const response = await witness.session.send("Runtime.evaluate", {
  140 |                 contextId: witness.contextId,
  141 |                 expression:
  142 |                   "globalThis.__JAPP_W14_TEST_RESULT_HASH_PAUSE__?.reached === true",
  143 |                 returnByValue: true,
  144 |               });
  145 |               return response.result.value === true;
  146 |             },
  147 |             { timeout: 5000 },
  148 |           )
  149 |           .toBe(true);
  150 |         const physical = await h.page.evaluate((reject) => {
  151 |           const input = document.querySelector("input");
  152 |           if (input === null) throw new Error("native input missing");
  153 |           const read = () => ({
  154 |             value: input.value,
  155 |             valid: input.validity.valid,
  156 |             customError: input.validity.customError,
  157 |             willValidate: input.willValidate,
  158 |             validationMessage: input.validationMessage,
  159 |             ariaInvalid: input.getAttribute("aria-invalid"),
  160 |           });
  161 |           const before = read();
  162 |           const observer = new MutationObserver(() => undefined);
  163 |           observer.observe(document, {
  164 |             subtree: true,
  165 |             childList: true,
  166 |             attributes: true,
  167 |             characterData: true,
  168 |           });
  169 |           if (reject) input.setCustomValidity("Late synthetic site rejection");
  170 |           const records = observer.takeRecords().length;
  171 |           observer.disconnect();
  172 |           return { before, after: read(), mutationRecords: records };
  173 |         }, lateRejection);
  174 |         await witness.session.send("Runtime.evaluate", {
  175 |           contextId: witness.contextId,
  176 |           expression:
  177 |             "globalThis.__JAPP_W14_TEST_RESULT_HASH_PAUSE__.release()",
  178 |         });
  179 |         const completed = await operationPromise;
  180 |         pending = undefined;
  181 |         const current =
  182 |           operation === "W11"
  183 |             ? await dynReconcile(h, top.frame_context.frame_id)
  184 |             : null;
  185 |         await record(
  186 |           info,
  187 |           `fresh-native-validity-${operation}-${lateRejection}`,
  188 |           {
  189 |             operation,
  190 |             lateRejection,
  191 |             field,
  192 |             tx,
  193 |             initial,
  194 |             baseline,
  195 |             physical,
  196 |             completed,
  197 |             current,
  198 |             native: await witness.snapshot(),
  199 |             browserVersion: extensionContext.browser()?.version(),
  200 |             serviceWorkerUrl: serviceWorker.url(),
  201 |           },
  202 |         );
  203 |         expect(physical.mutationRecords).toBe(0);
  204 |         expect(physical.after.value).toBe(physical.before.value);
  205 |         expect(physical.after.valid).toBe(!lateRejection);
  206 |         expect(physical.after.customError).toBe(lateRejection);
  207 |         if (operation === "EXECUTE") {
  208 |           const execution = completed as Awaited<ReturnType<typeof dynExecute>>;
  209 |           if (lateRejection)
  210 |             expect(firstDriverOutcome(execution)).not.toBe("VERIFIED");
  211 |           else {
  212 |             expect(firstDriverOutcome(execution)).toBe("VERIFIED");
  213 |             const item = execution.items[0];
  214 |             expect(
  215 |               item !== undefined &&
  216 |                 "undo_available" in item &&
  217 |                 item.undo_available,
  218 |             ).toBe(true);
  219 |           }
  220 |         } else if (operation === "UNDO") {
  221 |           const undo = parseUndoTabResult(completed);
  222 |           expect(undo?.outcome.status).toBe("COMPLETED");
  223 |           if (undo?.outcome.status !== "COMPLETED")
  224 |             throw new Error("undo result absent");
  225 |           if (lateRejection)
> 226 |             expect(undo.outcome.result.outcome).not.toBe("VERIFIED");
      |                                                     ^ Error: expect(received).not.toBe(expected) // Object.is equality
  227 |           else expect(undo.outcome.result.outcome).toBe("VERIFIED");
  228 |           expect(physical.after.value).toBe("Prior");
  229 |         } else {
  230 |           const publication = completed as Awaited<
  231 |             ReturnType<typeof dynReconcile>
  232 |           >;
  233 |           if (lateRejection) {
  234 |             expect(reconciled(current!).inventory.readiness).toBe("NOT_READY");
  235 |             expect(
  236 |               publication.status === "RECONCILED" &&
  237 |                 publication.inventory.readiness === "READY",
  238 |             ).toBe(false);
  239 |           } else {
  240 |             expect(reconciled(publication).inventory.readiness).toBe("READY");
  241 |             expect(reconciled(current!).inventory.readiness).toBe("READY");
  242 |           }
  243 |         }
  244 |       } finally {
  245 |         await witness.session.send("Runtime.evaluate", {
  246 |           contextId: witness.contextId,
  247 |           expression:
  248 |             "globalThis.__JAPP_W14_TEST_RESULT_HASH_PAUSE__?.restore()",
  249 |         });
  250 |         await pending?.catch(() => undefined);
  251 |         await witness.dispose();
  252 |         await h.page.close();
  253 |         await h.controller.close();
  254 |       }
  255 |     });
  256 |   }
  257 | }
  258 | 
```