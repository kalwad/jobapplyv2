# W14 native validity publication correction

Base: d99c5921338984d6727a0a81bc38d7c628b41199. Draft production correction outside root only. Root remained frozen and unchanged. This correction does not constitute W15/Gate A approval.

Patch: `NATIVE-VALIDITY-DELTA.patch`, SHA256 `56382908665d5fd4c8543df701b67498b3f222bafc768164a15607755b0d21e8`. Exact two-file preimages and final hashes are in `source-manifest.json`.

The independent reviewer confirmed that `setCustomValidity()` can change native acceptance during awaited result metadata without changing the control value or emitting any MutationObserver record. EXECUTE and UNDO could publish VERIFIED; W11 could retain READY. The original six probes were not modified by this implementation agent.

The correction snapshots the exact native inputs consumed by `readSiteAcceptance`: `willValidate`, `validity.valid`, and `validationMessage`. `ValidityState` itself is live, so its object identity is not a snapshot. Comparing these three scalar inputs catches changed native acceptance without inventing a new authority source. The existing value/checked/files/select witnesses and 129-element original input bound remain. The union of native target and acceptance controls is separately bounded to 129 unique native controls; excess observations refuse rather than publish a partial proof.

Driver acceptance-source audit:

| Drivers | Site-acceptance scope | Witness coverage |
|---|---|---|
| Native text/textarea, date, select, checkbox, radio | Default anchor and members | Existing value sources plus native acceptance scalars |
| File upload | File host plus application-root `[role=status][data-tone]` nodes | File host plus any native status nodes; non-native text/attributes retain DOM/index fences |
| Editable ARIA combobox | Input host plus application-root `.error[role=status]` nodes | Host plus any native error nodes; non-native text/attributes retain DOM/index fences |
| ARIA listbox / Workday research prompt | Driver's selected host | Native hosts if present; custom hosts retain existing selected-option and DOM/index fences |
| Repeater | Repeater root | Native acceptance root if present; native controller remains in target witness; existing repeater observation/DOM fences remain |

`captureDriverObservationWitness` now passes `driver.acceptanceElements(context)` into the native witness. This prevents an auxiliary native error/status control's acceptance from escaping merely because it is not the target's anchor/member. Driver queries happen only when capturing the witness, before observation awaits. The new final callback performs bounded scalar property comparisons only: no await, event, mutation, hash or tree walk. Existing publication downgrade branches/reasons and all other fences remain unchanged. No compiler, schema, RPC, policy or test source changed.

Static validation (outside, pinned Node24): strict TypeScript with the repository's inherited strict flags PASS; repository typed ESLint configuration PASS; Prettier check PASS. The initial standalone typecheck omitted Node types and failed on unchanged contract imports; the corrected standalone config explicitly reads the pinned Node type definitions and passed. These are outside source checks, not a whole-repository run.

Fresh independent actual proof, reported and retained by `/root/fresh_safety_review`: sealed RED has 3 unchanged positives PASS and 3 safety negatives FAIL. Applying only this exact two-file patch yields GREEN6/6 on the same immutable probes. Late rejection makes EXECUTE/UNDO NEEDS_REVIEW; W11 initially ROOT_UNRESOLVED and on a fresh pass NOT_READY. No-race execute/undo remain VERIFIED and W11 READY. Full355 runtime/probe/build/toolchain/HEAD/status bindings are equal at both endpoints of each run. See `/tmp/japp-w14-validity-sealed-red-binding.json`, `/tmp/japp-w14-validity-sealed-green-binding.json`, and `/tmp/japp-w14-validity-red-green-summary.json` (reviewer-owned proof; not reauthored here).

Root integration and the complete affected frozen regression remain with root after its active aggregate ends. Public scored coverage, Simplify comparison and final independent gate review remain incomplete.
