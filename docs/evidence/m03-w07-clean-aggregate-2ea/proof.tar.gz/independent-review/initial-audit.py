"""Independent 2ea data review, adapting the prior b28 audit structure. No subject actor."""
from pathlib import Path
import collections,datetime,hashlib,json,os,re,shlex,stat,struct,subprocess
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');P=E/'full-2ea0fde';OUT=Path(__file__).parent;ROOT=Path('/Users/tanishkalwad/jobapplyv2');HEAD='2ea0fdedb5eb5452027d9b9760541bd1c30b0e12';TREE='785d5bad70977edd51afbe602ad2abff39c8458d';rows=[]
def ck(n,v,d=None):rows.append({'name':n,'pass':bool(v),'detail':d})
def doc(p):return json.loads(p.read_bytes())
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode);b=p.read_bytes();z=p.lstat();assert (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_mode)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns,z.st_mode) and len(b)==a.st_size
 return {'bytes':len(b),'mode':stat.S_IMODE(a.st_mode),'sha256':hashlib.sha256(b).hexdigest()}
initial={str(q.relative_to(P)):pin(q) for q in sorted(P.rglob('*')) if q.is_file()}
before,after=doc(P/'before.json'),doc(P/'after.json');ctx,end=doc(P/'context.json'),doc(P/'end-context.json');closure=doc(P/'closure.json');results=doc(P/'results.json')
ck('source2240',len(before['source'])==len(after['source'])==2240);ck('runtime40',len(before['runtime'])==len(after['runtime'])==40);ck('all_snapshot_equal',before==after)
for n,r in before['source'].items():ck('source_endpoint:'+n,r==after['source'].get(n))
for n,r in before['runtime'].items():ck('runtime_endpoint:'+n,r==after['runtime'].get(n))
ck('clean_status_endpoints',before['git_status']==after['git_status']=='')
ck('context_heads',ctx['commit']==end['commit']==HEAD and ctx['tree']==end['tree']==TREE)
ck('closure_all_true',all(closure[k] is True for k in ('source_bytes_modes_unchanged','runtime_bytes_modes_unchanged','commit_and_tree_equal_at_end_observation','all_commands_exit_zero')))
ck('context_time_order',datetime.datetime.fromisoformat(ctx['start_utc'])<datetime.datetime.fromisoformat(end['observed_utc'])<=datetime.datetime.fromisoformat(closure['end_utc']))
ck('exact_outer_commands',[r['argv'] for r in results]==[['pnpm','run','doctor'],['pnpm','verify']])
for r in results:ck('closed:'+r['name'],r['exit_code']==0 and r['timeout'] is False and r['direct_child_reaped'] is True and r['observed_group']=='ABSENT' and r['outer_cleanup_signals']==[])
ck('outer_elapsed',results[0]['seconds']==6.311710459063761 and results[1]['seconds']==1164.6463222919265)
wrapper=(P/'wrapper-executed.py').read_text();ck('explicit_end_pointer_observation',"(OUT / 'end-context.json')" in wrapper and "['git', 'rev-parse', 'HEAD^{tree}']" in wrapper)
# Independently stream retained immutable local Git bodies using bounded metadata commands.
commands=[]
def git(args,inputs=None):
 c=subprocess.run(['/usr/bin/git','--no-pager','--no-optional-locks','-C',str(ROOT),*args],input=inputs,stdin=None if inputs is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,check=True,env={'PATH':'/usr/bin:/bin','LC_ALL':'C','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0'})
 commands.append({'args':args,'exit_code':c.returncode,'stdout_bytes':len(c.stdout),'stdout_sha256':hashlib.sha256(c.stdout).hexdigest(),'stderr_bytes':len(c.stderr)});return c.stdout
actualtree=git(['rev-parse',HEAD+'^{tree}']).decode().strip();ck('immutable_tree',actualtree==TREE)
listing=git(['ls-tree','-r','-z',HEAD]);entries=[]
for item in listing.split(b'\0'):
 if not item:continue
 meta,n=item.split(b'\t',1);mode,kind,oid=meta.decode().split();assert kind=='blob' and mode in ('100644','100755');entries.append((n.decode(),mode,oid))
ck('immutable_exact_paths',len(entries)==2240 and {n for n,_,_ in entries}==before['source'].keys())
ids=sorted({oid for _,_,oid in entries});request=('\n'.join(ids)+'\n').encode();sizes=git(['cat-file','--batch-check'],request);total=sum(int(r.split()[2]) for r in sizes.decode().splitlines());assert total<512*1024*1024
raw=git(['cat-file','--batch'],request);view=memoryview(raw);offset=0;blobs={};payloads={};wanted={oid for n,_,oid in entries if n in {'scripts/python-test-inventory.v1.json','scripts/verification-suites.json'}}
for oid in ids:
 stop=raw.index(b'\n',offset);actual,kind,size=raw[offset:stop].decode().split();size=int(size);offset=stop+1;body=view[offset:offset+size];offset+=size;assert raw[offset:offset+1]==b'\n';offset+=1
 frame=hashlib.sha1(b'blob '+str(size).encode()+b'\0');frame.update(body);assert actual==oid and kind=='blob' and len(body)==size and frame.hexdigest()==oid
 blobs[oid]={'bytes':size,'sha256':hashlib.sha256(body).hexdigest()}
 if oid in wanted:payloads[oid]=bytes(body)
ck('immutable_full_framing',offset==len(raw))
observed={};inventory=None
for n,mode,oid in entries:
 row={**blobs[oid],'git_mode':mode,'git_blob':oid};observed[n]=row;snapshot=before['source'][n]
 ck('immutable_body:'+n,snapshot['bytes']==row['bytes'] and snapshot['sha256']==row['sha256'])
 ck('immutable_execute_class:'+n,bool(snapshot['mode']&0o111)==(mode=='100755'))
 if n=='scripts/python-test-inventory.v1.json':inventory=json.loads(payloads[oid])
(OUT/'immutable-source-joins.json').write_text(json.dumps({'commit':HEAD,'tree':TREE,'scope':'Actual immutable local Git bodies and execute classes, no later worktree body substitution/full-mode inference','files':observed,'metadata_commands':commands,'unique_blob_bytes':total},indent=2)+'\n')
# Bind the unchanged staged payload to earlier separately reviewed endpoints.
for earlier in ('full-80e68ac','full-9872aca'):
 prior=doc(E/earlier/'before.json')['runtime'];ck('runtime_baseline:'+earlier,prior==before['runtime'])
package=doc(E/'mac-package-refreshed/app-build-before.json');ck('runtime_package_binding',package['runtime']==before['runtime'])
ck('runtime_manifest',before['runtime']['manifest.json']['sha256']=='ad2c977971924201a3d1eb7b8c6631db2c8739831f5fe131f2448e0b7914abd9')
ck('runtime_size',sum(r['bytes'] for r in before['runtime'].values())==29903346)
# Parse actual logs, not fixture strings echoed during tests.
log=(P/'verify.log').read_text();lines=log.splitlines();doctor=(P/'doctor.log').read_text();ck('doctor28',bool(re.search(r'^summary: 28 pass, 0 warning, 0 fail, 0 not-yet-applicable$',doctor,re.M)))
summary=log.split('== verification summary ==')[-1];suite_rows=[m.groups() for m in re.finditer(r'^([a-z0-9-]+)\s+(ACTIVE)\s+(PASS)\s*$',summary,re.M)]
expected_suites=['toolchain','format','lint','typecheck','unit-ts','contract-gen','fixture-corpus','evaluation-corpus','contract','build','e2e-browser','w14-public-controlled','w14-public-contact-controlled','visual','python','rust','portability','traceability','status','integrity'];ck('20_active_pass',[r[0] for r in suite_rows]==expected_suites and 'verification exit code: 0' in summary)
collect_index=next(i for i,r in enumerate(lines) if r.startswith('$ uv run pytest ') and '--collect-only' in r);collect_end=next(i for i in range(collect_index+1,len(lines)) if lines[i].startswith('2477 tests collected'))
collected=[r for r in lines[collect_index+1:collect_end] if re.match(r'^(scripts|services|packages)/.+::',r)];ck('2477_collection',len(collected)==len(set(collected))==2477)
expected=sorted(inventory['common']['node_ids']+inventory['posix_only_node_ids']);ck('collection_catalog',sorted(collected)==expected and inventory['common']['count']==2475 and len(inventory['posix_only_node_ids'])==2)
collected_digest=hashlib.sha256(('\n'.join(sorted(collected))+'\n').encode()).hexdigest();ck('collection_digest_matches_immutable_catalog',collected_digest==hashlib.sha256(('\n'.join(expected)+'\n').encode()).hexdigest())
execution_index=next(i for i in range(collect_end+1,len(lines)) if lines[i].startswith('$ uv run pytest ') and '--collect-only' not in lines[i]);cargs=shlex.split(lines[collect_index][2:]);eargs=shlex.split(lines[execution_index][2:]);ck('execution_same_argv',[s for s in cargs if s not in ('--collect-only','-q')]==eargs)
ck('2477_actual_pass',bool(re.search(r'^=+ 2477 passed in 412\.73s \(0:06:52\) =+$',log,re.M)))
# Fresh TypeScript unit tasks: exclude other later focused suites and cached typechecking.
start=log.index('$ pnpm exec turbo run test --force --concurrency=2 -- --reporter=default');stop=log.index('$ pnpm exec turbo run build --force');ts=log[start:stop];counts=re.findall(r'^(@japp/[^:]+):test:\s+Tests\s+([0-9]+) passed \(\2\)\s*$',ts,re.M)
ck('ts15_4006',len(counts)==len({n for n,_ in counts})==15 and sum(int(c) for _,c in counts)==4006);ck('ts_zero_cached','Cached:    0 cached, 15 total' in ts)
for text in ('278 passed (8.4m)','2 passed (1.7s)','62 passed (40.4s)','17 passed (7.4s)'):ck('browser_actual:'+text,any(r.strip()==text for r in lines))
# Exact native test sets per executed feature argv, plus separate unit/contract.
feature_args=['$ cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml','$ cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml --all-features','$ cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml --features tauri/custom-protocol'];native=[]
for command in feature_args:
 i=lines.index(command);j=next((n for n in range(i+1,len(lines)) if lines[n].startswith('$ ')),len(lines));section=lines[i+1:j];cases=re.findall(r'^test (.+) \.\.\. ok$', '\n'.join(section),re.M);native.append(set(cases));ck('native342:'+command,len(cases)==len(set(cases))==342 and any('test result: ok. 342 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in r for r in section))
ck('same342_three_modes',native[0]==native[1]==native[2]);ck('separate_native1','test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in log);ck('separate_contract10','test result: ok. 10 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in log)
# Finite stable visual retention, with explicit duplicate aliases and prior captures.
ret=P/'retained-visual';r=doc(ret/'retention.json');ck('retention_pin',pin(ret/'retention.json')['sha256']=='1050b03a915d47d1dc1e330d4799336e2ecc038c53cae7cc242c153d98e2ddb1');ck('retention_context',r['context']==ctx)
ck('retention_counts',r['selected_regular_files']==33 and r['png_files']==19 and r['other_metadata_files']==14 and r['unique_bodies']==29 and len(r['files'])==33 and len(r['excluded_original_files'])==34)
bodycounts=collections.Counter();selected={q['path']:q for q in r['files']};pngs=[]
for q in r['files']:
 n=q['path'];ck('retained_visual:'+n,pin(ret/n)=={k:q[k] for k in ('bytes','mode','sha256')});bodycounts[q['sha256']]+=1
 if n.endswith('.png'):
  b=(ret/n).read_bytes();ck('PNG_signature:'+n,b[:8]==b'\x89PNG\r\n\x1a\n' and b[12:16]==b'IHDR');pngs.append(n);ck('prior80_png:'+n,pin(E/'full-80e68ac/retained-visual'/n)['sha256']==q['sha256'])
ck('29unique_bodies',len(bodycounts)==29);ck('PNG19',len(pngs)==19)
ck('retained_exact_file_set',{str(q.relative_to(ret)) for q in ret.rglob('*') if q.is_file()}==set(selected)|{'retention.json'})
aliases=[q for q in r['excluded_original_files'] if '/attachments/' in q['path']];marker=[q for q in r['excluded_original_files'] if q['path']=='.last-run.json'];ck('excluded_shape',len(aliases)==33 and len(marker)==1)
for q in aliases:
 directory=q['path'].split('/attachments/')[0];matches=[s for n,s in selected.items() if str(Path(n).parent)==directory and all(s[k]==q[k] for k in ('bytes','mode','sha256'))];ck('exact_alias_body:'+q['path'],len(matches)==1)
ck('full67_inventory',len(set(selected)|{q['path'] for q in r['excluded_original_files']})==67)
ck('retention_not_backdated',r['aggregate_state_at_retention'].startswith('RUNNING/') and datetime.datetime.fromisoformat(ctx['start_utc'])<datetime.datetime.fromisoformat(r['observed_utc'])<datetime.datetime.fromisoformat(end['observed_utc']))
registry=json.loads(payloads[next(oid for n,mode,oid in entries if n=='scripts/verification-suites.json')])
ck('all20_summary_exact_immutable_registry',[r[0] for r in suite_rows]==[s['id'] for s in registry['suites']])
command_lines=[(i,shlex.split(line[2:])) for i,line in enumerate(lines) if line.startswith('$ ')]
cursor=-1;suite_command_joins=[]
def strip_canonical_config(args):
 result=[];i=0
 while i<len(args):
  if args[i] in ('--config','--config-file') and i+1<len(args) and args[i+1]=='pyproject.toml':i+=2
  else:result.append(args[i]);i+=1
 return result
for suite in registry['suites']:
 observed_commands=[]
 for declared in suite['commands']:
  candidates=[]
  for index,args in command_lines:
   if index<=cursor:continue
   actual=strip_canonical_config(args) if suite['id']=='python' else args
   matches=(actual[:len(declared)]==declared)
   if matches:candidates.append((index,args))
  ck('normal_registry_command:'+suite['id']+':'+str(len(observed_commands)),bool(candidates),{'declared':declared,'observed':candidates[0][1] if candidates else None})
  if candidates:cursor=candidates[0][0];observed_commands.append(candidates[0][1])
 suite_command_joins.append({'id':suite['id'],'declared_commands':len(suite['commands']),'observed_commands':observed_commands,'proofs':suite['proofs'],'builtin':suite.get('builtin')})
ck('toolchain_six_actual_commands',all(any(args==expected for _,args in command_lines) for expected in [['node','--version'],['pnpm','--version'],['uv','run','python','--version'],['uv','--version'],['rustup','show','active-toolchain'],['cargo','--version']]))
integrity_start=lines.index('$ git ls-files')
integrity_end=lines.index('== verification summary ==')
integrity_paths=[line for line in lines[integrity_start+1:integrity_end] if line.strip()]
ck('integrity_actual2240_listing_exact_source_paths',len(integrity_paths)==2240 and set(integrity_paths)==set(before['source']))
strict_prefix=['uv','run','pytest','-c','pyproject.toml','--rootdir=.','--confcutdir=.','-o','addopts=','-ra','--strict-markers','--strict-config','--disable-plugin-autoload','--collect-only','-q']
ck('Python_canonical_strict_collection_prefix_and_exact_file_set',cargs[:len(strict_prefix)]==strict_prefix and cargs[len(strict_prefix):]==sorted({n.split('::',1)[0] for n in collected}))
old_inventory=json.loads(git(['show','b28b2b9f245d057bea24b92f28ca131a7cf349c9:scripts/python-test-inventory.v1.json']))
ck('all_prior2141_Python_IDs_preserved_exact2_POSIX_336_new_common',set(old_inventory['common']['node_ids'])<=set(inventory['common']['node_ids']) and old_inventory['posix_only_node_ids']==inventory['posix_only_node_ids'] and len(set(inventory['common']['node_ids'])-set(old_inventory['common']['node_ids']))==336)
def between(first,last):return log[log.index(first):log.index(last,log.index(first)+len(first))]
ck('normal_typecheck_task_count15_cache_disclosed','Tasks:    15 successful, 15 total' in between('$ pnpm exec turbo run typecheck\n','$ pnpm exec tsc -p tsconfig.json') and 'Cached:    15 cached, 15 total' in between('$ pnpm exec turbo run typecheck\n','$ pnpm exec tsc -p tsconfig.json'))
ck('normal_fixture_exact165_and_evaluation218_proofs',sum(int(n) for n in re.findall(r'^\s+Tests\s+(\d+) passed',between('$ pnpm --filter @japp/test-fixtures exec vitest run test/m02-w01','$ pnpm --filter @japp/evaluation-corpus corpus:check'),re.M))==165 and bool(re.search(r'^\s+Tests\s+218 passed',between('$ pnpm --filter @japp/evaluation-corpus test','$ pnpm --filter @japp/contracts exec vitest run test/contract'),re.M)))
ck('normal_contract745_and_build3_task_proofs',bool(re.search(r'^\s+Tests\s+745 passed',between('$ pnpm --filter @japp/contracts exec vitest run test/contract','$ pnpm exec turbo run build --force'),re.M)) and 'Tasks:    3 successful, 3 total' in between('$ pnpm exec turbo run build --force\n','$ pnpm exec playwright test\n'))
browser_identity_sets={}
for label,run_command,list_command,count in [
 ('browser','$ pnpm exec playwright test\n','$ pnpm exec playwright test --list',278),
 ('public','$ pnpm exec playwright test --config e2e/extension/public-research/playwright.config.ts\n','$ pnpm exec playwright test --config e2e/extension/public-research/playwright.config.ts --list',2),
 ('contact','$ pnpm exec playwright test --config e2e/extension/public-contact/playwright.config.ts --reporter=list,json\n','$ pnpm exec playwright test --config e2e/extension/public-contact/playwright.config.ts --reporter=list,json --list',62),
 ('visual','$ pnpm exec playwright test e2e/visual --output test-results/visual\n','$ pnpm exec playwright test e2e/visual --output test-results/visual --list',17)]:
 i=log.index(run_command);j=log.index(list_command,i+len(run_command));k=log.find('\n$ ',j+len(list_command));k=len(log) if k<0 else k
 executed=re.findall(r'^  [✓✔]\s+\d+ (?:\[.*?\] › )?(?:e2e/)?(.+:\d+:\d+ › .+) \([\d.]+(?:ms|s|m)\)$',log[i:j],re.M)
 listed=re.findall(r'^  (?:\[.*?\] › )?(.+:\d+:\d+ › .+)$',log[j:k],re.M)
 if label in ('public','contact'):executed=[value.rsplit('/',1)[-1] for value in executed]
 ck('normal_discovery_identity_proof:'+label,len(executed)==len(set(executed))==len(listed)==len(set(listed))==count and set(executed)==set(listed))
 browser_identity_sets[label]=executed
ck('normal_W14_pure_scope4_contact2_proofs',bool(re.search(r'^\s+Tests\s+4 passed',between('$ pnpm --filter @japp/extension exec vitest run test/m02-w14/public-inspection/scope.test.ts','$ pnpm --filter @japp/extension build\n'),re.M)) and bool(re.search(r'^\s+Tests\s+2 passed',between('$ pnpm --filter @japp/extension exec vitest run test/m02-w14/public-contact/protocol.test.ts','$ pnpm --filter @japp/extension exec wxt build -b chrome -c test/m02-w14/public-contact/wxt.config.ts'),re.M)))
for item in r['excluded_original_files']:
 path=ROOT/'test-results/visual'/item['path'];ck('excluded_visual_actual_body:'+item['path'],path.is_file() and pin(path)=={k:item[k] for k in ('bytes','mode','sha256')})
final={str(q.relative_to(P)):pin(q) for q in sorted(P.rglob('*')) if q.is_file()};ck('review_evidence_unchanged',initial==final)
report={'scope':'Independent retained-data and immutable local Git review, not source/native/platform acceptance','total':len(rows),'pass_count':sum(r['pass'] for r in rows),'joins':rows,'evidence_pins':initial,'normal_suite_command_joins':suite_command_joins,'actual_browser_case_IDs':browser_identity_sets,'parsed_counts':{'typescript':counts,'python_collection_sha256':collected_digest,'native_case_sets_equal':native[0]==native[1]==native[2],'native_unique_cases':len(native[0]),'suite_names':[q[0] for q in suite_rows]}}
(OUT/'data-joins.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'total':len(rows),'pass':sum(r['pass'] for r in rows),'failed':[r for r in rows if not r['pass']]}))
