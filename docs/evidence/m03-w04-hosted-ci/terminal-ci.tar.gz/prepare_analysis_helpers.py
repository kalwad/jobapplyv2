"""Reuse collector software only. No historical result, source or data transfer."""
import hashlib,json,pathlib
ROOT=pathlib.Path('/tmp/japp-m03-w04-hosted-ci-2a327c6-20261019')
OLD=pathlib.Path('/tmp/japp-m03-w03-hosted-ci-6d3a6b8-20261019')
def sha(b):return hashlib.sha256(b).hexdigest()
changes=[]
for name in ['prepare_platform_logs.py','analyze_closed_ci.py']:
 raw=(OLD/name).read_bytes();source=raw.decode();source=source.replace('from collect_hosted_ci import','from collect_ci import')
 if name=='analyze_closed_ci.py':
  source=source.replace("browser_commands=[('default','$ pnpm exec playwright test',256),('controlled_public_research','$ pnpm exec playwright test --config e2e/extension/public-research/playwright.config.ts',2),('controlled_public_contact','$ pnpm exec playwright test --config e2e/extension/public-contact/playwright.config.ts --reporter=list,json',62),('visual','$ pnpm exec playwright test e2e/visual',3)]", "commands_by_suite={s['id']:s['commands'] for s in registry['suites']}\n    browser_commands=[('default','$ '+' '.join(commands_by_suite['e2e-browser'][0]),262),('controlled_public_research','$ '+' '.join(commands_by_suite['w14-public-controlled'][-1]),2),('controlled_public_contact','$ '+' '.join(commands_by_suite['w14-public-contact-controlled'][-1]),62),('visual','$ '+' '.join(commands_by_suite['visual'][0]),3)]")
  source=source.replace("'expected_count':1651 if label=='windows-2025' else 1653", "'expected_count':1677 if label=='windows-2025' else 1679")
  source=source.replace("{'macos-15':77,'ubuntu-24.04':76,'windows-2025':70}","{'macos-15':138,'ubuntu-24.04':137,'windows-2025':131}")
  old="'scope':'Actual emitted benchmark payload only. Frozen source defaults to1 sample and applies the1500ms Darwin assertion only when sampleCount==20; no one-sample hosted result is promoted to canonical20-sample target evidence.'"
  source=source.replace(old,"'scope':'Actual emitted benchmark payload only. No one-sample hosted result is promoted to canonical20-sample target evidence; exact source is retained separately.'")
  begin=source.index('source_final={');end=source.index("save('source-binding-final.json'",begin)
  source=source[:begin]+"source_final={'head_sha':HEAD,'head_tree_sha':TREE,'actual_checkouts':[{'platform':p['label'],'sha':p['actual_checkout_sha'],'tree':p['actual_checkout_tree']} for p in platforms],'all_actual_content_trees_match':bindings['all_actual_content_trees_match'],'immutable_source_projection':'immutable-source-projection.json','complete_immutable_remote_source_entries':1886,'selected_blob_count':len(load('immutable-source-projection.json')['files']),'actual_checkout_manifest':'platform-logs-manifest.json','canonical_root_observed_or_frozen':False,'scope':'Actual closed-job tested checkout content trees join the immutable new published2a327 tree. Later legitimate canonical-root advancement is independent; no full working-copy byte equality or historical result transfer is claimed.'}\n"+source[end:]
  source=source.replace("load('terminal-check-annotations.json')","load('terminal-non-success-annotations.json')")
  source=source.replace('complete remote/candidate1798-entry source','complete immutable remote1886-entry source')
  source=source.replace('Root/candidate source equivalence, source publication history and the initial private d28 observation remain separate records.','This CI binds the immutable remote head and actual tested merge tree. The canonical root may advance independently and is never scanned or frozen by this collector.')
  source=source.replace('distinct from cancelled run39181477863 and cannot relabel it','distinct from historical run39188122249 Windows cleanup FAILURE and cannot relabel it')
  source=source.replace("'scanner/temp/test-inventory changes coexist.'","'No controlled throughput comparison is inferred.'")
  marker="source_final={'head_sha':HEAD"
  insertion="all_actual_expected_counts_match=all(p['doctor'].get('pass')==28 and p['doctor'].get('warning')==p['doctor'].get('fail')==p['doctor'].get('not_yet_applicable')==0 and p['unit_ts'].get('passed')==4006 and p['unit_ts'].get('ordinary_counts_consistent') and all(b.get('expected_pass_count_matches') and all(count==0 for state,count in b.get('summary_counts',{}).items() if state!='passed') for b in p['playwright'].values()) and p['python'].get('execution_counts')=={'passed':p['python']['expected_count']} for p in platforms)\n"
  source=source.replace(marker,insertion+marker,1)
  source=source.replace("'all_required_native_count_python_and_temp_observations_match':all_required,","'all_required_native_count_python_and_temp_observations_match':all_required,'all_actual_expected_doctor_TS_browser_python_counts_match':all_actual_expected_counts_match,")
  source=source.replace("'official_non_success_annotations':load('terminal-non-success-annotations.json'),","'official_non_success_annotations':load('terminal-non-success-annotations.json'),'official_failure_artifacts':load('official-failure-artifacts-manifest.json'),'actual_visual_registry_argv':next(s['commands'][0] for s in registry['suites'] if s['id']=='visual'),")
  assert 'candidate_git_directory' not in source and 'all_1798_candidate_bytes' not in source and "'expected_count':1651" not in source and 'remote/candidate1798' not in source
 target=ROOT/name;assert not target.exists();target.write_text(source)
 changes.append({'name':name,'software_template':str(OLD/name),'template_sha256':sha(raw),'new_software_sha256':sha(source.encode()),'scope':'Collector code reuse only; no prior evidence, source or result reused.'})
(ROOT/'collector-helper-software-provenance.json').write_text(json.dumps(changes,indent=2)+'\n')
print(json.dumps({'prepared_helpers':[x['name'] for x in changes],'no_source_or_historical_result_copied':True},indent=2))
