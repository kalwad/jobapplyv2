"""Read-only early observation of the actual closed Windows job, before all hosts close."""
import json,re
from collect_ci import ROOT,REPO,RUN_ID,HEAD,TREE,api,capture,save,sha,utc
snapshot=json.loads(sorted(ROOT.glob('snapshot-*.json'))[-1].read_bytes())
job=next(x for x in snapshot['jobs'] if x['job_id']==117874182536)
assert job['status']=='completed' and job['conclusion']=='failure'
folder=ROOT/'early-windows-closure';assert not folder.exists();folder.mkdir()
raw,record=capture(['/opt/homebrew/bin/gh','api','-H','Accept: application/vnd.github+json',f'repos/{REPO}/actions/jobs/{job["job_id"]}/logs'],'early-official-windows-complete-job-log')
(folder/'official-job.log').write_bytes(raw)
check,cr=api(f'repos/{REPO}/check-runs/{job["job_id"]}','early-windows-check')
notes,nr=api(f'repos/{REPO}/check-runs/{job["job_id"]}/annotations?per_page=100','early-windows-annotations')
lines=[re.sub(r'^\d{4}-\d\d-\d\dT\S+\s*','',re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',x)).strip() for x in raw.decode().splitlines()]
positions=[i for i,x in enumerate(lines) if x=='== verification summary ==']
relevant=[{'line':i+1,'text':x} for i,x in enumerate(lines) if x.startswith(('##[error]','Error:','verification exit code:')) or (positions and positions[0]<=i<=positions[0]+24)]
save('early-windows-closure/observation.json',{'run_id':RUN_ID,'head_sha':HEAD,'expected_tree':TREE,'observed_utc':utc(),'actual_job':job,'official_complete_job_log':{'path':'early-windows-closure/official-job.log','bytes':len(raw),'sha256':sha(raw),'command_record':record},'check_record':cr,'annotations_record':nr,'actual_annotations':notes,'selected_actual_lines':relevant,'scope':'Actual closed Windows official job log/check only. Other hosts and run may still be in progress; no all-host or source-tree checkout claim yet.'})
print(json.dumps({'job':job,'log_bytes':len(raw),'actual_annotations':notes,'selected_actual_lines':relevant},indent=2))
