import io,json,pathlib,stat,zipfile
from collect_ci import ROOT,REPO,HEAD,TREE,api,capture,save,sha,identity
release=json.loads((ROOT/'heavy-release.json').read_text());assert release['parent_explicit_release'] is True
if (ROOT/'heavy-hold-w05-full.json').exists():
 resumed=json.loads((ROOT/'heavy-release-after-w05-browser.json').read_text());assert resumed['parent_explicit_release'] is True
snap=json.loads(sorted(ROOT.glob('snapshot-*.json'))[-1].read_text())
assert snap['status']=='completed' and len(snap['jobs'])==3 and all(x['status']=='completed' for x in snap['jobs'])
run_id=identity();attempt=snap['run_attempt']
for name,record in [('final-run.json',snap['run_record']),('final-jobs.json',snap['jobs_record'])]:
 raw=(ROOT/record['stdout']['path']).read_bytes();assert len(raw)==record['stdout']['bytes'] and sha(raw)==record['stdout']['sha256']
 target=ROOT/name;assert not target.exists();target.write_bytes(raw)
metadata,mr=api(f'repos/{REPO}/actions/runs/{run_id}/attempts/{attempt}','terminal-attempt')
assert metadata['id']==run_id and metadata['head_sha']==HEAD and metadata['run_attempt']==attempt and metadata['status']=='completed'
(ROOT/'final-attempt.json').write_bytes((ROOT/mr['stdout']['path']).read_bytes())
annotations=[]
for job in json.loads((ROOT/'final-jobs.json').read_text())['jobs']:
 if job['conclusion']=='success':continue
 check,cr=api(f"repos/{REPO}/check-runs/{job['id']}",'terminal-check-'+str(job['id']))
 notes,nr=api(f"repos/{REPO}/check-runs/{job['id']}/annotations?per_page=100",'terminal-annotations-'+str(job['id']))
 annotations.append({'job_id':job['id'],'conclusion':job['conclusion'],'check_record':cr,'annotations_record':nr,'annotations':notes})
save('terminal-non-success-annotations.json',{'jobs':annotations,'scope':'Actual official checks/annotations only; no cause or timeout inference.'})
def extract(raw,folder):
 assert not folder.exists();folder.mkdir();rows=[];seen=set();folded=set()
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  infos=z.infolist();assert len(infos)<=20000 and sum(x.file_size for x in infos)<=2*1024*1024*1024
  for info in infos:
   name=info.filename;p=pathlib.PurePosixPath(name)
   assert name and '\\' not in name and '\0' not in name and not p.is_absolute() and '..' not in p.parts
   assert name not in seen and name.casefold() not in folded and not stat.S_ISLNK(info.external_attr>>16)
   seen.add(name);folded.add(name.casefold());assert info.file_size<=512*1024*1024
   target=folder/pathlib.Path(*p.parts)
   if info.is_dir():target.mkdir(parents=True,exist_ok=True);continue
   body=z.read(info);assert len(body)==info.file_size;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();target.write_bytes(body)
   row={'path':name,'bytes':len(body),'sha256':sha(body),'compressed_bytes':info.compress_size,'crc32_hex':f'{info.CRC:08x}'}
   if name.endswith('trace.zip'):
    with zipfile.ZipFile(io.BytesIO(body)) as trace:
     assert sum(x.file_size for x in trace.infolist())<=1024*1024*1024 and trace.testzip() is None
     row.update(inner_trace_zip_crc_checked=True,inner_trace_zip_entries=len(trace.infolist()))
   rows.append(row)
 return {'zip_entry_count':len(infos),'safe_regular_file_count':len(rows),'files':rows,'all_members_read_with_crc_validation':True}
raw,zr=capture(['/opt/homebrew/bin/gh','api','-H','Accept: application/vnd.github+json',f'repos/{REPO}/actions/runs/{run_id}/attempts/{attempt}/logs'],'official-complete-logs-zip')
(ROOT/'logs.zip').write_bytes(raw);manifest=extract(raw,ROOT/'official-logs')
manifest.update(run_id=run_id,run_attempt=attempt,head_sha=HEAD,expected_tree_sha=TREE,official_api_endpoint=zr['argv'][-1],zip={'path':'logs.zip','bytes':len(raw),'sha256':sha(raw),'command_stdout':zr['stdout']['path']})
save('official-logs-manifest.json',manifest)
listing,lr=api(f'repos/{REPO}/actions/runs/{run_id}/artifacts?per_page=100','official-artifacts-list')
assert len(listing['artifacts'])==listing['total_count'];(ROOT/'official-artifacts-list.json').write_bytes((ROOT/lr['stdout']['path']).read_bytes())
artifacts=[]
for artifact in listing['artifacts']:
 if not artifact['name'].startswith('playwright-failure-'):continue
 assert artifact['workflow_run']['id']==run_id and artifact['workflow_run']['head_sha']==HEAD
 if artifact['expired']:
  artifacts.append({'metadata':artifact,'download_status':'EXPIRED_NO_OUTPUT_RECONSTRUCTION'});continue
 raw,ar=capture(['/opt/homebrew/bin/gh','api','-H','Accept: application/vnd.github+json',f"repos/{REPO}/actions/artifacts/{artifact['id']}/zip"],f"official-failure-artifact-{artifact['id']}")
 name='artifact-'+str(artifact['id']);path=ROOT/(name+'.zip');assert not path.exists();path.write_bytes(raw)
 item=extract(raw,ROOT/name);item.update(metadata=artifact,download_status='ACTUAL_OFFICIAL_COMPLETE_ZIP',extracted_folder=name,zip={'path':path.name,'bytes':len(raw),'sha256':sha(raw),'command_stdout':ar['stdout']['path']})
 artifacts.append(item)
save('official-failure-artifacts-manifest.json',{'run_id':run_id,'head_sha':HEAD,'expected_tree_sha':TREE,'list_record':lr,'actual_total_artifacts':listing['total_count'],'artifacts':artifacts,'scope':'Explicit official test outputs only, retained without opening viewers or running actors. Missing/expired outputs are not reconstructed.'})
print(json.dumps({'run_id':run_id,'actual_conclusion':snap['conclusion'],'complete_logs_zip':manifest['zip'],'official_log_regular_files':manifest['safe_regular_file_count'],'official_failure_artifacts':len(artifacts)},indent=2))
