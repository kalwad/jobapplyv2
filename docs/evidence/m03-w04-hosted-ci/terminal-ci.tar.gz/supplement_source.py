import base64,hashlib,json,pathlib
from collect_ci import ROOT,REPO,HEAD,TREE,api,save,sha
path=ROOT/'immutable-source-projection.json';before=path.read_bytes();projection=json.loads(before)
tree=json.loads((ROOT/projection['remote_tree_record']['stdout']['path']).read_bytes());entries={x['path']:x for x in tree['tree'] if x['type']=='blob'}
requested=['e2e/extension/public-research/playwright.config.ts','e2e/extension/public-contact/playwright.config.ts','apps/desktop/src-tauri/src/service/platform.rs','apps/desktop/src-tauri/src/service/runtime_descriptor.rs','scripts/tests/test_ci_workflow.py','scripts/tests/test_portability.py']
assert all(name in entries for name in requested)
files=[]
for index,name in enumerate(requested,1):
 assert name in entries,name
 entry=entries[name];target=ROOT/'source'/name
 if target.exists():
  prior=list((ROOT/'commands').glob(f'*-supplement-source-blob-{index:02d}.record.json'));assert len(prior)==1
  record=json.loads(prior[0].read_bytes());blob=json.loads((ROOT/record['stdout']['path']).read_bytes())
 else:blob,record=api(f"repos/{REPO}/git/blobs/{entry['sha']}",f'supplement-source-blob-{index:02d}')
 assert blob['encoding']=='base64' and blob['sha']==entry['sha'];raw=base64.b64decode(blob['content'])
 assert len(raw)==entry['size']==blob['size'] and hashlib.sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest()==entry['sha']
 if target.exists():assert target.read_bytes()==raw
 else:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 files.append({'path':name,'bytes':len(raw),'sha256':sha(raw),'git_blob_sha':entry['sha'],'git_mode':entry['mode'],'record_stdout':record['stdout']['path']})
initial=ROOT/'immutable-source-projection-initial.json';assert not initial.exists();initial.write_bytes(before)
projection['files']+=files;projection['selected_source_blobs']=len(projection['files']);projection['supplement_note']='Six additional bounded control-output/native-runtime/static-policy blobs retained after initial28 projection. Initial projection remains exact in immutable-source-projection-initial.json.'
path.write_text(json.dumps(projection,indent=2)+'\n')
save('source-supplement.json',{'head_sha':HEAD,'tree_sha':TREE,'initial_projection_sha256':sha(before),'files':files,'current_selected_count':len(projection['files']),'scope':'Additional actual immutable source blobs only; no product execution or current root observation.'})
print(json.dumps({'added':len(files),'total_selected_blobs':len(projection['files'])},indent=2))
