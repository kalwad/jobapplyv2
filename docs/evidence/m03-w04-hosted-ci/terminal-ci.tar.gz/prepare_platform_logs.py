import json,pathlib,re
from collect_ci import ROOT,REPO,RUN_ID,HEAD,TREE,api,sha

manifest=json.loads((ROOT/'official-logs-manifest.json').read_text())
assert sha((ROOT/'logs.zip').read_bytes())==manifest['zip']['sha256']
run=json.loads((ROOT/'final-run.json').read_text());jobs=json.loads((ROOT/'final-jobs.json').read_text())['jobs']
assert run['id']==RUN_ID and run['head_sha']==HEAD and run['status']=='completed'
folder=ROOT/'platform-logs';assert not folder.exists();folder.mkdir()
rows=[];objects={}
for job in jobs:
 roots=[x for x in manifest['files'] if '/' not in x['path'] and x['path'].endswith('_'+job['name']+'.txt')]
 assert len(roots)==1
 entry=roots[0];data=(ROOT/'official-logs'/entry['path']).read_bytes()
 assert len(data)==entry['bytes'] and sha(data)==entry['sha256']
 label=next(x for x in job['labels'] if x in ['windows-2025','macos-15','ubuntu-24.04'])
 target=folder/(label+'.log');target.write_bytes(data)
 text=data.decode('utf-8');text=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',text)
 lines=[re.sub(r'^\d{4}-\d{2}-\d{2}T\S+\s','',x) for x in text.splitlines()]
 checkouts=[]
 for i,line in enumerate(lines):
  if 'log -1 --format=%H' in line:
   checkouts.extend(x.strip() for x in lines[i+1:i+4] if re.fullmatch(r'[0-9a-f]{40}',x.strip()))
 assert len(checkouts)==1
 checkout=checkouts[0]
 if checkout not in objects:
  obj,record=api('repos/{}/git/commits/{}'.format(REPO,checkout),'actual-checkout-git-commit-{}'.format(len(objects)+1))
  assert obj['sha']==checkout
  objects[checkout]={'sha':obj['sha'],'tree':obj['tree']['sha'],'parents':[x['sha'] for x in obj['parents']],'record_stdout':record['stdout']['path']}
 obj=objects[checkout]
 row={'label':label,'job_id':job['id'],'job_name':job['name'],'job_status':job['status'],'job_conclusion':job['conclusion'],'official_combined_member':entry['path'],'platform_log':str(target.relative_to(ROOT)),'bytes':len(data),'sha256':sha(data),'actual_checkout_sha':checkout,'actual_checkout_tree':obj['tree'],'expected_content_tree_matches':obj['tree']==TREE,'checkout_commit_api':obj,'normalized_lines':len(lines),'scope':'Exact complete official combined job-log bytes, not a truncated failed-step view.'}
 rows.append(row)
 print(json.dumps({'platform':label,'checkout':checkout,'tree_matches':row['expected_content_tree_matches'],'log_bytes':len(data),'last_commands':[{'line':i+1,'command':x} for i,x in enumerate(lines) if x.startswith('$ ')][-16:],'last_lines':[{'line':i+1,'text':x} for i,x in enumerate(lines) if i>=len(lines)-65]},indent=2))
(ROOT/'platform-logs-manifest.json').write_text(json.dumps({'run_id':RUN_ID,'head_sha':HEAD,'expected_source_tree':TREE,'platforms':rows,'all_actual_content_trees_match':all(x['expected_content_tree_matches'] for x in rows),'scope':'Actual tested commit/tree from each complete official job log and immutable Git API, independent of PR head assumptions.'},indent=2)+'\n')
