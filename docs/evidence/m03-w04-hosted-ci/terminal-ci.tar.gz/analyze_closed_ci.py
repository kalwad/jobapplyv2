"""Closed official CI log analysis only; no compiler, browser or test actor."""
import collections
import datetime as dt
import json
import re

from collect_ci import ROOT,RUN_ID,HEAD,TREE,sha,utc

def load(name):return json.loads((ROOT/name).read_text())
def save(name,value):
    path=ROOT/name;assert not path.exists();path.write_text(json.dumps(value,indent=2)+'\n')

run=load('final-run.json');jobs=load('final-jobs.json')['jobs'];bindings=load('platform-logs-manifest.json')
assert run['id']==RUN_ID and run['head_sha']==HEAD and run['status']=='completed'
assert len(jobs)==3 and all(j['status']=='completed' for j in jobs)
assert bindings['all_actual_content_trees_match']
registry=load('source/scripts/verification-suites.json');suite_ids=[s['id'] for s in registry['suites']]
assert len(suite_ids)==20
rust_commands=['$ '+' '.join(c) for c in next(s for s in registry['suites'] if s['id']=='rust')['commands']]
assert len(rust_commands)==15
strict_commands=[c for c in rust_commands if c.startswith('$ cargo clippy ')]
native_commands=[c for c in rust_commands if c.startswith('$ cargo test ') and 'apps/desktop/src-tauri' in c]
assert len(strict_commands)==len(native_commands)==3
platforms=[];collection_lines={};native_names={}

for binding in bindings['platforms']:
    label=binding['label'];job=next(j for j in jobs if j['id']==binding['job_id'])
    data=(ROOT/binding['platform_log']).read_bytes();assert sha(data)==binding['sha256'] and len(data)==binding['bytes']
    raw=data.decode('utf-8').splitlines()
    lines=[re.sub(r'^\d{4}-\d\d-\d\dT\S+\s*','',re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',x)).strip() for x in raw]
    assert len(lines)==binding['normalized_lines']
    def ref(i):return {'log':binding['platform_log'],'line':i+1,'text':lines[i],'raw':raw[i]}
    def find(pattern,start=0,end=None):
        return [(i,m) for i,x in enumerate(lines) if i>=start and (end is None or i<end) and (m:=re.fullmatch(pattern,x))]
    def positions(command,start=0):return [i for i,x in enumerate(lines) if i>=start and x==command]
    def unique(command,start=0):
        rows=positions(command,start);assert len(rows)<=1,(label,command);return rows[0] if rows else None
    summary_positions=positions('== verification summary ==');assert len(summary_positions)<=1
    exits=find(r'verification exit code: (\d+)');assert len(exits)<=1
    explicit_command_failures=find(r'- command failed \(exit (\d+)\): (.+)')
    reported={}
    if summary_positions:
        for i,m in find(r'(\S+)\s+(ACTIVE|NOT_YET_APPLICABLE|REQUIRED_MISSING)\s+(\S+)(?:\s+(.*))?',summary_positions[0]+1):
            if m[1] in suite_ids:
                assert m[1] not in reported
                reported[m[1]]={'suite_id':m[1],'state':m[2],'result':m[3],'detail':m[4],'evidence':ref(i)}
    suite_rows=[reported.get(sid,{'suite_id':sid,'state':None,'result':'NOT_REPORTED','detail':'No actual terminal suite row emitted; component observations remain separate.'}) for sid in suite_ids]
    rust_pass=reported.get('rust',{}).get('result')=='PASS'
    doctor=find(r'summary: (\d+) pass, (\d+) warning, (\d+) fail, (\d+) not-yet-applicable');assert len(doctor)<=1
    doctor_result={'status':'NOT_OBSERVED'}
    if doctor:
        i,m=doctor[0];doctor_result={'status':'REPORTED','pass':int(m[1]),'warning':int(m[2]),'fail':int(m[3]),'not_yet_applicable':int(m[4]),'evidence':ref(i)}
    unit_start=unique('$ pnpm exec turbo run test --force -- --reporter=default')
    unit_end=unique('$ pnpm generate:contracts --check')
    unit={'status':'NOT_OBSERVED'}
    if unit_start is not None:
        rows=find(r'Tests\s+(\d+) passed \((\d+)\)',unit_start+1,unit_end)
        files=find(r'Test Files\s+(\d+) passed \((\d+)\)',unit_start+1,unit_end)
        unit={'status':'OBSERVED','workspace_summaries':len(rows),'passed':sum(int(m[1]) for _,m in rows),'test_files':sum(int(m[1]) for _,m in files),'ordinary_counts_consistent':all(m[1]==m[2] for _,m in rows+files),'evidence':[ref(i) for i,_ in rows],'scope':'Only the root forced Turbo unit block; no later repeated corpus or contract counts included.'}
    browser={}
    commands_by_suite={s['id']:s['commands'] for s in registry['suites']}
    browser_commands=[('default','$ '+' '.join(commands_by_suite['e2e-browser'][0]),262),('controlled_public_research','$ '+' '.join(commands_by_suite['w14-public-controlled'][-1]),2),('controlled_public_contact','$ '+' '.join(commands_by_suite['w14-public-contact-controlled'][-1]),62),('visual','$ '+' '.join(commands_by_suite['visual'][0]),3)]
    for key,command,expected in browser_commands:
        start=unique(command)
        row={'status':'NOT_OBSERVED','command':command,'expected_pass_count':expected}
        if start is not None:
            end=next((i for i in range(start+1,len(lines)) if lines[i].startswith('$ ')),len(lines))
            summaries=find(r'(\d+) (passed|failed|skipped|flaky|interrupted|did not run)(?: \(([^)]+)\))?',start+1,end)
            counts=collections.Counter()
            for i,m in summaries:counts[m[2]]+=int(m[1])
            row.update({'status':'OBSERVED','command_evidence':ref(start),'summary_counts':dict(counts),'summary_evidence':[ref(i) for i,_ in summaries],'duration':[m[3] for _,m in summaries if m[2]=='passed'],'expected_pass_count_matches':counts.get('passed')==expected,'scope':'Actual standalone summary lines only; absent statuses are not independently emitted process exit codes.'})
        browser[key]=row
    collect=[i for i,x in enumerate(lines) if x.startswith('$ uv run pytest ') and ' --collect-only -q ' in x]
    execute=[i for i,x in enumerate(lines) if x.startswith('$ uv run pytest ') and ' --collect-only ' not in x]
    assert len(collect)<=1 and len(execute)<=1
    first_clippy=unique(strict_commands[0])
    first_fmt=[i for i in positions(rust_commands[0]) if first_clippy is not None and i<first_clippy]
    rust_start=max(first_fmt) if first_fmt else (first_clippy if first_clippy is not None else len(lines))
    rust_positions={c:unique(c,max(0,rust_start)) for c in rust_commands}
    python={'status':'NOT_OBSERVED','expected_count':1677 if label=='windows-2025' else 1679}
    if collect:
        stop=execute[0] if execute else rust_start
        summaries=find(r'(\d+) tests collected in ([0-9.]+)s',collect[0]+1,stop)
        assert len(summaries)<=1
        if summaries:
            i,m=summaries[0]
            ids=[x for x in lines[collect[0]+1:i] if re.match(r'^(?:scripts|services)/[^ ]+\.py::',x)]
            collection_lines[label]=ids
            duplicate={x:n for x,n in collections.Counter(ids).items() if n>1}
            save(f'python-visible-collected-lines-{label}.json',{'platform':label,'actual_reported_count':int(m[1]),'visible_node_line_count':len(ids),'distinct_visible_lines':len(set(ids)),'visible_node_lines':ids,'duplicate_visible_lines':duplicate,'scope':'GitHub may mask authorization parameter text to repeated *** prefixes; no unredacted unique-ID equality is reconstructed.'})
            python.update({'status':'COLLECTION_OBSERVED','collection_count':int(m[1]),'collection_duration_seconds':float(m[2]),'visible_node_line_count':len(ids),'visible_node_count_matches_reported':len(ids)==int(m[1]),'masked_or_duplicate_visible_lines':duplicate,'collection_summary_evidence':ref(i)})
    if execute:
        end=rust_start if rust_start>execute[0] else len(lines)
        collected=find(r'collected (\d+) items',execute[0]+1,end)
        finals=find(r'=+ (.+) in ([0-9.]+)s(?: \([^)]*\))? =+',execute[0]+1,end)
        assert len(collected)<=1 and len(finals)<=1
        python['execution_command_evidence']=ref(execute[0])
        if collected:python['execution_collection_count']=int(collected[0][1][1])
        if finals:
            i,m=finals[0];counts={key:int(count) for count,key in re.findall(r'(\d+) (passed|failed|skipped|xfailed|xpassed|errors?|deselected)',m[1])}
            python.update({'status':'EXECUTION_SUMMARY_REPORTED','execution_status_text':m[1],'execution_counts':counts,'duration_seconds':float(m[2]),'summary_evidence':ref(i),'actual_collection_matches_expected':python.get('collection_count')==python['expected_count'],'actual_passed_matches_expected':counts.get('passed')==python['expected_count'],'scope':'Real anchored outer pytest execution footer, after the actual execution command. Poison fixture parameter IDs do not count as execution summaries.'})
    def rust_block(command):
        index=rust_commands.index(command);start=rust_positions[command]
        explicit=[(i,m) for i,m in explicit_command_failures if m[2]==command.removeprefix('$ ')];assert len(explicit)<=1
        row={'command':command,'status':'NOT_OBSERVED','direct_process_exit_code':int(explicit[0][1][1]) if explicit else None,'direct_exit_evidence':ref(explicit[0][0]) if explicit else None}
        if start is None:return row
        later=[position for position in rust_positions.values() if position is not None and position>start]
        next_rust=min(later) if later else None
        end=next_rust if next_rust is not None else next((i for i in range(start+1,len(lines)) if lines[i].startswith('$ ') and not lines[i].startswith('$ vite ')),len(lines))
        expected_next=rust_commands[index+1] if index+1<len(rust_commands) else None
        continued=expected_next is not None and rust_positions.get(expected_next)==next_rust and next_rust is not None
        interrupted=[ref(i) for i in range(start+1,end) if lines[i] in ['KeyboardInterrupt','##[error]The operation was canceled.'] or lines[i].startswith('TIMEOUT after ')]
        profiles=[ref(i) for i in range(start+1,end) if re.match(r'^Finished `(?:dev|test)` profile ',lines[i])]
        errors=[ref(i) for i in range(start+1,end) if lines[i].startswith(('error:',"process didn't exit successfully:",'Caused by:','note: test exited abnormally'))]
        results=[]
        for i,m in find(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in (.+)',start+1,end):
            results.append({'result':m[1],'passed':int(m[2]),'failed':int(m[3]),'ignored':int(m[4]),'measured':int(m[5]),'filtered_out':int(m[6]),'duration':m[7],'evidence':ref(i)})
        status='FAILED_REPORTED_PROCESS_EXIT' if explicit else ('COMPLETED_VERIFIER_CONTINUED' if continued and not interrupted else ('COMPLETED_WITH_RUST_SUITE_PASS' if rust_pass and index==len(rust_commands)-1 else ('STARTED_INTERRUPTED' if interrupted else 'STARTED_COMPLETION_NOT_ESTABLISHED')))
        row.update({'status':status,'command_evidence':ref(start),'next_rust_command_evidence':ref(next_rust) if next_rust is not None else None,'finished_profiles':profiles,'test_results':results,'reported_error_evidence':errors,'interruptions':interrupted,'exit_inference':'Exit0 inferred only when the next exact Rust registry command ran under the frozen break-on-nonzero loop, or the final Rust suite actually reports PASS; child exit0 is not separately printed.' if status.startswith('COMPLETED_') else 'No completed process exit is invented; explicit reported error and executable exit text are retained separately.'})
        if command in native_commands:
            names=[m[1] for _,m in find(r'test (\S+) \.\.\. ok',start+1,end)]
            native_names[(label,native_commands.index(command))]=names
            row['passed_library_names']=names
            row['expected_library_count']={'macos-15':138,'ubuntu-24.04':137,'windows-2025':131}[label]
            row['all_required_native_observations_match']=status.startswith('COMPLETED_') and len(results)==3 and [x['passed'] for x in results]==[row['expected_library_count'],0,0] and all(x['result']=='ok' and all(x[k]==0 for k in ['failed','ignored','measured','filtered_out']) for x in results)
        return row
    strict=[rust_block(c) for c in strict_commands];modes=[rust_block(c) for c in native_commands]
    declarations=[]
    for command in ['pnpm run doctor','pnpm verify']:
        starts=positions('##[group]Run '+command)
        assert len(starts)<=1
        row={'command':command,'status':'NOT_OBSERVED'}
        if starts:
            start=starts[0];end=next((i for i in range(start+1,len(lines)) if lines[i]=='##[endgroup]'),len(lines))
            values={};evidence=[]
            for i,m in find(r'(TMPDIR|TEMP|TMP|RUSTUP_HOME):\s*(.*)',start+1,end):values[m[1]]=m[2];evidence.append(ref(i))
            selected=[values.get(k) for k in ['TMPDIR','TEMP','TMP']]
            row.update({'status':'DECLARED_STEP_ENV_OBSERVED','values':values,'all_three_temp_selectors_same':None not in selected and len(set(selected))==1,'evidence':evidence,'scope':'Actual emitted step environment declarations. No explicit Python gettempdir or physical volume benchmark was emitted, so neither is inferred.'})
        declarations.append(row)
    performance=[]
    for i,line in enumerate(lines):
        if line.startswith('W13_TARGET_P95 '):
            payload=json.loads(line.removeprefix('W13_TARGET_P95 '))
            performance.append({'payload':payload,'evidence':ref(i),'twenty_sample_target_proof':payload.get('samples')==20,'scope':'Actual emitted benchmark payload only. No one-sample hosted result is promoted to canonical20-sample target evidence; exact source is retained separately.'})
    command_events=[]
    for i,line in enumerate(lines):
        if line.startswith('$ '):
            time_match=re.match(r'^(\S+) ',raw[i]);command_events.append({'command':line,'line':i+1,'time':time_match[1] if time_match else None})
    def timestamp(value):return dt.datetime.fromisoformat(re.sub(r'(\.\d{6})\d+Z$',r'\1Z',value).replace('Z','+00:00'))
    for index,event in enumerate(command_events[:-1]):event['elapsed_to_next_emitted_command_seconds']=(timestamp(command_events[index+1]['time'])-timestamp(event['time'])).total_seconds()
    selected_events=[e for e in command_events if e['command'] in rust_commands or e['command'].startswith('$ uv run pytest ') or e['command'] in [c for _,c,_ in browser_commands]]
    save(f'observed-timing-{label}.json',{'platform':label,'events':selected_events,'scope':'Actual header-to-next-header elapsed only. Buffered child output and absent completion are not internal compiler phase timings or a controlled performance comparison.'})
    neutrality_step=next((s for s in job.get('steps',[]) if s['name']=='Assert verification left no tracked changes'),None)
    neutrality={'actual_step':neutrality_step,'aggregate_integrity_row':reported.get('integrity'),'tracked_change_assertion_success':bool(neutrality_step and neutrality_step.get('status')=='completed' and neutrality_step.get('conclusion')=='success'),'scope':'Actual post-verification job step and aggregate integrity reporting; no absence of ignored/untracked build artifacts is inferred.'}
    platforms.append({**binding,'started_at':job['started_at'],'completed_at':job['completed_at'],'aggregate_step':next((s for s in job.get('steps',[]) if s['name'].startswith('Canonical aggregate verification')),None),'neutrality':neutrality,'suite_rows':suite_rows,'reported_suite_count':len(reported),'reported_suite_pass_count':sum(x['result']=='PASS' for x in suite_rows),'verification_exit_code':int(exits[0][1][1]) if exits else None,'verification_exit_evidence':ref(exits[0][0]) if exits else None,'doctor':doctor_result,'unit_ts':unit,'playwright':browser,'python':python,'strict_clippy':strict,'desktop_native_test_modes':modes,'desktop_native_final_build':rust_block(rust_commands[-1]),'rust_registry_commands':[rust_block(c) for c in rust_commands],'declared_temp_step_environments':declarations,'extension_benchmark_actual_payloads':performance,'timing_file':f'observed-timing-{label}.json'})

python_delta={'status':'INSUFFICIENT_COLLECTION_LOGS'}
if all(label in collection_lines for label in ['macos-15','ubuntu-24.04','windows-2025']):
    ubuntu=collections.Counter(collection_lines['ubuntu-24.04']);mac=collections.Counter(collection_lines['macos-15']);windows=collections.Counter(collection_lines['windows-2025'])
    python_delta={'status':'OBSERVED_VISIBLE_MULTISET_DIFFERENCE','ubuntu_macos_visible_multisets_equal':ubuntu==mac,'counts':{label:len(lines) for label,lines in collection_lines.items()},'ubuntu_only_relative_to_windows':list((ubuntu-windows).elements()),'windows_only_relative_to_ubuntu':list((windows-ubuntu).elements()),'macos_only_relative_to_ubuntu':list((mac-ubuntu).elements()),'scope':'Visible masked-line occurrences only; no unique unredacted-ID equality reconstructed.'}
all_pass=all(p['job_conclusion']=='success' and p['reported_suite_count']==p['reported_suite_pass_count']==20 and p['verification_exit_code']==0 and all(s['state']=='ACTIVE' and s['result']=='PASS' for s in p['suite_rows']) for p in platforms)
all_required=all(all(m.get('all_required_native_observations_match') for m in p['desktop_native_test_modes']) and all(c['status'].startswith('COMPLETED_') and c.get('finished_profiles') for c in p['strict_clippy']) and p['python'].get('actual_passed_matches_expected') and all(t.get('all_three_temp_selectors_same') for t in p['declared_temp_step_environments']) for p in platforms)
all_actual_expected_counts_match=all(p['doctor'].get('pass')==28 and p['doctor'].get('warning')==p['doctor'].get('fail')==p['doctor'].get('not_yet_applicable')==0 and p['unit_ts'].get('passed')==4006 and p['unit_ts'].get('ordinary_counts_consistent') and all(b.get('expected_pass_count_matches') and all(count==0 for state,count in b.get('summary_counts',{}).items() if state!='passed') for b in p['playwright'].values()) and p['python'].get('execution_counts')=={'passed':p['python']['expected_count']} for p in platforms)
source_final={'head_sha':HEAD,'head_tree_sha':TREE,'actual_checkouts':[{'platform':p['label'],'sha':p['actual_checkout_sha'],'tree':p['actual_checkout_tree']} for p in platforms],'all_actual_content_trees_match':bindings['all_actual_content_trees_match'],'immutable_source_projection':'immutable-source-projection.json','complete_immutable_remote_source_entries':1886,'selected_blob_count':len(load('immutable-source-projection.json')['files']),'actual_checkout_manifest':'platform-logs-manifest.json','canonical_root_observed_or_frozen':False,'scope':'Actual closed-job tested checkout content trees join the immutable new published2a327 tree. Later legitimate canonical-root advancement is independent; no full working-copy byte equality or historical result transfer is claimed.'}
save('source-binding-final.json',source_final)
summary={'run_id':RUN_ID,'run_attempt':run['run_attempt'],'head_sha':HEAD,'expected_source_tree':TREE,'run_status':run['status'],'run_conclusion':run['conclusion'],'run_url':run['html_url'],'all_three_hosts_pass':all_pass,'all_required_native_count_python_and_temp_observations_match':all_required,'all_actual_expected_doctor_TS_browser_python_counts_match':all_actual_expected_counts_match,'registry_suite_ids':suite_ids,'platforms':platforms,'python_platform_visible_difference':python_delta,'source_binding':source_final,'official_complete_logs_zip':load('official-logs-manifest.json')['zip'],'official_non_success_annotations':load('terminal-non-success-annotations.json'),'official_failure_artifacts':load('official-failure-artifacts-manifest.json'),'actual_visual_registry_argv':next(s['commands'][0] for s in registry['suites'] if s['id']=='visual'),'scope':{'native_gui_credit':False,'platform_packaging_credit':False,'windows_11_packaged_credit':False,'prior_cancelled_run_transfer':False,'local_full_result_transfer':False,'performance_saving_claim':False,'summary':'Only actual source-bound hosted CI. Step temp declarations do not establish physical storage topology or a causal throughput gain. No controlled throughput comparison is inferred. All earlier runs retain their actual outcomes.'},'analyzed_at_utc':utc()}
save('hosted-ci-summary.json',summary)
review=[f'# Hosted CI {RUN_ID}: {run["conclusion"].upper()}','',f'Exact published head `{HEAD}`, tree `{TREE}`. All three actual closed checkout content trees match the complete immutable remote1886-entry source.','', '| Host | Job | Actual terminal suites | Python execution | Native desktop feature modes |','|---|---|---|---|---|']
for p in platforms:
    modes='/'.join(str(m.get('test_results',[{}])[0].get('passed')) if m.get('test_results') else m['status'] for m in p['desktop_native_test_modes'])
    review.append(f'| {p["label"]} | {p["job_conclusion"]} | {p["reported_suite_pass_count"]}/{p["reported_suite_count"]} reported PASS; verifier exit {p["verification_exit_code"]} | {p["python"].get("execution_status_text","not reported")} | {modes} |')
review+=['','Every terminal suite row, actual counts, raw timestamp/line references, strict Clippy block, native feature mode and temp declaration are in hosted-ci-summary.json. Absent results remain unreported. Direct child exit0 values are not printed: completed Rust command exit0 is explicitly inferred from the frozen stop-on-nonzero sequence or final Rust PASS.','', 'The new workflow emits TMPDIR/TEMP/TMP for doctor and verify. Actual declared paths are retained. There is no explicit Python gettempdir or physical-volume benchmark, and no causal speed claim. This CI binds the immutable remote head and actual tested merge tree. The canonical root may advance independently and is never scanned or frozen by this collector.','', 'The full official logs.zip, all safely extracted member hashes and complete platform logs are retained. This packet is distinct from historical run39188122249 Windows cleanup FAILURE and cannot relabel it. No prior local result, native GUI, packaging, Windows11 or Ubuntu default-GNOME certification is transferred.']
(ROOT/'review.md').write_text('\n'.join(review)+'\n')
print(json.dumps({'run_id':RUN_ID,'conclusion':run['conclusion'],'all_three_hosts_pass':all_pass,'all_required_observations_match':all_required,'platforms':[{'host':p['label'],'job':p['job_conclusion'],'suite_pass':p['reported_suite_pass_count'],'suite_reported':p['reported_suite_count'],'python':p['python'].get('execution_counts'),'native_modes':[{'status':m['status'],'counts':[r['passed'] for r in m.get('test_results',[])]} for m in p['desktop_native_test_modes']],'temp':[t.get('values') for t in p['declared_temp_step_environments']]} for p in platforms]},indent=2))
