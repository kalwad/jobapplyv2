"""Finite read-only-evidence sealing after actual all3 terminal states and audit."""
import datetime as dt,gzip,io,json,os,pathlib,stat,tarfile
from collect_ci import ROOT,RUN_ID,HEAD,TREE,sha
OUT=pathlib.Path(str(ROOT)+'-retained')
def read(p):
 before=p.lstat();assert stat.S_ISREG(before.st_mode);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  chunks=[]
  while True:
   b=os.read(fd,1048576)
   if not b:break
   chunks.append(b)
  after=os.fstat(fd)
 finally:os.close(fd)
 last=p.lstat();key=lambda s:(s.st_ino,s.st_dev,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 assert key(before)==key(after)==key(last);return b''.join(chunks)
summary=json.loads(read(ROOT/'hosted-ci-summary.json'));assert summary['run_id']==RUN_ID and summary['head_sha']==HEAD and summary['expected_source_tree']==TREE
assert summary['run_status']=='completed' and len(summary['platforms'])==3 and all(p['job_status']=='completed' for p in summary['platforms'])
assert json.loads(read(ROOT/'retained-input-audit.json'))['result']=='PASS'
assert summary['scope']['native_gui_credit'] is False and summary['scope']['local_full_result_transfer'] is False and summary['scope']['performance_saving_claim'] is False
rows=[]
for p in sorted(ROOT.rglob('*')):
 assert not p.is_symlink()
 if not p.is_file():continue
 name=p.relative_to(ROOT).as_posix()
 if '__pycache__' in pathlib.PurePosixPath(name).parts or name=='evidence-inputs.json':continue
 raw=read(p);rows.append({'path':name,'bytes':len(raw),'sha256':sha(raw)})
manifest={'run_id':RUN_ID,'head_sha':HEAD,'expected_tree':TREE,'file_count':len(rows),'files':rows,'scope':'Exact finite immutable2a327 hosted CI source/metadata/raw command outputs/official complete logs/artifacts/source joins/observed results. Canonical root neither read nor frozen; earlier failures stay separate. No GUI, packaging, local-result, canonical20sample performance or acceptance credit.'}
mb=(json.dumps(manifest,indent=2)+'\n').encode();target=ROOT/'evidence-inputs.json';assert not target.exists();target.write_bytes(mb)
entries=rows+[{'path':'evidence-inputs.json','bytes':len(mb),'sha256':sha(mb)}];assert not OUT.exists();OUT.mkdir();archive=OUT/'proof.tar.gz'
with archive.open('wb') as f:
 with gzip.GzipFile(fileobj=f,filename='',mode='wb',mtime=0,compresslevel=6) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for row in entries:
    raw=read(ROOT/row['path']);assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
    info=tarfile.TarInfo(row['path']);info.size=len(raw);info.mode=0o644;info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;tar.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(entries)==len({m.name for m in members})
 for member,row in zip(members,entries):
  assert member.isfile() and member.name==row['path'];raw=tar.extractfile(member).read();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
for row in entries:
 raw=read(ROOT/row['path']);assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
raw=read(archive);outer={'archive':'proof.tar.gz','bytes':len(raw),'sha256':sha(raw),'regular_members':len(entries),'input_manifest_sha256':sha(mb),'run_id':RUN_ID,'head_sha':HEAD,'expected_tree':TREE,'actual_run_conclusion':summary['run_conclusion'],'actual_all3_host_pass':summary['all_three_hosts_pass'],'created_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'scope':manifest['scope']}
(OUT/'manifest.json').write_text(json.dumps(outer,indent=2)+'\n');print(json.dumps(outer,indent=2))
