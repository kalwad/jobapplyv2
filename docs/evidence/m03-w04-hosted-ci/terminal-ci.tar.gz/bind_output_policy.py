import json,re
from collect_ci import ROOT,HEAD,TREE,save,sha
projection=json.loads((ROOT/'immutable-source-projection.json').read_bytes());files={x['path']:x for x in projection['files']}
configs=['playwright.config.ts','e2e/extension/public-research/playwright.config.ts','e2e/extension/public-contact/playwright.config.ts']
rows=[]
for name in configs:
 lines=(ROOT/'source'/name).read_text().splitlines();matches=[(i,x,re.search(r'outputDir:\s*"([^"]+)"',x)) for i,x in enumerate(lines,1) if re.search(r'outputDir:\s*"([^"]+)"',x)]
 assert len(matches)==1;i,line,match=matches[0]
 rows.append({'source':name,'git_blob_sha':files[name]['git_blob_sha'],'declared_output_dir':match[1],'line':i,'source_text':line,'actual_retries_zero_literal_observed':any(re.search(r'retries:\s*0,',x) for x in lines)})
registry=json.loads((ROOT/'source/scripts/verification-suites.json').read_bytes());visual=next(x for x in registry['suites'] if x['id']=='visual')['commands'][0]
assert visual==['pnpm','exec','playwright','test','e2e/visual','--output','test-results/visual']
save('source-playwright-output-policy.json',{'head_sha':HEAD,'tree_sha':TREE,'configs':rows,'visual_registry_argv':visual,'registry_git_blob_sha':files['scripts/verification-suites.json']['git_blob_sha'],'scope':'Exact immutable source declarations only. Actual child command/result paths and official artifact availability remain separate observations; no artifact is presumed to exist.'})
software=json.loads((ROOT/'collector-helper-software-provenance.json').read_bytes());initial=next(x for x in software if x['name']=='analyze_closed_ci.py')
save('collector-software-revision-note.json',{'name':'analyze_closed_ci.py','initial_prepared_sha256':initial['new_software_sha256'],'current_sha256':sha((ROOT/'analyze_closed_ci.py').read_bytes()),'revision':'Removed one leftover template scope sentence about old scanner/temp/inventory coexistence before any analysis execution. No old source or evidence was reused; only collector software template was adapted.','initial_version_executed':False,'scope':'Initial preparation hash is historical software metadata; final finite file list binds the actual analysis software used.'})
print(json.dumps({'bound_source_output_configs':len(rows),'visual_argv':visual,'actual_hosted_output_outcome_claim':False},indent=2))
