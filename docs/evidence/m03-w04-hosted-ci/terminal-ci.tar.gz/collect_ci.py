"""Read-only actual hosted CI evidence. No canonical-root stability dependency."""
import datetime as dt,hashlib,json,pathlib,subprocess,sys,time
ROOT=pathlib.Path('/tmp/japp-m03-w04-hosted-ci-2a327c6-20261019')
REPO='kalwad/jobapplyv2'
HEAD='2a327c6210bfb7236f3d8a572a3a62e9b7e13d63'
TREE='4ce9cf0c1f5515252a029584f820ea674a66e05e'
def utc():return dt.datetime.now(dt.timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def save(name,value):
 p=ROOT/name;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2)+'\n')
def capture(argv,label):
 folder=ROOT/'commands';folder.mkdir(exist_ok=True);stem=f'{len(list(folder.glob("*.record.json")))+1:04d}-{label}'
 started=utc();tick=time.monotonic();timeout=False
 try:
  p=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60);out=p.stdout;err=p.stderr;code=p.returncode
 except subprocess.TimeoutExpired as e:
  timeout=True;out=e.stdout or b'';err=e.stderr or b'';code=None
 row={'argv':argv,'cwd':str(ROOT),'started_utc':started,'ended_utc':utc(),'elapsed_seconds':time.monotonic()-tick,'exit_code':code,'collector_command_timeout':timeout,'scope':'Read-only GitHub immutable source/metadata/logs; no actions mutation, root read/freeze/write, compiler, browser or test actor.'}
 for name,raw in [('stdout',out),('stderr',err)]:
  target=folder/(stem+'.'+name);assert not target.exists();target.write_bytes(raw);row[name]={'path':str(target.relative_to(ROOT)),'bytes':len(raw),'sha256':sha(raw)}
 save('commands/'+stem+'.record.json',row)
 if timeout or code!=0:raise RuntimeError(f'{label} actual exit={code}, command_timeout={timeout}; raw outputs retained')
 return out,row
def api(endpoint,label):
 raw,row=capture(['/opt/homebrew/bin/gh','api','-H','Accept: application/vnd.github+json',endpoint],label);return json.loads(raw),row
def identity():return json.loads((ROOT/'discovered-run.json').read_text())['run_id']
RUN_ID=identity() if (ROOT/'discovered-run.json').exists() else None
def discover():
 listing,record=api(f'repos/{REPO}/actions/runs?head_sha={HEAD}&per_page=100','discover-exact-head')
 matches=[x for x in listing['workflow_runs'] if x['head_sha']==HEAD and x['path']=='.github/workflows/ci.yml']
 assert len(matches)==1,[(x['id'],x['status']) for x in matches]
 run=matches[0];save('discovered-run.json',{'run_id':run['id'],'run_attempt':run['run_attempt'],'head_sha':HEAD,'expected_tree_sha':TREE,'html_url':run['html_url'],'discovery_record':record,'scope':'Normally triggered new published2a327 run; old39188122249 FAIL stays separate. Current canonical root may legitimately advance and is not frozen for CI.'})
 commit,cr=api(f'repos/{REPO}/git/commits/{HEAD}','immutable-published-head-commit')
 assert commit['sha']==HEAD and commit['tree']['sha']==TREE
 save('published-head-metadata.json',{'head_sha':HEAD,'head_tree_sha':commit['tree']['sha'],'commit_record':cr,'actual_tested_checkout':'PENDING_OFFICIAL_CLOSED_JOB_LOGS_AND_GIT_OBJECT','source_projection':'PENDING_HEAVY_COLLECTION_RELEASE','canonical_root_observed_or_frozen':False})
 print(json.dumps({'run_id':run['id'],'status':run['status'],'conclusion':run['conclusion'],'html_url':run['html_url'],'published_tree_verified':TREE},indent=2))
def status():
 run_id=identity();run,rr=api(f'repos/{REPO}/actions/runs/{run_id}','run-status')
 assert run['head_sha']==HEAD and run['id']==run_id
 jobs,jr=api(f"repos/{REPO}/actions/runs/{run_id}/attempts/{run['run_attempt']}/jobs?per_page=100",'jobs-status')
 assert len(jobs['jobs'])==jobs['total_count']
 value={'observed_utc':utc(),'run_id':run_id,'run_attempt':run['run_attempt'],'head_sha':HEAD,'expected_tree_sha':TREE,'status':run['status'],'conclusion':run['conclusion'],'run_record':rr,'jobs_record':jr,'jobs':[{'job_id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'started_at':j['started_at'],'completed_at':j['completed_at'],'active_steps':[{k:s.get(k) for k in ['number','name','status','started_at']} for s in j.get('steps',[]) if s['status']=='in_progress']} for j in jobs['jobs']],'scope':'Only observed states. No inferred suite counts or local-result transfer; canonical root is not scanned or frozen.'}
 name=f'snapshot-{len(list(ROOT.glob("snapshot-*.json")))+1:04d}.json';save(name,value)
 print(json.dumps({'snapshot':name,**{k:value[k] for k in ['observed_utc','run_id','status','conclusion','jobs']}},indent=2))
if __name__=='__main__':
 assert len(sys.argv)==2 and sys.argv[1] in ['discover','status']
 discover() if sys.argv[1]=='discover' else status()
