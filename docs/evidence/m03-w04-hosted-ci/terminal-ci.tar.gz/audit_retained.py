"""Finite documentary consistency audit; works for actual PASS or FAIL runs."""
import base64,hashlib,json,pathlib,stat,zipfile
from collect_ci import ROOT,RUN_ID,HEAD,TREE,sha,save
def load(name):return json.loads((ROOT/name).read_bytes())
records=[]
for folder in ['commands','operations']:
 for path in sorted((ROOT/folder).glob('*.record.json')):
  row=json.loads(path.read_bytes())
  for stream in ['stdout','stderr']:
   item=row[stream];raw=(ROOT/item['path']).read_bytes();assert len(raw)==item['bytes'] and sha(raw)==item['sha256']
  records.append({'path':str(path.relative_to(ROOT)),'argv':row['argv'],'exit_code':row['exit_code'],'timeout':row.get('collector_command_timeout',False)})
projection=load('immutable-source-projection.json');assert projection['head_sha']==HEAD and projection['tree_sha']==TREE and projection['complete_remote_entries']==1886 and projection['recursive_tree_truncated'] is False
tree=load(projection['remote_tree_record']['stdout']['path']);assert tree['sha']==TREE and tree['truncated'] is False
remote={x['path']:x for x in tree['tree'] if x['type']!='tree'};assert len(remote)==1886
head=load('published-head-metadata.json');head_commit=load(head['commit_record']['stdout']['path']);assert head_commit['sha']==HEAD and head_commit['tree']['sha']==TREE
for row in projection['files']:
 raw=(ROOT/'source'/row['path']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
 assert remote[row['path']]['sha']==row['git_blob_sha'] and remote[row['path']]['mode']==row['git_mode']
 assert hashlib.sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest()==row['git_blob_sha']
 blob=load(row['record_stdout']);assert blob['sha']==row['git_blob_sha'] and base64.b64decode(blob['content'])==raw
def audit_zip(manifest,folder):
 raw=(ROOT/manifest['zip']['path']).read_bytes();assert len(raw)==manifest['zip']['bytes'] and sha(raw)==manifest['zip']['sha256']
 assert raw==(ROOT/manifest['zip']['command_stdout']).read_bytes()
 expected={x['path']:x for x in manifest['files']}
 with zipfile.ZipFile(ROOT/manifest['zip']['path']) as z:
  infos=z.infolist();assert len(infos)==manifest['zip_entry_count'] and z.testzip() is None
  assert len([x for x in infos if not x.is_dir()])==len(expected)==manifest['safe_regular_file_count']
  assert len({x.filename.casefold() for x in infos})==len(infos)
  for item in infos:
   p=pathlib.PurePosixPath(item.filename);assert not p.is_absolute() and '..' not in p.parts and '\\' not in item.filename and '\0' not in item.filename
   assert not stat.S_ISLNK(item.external_attr>>16)
   if item.is_dir():continue
   row=expected[item.filename];body=z.read(item);assert len(body)==row['bytes'] and sha(body)==row['sha256'] and f'{item.CRC:08x}'==row['crc32_hex']
   assert (ROOT/folder/item.filename).read_bytes()==body
 return len(expected)
logs=load('official-logs-manifest.json');log_count=audit_zip(logs,'official-logs')
platforms=load('platform-logs-manifest.json');assert len(platforms['platforms'])==3 and platforms['all_actual_content_trees_match']
for p in platforms['platforms']:
 raw=(ROOT/p['platform_log']).read_bytes();assert len(raw)==p['bytes'] and sha(raw)==p['sha256'] and (ROOT/'official-logs'/p['official_combined_member']).read_bytes()==raw
 actual=load(p['checkout_commit_api']['record_stdout']);assert actual['sha']==p['actual_checkout_sha'] and actual['tree']['sha']==p['actual_checkout_tree']==TREE
windows=next(p for p in platforms['platforms'] if p['label']=='windows-2025')
assert (ROOT/'early-windows-closure/official-job.log').read_bytes()==(ROOT/windows['platform_log']).read_bytes()
artifacts=load('official-failure-artifacts-manifest.json');listing=load('official-artifacts-list.json');assert listing['total_count']==len(listing['artifacts'])==artifacts['actual_total_artifacts']
artifact_counts=[]
for item in artifacts['artifacts']:
 if item['download_status']=='ACTUAL_OFFICIAL_COMPLETE_ZIP':
  artifact_counts.append({'id':item['metadata']['id'],'regular_members':audit_zip(item,item['extracted_folder'])})
  for row in item['files']:
   if row['path'].endswith('.png'):assert (ROOT/item['extracted_folder']/row['path']).read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
 else:assert item['download_status']=='EXPIRED_NO_OUTPUT_RECONSTRUCTION' and item['metadata']['expired'] is True
summary=load('hosted-ci-summary.json');assert summary['run_id']==RUN_ID and summary['head_sha']==HEAD and summary['expected_source_tree']==TREE and summary['run_status']=='completed' and len(summary['platforms'])==3
assert summary['scope']['native_gui_credit'] is False and summary['scope']['platform_packaging_credit'] is False and summary['scope']['local_full_result_transfer'] is False and summary['scope']['performance_saving_claim'] is False
allpass=all(p['job_conclusion']=='success' and p['reported_suite_count']==p['reported_suite_pass_count']==20 and p['verification_exit_code']==0 and all(s['state']=='ACTIVE' and s['result']=='PASS' for s in p['suite_rows']) for p in summary['platforms'])
assert summary['all_three_hosts_pass']==allpass and all(p['job_status']=='completed' and len(p['suite_rows'])==20 for p in summary['platforms'])
save('retained-input-audit.json',{'result':'PASS','scope':'Documentary consistency only; actual run PASS or FAIL remains its own outcome. No product rerun or acceptance.','raw_records_at_audit_start':len(records),'actual_nonzero_or_timeout_records':[x for x in records if x['exit_code']!=0 or x['timeout']],'immutable_remote_entries':1886,'selected_source_blobs_checked':len(projection['files']),'all3_actual_tested_checkout_trees_equal_immutable_head_tree':True,'official_logs_regular_members':log_count,'official_artifact_member_counts':artifact_counts,'actual_all_three_hosts_pass':allpass,'canonical_root_scanned_or_frozen':False,'no_GUI_packaging_local_result_or_performance_claim':True,'audit_operation_record':'Written after this process closes; also bound by final finite archive.'})
print(json.dumps({'documentary_audit':'PASS','actual_all3_host_pass':allpass,'remote_entries':1886,'source_blobs':len(projection['files']),'official_log_members':log_count,'failure_artifacts':artifact_counts},indent=2))
