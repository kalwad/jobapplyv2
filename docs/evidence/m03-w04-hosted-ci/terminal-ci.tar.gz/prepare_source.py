"""Immutable API projection only; deliberately never reads the canonical root."""
import base64,hashlib,json,pathlib
from collect_ci import ROOT,REPO,HEAD,TREE,api,save,sha
release=json.loads((ROOT/'heavy-release.json').read_text());assert release['parent_explicit_release'] is True
tree,tr=api(f'repos/{REPO}/git/trees/{TREE}?recursive=1','complete-immutable-source-tree')
assert tree['sha']==TREE and tree['truncated'] is False
files=[x for x in tree['tree'] if x['type']!='tree'];assert len(files)==1886 and all(x['type']=='blob' for x in files)
byname={x['path']:x for x in files};assert len(byname)==1886
selected=[
 '.github/workflows/ci.yml','scripts/verification-suites.json','scripts/verify.py','scripts/doctor.py','scripts/python-test-inventory.v1.json','scripts/validate_status.py',
 'package.json','pnpm-lock.yaml','pyproject.toml','uv.lock','.nvmrc','.python-version','rust-toolchain.toml','playwright.config.ts',
 'e2e/extension/extension-benchmark.spec.ts','e2e/extension/support/extension-test.ts','e2e/extension/extension-research.spec.ts',
 'apps/extension/package.json','apps/extension/test/m02-w15/inherited-fixture-cleanup.test.ts','apps/desktop/package.json',
 'apps/desktop/src-tauri/Cargo.toml','apps/desktop/src-tauri/src/lib.rs','apps/desktop/src-tauri/src/main.rs','apps/desktop/src-tauri/build.rs','apps/desktop/src-tauri/build_support.rs',
 'services/native-host/Cargo.toml','packages/contracts/test/contract/rust-harness/Cargo.toml'
]
# Include the bounded current fixture cleanup implementation and output policy files,
# deriving their actual paths from this immutable tree rather than the moving root.
extra=[p for p in byname if any(word in p.lower() for word in ['fixture-cleanup','legacy-browser-cleanup','browser-cleanup','playwright-output']) and not p.startswith('docs/')]
selected=sorted(set(selected+extra));missing=[p for p in selected if p not in byname]
selected=[p for p in selected if p in byname]
rows=[]
for number,name in enumerate(selected,1):
 entry=byname[name];blob,record=api(f"repos/{REPO}/git/blobs/{entry['sha']}",f'project-source-blob-{number:02d}')
 assert blob['sha']==entry['sha'] and blob['encoding']=='base64';raw=base64.b64decode(blob['content'])
 assert len(raw)==blob['size']==entry['size'] and hashlib.sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest()==entry['sha']
 target=ROOT/'source'/name;assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 rows.append({'path':name,'bytes':len(raw),'sha256':sha(raw),'git_blob_sha':entry['sha'],'git_mode':entry['mode'],'record_stdout':record['stdout']['path']})
save('immutable-source-projection.json',{'head_sha':HEAD,'tree_sha':TREE,'complete_remote_entries':1886,'recursive_tree_truncated':False,'remote_tree_record':tr,'selected_source_blobs':len(rows),'files':rows,'requested_absent_paths':missing,'scope':'All1886 immutable remote source entries bind the head content tree; selected exact Git blobs form a private outside interpretation projection. No whole working-tree byte-copy claim, root scan/freeze or dependence on subsequent canonical root state.'})
print(json.dumps({'head':HEAD,'tree':TREE,'complete_entries':1886,'selected_blobs':len(rows),'actual_extra_cleanup_paths':extra,'requested_absent':missing},indent=2))
