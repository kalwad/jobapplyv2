# Hosted CI 39194489970: FAILURE

Exact published head `2a327c6210bfb7236f3d8a572a3a62e9b7e13d63`, tree `4ce9cf0c1f5515252a029584f820ea674a66e05e`. All three actual closed checkout content trees match the complete immutable remote1886-entry source.

| Host | Job | Actual terminal suites | Python execution | Native desktop feature modes |
|---|---|---|---|---|
| ubuntu-24.04 | success | 20/20 reported PASS; verifier exit 0 | 1679 passed | 137/137/137 |
| macos-15 | success | 20/20 reported PASS; verifier exit 0 | 1679 passed | 138/138/138 |
| windows-2025 | failure | 19/20 reported PASS; verifier exit 1 | 1677 passed | FAILED_REPORTED_PROCESS_EXIT/NOT_OBSERVED/NOT_OBSERVED |

Every terminal suite row, actual counts, raw timestamp/line references, strict Clippy block, native feature mode and temp declaration are in hosted-ci-summary.json. Absent results remain unreported. Direct child exit0 values are not printed: completed Rust command exit0 is explicitly inferred from the frozen stop-on-nonzero sequence or final Rust PASS.

The new workflow emits TMPDIR/TEMP/TMP for doctor and verify. Actual declared paths are retained. There is no explicit Python gettempdir or physical-volume benchmark, and no causal speed claim. This CI binds the immutable remote head and actual tested merge tree. The canonical root may advance independently and is never scanned or frozen by this collector.

The full official logs.zip, all safely extracted member hashes and complete platform logs are retained. This packet is distinct from historical run39188122249 Windows cleanup FAILURE and cannot relabel it. No prior local result, native GUI, packaging, Windows11 or Ubuntu default-GNOME certification is transferred.


Windows failed after the default desktop library executable was launched. Cargo explicitly reports `0xc0000139, STATUS_ENTRYPOINT_NOT_FOUND` at platform-log line8833; the verifier explicitly reports cargo exit3221225785. No Windows library test summary was emitted. The all-features and dependency SDK commands and final desktop build were not invoked after that failure. Eleven of fifteen Rust registry commands completed; the twelfth was the failing default desktop test. All three strict Clippy commands completed. The exact missing DLL or export is not named by these logs.

Across all three hosts, actual doctor is28PASS/0warning/0fail/0NYA; root forced TypeScript is4006PASS; browser groups are262/2/62/3PASS; Python is1679/1679/1677PASS with no outer skipped/failed footer. Visible collection multisets differ only by the POSIX FIFO and socket source-refusal cases. Ubuntu and macOS execute all15 Rust commands and all three native modes with137 and138 library PASS respectively,0failed/ignored/measured/filtered. Windows has19 ACTIVE PASS and the one Rust FAIL. Step26 is SUCCESS on Ubuntu/macOS and SKIPPED on Windows; aggregate integrity PASS is retained separately.

Official artifact inventory is not empty: artifact12162960570 is a465,158byte Windows upload with ten actual visual PNG members (duplicated attachment/output copies). It supplies no native exe/DLL/runtime directory listing, trace, video or error-context file. The visual suite itself passed; the artifact's name follows the failed job, not a claimed browser failure. Every ZIP member and CRC is retained. No image viewer or trace browser was opened.

Actual doctor/verify temp declarations are `/home/runner/work/_temp`, `/Users/runner/work/_temp` and `D:\a\_temp`, respectively. Header-to-next-header timing and Python footer times are retained, with no causal speed comparison. Each hosted W13 payload has exactly one sample; none supplies the canonical20-sample benchmark.

Collector-only history remains visible: source supplement operation0004 failed on a guessed nonexistent `service/platform/native.rs`; operation0005 corrected the source lookup to the exact immutable `service/platform.rs`. The earlier successful two config blobs remain bound to their original actual API receipts. Collector helpers were prepared from prior collector software only; old run outcomes were not imported. Before first terminal analysis, documented analyzer changes retained explicit abnormal executable errors and exact aggregate command failure exits. These are documentary parser corrections, not product edits or test reruns. Both resource holds and explicit browser-phase releases are retained.
