"""Finalize factual documentary handoff, without product execution or root access."""
import json
from collect_ci import ROOT,HEAD,TREE,RUN_ID,save,sha
s=json.loads((ROOT/'hosted-ci-summary.json').read_bytes())
assert s['run_status']=='completed' and s['run_conclusion']=='failure' and not s['all_three_hosts_pass']
w=next(p for p in s['platforms'] if p['label']=='windows-2025')
assert w['reported_suite_pass_count']==19 and w['desktop_native_test_modes'][0]['direct_process_exit_code']==3221225785
assert [m['status'] for m in w['desktop_native_test_modes']]==['FAILED_REPORTED_PROCESS_EXIT','NOT_OBSERVED','NOT_OBSERVED']
art=s['official_failure_artifacts'];assert art['actual_total_artifacts']==len(art['artifacts'])==1
a=art['artifacts'][0];assert len(a['files'])==10 and all(f['path'].endswith('.png') for f in a['files'])
lines=[]
for p in s['platforms']:
 lines.append({'platform':p['label'],'doctor':[p['doctor'][k] for k in ['pass','warning','fail','not_yet_applicable']],'typescript_passed':p['unit_ts']['passed'],'browser_counts':{k:v['summary_counts'] for k,v in p['playwright'].items()},'python_passed':p['python']['execution_counts']['passed'],'python_elapsed_seconds':p['python']['duration_seconds'],'actual_rust_registry_commands_started':sum(c['status']!='NOT_OBSERVED' for c in p['rust_registry_commands']),'actual_rust_registry_commands_completed':sum(c['status'].startswith('COMPLETED_') for c in p['rust_registry_commands']),'three_strict_clippy_completed':all(c['status'].startswith('COMPLETED_') for c in p['strict_clippy']),'step26_actual_conclusion':p['neutrality']['actual_step']['conclusion'],'hosted_W13_sample_counts':[x['payload']['samples'] for x in p['extension_benchmark_actual_payloads']]})
save('closed-observation-highlights.json',{'run_id':RUN_ID,'head_sha':HEAD,'tree_sha':TREE,'actual_run':'FAILURE','platforms':lines,'windows_actual_rust_cargo_exit':3221225785,'windows_actual_library_executable_error':'0xc0000139, STATUS_ENTRYPOINT_NOT_FOUND','missing_DLL_or_export_identity':'NOT_REPORTED','early_complete_windows_job_log_equals_final_official_combined_log':(ROOT/'early-windows-closure/official-job.log').read_bytes()==(ROOT/w['platform_log']).read_bytes(),'official_windows_artifact':{'id':a['metadata']['id'],'zip':a['zip'],'members':len(a['files']),'content':'Only ten actual visual PNG files; no native executable, DLL, runtime directory listing, failure trace, video or error-context member.'},'platform_python_difference':s['python_platform_visible_difference'],'scope':'Observed source-bound actual results only; no performance saving or acceptance transfer.'})
addendum='''

Windows failed after the default desktop library executable was launched. Cargo explicitly reports `0xc0000139, STATUS_ENTRYPOINT_NOT_FOUND` at platform-log line8833; the verifier explicitly reports cargo exit3221225785. No Windows library test summary was emitted. The all-features and dependency SDK commands and final desktop build were not invoked after that failure. Eleven of fifteen Rust registry commands completed; the twelfth was the failing default desktop test. All three strict Clippy commands completed. The exact missing DLL or export is not named by these logs.

Across all three hosts, actual doctor is28PASS/0warning/0fail/0NYA; root forced TypeScript is4006PASS; browser groups are262/2/62/3PASS; Python is1679/1679/1677PASS with no outer skipped/failed footer. Visible collection multisets differ only by the POSIX FIFO and socket source-refusal cases. Ubuntu and macOS execute all15 Rust commands and all three native modes with137 and138 library PASS respectively,0failed/ignored/measured/filtered. Windows has19 ACTIVE PASS and the one Rust FAIL. Step26 is SUCCESS on Ubuntu/macOS and SKIPPED on Windows; aggregate integrity PASS is retained separately.

Official artifact inventory is not empty: artifact12162960570 is a465,158byte Windows upload with ten actual visual PNG members (duplicated attachment/output copies). It supplies no native exe/DLL/runtime directory listing, trace, video or error-context file. The visual suite itself passed; the artifact's name follows the failed job, not a claimed browser failure. Every ZIP member and CRC is retained. No image viewer or trace browser was opened.

Actual doctor/verify temp declarations are `/home/runner/work/_temp`, `/Users/runner/work/_temp` and `D:\\a\\_temp`, respectively. Header-to-next-header timing and Python footer times are retained, with no causal speed comparison. Each hosted W13 payload has exactly one sample; none supplies the canonical20-sample benchmark.

Collector-only history remains visible: source supplement operation0004 failed on a guessed nonexistent `service/platform/native.rs`; operation0005 corrected the source lookup to the exact immutable `service/platform.rs`. The earlier successful two config blobs remain bound to their original actual API receipts. Collector helpers were prepared from prior collector software only; old run outcomes were not imported. Before first terminal analysis, documented analyzer changes retained explicit abnormal executable errors and exact aggregate command failure exits. These are documentary parser corrections, not product edits or test reruns. Both resource holds and explicit browser-phase releases are retained.
'''
with (ROOT/'review.md').open('a') as f:f.write(addendum)
(ROOT/'HANDOFF.md').write_text(f'''# Hosted CI {RUN_ID}: actual FAILURE, all hosts terminal

Remote immutable head `{HEAD}` / tree `{TREE}` /1886 source entries. Actual tested checkout on all hosts is `bdeb5ddae0ade030b5d0be2aa95dd3a8288fc03b`; immutable Git API verifies the same content tree. No current canonical-root freeze or working-copy equality is used.

Ubuntu20 ACTIVE PASS and native137×3; macOS20 ACTIVE PASS and native138×3. Windows19 ACTIVE PASS/Rust FAIL: default desktop executable loader reports0xc0000139/STATUS_ENTRYPOINT_NOT_FOUND and cargo exit3221225785. It does not execute Windows library cases, later feature-mode test commands or final desktop build. All hosts doctor28,TS4006,browser262+2+62+3 and Python1679/1679/1677 PASS. Windows post-verification source assertion is skipped; Ubuntu/macOS succeed.

Read review.md, hosted-ci-summary.json, closed-observation-highlights.json and source-binding-final.json. Every parsed actual count/exit has full log and line references. Complete official logs.zip is1,447,818bytes SHA25672304ac2157ecb71b9a2192dab7ce9e228786d1b06a70867861ccb26f21d0e42,86 regular members. Official Windows artifact12162960570 is465,158bytes SHA25601c3173c10bca41a1924e283e2413c1cda1927c9cecfe314e6b75e16c1585a90,ten visual PNG members only. Missing DLL/export identity is unreported.

Exact immutable recursive tree and34 selected decoded Git blobs, actual commands/stdout/stderr/exits, job/run/attempt/check metadata, official complete ZIPs and safe member hashes are retained. Early Windows full log bytes equal the final official combined member. Collector-only failed source path lookup and subsequent documentary parser changes are disclosed in review.md. All earlier cancelled/failed runs stay separate and unchanged.

No product execution, root mutation, CI mutation, retry/dispatch/cancel, native GUI, packaging, Windows11/Ubuntu GNOME certification, local-result transfer, controlled speed saving, canonical20sample W13 claim or milestone/Gate acceptance is supplied. This packet is intended for a different independent data reviewer. Final retained-input-audit.json and the sibling-retained manifest bind the documentary audit and finite seal; they do not convert the run to PASS.
''')
print(json.dumps({'actual_run':'FAILURE','all_hosts_terminal':True,'report':'review.md','handoff':'HANDOFF.md','official_artifact_regular_members':10,'no_all_three_PASS':True},indent=2))
