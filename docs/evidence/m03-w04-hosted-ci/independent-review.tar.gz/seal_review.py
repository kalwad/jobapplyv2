#!/usr/bin/env python3
"""Seal only this compact independent documentary review; no project reads."""
import datetime
import gzip
import hashlib
import io
import json
import pathlib
import tarfile

root = pathlib.Path(__file__).resolve().parent
retained = root.with_name(root.name + '-retained')
retained.mkdir(exist_ok=True)
files = sorted(p for p in root.iterdir() if p.name != 'review-inputs.json')
assert all(p.is_file() and not p.is_symlink() for p in files)
assert sum(p.stat().st_size for p in files) < 1_000_000
assert json.loads((root / 'checks.json').read_bytes())['result'] == 'PASS'
manifest = {'scope':'Finite reviewer-only source/checks/raw observations and observer errors; author archive is referenced, not duplicated.',
            'actual_ci_conclusion':'failure', 'actual_all_three_hosts_pass':False,
            'files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
(root / 'review-inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
files.append(root / 'review-inputs.json')
archive = retained / 'proof.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w') as tf:
            for p in sorted(files):
                b=p.read_bytes()
                info=tarfile.TarInfo(p.name)
                info.size=len(b)
                info.mode=0o600
                info.mtime=0
                tf.addfile(info,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tf:
    members=tf.getmembers()
    assert len(members)==len(files) and all(m.isfile() for m in members)
    assert {m.name for m in members}=={p.name for p in files}
    assert all(tf.extractfile(m).read()==(root/m.name).read_bytes() for m in members)
summary={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
         'regular_members':len(files),'input_manifest_sha256':hashlib.sha256((root/'review-inputs.json').read_bytes()).hexdigest(),
         'documentary_result':'PASS','documentary_checks':74,'actual_ci_run':39194489970,'actual_ci_conclusion':'failure','actual_all_three_hosts_pass':False,
         'referenced_author_archive_sha256':'f4b880dd5306c3f1bb8f4a3616c170a6dfce10db37d93b96173ddf6c00fa9d8e',
         'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(retained/'manifest.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
