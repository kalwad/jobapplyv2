#!/usr/bin/env python3
"""Independent documentary audit; reads only the fixed CI packet, writes here.
No project imports, child processes, compilers, test actors, or network calls.
"""
import base64
import collections
import datetime
import hashlib
import json
import pathlib
import re
import stat
import tarfile
import zipfile

PACKET = pathlib.Path('/tmp/japp-m03-w04-hosted-ci-2a327c6-20261019')
RETAINED = pathlib.Path(str(PACKET) + '-retained')
OUT = pathlib.Path(__file__).resolve().parent
HEAD = '2a327c6210bfb7236f3d8a572a3a62e9b7e13d63'
TREE = '4ce9cf0c1f5515252a029584f820ea674a66e05e'
MERGE = 'bdeb5ddae0ade030b5d0be2aa95dd3a8288fc03b'
RUN = 39194489970
checks = []
observed = {'reviewer': '/root/ci_terminal_data_review', 'collector': '/root/current_native_ci_collector',
            'scope': 'Independent data audit only. No canonical-root read or mutation, product execution, network or CI action.'}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def load(path):
    return json.loads((PACKET / path).read_bytes())

def check(name, ok, detail=None):
    checks.append({'check': name, 'result': 'PASS' if ok else 'FAIL', 'detail': detail})
    if not ok:
        print('DOCUMENTARY CHECK FAILED:', name, detail)

def safe(path):
    p = pathlib.PurePosixPath(path)
    return not p.is_absolute() and '..' not in p.parts and '\\' not in path

def receipt_match(r):
    b = (PACKET / r['path']).read_bytes()
    return len(b) == r['bytes'] and digest(b) == r['sha256']

def git_hash(kind, data):
    return hashlib.sha1(kind.encode() + b' ' + str(len(data)).encode() + b'\0' + data).hexdigest()

# Verify the finite input and all local packet bytes against the sealed archive.
seal = json.loads((RETAINED / 'manifest.json').read_bytes())
archive = (RETAINED / 'proof.tar.gz').read_bytes()
check('author archive supplied digest and size', len(archive) == 7960344 and digest(archive) == 'f4b880dd5306c3f1bb8f4a3616c170a6dfce10db37d93b96173ddf6c00fa9d8e')
check('author retained manifest binding', seal['bytes'] == len(archive) and seal['sha256'] == digest(archive) and seal['run_id'] == RUN and seal['actual_run_conclusion'] == 'failure' and seal['actual_all3_host_pass'] is False)
inputs_bytes = (PACKET / 'evidence-inputs.json').read_bytes()
check('author input manifest supplied digest', digest(inputs_bytes) == '30a1607b85e46a40f47b2c7f2c6b95ecad287dd056b963106ee4a66e4d2375fb' == seal['input_manifest_sha256'])
inputs = json.loads(inputs_bytes)
index = {x['path']: x for x in inputs['files']}
with tarfile.open(RETAINED / 'proof.tar.gz', 'r:gz') as tf:
    members = tf.getmembers()
    check('author archive finite safe regular members', len(members) == 471 and all(m.isfile() and safe(m.name) for m in members) and len({m.name for m in members}) == 471)
    check('author manifest exact membership', len(index) == inputs['file_count'] == 470 and set(index) | {'evidence-inputs.json'} == {m.name for m in members})
    mismatches = []
    for m in members:
        data = tf.extractfile(m).read()
        if data != (PACKET / m.name).read_bytes():
            mismatches.append([m.name, 'archive/disk bytes differ'])
        if m.name in index and (digest(data) != index[m.name]['sha256'] or len(data) != index[m.name]['bytes']):
            mismatches.append([m.name, 'manifest digest/size mismatch'])
    check('all 471 archived bytes equal local packet and all 470 input receipts', not mismatches, mismatches)
observed['author_seal'] = seal

# Check original command stdout/stderr bytes and preserve nonzero observer history.
records = []
bad_receipts = []
for f in sorted(PACKET.glob('commands/*.record.json')) + sorted(PACKET.glob('operations/*.record.json')):
    j = json.loads(f.read_bytes())
    records.append((str(f.relative_to(PACKET)), j))
    for channel in ('stdout', 'stderr'):
        if not receipt_match(j[channel]):
            bad_receipts.append([str(f.relative_to(PACKET)), channel])
check('all command and operation stdout/stderr receipts', not bad_receipts, {'records': len(records), 'mismatches': bad_receipts})
nonzero = [{'path': p, 'exit_code': j['exit_code'], 'timeout': j.get('collector_command_timeout', False), 'argv': j['argv']} for p, j in records if j['exit_code'] != 0 or j.get('collector_command_timeout', False)]
check('collector nonzero history disclosed and distinct from product failure', len(nonzero) == 1 and nonzero[0]['path'] == 'operations/0004-supplemental-immutable-source.record.json' and nonzero[0]['exit_code'] == 1 and not nonzero[0]['timeout'], nonzero)
observed['collector_nonzero_history'] = nonzero
for projected, raw in [('final-run.json', 'commands/0069-run-status.stdout'), ('final-jobs.json', 'commands/0070-jobs-status.stdout'), ('final-attempt.json', 'commands/0071-terminal-attempt.stdout')]:
    check(projected + ' equals retained raw API JSON', load(projected) == load(raw), raw)
run, attempt, jobs_doc = load('final-run.json'), load('final-attempt.json'), load('final-jobs.json')
check('actual terminal run and attempt failure', all(j['id'] == RUN and j['head_sha'] == HEAD and j['run_attempt'] == 1 and j['status'] == 'completed' and j['conclusion'] == 'failure' for j in (run, attempt)))
expected = {'ubuntu-24.04': (117874182346, 'success'), 'macos-15': (117874182492, 'success'), 'windows-2025': (117874182536, 'failure')}
jobs = {}
for label, (ident, conclusion) in expected.items():
    job = next(j for j in jobs_doc['jobs'] if j['id'] == ident)
    jobs[label] = job
    steps = {s['number']: s for s in job['steps']}
    check(label + ' exact API job and aggregate/step26', job['run_id'] == RUN and job['head_sha'] == HEAD and job['status'] == 'completed' and job['conclusion'] == conclusion and steps[25]['conclusion'] == conclusion and steps[26]['conclusion'] == ('skipped' if conclusion == 'failure' else 'success'))
check('exact three terminal jobs', jobs_doc['total_count'] == len(jobs_doc['jobs']) == 3)
wincheck = load('commands/0072-terminal-check-117874182536.stdout')
check('Windows check-run API agrees with job failure', wincheck['id'] == expected['windows-2025'][0] and wincheck['status'] == 'completed' and wincheck['conclusion'] == 'failure')
observed['run'] = {k: run[k] for k in ('id', 'head_sha', 'run_attempt', 'status', 'conclusion', 'html_url', 'created_at', 'updated_at')}

# Rebuild Git trees from all recursive entries, then join every selected blob.
head_object = load('commands/0002-immutable-published-head-commit.stdout')
merge_object = load('commands/0077-actual-checkout-git-commit-1.stdout')
tree_object = load('commands/0011-complete-immutable-source-tree.stdout')
entries = {e['path']: e for e in tree_object['tree']}
check('immutable API object identities and complete tree', head_object['sha'] == HEAD and head_object['tree']['sha'] == TREE and merge_object['sha'] == MERGE and merge_object['tree']['sha'] == TREE and HEAD in [p['sha'] for p in merge_object['parents']] and tree_object['sha'] == TREE and tree_object['truncated'] is False)
check('2250 recursive entries comprise 1886 tracked blobs and 364 trees', len(entries) == 2250 and sum(x['type'] == 'blob' for x in entries.values()) == 1886 and sum(x['type'] == 'tree' for x in entries.values()) == 364)
children = collections.defaultdict(list)
for path, e in entries.items():
    parent, _, name = path.rpartition('/')
    children[parent].append((name, e))
tree_bad = []
for parent, values in children.items():
    values.sort(key=lambda pair: (pair[0] + ('/' if pair[1]['type'] == 'tree' else '')).encode())
    payload = b''.join((e['mode'].lstrip('0') + ' ').encode() + name.encode() + b'\0' + bytes.fromhex(e['sha']) for name, e in values)
    actual = git_hash('tree', payload)
    wanted = TREE if not parent else entries[parent]['sha']
    if actual != wanted:
        tree_bad.append(parent or '/')
check('all 365 Git tree object hashes reconstructed independently', not tree_bad and len(children) == 365, tree_bad)
projection = load('immutable-source-projection.json')
bad_blobs = []
for e in projection['files']:
    blob = load(e['record_stdout'])
    data = base64.b64decode(blob['content'])
    actual = (PACKET / 'source' / e['path']).read_bytes()
    if not (data == actual and len(data) == e['bytes'] == blob['size'] and digest(data) == e['sha256'] and git_hash('blob', data) == e['git_blob_sha'] == blob['sha'] == entries[e['path']]['sha'] and e['git_mode'] == entries[e['path']]['mode']):
        bad_blobs.append(e['path'])
check('all 34 exact selected API blobs/source bytes/Git hashes/tree entries', len(projection['files']) == projection['selected_source_blobs'] == 34 and not bad_blobs, bad_blobs)

# Read ZIP members with CRC verification; compare every retained manifest member.
def audit_zip(manifest, folder):
    info = manifest['zip']
    data = (PACKET / info['path']).read_bytes()
    check(info['path'] + ' supplied digest and raw download bytes', len(data) == info['bytes'] and digest(data) == info['sha256'] and data == (PACKET / info['command_stdout']).read_bytes())
    idx = {x['path']: x for x in manifest['files']}
    bad = []
    with zipfile.ZipFile(PACKET / info['path']) as z:
        zs = z.infolist()
        check(info['path'] + ' finite safe regular membership', len(zs) == len(idx) == manifest['safe_regular_file_count'] == manifest['zip_entry_count'] and len({x.filename for x in zs}) == len(zs) and all(safe(x.filename) and not x.is_dir() and not stat.S_ISLNK(x.external_attr >> 16) for x in zs))
        for zi in zs:
            body = z.read(zi)
            r = idx[zi.filename]
            if not (len(body) == r['bytes'] and digest(body) == r['sha256'] and zi.compress_size == r['compressed_bytes'] and f'{zi.CRC:08x}' == r['crc32_hex'] and body == (PACKET / folder / zi.filename).read_bytes()):
                bad.append(zi.filename)
    check(info['path'] + ' every member CRC/hash/extraction receipt', not bad, bad)
    return list(idx)

logs_manifest = load('official-logs-manifest.json')
audit_zip(logs_manifest, 'official-logs')
artifact_doc = load('official-failure-artifacts-manifest.json')
artifact = artifact_doc['artifacts'][0]
artifact_names = audit_zip(artifact, artifact['extracted_folder'])
check('official Windows artifact only 10 PNGs', artifact_doc['actual_total_artifacts'] == len(artifact_doc['artifacts']) == 1 and artifact['metadata']['id'] == 12162960570 and artifact['zip']['bytes'] == 465158 and len(artifact_names) == 10 and all(x.endswith('.png') for x in artifact_names) and artifact['metadata']['digest'] == 'sha256:' + artifact['zip']['sha256'])
observed['artifacts'] = {'logs_zip': logs_manifest['zip'], 'logs_members': 86, 'Windows_zip': artifact['zip'], 'Windows_members': len(artifact_names), 'Windows_contents': 'Only visual PNGs; no PE/DLL/runtime list/trace/video/error-context evidence.'}

ansi = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
timestamp = re.compile(r'^\d{4}-\d\d-\d\dT\S+Z ?')
def normal(line):
    return ansi.sub('', timestamp.sub('', line))

summary = load('hosted-ci-summary.json')
registry = json.loads((PACKET / 'source/scripts/verification-suites.json').read_bytes())
rust = next(s for s in registry['suites'] if s['id'] == 'rust')['commands']
rust_cmds = ['$ ' + ' '.join(c) for c in rust]
check('strict Clippy source scope: three manifests, one desktop all-features mode', len([c for c in rust if c[:2] == ['cargo', 'clippy']]) == 3 and len([c for c in rust if c[:2] == ['cargo', 'clippy'] and 'apps/desktop/src-tauri/Cargo.toml' in c]) == 1 and ['cargo','clippy','--locked','--manifest-path','apps/desktop/src-tauri/Cargo.toml','--all-targets','--all-features','--','-D','warnings'] in rust)
verify = (PACKET / 'source/scripts/verify.py').read_text()
check('frozen verifier breaks suite loop on first nonzero', 'for argv in commands if not messages else ():' in verify and 'messages.append(f"command failed (exit {code}): {\' \'.join(argv)}")\n                break' in verify)
platform_logs = load('platform-logs-manifest.json')
all_raw = {}
all_normal = {}
for m in platform_logs['platforms']:
    b = (PACKET / m['platform_log']).read_bytes()
    check(m['label'] + ' full log exact official combined bytes', len(b) == m['bytes'] and digest(b) == m['sha256'] and b == (PACKET / 'official-logs' / m['official_combined_member']).read_bytes())
    all_raw[m['platform_log']] = b.decode('utf-8').splitlines()
    all_normal[m['platform_log']] = [normal(l) for l in all_raw[m['platform_log']]]
    check(m['label'] + ' raw checkout SHA observed', MERGE in all_normal[m['platform_log']] and m['actual_checkout_sha'] == MERGE and m['actual_checkout_tree'] == TREE)

ref_count = 0
ref_bad = []
def audit_refs(x):
    global ref_count
    if isinstance(x, dict):
        if all(k in x for k in ('log','line','raw','text')) and x['log'] in all_raw:
            ref_count += 1
            line = all_raw[x['log']][x['line'] - 1]
            if line != x['raw'] or normal(line).strip() != x['text'].strip():
                ref_bad.append([x['log'], x['line']])
        for value in x.values():
            audit_refs(value)
    elif isinstance(x, list):
        for value in x:
            audit_refs(value)
audit_refs(summary)
check('all summary raw log/line/text references independently resolve', not ref_bad, {'reference_occurrences': ref_count, 'bad': ref_bad})

cohorts = {}
observed['platforms'] = []
for p in summary['platforms']:
    label, logfile = p['label'], p['platform_log']
    lines = all_normal[logfile]
    rows = [re.fullmatch(r'(\S+)\s+(ACTIVE)\s+(PASS|FAIL)(?:\s+(.*?))?\s*', l) for l in lines]
    rows = [r for r in rows if r]
    pass_count = sum(r[3] == 'PASS' for r in rows)
    check(label + ' raw aggregate 20 ACTIVE outcomes', [r[1] for r in rows] == [s['id'] for s in registry['suites']] and len(rows) == 20 and pass_count == (19 if label.startswith('windows') else 20) and pass_count == p['reported_suite_pass_count'])
    check(label + ' doctor28 raw summary', 'summary: 28 pass, 0 warning, 0 fail, 0 not-yet-applicable' in lines)
    ts_start = next(i for i,l in enumerate(lines) if l.startswith('$ pnpm exec turbo run test --force'))
    ts_end = next(i for i in range(ts_start+1,len(lines)) if lines[i].startswith('$ '))
    ts_counts = [int(m[1]) for l in lines[ts_start:ts_end] if (m := re.fullmatch(r'\s*Tests\s+(\d+) passed \(\d+\)\s*',l))]
    check(label + ' forced root TS counts', len(ts_counts) == 15 and sum(ts_counts) == 4006 == p['unit_ts']['passed'])
    browser_counts = {}
    for group, q in p['playwright'].items():
        start = next(i for i,l in enumerate(lines) if l == q['command'])
        end = next((i for i in range(start+1,len(lines)) if lines[i].startswith('$ ')),len(lines))
        counts = [int(m[1]) for l in lines[start+1:end] if (m := re.fullmatch(r'\s*(\d+) passed \([^)]+\)\s*',l))]
        browser_counts[group] = counts
        check(label + ' raw browser ' + group, counts == [q['expected_pass_count']] and q['summary_counts'] == {'passed': counts[0]})
    col_end = next(i for i,l in enumerate(lines) if re.fullmatch(r'\d+ tests collected in [\d.]+s',l))
    col_start = max(i for i,l in enumerate(lines[:col_end]) if l.startswith('$ uv run pytest ') and '--collect-only' in l)
    nodes = [l for l in lines[col_start+1:col_end] if re.match(r'(scripts|services)/.*::',l)]
    cohorts[label] = collections.Counter(nodes)
    n = 1677 if label.startswith('windows') else 1679
    footers = [l for l in lines[col_end+1:] if re.fullmatch(r'=+ \d+ passed in [\d.]+s(?: \([^)]+\))? =+',l)]
    check(label + ' raw Python collection and execution count', len(nodes) == n and int(lines[col_end].split()[0]) == n and len(footers) == 1 and re.match(r'=+ '+str(n)+r' passed in ',footers[0]) is not None and p['python']['passed'] == n)
    positions = [(i,l) for i,l in enumerate(lines) if l in rust_cmds]
    expected_n = 12 if label.startswith('windows') else 15
    check(label + ' raw Rust registry exact started prefix', [l for _,l in positions] == rust_cmds[:expected_n])
    native = []
    for cmd in rust_cmds[11:14]:
        hits = [i for i,l in enumerate(lines) if l == cmd]
        if not hits:
            native.append({'command':cmd,'status':'UNEXECUTED','library_counts':[]})
            continue
        start = hits[0]
        end = next((i for i in range(start+1,len(lines)) if lines[i].startswith('$ ')),len(lines))
        counts = [int(m[1]) for l in lines[start+1:end] if (m := re.match(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;',l)) and int(m[1]) > 0]
        native.append({'command':cmd,'status':'FAILED_LOADER' if label.startswith('windows') else 'PASS','library_counts':counts})
    expected_counts = [[],[],[]] if label.startswith('windows') else [[138 if label.startswith('macos') else 137]] * 3
    check(label + ' independently parsed three native library modes', [x['library_counts'] for x in native] == expected_counts)
    if label.startswith('windows'):
        check('Windows loader exit and no library execution/start lines', any('exit code: 0xc0000139, STATUS_ENTRYPOINT_NOT_FOUND' in l for l in lines) and '- command failed (exit 3221225785): cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml' in [l.strip() for l in lines] and not any(re.fullmatch(r'running \d+ tests?', l) for l in lines[positions[-1][0]:]))
    temp_lines = [l.strip() for l in lines if re.match(r'\s*(TMPDIR|TEMP|TMP): ',l)]
    tool_lines = [l for l in lines if 'PASS' in l and re.match(r'(Node |pnpm |uv |Python |cargo |rustc |@playwright/test )', l)]
    check(label + ' pinned tool doctor rows exist', all(any(l.startswith(prefix) for l in tool_lines) for prefix in ('Node 24.18.0','pnpm 11.17.0','uv 0.11.32','Python 3.12.13','cargo 1.97.1','rustc 1.97.1','@playwright/test 1.62.0')))
    observed['platforms'].append({'platform':label,'job_id':p['job_id'],'job_conclusion':p['job_conclusion'],'aggregate_passes':pass_count,'aggregate_exit':p['verification_exit_code'],'step26':p['neutrality']['actual_step']['conclusion'],'typescript':sum(ts_counts),'browser':browser_counts,'Python':n,'Python_footer':footers,'Rust_commands_started':expected_n,'native_modes':native,'temp_declarations':temp_lines,'tool_doctor_rows':tool_lines})
posix = list((cohorts['ubuntu-24.04'] - cohorts['windows-2025']).elements())
inventory = json.loads((PACKET / 'source/scripts/python-test-inventory.v1.json').read_bytes())
check('Python visible cohort difference equals exact inventory POSIX-only FIFO/socket cases', cohorts['ubuntu-24.04'] == cohorts['macos-15'] and not (cohorts['windows-2025'] - cohorts['ubuntu-24.04']) and sorted(posix) == sorted(inventory['posix_only_node_ids']) and len(posix) == 2)
observed['Python_cohort_difference'] = {'POSIX_only':posix,'scope':'Visible masked-line multiset only; not a claim of unique unredacted-ID equality.'}
check('early complete Windows log identical final official combined bytes', (PACKET / 'early-windows-closure/official-job.log').read_bytes() == (PACKET / 'platform-logs/windows-2025.log').read_bytes())
check('all actual benchmark payloads have exactly one sample', all(len(p['extension_benchmark_actual_payloads']) == 1 and p['extension_benchmark_actual_payloads'][0]['sampleCount'] == 1 for p in summary['platforms']))
observed['limits'] = ['Actual run FAILURE remains FAILURE; no total Windows PASS.', 'Windows all-features/custom-protocol tests and final native build unexecuted after default loader failure.', 'Missing DLL/export identity and cause are not reported.', 'Browser passes close only this run browser scope; historical cancelled/failed runs remain distinct.', 'No canonical-root/local-full result equality or transfer, native GUI/package/platform/M03/release acceptance, 20-sample performance or speed-causality claim.']
result = 'PASS' if all(c['result'] == 'PASS' for c in checks) else 'FAIL'
checks_doc = {'result':result,'scope':'Documentary integrity/consistency only; actual product run conclusion remains failure.', 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks}
(OUT / 'checks.json').write_text(json.dumps(checks_doc,indent=2)+'\n')
(OUT / 'observations.json').write_text(json.dumps(observed,indent=2)+'\n')
print(json.dumps({'documentary_result':result,'checks':len(checks),'failed_checks':[x['check'] for x in checks if x['result'] != 'PASS'],'actual_run_conclusion':'failure','actual_all_three_hosts_pass':False,'output':str(OUT)}))
