import datetime as dt,hashlib,json,pathlib,subprocess,sys,time
ROOT=pathlib.Path('/tmp/japp-m03-w04-current-app-build-independent-review-20261019')
label=sys.argv[1];argv=sys.argv[2:];assert len(argv)>=2
folder=ROOT/'operations';folder.mkdir(exist_ok=True);stem=f'{len(list(folder.glob("*.json")))+1:04d}-{label}'
started=dt.datetime.now(dt.timezone.utc).isoformat();tick=time.monotonic()
p=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
row={'argv':argv,'cwd':str(ROOT),'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-tick,'exit_code':p.returncode,'scope':'Read-only finite documentary artifact curation/review; no product, compiler or GUI actors.'}
for stream,raw in [('stdout',p.stdout),('stderr',p.stderr)]:
 target=folder/(stem+'.'+stream);assert not target.exists();target.write_bytes(raw)
 row[stream]={'path':str(target.relative_to(ROOT)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
(folder/(stem+'.json')).write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(row,indent=2));print(p.stdout.decode(errors='replace')[:12000]);print(p.stderr.decode(errors='replace')[:12000]);raise SystemExit(p.returncode)
