# Closure command PATH clarification

The first 22 entries in the original closure.json commands array contain the later owned-virtualenv-prefixed PATH. Those entries cover the four initial root probes, venv-copy, cargo-copy and node-copy-01 through node-copy-16. The wrapper's command dictionaries retain a reference to the mutable ENV dictionary, so the later PATH update appears retroactively when the closure array is serialized.

For each affected command, its original individual upfront and result records agree on the initial PATH, and every other closure command field agrees. Those frozen individual records are authoritative. The full exact affected labels, before/after values and record paths are in closure-PATH-erratum.json. The actual app-build command uses the later PATH; its individual upfront/result records and closure entry all agree. No material build input remains unbound because of this summary discrepancy.

The original closure, individual records, raw logs and author archive remain untouched. This clarification is a documentary erratum, with no product failure, source change or build rerun. The original captured root before/after records also remain untouched and equal; their neutral interval ended before the parent's explicit root release.
