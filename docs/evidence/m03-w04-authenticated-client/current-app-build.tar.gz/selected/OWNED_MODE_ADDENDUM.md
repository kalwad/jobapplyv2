# Approved owned runtime-stage mode correction

Root's terminal-release follow-up diagnoses the closed current-full EACCES as inherited frozen runtime modes, not permission-policy guard files: the retained runtime leaves were read-only and Tauri's resource copy preserves those modes into the owned Cargo debug runtime. Root explicitly authorizes adding owner-write permission only to owned ignored compile/build-stage runtime leaves and owned generated/cache outputs as necessary.

This build may therefore add `u+w` to copied runtime payload leaves under its own ignored `source/apps/desktop/src-tauri/runtime-payload/` and Cargo target/generated copies, never the tracked `.gitignore`, a logical source, donor or original retained payload. Preserve every byte and every execute bit. Record original/corrected modes and SHA-256; distinguish the copied-stage map from the normalized prebuild-stage map and verify exact byte equality to the same40-file donor before/after build. Native/Python/runtime build credit is unchanged. This is a data-mode repair to owned build inputs, not weakening a guard or changing executable authority. Failed attempts, if any, remain retained.

The approved PLAN.md bytes remain unchanged. This additive mode scope comes directly from root after concrete diagnosis and before this wrapper's first actor.
