from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

SOURCE=Path('/tmp/japp-m03-w04-current-root-shadow-20261018/source')
FREEZE=SOURCE.parent/'frozen-preparation-v2'
OUT=Path('/tmp/japp-m03-w04-preparation-wheels-runtime-20261018')
OUT.mkdir(exist_ok=False)
(OUT/'executed-wrapper.py').write_bytes(Path(__file__).read_bytes())
frozen=json.loads((FREEZE/'source-manifest.json').read_text())
def source_matches():
    return all((SOURCE/n).stat().st_size==row['bytes'] and hashlib.sha256((SOURCE/n).read_bytes()).hexdigest()==row['sha256'] for n,row in frozen.items())
assert source_matches()
env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@24/bin:'+env['PATH'];env['UV_OFFLINE']='true'
records=[]
def run(label,argv):
    start=time.monotonic();record={'label':label,'argv':argv,'cwd':str(SOURCE),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with (OUT/(label+'.log')).open('xb') as f:p=subprocess.run(argv,cwd=SOURCE,env=env,stdout=f,stderr=subprocess.STDOUT)
    record.update(exit_code=p.returncode,seconds=time.monotonic()-start,log_sha256=hashlib.sha256((OUT/(label+'.log')).read_bytes()).hexdigest());records.append(record);(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True);assert p.returncode==0,label
wheels=OUT/'wheels'
run('contracts-wheel',['uv','build','--wheel','--package','japp-contracts','--out-dir',str(wheels),'--offline'])
run('service-wheel',['uv','build','--wheel','--package','orchestrator','--out-dir',str(wheels),'--offline'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
contracts=wheels/'japp_contracts-0.0.1-py3-none-any.whl';service=wheels/'orchestrator-0.0.1-py3-none-any.whl'
payload=OUT/'payload';payload.mkdir();(payload/'.gitignore').write_bytes((SOURCE/'apps/desktop/src-tauri/runtime-payload/.gitignore').read_bytes())
argv=[str(SOURCE/'.venv/bin/python'),'scripts/build-service-runtime.py','--contracts-wheel',str(contracts),'--contracts-sha256',sha(contracts),'--orchestrator-wheel',str(service),'--orchestrator-sha256',sha(service),'--runtime-requirements','/tmp/japp-m03-w02-service-proposal/proof/wheel-runtime-requirements.txt','--python','/Users/tanishkalwad/.local/share/uv/python/cpython-3.12.13-macos-aarch64-none/bin/python3.12','--uv','/Users/tanishkalwad/.local/bin/uv','--work-dir',str(OUT/'build-work'),'--destination',str(payload),'--target','aarch64-apple-darwin']
run('runtime-build',argv)
assert source_matches()
(OUT/'closure.json').write_text(json.dumps({'scope':'OUTSIDE ROOT W04 BUILD PREPARATION ONLY; no service/app/browser/native/GUI actors','source_manifest_sha256':sha(FREEZE/'source-manifest.json'),'source_unchanged':True,'root_writes':False,'wheels':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in [contracts,service]},'runtime_manifest_sha256':sha(payload/'manifest.json')},indent=2)+'\n')
print((OUT/'closure.json').read_text(),flush=True)
