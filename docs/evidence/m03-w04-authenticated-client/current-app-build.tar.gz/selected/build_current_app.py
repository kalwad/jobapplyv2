"""Approved outside-only fresh1849 app build; never launches app or service."""
from __future__ import annotations
import hashlib
import json
import os
import shutil
import signal
import stat
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

B=Path(__file__).resolve().parent
S=B/'source'
J=Path('/tmp/japp-m03-w04-current-tooling-join-20261019')
D=Path('/tmp/japp-m03-w04-owned-session-full-preparation-v3-20261019')
P=Path('/tmp/japp-m03-w04-owned-session-app-build-v2-20261019')
R=Path('/tmp/japp-m03-w04-preparation-wheels-runtime-20261018')
OLD=Path('/tmp/japp-m03-w04-current-root-shadow-20261018/source')
ROOT=Path('/Users/tanishkalwad/jobapplyv2')
MANIFEST='b79acf135fcd53da216363dfa50f30af376315fab3504696a697fe08490a66d0'
RUNTIME='d274dcc7194722a4ec1549043543225d63bf48e5c6c8e55f4049eee4b5ceeea0'
RUST=Path('/Users/tanishkalwad/.rustup/toolchains/1.97.1-aarch64-apple-darwin/bin')
ENV={'HOME':'/Users/tanishkalwad','USER':'tanishkalwad','LOGNAME':'tanishkalwad','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TMPDIR':str(B/'tmp'),'PATH':str(RUST)+':/opt/homebrew/opt/node@24/bin:/Users/tanishkalwad/.local/bin:/usr/bin:/bin:/usr/sbin:/sbin','CARGO_TARGET_DIR':str(B/'cargo-target'),'CARGO_NET_OFFLINE':'true','UV_OFFLINE':'true','COREPACK_ENABLE_NETWORK':'0','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_SYSTEM':'/dev/null','GIT_OPTIONAL_LOCKS':'0','PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':os.pathsep.join(str(S/n) for n in ['services/orchestrator/src','packages/contracts/generated/python/src','scripts'])}
COMMANDS=[]
DONORS={}
ROWS={}

def require(condition, code):
    if not condition: raise RuntimeError(code)

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def now():return datetime.now(timezone.utc).isoformat()
def write(p,data):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
def identity(p):
    q=p.resolve(strict=True)
    return {'requested':str(p),'resolved':str(q),'bytes':q.stat().st_size,'mode':stat.S_IMODE(q.stat().st_mode),'sha256':sha(q)}
def inv(root,names):
    return {n:{'bytes':(root/n).stat().st_size,'sha256':sha(root/n)} for n in sorted(names)}
def tree(root):
    result={}
    require(root.is_dir() and not root.is_symlink(),'TREE_ROOT_REQUIRED')
    for parent,dirs,files in os.walk(root,followlinks=False):
        for name in sorted(dirs+files):
            p=Path(parent)/name;n=p.relative_to(root).as_posix();mode=stat.S_IMODE(p.lstat().st_mode)
            if p.is_symlink():result[n]={'type':'symlink','target':os.readlink(p),'mode':mode}
            elif p.is_file():result[n]={'type':'file','bytes':p.stat().st_size,'sha256':sha(p),'mode':mode}
            else:require(p.is_dir(),'NONREGULAR_TREE_ENTRY')
    return result

def source_ok():
    return not ROWS or (inv(J/'source',ROWS)==ROWS and (not S.exists() or inv(S,ROWS)==ROWS))

def run(label,argv,cwd,timeout=300,input_bytes=None,expect=True):
    exe=Path(shutil.which(argv[0],path=ENV['PATH']) or argv[0])
    record={'label':label,'argv':argv,'cwd':str(cwd),'environment':ENV,'source_manifest_sha256':MANIFEST,'started_utc':now(),'timeout_seconds':timeout,'executable':identity(exe),'wrapper':identity(Path(__file__)),'plan_sha256':sha(B/'PLAN.md'),'scope':'OUTSIDE_APP_BUILD_ONLY_NOT_LAUNCHED'}
    write(B/'commands'/f'{label}-upfront.json',record)
    start=time.monotonic();timed_out=False
    with (B/'commands'/f'{label}.stdout').open('xb') as out,(B/'commands'/f'{label}.stderr').open('xb') as err:
        child=subprocess.Popen(argv,cwd=cwd,env=ENV,stdin=subprocess.PIPE if input_bytes is not None else subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
        write(B/'commands'/f'{label}-owned-pid.json',{'pid':child.pid,'parent_pid':os.getpid(),'owned_process_group':child.pid})
        try:child.communicate(input_bytes,timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out=True;os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=5)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
        except BaseException:
            if child.poll() is None:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=5)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
            raise
        finally:
            record.update(exit_code=child.poll(),timed_out=timed_out,owned_child_reaped=child.poll() is not None,elapsed_seconds=time.monotonic()-start,ended_utc=now(),executable_after=identity(exe),stdout_sha256=sha(B/'commands'/f'{label}.stdout'),stderr_sha256=sha(B/'commands'/f'{label}.stderr'),logical_source_unchanged=source_ok())
            write(B/'commands'/f'{label}-result.json',record);COMMANDS.append(record)
    print(json.dumps({'label':label,'exit':record['exit_code'],'seconds':record['elapsed_seconds']}),flush=True)
    require(record['logical_source_unchanged'] and record['executable']==record['executable_after'],'COMMAND_INPUT_CHANGED')
    require(not timed_out and record['owned_child_reaped'],'COMMAND_NOT_COMPLETE')
    if expect:require(child.returncode==0,'COMMAND_FAILED_'+label)
    return child.returncode,(B/'commands'/f'{label}.stdout').read_text()

def root_state(label):
    _,head=run(label+'-head',['git','rev-parse','HEAD'],ROOT)
    _,git_tree=run(label+'-tree',['git','rev-parse','HEAD^{tree}'],ROOT)
    _,status=run(label+'-status',['git','status','--porcelain=v1','--untracked-files=all'],ROOT)
    _,names=run(label+'-paths',['git','ls-files','-z'],ROOT)
    paths=names.rstrip('\0').split('\0')
    record={'head':head.strip(),'tree':git_tree.strip(),'status':status,'tracked_paths':len(paths),'files':inv(ROOT,paths)}
    write(B/(label+'.json'),record);return record

def clone(label,src,dst):
    require(src.is_dir() and not src.is_symlink() and not dst.exists(),'BAD_COW_COPY')
    before=tree(src);write(B/'dependency-inputs'/(label+'.json'),{'source':str(src),'tree':before})
    DONORS[label]=(src,before)
    dst.parent.mkdir(parents=True,exist_ok=True)
    run(label,['/bin/cp','-cR',str(src),str(dst)],B)
    require(tree(src)==before and tree(dst)==before,'COW_COPY_CHANGED_BYTES_OR_MODES')

def normalize_generated(label):
    changes={}
    for root in [B/'cargo-target',S/'apps/desktop/src-tauri/gen',S/'apps/desktop/src-tauri/runtime-payload']:
        if not root.exists():continue
        for parent,dirs,files in os.walk(root,followlinks=False):
            for name in sorted(dirs+files):
                p=Path(parent)/name
                if p.is_symlink():continue
                mode=stat.S_IMODE(p.stat().st_mode)
                if mode & stat.S_IWUSR:continue
                rel=p.relative_to(B).as_posix()
                require(not p.is_relative_to(S) or p.relative_to(S).as_posix() not in ROWS,'LOGICAL_SOURCE_MODE_CHANGE_REFUSED')
                digest=sha(p) if p.is_file() else None
                p.chmod(mode|stat.S_IWUSR)
                require(not p.is_file() or sha(p)==digest,'MODE_REPAIR_CHANGED_BYTES')
                changes[rel]={'old_mode':mode,'new_mode':mode|stat.S_IWUSR,'byte_sha256':digest}
    write(B/(label+'.json'),{'scope':'OWN_IGNORED_CARGO_GENERATED_OR_RUNTIME_STAGE_ONLY_BYTE_NEUTRAL_ADD_OWNER_WRITE_NO_EXEC_BIT_CHANGE','entries':changes})
    return changes

def main():
    global ROWS
    require(sha(B/'PLAN.md')=='d94fa22b22c07bfdd95538d77f1431a2fb521720541b25530a1d3d2c38aefbcc','APPROVED_PLAN_CHANGED')
    require(sha(J/'source-manifest.json')==MANIFEST,'JOINED_SOURCE_MANIFEST_CHANGED')
    ROWS=json.loads((J/'source-manifest.json').read_text());require(len(ROWS)==1849 and not S.exists(),'WRONG_SOURCE_COUNT_OR_ALREADY_STARTED')
    (B/'tmp').mkdir(mode=0o700);(B/'commands').mkdir();(B/'dependency-inputs').mkdir()
    write(B/'authorization.json',{'root_scope_approval':'PLANd94fa22 approved','terminal_release':'Current full38742 closed1 at02:50:29; root direct message authorizes this build using completed oldv3 donor only','GUI':'NO_LAUNCH; native_GUI_availability_UNVERIFIED; lastCUAcheck_TOOLSAFETYBLOCKED','authority':'NONE'})
    before=root_state('root-before');require(before['head']=='6d3a6b8ccde5b75e12248ae7bbefc473b72922e4' and before['status']=='','ROOT_EPOCH_CHANGED')
    require(inv(J/'source',ROWS)==ROWS,'SOURCE_BYTES_NOT_FROZEN')
    donor_rows=json.loads((D/'source-manifest.json').read_text());require(len(donor_rows)==1848 and inv(D/'source',donor_rows)==donor_rows,'COMPLETED_DONOR_SOURCE_CHANGED')
    write(B/'source-manifest.json',ROWS)
    for name in ROWS:
        dst=S/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(J/'source'/name,dst)
    require(inv(S,ROWS)==ROWS,'OWN_SOURCE_COPY_MISMATCH')
    inputs=json.loads((P/'unchanged-python-wheel-source-inputs.json').read_text())['paths'];require(len(inputs)==135,'WRONG_RUNTIME_INPUT_COUNT')
    require(inv(OLD,inputs)==inputs and inv(J/'source',inputs)==inputs and inv(S,inputs)==inputs,'RUNTIME_135_BYTES_NOT_APPLICABLE')
    payload=R/'payload';require(sha(payload/'manifest.json')==RUNTIME,'RUNTIME_MANIFEST_CHANGED')
    prior_runtime=json.loads((P/'runtime-source-tree.json').read_text());runtime_actual=inv(payload,prior_runtime)
    require(len(prior_runtime)==40 and runtime_actual==prior_runtime,'WHOLE_RUNTIME_NOT_IDENTICAL')
    require({p.relative_to(payload).as_posix() for p in payload.rglob('*') if p.is_file()}==set(prior_runtime),'UNEXPECTED_RUNTIME_LEAF')
    require(not any(p.is_symlink() for p in payload.rglob('*')),'RUNTIME_SYMLINK')
    manifest=json.loads((payload/'manifest.json').read_text())
    require(set(prior_runtime)=={entry['path'] for entry in manifest['files']}|{'manifest.json'},'RUNTIME_MANIFEST_MEMBERSHIP_MISMATCH')
    for entry in manifest['files']:require(prior_runtime[entry['path']]=={'bytes':entry['bytes'],'sha256':entry['sha256']},'RUNTIME_DECLARED_FILE_CHANGED')
    wheels={'japp_contracts-0.0.1-py3-none-any.whl':'d1ac6f4725a98bb35dca624192bc80b89d4634a3558467b80b6b2f190b2c6d7c','orchestrator-0.0.1-py3-none-any.whl':'6ef4e59987a42d0a4b34d9bb8507537616e7d83913133b2d5a55bbb83b5e6052'}
    wheel_proof={}
    for name,digest in wheels.items():
        path=R/'wheels'/name;require(sha(path)==digest,'RETAINED_WHEEL_CHANGED');wheel_proof[name]=identity(path)
    requirements={'runtime_requirements':(Path('/tmp/japp-m03-w02-service-proposal/proof/wheel-runtime-requirements.txt'),'b02e40a467e53d35159f3bc06d456ca98d83020daac6d6d720e2e4bb2d8fe307'),'build_requirements':(S/'scripts/service-build-tools.requirements.lock','a61cfea9359f0f0f6fdab4a0d1d3753aa719e73f3404e930adb75d7f99eb9e79')}
    requirement_proof={}
    for name,(path,digest) in requirements.items():
        retained=R/'build-work/inputs'/({'runtime_requirements':'wheel-runtime-requirements.txt','build_requirements':'service-build-tools.requirements.lock'}[name])
        require(sha(path)==digest and sha(retained)==digest and manifest['source_inputs'][name+'_sha256']==digest,'ACTUAL_REQUIREMENT_NOT_APPLICABLE')
        requirement_proof[name]={'current':identity(path),'retained_build_input':identity(retained)}
    require(manifest['source_inputs']['contracts_wheel_sha256']==wheels['japp_contracts-0.0.1-py3-none-any.whl'] and manifest['source_inputs']['orchestrator_wheel_sha256']==wheels['orchestrator-0.0.1-py3-none-any.whl'],'WHEEL_MANIFEST_JOIN_FAILED')
    write(B/'runtime-applicability.json',{'scope':'ACTUAL_UNCHANGED135_PLUS_REQUIREMENT_LOCKS_WHEELS_WHOLE40_REUSE_ONLY','source_inputs':inputs,'wheels':wheel_proof,'additional_requirements':requirement_proof,'runtime':runtime_actual,'new_Python_build_or_actor_credit':False})
    retained_inputs=B/'retained-runtime-inputs';retained_inputs.mkdir()
    for name in wheels:shutil.copy2(R/'wheels'/name,retained_inputs/name)
    for _name,(path,_digest) in requirements.items():shutil.copy2(path,retained_inputs/path.name)
    for name in ['executed-wrapper.py','commands.json','closure.json','contracts-wheel.log','service-wheel.log','runtime-build.log']:
        shutil.copy2(R/name,retained_inputs/('historical-'+name))
    stage=S/'apps/desktop/src-tauri/runtime-payload'
    require({p.relative_to(stage).as_posix() for p in stage.rglob('*') if p.is_file()}=={'.gitignore'},'UNEXPECTED_EXISTING_STAGE')
    for name in prior_runtime:
        dst=stage/name;src=payload/name
        if dst.exists():require(sha(dst)==sha(src),'TRACKED_RUNTIME_MERGE_CONFLICT')
        else:dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
    require(inv(stage,prior_runtime)==runtime_actual,'STAGE_RUNTIME_MISMATCH')
    write(B/'runtime-stage-copied.json',tree(stage))
    clone('venv-copy',D/'source/.venv',S/'.venv')
    clone('cargo-copy',D/'cargo-target',B/'cargo-target')
    normalize_generated('owned-prebuild-write-modes')
    write(B/'runtime-stage-before.json',tree(stage))
    copy_number=0
    for parent in sorted({Path(n).parent.as_posix() for n in ROWS if Path(n).name=='package.json'}):
        src=D/'source'/parent/'node_modules'
        if src.is_dir():
            copy_number+=1;clone(f'node-copy-{copy_number:02}',src,S/parent/'node_modules')
    changes={};oldprefix=str((D/'source').resolve()).encode();newprefix=str(S).encode()
    for p in sorted(S.rglob('*')):
        if p.is_symlink() or not p.is_file():continue
        rel=p.relative_to(S).as_posix()
        eligible=(rel.startswith('.venv/bin/') or ('.bin/' in rel and 'node_modules/' in rel) or (p.name in {'.modules.yaml','.pnpm-workspace-state-v1.json'} and 'node_modules/' in rel))
        if not eligible:continue
        raw=p.read_bytes();updated=raw.replace(oldprefix,newprefix)
        if rel.startswith('.venv/bin/') and raw.startswith(b'#!'):
            first,sep,rest=updated.partition(b'\n')
            if b'/bin/python' in first:updated=b'#!'+str(S/'.venv/bin/python').encode()+sep+rest
        if updated!=raw:
            p.write_bytes(updated);changes[rel]={'before_sha256':hashlib.sha256(raw).hexdigest(),'after_sha256':sha(p)}
    for pkg,rel in [('japp_contracts','packages/contracts/generated/python/src'),('orchestrator','services/orchestrator/src')]:
        p=S/'.venv/lib/python3.12/site-packages'/f'_editable_impl_{pkg}.pth';raw=p.read_bytes();p.write_text(str(S/rel));changes[p.relative_to(S).as_posix()]={'before_sha256':hashlib.sha256(raw).hexdigest(),'after_sha256':sha(p)}
    for parent in sorted({Path(n).parent.as_posix() for n in ROWS if Path(n).name=='package.json'}):
        folder=S/parent/'node_modules'
        if not folder.is_dir():continue
        for p in folder.rglob('*'):
            if p.is_symlink():require(p.resolve().is_relative_to(S),'COPIED_NODE_LINK_ESCAPES_OWN_SOURCE')
    write(B/'owned-dependency-reanchors.json',changes)
    ENV['PATH']=str(S/'.venv/bin')+':'+ENV['PATH']
    tools={n:identity(Path(shutil.which(n,path=ENV['PATH']))) for n in ['node','pnpm','cargo','rustc','clang','xcrun','codesign','git','cp']}
    cli=S/'apps/desktop/node_modules/@tauri-apps/cli/tauri.js'
    if cli.is_file():tools['tauri-js']=identity(cli)
    write(B/'toolchain-upfront.json',tools)
    run('node-version',['node','--version'],S);run('pnpm-version',['pnpm','--version'],S);run('rustc-version',['rustc','--version'],S);run('cargo-version',['cargo','--version'],S)
    run('tauri-version',['pnpm','--filter','@japp/desktop','exec','tauri','--version'],S)
    empty=B/'empty-git-template';empty.mkdir();run('git-init',['git','init','--quiet','--template='+str(empty),'--initial-branch=codex/w04-current-app-build',str(S)],B)
    paths=B/'logical-paths.nul';paths.write_bytes(b'\0'.join(n.encode() for n in sorted(ROWS))+b'\0')
    run('git-add',['git','add','--force','--pathspec-from-file='+str(paths),'--pathspec-file-nul'],S)
    _,git_tree=run('git-write-tree',['git','write-tree'],S)
    _,commit=run('git-commit',['git','-c','user.name=Outside Preparation','-c','user.email=evidence@example.invalid','-c','commit.gpgsign=false','commit-tree',git_tree.strip()],S,input_bytes=b'Synthetic exact1849 outside app build snapshot only\n')
    run('git-head',['git','update-ref','refs/heads/codex/w04-current-app-build',commit.strip()],S)
    _,own_status=run('git-status-before',['git','status','--porcelain=v1','--untracked-files=all'],S);require(own_status=='','OWN_SOURCE_GIT_NOT_CLEAN')
    write(B/'isolated-git-input.json',{'commit':commit.strip(),'tree':git_tree.strip(),'own_objects_index_refs':str(S/'.git'),'canonical_commit':False,'source_manifest':MANIFEST})
    run('cargo-clean-help',['cargo','clean','--help'],S)
    run('cargo-clean-desktop',['cargo','clean','-p','japp-desktop','--manifest-path',str(S/'apps/desktop/src-tauri/Cargo.toml'),'--locked','--offline'],S)
    app=B/'cargo-target/debug/bundle/macos/Desktop App.app'
    if app.exists():shutil.rmtree(app)
    require(not (S/'apps/desktop/dist').exists() and not app.exists() and not (B/'cargo-target/debug/japp-desktop').exists(),'FRESH_PRODUCT_OUTPUT_PREMISE_FAILED')
    overlay=B/'local-app-build.json';write(overlay,{'bundle':{'active':True}})
    argv=['pnpm','--filter','@japp/desktop','exec','tauri','build','--debug','--bundles','app','--config',str(overlay),'--ci','--','--locked','--offline']
    code,_=run('build-app-attempt1',argv,S,600,expect=False)
    if code:
        error=(B/'commands/build-app-attempt1.stderr').read_text()
        require('Permission denied' in error or 'PermissionDenied' in error,'BUILD_FAILED_WITHOUT_AUTHORIZED_MODE_REPAIR')
        fixes=normalize_generated('owned-regenerated-write-modes')
        require(bool(fixes),'NO_OWNED_READONLY_REPAIR_AVAILABLE')
        code,_=run('build-app-attempt2',argv,S,600,expect=False)
    require(code==0,'APP_BUILD_NOT_SUCCESSFUL')
    actual=tree(app);runtime_bundled=inv(app/'Contents/Resources/runtime',prior_runtime)
    require(runtime_bundled==runtime_actual and tree(stage)==json.loads((B/'runtime-stage-before.json').read_text()),'BUNDLED_RUNTIME_CHANGED')
    require({p.relative_to(app/'Contents/Resources/runtime').as_posix() for p in (app/'Contents/Resources/runtime').rglob('*') if p.is_file()}==set(prior_runtime),'UNEXPECTED_BUNDLED_RUNTIME_FILE')
    write(B/'app-tree.json',actual);write(B/'renderer-output-tree.json',tree(S/'apps/desktop/dist'))
    descriptors=list((B/'cargo-target/debug/build').glob('japp-desktop-*/out/runtime_descriptor.rs'));require(len(descriptors)==1,'UNEXPECTED_COMPILED_DESCRIPTOR_COUNT')
    shutil.copy2(descriptors[0],B/'runtime_descriptor.executed.rs')
    write(B/'binary-runtime-join.json',{'main_executable':identity(app/'Contents/MacOS/japp-desktop'),'runtime_manifest':identity(app/'Contents/Resources/runtime/manifest.json'),'runtime_executable':identity(app/'Contents/Resources/runtime'/manifest['entrypoint']),'build_rs':ROWS['apps/desktop/src-tauri/build.rs'],'build_support_rs':ROWS['apps/desktop/src-tauri/build_support.rs'],'compiled_descriptor':identity(descriptors[0]),'runtime40_exact':True,'new_Python_build_credit':False,'launched':False})
    saved=B/'app-upfront'/app.name;saved.parent.mkdir();shutil.copytree(app,saved,copy_function=shutil.copy2,symlinks=True);require(tree(saved)==actual,'UPFRONT_APP_COPY_NOT_EXACT')
    write(B/'app-upfront-tree.json',tree(saved))
    donor_checks={}
    for label,(src,expected) in DONORS.items():require(tree(src)==expected,'COMPLETED_DONOR_MUTATED');donor_checks[label]={'source':str(src),'unchanged':True}
    require(inv(D/'source',donor_rows)==donor_rows and source_ok(),'SOURCE_DONOR_CHANGED')
    require(inv(payload,prior_runtime)==runtime_actual,'RUNTIME_DONOR_CHANGED')
    after=root_state('root-after');require(before==after,'CANONICAL_ROOT_CHANGED_DURING_BUILD')
    _,own_status=run('git-status-after',['git','status','--porcelain=v1','--untracked-files=all'],S);require(own_status=='','OWN_SOURCE_DIRTY_AFTER_BUILD')
    write(B/'closure.json',{'scope':'ACTUAL_FRESH_JOINED1849_MACOS_DEBUG_APP_BUILD_ONLY','source_manifest_sha256':MANIFEST,'source1849_unchanged':True,'completed_donors_unchanged':donor_checks,'runtime135_plus_locks_wheels40_actual_applicable':True,'Python_payload_reused_no_new_build_credit':True,'build_exit0':True,'whole_bundle_regular_files':sum(v['type']=='file' for v in actual.values()),'upfront_copy_exact':True,'runtime40_exact':True,'root_unchanged':True,'own_git_clean':True,'app_launched':False,'native_GUI_availability':'UNVERIFIED','latest_GUI_check':'TOOLSAFETYBLOCKED; no workaround','W05_W09_composition':False,'owner1850_credit':False,'milestone_acceptance':False,'commands':COMMANDS})
    print('CLOSED fresh joined1849 app build; complete bundle/upfront/runtime join; NOT_LAUNCHED; no acceptance credit',flush=True)

if __name__=='__main__':
    try:main()
    except BaseException as error:
        write(B/'wrapper-failure.json',{'created_utc':now(),'type':type(error).__name__,'code':str(error),'closure_claim':False,'commands_completed':len(COMMANDS),'app_launched':False})
        raise
