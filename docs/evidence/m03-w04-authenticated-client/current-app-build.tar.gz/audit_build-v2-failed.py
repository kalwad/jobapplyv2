"""Independent source/data review; never executes built code or a compiler."""
import datetime as dt,hashlib,json,os,pathlib,re,stat,subprocess
ROOT=pathlib.Path('/tmp/japp-m03-w04-current-app-build-independent-review-20261019')
S=ROOT/'selected'
AUTHOR=pathlib.Path('/tmp/japp-m03-w04-current-app-build-preparation-20261019')
OLD=pathlib.Path('/tmp/japp-m03-w04-current-root-shadow-20261018/source')
JOIN=pathlib.Path('/tmp/japp-m03-w04-current-tooling-join-20261019/source')
DONOR=pathlib.Path('/tmp/japp-m03-w04-owned-session-full-preparation-v3-20261019/source')
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
def save(name,value):
 p=ROOT/name;assert not p.exists();p.write_text(json.dumps(value,indent=2)+'\n')
def digest(p):
 before=p.stat();raw=p.read_bytes();after=p.stat();assert (before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns)
 return {'bytes':len(raw),'sha256':sha(raw)}
report=load(S/'REPORT.json');closure=load(S/'closure.json');source=load(S/'source-manifest.json')
assert sha((S/'REPORT.json').read_bytes())=='b737ab143f2eea0f51bd7ec964dd475c8bb3f115d43015a9b551b88cd4ceaac8'
assert sha((S/'README.md').read_bytes())=='064d299c916526389ceae3a08d81b81b4720c13828189d3326ea7b406bcd4c94'
assert len(source)==1849 and sha((S/'source-manifest.json').read_bytes())==report['source_manifest_sha256']=='b79acf135fcd53da216363dfa50f30af376315fab3504696a697fe08490a66d0'
kept=load(ROOT/'selected-member-map.json');omitted=load(ROOT/'omitted-members.json')
allrows=kept['members']+omitted['members'];byname={r['path']:r for r in allrows};assert len(byname)==4228
for name,entry in source.items():assert {k:byname['source/'+name][k] for k in ['bytes','sha256']}==entry
commands=report['commands'];assert len(commands)==len(closure['commands'])==41
checked=[];closure_path_errata=[]
for c,closed in zip(commands,closure['commands']):
 label=c['label'];assert closed['label']==label
 upfront_path=S/'commands'/(label+'-upfront.json');result_path=S/'commands'/(label+'-result.json')
 upfront=load(upfront_path);result=load(result_path)
 assert sha(upfront_path.read_bytes())==c['upfront_sha256'] and sha(result_path.read_bytes())==c['result_sha256']
 assert {k:v for k,v in result.items() if k!='environment'}=={k:v for k,v in closed.items() if k!='environment'}
 if result['environment']!=closed['environment']:
  changed=[k for k in set(result['environment'])|set(closed['environment']) if result['environment'].get(k)!=closed['environment'].get(k)]
  assert changed==['PATH'] and closed['environment']['PATH']==str(AUTHOR.resolve()/'source/.venv/bin')+':'+result['environment']['PATH']
  closure_path_errata.append({'label':label,'authoritative_upfront_path':str(upfront_path.relative_to(ROOT)),'authoritative_result_path':str(result_path.relative_to(ROOT)),'actual_PATH':result['environment']['PATH'],'closure_PATH':closed['environment']['PATH'],'different_field':'environment.PATH'})
 assert result['exit_code']==c['exit']==0 and result['timed_out'] is False and result['owned_child_reaped'] is True and result['logical_source_unchanged'] is True
 for k,v in upfront.items():assert result[k]==v
 assert result['executable']==result['executable_after'] and result['executable']['sha256']==c['executable_sha256']
 assert result['source_manifest_sha256']==report['source_manifest_sha256'] and result['wrapper']['sha256']==report['wrapper_sha256']
 for stream in ['stdout','stderr']:
  raw=(S/'commands'/(label+'.'+stream)).read_bytes();assert sha(raw)==c[stream+'_sha256']==result[stream+'_sha256']
 checked.append({'label':label,'argv':result['argv'],'exit_code':result['exit_code'],'elapsed_seconds':result['elapsed_seconds'],'started_utc':result['started_utc'],'ended_utc':result['ended_utc']})
save('actual-command-review.json',{'commands':checked,'all41_exit0_and_raw_hashes_match':True,'scope':'Actual closed author commands; no command replay by reviewer.'})
assert len(closure_path_errata)==22 and [x['label'] for x in closure_path_errata]==[x['label'] for x in commands[:22]]
save('closure-PATH-erratum.json',{'affected_command_count':len(closure_path_errata),'affected':closure_path_errata,'scope':'Only closure.commands history embeds the later mutable ENV PATH for22 early commands. Exact per-command upfront/result records agree and are authoritative. No actual build command input is missing; original author closure and raw records are unchanged.','original_closure_sha256':sha((S/'closure.json').read_bytes()),'actual_build_PATH_matches_its_upfront_result_and_closure':True})
assert sha((S/'build_current_app.py').read_bytes())==report['wrapper_sha256']
build=load(S/'commands/build-app-attempt1-result.json');assert build['argv'][:8]==['pnpm','--filter','@japp/desktop','exec','tauri','build','--debug','--bundles'] and build['argv'][8]=='app' and build['argv'][-4:]==['--ci','--','--locked','--offline']
assert build['elapsed_seconds']==report['actual_build']['seconds']==16.652394792006817 and report['actual_build']['attempts']==1
assert not (AUTHOR/'commands/build-app-attempt2-result.json').exists()
stdout=(S/'commands/build-app-attempt1.stdout').read_text();stderr=(S/'commands/build-app-attempt1.stderr').read_text()
assert 'vite v7.3.6' in stdout and '45 modules transformed.' in stdout
assert 'Compiling japp-desktop v0.0.1 (/private/tmp/japp-m03-w04-current-app-build-preparation-20261019/source)' in stderr
assert 'Bundling Desktop App.app' in stderr and 'Finished 1 bundle at:' in stderr
assert 'cargo-clean-desktop' in [c['label'] for c in commands]
assert load(S/'commands/cargo-clean-desktop-result.json')['argv'][1:4]==['clean','-p','japp-desktop']
wrapper=(S/'build_current_app.py').read_text();assert "not (S/'apps/desktop/dist').exists() and not app.exists() and not (B/'cargo-target/debug/japp-desktop').exists()" in wrapper
assert "'FRESH_PRODUCT_OUTPUT_PREMISE_FAILED'" in wrapper
assert sha((S/'root-before.json').read_bytes())==sha((S/'root-after.json').read_bytes())
root=load(S/'root-before.json');assert root['head']=='6d3a6b8ccde5b75e12248ae7bbefc473b72922e4' and root['tree']=='34fcf854cb4a1a452b267a02a05e0c34aeb6f89c' and root['status']=='' and len(root['files'])==1798
release=load(S/'canonical-root-release.json');assert report['canonical_root']['released_after_final_neutral_record'] and report['canonical_root']['no_after_release_stability_claim']
app=load(S/'app-tree.json');upfront=load(S/'app-upfront-tree.json');assert app==upfront and len(app)==42 and all(x['type']=='file' for x in app.values())
for name,entry in app.items():
 row=byname['app-upfront/Desktop App.app/'+name]
 assert {k:row[k] for k in ['bytes','sha256','mode']}=={k:entry[k] for k in ['bytes','sha256','mode']}
applicability=load(S/'runtime-applicability.json');runtime=applicability['runtime'];inputs=applicability['source_inputs']
assert len(runtime)==40 and len(inputs)==135 and applicability['new_Python_build_or_actor_credit'] is False
for name,entry in inputs.items():
 assert source[name]==entry
 for base in [OLD,JOIN,AUTHOR/'source']:assert digest(base/name)==entry
assert inputs==load(S/'metadata/prior135-input-map.json')['paths']
assert runtime==load(S/'metadata/prior40-runtime-map.json')
assert {k:{a:v[a] for a in ['bytes','sha256']} for k,v in load(S/'runtime-stage-before.json').items()}==runtime
assert load(S/'runtime-stage-before.json')==load(S/'runtime-stage-copied.json')
for name,entry in runtime.items():assert {k:app['Contents/Resources/runtime/'+name][k] for k in ['bytes','sha256']}==entry
runtime_manifest=load(S/'app-upfront/Desktop App.app/Contents/Resources/runtime/manifest.json')
assert set(runtime)=={x['path'] for x in runtime_manifest['files']}|{'manifest.json'}
for entry in runtime_manifest['files']:assert runtime[entry['path']]=={k:entry[k] for k in ['bytes','sha256']}
for name,identity in applicability['wheels'].items():
 entry={k:identity[k] for k in ['bytes','sha256']}
 assert digest(pathlib.Path(identity['resolved']))==entry and digest(S/'retained-runtime-inputs'/name)==entry
for name,value in applicability['additional_requirements'].items():
 current=value['current'];retained=value['retained_build_input'];expected={k:current[k] for k in ['bytes','sha256']}
 assert digest(pathlib.Path(current['resolved']))==expected==digest(pathlib.Path(retained['resolved']))
 assert sha((S/'retained-runtime-inputs'/pathlib.Path(current['requested']).name).read_bytes())==expected['sha256']==runtime_manifest['source_inputs'][name+'_sha256']
for field,filename in [('contracts_wheel_sha256','japp_contracts-0.0.1-py3-none-any.whl'),('orchestrator_wheel_sha256','orchestrator-0.0.1-py3-none-any.whl')]:assert runtime_manifest['source_inputs'][field]==applicability['wheels'][filename]['sha256']
descriptor=(S/'runtime_descriptor.executed.rs').read_text();hashes={}
for name in ['executable_sha256','manifest_sha256']:
 match=re.search(name+r': \[([0-9, ]+)\]',descriptor);assert match
 decoded=bytes(int(v.strip()) for v in match[1].split(','));assert len(decoded)==32;hashes[name]=decoded.hex()
assert hashes['executable_sha256']==runtime['japp-orchestrator/japp-orchestrator']['sha256']
assert hashes['manifest_sha256']==runtime['manifest.json']['sha256']
assert 'resource_relative: "runtime/japp-orchestrator/japp-orchestrator"' in descriptor
main=AUTHOR/'app-upfront/Desktop App.app/Contents/MacOS/japp-desktop';mainbytes=main.read_bytes()
assert len(mainbytes)==app['Contents/MacOS/japp-desktop']['bytes'] and sha(mainbytes)==report['actual_build']['main_sha256']
assert all(bytes.fromhex(v) in mainbytes for v in hashes.values())
reanchors=load(S/'owned-dependency-reanchors.json');assert len(reanchors)==122
for name,entry in reanchors.items():
 assert digest(AUTHOR/'source'/name)['sha256']==entry['after_sha256']
 assert digest(DONOR/name)['sha256']==entry['before_sha256']
modes=load(S/'owned-prebuild-write-modes.json');assert not modes['entries']
donor_maps=[]
for row in allrows:
 if not row['path'].startswith('dependency-inputs/'):continue
 original=AUTHOR/row['path'];raw=original.read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
 value=json.loads(raw);assert value['source'].startswith('/tmp/japp-m03-w04-owned-session-full-preparation-v3-20261019/')
 donor_maps.append({'archive_member':row['path'],'bytes':row['bytes'],'sha256':row['sha256'],'source':value['source'],'mapped_leaves':len(value['tree']),'closure_unchanged':closure['completed_donors_unchanged'][pathlib.PurePosixPath(row['path']).stem]['unchanged']})
assert len(donor_maps)==18 and all(x['closure_unchanged'] for x in donor_maps)
save('bounded-dependency-map-review.json',{'maps':donor_maps,'exact_original_archive_member_bindings':True,'reanchors122_actual_selected_bytes_checked':True,'whole_donor_cache_rehashed':False,'scope':'Recorded maps and selected actual reanchor bytes only; no independent complete cache-image claim.'})
isolated=load(S/'isolated-git-input.json');assert isolated['tree']=='771bb67a61483ec7624266664da4beb1b181b46a' and isolated['source_manifest']==report['source_manifest_sha256']
assert (S/'commands/git-commit.stdout').read_text().strip()==isolated['commit']=='c8a712867c8ceca25877432a3a77084c2cd18dd1'
assert (S/'commands/git-write-tree.stdout').read_text().strip()==isolated['tree']
assert (S/'commands/git-status-before.stdout').read_bytes()==(S/'commands/git-status-after.stdout').read_bytes()==b''
assert not (AUTHOR/'source/.git/objects/info/alternates').exists()
for name,expected in load(S/'renderer-output-tree.json').items():
 row=byname['source/apps/desktop/dist/'+name];assert {k:row[k] for k in ['bytes','sha256','mode']}=={k:expected[k] for k in ['bytes','sha256','mode']}
assert len(load(S/'renderer-output-tree.json'))==4
assert report['acceptance_limits']['app_launched'] is False and report['acceptance_limits']['service_runtime_actor'] is False
result={'result':'PASS_FOR_SOURCE_BOUND_FRESH_APP_BUILD_DATA_WITH_DOCUMENTED_METADATA_ERRATUM','scope':'Independent finite source/command/app/runtime data review; no built code, compiler, GUI or product execution by reviewer.','author_archive':load(ROOT/'original-archive-binding.json'),'metadata_erratum':{'closure_affected_early_command_PATH_fields':22,'per_command_upfront_and_result_authoritative_and_agree':True,'actual_build_receipt_matches_closure':True,'all_other_closure_command_fields_agree':True,'details':'closure-PATH-erratum.json'},'source':{'logical_entries':1849,'all_archived_source_bytes_match_b79_manifest':True,'private_commit':isolated['commit'],'private_tree':isolated['tree'],'standalone_no_alternates':True},'build':{'attempts':1,'exit_code':0,'elapsed_seconds':build['elapsed_seconds'],'commands_closed0':41,'fresh_renderer_outputs':4,'fresh_renderer_modules':45,'owned_desktop_clean_and_output_absence_guard_observed':True,'native_current_source_compile_and_app_bundle_emitted':True,'app_files_exact':42,'runtime_files_exact':40,'main_sha256':sha(mainbytes),'descriptor_numeric_arrays_and_linked_main_match':True},'runtime_reuse':{'source_inputs_actual_old_current_owned135':True,'both_wheels_and_actual_requirements_exact':True,'new_Python_build_or_execution_credit':False},'dependency_scope':{'recorded_maps_bound':18,'actual_targeted_reanchors':122,'mode_repairs':0,'whole_cache_images_rehashed':False},'captured_root':{'before_after_file_sha256':sha((S/'root-before.json').read_bytes()),'head':root['head'],'tree':root['tree'],'tracked_files':1798,'status':'','explicitly_released_after_closure':True,'no_current_root_scan_or_after_release_stability_claim':True},'curation':{'selected_members':kept['selected_count'],'omitted_exhaustively_bound':omitted['omitted_count'],'original_archive_duplicated':False,'original_archive_and_author_proof_untouched':True},'limitations':['App and service unlaunched; no native GUI or runtime execution proof.','Reused Python payload, no current Python rebuild.','No Windows11, Ubuntu default GNOME, signing/notarization/distribution trust, hosted CI, root adoption, W05/W09 composition or milestone acceptance.','Author supplemental hex-literal checker failure is retained; parsed actual Rust numeric arrays without product changes or actor reruns.']}
save('review.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in ['author_archive','limitations']},indent=2))
