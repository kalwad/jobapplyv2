"""One read-only stream over the sealed author archive; retain a small exact selection."""
import datetime as dt,hashlib,json,pathlib,stat,tarfile
OUT=pathlib.Path('/tmp/japp-m03-w04-current-app-build-independent-review-20261019')
AUTHOR=pathlib.Path('/tmp/japp-m03-w04-current-app-build-preparation-20261019')
ARCHIVE=pathlib.Path(str(AUTHOR)+'-retained/proof.tar.gz')
EXPECTED_SHA='7df491ad7bd7299d1ae0ab9b8806020dc6bdc3c6f2cbda1df808d45ab73a7b33'
def sha(b):return hashlib.sha256(b).hexdigest()
def obj(p):return json.loads(p.read_bytes())
def save(name,value):
 p=OUT/name;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2)+'\n')
source=obj(AUTHOR/'source-manifest.json');root=obj(AUTHOR/'root-before.json')['files']
delta={n:{'current':entry,'canonical_before':root.get(n)} for n,entry in source.items() if root.get(n)!=entry}
selected_source={n for n in delta if not n.startswith('docs/') and source[n]['bytes']<=262144}
selected_source.update(n for n in source if n in ['package.json','pnpm-lock.yaml','uv.lock','scripts/verification-suites.json','scripts/verify.py','scripts/build-service-runtime.py','scripts/service-build-tools.requirements.lock','apps/desktop/src-tauri/Cargo.toml','apps/desktop/src-tauri/Cargo.lock','apps/desktop/src-tauri/build.rs','apps/desktop/src-tauri/build_support.rs','apps/desktop/src-tauri/src/service/runtime_descriptor.rs','apps/desktop/package.json','apps/desktop/src-tauri/tauri.conf.json'])
save('source-delta-selection.json',{'source_entries':len(source),'canonical_before_entries':len(root),'changed_or_added':delta,'selected_source':sorted(selected_source),'scope':'Selection from exact author1849 source compared with the captured canonical6d root only; no claim about current root.'})
def selected(name,size):
 if name.startswith('source/'):
  return name.removeprefix('source/') in selected_source
 if name.startswith('app-upfront/'):
  return name.endswith('/Contents/Info.plist') or name.endswith('/runtime/manifest.json')
 if name.startswith('dependency-inputs/'):return size<=262144
 return '/' not in name or name.startswith(('commands/','metadata/','retained-runtime-inputs/'))
class Reader:
 def __init__(self,file):self.file=file;self.digest=hashlib.sha256();self.bytes=0
 def read(self,size=-1):
  b=self.file.read(size);self.digest.update(b);self.bytes+=len(b);return b
archive_before=ARCHIVE.stat();allrows=[];kept=[];omitted=[];seen=set();case_seen=set();started=dt.datetime.now(dt.timezone.utc).isoformat()
with ARCHIVE.open('rb') as raw:
 reader=Reader(raw)
 with tarfile.open(fileobj=reader,mode='r|gz') as tar:
  for member in tar:
   name=member.name;p=pathlib.PurePosixPath(name)
   assert member.isfile() and name and not p.is_absolute() and '..' not in p.parts and '\\' not in name and '\0' not in name
   assert name not in seen and name.casefold() not in case_seen
   seen.add(name);case_seen.add(name.casefold());assert member.size<=2*1024*1024*1024
   keep=selected(name,member.size);digest=hashlib.sha256();count=0;target=None
   if keep:
    target=OUT/'selected'/pathlib.Path(*p.parts);target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();writer=target.open('xb')
   else:writer=None
   stream=tar.extractfile(member)
   try:
    while True:
     chunk=stream.read(1048576)
     if not chunk:break
     digest.update(chunk);count+=len(chunk)
     if writer is not None:writer.write(chunk)
   finally:
    if writer is not None:writer.close()
   assert count==member.size
   row={'path':name,'bytes':count,'mode':member.mode,'sha256':digest.hexdigest(),'archive_member_offset_uncompressed':member.offset_data,'author_physical_path':str(AUTHOR/name)}
   physical=AUTHOR/name;assert physical.is_file() and not physical.is_symlink() and physical.stat().st_size==count
   allrows.append(row)
   if keep:kept.append(row)
   else:omitted.append(row)
 while reader.read(1048576):pass
 assert reader.bytes==639628607 and reader.digest.hexdigest()==EXPECTED_SHA
archive_after=ARCHIVE.stat();key=lambda s:(s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
assert key(archive_before)==key(archive_after) and len(allrows)==4228
manifest=obj(OUT/'selected/proof-inputs.json');expected={x['path']:x for x in manifest['files']}
assert len(expected)==4227 and set(expected)|{'proof-inputs.json'}==set(seen)
for row in allrows:
 if row['path']=='proof-inputs.json':continue
 assert {k:row[k] for k in ['path','bytes','mode','sha256']}==expected[row['path']]
assert sha((OUT/'selected/proof-inputs.json').read_bytes())=='5cd7642ad7ed7ccb0e2d8c0855592de04f97ac9932820df65db3341792a34d85'
binding={'archive_path':str(ARCHIVE),'bytes':reader.bytes,'sha256':reader.digest.hexdigest(),'regular_members':len(allrows),'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'all4228_actual_member_bytes_sha_and_modes_checked':True,'physical_body_authority':'The original sealed physical archive, verified as exact compressed bytes and exhaustive member bodies. Original per-member loose paths were checked for existence/type/size only; their duplicate large bytes were not rehashed.','original_archive_untouched':True,'whole_dependency_cache_rehashed':False}
save('original-archive-binding.json',binding)
save('selected-member-map.json',{'original_archive':binding,'selected_count':len(kept),'selected_bytes':sum(x['bytes'] for x in kept),'members':kept})
save('omitted-members.json',{'original_archive':binding,'omitted_count':len(omitted),'omitted_bytes':sum(x['bytes'] for x in omitted),'members':omitted,'retrieval':'Read the exact named member from the bound original physical archive; no new CAS or duplicate author archive was created.'})
external=pathlib.Path(str(AUTHOR)+'-retained/archive-manifest.json').read_bytes();(OUT/'original-archive-manifest.json').write_bytes(external)
print(json.dumps({'original_archive_sha256':binding['sha256'],'original_regular_members':len(allrows),'selected_count':len(kept),'selected_bytes':sum(x['bytes'] for x in kept),'exhaustively_bound_omitted_count':len(omitted),'original_untouched':True},indent=2))
