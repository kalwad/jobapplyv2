"""Independent light source/data pass; no subject import or execution."""
import ast
import difflib
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
P = Path('/tmp/japp-m03-w04-real-owner-http-preparation-20261019')
S = P / 'source'
E = P / 'evidence/final-v6'
B = Path('/tmp/japp-m03-w04-owned-session-full-preparation-v3-20261019/source')
INPUTS = {}
HEAVY = {}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    raw = path.read_bytes()
    INPUTS[str(path)] = {'bytes': len(raw), 'sha256': sha(raw)}
    return raw

def data(path):
    return json.loads(read(path))

def check(value, reason):
    if not value:
        raise RuntimeError(reason)

def need(path, digest, size=None):
    HEAVY[str(Path(path).resolve())] = {'sha256': digest, 'bytes': size}

pins = {
    'HANDOFF.md': 'c47946294a4f613253f9296f2fd2eba6ac6daf133f4579c2e1b48c5b44a59948',
    'source-manifest.json': '5753a3801bf902c9707ce18fd6cbb0ddff9dd40592f1318f9a6f2fd169d37447',
    'outside-proof-only.patch': '8514df4a7ae97e0d5e3142e5cfbeb63eb0c7c47372f5de4d190bc5bc533d9c6b',
    'preservation.json': '99d9c87fc051b0b102773cb237fbedb86602e5bad6ad6545e9f79eab2664d2b6',
    'validation-summary.json': '648be7353b439b77dc27f84703532d9079640d7d8d1bba2526748113afe08bf6',
    'retention-manifest.json': 'd4db2d8ef66d57aeee5fb126270a4a686fce151803bffc2fce827da1ae834faf',
    'full-blob-recovery-map.json': '567b2fdcc4864df4c89aa6ebc9624f7e5144737eecce23bf45c2606e724e203e',
}
for name, digest in pins.items():
    check(sha(read(P / name)) == digest, 'selected pin ' + name)
source = data(P / 'source-manifest.json')
base = data(P / 'inputs/base-source-manifest.json')
check(sha(read(P / 'inputs/base-source-manifest.json')) == '516a011c151e44c69fe2fe545ab47353b5ade0234fbc334bb34e1d78fa4ea7b1', 'base source pin')
check(len(source) == 1850 and len(base) == 1848, 'source inventories')
delta = data(P / 'source-delta.json')
preserved = data(P / 'preservation.json')
modified = sorted(path for path in base if source[path] != base[path])
new = sorted(set(source) - set(base))
check(len(modified) == 4 and len(new) == 2 and sorted(row['path'] for row in delta) == sorted(modified + new), 'six-file delta')
check(len(base) - len(modified) == 1844 and all(source[path] == base[path] for path in base if path not in modified), '1844 unaffected named file bindings')

# Independent lexical function spans: comment/literal tokens do not count as braces.
tokens = re.compile(r'//[^\n]*|/\*.*?\*/|(?:br|r)(?P<h>\#*)".*?"(?P=h)|b?"(?:\\.|[^"\\])*"|b?\'(?:\\.|[^\'\\])\'|[{}]', re.S)
def fn_span(raw, name):
    text = raw.decode()
    match = re.search(r'\b(?:async\s+)?fn\s+' + re.escape(name) + r'\s*\(', text)
    check(match is not None, 'test function present')
    start = text.index('{', match.end())
    depth = 0
    for token in tokens.finditer(text, start):
        if token.group() == '{':
            depth += 1
        elif token.group() == '}':
            depth -= 1
            if depth == 0:
                return text[match.start():token.end()].encode()
    raise RuntimeError('function brace closure')

source_cache = {}
base_cache = {}
for row in preserved['all138_old_bodies']:
    path = row['path']
    source_cache.setdefault(path, read(S / path))
    base_cache.setdefault(path, read(B / path))
    old = fn_span(base_cache[path], row['id'].rsplit('::', 1)[-1])
    now = fn_span(source_cache[path], row['id'].rsplit('::', 1)[-1])
    check(old == now and len(old) == row['bytes'] and sha(old) == row['sha256'], '138 inherited function/assertion bytes')
check(len(preserved['all138_old_bodies']) == 138, 'old138 exact inventory')

blocks = {
 'apps/desktop/src-tauri/src/diagnostics/owner.rs': ['\n#[cfg(all(test, unix))]\n#[path = "tests/real_owner_http.rs"]\nmod real_owner_http_tests;\n'],
 'apps/desktop/src-tauri/src/service/tauri_lifecycle.rs': ['\n#[cfg(all(test, unix))]\n#[path = "proof/real_owner.rs"]\npub(crate) mod real_owner_proof;\n'],
 'apps/desktop/src-tauri/src/service/platform.rs': [
     '        #[cfg(test)]\n        super::super::tauri_lifecycle::real_owner_proof::spawned(child.id());\n',
     '        #[cfg(test)]\n        fn proof_pid(&self) -> Option<u32> {\n            Some(self.child.id())\n        }\n'],
 'apps/desktop/src-tauri/src/service/supervisor.rs': ['    #[cfg(all(test, unix))]\n    fn proof_pid(&self) -> Option<u32> {\n        None\n    }\n'],
}
patch = ''
for path in sorted(modified + new):
    raw = read(S / path)
    check(sha(raw) == source[path]['sha256'] and len(raw) == source[path]['bytes'], 'physical changed source')
    old = read(B / path) if path in base else b''
    patch += ''.join(difflib.unified_diff(old.decode().splitlines(keepends=True), raw.decode().splitlines(keepends=True),
        fromfile='a/' + path if path in base else '/dev/null', tofile='b/' + path))
    if path not in base:
        continue
    text = raw.decode()
    for block in blocks[path]:
        check(text.count(block) == 1, 'one explicit test island')
        text = text.replace(block, '')
    if path.endswith('service/supervisor.rs'):
        marker = '\n#[cfg(all(test, unix))]\nimpl<A: RuntimeAdapter, C: Clock> Supervisor<A, C> {'
        begin = text.index(marker)
        end = text.index('\n#[cfg(test)]\nmod tests {', begin)
        text = text[:begin] + text[end:]
    if path.endswith('service/platform.rs'):
        text = text.replace('    impl OwnedProcess for NativeChild {\n\n', '    impl OwnedProcess for NativeChild {\n')
    check(text.encode() == old, 'exact shipping source projection')
check(patch.encode() == read(P / 'outside-proof-only.patch'), 'exact patch reconstruction')
for path in (E / 'compiled-source').rglob('*.rs'):
    check(read(path) == read(S / path.relative_to(E / 'compiled-source')), 'final executed Rust source copies')

catalog = data(P / 'executed-command-catalog.json')
check(len(catalog) == 75, 'retained75 command catalog')
failures = []
final_commands = {}
for item in catalog:
    q = P / item['path']
    u = data(q / 'upfront.json')
    r = data(q / 'result.json')
    check(sha(read(q / 'upfront.json')) == item['upfront_sha256'] and sha(read(q / 'result.json')) == item['result_sha256'], 'catalog receipt hashes')
    check(item['argv'] == u['argv'] == r['argv'] and item['exit_code'] == r['exit_code'], 'actual argv and exit')
    check(r['watchdog'] is None and u['tool_sha256'] == r['tool_sha256_after'] and u['collector_sha256'] == r['collector_sha256_after'], 'command watchdog/tool/collector stability')
    for name in ['stdout', 'stderr']:
        check(sha(read(q / name)) == r[name + '_sha256'], 'actual raw hash binding')
    before = read(q / 'source-before.json')
    after = read(q / 'source-after.json')
    check(sha(before) == u['source_before_sha256'], 'upfront source manifest')
    if not r['source_unchanged']:
        check(q.name == '00-initial-format', 'only declared formatting mutates source')
    else:
        check(before == after, 'before/after bytes identical')
    check(data(q / 'owned-child.json')['direct_child_owned'], 'owned collector child')
    need(u['tool_image'], u['tool_sha256'])
    if item['exit_code']:
        failures.append(item['path'])
    if item['path'].startswith('evidence/final-v6/checks/'):
        check(json.loads(before) == source and before == after and r['exit_code'] == 0, 'final source all commands exact successful')
        final_commands[q.name] = {'upfront': u, 'result': r}
check(failures == ['evidence/checks/default-compile', 'evidence/final/checks/app-custom-compile', 'evidence/final-v4/checks/sdk-custom-compile', 'evidence/final-v5/checks/clippy-default'], 'full retained actual failure inventory')
check(len(final_commands) == 24, '24 final command records')
clippy_failed = read(P / failures[-1] / 'stderr').decode()
check('unnecessary use of `to_owned`' in clippy_failed and 'items after a test module' in clippy_failed and 'due to 2 previous errors' in clippy_failed, 'two harness style diagnostics retained')

old_ids = sorted(row['id'] for row in preserved['all138_old_bodies'])
all_cases = []
durations = {}
for mode, appfeatures, depcustom in [('default', ['default'], False), ('app-custom', ['custom-protocol', 'default'], True), ('sdk-custom', ['default'], True)]:
    artifacts = data(E / (mode + '-artifacts-upfront.json'))
    check(len(artifacts) == 2, 'two compiler-artifact executable targets')
    compile_stdout = read(E / 'checks' / (mode + '-compile') / 'stdout').decode()
    compiler_records = [json.loads(line) for line in compile_stdout.splitlines()]
    actual_artifacts = [r for r in compiler_records if r.get('reason') == 'compiler-artifact' and r.get('executable') and r.get('profile', {}).get('test')]
    check([a['compiler_artifact'] for a in artifacts] == actual_artifacts, 'exact JSON artifact discovery')
    tauri = [r for r in compiler_records if r.get('reason') == 'compiler-artifact' and r.get('target', {}).get('name') == 'tauri']
    check(len(tauri) == 1 and ('custom-protocol' in tauri[0]['features']) == depcustom, 'actual SDK custom feature compiled')
    ids = []
    actor_upfront = data(E / (mode + '-runtime-actors-upfront.json'))
    for i, a in enumerate(artifacts):
        check(a['compiler_artifact']['features'] == appfeatures and Path(a['compiler_artifact']['manifest_path']).resolve() == (S / 'apps/desktop/src-tauri/Cargo.toml').resolve(), 'app feature/source artifact binding')
        need(a['retained'], a['sha256'], a['bytes'])
        listing = E / 'checks' / f'{mode}-{i}-list'
        listed = [line[:-6] for line in read(listing / 'stdout').decode().splitlines() if line.endswith(': test')]
        ids.extend(listed)
        q = E / 'checks' / f'{mode}-{i}-actual-tests'
        u = final_commands[q.name]['upfront']
        r = final_commands[q.name]['result']
        check(u['argv'] == [a['retained'], '--test-threads=1', '--nocapture'] and u['tool_sha256'] == a['sha256'], 'exact retained binary executed')
        check(final_commands[listing.name]['upfront']['argv'] == [a['retained'], '--list'], 'same retained binary listed')
        raw = read(q / 'stdout').decode()
        passed = re.findall(r'^test (.+) \.\.\. ok$', raw, re.M)
        expected = 141 if a['compiler_artifact']['target']['kind'] == ['lib'] else 0
        check(len(passed) == expected and sorted(passed) == sorted(listed), 'actual same IDs list/pass')
        check(re.search(r'^test result: ok\. ' + str(expected) + r' passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', raw, re.M) is not None, 'ordinary actual native result')
        check(u['environment']['JAPP_OWNER_PROOF_RUNTIME'] == actor_upfront['environment']['JAPP_OWNER_PROOF_RUNTIME'] and u['environment']['JAPP_OWNER_PROOF_SHA256'] == 'fc2293a3d6425093c03ada543249ccdc2050038613cf984b3983aada18032c7c', 'current runtime actor environment')
        if expected:
            durations[mode] = r['elapsed_seconds']
            harness = data(q / 'owned-child.json')['pid']
            lib_u, lib_r = u, r
    check(len(ids) == len(set(ids)) == 141 and sorted(ids) == data(E / (mode + '-test-identities.json')), '141 full list')
    check(set(old_ids) < set(ids) and len(set(ids) - set(old_ids)) == 3, '138 preserved IDs plus3')
    events = [json.loads(line) for line in read(E / (mode + '-real-owner-ledger.jsonl')).splitlines()]
    check(len(events) == 27 and all(e['harness_pid'] == harness and e['nonce'] == lib_u['environment']['JAPP_OWNER_PROOF_NONCE'] for e in events), '27 nonce/owned-harness-bound events')
    expected_cases = {'real_owner_success', 'real_owner_quit', 'real_owner_death'}
    check({e['case'] for e in events} == expected_cases and all(e['event'] != 'unwind_cleanup' for e in events), 'three cases no unwind cleanup credit')
    for name in sorted(expected_cases):
        case = [e for e in events if e['case'] == name]
        mapping = {e['event']: e for e in case}
        check(len(case) == len(mapping) == 9 and case[0]['event'] == 'case_start' and case[-1]['event'] == 'case_pass' and [e['unix_ms'] for e in case] == sorted(e['unix_ms'] for e in case), 'finite ordered complete case')
        spawn, ack = mapping['spawn']['details'], mapping['ack_live_running']['details']
        check(spawn['child_pid'] == spawn['pgid'] == ack['child_pid'] == ack['pgid'] and spawn['executable_sha256'] == lib_u['environment']['JAPP_OWNER_PROOF_SHA256'], 'actual owned PID/group/current-runtime receipt')
        check(mapping['start_result']['details']['spawn_receipts'] == [spawn['child_pid']], 'one fresh owned child')
        shutdown = mapping['shutdown']['details']
        cleanup = mapping['cleanup_verified']['details']
        check(shutdown['result'] == 'Ok(())' and shutdown['child_retained'] is False and shutdown['elapsed_ms'] < 8000, 'explicit shutdown success')
        check(all(cleanup[k] for k in ['child_slot_released', 'group_absent', 'pid_absent', 'reader_completed_by_shutdown', 'rebound_owned_socket']) and cleanup['port'] == ack['port'], 'native cleanup and exact retired port rebind')
        check(mapping['stale_client_rejected']['details'] == {'failure': 'Disconnected', 'no_connection_observed_ms': 100}, 'stale client rejected finite no-connect observation')
        if name == 'real_owner_quit':
            observation = mapping['quit_while_owner_held']['details']
            check(observation['elapsed_ms'] < 100 and observation['issued_flag_revoked'] and observation['epoch_advanced'] and observation['engine_state'] == 'STOPPING', 'Quit revokes before contended owner')
        elif name == 'real_owner_death':
            observation = mapping['owned_death_revoked']['details']
            check(observation['unreaped_owner_retained'] and observation['issued_flag_revoked'] and observation['epoch_unchanged_until_close'] and observation['first_cause'] == 'ChildExited' and observation['engine_state'] == 'UNAVAILABLE', 'read-only death observation before actual cleanup')
        else:
            check(all(mapping['real_mock_ipc_ready']['details'].values()), 'cached Arc actual owner HTTP mock IPC closed DTO')
        all_cases.append({'mode': mode, 'case': name, 'harness_pid': harness, 'child_pid': spawn['child_pid'], 'port': ack['port'], 'start_to_pass_ms': case[-1]['unix_ms'] - case[0]['unix_ms'], 'explicit_cleanup': True, 'stale_client_no_connect_window_ms': 100})

preflight = data(P / 'evidence/runtime-preflight.json')
runtime_manifest = data(P / 'current-runtime/manifest.json')
check(sha(read(P / 'current-runtime/manifest.json')) == 'd274dcc7194722a4ec1549043543225d63bf48e5c6c8e55f4049eee4b5ceeea0' and len(preflight['runtime_files']) == 40, 'approved runtime manifest/tree count')
check(len(preflight['verified_declared_source_inputs']) == 135 and all(source[p] == row for p, row in preflight['verified_declared_source_inputs'].items()), '135 declared current source inputs exact')
for mode in ['default', 'app-custom', 'sdk-custom']:
    up = data(E / (mode + '-runtime-actors-upfront.json'))
    check(set(up['runtime']) == set(preflight['runtime_files']) and all(row == {k:v for k,v in preflight['runtime_files'][p].items() if k != 'mode'} for p,row in up['runtime'].items()), 'actor full40 runtime tree bound upfront')
    check(up['all_binary_artifacts'] == data(E / (mode + '-artifacts-upfront.json')), 'runtime actor upfront same artifacts')
for label in ['clippy-default', 'clippy-app-custom', 'clippy-sdk-custom', 'final-rustfmt']:
    check(label in final_commands and final_commands[label]['result']['exit_code'] == 0, 'strict statics all modes')

result = {'result': 'PASS_LIGHT_SOURCE_AND_RAW_DATA_PENDING_PHASE_CLEAR_HASHES',
    'created_utc': datetime.now(timezone.utc).isoformat(), 'subject_execution': False,
    'source_named_paths': 1850, 'base_paths': 1848, 'unaffected_named_bindings': 1844,
    'modified_test_only_existing_paths': modified, 'new_test_only_paths': new,
    'all138_bodies_assertions_byte_exact': True, 'production_projection_byte_exact': True,
    'patch_exact_reconstructed': True, 'retained_command_count': 75,
    'final_command_count': 24, 'retained_failed_commands': failures,
    'failure_scope': 'three compile setup failures from two owned-copy causes; one Clippy invocation with two new harness style errors; no product RED claim',
    'final_actual141_per_mode': True, 'actual_library_durations_seconds': durations,
    'actual_current_runtime_cases': all_cases, 'watchdog_or_unwind_PASS_credit': False,
    'runtime_manifest': 'd274dcc7194722a4ec1549043543225d63bf48e5c6c8e55f4049eee4b5ceeea0',
    'runtime_source_inputs_current': 135, 'runtime_files': 40,
    'remaining': 'Hash all retained physical blobs, selected safe archive, wheel RECORD/source members and deferred tool/dependency images after root phase clearance.'}
(OUT / 'light-results.json').write_text(json.dumps(result, indent=2) + '\n')
(OUT / 'light-input-hashes.json').write_text(json.dumps(INPUTS, indent=2, sort_keys=True) + '\n')
(OUT / 'deferred-hash-requests.json').write_text(json.dumps(HEAVY, indent=2, sort_keys=True) + '\n')
print(json.dumps({k:result[k] for k in ['result','all138_bodies_assertions_byte_exact','production_projection_byte_exact','retained_command_count','final_actual141_per_mode']}))
