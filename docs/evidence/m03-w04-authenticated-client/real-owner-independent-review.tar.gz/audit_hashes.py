"""Deferred physical/archive/wheel hash pass, run only after root phase clearance."""
import base64
import csv
import hashlib
import io
import json
import re
import stat
import tarfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

OUT = Path(__file__).resolve().parent
P = Path('/tmp/japp-m03-w04-real-owner-http-preparation-20261019')
S = P / 'source'
E = P / 'evidence/final-v6'
CACHE = {}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def check(value, reason):
    if not value:
        raise RuntimeError(reason)

def data(path):
    return json.loads(path.read_bytes())

def identity(path):
    path = Path(path).resolve(strict=True)
    key = str(path)
    if key not in CACHE:
        digest = hashlib.sha256()
        length = 0
        with path.open('rb') as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b''):
                digest.update(chunk)
                length += len(chunk)
        CACHE[key] = {'bytes': length, 'sha256': digest.hexdigest()}
    return CACHE[key]

def verify(path, row):
    check(not Path(path).is_symlink() and Path(path).is_file(), 'physical regular retained file')
    actual = identity(path)
    check(actual['sha256'] == row['sha256'] and (row.get('bytes') is None or actual['bytes'] == row['bytes']), 'physical blob bytes ' + str(path))

clear = data(OUT / 'phase-clear.json')
check(clear['permission'] == 'ROOT_EXPLICIT_HEAVY_HASH_PHASE_CLEAR', 'phase permission')
retention_path = P / 'retention-manifest.json'
check(identity(retention_path)['sha256'] == 'd4db2d8ef66d57aeee5fb126270a4a686fce151803bffc2fce827da1ae834faf', 'full retention pin')
retained = data(retention_path)
check(len(retained) == 2959, '2959 retained records')
for name, row in retained.items():
    path = PurePosixPath(name)
    check(not path.is_absolute() and '..' not in path.parts and '\\' not in name and Path(row['physical_path']).resolve() == (P / name).resolve(), 'safe physically bound path')
    verify(P / name, row)
check(identity(P / 'review-selection.tar.gz') == {'sha256': 'ac7d15d69536beaa197468f2b79b17b827ac5c35a3d1d1a40ffae0de679af09d', 'bytes': 17772110}, 'selected archive pin')
selection = data(P / 'review-selection-inventory.json')
recovery = data(P / 'full-blob-recovery-map.json')['records']
check(len(selection) == 936 and len(recovery) == 2020 and not set(selection) & set(recovery), 'selection/recovery disjoint inventory')
check(set(retained) == set(selection) | set(recovery) | {'review-selection.tar.gz', 'review-selection-inventory.json', 'archive-digest.json'}, 'full physical inventory partition')
for name, row in {**selection, **recovery}.items():
    check(row == retained[name], 'selection/recovery exact physical records')
archive_names = []
with tarfile.open(P / 'review-selection.tar.gz', 'r:gz') as archive:
    for member in archive:
        name = PurePosixPath(member.name)
        check(member.isfile() and not name.is_absolute() and '..' not in name.parts and member.name not in archive_names, 'safe regular unique archive members')
        archive_names.append(member.name)
        payload = archive.extractfile(member).read()
        row = retained[member.name]
        check(len(payload) == row['bytes'] and sha(payload) == row['sha256'], 'selected archive member bytes')
check(len(archive_names) == 937 and set(archive_names) == set(selection) | {'review-selection-inventory.json'}, 'exact937 selected members')

source = data(P / 'source-manifest.json')
declared_source_prefix = {name[len('source/'):] for name in retained if name.startswith('source/')}
omitted_named_source = sorted(set(source) - declared_source_prefix)
included_extra_source = sorted(declared_source_prefix - set(source))
check(len(omitted_named_source) == 55 and all(path.startswith('docs/') and path.endswith('/retention-manifest.json') for path in omitted_named_source), 'exact55 nested source-index omission')
check(len(included_extra_source) == 165, '165 included generated/ignored/pyc leaves')
for name, row in source.items():
    if 'source/' + name in retained:
        check({k:retained['source/' + name][k] for k in ['bytes','sha256']} == row, 'indexed named source binding')
    verify(S / name, row)
for path, row in data(OUT / 'deferred-hash-requests.json').items():
    verify(path, row)

preflight = data(P / 'evidence/runtime-preflight.json')
runtime = data(P / 'current-runtime/manifest.json')
expected = {row['path']: {'bytes':row['bytes'],'sha256':row['sha256']} for row in runtime['files']}
check(len(expected) == 39, '39 manifest payload members')
expected['manifest.json'] = identity(P / 'current-runtime/manifest.json')
check(set(expected) == set(preflight['runtime_files']), 'exact40 runtime tree')
for name, row in expected.items():
    check({k:preflight['runtime_files'][name][k] for k in ['bytes','sha256']} == row, 'runtime declaration actual bytes')
    verify(P / 'current-runtime' / name, row)
entry = P / 'current-runtime' / runtime['entrypoint']
check(identity(entry)['sha256'] == 'fc2293a3d6425093c03ada543249ccdc2050038613cf984b3983aada18032c7c' and bool(entry.stat().st_mode & 0o111), 'approved executable entry')
wheel_counts = {}
for name, record in preflight['wheel_checks'].items():
    verify(P / 'wheels' / name, record)
    prefix = record['source_prefix']
    mapped = {}
    with zipfile.ZipFile(P / 'wheels' / name) as wheel:
        names = wheel.namelist()
        check(len(names) == len(set(names)) and all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and '\\' not in n for n in names), 'safe unique wheel members')
        records = [n for n in names if n.endswith('.dist-info/RECORD')]
        check(len(records) == 1, 'one wheel RECORD')
        entries = list(csv.reader(io.StringIO(wheel.read(records[0]).decode())))
        check(len(entries) == len(names) and {row[0] for row in entries} == set(names), 'whole wheel RECORD closure')
        for member, encoded, size in entries:
            payload = wheel.read(member)
            if encoded:
                check(encoded == 'sha256=' + base64.urlsafe_b64encode(hashlib.sha256(payload).digest()).decode().rstrip('=') and int(size) == len(payload), 'wheel RECORD actual bytes')
            else:
                check(member == records[0] and not size, 'only RECORD self unpinned')
            if member.endswith('.py'):
                check(payload == (S / prefix / member).read_bytes(), 'every package Python source byte exact')
                mapped[member] = {'source': prefix + member, 'sha256': sha(payload)}
        check(mapped == record['exact_source_members'], 'wheel source mappings exact')
        check(set(mapped) == {path[len(prefix):] for path in preflight['verified_declared_source_inputs'] if path.startswith(prefix) and path.endswith('.py')}, 'whole declared Python member closure')
        wheel_counts[name] = {'all_RECORD_members_verified': len(names), 'Python_source_members': len(mapped), 'sha256': record['sha256']}
check(sorted(v['Python_source_members'] for v in wheel_counts.values()) == [9,109], 'corrected actual Python member counts')
build_lock = S / 'scripts/service-build-tools.requirements.lock'
check(identity(build_lock)['sha256'] == runtime['source_inputs']['build_requirements_sha256'], 'exact pinned build lock source')
original_runtime_commands = data(P / 'inputs/runtime-original-commands.json')
original_runtime_argv = next(row['argv'] for row in original_runtime_commands if row['label'] == 'runtime-build')
generated_requirements = Path(original_runtime_argv[original_runtime_argv.index('--runtime-requirements') + 1])
check(identity(generated_requirements)['sha256'] == runtime['source_inputs']['runtime_requirements_sha256'], 'original generated requirements input pin; not a named canonical source file')

# Verify the recorded owned compile inputs and dependency image once, without running them.
compile_inputs = data(E / 'compile-inputs-upfront.json')
for root, key in [(S / 'apps/desktop/src-tauri/runtime-payload','old_runtime_compile_only'), (S / 'apps/desktop/dist','frontend_compile_only'), (S / '.venv','owned_venv')]:
    for name, row in compile_inputs[key].items():
        verify(root / name, row)
check(compile_inputs['old_runtime_compile_only'] == compile_inputs['current_runtime'], 'compile payload and actor payload identical bytes despite separate use')
check(identity(compile_inputs['python_resolved'])['sha256'] == compile_inputs['python_sha256'], 'recorded compile Python interpreter')

# The pre-Clippy successful source/cases remain separate, and changed assertions are not credited.
prefinal = P / 'evidence/final-v5'
case_path = 'apps/desktop/src-tauri/src/diagnostics/tests/real_owner_http.rs'
before = (prefinal / 'compiled-source' / case_path).read_text()
after = (S / case_path).read_text()
for name in re.findall(r'^fn (real_managed_owner_\w+)\(', after, re.M):
    prefix = 'fn ' + name
    start_old, start_new = before.index(prefix), after.index(prefix)
    next_old = before.find('\n#[test]', start_old)
    next_new = after.find('\n#[test]', start_new)
    check(before[start_old:next_old if next_old != -1 else len(before)] == after[start_new:next_new if next_new != -1 else len(after)], 'new3 test bodies/assertions unchanged by harness style correction')
for mode in ['default','app-custom','sdk-custom']:
    cases = list((prefinal / 'checks').glob(mode + '-*-actual-tests/stdout'))
    check(len(cases) == 2 and sum(len(re.findall(r'^test .+ \.\.\. ok$', p.read_text(), re.M)) for p in cases) == 141, 'prefinal141 actual GREEN retained all3 modes')

result = {'result':'PASS_FULL_PHYSICAL_ARCHIVE_RUNTIME_WHEEL_BINDING',
    'created_utc':datetime.now(timezone.utc).isoformat(), 'phase_clear':clear,
    'all_retained_records':2959, 'all_source_named_files':1850,
    'selected_archive_sha256':'ac7d15d69536beaa197468f2b79b17b827ac5c35a3d1d1a40ffae0de679af09d',
    'selected_archive_bytes':17772110, 'safe_regular_selected_members':937,
    'selected_input_records':936, 'omitted_physically_retained_records':2020,
    'original_full_blob_recovery_map_exact_for_its2020_records':True,
    'original_full_index_omitted_named_source':omitted_named_source,
    'original_full_index_included_extra_source':included_extra_source,
    'runtime_files_verified':40,
    'runtime135_declared_source_bindings_verified':True, 'wheel_RECORD_source_checks':wheel_counts,
    'compile_only_runtime_and_actor_runtime_identical40_bytes':True,
    'owned_compile_venv_regular_files_verified':len(compile_inputs['owned_venv']),
    'prefinal141_all3_modes_and_new3_assertions_preserved':True,
    'hash_unique_paths':len(CACHE), 'hash_unique_path_bytes':sum(row['bytes'] for row in CACHE.values()),
    'subject_import_or_execution':False,
    'limits':['Selected archive omits2020 full blobs; recovery requires retained physical paths. No durable CAS upload claimed.', 'Ignored dependency/compiler caches are not part of2959 retained set; recorded compile inputs were checked where physically present.', 'No canonical adoption, new Wry/background/event/GUI, pending-body real-owner cancellation, W05, Windows/Linux or platform acceptance.']}
(OUT / 'hash-results.json').write_text(json.dumps(result,indent=2)+'\n')
(OUT / 'physical-hash-index.json').write_text(json.dumps(CACHE,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:result[k] for k in ['result','all_retained_records','safe_regular_selected_members','runtime_files_verified','hash_unique_path_bytes']}))
