"""Additive retention and narrow current-tooling applicability binding only."""
import hashlib
import json
import stat
import tarfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

O = Path(__file__).resolve().parent
P = Path('/tmp/japp-m03-w04-real-owner-http-preparation-20261019')
D = Path('/Users/tanishkalwad/jobapplyv2-evidence/m03-w04-real-owner-http-20261019')
A = Path('/tmp/japp-m03-w04-real-owner-http-retained-20261019')
J = Path('/tmp/japp-m03-w04-current-tooling-join-20261019')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def load(path):
    return json.loads(path.read_bytes())

def check(value, reason):
    if not value:
        raise RuntimeError(reason)

pins = {
 'source-index-supplement.json': '8cfde1280845f69a4275b98b958ed4933a0b758d6495f40f1c42a4f9630161dc',
 'path-bindings.json': 'b6e4dab6e3cd07eddd247b8cb787f627a99084f3505c584f6255608ae54995fc',
 'durable-full-recovery-map.json': '6b4ee5ae5c7bf3e55bf4ef1f55bfbc6e515d71338de1aa3960edebba3363296e',
 'remote-omissions.json': '78faf76d38a79d74023a09f114e83ef9afc4c5eb86d376b3a821321201954526',
 'retention-manifest.json': '585920a0503cd3443bde685d6320810c4b64d6bfd7d5bbbdf99bcd202b138773',
 'HANDOFF.md': '01f4598ddb822b1e21530b87f8af58f2a60964d5ec0fbd1f9c5398952b41be7a',
}
for name, digest in pins.items():
    check(sha((D / name).read_bytes()) == digest, 'new durable control pin')
check((D / 'original-retention-manifest.json').read_bytes() == (P / 'retention-manifest.json').read_bytes(), 'original2959 index preserved verbatim')
original = load(P / 'retention-manifest.json')
source = load(P / 'source-manifest.json')
declared_source = {name[len('source/'):] for name in original if name.startswith('source/')}
missing = sorted(set(source) - declared_source)
extra = sorted(declared_source - set(source))
supp = load(D / 'source-index-supplement.json')
check(supp['exact_source_index_minus_full_index'] == missing and supp['supplement_count'] == len(missing) == 55 and supp['union_count'] == 3014, 'exact supplement set/count')
check(supp['already_declared_ignored_generated_pyc_paths'] == ['source/' + name for name in extra] and len(extra) == 165, 'explicit included165 generated/ignored/pyc leaves')
supp_rows = {row['relative']:row for row in supp['records']}
expected = {name:{k:row[k] for k in ['bytes','sha256']} for name,row in original.items()}
for name in missing:
    row = supp_rows['source/' + name]
    check({k:row[k] for k in ['bytes','sha256']} == source[name], '55 exact authoritative source bindings')
    expected['source/' + name] = source[name]
check(len(expected) == 3014, 'union3014')
bindings = load(D / 'path-bindings.json')['records']
recovery = load(D / 'durable-full-recovery-map.json')['records']
by_name = {row['relative']:row for row in bindings}
check(len(bindings) == len(by_name) == len(recovery) == 3014 and set(by_name) == set(expected) == set(recovery), 'complete durable union path closure')
unique = {}
for name, row in by_name.items():
    check({k:row[k] for k in ['bytes','sha256']} == expected[name], 'durable original/supplement bytes')
    check(Path(row['original_physical_path']).resolve() == (P / name).resolve(), 'original physical identity binding')
    check(row['original_mode'] == stat.S_IMODE((P / name).stat().st_mode), 'original captured modes remain unchanged')
    check(row['durable_relative'] == 'blobs/' + row['sha256'] and Path(row['durable_full_path']).resolve() == (D / row['durable_relative']).resolve(), 'content-addressed recovery binding')
    check(row['index_origin'] == ('original-2959-full-index' if name in original else 'separately-authorized-55-source-index-supplement'), 'honest original vs additive origin')
    target = D / row['durable_relative']
    if row['sha256'] not in unique:
        check(target.is_file() and not target.is_symlink(), 'physical regular CAS body')
        payload = target.read_bytes()
        check(len(payload) == row['bytes'] and sha(payload) == row['sha256'] and stat.S_IMODE(target.stat().st_mode) == 0o444, 'complete durable payload actual bytes and readonly mode')
        unique[row['sha256']] = row['bytes']
    record = recovery[name]
    check(all(record[k] == row[k] for k in ['bytes','sha256','original_mode','durable_relative','durable_full_path']), 'complete recovery record')
check(stat.S_IMODE(D.stat().st_mode) == 0o555, 'sealed durable directory')
retained = load(D / 'retention-manifest.json')['files']
check(len(retained) == len({row['path'] for row in retained}) == 2256, 'new exhaustive durable index')
for row in retained:
    target = D / row['path']
    payload = target.read_bytes()
    check(len(payload) == row['bytes'] and sha(payload) == row['sha256'] and stat.S_IMODE(target.stat().st_mode) == row['mode'], 'new durable controls/payload index bytes')

selected = A / 'real-owner-http-selected.tar.gz'
check(selected.stat().st_size == 2846894 and sha(selected.read_bytes()) == '030da6298a66b6faf79832f27b179bf0faf4686e53ed16b7dc51c7cec91481b1', 'new selected archive pin')
manifest_path = A / 'real-owner-http-selected.manifest.json'
check(sha(manifest_path.read_bytes()) == '75b368319b50d90f72103e4ada9a6c73add55331a8537ec662cfbf12b049bb01', 'new selected exhaustive manifest pin')
selected_manifest = load(manifest_path)
selected_rows = {row['path']:row for row in selected_manifest['members']}
seen = set()
with tarfile.open(selected, 'r:gz') as archive:
    for member in archive:
        path = PurePosixPath(member.name)
        check(member.isfile() and not path.is_absolute() and '..' not in path.parts and path.parts[0] == D.name, 'safe regular new selected archive')
        name = '/'.join(path.parts[1:])
        check(name not in seen and name in selected_rows, 'unique new selected member closure')
        seen.add(name)
        payload = archive.extractfile(member).read()
        row = selected_rows[name]
        check(len(payload) == row['bytes'] and sha(payload) == row['sha256'] and payload == (D / name).read_bytes(), 'every new selected member exact durable bytes')
check(len(seen) == 424 and seen == set(selected_rows), 'all424 selected members')
omissions = load(D / 'remote-omissions.json')
omitted = {row['relative']:row for row in omissions['omitted_records']}
check(len(omitted) == 1998 and set(omitted) == {name for name,row in by_name.items() if not row['remote_included_by_content']}, 'exact remote omission disclosure')
check(all(row == by_name[name] for name,row in omitted.items()), 'every omitted body fully mapped durable')

# Narrow current-tooling source applicability join. No current-root or actor access.
join_manifest_path = J / 'source-manifest.json'
check(sha(join_manifest_path.read_bytes()) == 'b79acf135fcd53da216363dfa50f30af376315fab3504696a697fe08490a66d0', 'current1849 join pin')
joined = load(join_manifest_path)
base = load(P / 'inputs/base-source-manifest.json')
tooling = {'.github/workflows/ci.yml','scripts/python-test-inventory.v1.json','scripts/tests/test_status_scan_streaming.py','scripts/validate_status.py'}
changed = {path for path in set(base) | set(joined) if base.get(path) != joined.get(path)}
check(len(joined) == 1849 and changed == tooling, 'only four tooling changes current join')
check(all(joined[path] == row for path,row in base.items() if path not in tooling), 'all1845 inherited non-tooling bindings exact')
preflight = load(P / 'evidence/runtime-preflight.json')
actual_paths = set(preflight['verified_declared_source_inputs'])
actual_paths |= {path for path in base if path.startswith('apps/desktop/') and (path.endswith('.rs') or path.endswith('Cargo.toml') or path.endswith('Cargo.lock') or path.endswith('tauri.conf.json'))}
actual_paths |= tooling
for path in actual_paths:
    payload = (J / 'source' / path).read_bytes()
    check(len(payload) == joined[path]['bytes'] and sha(payload) == joined[path]['sha256'], 'physical current join code/runtime/tooling bytes')
check(all(joined[path] == row for path,row in preflight['verified_declared_source_inputs'].items()), 'current join same135 runtime inputs')
preserved = load(P / 'preservation.json')
check(all(joined[row['path']] == base[row['path']] for row in preserved['all138_old_bodies']), 'current join same files for all138 inherited test bodies')
check(all(joined[row['path']]['sha256'] == row['production_projection_sha256'] for row in preserved['modified_existing_files']), 'current join exact shipping projection of proof islands')
check(all(path not in joined for path in preserved['test_only_new_files']), 'outside harness two files not current join')

result = {'result':'PASS_ADDITIVE_RETENTION_AND_NARROW_CURRENT_JOIN_BINDING',
 'created_utc':datetime.now(timezone.utc).isoformat(),
 'original2959_index_unchanged':True, 'supplement_exact55':True, 'complete_union3014':True,
 'all1850_named_source_physically_durable':True, 'included_generated_ignored_pyc_leaves':165,
 'complete_durable_unique_bodies':len(unique), 'unique_durable_body_bytes':sum(unique.values()),
 'durable_control_pins':pins, 'durable_exhaustive_index_records':2256,
 'new_selected_archive':{'sha256':'030da6298a66b6faf79832f27b179bf0faf4686e53ed16b7dc51c7cec91481b1','bytes':2846894,'safe_regular_members':424,'exhaustive_manifest_sha256':'75b368319b50d90f72103e4ada9a6c73add55331a8537ec662cfbf12b049bb01'},
 'remote_omitted_leaf_bindings':1998, 'all_omissions_exact_physical_durable_CAS':True,
 'current_join':{'source_manifest_sha256':'b79acf135fcd53da216363dfa50f30af376315fab3504696a697fe08490a66d0','named_files':1849,'only_tooling_delta':sorted(tooling),'every_other1845_binding_exact':True,'physical_key_paths_checked':len(actual_paths),'runtime135_inputs_exact':True,'proof_shipping_projection_exact':True,'all138_inherited_test_files_exact':True,'outside2new_files_not_joined':True},
 'subject_execution_or_current_root_access':False,
 'limits':['Retention correction only; no source reconstruction, original index rewrite or new execution credit.', 'Selected424 archive is not complete; all3014 named bindings require physically durable CAS for omitted bodies.', 'No Wry/background/request_shutdown/Close/Exit/nativeGUI/W05/platform/hostedCI/canonical-adoption credit; current join is static applicability only.']}
(O / 'supplement-join-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['result','complete_union3014','all1850_named_source_physically_durable','complete_durable_unique_bodies']}))
