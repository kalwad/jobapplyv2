"""Bounded documentary audit. Never launches product, test, browser or compiler actors."""
import datetime as dt,hashlib,json,os,pathlib,re,stat,subprocess
OUT=pathlib.Path('/tmp/japp-m03-w04-current-tooling-command-independent-review-20261019')
FULL=pathlib.Path('/tmp/japp-m03-w04-current-tooling-full-preparation-20261019')
RETRY=pathlib.Path('/tmp/japp-m03-w04-current-tooling-native-retry-20261019')
JOIN=pathlib.Path('/tmp/japp-m03-w04-current-tooling-join-20261019')
SOURCE=FULL/'source'
def sha(b):return hashlib.sha256(b).hexdigest()
def data(p):
 before=p.stat();raw=p.read_bytes();after=p.stat()
 assert (before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns),str(p)
 return raw
def obj(p):return json.loads(data(p))
def save(p,value):
 assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2)+'\n')
def digest(p):
 raw=data(p);return {'bytes':len(raw),'sha256':sha(raw)}
retained=[]
for label,base in [('full',FULL),('retry',RETRY)]:
 for p in sorted(base.iterdir()):
  if not p.is_file():continue
  assert not p.is_symlink()
  raw=data(p);target=OUT/'inputs'/label/p.name
  target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();target.write_bytes(raw)
  retained.append({'original':str(p),'retained':str(target.relative_to(OUT)),'bytes':len(raw),'sha256':sha(raw)})
for p,label in [(pathlib.Path(str(FULL)+'.outer.log'),'original-outer.log'),(JOIN/'composition.json','join-composition.json'),(JOIN/'source-manifest.json','join-source-manifest.json')]:
 raw=data(p);target=OUT/'inputs'/label;assert not target.exists();target.write_bytes(raw)
 retained.append({'original':str(p),'retained':str(target.relative_to(OUT)),'bytes':len(raw),'sha256':sha(raw)})
save(OUT/'retained-inputs.json',retained)
f=lambda n:obj(OUT/'inputs/full'/n)
r=lambda n:obj(OUT/'inputs/retry'/n)
source_manifest=f('source-manifest.json');assert len(source_manifest)==1849 and source_manifest==r('source-manifest.json')==obj(JOIN/'source-manifest.json')
assert sha(data(FULL/'source-manifest.json'))==obj(JOIN/'composition.json')['source1849_manifest_sha256']
observed={n:digest(SOURCE/n) for n in source_manifest};assert observed==source_manifest
save(OUT/'actual-source-1849.json',{'observed_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'files':observed,'all_equal':True})
git_records=[]
def git(args,label):
 argv=['git',*args];started=dt.datetime.now(dt.timezone.utc).isoformat()
 p=subprocess.run(argv,cwd=SOURCE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
 for suffix,raw in [('stdout',p.stdout),('stderr',p.stderr)]: (OUT/(label+'.'+suffix)).write_bytes(raw)
 rec={'argv':argv,'cwd':str(SOURCE),'started_utc':started,'exit_code':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr),'scope':'Read-only Git source metadata; no status/index mutation or actors.'}
 save(OUT/(label+'.json'),rec);git_records.append(rec);assert p.returncode==0
 return p.stdout
tree=git(['ls-tree','-rz','--full-tree','HEAD'],'logical-checkout-tree')
git_rows={}
for item in tree.split(b'\0'):
 if not item:continue
 meta,name=item.split(b'\t');mode,kind,oid=meta.decode().split();name=name.decode();assert kind=='blob';raw=data(SOURCE/name)
 assert hashlib.sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest()==oid
 git_rows[name]={'mode':mode,'git_blob_sha':oid}
assert set(git_rows)==set(source_manifest)
commit=git(['cat-file','-p','HEAD'],'logical-checkout-commit').decode()
isolated=f('isolated-git-input.json');assert commit.startswith('tree '+isolated['tree']+'\nparent 6d3a6b8ccde5b75e12248ae7bbefc473b72922e4\n')
assert data(FULL/'git-commit-tree.stdout').decode().strip()==isolated['source_snapshot_commit']
assert data(FULL/'git-write-tree.stdout').decode().strip()==isolated['tree']
root0=f('root-before.json');root1=r('root-before.json');root2=r('root-after.json')
assert len(root0)==1798 and root1==root2 and root0==root1['files'] and root1['status']=='' and root1['head']=='6d3a6b8ccde5b75e12248ae7bbefc473b72922e4'
assert r('failed-full-poststate.json')['root1798_unchanged'] and r('retry-result.json')['root1798_unchanged']
oldbindings=r('original-failure-bindings.json')
for name,entry in oldbindings.items():
 original=pathlib.Path(name) if name.startswith('/') else FULL/name
 copied=RETRY/('original-outer.log' if name.startswith('/') else 'original-'+name)
 assert digest(original)==entry==digest(copied)
for base,receipt,stem in [(FULL,f('doctor-result.json'),'doctor'),(FULL,f('canonical-aggregate-result.json'),'canonical-aggregate'),(RETRY,r('retry-result.json'),'rust')]:
 assert sha(data(base/(stem+'.stdout')))==receipt['stdout_sha256'] and sha(data(base/(stem+'.stderr')))==receipt['stderr_sha256']
assert f('doctor-result.json')['exit_code']==0 and f('canonical-aggregate-result.json')['exit_code']==1 and r('retry-result.json')['exit_code']==0
assert f('canonical-aggregate-result.json')['source_unchanged'] and r('retry-result.json')['source1849_unchanged']
assert not (FULL/'closure.json').exists() and f('wrapper-failure.json')['closure_claim'] is False
for p in FULL.glob('*-result.json'):
 receipt=obj(p);assert receipt['source_unchanged'] and receipt['executable_sha256_before']==receipt['executable_sha256_after']
 assert digest(pathlib.Path(receipt['executable']))['sha256']==receipt['executable_sha256_after']
 if p.name!='canonical-aggregate-result.json':assert receipt['exit_code']==0
reanchors=f('owned-environment-reanchors.json')
for name,entry in reanchors.items():
 raw=data(SOURCE/name)
 if 'after_sha256' in entry:
  assert sha(raw)==entry['after_sha256'] and raw.partition(b'\n')[0].decode()==entry['after_shebang']
  original=entry['before_shebang'].encode()+b'\n'+raw.partition(b'\n')[2]
  assert sha(original)==entry['before_sha256']
 else:assert raw.decode()==entry['after'] and sha(raw)==entry['sha256']
assert digest(SOURCE/'.venv/bin/python')['sha256']==isolated['interpreter_sha256_before']
fullenv=f('canonical-aggregate-upfront.json')['environment'];retryenv=r('retry-upfront.json')['environment']
assert retryenv=={**fullenv,'CARGO_BUILD_JOBS':'2'}
assert r('retry-upfront.json')['argv']==['pnpm','verify','--suite','rust'] and f('canonical-aggregate-upfront.json')['argv']==['pnpm','verify']
runtime=f('compile-runtime-upfront.json');correction=r('owned-ignored-runtime-mode-correction.json')
assert len(runtime['manifest'])==39 and len(correction['before'])==len(correction['changes'])==78
runtime_roots=[SOURCE/'apps/desktop/src-tauri/runtime-payload',FULL/'cargo-target/debug/runtime']
for base in runtime_roots:
 for name,entry in runtime['manifest'].items():assert digest(base/name)==entry
assert all(digest(pathlib.Path(runtime['source'])/n)==v for n,v in runtime['manifest'].items())
for change in correction['changes']:
 p=pathlib.Path(change['path']);assert any(p.is_relative_to(base) for base in runtime_roots)
 assert not p.is_symlink() and not (p.is_relative_to(SOURCE) and p.relative_to(SOURCE).as_posix() in source_manifest)
 before=correction['before'][str(p)];assert change['before_mode']==before['mode']=='0o444' and change['after_mode']=='0o644'
 assert int(change['before_mode'],8)|0o200==int(change['after_mode'],8) and (p.stat().st_mode&0o777)==0o644
 assert digest(p)=={'bytes':before['bytes'],'sha256':before['sha256']} and change['sha256_unchanged']==before['sha256']
assert f('owned-copied-cache-write-modes.json')['entries']=={}
log=data(FULL/'canonical-aggregate.stdout').decode();retry=data(RETRY/'rust.stdout').decode();doctor=data(FULL/'doctor.stdout').decode()
ansi=re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]');log=ansi.sub('',log);retry=ansi.sub('',retry)
def rows(text):
 tail=text.rsplit('== verification summary ==',1)[1]
 return [{'suite':m[0],'state':m[1],'result':m[2]} for m in re.findall(r'^([\w-]+)\s+(ACTIVE|NOT_YET_APPLICABLE|REQUIRED_MISSING)\s+(PASS|FAIL)\b',tail,re.M)]
suite_rows=rows(log);retry_rows=rows(retry);assert len(suite_rows)==20 and all(x['state']=='ACTIVE' for x in suite_rows)
assert [(x['suite'],x['result']) for x in suite_rows if x['result']!='PASS']==[('rust','FAIL')]
assert retry_rows==[{'suite':'rust','state':'ACTIVE','result':'PASS'}]
assert 'verification exit code: 1' in log and 'verification exit code: 0' in retry
unit=re.findall(r'^(@[^\s]+):test:\s+Tests\s+(\d+) passed \((\d+)\)\s*$',log,re.M)
assert len(unit)==15 and all(a==b for _,a,b in unit) and sum(int(a) for _,a,_ in unit)==3990
python_footer=re.findall(r'^=+ (\d+) passed in ([\d.]+)s \([^\n]+\) =+\s*$',log,re.M)
assert python_footer==[('1679','379.30')]
browser=re.findall(r'^\s+(\d+) passed \(([^\n]+)\)\s*$',log,re.M)
assert [int(x[0]) for x in browser]==[262,2,62,3]
assert 'summary: 28 pass, 0 warning, 0 fail, 0 not-yet-applicable' in doctor
native_results=re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([\d.]+)s$',retry,re.M)
assert [int(x[0]) for x in native_results]==[1,10,138,0,0,138,0,0,138,0,0] and all(x[1:5]==('0','0','0','0') for x in native_results)
registry=obj(SOURCE/'scripts/verification-suites.json');assert len(registry['suites'])==20 and registry['allowed_skips']==[]
rust=next(s for s in registry['suites'] if s['id']=='rust');assert len(rust['commands'])==15
retry_headers=re.findall(r'^\$ (.+)$',retry,re.M);expected_rust=[' '.join(c) for c in rust['commands']]
assert [h for h in retry_headers if h in expected_rust]==expected_rust
extras=[h for h in retry_headers if h not in expected_rust]
assert extras==['vite build --config vite.desktop.config.ts']
assert len(retry_headers)==16
rust_start=log.index('$ '+expected_rust[0],log.index('1679 passed in'))
rust_end=log.index('$ python3 scripts/check_portability.py',rust_start)
original_rust=log[rust_start:rust_end]
assert 'error: failed to run custom build command for `japp-desktop' in original_rust and 'Desktop command policy could not be built: Permission denied (os error 13)' in original_rust
assert [h for h in re.findall(r'^\$ (.+)$',original_rust,re.M) if h in expected_rust]==expected_rust[:12]
assert 'test result: ok. 138 passed;' not in original_rust
allheaders=re.findall(r'^\$ (.+)$',log,re.M)
coverage=[]
for suite in registry['suites']:
 for command in suite['commands']:
  expected=' '.join(command);where=retry_headers if suite['id']=='rust' else allheaders
  found=[h for h in where if h==expected or h in [expected+' --reporter=default',expected+' -- --reporter=default']]
  kind='exact_or_canonical_default_reporter'
  if command==['uv','run','pytest']:
   found=[h for h in where if h.startswith('uv run pytest ') and '--collect-only' not in h];kind='canonical_python_explicit_inventory'
  assert found,(suite['id'],command)
  coverage.append({'suite':suite['id'],'registry_argv':command,'actual_matching_headers':found,'matching_scope':kind,'evidence':'retry' if suite['id']=='rust' else 'original_aggregate'})
save(OUT/'registry-command-coverage.json',{'commands':coverage,'rust_registry_count':15,'rust_all_header_count':16,'rust_extra_headers':extras,'scope':'Complementary recorded coverage; original aggregate remains FAIL. Child exit0 inferred from immutable stop-on-nonzero sequence and suite PASS, not invented direct child exit records.'})
selected=['scripts/verification-suites.json','scripts/verify.py','package.json','pnpm-lock.yaml','uv.lock','apps/desktop/package.json','apps/desktop/src-tauri/Cargo.toml','apps/desktop/src-tauri/Cargo.lock','apps/desktop/src-tauri/build.rs','apps/desktop/src-tauri/src/lib.rs','apps/desktop/src-tauri/src/service/runtime_descriptor.rs','apps/desktop/src-tauri/src/service/platform/native.rs','services/native-host/Cargo.toml','packages/contracts/test/contract/rust-harness/Cargo.toml']
selected_retained=[]
for name in selected:
 if name not in source_manifest:continue
 raw=data(SOURCE/name);target=OUT/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 selected_retained.append({'path':name,**digest(target),'logical_git':git_rows[name]})
save(OUT/'selected-source-manifest.json',selected_retained)
result={'result':'PASS_WITH_ORIGINAL_AGGREGATE_FAILURE_PRESERVED','review_scope':'Bounded independent documentary audit only. No actors, compilers, reruns, installs, root/source/original-proof writes or whole-cache image audit.','original_aggregate':{'exit_code':1,'active_suites':20,'passed_suites':19,'failed_suite':'rust','native_failure':'Default desktop cargo test exits101 in build script PermissionDenied before desktop test body; 12/15 Rust registry commands attempted.'},'focused_retry':{'exit_code':0,'active_suites':1,'passed_suites':1,'rust_registry_commands':15,'actual_dollar_headers':16,'extra_nested_build_header':extras[0],'native_desktop_modes':[138,138,138],'other_native_tests':[1,10],'all_zero_failed_ignored_measured_filtered':True},'observed_counts':{'doctor_pass':28,'unit_ts_workspaces':15,'unit_ts_passed':3990,'python_passed':1679,'default_browser_passed':262,'controlled_scope_passed':2,'controlled_contact_passed':62,'visual_passed':3},'source':{'logical_files':1849,'all_current_bytes_equal_recorded_manifest':True,'isolated_commit':isolated['source_snapshot_commit'],'isolated_tree':isolated['tree'],'canonical_parent':'6d3a6b8ccde5b75e12248ae7bbefc473b72922e4','actual_git_blobs_equal_all_manifest_files':True},'neutrality':{'root_before_after_recorded1798_equality':True,'root_head':'6d3a6b8ccde5b75e12248ae7bbefc473b72922e4','retry_logical_git_status':r('retry-result.json')['logical_git_status'],'old_frozen_raw_bindings_checked':len(oldbindings),'original_full_closure_absent':True},'operational_correction':{'owned_ignored_runtime_paths':78,'mode_before':'0444','mode_after':'0644','owner_write_bit_only':True,'all78_current_bytes_match_before':True,'two39_file_copies_match_compile_input':True,'donor39_compile_bytes_match_recorded':True,'reanchored_venv_paths_checked':len(reanchors),'retry_environment_delta':{'CARGO_BUILD_JOBS':'2'},'whole_cache_images_checked':False},'limitations':['Complementary command coverage is not one successful all20 aggregate.','Old compile-only payload is not a newly bundled current service runtime or app/GUI acceptance.','No ambient process/environment, full dependency cache or platform certification claim.','No test, assertion, source, product guard, command, bound or donor mutation was performed by the reviewer.']}
save(OUT/'review.json',result)
print(json.dumps(result,indent=2))
