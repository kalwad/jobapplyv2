import hashlib,json,pathlib,re
ROOT=pathlib.Path('/tmp/japp-m03-w04-current-tooling-command-independent-review-20261019')
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
checked=[]
for folder in [ROOT/'attempt3/inputs/full',ROOT/'attempt3/inputs/retry']:
 for receipt_path in sorted(folder.glob('*-result.json')):
  receipt=load(receipt_path)
  stem=receipt_path.name.removesuffix('-result.json')
  if stem.startswith('original-'):continue
  if stem=='retry':stem='rust'
  for stream in ['stdout','stderr']:
   path=folder/(stem+'.'+stream)
   assert sha(path.read_bytes())==receipt[stream+'_sha256']
  checked.append({'path':str(receipt_path.relative_to(ROOT)),'exit_code':receipt['exit_code']})
log=(ROOT/'attempt3/inputs/full/canonical-aggregate.stdout').read_text()
ansi=re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]');log=ansi.sub('',log)
start=log.index('$ pnpm exec turbo run build --force\n');end=log.index('$ pnpm exec playwright test\n',start)
block=log[start:end]
assert 'Tasks:    3 successful, 3 total' in block and 'Cached:    0 cached, 3 total' in block
for name in ['desktop','extension','mock-ats-lab']:assert f'@japp/{name}:build: cache bypass, force executing ' in block
lines=log.splitlines()
excerpts=[]
for number,line in enumerate(lines,1):
 if line.startswith(' Tasks:') or line.startswith('Cached:') or 'Tasks:    3 successful' in line or 'Cached:    0 cached, 3 total' in line or line.startswith('summary:') or re.match(r'^(@\S+):test:\s+Tests\s+\d+ passed',line) or re.match(r'^\s+\d+ passed \(',line) or re.match(r'^=+ 1679 passed in ',line) or 'Permission denied (os error 13)' in line:
  excerpts.append({'line':number,'text':line})
frozen=[]
for entry in load(ROOT/'attempt3/retained-inputs.json'):
 original=pathlib.Path(entry['original']);raw=original.read_bytes()
 assert len(raw)==entry['bytes'] and sha(raw)==entry['sha256']
 assert (ROOT/'attempt3'/entry['retained']).read_bytes()==raw
 frozen.append(entry['original'])
value={'result':'PASS','all_preparation_and_retry_receipt_streams_hash_checked':checked,'forced_frontend_builds':['desktop','extension','mock-ats-lab'],'build_tasks_successful':3,'build_cached':0,'actual_source_log_line_excerpts':excerpts,'all_retained_originals_remain_byte_equal_after_review':len(frozen),'reviewer_analysis_failures_retained':['audit-operation.json','audit-operation-0002.json'],'analysis_corrections_only':['Compile-input manifest has 40 files including tracked .gitignore; 79 before observations and 78 owner-write-bit corrections.','Python canonical quality commands insert explicit pyproject config arguments in the source runner.'],'no_product_rerun':True}
target=ROOT/'supplemental-final-check.json';assert not target.exists();target.write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps({'result':'PASS','receipt_count':len(checked),'unchanged_original_files':len(frozen),'forced_builds':3,'analysis_failures_preserved':2},indent=2))
