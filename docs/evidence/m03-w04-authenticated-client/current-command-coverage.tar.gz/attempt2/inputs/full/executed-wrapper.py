"""Whole canonical doctor/aggregate campaign in an isolated reviewed W04 source snapshot; outside preparation only."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import time
import traceback

B=Path('/tmp/japp-m03-w04-current-tooling-full-preparation-20261019').resolve()
F=Path('/tmp/japp-m03-w04-current-tooling-join-20261019').resolve()
N=Path('/tmp/japp-m03-w04-owned-session-full-preparation-v3-20261019').resolve()
ROOT=Path('/Users/tanishkalwad/jobapplyv2')
D=Path('/tmp/japp-m03-w04-owned-session-app-build-v2-20261019/source')
S=B/'source'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1048576),b''):h.update(c)
 return h.hexdigest()
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def now():return datetime.now(timezone.utc).isoformat()
def inv(p,names):return {n:{'bytes':(p/n).stat().st_size,'sha256':sha(p/n)} for n in sorted(names)}
def rootstate():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='6d3a6b8ccde5b75e12248ae7bbefc473b72922e4'
 assert subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=ROOT,text=True)==''
 ns=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().rstrip('\0').split('\0');assert len(ns)==1798
 return inv(ROOT,ns)
B.mkdir(exist_ok=False);shutil.copy2(__file__,B/'executed-wrapper.py')
write(B/'campaign-scope.json',{'purpose':'OUTSIDE W04 source1849 join of reviewed516a and current6d3 CI tooling; no root adoption, currentroot full, GUI or CI credit','upstream_full_review':'/tmp/japp-m03-w04-independent-full-preparation-review-20261019/REVIEW.md','source_join':'/tmp/japp-m03-w04-current-tooling-join-20261019/composition.json'})
rows=json.loads((F/'source-manifest.json').read_text());assert len(rows)==1849
join=json.loads((F/'composition.json').read_text());assert sha(F/'source-manifest.json')==join['source1849_manifest_sha256']
shutil.copy2(F/'source-manifest.json',B/'source-manifest.json')
before=rootstate();write(B/'root-before.json',before)
assert inv(F/'source',rows)==rows
for n in rows:
 p=S/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(F/'source'/n,p);p.chmod(p.stat().st_mode | 0o200)
assert inv(S,rows)==rows
env={k:os.environ[k] for k in ['HOME','USER','LOGNAME','TMPDIR','LANG','LC_ALL','CARGO_HOME','RUSTUP_HOME'] if k in os.environ}
env.update(PATH=str(S/'.venv/bin')+':/opt/homebrew/opt/node@24/bin:'+os.environ['PATH'],UV_OFFLINE='true',CARGO_NET_OFFLINE='true',CARGO_TARGET_DIR=str(B/'cargo-target'),PYTHONPATH=os.pathsep.join(str(S/n) for n in ['services/orchestrator/src','packages/contracts/generated/python/src','scripts']),GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_SYSTEM='/dev/null')
records=[]
def run(label,argv,cwd,timeout=300,input_bytes=None):
 exe=Path(shutil.which(argv[0],path=env['PATH']) or argv[0]).resolve(strict=True)
 rec={'argv':argv,'cwd':str(cwd),'environment':env,'started_utc':now(),'timeout_seconds':timeout,'executable':str(exe),'executable_sha256_before':sha(exe),'source_manifest_sha256':sha(B/'source-manifest.json'),'scope':'OUTSIDE W04 DOCTOR/AGGREGATE PREPARATION ONLY; NOT ROOT/GUI/PLATFORM/PACKAGE ACCEPTANCE'}
 write(B/(label+'-upfront.json'),rec);clock=time.monotonic()
 with (B/(label+'.stdout')).open('xb') as out,(B/(label+'.stderr')).open('xb') as err:
  p=subprocess.run(argv,cwd=cwd,env=env,input=input_bytes,stdout=out,stderr=err,timeout=timeout,check=False)
 rec.update(exit_code=p.returncode,seconds=time.monotonic()-clock,ended_utc=now(),executable_sha256_after=sha(exe),stdout_sha256=sha(B/(label+'.stdout')),stderr_sha256=sha(B/(label+'.stderr')),source_unchanged=inv(S,rows)==rows)
 write(B/(label+'-result.json'),rec);records.append(rec)
 print(json.dumps({'label':label,'exit_code':p.returncode,'seconds':rec['seconds']}),flush=True)
 assert rec['source_unchanged'] and rec['executable_sha256_before']==rec['executable_sha256_after']
 assert p.returncode==0,label
 return (B/(label+'.stdout')).read_text().strip()
def clone(label,src,dst):
 assert src.is_dir() and not src.is_symlink() and not dst.exists(),(src,dst)
 dst.parent.mkdir(parents=True,exist_ok=True);run(label,['/bin/cp','-cR',str(src),str(dst)],B)
try:
 clone('venv-copy',N/'source/.venv',S/'.venv')
 # Every copied editable path and entrypoint points into this owned clone.
 changes={}
 for p in sorted((S/'.venv/bin').iterdir()):
  if p.is_symlink() or not p.is_file():continue
  raw=p.read_bytes()
  if not raw.startswith(b'#!'):continue
  first,sep,rest=raw.partition(b'\n')
  if b'/bin/python' not in first:continue
  new=b'#!'+str(S/'.venv/bin/python').encode()+sep+rest
  if new!=raw:
   changes[p.relative_to(S).as_posix()]={'before_sha256':hashlib.sha256(raw).hexdigest(),'after_sha256':hashlib.sha256(new).hexdigest(),'before_shebang':first.decode(),'after_shebang':new.partition(b'\n')[0].decode()}
   p.write_bytes(new)
 for pkg,rel in [('japp_contracts','packages/contracts/generated/python/src'),('orchestrator','services/orchestrator/src')]:
  p=S/'.venv/lib/python3.12/site-packages'/f'_editable_impl_{pkg}.pth';old=p.read_text();p.write_text(str(S/rel));changes[p.relative_to(S).as_posix()]={'before':old,'after':p.read_text(),'sha256':sha(p)}
 write(B/'owned-environment-reanchors.json',changes)
 clone('cargo-copy',N/'cargo-target',B/'cargo-target')
 # Correct only inherited read-only modes inside this newly owned copied cache.
 cache_modes={}
 for entry in sorted((B/'cargo-target').rglob('*')):
  if entry.is_symlink() or not entry.is_file():continue
  mode=entry.stat().st_mode & 0o777
  if mode & 0o200:continue
  digest=sha(entry);entry.chmod(mode|0o200);assert sha(entry)==digest
  cache_modes[entry.relative_to(B/'cargo-target').as_posix()]={'before_mode':oct(mode),'after_mode':oct(mode|0o200),'sha256_unchanged':digest}
 write(B/'owned-copied-cache-write-modes.json',{'scope':'Only own COW Cargo copy; donor untouched; no source/guard/bound changes; not a full dependency image','entries':cache_modes})
 runtime=N/'source/apps/desktop/src-tauri/runtime-payload'
 if runtime.is_dir():
  runtime_names=[p.relative_to(runtime).as_posix() for p in sorted(runtime.rglob('*')) if p.is_file()]
  runtime_before=inv(runtime,runtime_names);write(B/'compile-runtime-upfront.json',{'source':str(runtime),'manifest':runtime_before,'scope':'UNCHANGED OLD PAYLOAD ONLY COMPILE INPUT; NO CURRENT BUNDLED RUNTIME CREDIT'})
  for name in runtime_names:
   dst=S/'apps/desktop/src-tauri/runtime-payload'/name;src=runtime/name
   if dst.exists(): assert sha(dst)==sha(src),name
   else: dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
  assert inv(runtime,runtime_names)==runtime_before and inv(S/'apps/desktop/src-tauri/runtime-payload',runtime_names)==runtime_before
 count=0
 for parent in sorted({Path(n).parent.as_posix() for n in rows if Path(n).name=='package.json'}):
  for folder in ['node_modules','dist']:
   src=D/parent/folder
   if src.is_dir():
    count+=1;clone(f'frontend-input-{count:02}',src,S/parent/folder)
 # A private Git index/objects directory permits exact historical fixtures without root writes.
 empty=B/'empty-git-template';empty.mkdir()
 run('git-init',['git','init','--quiet','--template='+str(empty),'--initial-branch=codex/w04-full-preparation',str(S)],B)
 objects=subprocess.check_output(['git','rev-parse','--path-format=absolute','--git-path','objects'],cwd=ROOT,text=True).strip()
 (S/'.git/objects/info/alternates').write_text(objects+'\n')
 paths=B/'logical-paths.nul';paths.write_bytes(b'\0'.join(n.encode() for n in sorted(rows))+b'\0')
 run('git-add',['git','add','--force','--pathspec-from-file='+str(paths),'--pathspec-file-nul'],S)
 tree=run('git-write-tree',['git','write-tree'],S)
 commit=run('git-commit-tree',['git','-c','user.name=Preparation','-c','user.email=evidence@example.invalid','commit-tree',tree,'-p','6d3a6b8ccde5b75e12248ae7bbefc473b72922e4'],S,input_bytes=b'Temporary source snapshot for isolated W04 full preparation only\n')
 run('git-head',['git','update-ref','refs/heads/codex/w04-full-preparation',commit],S)
 assert subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=S,text=True)==''
 write(B/'isolated-git-input.json',{'source_snapshot_commit':commit,'tree':tree,'parent':'6d3a6b8ccde5b75e12248ae7bbefc473b72922e4','read_only_alternate_objects':objects,'own_index_objects_refs':str(S/'.git'),'canonical_project_commit':False,'interpreter_sha256_before':sha(S/'.venv/bin/python')})
 run('owned-locked-sync',['uv','sync','--locked','--offline'],S,300)
 run('doctor',['pnpm','run','doctor'],S,300)
 run('canonical-aggregate',['pnpm','verify'],S,2400)
 assert inv(S,rows)==rows and inv(F/'source',rows)==rows
 after=rootstate();write(B/'root-after.json',after);assert before==after
 assert subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=S,text=True)==''
 write(B/'closure.json',{'scope':'ACTUAL OUTSIDE CURRENT W04 DOCTOR/CANONICAL AGGREGATE PREPARATION ONLY','doctor_and_aggregate_exit0':True,'source1849_unchanged':True,'root1798_unchanged':True,'frozen1849_unchanged':True,'isolated_git_clean':True,'actual_native_gui':False,'hosted_ci':False,'root_full20':False,'milestone_acceptance':False,'commands':records})
 print('CLOSED outside W04 doctor/aggregate0; inspect exact20 outcomes and1679Python before preparation credit; no root/package acceptance',flush=True)
except BaseException as e:
 write(B/'wrapper-failure.json',{'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc(),'closure_claim':False,'utc':now()});raise
