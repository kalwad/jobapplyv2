"""Preserve failed aggregate; repair only owned ignored build-input modes; retry Rust."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import subprocess
import time

B = Path('/tmp/japp-m03-w04-current-tooling-native-retry-20261019')
OLD = Path('/tmp/japp-m03-w04-current-tooling-full-preparation-20261019')
S = OLD / 'source'
ROOT = Path('/Users/tanishkalwad/jobapplyv2')

def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for data in iter(lambda: f.read(1048576), b''):
            h.update(data)
    return h.hexdigest()

def write(name, obj):
    with (B / name).open('x') as f:
        json.dump(obj, f, indent=2)
        f.write('\n')

def inv(base, names):
    return {n: {'bytes': (base / n).stat().st_size, 'sha256': sha(base / n)} for n in sorted(names)}

def rootstate():
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    status = subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=ROOT, text=True)
    assert head == '6d3a6b8ccde5b75e12248ae7bbefc473b72922e4' and not status
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().rstrip('\0').split('\0')
    assert len(names) == 1798
    return {'head': head, 'status': status, 'files': inv(ROOT, names)}

B.mkdir(exist_ok=False)
shutil.copy2(__file__, B / 'executed-wrapper.py')
rows = json.loads((OLD / 'source-manifest.json').read_text())
assert len(rows) == 1849 and inv(S, rows) == rows
shutil.copy2(OLD / 'source-manifest.json', B / 'source-manifest.json')
before = rootstate()
write('root-before.json', before)
write('failed-full-poststate.json', {'source1849_unchanged': True, 'root1798_unchanged': inv(ROOT, json.loads((OLD / 'root-before.json').read_text())) == json.loads((OLD / 'root-before.json').read_text()), 'first_aggregate_exit': 1, 'first_aggregate_rust': 'FAIL before test body: Tauri build resource copy PermissionDenied; 19 other ACTIVE suites PASS; no aggregate PASS claim'})
frozen = {}
for name in ['campaign-scope.json', 'canonical-aggregate-result.json', 'canonical-aggregate-upfront.json', 'canonical-aggregate.stdout', 'canonical-aggregate.stderr', 'doctor-result.json', 'doctor-upfront.json', 'doctor.stdout', 'doctor.stderr', 'wrapper-failure.json', 'executed-wrapper.py', 'compile-runtime-upfront.json', 'owned-copied-cache-write-modes.json']:
    shutil.copy2(OLD / name, B / ('original-' + name))
    frozen[name] = {'sha256': sha(OLD / name), 'bytes': (OLD / name).stat().st_size}
outer = Path(str(OLD) + '.outer.log')
shutil.copy2(outer, B / 'original-outer.log')
frozen[str(outer)] = {'sha256': sha(outer), 'bytes': outer.stat().st_size}
write('original-failure-bindings.json', frozen)

# Tauri fs::copy preserves a copied source's read-only permissions. A previous
# retention operation made this compile-only donor read-only. The first build
# copies those modes into target/debug/runtime; the next copy cannot overwrite.
# Only this already-owned ignored stage and generated output receive u+w.
mode_changes = []
runtime_before = {}
for base in [S / 'apps/desktop/src-tauri/runtime-payload', OLD / 'cargo-target/debug/runtime']:
    for p in sorted(base.rglob('*')):
        assert not p.is_symlink(), str(p)
        if not p.is_file():
            continue
        rel = p.relative_to(S).as_posix() if p.is_relative_to(S) else None
        if rel in rows:
            continue
        digest = sha(p)
        mode = p.stat().st_mode & 0o777
        runtime_before[str(p)] = {'sha256': digest, 'bytes': p.stat().st_size, 'mode': oct(mode)}
        if not mode & 0o200:
            p.chmod(mode | 0o200)
            assert sha(p) == digest
            mode_changes.append({'path': str(p), 'before_mode': oct(mode), 'after_mode': oct(mode | 0o200), 'sha256_unchanged': digest})
assert len(mode_changes) == 78, len(mode_changes)
assert inv(S, rows) == rows
write('owned-ignored-runtime-mode-correction.json', {'scope': 'Only owned ignored compile runtime and generated Cargo runtime output; no logical source, donor, content, execute-bit, runtime guard or test changes; no app/service launch', 'before': runtime_before, 'changes': mode_changes, 'diagnosis': 'Tauri 2.7.3 copy_resources -> copy_file -> std::fs::copy preserves source permissions; initial allfeatures Clippy copied39 mode444 leaves; next default build could not overwrite. No permission-file claim.'})
receipt = json.loads((OLD / 'canonical-aggregate-upfront.json').read_text())
env = receipt['environment']
env['CARGO_BUILD_JOBS'] = '2'
argv = ['pnpm', 'verify', '--suite', 'rust']
exe = Path(shutil.which('pnpm', path=env['PATH'])).resolve(strict=True)
write('retry-upfront.json', {'argv': argv, 'cwd': str(S), 'environment': env, 'executable': str(exe), 'executable_sha256': sha(exe), 'source_manifest_sha256': sha(B / 'source-manifest.json'), 'started_utc': datetime.now(timezone.utc).isoformat(), 'timeout_seconds': 1200, 'scope': 'Focused complete canonical Rust suite; original full FAIL remains; no new overall aggregate/root/GUI/CI acceptance claim'})
start = time.monotonic()
with (B / 'rust.stdout').open('xb') as out, (B / 'rust.stderr').open('xb') as err:
    p = subprocess.run(argv, cwd=S, env=env, stdout=out, stderr=err, timeout=1200, check=False)
assert inv(S, rows) == rows
after = rootstate()
write('root-after.json', after)
assert before == after
write('retry-result.json', {'exit_code': p.returncode, 'seconds': time.monotonic() - start, 'ended_utc': datetime.now(timezone.utc).isoformat(), 'source1849_unchanged': True, 'root1798_unchanged': True, 'stdout_sha256': sha(B / 'rust.stdout'), 'stderr_sha256': sha(B / 'rust.stderr'), 'logical_git_status': subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=S, text=True), 'original_aggregate_exit': 1})
print(json.dumps({'exit_code': p.returncode, 'seconds': time.monotonic() - start}), flush=True)
raise SystemExit(p.returncode)
