import datetime as dt,hashlib,json,pathlib,subprocess,time
OUT=pathlib.Path('/tmp/japp-m03-w04-current-tooling-command-independent-review-20261019')
argv=['python3',str(OUT/'audit.py')];started=dt.datetime.now(dt.timezone.utc).isoformat();tick=time.monotonic()
number=len(list(OUT.glob('audit-operation*.json')))+1
p=subprocess.run(argv,cwd=OUT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
row={'argv':argv,'cwd':str(OUT),'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-tick,'exit_code':p.returncode,'scope':'Finite documentary review only; no product/test/compiler actors.'}
for name,raw in [('stdout',p.stdout),('stderr',p.stderr)]:
 target=OUT/(f'audit-operation-{number:04d}.'+name);assert not target.exists();target.write_bytes(raw)
 row[name]={'path':target.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
target=OUT/f'audit-operation-{number:04d}.json';assert not target.exists();target.write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(row,indent=2));print(p.stdout.decode(errors='replace')[:14000]);print(p.stderr.decode(errors='replace')[:14000]);raise SystemExit(p.returncode)
