from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import subprocess
import time

R = Path('/Users/tanishkalwad/jobapplyv2')
B = Path('/tmp/japp-m03-w04-canonical-adoption-20261019/focused')
B.mkdir(exist_ok=False)
shutil.copy2(__file__, B / 'executed-wrapper.py')
names = sorted(set(subprocess.check_output(['git', 'ls-files', '-z'], cwd=R).decode().rstrip('\0').split('\0')) | set(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=R).decode().rstrip('\0').split('\0')))
names = [n for n in names if n]
assert len(names) == 1873, len(names)
def sha(p):
    return hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
def inventory():
    return {n: {'bytes': (R/n).stat().st_size, 'sha256': sha(R/n)} for n in names}
def write(n,v):
    with (B/n).open('x') as f:
        json.dump(v,f,indent=2)
        f.write('\n')
before = inventory()
write('source-before.json',before)
env = {k: os.environ[k] for k in ['HOME','USER','LOGNAME','TMPDIR','LANG','LC_ALL','RUSTUP_HOME','CARGO_HOME'] if k in os.environ}
env.update(PATH='/opt/homebrew/opt/node@24/bin:'+os.environ['PATH'], CARGO_NET_OFFLINE='true', UV_OFFLINE='true', CARGO_BUILD_JOBS='2', COREPACK_ENABLE_NETWORK='0')
commands = [
 ('frozen-node', ['pnpm','install','--frozen-lockfile','--offline'],300),
 ('locked-python', ['uv','sync','--locked','--offline'],300),
 ('format', ['pnpm','verify','--suite','format'],300),
 ('typecheck', ['pnpm','verify','--suite','typecheck'],300),
 ('desktop-unit', ['pnpm','--filter','@japp/desktop','test'],300),
 ('contract-unit', ['pnpm','--filter','@japp/contracts','test'],300),
 ('service-python', ['uv','run','pytest','services/orchestrator/tests','-q'],300),
 ('native', ['pnpm','verify','--suite','rust'],1200),
]
results=[]
for label,argv,timeout in commands:
    exe=Path(shutil.which(argv[0],path=env['PATH'])).resolve(strict=True)
    rec={'argv':argv,'cwd':str(R),'environment':dict(env),'started_utc':datetime.now(timezone.utc).isoformat(),'executable':str(exe),'executable_sha256_before':sha(exe),'source_manifest_sha256':sha(B/'source-before.json'),'timeout_seconds':timeout,'scope':'Current-root focused W04 checks; not full aggregate/GUI/hosted/milestone acceptance'}
    write(label+'-upfront.json',rec)
    start=time.monotonic()
    with (B/(label+'.stdout')).open('xb') as out,(B/(label+'.stderr')).open('xb') as err:
        p=subprocess.run(argv,cwd=R,env=env,stdout=out,stderr=err,timeout=timeout,check=False)
    rec.update(exit_code=p.returncode,seconds=time.monotonic()-start,ended_utc=datetime.now(timezone.utc).isoformat(),executable_sha256_after=sha(exe),stdout_sha256=sha(B/(label+'.stdout')),stderr_sha256=sha(B/(label+'.stderr')),source_unchanged=inventory()==before)
    write(label+'-result.json',rec)
    results.append(rec)
    print(json.dumps({'label':label,'exit_code':p.returncode,'seconds':rec['seconds']}),flush=True)
    assert rec['source_unchanged'] and rec['executable_sha256_before']==rec['executable_sha256_after']
    if p.returncode:
        write('failure.json',{'label':label,'exit_code':p.returncode,'commands':results,'no_full_claim':True})
        raise SystemExit(p.returncode)
write('source-after.json',inventory())
write('closure.json',{'commands':results,'source1873_unchanged':True,'full_aggregate':False,'native_gui':False,'hosted_ci':False})
