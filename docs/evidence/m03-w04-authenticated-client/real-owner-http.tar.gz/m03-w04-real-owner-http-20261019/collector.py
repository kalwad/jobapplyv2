"""Outside archival collector; no project/helper imports or actor execution."""
from pathlib import Path, PurePosixPath
import datetime
import gzip
import hashlib
import json
import os
import shutil
import stat
import tarfile
import traceback

SOURCE = Path('/tmp/japp-m03-w04-real-owner-http-preparation-20261019')
OUT = Path('/tmp/japp-m03-w04-real-owner-http-retained-20261019')
STORE = Path('/Users/tanishkalwad/jobapplyv2-evidence/m03-w04-real-owner-http-20261019')
PREFIX = 'm03-w04-real-owner-http-20261019'
EXPECTED = {
    'HANDOFF.md': 'c47946294a4f613253f9296f2fd2eba6ac6daf133f4579c2e1b48c5b44a59948',
    'retention-manifest.json': 'd4db2d8ef66d57aeee5fb126270a4a686fce151803bffc2fce827da1ae834faf',
    'review-selection.tar.gz': 'ac7d15d69536beaa197468f2b79b17b827ac5c35a3d1d1a40ffae0de679af09d',
    'full-blob-recovery-map.json': '567b2fdcc4864df4c89aa6ebc9624f7e5144737eecce23bf45c2606e724e203e',
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def dump(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')

def safe(name):
    path = PurePosixPath(name)
    assert name and not path.is_absolute() and '..' not in path.parts and '\\' not in name, name
    return path

def main():
    # Explicit parent release is required before any payload hashing or copying.
    release = json.loads((OUT / 'phase-release.json').read_text())
    assert release['root_explicit_phase_clear'] is True
    supplement_authorization = json.loads((OUT / 'supplement-authorization.json').read_text())
    assert supplement_authorization['root_explicit_additive55_approved'] is True
    assert not STORE.exists(), str(STORE)
    for name, expected in EXPECTED.items():
        assert digest(SOURCE / name) == expected, name
    declared = json.loads((SOURCE / 'retention-manifest.json').read_text())
    original_selection = json.loads((SOURCE / 'review-selection-inventory.json').read_text())
    original_recovery = json.loads((SOURCE / 'full-blob-recovery-map.json').read_text())['records']
    source_index = json.loads((SOURCE / 'source-manifest.json').read_text())
    assert len(declared) == 2959 and len(original_selection) == 936 and len(original_recovery) == 2020 and len(source_index) == 1850
    assert declared['review-selection.tar.gz']['bytes'] == 17772110
    assert set(original_selection).isdisjoint(original_recovery)
    assert set(declared) - set(original_selection) - set(original_recovery) == {'archive-digest.json', 'review-selection-inventory.json', 'review-selection.tar.gz'}
    assert 'retention-manifest.json' not in declared
    assert sum(row['bytes'] for row in declared.values()) == 920554948
    frozen_root = SOURCE.resolve()
    for name, row in declared.items():
        safe(name)
        assert Path(row['physical_path']).resolve() == frozen_root / name
    supplement_names = sorted(name for name in source_index if 'source/' + name not in declared)
    assert len(supplement_names) == 55
    assert all(name.endswith('/retention-manifest.json') for name in supplement_names)
    supplement = {'source/' + name: {**source_index[name], 'physical_path': str(frozen_root / 'source' / name)} for name in supplement_names}
    combined = {**declared, **supplement}
    assert len(combined) == 3014
    ignored_generated = sorted(name for name in declared if name.startswith('source/') and name[7:] not in source_index)
    assert len(ignored_generated) == 165
    STORE.mkdir()
    (STORE / 'blobs').mkdir()
    remote_hashes = {row['sha256'] for row in original_selection.values()}
    remote_hashes.add(declared['review-selection-inventory.json']['sha256'])
    remote_hashes.add(declared['archive-digest.json']['sha256'])
    # Keep the original opaque archive fully durable, but omit it remotely.
    assert EXPECTED['review-selection.tar.gz'] not in remote_hashes
    bindings = []
    upfront = []
    for number, (name, expected) in enumerate(sorted(combined.items()), 1):
        original = Path(expected['physical_path'])
        assert original.resolve() == frozen_root / name
        info = original.lstat()
        assert stat.S_ISREG(info.st_mode), name
        actual = digest(original)
        assert actual == expected['sha256'] and info.st_size == expected['bytes'], name
        blob = STORE / 'blobs' / actual
        if not blob.exists():
            # Fresh owned regular file; no hardlink or donor permission change.
            shutil.copyfile(original, blob)
            assert not os.path.samefile(original, blob)
            assert digest(blob) == actual
        else:
            assert blob.stat().st_size == info.st_size
            assert not os.path.samefile(original, blob)
        record = {'relative': name, 'original_physical_path': str(original), 'bytes': info.st_size, 'sha256': actual, 'original_mode': stat.S_IMODE(info.st_mode), 'original_mode_octal': oct(stat.S_IMODE(info.st_mode)), 'durable_relative': 'blobs/' + actual, 'durable_full_path': str(blob), 'index_origin': 'original-2959-full-index' if name in declared else 'separately-authorized-55-source-index-supplement', 'remote_included_by_content': actual in remote_hashes, 'originally_selected': name in original_selection, 'originally_in_full_blob_recovery': name in original_recovery}
        bindings.append(record)
        upfront.append({'relative': name, 'bytes': info.st_size, 'sha256': actual, 'mode': stat.S_IMODE(info.st_mode)})
        if number % 500 == 0:
            print(json.dumps({'physical_leaves_copied_and_bound': number, 'primary_index': 2959, 'source_index_supplement': 55, 'union_total': 3014}), flush=True)
    by_name = {row['relative']: row for row in bindings}
    for name, expected in original_selection.items():
        actual = by_name[name]
        assert actual['sha256'] == expected['sha256'] and actual['bytes'] == expected['bytes']
    for name, expected in original_recovery.items():
        actual = by_name[name]
        assert actual['sha256'] == expected['sha256'] and actual['bytes'] == expected['bytes']
        assert actual['original_physical_path'] == expected['physical_path']
    for name, expected in source_index.items():
        actual = by_name['source/' + name]
        assert actual['sha256'] == expected['sha256'] and actual['bytes'] == expected['bytes']
    # Read and verify every member of the original selected archive as data.
    old_members = []
    old_expected = {**original_selection, 'review-selection-inventory.json': declared['review-selection-inventory.json']}
    longest = sorted(old_expected, key=len, reverse=True)
    seen = set()
    with tarfile.open(SOURCE / 'review-selection.tar.gz', 'r:gz') as archive:
        assert len(archive.getmembers()) == 937
        for member in archive.getmembers():
            safe(member.name)
            assert member.isfile() and not member.issym() and not member.islnk()
            relative = member.name if member.name in old_expected else next((name for name in longest if member.name.endswith('/' + name)), None)
            assert relative is not None and relative not in seen, member.name
            seen.add(relative)
            stream = archive.extractfile(member)
            assert stream is not None
            data = stream.read()
            expected = old_expected[relative]
            assert len(data) == expected['bytes'] and sha(data) == expected['sha256'], member.name
            old_members.append({'member': member.name, 'relative': relative, 'bytes': len(data), 'sha256': sha(data), 'mode': member.mode, 'durable_blob': by_name[relative]['durable_relative']})
    assert seen == set(old_expected)
    copied_manifest = STORE / 'original-retention-manifest.json'
    shutil.copyfile(SOURCE / 'retention-manifest.json', copied_manifest)
    assert digest(copied_manifest) == EXPECTED['retention-manifest.json']
    omitted = [row for row in bindings if not row['remote_included_by_content']]
    unique_primary = {row['sha256']: row['bytes'] for row in bindings if row['relative'] in declared}
    assert len(unique_primary) == 2194 and sum(unique_primary.values()) == 737505118
    unique = {row['sha256']: row['bytes'] for row in bindings}
    dump(STORE / 'path-bindings.json', {'scope': 'ORIGINAL_2959_UNCHANGED_PLUS_EXPLICIT_SOURCE_INDEX_55_SUPPLEMENT_3014_UNION_NOT_A_FULL_BUILD_ENVIRONMENT_IMAGE', 'records': bindings})
    dump(STORE / 'source-index-supplement.json', {'scope': 'SEPARATELY_AUTHORIZED_RETENTION_COMPLETENESS_ONLY_NO_NEW_EXECUTION_OR_SOURCE_IMAGE_CREDIT', 'original_full_index_sha256_unchanged': EXPECTED['retention-manifest.json'], 'original_index_count': 2959, 'authoritative_source_index_sha256': declared['source-manifest.json']['sha256'], 'authoritative_source_named_files': 1850, 'exact_source_index_minus_full_index': supplement_names, 'supplement_count': 55, 'union_count': 3014, 'supplement_logical_bytes': sum(row['bytes'] for row in bindings if row['relative'] in supplement), 'records': [row for row in bindings if row['relative'] in supplement], 'already_declared_ignored_generated_pyc_count': 165, 'already_declared_ignored_generated_pyc_paths': ignored_generated, 'included_not_a_whole_cache_image': True, 'no_reconstructed_or_guessed_body': True})
    dump(STORE / 'declared-before.json', upfront)
    dump(STORE / 'durable-full-recovery-map.json', {'scope': 'EVERY_DECLARED_BODY_PHYSICALLY_DURABLE_NO_IMPLICIT_ROOT_OR_GIT_RECOVERY', 'records': {row['relative']: {key: row[key] for key in ('bytes', 'sha256', 'original_mode', 'durable_relative', 'durable_full_path')} for row in bindings}})
    dump(STORE / 'remote-omissions.json', {'scope': 'REMOTE_REVIEW_IS_SELECTED_NOT_COMPLETE_ALL_OMITTED_BODIES_PHYSICALLY_DURABLE', 'omitted_records': omitted, 'original_opaque_review_archive_omitted_here_but_full_bytes_durable': by_name['review-selection.tar.gz'], 'no_missing_historical_preimage_or_intermediate_binary_reconstruction': True})
    dump(STORE / 'original-selected-archive-readback.json', {'archive_sha256': EXPECTED['review-selection.tar.gz'], 'archive_bytes': 17772110, 'safe_regular_members': old_members, 'all_937_member_bytes_verified': True})
    dump(STORE / 'collection-checks.json', {'provided_endpoints_verified': EXPECTED, 'original_declared_leaves': 2959, 'source_index_supplement': 55, 'union_leaves': 3014, 'named_final_source_files_all_physically_retained': 1850, 'already_declared_ignored_generated_pyc_leaves_included': 165, 'all_original_2020_recovery_bodies_now_physically_durable': True, 'original_selected_members_read_back': 937, 'original_declared_logical_bytes': 920554948, 'original_unique_declared_bodies': 2194, 'original_unique_body_bytes': 737505118, 'original_logical_byte_alias_deduplication': 183049830, 'union_logical_bytes': sum(row['bytes'] for row in bindings), 'union_unique_bodies': len(unique), 'union_unique_body_bytes': sum(unique.values()), 'physical_allocation_savings_or_complete_image_claim': False, 'copy_method': 'shutil.copyfile to fresh regular CAS files; no hardlinks, no donor mutation', 'unindexed_extras': 'Only original2959 leaves and separately authoritative55 source-index leaves copied. No package-review stdout/stderr, retention-verification, full Cargo/venv/cache image or arbitrary donor extras. The original full index is preserved as an explicit binding control.', 'no_independent_source_or_data_PASS_claim': True})
    shutil.copyfile(Path(__file__), STORE / 'collector.py')
    shutil.copyfile(OUT / 'phase-release.json', STORE / 'phase-release.json')
    shutil.copyfile(OUT / 'supplement-authorization.json', STORE / 'supplement-authorization.json')
    shutil.copyfile(OUT / 'PLAN.json', STORE / 'collection-plan-upfront.json')
    shutil.copyfile(OUT / 'metadata-boundary.json', STORE / 'metadata-boundary-before-heavy.json')
    shutil.copyfile(OUT / 'supplement-metadata-stat.json', STORE / 'source-supplement-metadata-stat-before-heavy.json')
    dump(STORE / 'invocation.json', {'argv': [str(Path(__file__))], 'collector_sha256': digest(Path(__file__)), 'started_at_utc': STARTED, 'scope': 'AFTER_EXPLICIT_ROOT_PHASE_CLEAR_READ_HASH_COPY_ARCHIVE_ONLY', 'input_prefix': str(frozen_root), 'no_root_live_product_Git_GitHub_network_secrets_or_actor_access': True})
    (STORE / 'HANDOFF.md').write_text('''# Retained outside W04 real-owner HTTP proof

This is archival collection of the frozen outside proof, not a product change,
test/actor rerun, canonical adoption, current full result or independent PASS.
The source/data review by a different agent remains separate. No root working
tree, live product directory, GitHub, network or secret source was accessed.

Every one of the original retention index's 2,959 declared present leaves is now
physically retained in durable content-addressed blobs, with exact original path,
SHA-256, length and collected mode in path-bindings.json. The original full index
is preserved verbatim as an explicit binding control. Its 55 omitted nested source
retention-manifest files are separately indexed by the authoritative 1,850-file
source-manifest. Root explicitly authorized their verbatim physical retention as
an additive 55-file supplement: no original index rewrite, guessed body or new
execution/source-image credit. source-index-supplement.json records the exact
set difference and 3,014-leaf union. All 1,850 named source files are physically
retained. The original165 ignored/generated/Python bytecode leaves are included
honestly as indexed inputs, not described as excluded or as a whole cache image.
This includes full source
images, actually retained/listed/executed binary versions, 40-file runtime,
wheels, source/command/preparation receipts and historical harness/style failures.
All original 2,020 omitted-blob mappings are satisfied by physical durable bodies.
No leaf is deleted or replaced by an unstated Git/root recovery assumption.

The original 920,554,948 logical leaf bytes deduplicate to 2,194 declared bodies
totaling 737,505,118 bytes. This describes content aliases, not measured disk
allocation savings or an entire Cargo/venv/cache/build-machine image. Only the
original full-index leaves and explicitly authorized source-index55 are collected:
no unindexed extras, full compiler/dependency/cache images or guessed donor contents.
Copies are fresh owned regular files, never
hardlinks. Donor bytes and permissions are checked unchanged afterward.

The new remote review tar is explicitly SELECTED, NOT COMPLETE. It deduplicates
the original selected review bodies and preserves source/patch/receipt/recovery
indexes. Every omitted body has an exact full durable path/hash/size/mode in
remote-omissions.json and durable-full-recovery-map.json. The original opaque
17,772,110-byte selected archive remains fully durable but is not nested remotely;
all 937 original regular member bodies were independently read back as data.

Original PLAN/HANDOFF words, historical setup failures, source versions and
provenance limits are unchanged. No missing early receipt, unretained intermediate
binary or preimage is reconstructed. In particular, the original incomplete
preparation receipt and refused intermediate binary overwrite retain their stated
limits. The later complete actual final evidence is preserved at its own scope.

No real Wry/GUI/event wiring, pending-body real-owner cancellation, W05 restart,
Windows/Linux execution, packaging/signature/OS trust, full verification or
milestone/Gate credit is added by this retention. The outside cfg(test)-only
proof and its original actor observations are not unconditional canonical CI
requirements. Root alone owns adoption and completion decisions.

Heavy collection started only after the recorded explicit root phase-clear.
The collector imports standard library only and performs file reads/hash/copies
and archive read/write in owned retention directories. No helper/product import,
test, build, install, service, process/socket/browser actor, root edit, commit or
push occurred. Retention manifests and every selected tar member are read back
before sealing for a different independent binding reviewer.
''')
    # Exhaustively recapture every donor's bytes/mode after copying, without writes.
    after = []
    for record in bindings:
        path = Path(record['original_physical_path'])
        info = path.lstat()
        assert stat.S_ISREG(info.st_mode) and info.st_size == record['bytes']
        assert digest(path) == record['sha256'] and stat.S_IMODE(info.st_mode) == record['original_mode']
        after.append({'relative': record['relative'], 'bytes': info.st_size, 'sha256': record['sha256'], 'mode': stat.S_IMODE(info.st_mode)})
    assert after == upfront
    dump(STORE / 'declared-after.json', after)
    assert digest(SOURCE / 'retention-manifest.json') == EXPECTED['retention-manifest.json']
    payload = [{'path': str(path.relative_to(STORE)), 'bytes': path.stat().st_size, 'mode': 0o444, 'sha256': digest(path)} for path in sorted(STORE.rglob('*')) if path.is_file()]
    dump(STORE / 'retention-manifest.json', {'scope': 'EXHAUSTIVE_DURABLE_CAS_AND_COLLECTION_CONTROLS_EXCEPT_THIS_MANIFEST', 'files': payload})
    members = [{'path': str(path.relative_to(STORE)), 'bytes': path.stat().st_size, 'mode': 0o444, 'sha256': digest(path)} for path in sorted(STORE.rglob('*')) if path.is_file() and (path.parent != STORE / 'blobs' or path.name in remote_hashes)]
    archive_path = OUT / 'real-owner-http-selected.tar.gz'
    with archive_path.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
                for row in members:
                    safe(row['path'])
                    info = tarfile.TarInfo(PREFIX + '/' + row['path'])
                    info.size = row['bytes']
                    info.mode = row['mode']
                    info.mtime = info.uid = info.gid = 0
                    info.uname = info.gname = ''
                    with (STORE / row['path']).open('rb') as stream:
                        archive.addfile(info, stream)
    assert archive_path.stat().st_size < 15 * 1024 * 1024
    expected_members = {PREFIX + '/' + row['path']: row for row in members}
    seen = set()
    with tarfile.open(archive_path, 'r:gz') as archive:
        for member in archive.getmembers():
            safe(member.name)
            assert member.isfile() and not member.issym() and not member.islnk()
            assert member.name not in seen and member.name in expected_members
            seen.add(member.name)
            stream = archive.extractfile(member)
            assert stream is not None
            data = stream.read()
            row = expected_members[member.name]
            assert len(data) == row['bytes'] and sha(data) == row['sha256'] and member.mode == row['mode']
    assert seen == set(expected_members)
    for row in payload:
        path = STORE / row['path']
        assert path.stat().st_size == row['bytes'] and digest(path) == row['sha256']
    result = {'scope': 'SELECTED_RETENTION_OF_COMPLETE_DECLARED_OUTSIDE_W04_REAL_OWNER_PROOF_NO_NEW_EXECUTION_OR_INDEPENDENT_PASS', 'durable': str(STORE), 'archive': str(archive_path), 'archive_bytes': archive_path.stat().st_size, 'archive_sha256': digest(archive_path), 'safe_regular_members': len(members), 'all_remote_members_and_complete_durable_payload_read_back': True, 'unsafe_duplicate_missing_nonregular_members': 0, 'original_declared_leaves': 2959, 'separately_authorized_source_index_supplement': 55, 'union_leaves': 3014, 'original_named_source_files_all_physically_retained': 1850, 'already_declared_ignored_generated_pyc_leaves_included': 165, 'logical_original_declared_bytes': 920554948, 'original_unique_declared_bodies': 2194, 'original_unique_body_bytes': 737505118, 'original_logical_alias_dedup_bytes': 183049830, 'union_logical_bytes': sum(row['bytes'] for row in bindings), 'union_unique_bodies': len(unique), 'union_unique_body_bytes': sum(unique.values()), 'physical_disk_allocation_or_complete_build_image_claim': False, 'original_2020_recovery_rows_physically_retained': True, 'all_937_original_archive_members_read_back': True, 'remote_omitted_leaf_bindings': len(omitted), 'remote_omitted_unique_bodies': len({row['sha256'] for row in omitted}), 'every_omitted_leaf_has_full_durable_CAS': True, 'source_supplement_sha256': digest(STORE / 'source-index-supplement.json'), 'path_bindings_sha256': digest(STORE / 'path-bindings.json'), 'recovery_map_sha256': digest(STORE / 'durable-full-recovery-map.json'), 'omissions_sha256': digest(STORE / 'remote-omissions.json'), 'retention_manifest_sha256': digest(STORE / 'retention-manifest.json'), 'handoff_sha256': digest(STORE / 'HANDOFF.md'), 'collector_sha256': digest(Path(__file__)), 'donor_before_after_bytes_and_modes_identical': True, 'no_root_or_live_product_directory_access_or_actor': True, 'no_missing_receipt_preimage_or_binary_reconstruction': True}
    dump(OUT / 'real-owner-http-selected.manifest.json', {**result, 'members': members})
    dump(OUT / 'collection-result.json', result)
    for path in STORE.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            path.chmod(0o444)
    for path in sorted((path for path in STORE.rglob('*') if path.is_dir()), key=lambda path: len(path.parts), reverse=True):
        path.chmod(0o555)
    STORE.chmod(0o555)
    for row in payload:
        assert stat.S_IMODE((STORE / row['path']).stat().st_mode) == row['mode']
    for path in OUT.iterdir():
        if path.is_file():
            path.chmod(0o444)
    print(json.dumps(result, indent=2), flush=True)

STARTED = datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
    main()
except BaseException as error:
    dump(OUT / 'collector-failure.json', {'scope': 'ARCHIVAL_COLLECTOR_PREMISE_FAILURE_NOT_PRODUCT_PROOF_FAILURE', 'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc(), 'collector_sha256': digest(Path(__file__))})
    raise
