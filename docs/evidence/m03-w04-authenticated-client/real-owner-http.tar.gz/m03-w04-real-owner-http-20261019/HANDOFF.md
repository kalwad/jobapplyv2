# Retained outside W04 real-owner HTTP proof

This is archival collection of the frozen outside proof, not a product change,
test/actor rerun, canonical adoption, current full result or independent PASS.
The source/data review by a different agent remains separate. No root working
tree, live product directory, GitHub, network or secret source was accessed.

Every one of the original retention index's 2,959 declared present leaves is now
physically retained in durable content-addressed blobs, with exact original path,
SHA-256, length and collected mode in path-bindings.json. The original full index
is preserved verbatim as an explicit binding control. Its 55 omitted nested source
retention-manifest files are separately indexed by the authoritative 1,850-file
source-manifest. Root explicitly authorized their verbatim physical retention as
an additive 55-file supplement: no original index rewrite, guessed body or new
execution/source-image credit. source-index-supplement.json records the exact
set difference and 3,014-leaf union. All 1,850 named source files are physically
retained. The original165 ignored/generated/Python bytecode leaves are included
honestly as indexed inputs, not described as excluded or as a whole cache image.
This includes full source
images, actually retained/listed/executed binary versions, 40-file runtime,
wheels, source/command/preparation receipts and historical harness/style failures.
All original 2,020 omitted-blob mappings are satisfied by physical durable bodies.
No leaf is deleted or replaced by an unstated Git/root recovery assumption.

The original 920,554,948 logical leaf bytes deduplicate to 2,194 declared bodies
totaling 737,505,118 bytes. This describes content aliases, not measured disk
allocation savings or an entire Cargo/venv/cache/build-machine image. Only the
original full-index leaves and explicitly authorized source-index55 are collected:
no unindexed extras, full compiler/dependency/cache images or guessed donor contents.
Copies are fresh owned regular files, never
hardlinks. Donor bytes and permissions are checked unchanged afterward.

The new remote review tar is explicitly SELECTED, NOT COMPLETE. It deduplicates
the original selected review bodies and preserves source/patch/receipt/recovery
indexes. Every omitted body has an exact full durable path/hash/size/mode in
remote-omissions.json and durable-full-recovery-map.json. The original opaque
17,772,110-byte selected archive remains fully durable but is not nested remotely;
all 937 original regular member bodies were independently read back as data.

Original PLAN/HANDOFF words, historical setup failures, source versions and
provenance limits are unchanged. No missing early receipt, unretained intermediate
binary or preimage is reconstructed. In particular, the original incomplete
preparation receipt and refused intermediate binary overwrite retain their stated
limits. The later complete actual final evidence is preserved at its own scope.

No real Wry/GUI/event wiring, pending-body real-owner cancellation, W05 restart,
Windows/Linux execution, packaging/signature/OS trust, full verification or
milestone/Gate credit is added by this retention. The outside cfg(test)-only
proof and its original actor observations are not unconditional canonical CI
requirements. Root alone owns adoption and completion decisions.

Heavy collection started only after the recorded explicit root phase-clear.
The collector imports standard library only and performs file reads/hash/copies
and archive read/write in owned retention directories. No helper/product import,
test, build, install, service, process/socket/browser actor, root edit, commit or
push occurred. Retention manifests and every selected tar member are read back
before sealing for a different independent binding reviewer.
