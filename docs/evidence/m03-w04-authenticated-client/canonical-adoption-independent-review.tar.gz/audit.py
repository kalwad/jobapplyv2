"""Finite integration/data binding only. Never imports or executes subject code."""
import hashlib, io, json, pathlib, subprocess

R=pathlib.Path('/Users/tanishkalwad/jobapplyv2')
P=pathlib.Path('/tmp/japp-m03-w04-canonical-adoption-20261019')
J=pathlib.Path('/tmp/japp-m03-w04-current-tooling-join-20261019')
H=pathlib.Path('/tmp/japp-m03-w04-real-owner-http-preparation-20261019')
O=pathlib.Path(__file__).parent
BASE='c5766246f8b81f32fbfb2eebbacb96c0ba9f5307'
PRIOR='6d3a6b8ccde5b75e12248ae7bbefc473b72922e4'
G=['/usr/bin/git','--no-optional-locks','-C',str(R)]
def git(*args):return subprocess.check_output(G+list(args))
def sha(b):return hashlib.sha256(b).hexdigest()
def row(b):return {'bytes':len(b),'sha256':sha(b)}
def load(p):return json.loads(p.read_bytes())
ad=load(P/'adoption.json');cl=load(P/'generation-closure.json')
assert ad['base']==cl['base']==BASE and git('rev-parse','HEAD').decode().strip()==BASE
assert {k:v for k,v in cl.items() if k not in ('canonical_generation_actual','all81_adopted_hashes_match')}==ad
jm=J/'source-manifest.json'
assert sha(jm.read_bytes())==ad['implementation_source_manifest']=='b79acf135fcd53da216363dfa50f30af376315fab3504696a697fe08490a66d0'
joined=load(jm)
changes={x['path']:x for x in ad['reviewed_changes81']}
assert len(changes)==81 and sum(x['kind']=='ADD' for x in changes.values())==51
base_tree={}
for record in git('ls-tree','-rz','--full-tree',BASE).split(b'\x00'):
 if not record:continue
 info,name=record.split(b'\t',1);base_tree[name.decode()]=info.decode().split()[2]
for n,c in changes.items():
 assert joined[n]==c['candidate']==row((R/n).read_bytes())==row((J/'source'/n).read_bytes())
 assert (n in base_tree)==(c['kind']=='MOD')
assert set(git('diff','--name-only').decode().splitlines())=={n for n,c in changes.items() if c['kind']=='MOD'}
assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={n for n,c in changes.items() if c['kind']=='ADD'}
assert len(ad['applied_nongenerated'])==70 and len(ad['generated_pending_canonical_generator'])==11
assert set(ad['applied_nongenerated'])|set(ad['generated_pending_canonical_generator'])==set(changes)
assert not set(ad['applied_nongenerated'])&set(ad['generated_pending_canonical_generator'])
assert set(ad['preimages'])=={n for n,c in changes.items() if c['kind']=='MOD'}
for n,binding in ad['preimages'].items():
 b=git('show',BASE+':'+n);assert row(b)==binding and b==git('show',PRIOR+':'+n)
for n,binding in ad['governance_current_ci_scanner_preserved'].items():
 b=(R/n).read_bytes();assert sha(b)==binding and b==git('show',BASE+':'+n)
inventory=load(R/'scripts/python-test-inventory.v1.json')
old_inventory=json.loads(git('show',BASE+':scripts/python-test-inventory.v1.json'))
common=inventory['common']['node_ids']
assert inventory['common']['count']==len(common)==1677 and len(set(common))==1677
assert inventory['posix_only_node_ids']==old_inventory['posix_only_node_ids'] and len(inventory['posix_only_node_ids'])==2
assert set(old_inventory['common']['node_ids'])<=set(common)
assert len(set(common)-set(old_inventory['common']['node_ids']))==26
gen=load(R/'packages/contracts/generated/MANIFEST.json')
gen_paths={'packages/contracts/generated/'+x['path'] for x in gen['outputs']}|{'packages/contracts/generated/MANIFEST.json'}
assert len(gen['outputs'])==204 and len(gen_paths)==205
for output in gen['outputs']:
 assert sha((R/'packages/contracts/generated'/output['path']).read_bytes())==output['sha256']
for n in gen_paths:assert row((R/n).read_bytes())==joined[n]
gen_delta={n for n in gen_paths if n not in base_tree or (R/n).read_bytes()!=git('show',BASE+':'+n)}
assert gen_delta==set(ad['generated_pending_canonical_generator']) and len(gen_delta)==11
old_gen={n for n in base_tree if n.startswith('packages/contracts/generated/')}
assert old_gen<=gen_paths and len(old_gen)==198
assert len(gen_paths-gen_delta)==194
assert cl['canonical_generation_actual']=={'exit_code':0,'files':205,'all_generated_bytes_match_reviewed_current_join':True}
assert cl['all81_adopted_hashes_match'] is True
assert 'generated 205 files into /Users/tanishkalwad/jobapplyv2/packages/contracts/generated' in (P/'generate.stdout').read_text()

preflight=load(H/'evidence/runtime-preflight.json')
source_inputs=preflight['verified_declared_source_inputs']
assert len(source_inputs)==135
for n,binding in source_inputs.items():assert row((R/n).read_bytes())==binding==joined[n]
runtime=load(H/'current-runtime/manifest.json')
assert sha((H/'current-runtime/manifest.json').read_bytes())=='d274dcc7194722a4ec1549043543225d63bf48e5c6c8e55f4049eee4b5ceeea0'
assert sha((R/'scripts/service-build-tools.requirements.lock').read_bytes())==runtime['source_inputs']['build_requirements_sha256']
requirements_argv=next(x['argv'] for x in load(H/'inputs/runtime-original-commands.json') if x['label']=='runtime-build')
requirements=pathlib.Path(requirements_argv[requirements_argv.index('--runtime-requirements')+1])
assert sha(requirements.read_bytes())==runtime['source_inputs']['runtime_requirements_sha256']
for name,wheel in preflight['wheel_checks'].items():
 assert sha((H/'wheels'/name).read_bytes())==wheel['sha256']
 for item in wheel['exact_source_members'].values():assert sha((R/item['source']).read_bytes())==item['sha256']
preservation=load(H/'preservation.json')
for item in preservation['all138_old_bodies']:assert row((R/item['path']).read_bytes())==joined[item['path']]
for item in preservation['modified_existing_files']:assert sha((R/item['path']).read_bytes())==item['production_projection_sha256']
for n in preservation['test_only_new_files']:assert not (R/n).exists()
native_paths={n for n in joined if n.startswith('apps/desktop/src-tauri/') and (n.endswith('.rs') or n.endswith('Cargo.toml') or n.endswith('Cargo.lock') or n.endswith('tauri.conf.json'))}
for n in native_paths:assert row((R/n).read_bytes())==joined[n]
assert not (R/'apps/desktop/src-tauri/src/service/restart.rs').exists()
status=(R/'docs/PROJECT_STATUS.md').read_text()
assert 'Current work package: M03-W04' in status and '36/300 packages VERIFIED' in status and 'Overall release gate: NOT_READY' in status
bindings={str(p):row(p.read_bytes()) for p in [P/'adoption.json',P/'generation-closure.json',jm,P/'generate.stdout',P/'generate.stderr',P/'pnpm-install.stdout',P/'pnpm-install.stderr',P/'uv-sync.stdout',P/'uv-sync.stderr',H/'evidence/runtime-preflight.json',H/'preservation.json',H/'current-runtime/manifest.json']}
result={'result':'PASS_FINITE_W04_CANONICAL_ADOPTION_SOURCE_DATA_BINDING','base':BASE,'implementation_manifest':ad['implementation_source_manifest'],'current_delta_paths':81,'modified':30,'new':51,'nongenerated_copied_paths':70,'preimages_match_c576_and_6d3':30,'canonical_generated_paths_exact_candidate':205,'generated_outputs':204,'generated_delta':11,'old_generated_unchanged':194,'old_generated_removed':0,'runtime_source_inputs_exact':135,'native_paths_exact_candidate':len(native_paths),'all138_inherited_test_files_and_shipping_projection_exact':True,'outside_real_owner_test_only_files_not_adopted':True,'python_inventory':{'common':1677,'posix_only':2,'expected_posix_execution':1679,'new_common_ids':26,'all_old_ids_preserved':True},'governance_current_CI_scanner_preserved':12,'future_W05_not_adopted':True,'generation_receipt':'Canonical closure exit0 and actual205-file stdout; reviewer did not rerun generator. Selected data does not serialize outer invocation argv/environment.','runtime_scope':'Previously reviewed d274 runtime/wheels/input applicability only; staging, fresh runtime build or launch not claimed.','validation_scope':'Product focused/current root full verification not evaluated or claimed by this adoption audit.','inputs':bindings,'subject_import_or_execution':False}
(O/'findings.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='inputs'},indent=2))
