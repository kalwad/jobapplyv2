from pathlib import Path
import difflib,hashlib,json,re,shutil
base=Path('/tmp/japp-w14-closeout-template');h=base/'history/template-002';h.mkdir(parents=True,exist_ok=False)
for name in ['closeout-template.patch','template-manifest.json','finalize-after-root-release.py','prepared-finalizer-manifest.json','README.md']:
 shutil.copy2(base/name,h/name)
shutil.copytree(base/'afterimages',h/'afterimages')
p=base/'afterimages/docs/TEST_EVIDENCE.md';s=p.read_text()
s=s.replace('Fresh no-hardlinks clone, locked pnpm/uv dependencies, Chromium installation, doctor and full verification completed with exit0 and unchanged clean before/after source/tree/tracked inventories.','Fresh no-hardlinks clone, locked pnpm/uv dependencies, Chromium installation and full verification completed with exit0 and unchanged clean before/after source/tree/tracked inventories.',1)
s=s.replace('Separate closeout review: __CLOSEOUT_REVIEW_REF__, SHA-256 __CLOSEOUT_REVIEW_SHA256__.','Separate completed full-run data audit: __FULL_RUN_DATA_AUDIT_REF__, SHA-256 __FULL_RUN_DATA_AUDIT_SHA256__. Final closure-patch source review follows materialization and precedes root integration; it is not a prerequisite claimed complete by this template.',1)
needle='These fields must come from completed retained observations; the template itself records no future command result.'
correction='The wrapper\'s initial `pnpm doctor` invoked pnpm11\'s builtin rather than the repository doctor. Original wrapper/log/source are retained. Root separately ran `pnpm run doctor` in the same clone during aggregate static/typecheck, before browser/benchmark work, from22:55:07.349105Z to22:55:12.916122Z on2026-10-17: exit0,27 PASS/0 WARN/0 FAIL/1 NOT_YET_APPLICABLE. Its actual command record and3226-byte repository-doctor.log SHA-2566367e0a7a7b8d1c7d09d93d9aacd76b43461ba34a638d74a4dde74682911bc23 are retained with the proof. No serial repository-doctor-before-aggregate order is asserted.'
if s.count(needle)!=1:raise SystemExit('Expected one proof template paragraph')
s=s.replace(needle,needle+'\n\n'+correction,1);p.write_text(s)
p=base/'finalize-after-root-release.py';s=p.read_text()
s=s.replace('"""Outside-only materialization; do not execute before explicit root PASS release."""','"""Outside-only materialization after producer completion and sealed data audit."""',1)
s=s.replace("facts.get('root_explicitly_released_after_completed_pass')", "facts.get('producer_completed_raw_pass_and_data_audit_sealed')",1)
s=s.replace("raise SystemExit('Root completion/release is required')", "raise SystemExit('Producer completion and completed full-run data audit are required')",1)
s=s.replace('__CLOSEOUT_REVIEW_REF__','__FULL_RUN_DATA_AUDIT_REF__').replace('__CLOSEOUT_REVIEW_SHA256__','__FULL_RUN_DATA_AUDIT_SHA256__')
needle="summary=(proof/'aggregate.log').read_text(errors='replace').split('== verification summary ==')[-1]"
extra="""# The retained wrapper 'doctor' stage is pnpm's builtin; repository doctor is
# this separately completed correction in the same clone, during early aggregate.
correction=Path(facts['repository_doctor_correction_directory'])
repository_doctor=json.loads((correction/'command.json').read_text())
doctor_log=(correction/'repository-doctor.log').read_bytes()
aggregate_record=next(r for r in records if r['name']=='aggregate')
if not (repository_doctor.get('argv')==['pnpm','run','doctor'] and repository_doctor.get('cwd')==aggregate_record['cwd'] and repository_doctor.get('exit_code')==0 and len(doctor_log)==repository_doctor.get('log_bytes')==3226 and hashlib.sha256(doctor_log).hexdigest()==repository_doctor.get('log_sha256')=='6367e0a7a7b8d1c7d09d93d9aacd76b43461ba34a638d74a4dde74682911bc23'):
 raise SystemExit('Actual repository doctor correction binding is missing')
"""
if s.count(needle)!=1:raise SystemExit('Expected one summary guard')
s=s.replace(needle,extra+needle,1)
s=s.replace('Quoted actual closeout review binding missing','Quoted actual completed full-run data audit binding missing')
s=s.replace('Actual frozen6384 clone PASS/proof reviewed before materialization.','Actual frozen6384 clone PASS and completed full-run data audit bound before materialization; exact closure-patch source peer review still follows.',1)
p.write_text(s)
p=base/'README.md';s=p.read_text()
s=s.replace('complete PASS and releases materialization','complete raw PASS and the full-run data-audit seal is available',1)
s=s.replace('doctor and full verification','repository-doctor correction and full verification')
s=s.replace('plus actual closeout review path/SHA256. Both must exist before finalization','plus the completed full-run data-audit path/SHA256. Both must exist before materialization',1)
s=s.replace('Closeout timestamp and explicit root release after the actual successful run.','Closeout timestamp and producer completion coordination after the actual successful run plus full-run data audit. This is not an owner permission request. Exact closure-patch source review happens after materialization, then root applies and runs focused checks.',1)
s=s.replace('missing actual stages/log bindings/retention/proof/review','missing actual stages/log bindings/retention/proof/full-run data audit')
s=s.replace('`root_explicitly_released_after_completed_pass` true only after root release','`producer_completed_raw_pass_and_data_audit_sealed` true only after actual producer completion and data-audit seal',1)
s=s.replace('`raw_clone_proof_directory`, `actual_mounted_raw_artifact`, `actual_mounted_raw_sha256`;','`raw_clone_proof_directory`, `repository_doctor_correction_directory`, `actual_mounted_raw_artifact`, `actual_mounted_raw_sha256`;',1)
s+='\nDoctor provenance: the original wrapper `pnpm doctor` was pnpm11 builtin. Preserve it as such. The actual repository doctor is the separate completed `pnpm run doctor` correction in the same clone during aggregate static/typecheck, before browser/benchmark;27 PASS/0 WARN/0 FAIL/1 N/A,3226-byte log SHA6367e0a7.... The guard binds that exact record/log and makes no false serial-order claim. This correction alone does not require rerunning the aggregate.\n'
p.write_text(s)
m=json.loads((base/'template-manifest.json').read_text());patch=''
for item in m['paths']:
 rel=item['path'];pre=(base/'preimages'/rel).read_bytes();post=(base/'afterimages'/rel).read_bytes();item['draft_afterimage_sha256']=hashlib.sha256(post).hexdigest()
 if pre!=post:patch+=f'diff --git a/{rel} b/{rel}\n'+''.join(difflib.unified_diff(pre.decode().splitlines(True),post.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(base/'closeout-template.patch').write_text(patch);m['format_version']='W14_CLOSEOUT_CONDITIONAL_TEMPLATE_3';m['prior_template']='history/template-002/closeout-template.patch';m['prior_template_sha256']=hashlib.sha256((h/'closeout-template.patch').read_bytes()).hexdigest();m['template_patch_sha256']=hashlib.sha256((base/'closeout-template.patch').read_bytes()).hexdigest();m['required_substitutions']=sorted(set(re.findall(r'__[A-Z0-9_]+__',patch)));m['materialization_order']='Actual raw clone PASS then sealed independent full-run data audit -> outside materialization/generation -> exact final closure-patch source review -> root integration/focused checks. No owner permission step.';m['state']='DRAFT_ONLY_DO_NOT_APPLY_UNTIL_ACTUAL_CLONE_PASS_DATA_AUDIT_AND_LATER_CLOSURE_PATCH_REVIEW';(base/'template-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
f={'scope':'Prepared not executed; actual repository-doctor correction bound separately from original builtin stage; final source review correctly follows materialization.','prepared_sha256':hashlib.sha256((base/'finalize-after-root-release.py').read_bytes()).hexdigest(),'execution_attempts':0,'root_mutations':0};(base/'prepared-finalizer-manifest.json').write_text(json.dumps(f,indent=2)+'\n');print(json.dumps({'template_sha256':m['template_patch_sha256'],'finalizer_sha256':f['prepared_sha256'],'required_substitutions':m['required_substitutions']},indent=2))
