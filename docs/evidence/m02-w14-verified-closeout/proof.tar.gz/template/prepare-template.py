from pathlib import Path
import difflib,hashlib,json,re,shutil
root=Path('/Users/tanishkalwad/jobapplyv2');base=Path('/tmp/japp-w14-closeout-template')
commit='6384d98156ae198cd93d7b35d1bb28b501ed475e';tree='d2c1fd5e50bbbd31a926cbf251d6140d11b9b9c4'
paths=['docs/PROJECT_STATUS.md','docs/KNOWN_ISSUES.md','docs/CRITICAL_GATES.md','docs/gates/AUTOFILL_FEASIBILITY_GATE.md','docs/COMPATIBILITY_MATRIX.md','docs/TEST_EVIDENCE.md','docs/traceability.json','docs/REQUIREMENTS_TRACEABILITY.md','scripts/traceability.py']
if (base/'preimages').exists():raise SystemExit('Refusing to overwrite initial template')
for rel in paths:
 for part in ['preimages','afterimages']:
  p=base/part/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/rel,p)

p=base/'afterimages/docs/PROJECT_STATUS.md';s=p.read_text()
s=s.replace('Repository revision: M02-W14; accepted ADR-0007 external-evidence waiver; historical exact1d native CI passes; remaining W14/W15 review pending','Repository revision: W14 VERIFIED at tested6384 content; W15 READY for independent Gate A audit',1)
s=s.replace('Last updated: 2026-10-17','Last updated: __CLOSEOUT_TIMESTAMP__',1)
s=s.replace('Current work package: M02-W14','Current work package: M02-W15',1)
s=s.replace('- State: M02-W14 IN_PROGRESS; M00/M01 ACCEPTED and M02-W01 through W13 VERIFIED. W15 NOT_STARTED; no package is READY.31/300 packages remain VERIFIED. Per-W stopping is superseded by ADR-0006.','- State: M02-W14 VERIFIED at tree '+tree+'; M00/M01 remain ACCEPTED and M02-W01 through W14 VERIFIED. M02-W15 READY is the sole next package.32/300 packages are VERIFIED. Per-W stopping remains superseded by ADR-0006; this transition supplies no Gate A verdict.',1)
lines=s.splitlines()
for i,line in enumerate(lines):
 if line.startswith('- Remaining evidence:'):
  lines[i]='- Next work: direct Simplify comparison and executed public-form evidence remain WAIVED_BY_OWNER_ADR_0007, with actual cases0. KI-0089 is resolved only at its waived external-requirement scope. W14 package evidence, candidate index, retained synthetic inspection and actual clean-clone full verification are complete at their declared scopes. The genuine independent W15/source-bound owner Gate A decision is the next planned work, not a current implementation defect. Absolute numerical/safety/performance/controlled/native/legacy/usability/accessibility/visual obligations remain binding.'
s='\n'.join(lines)+'\n'
s=s.replace('| `M02-W14` | IN_PROGRESS | — | docs/TEST_EVIDENCE.md § M02-W14 | Clean730 full/actualR9 and exact1d native CI pass; direct Simplify/public-form evidence waived; remaining W14 audit/formalW15 decision pending |','| `M02-W14` | VERIFIED | tree '+tree+' | docs/TEST_EVIDENCE.md § M02-W14 | Frozen6384 clean-clone full verification and reviewed candidate package evidence complete; ADR6/7 waived observations stay unexecuted; formal Gate A decision belongs W15 |',1)
s=s.replace('| `M02-W15` | NOT_STARTED | — | — | Independent Autofill Feasibility Gate audit and decision |','| `M02-W15` | READY | — | — | Independent Autofill Feasibility Gate audit and source-bound owner decision; requires VERIFIED W14; no verdict yet |',1)
s=s.replace('- ID: NONE\n- Reason: M02-W14 is IN_PROGRESS. Continue its implementation and validation; per-package stopping is superseded by ADR-0006.','- ID: M02-W15\n- Reason: M02-W14 is VERIFIED and M00/M01 are ACCEPTED. Execute the separate independent Gate A audit and source-bound decision; continuous execution remains authorized.',1)
s=s.replace('- KI-0089 (HIGH, OPEN) — Direct Simplify/public-form portions are waived by ADR-0007; final eligible independent review and source-bound Gate A owner decision remain incomplete.','- None currently recorded. Formal Gate A review is the next planned package; Gate A remains IN_PROGRESS and release NOT_READY.',1)
p.write_text(s)

p=base/'afterimages/docs/KNOWN_ISSUES.md';s=p.read_text()
a=s.index('### KI-0089 —');b=s.index('\n### KI-0090 —',a);block=s[a:b]
block=block.replace('### KI-0089 — Gate A final independent review and decision remain incomplete','### KI-0089 — External public-form and direct Simplify evidence prerequisites waived by owner',1)
block=block.replace('- State: OPEN','- State: FIXED',1)
replacements={
'- Description:':'- Description: accepted OD-036 / ADR-0007 removes only the direct Simplify comparison and executed public-form evidence prerequisites behind this finding. Actual cases remain0 and their assessment is WAIVED_BY_OWNER_ADR_0007, never PASS. W14 now has reviewed scoped package evidence and successful clean-clone full verification at commit'+commit+'/tree'+tree+'. Formal eligible W15/source-bound owner Gate A decision remains required as the next planned package and is not claimed complete.',
'- Reproduction:':'- Reproduction: inspect the exact accepted ADR/source-aware machine authority, paired ledger/report waiver fields, retained W14 candidate index/manual synthetic checklist and the clean-clone closeout proof. Historical attempts, zero counts, old limitations and findings remain retained below.',
'- Workaround:':'- Workaround: the owner-authorized waiver is the resolution for only those two external prerequisites. It removes no controlled/absolute numeric, physical-safety, other-baseline, native, usability/accessibility/visual, independent-review or owner-decision requirement.',
'- Resolution + evidence link:':'- Resolution + evidence link: FIXED at the waived external scope and completed W14 package closeout, documented in docs/TEST_EVIDENCE.md § M02-W14 and docs/evidence/m02-w14-candidate-handoff. Formal W15 audit is READY and Gate A remains IN_PROGRESS; no owner gate verdict or M02 acceptance is inferred. The earlier pending-W15 work is retained as package work rather than a circular HIGH blocker preventing its own readiness.',
}
lines=block.splitlines();seen=set()
for i,line in enumerate(lines):
 for prefix,value in replacements.items():
  if prefix not in seen and line.startswith(prefix):lines[i]=value;seen.add(prefix);break
block='\n'.join(lines)+'\n';s=s[:a]+block+s[b:]
s=s.replace('W14 is IN_PROGRESS, Gate A IN_PROGRESS, W15 NOT_STARTED and release NOT_READY.','W14 is VERIFIED, Gate A IN_PROGRESS, W15 READY and release NOT_READY.',1)
p.write_text(s)

p=base/'afterimages/docs/CRITICAL_GATES.md';s=p.read_text();a=s.index('## AUTOFILL_FEASIBILITY\n');b=s.index('\n### Metric table',a);block=s[a:b]
k=block.index('- Known limitations:');block=block[:k]+'''- Known limitations: W14 evaluation package is VERIFIED at frozen content
  tree '''+tree+''' after actual clean-clone full verification
  and scoped package evidence review. Formal independent W15/source-bound
  owner Gate A decision remains pending; no final gate verdict is inferred.
  Contact, native128, mounted32, feature fixtures, legacy and native CI scopes
  remain individually limited to their retained observations.
- Simplify comparison result: WAIVED_BY_OWNER_ADR_0007
- Public-form evidence result: WAIVED_BY_OWNER_ADR_0007
- Next permitted action: execute READY M02-W15 in a separate eligible review
  session against exact final evidence; M03 remains NOT_STARTED until genuine
  Gate A PASS and M02 acceptance.
'''
s=s[:a]+block+s[b:];p.write_text(s)

p=base/'afterimages/docs/gates/AUTOFILL_FEASIBILITY_GATE.md';s=p.read_text()
s=s.replace('- Evaluated revision: retained clean730 local full/actualR9 and exact1d native three-OS CI are separate completed scopes. The accepted 2026-10-17 evidence waiver supplies no new execution or final W14/W15/owner Gate A verdict; remaining review is pending.','- Evaluated revision: W14 package content tree '+tree+' is validated by actual clean-clone verification at commit'+commit+'. Formal Gate A evaluated revision/verdict remains for READY M02-W15. Historical source scopes remain separate.',1)
s=s.replace('KI-0089 is OPEN for final eligible independent W15/source-bound owner decision; remaining W14 audit/closeout must clear first.','KI-0089 is FIXED only at its waived external-prerequisite scope. W14 is VERIFIED; final eligible independent W15/source-bound owner decision is the next planned READY package.',1)
s=s.replace('Independent reviewer: pending. M02-W15 has not started.','Independent reviewer: pending. M02-W15 is READY after verified W14 package closeout.',1)
s=s.replace('Gate A remains IN_PROGRESS; M02-W14 remains IN_PROGRESS, M02-W15 NOT_STARTED, M02 unaccepted and M03 NOT_STARTED.','Gate A remains IN_PROGRESS; M02-W14 is VERIFIED, M02-W15 READY, M02 unaccepted and M03 NOT_STARTED.',1)
s+='''\n\n## W14 package closeout and W15 handoff — 2026-10-17

W14 is VERIFIED at commit '''+commit+''' / tree '''+tree+''' following actual clean-clone locked-dependency installation, doctor and full19 verification. Exact fresh execution and proof bindings are recorded in docs/TEST_EVIDENCE.md § M02-W14. Retained candidate index and manual synthetic inspection: docs/evidence/m02-w14-candidate-handoff. Source-aware ADR6/ADR7 authority and separately scoped historical/raw results remain preserved. KI-0089 resolves only the owner-waived public-form/direct Simplify prerequisite gap; actual cases remain0.

M02-W15 is READY for the genuine independent architecture/safety/performance/evidence audit and concrete source-bound owner decision. The mounted32 accounting, contact200 distribution, original67 feature clauses, isolated four-case R9 comparison and historical native CI retain their individual scopes. This package transition is no Gate A PASS, no M02 acceptance, no production ATS support, no broad competitor superiority and no completion of future controlled Workday/native packaging/usability/accessibility/visual requirements.
''';p.write_text(s)

p=base/'afterimages/docs/COMPATIBILITY_MATRIX.md';s=p.read_text()
s=s.replace('W14 remains IN_PROGRESS and Gate A IN_PROGRESS.','W14 is VERIFIED at tree '+tree+'; Gate A remains IN_PROGRESS and M02-W15 is READY.',1)
s=s.replace('No accepted W14 revision exists.','W14 package verification does not accept M02 or certify a production adapter; the historical source rows remain unchanged.',1)
anchor='## Owner evidence waiver — 2026-10-17';notice='''## W14 evaluation package handoff — 2026-10-17

W14 package is VERIFIED at frozen6384 content/tree '''+tree+''' after actual clean-clone full verification and scoped evidence review. Current candidate index/manual synthetic checklist are retained in docs/evidence/m02-w14-candidate-handoff. The verified package supplies no new production support row: synthetic contact, mounted unsupported controls, fixture transition behavior, native repository CI and legacy comparison retain their exact scopes. Gate A remains IN_PROGRESS, with W15 READY for the independent verdict. The owner-waived public-form and direct Simplify categories remain unexecuted, not passed.

''';s=s.replace(anchor,notice+anchor,1);p.write_text(s)

p=base/'afterimages/docs/TEST_EVIDENCE.md';s=p.read_text();anchor='### M02-W14 — Visible development campaigns and supplemental comparison preparation (2026-10-16)'
section='''#### W14 verified package closeout and W15 readiness — 2026-10-17

Verified content: commit '''+commit+''' / tree '''+tree+'''. The actual clean-clone outer command was `__CLEAN_CLONE_OUTER_COMMAND__`; recorded child commands remain separate in the proof. Fresh no-hardlinks clone, locked pnpm/uv dependencies, Chromium installation, doctor and full verification completed with exit0 and unchanged clean before/after source/tree/tracked inventories. Actual result summary: __CLEAN_CLONE_RESULT_SUMMARY__. The exact command timestamps are __CLEAN_CLONE_STARTED_AT__ through __CLEAN_CLONE_ENDED_AT__. Complete source-bound clean-clone proof: __CLEAN_CLONE_PROOF_REF__, SHA-256 __CLEAN_CLONE_PROOF_SHA256__,__CLEAN_CLONE_PROOF_BYTES__bytes/__CLEAN_CLONE_PROOF_MEMBERS__regular members. Separate closeout review: __CLOSEOUT_REVIEW_REF__, SHA-256 __CLOSEOUT_REVIEW_SHA256__. These fields must come from completed retained observations; the template itself records no future command result.

W14 candidate evidence and retained manual synthetic inspection are docs/evidence/m02-w14-candidate-handoff/candidate-evidence-index.json, requirement-to-proof-checklist.md and manual-synthetic-inspection-checklist.md. Archivef9a2837336150dcb4d5b8d1781c05e3e4d108ea951c9af178f0f5176a548045f is5653702bytes/33 regular members with separate packaging peer32/32. The original index remains a historical1d proposal with its ADR7 digest null; accepted ADR7/source-aware machine authority is separately retained in docs/evidence/m02-w14-owner-waiver-governance and docs/evidence/m02-w14-owner-waiver-machine. No historical source binding is rewritten. Clean730 contact200/native128 and actualR9, current1d mounted32 and exact1d three-OS CI remain separately retained. The fresh clone's actual observations are described only by the proof above.

The declared W14 package scope covers the controlled development evaluation, original32 mounted cases, original67 fixture behavior clauses,200 contact variants, bounded feature/performance/safety proofs, frozen-input integrity, source-bound reports and isolated legacy comparison. Contact scoring and all original canonical results remain unchanged. Mounted32 means18 contact-scored/14 unsupported-only in its retained run, not32 fills;43 supported contact values/58 required controls reported and separate native-validity/framework-mirror checks retain their exact observation limits. The manual checklist is retained-image inspection, not a human usability study or fresh browser action. Source review supplies no W15 verdict.

KI-0089 is FIXED only for its owner-waived external prerequisite scope: direct Simplify/public-form observed cases remain0/WAIVED_BY_OWNER_ADR_0007 and hidden holdout remains WAIVED_BY_OWNER_ADR_0006. All other controlled/absolute numeric, physical-safety, legacy-baseline, native, actual usability/accessibility/visual and independent/source-bound owner requirements remain binding. M02-W14 is VERIFIED and M02-W15 READY;32/300 packages are VERIFIED. Gate A/M02 remain IN_PROGRESS, M03 NOT_STARTED and release NOT_READY. Formal W15 evidence reproduction, productionizability/manual-scope assessment, complete canonical gate bundle and actual owner decision remain the next planned work.

''';s=s.replace(anchor,anchor+'\n\n'+section,1);p.write_text(s)

p=base/'afterimages/docs/traceability.json';d=json.loads(p.read_text());evidence={'path':'docs/TEST_EVIDENCE.md','heading':'### M02-W14'}
updates={
'REQ-FORM-025':{'code':['apps/extension/src/driver-engine.ts','e2e/extension/support/autofill-w14-native-witness.ts','e2e/extension/public-contact/contact-harness.ts'],'tests':['e2e/extension/extension-w14-evaluation.spec.ts','e2e/extension/extension-w14-w06.spec.ts','e2e/extension/public-contact/controlled-contact.proof.ts'],'notes':'M02-W14 implements and records the feasibility/CI no-submit portion: loopback-only controlled evaluation, actual built-MV3 no-navigation/submission checks and source-bound raw physical observations. Public scored cases remain0 and are owner-waived under ADR0007, not passed. Future M21-W06/M22-W04/M23-W05 production/unattended compatibility portions and final Gate A decision remain unimplemented/unaccepted; this requirement remains SCAFFOLD_ONLY/NOT_YET_APPLICABLE.'},
'REQ-GATE-004':{'code':['e2e/extension/legacy-paired-options/campaign.mjs','e2e/extension/legacy-paired-options/compare-paired.mjs'],'tests':['e2e/extension/legacy-paired-options/paired-options.proof.ts','e2e/extension/legacy-paired-options/compare-paired.structural.test.mjs','e2e/extension/legacy-paired-options/runtime-inventory.test.mjs'],'notes':'M02-W14 records the actual source/lock-bound R9 same-input isolated legacy component comparison: candidate4/legacy4,40/40vs28/40 exact and separate40/40vs32/40 phone-digits equivalence; installed unexpected native activations0vs4. Four related synthetic cases and one shared component provide no broad/statistical/timing superiority or two-full-product claim. Direct Simplify comparison is WAIVED_BY_OWNER_ADR0007. M05-W11/M20-W10/M38-W04 other nonwaived baseline work and final gate decisions remain future; this requirement remains SCAFFOLD_ONLY/NOT_YET_APPLICABLE.'},
'REQ-GATE-007':{'code':['e2e/extension/legacy-paired-options/campaign.mjs','e2e/extension/legacy-paired-options/run-legacy.mjs'],'tests':['e2e/extension/legacy-paired-options/runtime-inventory.test.mjs','e2e/extension/legacy-paired-options/owned-child-lifecycle.test.mjs'],'notes':'M02-W04 supplied the isolated-observation scaffold; M02-W14 now adds actual provenance/license/source-locked legacy component execution and retained R9 observations in an isolated synthetic harness. CareerPulse/legacy shared source is treated as one component, not two independent products; no code reuse is authorized and no legacy import enters production. M27-W01 threat-model/provenance review remains future. The requirement stays SCAFFOLD_ONLY/NOT_YET_APPLICABLE.'},
'REQ-GATE-008':{'code':['e2e/extension/legacy-paired-options/compare-paired.mjs','e2e/extension/support/autofill-w14-native-witness.ts'],'tests':['e2e/extension/legacy-paired-options/paired-options.proof.ts','e2e/extension/legacy-paired-options/compare-paired.structural.test.mjs'],'notes':'M02-W04 supplied conversion/observation scaffolding; M02-W14 now preserves actual R9 legacy observations including four unexpected country-code ACTIVATIONs and eight empty country/state outcomes. Same-input candidate native-witness regressions explicitly assert zero unexpected native mutations, nonordinary changes, navigation and submission; accuracy values are recorded without rewriting expected truth or asserting improvement. This is scoped observed-behavior coverage, not completion of every future conversion or a universal unsafe-behavior claim. M27-W03 hardening remains future; the requirement stays SCAFFOLD_ONLY/NOT_YET_APPLICABLE.'},
}
for r in d['requirements']:
 if r['id'] not in updates:continue
 u=updates[r['id']];r['implementation_state']='SCAFFOLD_ONLY';r['verification_state']='NOT_YET_APPLICABLE'
 if evidence not in r['current_evidence']:r['current_evidence'].append(evidence)
 for key,values in [('completed_code_paths',u['code']),('completed_test_paths',u['tests'])]:
  for value in values:
   if not (root/value).is_file():raise SystemExit('Nonexistent scoped path '+value)
   if value not in r[key]:r[key].append(value)
 r['notes']=u['notes']
for w in d['work_packages']:
 if w['id']=='M02-W14':w['current_state']='VERIFIED';w['verified_revision']='tree '+tree;w['current_evidence']=[evidence]
 elif w['id']=='M02-W15':w['current_state']='READY'
d['review']['v1_4_requirements_mapping_sha256']='__W14_REQUIREMENT_PROJECTION_SHA256__'
p.write_text(json.dumps(d,indent=2)+'\n')

p=base/'afterimages/scripts/traceability.py';s=p.read_text();old='FINAL_V1_4_REQUIREMENT_MAPPING_SHA256 = (\n    "70424088492737b18171ea26872c3dff40461411726162f863c9f693e0144802"\n)'
new='''# M02-W14 records only scoped feasibility no-submit and actual isolated legacy
# evidence for REQ-FORM-025/REQ-GATE-004/007/008. Future owning-package portions
# remain SCAFFOLD_ONLY/NOT_YET_APPLICABLE. Ownership, requirement text, gate
# effects, dependency graphs and historical v1.2/v1.3 hashes stay unchanged.
# Prior reviewed v1.4 honesty projection:
# 70424088492737b18171ea26872c3dff40461411726162f863c9f693e0144802
FINAL_V1_4_REQUIREMENT_MAPPING_SHA256 = (
    "__W14_REQUIREMENT_PROJECTION_SHA256__"
)'''
if s.count(old)!=1:raise SystemExit('Unexpected projection hash preimage')
p.write_text(s.replace(old,new,1))
patch='';entries=[]
for rel in paths:
 pre=(base/'preimages'/rel).read_bytes();post=(base/'afterimages'/rel).read_bytes()
 if pre!=post:
  patch+=f'diff --git a/{rel} b/{rel}\n'+''.join(difflib.unified_diff(pre.decode().splitlines(True),post.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 entries.append({'path':rel,'preimage_sha256':hashlib.sha256(pre).hexdigest(),'draft_afterimage_sha256':hashlib.sha256(post).hexdigest(),'pending_generation':rel=='docs/REQUIREMENTS_TRACEABILITY.md'})
(base/'closeout-template.patch').write_text(patch)
manifest={'format_version':'W14_CLOSEOUT_CONDITIONAL_TEMPLATE_1','state':'DRAFT_ONLY_DO_NOT_APPLY_UNTIL_ACTUAL_CLONE_PASS_AND_CLOSEOUT_REVIEW','actual_content_commit':commit,'actual_content_tree':tree,'paths':entries,'template_patch_sha256':hashlib.sha256((base/'closeout-template.patch').read_bytes()).hexdigest(),'required_substitutions':sorted(set(re.findall(r'__[A-Z0-9_]+__',patch))),'required_generated_artifact':'docs/REQUIREMENTS_TRACEABILITY.md via isolated existing generator after real proof substitutions and reviewed honesty hash','states_if_and_only_if_finalized':{'M02-W14':'VERIFIED','M02-W15':'READY','verified_package_count':32,'AUTOFILL_FEASIBILITY':'IN_PROGRESS','M02':'IN_PROGRESS','M03':'NOT_STARTED','release':'NOT_READY'},'root_mutations_tests_builds_browsers':0}
(base/'template-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
