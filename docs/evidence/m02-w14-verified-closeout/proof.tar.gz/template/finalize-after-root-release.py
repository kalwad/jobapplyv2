"""Outside-only materialization after producer completion and sealed data audit."""
from pathlib import Path, PurePosixPath
import difflib,hashlib,json,re,shutil,subprocess,sys,tarfile

base=Path(__file__).resolve().parent
root=Path('/Users/tanishkalwad/jobapplyv2')
manifest=json.loads((base/'template-manifest.json').read_text())
if len(sys.argv)!=2:raise SystemExit('Usage: finalize-after-root-release.py ACTUAL_ROOT_FACTS.json')
facts=json.loads(Path(sys.argv[1]).read_text())
if facts.get('producer_completed_raw_pass_and_data_audit_sealed') is not True:raise SystemExit('Producer completion and completed full-run data audit are required')
proof=Path(facts['raw_clone_proof_directory'])
completion=json.loads((proof/'completion.json').read_text())
if not (completion.get('exit_code')==0 and completion.get('head_unchanged') is True and completion.get('tree_unchanged') is True and completion.get('tracked_inventory_unchanged') is True and completion.get('status_before')=='' and completion.get('status_after')==''):raise SystemExit('Actual clean-clone full verification did not complete cleanly')
commit=manifest['actual_content_commit'];tree=manifest['actual_content_tree']
for name in ['before.json','after.json']:
 snapshot=json.loads((proof/name).read_text())
 if snapshot.get('head')!=commit or snapshot.get('tree')!=tree or snapshot.get('status')!='':raise SystemExit('Wrong actual frozen clone source')
command=json.loads((proof/'wrapper-command.json').read_text());env=command.get('task_environment',{})
if command.get('expected_head')!=commit or env.get('JAPP_W13_PERFORMANCE_SAMPLES')!='20' or env.get('JAPP_W14_REQUIRE_TARGET_PERFORMANCE')!='1':raise SystemExit('Mandatory exact-source target20 run is missing')
records=json.loads((proof/'commands.json').read_text())
for name in ['clone','checkout','pnpm-install','uv-sync','playwright-install','doctor','aggregate']:
 matches=[r for r in records if r.get('name')==name]
 if len(matches)!=1 or matches[0].get('exit_code')!=0:raise SystemExit('Missing/failed actual clone stage '+name)
 r=matches[0];raw=(proof/(name+'.log')).read_bytes()
 if len(raw)!=r['log_bytes'] or hashlib.sha256(raw).hexdigest()!=r['log_sha256']:raise SystemExit('Actual clone stage bytes changed '+name)
# The retained wrapper 'doctor' stage is pnpm's builtin; repository doctor is
# this separately completed correction in the same clone, during early aggregate.
correction=Path(facts['repository_doctor_correction_directory'])
repository_doctor=json.loads((correction/'command.json').read_text())
doctor_log=(correction/'repository-doctor.log').read_bytes()
aggregate_record=next(r for r in records if r['name']=='aggregate')
if not (repository_doctor.get('argv')==['pnpm','run','doctor'] and repository_doctor.get('cwd')==aggregate_record['cwd'] and repository_doctor.get('exit_code')==0 and len(doctor_log)==repository_doctor.get('log_bytes')==3226 and hashlib.sha256(doctor_log).hexdigest()==repository_doctor.get('log_sha256')=='6367e0a7a7b8d1c7d09d93d9aacd76b43461ba34a638d74a4dde74682911bc23'):
 raise SystemExit('Actual repository doctor correction binding is missing')
summary=(proof/'aggregate.log').read_text(errors='replace').split('== verification summary ==')[-1]
active=re.findall(r'^([^\s]+)\s+ACTIVE\s+PASS\s*$',summary,re.M)
if len(active)!=19 or len(set(active))!=19 or 'verification exit code: 0' not in summary:raise SystemExit('Actual all19 full PASS is missing')
for relative in ['w14/assessment.json','w14/canonical-execution.json']:
 if not (proof/relative).is_file():raise SystemExit('Fresh contact retention is missing '+relative)
mounted=Path(facts['actual_mounted_raw_artifact'])
if not mounted.is_file() or not mounted.is_relative_to(proof/'mounted32') or hashlib.sha256(mounted.read_bytes()).hexdigest()!=facts['actual_mounted_raw_sha256']:raise SystemExit('Fresh mounted retention binding missing')
values=facts['substitutions']
required=set(manifest['required_substitutions'])-{'__W14_REQUIREMENT_PROJECTION_SHA256__'}
if set(values)!=required or any(not isinstance(v,str) or not v.strip() or re.search(r'__[A-Z0-9_]+__',v) for v in values.values()):raise SystemExit('Actual proof substitutions are missing/extra/unresolved')
for key in ['__CLEAN_CLONE_PROOF_SHA256__','__FULL_RUN_DATA_AUDIT_SHA256__']:
 if not re.fullmatch('[0-9a-f]{64}',values[key]):raise SystemExit('Invalid actual proof digest '+key)
archive=root/values['__CLEAN_CLONE_PROOF_REF__'];review=root/values['__FULL_RUN_DATA_AUDIT_REF__']
if not archive.is_file() or hashlib.sha256(archive.read_bytes()).hexdigest()!=values['__CLEAN_CLONE_PROOF_SHA256__'] or archive.stat().st_size!=int(values['__CLEAN_CLONE_PROOF_BYTES__']):raise SystemExit('Quoted retained clone archive binding missing')
with tarfile.open(archive,'r:gz') as tar:members=tar.getmembers()
if len(members)!=int(values['__CLEAN_CLONE_PROOF_MEMBERS__']) or len(set(m.name for m in members))!=len(members) or any(not m.isfile() or PurePosixPath(m.name).is_absolute() or '..' in PurePosixPath(m.name).parts for m in members):raise SystemExit('Quoted clone archive member binding unsafe/missing')
if not review.is_file() or hashlib.sha256(review.read_bytes()).hexdigest()!=values['__FULL_RUN_DATA_AUDIT_SHA256__']:raise SystemExit('Quoted actual completed full-run data audit binding missing')
for item in manifest['paths']:
 if (root/item['path']).read_bytes()!=(base/'preimages'/item['path']).read_bytes():raise SystemExit('Root preimage drift; explicit rebase required '+item['path'])
out=base/'materialized'
if out.exists():raise SystemExit('Refusing to overwrite an earlier materialization')
shutil.copytree(base/'afterimages',out/'afterimages')
for item in manifest['paths']:
 p=out/'afterimages'/item['path'];text=p.read_text()
 for token,value in values.items():text=text.replace(token,value)
 p.write_text(text)
metadata=out/'afterimages/docs/traceability.json';d=json.loads(metadata.read_text())
keys=['id','owning_packages','planned_components','automated_test_layers','manual_evidence','gate_effects','mapping_review_state','implementation_state','verification_state','completed_code_paths','completed_test_paths','current_evidence','notes']
projection=[[row.get(k) for k in keys] for row in d['requirements']]
projection_sha=hashlib.sha256(json.dumps(projection,ensure_ascii=False,separators=(',',':'),sort_keys=True).encode()).hexdigest()
for rel in ['docs/traceability.json','scripts/traceability.py']:
 p=out/'afterimages'/rel;p.write_text(p.read_text().replace('__W14_REQUIREMENT_PROJECTION_SHA256__',projection_sha))
# Isolate the exact frozen Git content before using its existing generator.
isolated=out/'isolated-tree';isolated.mkdir();archive_path=out/'frozen-content.tar'
with archive_path.open('wb') as handle:
 subprocess.run(['git','archive',commit],cwd=root,stdout=handle,check=True)
with tarfile.open(archive_path) as tar:
 for member in tar.getmembers():
  if member.issym() or member.islnk() or member.isdev() or member.isfifo() or PurePosixPath(member.name).is_absolute() or '..' in PurePosixPath(member.name).parts:raise SystemExit('Unsafe isolated source member')
 tar.extractall(isolated,filter='data')
for item in manifest['paths']:
 target=isolated/item['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(out/'afterimages'/item['path'],target)
argv=[sys.executable,str(isolated/'scripts/traceability.py'),'generate','--repo',str(isolated)]
result=subprocess.run(argv,cwd=isolated,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(out/'traceability-generate.stdout').write_text(result.stdout);(out/'traceability-generate.stderr').write_text(result.stderr)
(out/'generation-command.json').write_text(json.dumps({'argv':argv,'cwd':str(isolated),'exit_code':result.returncode,'scope':'OUTSIDE_TREE_GENERATION_ONLY_NOT_PRODUCT_TEST'},indent=2)+'\n')
if result.returncode:raise SystemExit('Isolated generator rejected materialization; preserve attempt and repair outside')
shutil.copy2(isolated/'docs/REQUIREMENTS_TRACEABILITY.md',out/'afterimages/docs/REQUIREMENTS_TRACEABILITY.md')
patch='';entries=[]
for item in manifest['paths']:
 rel=item['path'];pre=(base/'preimages'/rel).read_bytes();post=(out/'afterimages'/rel).read_bytes()
 if any(token.encode() in post for token in manifest['required_substitutions']):raise SystemExit('Unresolved final placeholder '+rel)
 if pre!=post:patch+=f'diff --git a/{rel} b/{rel}\n'+''.join(difflib.unified_diff(pre.decode().splitlines(True),post.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 entries.append({'path':rel,'preimage_sha256':hashlib.sha256(pre).hexdigest(),'afterimage_sha256':hashlib.sha256(post).hexdigest()})
(out/'closeout-final.patch').write_text(patch)
final={'format_version':'W14_CLOSEOUT_MATERIALIZATION_1','scope':'Outside-only proposal; root sole apply authority. Actual frozen6384 clone PASS and completed full-run data audit bound before materialization; exact closure-patch source peer review still follows. No product command or root mutation.','source_commit':commit,'source_tree':tree,'paths':entries,'projection_sha256':projection_sha,'patch_sha256':hashlib.sha256((out/'closeout-final.patch').read_bytes()).hexdigest(),'source_facts_sha256':hashlib.sha256(Path(sys.argv[1]).read_bytes()).hexdigest(),'generation_exit_code':0,'pending_tokens':[],'root_mutations_tests_builds_browsers':0}
(out/'final-manifest.json').write_text(json.dumps(final,indent=2)+'\n');print(json.dumps(final,indent=2))
