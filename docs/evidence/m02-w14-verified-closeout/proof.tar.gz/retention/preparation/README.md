# Prepared W14 closure retention builder

Prepared only. Do not execute until explicit parent/root release. No builder import, compilation or execution was performed during preparation.

After that release, the intended command is:

```sh
python3 /tmp/japp-w14-closeout-retention-builder.py --after-root-release
```

The builder requires the explicit flag and creates a new outside-only directory at `/tmp/japp-w14-closeout-retained-20261017`. It refuses existing output, output outside `/tmp`, or output inside a retained source. `--output /tmp/another-new-directory` is available if the default already contains a prior result. It never applies a patch, imports repository code, runs validators/tests/builds/browsers, or writes to the source repository.

The seven fixed sources are `/tmp/japp-w14-closeout-template`, `/tmp/japp-w14-closeout-peer-review`, `/tmp/japp-refine-w14-closeout-freshness.py`, `/tmp/japp-w14-closeout-actual-facts-6384.json`, `/tmp/japp-w14-closure-focused-checks-20261017.py`, `/tmp/japp-w14-closure-root-checks-20261017`, and `/tmp/japp-w14-closeout-supplemental-review`. All are required at execution. Their actual files are enumerated then; preparation does not freeze an incomplete root-log or supplemental-review inventory. Exact current materialization, template, history, refiner, actual facts, focused root runner, prior sealed reviews and all retained failure/green root-check records are included. Every root-check attempt/history/generation record and final green wrapper present at release is captured. Builder source, this README and the preparation source manifest are included as provenance.

Excluded directory basenames are `isolated-tree`, `node_modules`, `.venv`, `__pycache__`, `.cache`, `cache`, `caches`, `.pytest_cache`, `.mypy_cache`, `.ruff_cache`, `.turbo`, `.pnpm-store`, `.uv-cache`, `.uv_cache`, `.vite`, and `.vitest`. Excluded files are `frozen-content.tar` and existing proof archives: case-insensitive basenames containing `proof` and ending in `.tar`, `.tar.gz`, `.tgz`, `.tar.bz2`, `.tbz2`, `.tar.xz`, `.txz`, `.tar.zst`, `.zip`, or `.7z`. Excluded subtrees are not traversed. The execution index records every encountered exclusion.

Encountered symlinks, special files, unsafe member names and duplicate member paths fail the build. Source files are opened without following leaf symlinks and checked for changes during reading. The archive contains sorted regular members only; gzip/tar timestamps and owner metadata are normalized, permissions are 0644, and original source permissions are recorded in the index. Identical source bytes/inventory yield identical archive bytes. No archive extraction occurs.

Outputs are `proof.tar.gz`, `archive.index.json`, and `retention-manifest.json`. The index records every source path, archive member, byte count and SHA-256. Before issuing the outer manifest, the builder compares every archive member byte-for-byte with captured source bytes, then captures all sources again and requires an unchanged inventory, exclusions and payloads. Failure leaves diagnostic output without a successful outer manifest; sources and prior archives remain untouched.
