#!/usr/bin/env python3
"""Build outside-only W14 closure retention after an explicit root release."""
from pathlib import Path, PurePosixPath
import argparse
import gzip
import hashlib
import io
import json
import os
import stat
import tarfile

SOURCES = (
    ("template", Path("/tmp/japp-w14-closeout-template")),
    ("peer-review", Path("/tmp/japp-w14-closeout-peer-review")),
    ("refiner", Path("/tmp/japp-refine-w14-closeout-freshness.py")),
    ("actual-facts", Path("/tmp/japp-w14-closeout-actual-facts-6384.json")),
    ("focused-runner", Path("/tmp/japp-w14-closure-focused-checks-20261017.py")),
    ("root-checks", Path("/tmp/japp-w14-closure-root-checks-20261017")),
    ("supplemental-review", Path("/tmp/japp-w14-closeout-supplemental-review")),
)
PREPARATION = Path("/tmp/japp-w14-closeout-retention-preparation")
EXCLUDED_DIRS = frozenset({
    "isolated-tree", "node_modules", ".venv", "__pycache__", ".cache",
    "cache", "caches", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".turbo",
    ".pnpm-store", ".uv-cache", ".uv_cache", ".vite", ".vitest",
})
ARCHIVE_SUFFIXES = (".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2", ".tar.xz", ".txz", ".tar.zst", ".zip", ".7z")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode()


def safe_name(name):
    path = PurePosixPath(name)
    if not name or path.is_absolute() or str(path) != name or "\\" in name:
        raise ValueError("Unsafe member path: " + repr(name))
    if any(part in ("", ".", "..") for part in path.parts) or any(ord(c) < 32 or ord(c) == 127 for c in name):
        raise ValueError("Unsafe member path: " + repr(name))
    return name


def read_regular(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError("Not a regular file (symlinks refused): " + str(path))
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(descriptor, "rb") as stream:
        opened = os.fstat(stream.fileno())
        data = stream.read()
        after = os.fstat(stream.fileno())
    signature = lambda value: (value.st_dev, value.st_ino, value.st_mode, value.st_size, value.st_mtime_ns, value.st_ctime_ns)
    if signature(before) != signature(opened) or signature(opened) != signature(after) or len(data) != after.st_size:
        raise ValueError("Source changed while reading: " + str(path))
    return data, stat.S_IMODE(after.st_mode)


def capture():
    payloads, records, excluded = {}, [], []

    def visit(path, member):
        safe_name(member)
        metadata = path.lstat()
        if stat.S_ISLNK(metadata.st_mode):
            raise ValueError("Symlink refused: " + str(path))
        if stat.S_ISDIR(metadata.st_mode):
            if path.name in EXCLUDED_DIRS:
                excluded.append({"source": str(path), "reason": "excluded directory"})
                return
            for child in sorted(path.iterdir(), key=lambda value: value.name):
                visit(child, member + "/" + child.name)
            return
        if not stat.S_ISREG(metadata.st_mode):
            raise ValueError("Special file refused: " + str(path))
        lowered = path.name.lower()
        if path.name == "frozen-content.tar" or ("proof" in lowered and lowered.endswith(ARCHIVE_SUFFIXES)):
            excluded.append({"source": str(path), "reason": "excluded existing proof/frozen-content archive"})
            return
        if member in payloads:
            raise ValueError("Duplicate member path: " + member)
        data, mode = read_regular(path)
        payloads[member] = data
        records.append({"member": member, "source": str(path), "bytes": len(data), "sha256": sha(data), "source_mode": mode})

    for label, source in SOURCES:
        if not source.exists() and not source.is_symlink():
            raise ValueError("Required execution-time source is missing: " + str(source))
        visit(source, label if source.is_dir() else label + "/" + source.name)
    visit(Path(__file__).absolute(), "retention/builder.py")
    visit(PREPARATION / "README.md", "retention/preparation/README.md")
    visit(PREPARATION / "source-manifest.json", "retention/preparation/source-manifest.json")
    return payloads, sorted(records, key=lambda value: value["member"]), sorted(excluded, key=lambda value: value["source"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--after-root-release", action="store_true", help="Explicitly attest that parent/root released retention execution.")
    parser.add_argument("--output", type=Path, default=Path("/tmp/japp-w14-closeout-retained-20261017"))
    args = parser.parse_args()
    if not args.after_root_release:
        parser.error("Execution is gated: pass --after-root-release only after explicit parent/root release.")
    destination = args.output.absolute().resolve()
    temporary_root = Path("/tmp").resolve()
    if destination == temporary_root or not destination.is_relative_to(temporary_root):
        parser.error("Output must be a new directory beneath /tmp; source-root writes are forbidden.")
    for _, source in SOURCES:
        if destination == source.resolve() or destination.is_relative_to(source.resolve()):
            parser.error("Output cannot be inside a retained source.")
    if destination.exists() or destination.is_symlink():
        parser.error("Output already exists; retained results are never overwritten.")

    payloads, records, excluded = capture()
    preparation = json.loads(payloads["retention/preparation/source-manifest.json"])
    if preparation["builder"]["sha256"] != sha(payloads["retention/builder.py"]) or preparation["readme"]["sha256"] != sha(payloads["retention/preparation/README.md"]):
        raise ValueError("Prepared builder/README commitment does not match actual bytes.")
    index = encoded({
        "format_version": "W14_CLOSURE_RETENTION_INDEX_1",
        "capture_policy": "All required sources, including root-check and supplemental-review files, are enumerated at execution time.",
        "fixed_sources": [{"label": label, "path": str(path)} for label, path in SOURCES],
        "exclusions": {"directory_names": sorted(EXCLUDED_DIRS), "frozen_content_basename": "frozen-content.tar", "proof_archive_rule": "case-insensitive basename contains proof and ends with one of archive_suffixes", "archive_suffixes": list(ARCHIVE_SUFFIXES), "observed": excluded},
        "files": records,
    })
    if "retention/index.json" in payloads:
        raise ValueError("Duplicate generated index member")
    payloads["retention/index.json"] = index
    names = sorted(payloads)
    destination.mkdir(parents=False, exist_ok=False)
    archive = destination / "proof.tar.gz"
    partial = destination / "proof.tar.gz.partial"
    with partial.open("xb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, compresslevel=9, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as bundle:
                for name in names:
                    safe_name(name)
                    member = tarfile.TarInfo(name)
                    member.size, member.mode, member.mtime = len(payloads[name]), 0o644, 0
                    member.uid = member.gid = 0
                    member.uname = member.gname = ""
                    bundle.addfile(member, io.BytesIO(payloads[name]))
    compared = 0
    with tarfile.open(partial, "r:gz") as bundle:
        members = bundle.getmembers()
        if [member.name for member in members] != names or len(set(member.name for member in members)) != len(names):
            raise ValueError("Archive member inventory/order differs from exact sorted source inventory")
        for member in members:
            safe_name(member.name)
            if not member.isfile() or member.linkname or member.size != len(payloads[member.name]):
                raise ValueError("Unsafe or changed archive member: " + member.name)
            with bundle.extractfile(member) as stream:
                if stream.read() != payloads[member.name]:
                    raise ValueError("Archive byte comparison failed: " + member.name)
            compared += 1
    final_payloads, final_records, final_excluded = capture()
    if final_records != records or final_excluded != excluded or any(final_payloads[name] != payloads[name] for name in final_payloads):
        raise ValueError("Sources changed during retention; no successful manifest will be issued")
    partial.rename(archive)
    (destination / "archive.index.json").write_bytes(index)
    archive_bytes = archive.read_bytes()
    manifest = {
        "format_version": "W14_CLOSURE_RETENTION_MANIFEST_1",
        "archive": "proof.tar.gz", "archive_sha256": sha(archive_bytes), "archive_bytes": len(archive_bytes),
        "index": "archive.index.json", "index_sha256": sha(index),
        "source_file_count": len(records), "regular_archive_member_count": len(names),
        "source_payload_bytes": sum(record["bytes"] for record in records),
        "exhaustive_archive_byte_comparison": {"matched": compared, "expected": len(names), "result": "PASS"},
        "source_recapture_unchanged": True, "builder_sha256": sha(payloads["retention/builder.py"]),
        "root_writes_product_tests_builds_browsers": 0,
    }
    (destination / "retention-manifest.json").write_bytes(encoded(manifest))
    print(json.dumps({"output": str(destination), "archive_sha256": manifest["archive_sha256"], "regular_members": len(names)}, sort_keys=True))


if __name__ == "__main__":
    main()
