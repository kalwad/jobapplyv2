from pathlib import Path
import difflib
import hashlib
import json
import shutil

base = Path('/tmp/japp-w14-closeout-template')
out = base / 'materialized'
history = out / 'history/materialization-001'
history.mkdir(parents=True)
shutil.copytree(out / 'afterimages', history / 'afterimages')
for name in ['closeout-final.patch', 'final-manifest.json', 'generation-command.json', 'traceability-generate.stdout', 'traceability-generate.stderr']:
    shutil.copyfile(out / name, history / name)

replacements = {
    'docs/KNOWN_ISSUES.md': (
        'A separate three-file source-only correction proposal2876a179 has peer source clearance; author failure-path verification/integration/current-source full verification remain separate records. No integrated fix or current behavioral PASS is claimed here.',
        'The final separate three-file correction98d6e14cd31514623bf5d93550ecd73dc65a0347fb81f3baf12d134319e2dcb8 has independent source clearance and actual focused author evidence: the same18 fake-context cases yield13 original failures/5 passes and18 candidate passes in355ms. Sparse outside type/lint/format/policy checks pass. Exact sources, logs and review are retained in docs/evidence/m02-w14-harness-cleanup/proof.tar.gz (SHA256a885cd4d29f950fbf067d60f4a8fc7b48753c308891f6938b5c284e82db891b9). Root integration, whole-repository/unit/controlled-browser and final clean-candidate/key-case validation remain pending; no integrated fix or current6384 behavioral PASS is claimed.'
    ),
    'docs/TEST_EVIDENCE.md': (
        'A separate source-only three-file proposal2876a179 has source peer clearance; its author failure-path verification, root integration and clean final-candidate full/key-case reproductions are corrective work before W15 final decision, not current6384 fix/PASS evidence.',
        'The final separate three-file correction98d6e14cd31514623bf5d93550ecd73dc65a0347fb81f3baf12d134319e2dcb8 is independently source-clear; actual focused author evidence is13 FAIL/5 PASS on the original harnesses and18 PASS in355ms on the candidate. Pinned Node24.18/Vitest4.1.10 logs, sparse outside type/lint/format/policy checks, original failures/history and all source reviews are retained in docs/evidence/m02-w14-harness-cleanup/proof.tar.gz, SHA256a885cd4d29f950fbf067d60f4a8fc7b48753c308891f6938b5c284e82db891b9. Root integration, complete repository/unit/controlled-browser checks and final clean-candidate/key-case reproductions remain corrective work before W15 final decision; outside author passes do not certify the unmodified6384 source as fixed.'
    ),
    'docs/gates/AUTOFILL_FEASIBILITY_GATE.md': (
        'The peer-cleared three-file proposal2876a179 is separate from the actually tested6384 source and supplies no current integrated-fix or behavioral PASS here.',
        'The final separate three-file correction98d6e14cd31514623bf5d93550ecd73dc65a0347fb81f3baf12d134319e2dcb8 is independently source-clear. Focused author tests record13 original failures/5 passes and18 candidate passes; sparse outside static checks pass. Exact source/proof/reviews are retained in docs/evidence/m02-w14-harness-cleanup/proof.tar.gz (SHA256a885cd4d29f950fbf067d60f4a8fc7b48753c308891f6938b5c284e82db891b9). Root integration, full repository/actual controlled-browser/final clean-candidate/key-case checks remain pending. This does not supply an integrated fix or behavioral PASS for the unmodified6384 source.'
    ),
}
for relative, (old, new) in replacements.items():
    path = out / 'afterimages' / relative
    text = path.read_text()
    assert text.count(old) == 1, relative
    path.write_text(text.replace(old, new))

evidence = out / 'afterimages/docs/TEST_EVIDENCE.md'
text = evidence.read_text()
text = text.replace('without a strict serial-order claim..', 'without a strict serial-order claim.')
text = text.replace('Historical exact1d native proof remains separately scoped..', 'Historical exact1d native proof remains separately scoped.')
old = 'Final closure-patch source review follows materialization and precedes root integration; it is not a prerequisite claimed complete by this template. These fields must come from completed retained observations; the template itself records no future command result.'
assert text.count(old) == 1
text = text.replace(old, 'The exact closure source review is recorded separately; root integration and focused closure checks remain pending until executed. All run fields above come from the completed retained6384 observations.')
marker = '\nW14 candidate evidence and retained manual synthetic inspection are '
assert text.count(marker) == 1
manual = '\nRoot also opened the fresh6384 synthetic Workday contact PNG with tools.view_image:108550bytes/SHA25623153f9458e6ada78419ed734abb00778b508d5bc1ea93f3792105cb889dd2ab. The research-only/GUEST banner, populated synthetic contact/address values and unchanged upload/date/contact-method/sensitive/consent controls were visually inspected. The static Next control supplies no click proof. Actual checklist and capture are retained in the104-member clean-clone archive and docs/evidence/m02-w14-frozen-6384d98/manual-inspection.json. This is one retained synthetic image observation, not a user study, public compatibility claim, accessibility certification or owner visual approval.\n'
text = text.replace(marker, manual + marker)
evidence.write_text(text)

manifest = json.loads((out / 'final-manifest.json').read_text())
patch = ''
for row in manifest['paths']:
    relative = row['path']
    before = (base / 'preimages' / relative).read_bytes()
    after = (out / 'afterimages' / relative).read_bytes()
    assert hashlib.sha256(before).hexdigest() == row['preimage_sha256']
    row['afterimage_sha256'] = hashlib.sha256(after).hexdigest()
    if before != after:
        patch += f'diff --git a/{relative} b/{relative}\n'
        patch += ''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile='a/' + relative, tofile='b/' + relative))
(out / 'closeout-final.patch').write_text(patch)
manifest['original_materialization_patch_sha256'] = manifest['patch_sha256']
manifest['patch_sha256'] = hashlib.sha256((out / 'closeout-final.patch').read_bytes()).hexdigest()
manifest['narrative_refresh'] = {
    'source': str(Path(__file__)),
    'sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'scope': 'Only3 narrative afterimages: current focused correction98d6/source proof and actual fresh synthetic image inspection. Tested6384 observations/states/metrics/trace projection unchanged.',
    'focused_proof_sha256': '11dd77fa091be1873e929fd94f5cbaa24ba88583f7e8b6215845a23c823a7a13',
    'cleanup_archive_sha256': 'a885cd4d29f950fbf067d60f4a8fc7b48753c308891f6938b5c284e82db891b9',
}
(out / 'final-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'patch_sha256': manifest['patch_sha256'], 'paths': len(manifest['paths']), 'original_preserved': str(history)}, indent=2))
