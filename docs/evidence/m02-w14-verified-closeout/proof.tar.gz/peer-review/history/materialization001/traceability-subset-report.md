# Original materialization001 traceability subset audit

Outcome: no blocker in this subset. This report pins the original e05 proposal; the parent's freshness finding is handled in a separate narrative refresh. Existing parent REPORT.md and retained source history were preserved.

- Patch SHA-256: `e05ba23f8c343675375b9f7514382d1dc13d0cd28d04c7c9b2115a40311e0cf2`.
- Manifest SHA-256: `8e9b44347481ad8f226cf77ce3d76d5a554d35440fb408656b6a6aad84f4b81b`.
- Audit JSON SHA-256: `1b87aa9882fa2b8d4dc77d61c4f780c2cd353382f747386faffb44e0e2d1b7c8`.
- Read-only replay script SHA-256: `b48cedcf0c61a10c60cb637ec9f80d2637e9b258edbfc54cc8f003ddef10c829`.
- Source commit: `6384d98156ae198cd93d7b35d1bb28b501ed475e`; source tree: `d2c1fd5e50bbbd31a926cbf251d6140d11b9b9c4`.

All nine preimage hashes match the manifest and were independently checked against the exact source commit. All nine original afterimage hashes match the manifest and original isolated-tree bytes. The retained original patch was replayed in memory against unchanged preimages and reproduces all nine retained original afterimages exactly. This second sealing pass reads only outside history/preimage files.

| Path | Preimage SHA-256 | Original afterimage SHA-256 |
|---|---|---|
| docs/PROJECT_STATUS.md | `5e392bfaee56b25cc189ecdff50ae9550d3386512b12f09583195b392c4fd41c` | `5673c9916abfe42cae11e4eb5072486fe767392c34de399da25755a4f1ea62bd` |
| docs/KNOWN_ISSUES.md | `6932364930b2469d6288a690884e0dbd86a843af4fa9606a53aa0296489d7fef` | `710aa3b76cad3958ed559ffda51e6a7728bb6df273e73a67839c4da4ea4eedc8` |
| docs/CRITICAL_GATES.md | `de2288a2ea4a9025b1c83845ca3b1c8089b8da07a0b3cfcbfe0777aee5d6396a` | `925f161e82cd916ce0ba8db4ac36016de33a1dbd14ee67019ce0834307f965f4` |
| docs/gates/AUTOFILL_FEASIBILITY_GATE.md | `d90ec355ed39e59a3e79521cb8f6d408a6b0db25b8cc538a8d174c11929230e8` | `2c71b53b8d4c23fec351be8ea6c031742ea5340fcbeac331371b7d6b7250e173` |
| docs/COMPATIBILITY_MATRIX.md | `49757e4284cef3eea9ee22e2bf4df0939dab1b42189533736f4560bf99acd3a9` | `ee16c7707dafbd65b4a96fb482cddf82d4a073d72d28a4bb0495bf82bc9a18d7` |
| docs/TEST_EVIDENCE.md | `bd5114d9e8fea57e68fcdc30be76365941288b33bbc13372288444f8400eb727` | `c6e3b9c9c62fd84f2a6448eb64c7721dc516893c881309bb8d564c5a4e1e3aeb` |
| docs/traceability.json | `be27b5ab96fc9a27db3d6c0eeec4ad0ff96744aef55a601cfd6f6a354df1e8aa` | `f9d2c055a7c9f9b1682503efa647d8f77c7e5bbe8a842528171f92a868f669d0` |
| docs/REQUIREMENTS_TRACEABILITY.md | `26714c43036926a3e668b79a6198d9016a9438a24deab7d6f34f6ed2076d828e` | `2c15d40154fb441542b142bf3af651c7dc0dd6c0c7308adc07176acd5dc78f80` |
| scripts/traceability.py | `a7644b031d06b0aa670762f28ac384d8dccd3c4f3411983ab381d78444f1002a` | `0d27cb4858ed44cc270b2dbcae97e0739ad9126225748632259efbfbd04e499b` |

The validator delta is six added history-comment lines and the current v1.4 requirement projection constant. Restoring that constant makes the pre/post ASTs identical. Independently computed requirement projection changes from `70424088492737b18171ea26872c3dff40461411726162f863c9f693e0144802` to `15ea76b48b519df4673bc351dc8a8d8e3a850129d82efffd7fdd0a3964116640`; metadata, validator and manifest agree. The package dependency/proof-plan projection remains `ea991a047062a72281a8f5bf77942d2a2dc0a1cf153c2a849bc040d4972c48c1`.

All historical v1.2/v1.3 hash constants and metadata remain unchanged immutable snapshots. All 193 requirement IDs/text/families/owners/plans/gate effects/review provenance/verification states remain unchanged. All 300 package dependency/proof-plan projections remain unchanged. Only four requirements receive scoped code/test/evidence/notes updates; FORM-025 and GATE-004 advance to scaffold, and all four remain SCAFFOLD_ONLY / NOT_YET_APPLICABLE with explicit future portions. Every completed code/test reference exists. Only W14/W15 package live fields change; critical-gate metadata and dependency policy remain unchanged.

Canonical specification and DECISIONS.md, including ADR-0007, were checked byte-for-byte against the exact source commit. Specification SHA-256 remains `3eba7bdfbbb1591b5ea54c31bc415fc0cbfd3c361d32005b328f27a12f3ac943`; decisions SHA-256 remains `805b5ea2f7fa17c6007b991cc0dca3a228c7d4baf7cc6a9b1953f5635ef88413`. Historical hashes preserve prior snapshot semantics; the new v1.4 hash locks the complete current honesty/ownership/gate-effect projection rather than rewriting those historical layers.

No repository validator, product test/build/browser action, archived executable, patch application or source-root mutation was performed. The replay script uses standard-library JSON/AST/hash/diff data processing only.
