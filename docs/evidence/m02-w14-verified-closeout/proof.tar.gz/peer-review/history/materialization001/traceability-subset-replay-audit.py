#!/usr/bin/env python3
"""Read-only hash/replay audit; never imports repository code or applies a patch."""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import re

REQ_KEYS = ['id','owning_packages','planned_components','automated_test_layers','manual_evidence','gate_effects','mapping_review_state','implementation_state','verification_state','completed_code_paths','completed_test_paths','current_evidence','notes']
PKG_KEYS = ['id','direct_package_prerequisites','milestone_prerequisites','critical_gate_prerequisites','accepted_milestone_prerequisites','downstream_packages','downstream_milestones','primary_deliverables','required_automated_verification','required_manual_evidence','dependency_review_state']
IMMUTABLE_REQ_KEYS = ['id','text','family','owning_packages','planned_components','automated_test_layers','manual_evidence','gate_effects','mapping_review_state','verification_state']

def sha(data):
    return hashlib.sha256(data).hexdigest()

def inventory_sha(rows):
    return sha(json.dumps(rows,ensure_ascii=False,separators=(',',':'),sort_keys=True).encode())

def replay(section,preimage):
    lines=section.splitlines(keepends=True)
    source=preimage.decode().splitlines(keepends=True)
    output=[]
    cursor=0
    index=3
    while index<len(lines):
        match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[index])
        assert match,lines[index]
        start=int(match[1])-1
        output.extend(source[cursor:start])
        cursor=start
        index+=1
        old_count=new_count=0
        while index<len(lines) and not lines[index].startswith('@@ '):
            line=lines[index]
            index+=1
            assert line[:1] in (' ','-','+'),line
            if line[0] in (' ','-'):
                assert source[cursor]==line[1:],(cursor,line)
                cursor+=1
                old_count+=1
            if line[0] in (' ','+'):
                output.append(line[1:])
                new_count+=1
        assert old_count==int(match[2] or 1)
        assert new_count==int(match[4] or 1)
    output.extend(source[cursor:])
    return ''.join(output).encode()

def audit(snapshot,preimages,isolated=None):
    snapshot=Path(snapshot)
    preimages=Path(preimages)
    manifest_bytes=(snapshot/'final-manifest.json').read_bytes()
    manifest=json.loads(manifest_bytes)
    patch=(snapshot/'closeout-final.patch').read_bytes()
    assert sha(patch)==manifest['patch_sha256']
    sections=re.split(r'(?=^diff --git )',patch.decode(),flags=re.M)[1:]
    assert len(sections)==len(manifest['paths'])==9
    facts=[]
    for section,row in zip(sections,manifest['paths']):
        match=re.fullmatch(r'diff --git a/(.+) b/(.+)',section.splitlines()[0])
        assert match and match[1]==match[2]==row['path']
        path=row['path']
        before=(preimages/path).read_bytes()
        after=(snapshot/'afterimages'/path).read_bytes()
        item=dict(row)
        item.update(preimage_manifest_match=sha(before)==row['preimage_sha256'],afterimage_manifest_match=sha(after)==row['afterimage_sha256'],patch_replay_equals_afterimage=replay(section,before)==after)
        if isolated is not None:
            item['isolated_afterimage_manifest_match']=sha((Path(isolated)/path).read_bytes())==row['afterimage_sha256']
        assert all(value for key,value in item.items() if key.endswith('_match') or key=='patch_replay_equals_afterimage')
        facts.append(item)
    before=json.loads((preimages/'docs/traceability.json').read_text())
    after=json.loads((snapshot/'afterimages/docs/traceability.json').read_text())
    req_hash=inventory_sha([[row.get(key) for key in REQ_KEYS] for row in after['requirements']])
    pkg_hash=inventory_sha([[row.get(key) for key in PKG_KEYS] for row in after['work_packages']])
    assert req_hash==manifest['projection_sha256']==after['review']['v1_4_requirements_mapping_sha256']
    assert pkg_hash==before['review']['v1_4_work_package_dependency_sha256']==after['review']['v1_4_work_package_dependency_sha256']
    before_ast=ast.parse((preimages/'scripts/traceability.py').read_text())
    after_ast=ast.parse((snapshot/'afterimages/scripts/traceability.py').read_text())
    before_constants={n.targets[0].id:n.value.value for n in before_ast.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and isinstance(n.value,ast.Constant)}
    after_constants={n.targets[0].id:n.value.value for n in after_ast.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and isinstance(n.value,ast.Constant)}
    constant_deltas={key:[before_constants.get(key),after_constants.get(key)] for key in sorted(set(before_constants)|set(after_constants)) if before_constants.get(key)!=after_constants.get(key)}
    assert list(constant_deltas)==['FINAL_V1_4_REQUIREMENT_MAPPING_SHA256']
    for node in after_ast.body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='FINAL_V1_4_REQUIREMENT_MAPPING_SHA256' for t in node.targets):
            node.value=ast.Constant(before_constants['FINAL_V1_4_REQUIREMENT_MAPPING_SHA256'])
    ast_preserved=ast.dump(before_ast,include_attributes=False)==ast.dump(after_ast,include_attributes=False)
    assert ast_preserved
    immutable_req=all(all(x[key]==y[key] for key in IMMUTABLE_REQ_KEYS) for x,y in zip(before['requirements'],after['requirements']))
    immutable_pkg=all(all(x[key]==y[key] for key in PKG_KEYS) for x,y in zip(before['work_packages'],after['work_packages']))
    unchanged_root={key:before[key]==after[key] for key in ['schema_version','specification','enums','dependency_policy','critical_gates']}
    historical={key:after['review'][key] for key in ['requirements_mapping_sha256','work_package_dependency_sha256','expanded_requirements_mapping_sha256','expanded_work_package_dependency_sha256','v1_4_prior_requirement_inventory_sha256']}
    assert all(before['review'][key]==value for key,value in historical.items())
    assert immutable_req and immutable_pkg and all(unchanged_root.values())
    mixed=[{key:row[key] for key in ['id','implementation_state','verification_state','owning_packages','notes']} for row in after['requirements'] if row['id'] in ['REQ-FORM-025','REQ-GATE-004','REQ-GATE-007','REQ-GATE-008']]
    assert len(mixed)==4 and all(row['implementation_state']=='SCAFFOLD_ONLY' and row['verification_state']=='NOT_YET_APPLICABLE' for row in mixed)
    return {'scope':'Outside-only source/data audit; no repository validators, tests, builds, browser actions, patch application, or root writes.','snapshot':str(snapshot),'source_commit':manifest['source_commit'],'source_tree':manifest['source_tree'],'patch_sha256':sha(patch),'manifest_sha256':sha(manifest_bytes),'path_count':9,'paths':facts,'traceability':{'requirement_count':len(after['requirements']),'package_count':len(after['work_packages']),'requirement_projection_sha256':req_hash,'dependency_projection_sha256':pkg_hash,'historical_hashes':historical,'all_requirement_immutable_fields_preserved':immutable_req,'all_package_dependency_proof_fields_preserved':immutable_pkg,'unchanged_root_fields':unchanged_root,'validator_constant_deltas':constant_deltas,'validator_ast_preserved_after_reverting_projection_constant':ast_preserved,'mixed_requirements':mixed}}

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('snapshot')
    parser.add_argument('preimages')
    parser.add_argument('--isolated')
    args=parser.parse_args()
    print(json.dumps(audit(args.snapshot,args.preimages,args.isolated),indent=2)+'\n',end='')
