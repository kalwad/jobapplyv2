from pathlib import Path
import subprocess,os,time,datetime,hashlib,json,sys
root=Path('/Users/tanishkalwad/jobapplyv2')
out=Path('/tmp/japp-w14-closure-root-checks-20261017')
env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@24/bin:'+env['PATH']
steps=[('status',['uv','run','python','scripts/validate_status.py']),('traceability',['pnpm','traceability:check']),('ruff',['uv','run','ruff','check','scripts/traceability.py','scripts/tests/test_traceability.py']),('ruff-format',['uv','run','ruff','format','--check','scripts/traceability.py','scripts/tests/test_traceability.py']),('mypy',['uv','run','mypy','scripts/traceability.py','scripts/tests/test_traceability.py']),('diff',['git','diff','--check']),('pytest',['uv','run','pytest','scripts/tests/test_validate_status.py','scripts/tests/test_traceability.py','-q'])]
records=[]
for name,argv in steps:
 print('RUN '+name,flush=True);start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 with (out/(name+'.log')).open('wb') as f:r=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 b=(out/(name+'.log')).read_bytes();record=dict(name=name,argv=argv,cwd=str(root),started_at=start,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=r.returncode,elapsed_seconds=time.monotonic()-t,log_bytes=len(b),sha256=hashlib.sha256(b).hexdigest());records.append(record)
 (out/'commands.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),records=records),indent=2)+'\n');print(json.dumps(record),flush=True)
 print(b.decode(errors='replace')[-1500:],flush=True)
 if r.returncode:sys.exit(r.returncode)
