"""Reviewer-owned stdlib data/AST checks and fixed read-only Git metadata."""
from pathlib import Path
import ast,hashlib,json,os,re,stat,subprocess,tarfile
P=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/ubuntu-gnome-lifecycle-preparation/v5');V4=P.parent/'v4';OUT=Path(__file__).parent;ROOT=Path('/Users/tanishkalwad/jobapplyv2');HEAD='80e68ac9a24cd7ebf2874af625b866a055b9abe6';rows=[]
def ck(n,v,d=None):rows.append({'name':n,'pass':bool(v),'detail':d})
def doc(p):return json.loads(p.read_bytes())
def pin(p):
 a=p.lstat()
 if not stat.S_ISREG(a.st_mode):raise ValueError('nonregular '+str(p))
 h=hashlib.sha256();size=0
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b);size+=len(b)
 z=p.lstat()
 if (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_mode)!=(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns,z.st_mode) or size!=a.st_size:raise ValueError('changed '+str(p))
 return {'bytes':size,'mode':stat.S_IMODE(a.st_mode),'sha256':h.hexdigest()}
source=doc(P/'SOURCE.json');adopt=doc(P/'ADOPTION.json');manifest=doc(P/'MANIFEST.json');seal=doc(P/'SEAL.json')
for n,h in {'SOURCE.json':'d42eac5761a4d6295b5fca401021329504f5927912b5a5fd93d782bb066d8ba9','ADOPTION.json':'e87114e435dc511b8c5f7942b1d49300446fd0f3578a6163010162c67ba8b572','MANIFEST.json':'b3608e97f3d0cc61267d3ed602675813f2b08bf70fb43cb49cd65c735a7e874b','SEAL.json':'2902d5a8059f9a704785672af72395bc6089c17549d0b5159d1778a1d290569a'}.items():ck('root_pin:'+n,pin(P/n)['sha256']==h)
start={n:pin(P/'final-after'/n) for n in source['files']};ck('count38',len(start)==source['count']==38)
for n,r in source['files'].items():ck('source:'+n,start[n]==r);ck('working_after:'+n,pin(P/'after'/n)==r)
for key,n in [('source','SOURCE.json'),('adoption','ADOPTION.json'),('handoff','HANDOFF.md'),('manifest','MANIFEST.json'),('checks','FINAL-CHECKS.json'),('summary','SUMMARY.json'),('archive','proof-source-and-data.tar.gz')]:ck('seal:'+key,pin(P/n)==seal[key])
for n,r in manifest['files'].items():
 ck('safe_relative:'+n,not Path(n).is_absolute() and '..' not in Path(n).parts)
 ck('retained:'+n,pin(P/n)==r)
ck('manifest_count',len(manifest['files'])==manifest['count']==139)
for r in adopt['files']:
 ck('adopt_after:'+r['path'],pin(Path(r['after']))==r['after_pin']==source['files'][r['path']])
 if r['before']:ck('adopt_before:'+r['path'],pin(Path(r['before']))==r['before_pin'])
ck('adoption31',len(adopt['files'])==31 and adopt['operations']=={'ADD':23,'MODIFY':8} and len(adopt['reference_only'])==7)
with tarfile.open(P/'proof-source-and-data.tar.gz','r:gz') as tf:
 seen=set()
 for m in tf:
  n=m.name;ck('proof_safe:'+n,m.isfile() and not Path(n).is_absolute() and '..' not in Path(n).parts and n not in seen);seen.add(n)
  b=tf.extractfile(m).read();ck('proof_member:'+n,{'bytes':len(b),'mode':m.mode,'sha256':hashlib.sha256(b).hexdigest()}==pin(P/n))
 ck('proof_exact_set',seen==set(manifest['files'])|{'MANIFEST.json'} and len(seen)==seal['safe_regular_archive_members']==140)
oldsource=doc(V4/'SOURCE.json');delta={n for n in start if start[n]!=oldsource['files'][n]};want={'scripts/linux_gnome/ubuntu_gnome_vm.py','scripts/tests/test_ubuntu_gnome_review_regressions.py','scripts/python-test-inventory.v1.json'}
ck('exact3delta',delta==want and source['files'].keys()==oldsource['files'].keys())
for r in doc(P/'DELTA-FROM-V4.json')['changes']:ck('delta_pin:'+r['path'],r['v4']==oldsource['files'][r['path']] and r['v5']==start[r['path']])
ck('v4_source_preserved',pin(V4/'SOURCE.json')['sha256']=='3e8e6dc3d025898c34f99576aa8a2a563c6f5bd0024245f5bad839139d82dc33')
ck('v4_hold_preserved',pin(OUT.parent/'v4/REVIEW.md')['sha256']=='89512bdcb15f7273926ee94584c8d49bd26ee13ffb28d06c32d7a01052ed10db')
for n,r in oldsource['files'].items():ck('v4_body_preserved:'+n,pin(V4/'final-after'/n)==r)
# Verify all 2187 archived baseline bodies against actual immutable Git blob IDs, streaming large data.
command=['/usr/bin/git','--no-pager','--no-optional-locks','-C',str(ROOT),'ls-tree','-r','-z',HEAD]
g=subprocess.run(command,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,check=True,env={'PATH':'/usr/bin:/bin','LC_ALL':'C','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0'})
git={}
for r in g.stdout.split(b'\0'):
 if not r:continue
 meta,n=r.split(b'\t',1);mode,kind,oid=meta.decode().split();assert kind=='blob' and mode in ('100644','100755');git[n.decode()]=(mode,oid)
ck('git2187',len(git)==2187)
archive=P/'composed/canonical-source.tar';composition=doc(P/'COMPOSITION-FINAL.json');ck('immutable_archive_pin',pin(archive)==composition['immutable_archive'])
base={};seen=set()
with tarfile.open(archive,'r:') as tf:
 for m in tf:
  if m.isdir():continue
  n=m.name;ck('git_archive_safe:'+n,m.isfile() and not Path(n).is_absolute() and '..' not in Path(n).parts and n not in seen);seen.add(n)
  s1=hashlib.sha1(b'blob '+str(m.size).encode()+b'\0');s256=hashlib.sha256();count=0;stream=tf.extractfile(m)
  while b:=stream.read(1024*1024):s1.update(b);s256.update(b);count+=len(b)
  mode='100755' if m.mode&0o111 else '100644';ck('actual_git_blob:'+n,(mode,s1.hexdigest())==git.get(n) and count==m.size)
  base[n]={'bytes':count,'mode':0o755 if mode=='100755' else 0o644,'sha256':s256.hexdigest()}
 ck('git_archive_exact_set',seen==git.keys())
expected={**base,**source['files']};before=doc(P/'before-final.json');after=doc(P/'after-final.json');ck('source_endpoints_equal',before==after)
ck('actual2210_expected',len(expected)==2210 and expected==before['source_files'])
ck('overlay38_endpoints',before['overlay']==source['files'])
for n,r in expected.items():ck('actual_composed:'+n,pin(P/'composed/repo'/n)==r)
# Earlier QA snapshot explicitly predates only mechanical inventory update.
pre=doc(P/'SOURCE-BEFORE-QA.json')['files'];ck('pre_QA_only_inventory_delta',{n for n in pre if pre[n]!=source['files'][n]}=={'scripts/python-test-inventory.v1.json'})
checks=doc(P/'FINAL-CHECKS.json')['commands'];ck('12final_receipts',len(checks)==12)
for name,r in checks.items():
 ck('closed:'+name,r['exit_code']==0 and r['direct_child_reaped'] and r['group_after_reap']=='ABSENT' and r['signals']==[] and r['error'] is None)
 ck('receipt:'+name,doc(P/'checks'/name/'receipt.json')==r)
 for stream in ('stdout','stderr'):
  q=pin(P/'checks'/name/stream);ck('raw:'+name+':'+stream,{k:q[k] for k in ('bytes','sha256')}==r[stream])
raw=(P/'checks/pure-final/stdout').read_text();ck('407summary',bool(re.search(r'^407 passed in 6\.64s$',raw,re.M)))
collected=(P/'checks/collect/stdout').read_text();ids=[r for r in collected.splitlines() if re.match(r'^(scripts|services|packages)/.+::',r)]
new=doc(P/'final-after/scripts/python-test-inventory.v1.json');old=doc(V4/'final-after/scripts/python-test-inventory.v1.json');basecat=doc(P/'preimages/scripts/python-test-inventory.v1.json')
ck('2477collection',len(ids)==len(set(ids))==2477 and set(ids)==set(new['common']['node_ids'])|set(new['posix_only_node_ids']))
ck('all2474preserved',set(old['common']['node_ids'])<=set(new['common']['node_ids']) and old['posix_only_node_ids']==new['posix_only_node_ids'])
ck('all2141preserved',set(basecat['common']['node_ids'])<=set(new['common']['node_ids']) and basecat['posix_only_node_ids']==new['posix_only_node_ids'])
ck('3new336common',len(set(new['common']['node_ids'])-set(old['common']['node_ids']))==3 and len(set(new['common']['node_ids'])-set(basecat['common']['node_ids']))==336 and new['common']['count']==2475)
ck('new_digest',hashlib.sha256(('\n'.join(new['common']['node_ids'])+'\n').encode()).hexdigest()==new['common']['sha256'])
# Intended RED and current focused GREEN; source body remains old VM for RED.
ck('testfirst_actual_vm_v4',pin(P/'test-first-source/scripts/linux_gnome/ubuntu_gnome_vm.py')==oldsource['files']['scripts/linux_gnome/ubuntu_gnome_vm.py'])
red=(P/'checks/test-first/stdout').read_text();ck('intendedRED',bool(re.search(r'2 failed, 1 passed',red)))
focus=(P/'checks/focused-corrections/stdout').read_text();ck('focused11',bool(re.search(r'^11 passed in ',focus,re.M)))
# Record parsed definitions only; never import target modules.
parsed={n:[getattr(v,'name',type(v).__name__) for v in ast.parse((P/'final-after'/n).read_text()).body] for n in want if n.endswith('.py')}
end={n:pin(P/'final-after'/n) for n in source['files']};ck('review_source_endpoints',start==end)
(OUT/'data-joins.json').write_text(json.dumps({'scope':'Read-only exact data/AST/Git archive joins; no candidate execution','total':len(rows),'pass_count':sum(r['pass'] for r in rows),'joins':rows,'source_start':start,'source_end':end,'parsed_changed_files':parsed,'metadata_command':{'argv':command,'exit_code':g.returncode,'stdout_bytes':len(g.stdout),'stdout_sha256':hashlib.sha256(g.stdout).hexdigest(),'stderr_bytes':len(g.stderr)}},indent=2)+'\n')
print(json.dumps({'total':len(rows),'pass':sum(r['pass'] for r in rows),'failed':[r for r in rows if not r['pass']]}))
