"""Read-only stdlib data/AST audit; never imports or executes subject source."""
from pathlib import Path
import ast, hashlib, json, re, stat
SUBJECT=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/ubuntu-gnome-lifecycle-preparation/v3')
OUT=Path(__file__).parent
V2=SUBJECT.parent/'v2'
CANON=Path('/Users/tanishkalwad/jobapplyv2')
rows=[]
def check(label, value, detail=None):
 rows.append({'label':label,'pass':bool(value),'detail':detail})
def pin(path):
 a=path.lstat()
 if not stat.S_ISREG(a.st_mode): raise ValueError('not regular '+str(path))
 b=path.read_bytes(); z=path.lstat()
 if (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_mode)!=(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns,z.st_mode) or len(b)!=a.st_size: raise ValueError('changed '+str(path))
 return {'bytes':len(b),'mode':stat.S_IMODE(a.st_mode),'sha256':hashlib.sha256(b).hexdigest()}
def doc(path):return json.loads(path.read_bytes())
def defs(path):
 tree=ast.parse(path.read_text())
 return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
s=doc(SUBJECT/'SOURCE.json'); a=doc(SUBJECT/'ADOPTION.json'); m=doc(SUBJECT/'MANIFEST.json')
check('exact_source_pin',pin(SUBJECT/'SOURCE.json')['sha256']=='73d439780520d31203c79a51cf0f8336ae7baeefa790caa8a17500463438fc51')
check('exact_adoption_pin',pin(SUBJECT/'ADOPTION.json')['sha256']=='f2676b7918352651ce252f09b6c237773ddeadf7571174014beaa37d7bce59e8')
check('source_count',len(s['files'])==s['count']==30)
source_start={n:pin(SUBJECT/'final-after'/n) for n in s['files']}
for n,p in s['files'].items():check('source:'+n,source_start[n]==p)
actual_files={str(x.relative_to(SUBJECT/'final-after')) for x in (SUBJECT/'final-after').rglob('*') if x.is_file() and '__pycache__' not in x.parts}
check('exact_final_source_set',actual_files==s['files'].keys())
check('adoption_count',len(a['files'])==22 and sum(x['operation']=='ADD' for x in a['files'])==18 and sum(x['operation']=='MODIFY' for x in a['files'])==4)
check('adoption_paths',sorted(x['path'] for x in a['files'])==sorted(doc(SUBJECT/'ADOPTION-PATHS.json')))
for row in a['files']:
 check('adopt_after:'+row['path'],pin(Path(row['after']))==row['after_pin']==s['files'][row['path']])
 if row['operation']=='MODIFY':
  check('adopt_before:'+row['path'],pin(Path(row['before']))==row['before_pin'])
  check('canonical_finite_preimage:'+row['path'],pin(CANON/row['path'])==row['before_pin'])
 else:check('canonical_new_path:'+row['path'],not (CANON/row['path']).exists())
seen=set()
for row in m['files']:
 n=row['path']; check('manifest_path:'+n,n not in seen and not Path(n).is_absolute() and '..' not in Path(n).parts);seen.add(n)
 check('manifest_member:'+n,pin(SUBJECT/n)=={k:row[k] for k in ('bytes','mode','sha256')})
check('manifest_count',len(seen)==262)
for n,p in doc(V2/'SOURCE.json')['files'].items():check('v2_source_unchanged:'+n,pin(V2/n)==p)
for name,expected in s['parent_seals_verified_unchanged'].items():
 root=SUBJECT/name;seal=doc(root/'SEAL.json')
 check('parent_seal:'+name,pin(root/'SEAL.json')['sha256']==expected)
 for row in seal['files']:
  p=pin(root/row['path']);check('parent_member:'+name+'/'+row['path'],p['bytes']==row['size'] and p['sha256']==row['sha256'])
# Immutable before/after full final snapshots and all ten retained command closures.
before=doc(SUBJECT/'final-checks/source-before.json');after=doc(SUBJECT/'final-checks/source-after.json')
check('actual_final_source_endpoints',before==after==s['files'])
commands=doc(SUBJECT/'final-checks/commands.json')
check('ten_final_commands',len(commands)==10)
for row in commands:
 check('closed_command:'+row['name'],row['exit_code']==0 and row['direct_child_reaped'] and row['group_after_reap']=='ABSENT' and row['signals']==[])
 for stream in ('stdout','stderr'):check('raw_command:'+row['name']+':'+stream,pin(SUBJECT/'final-checks'/(row['name']+'.'+stream))==row[stream])
quality=[x['path'] for x in a['files'] if x['path'].endswith('.py')]
check('quality_exact_18',len(quality)==18)
for row in commands[:3]:
 check('quality_source_set:'+row['name'],all(n in row['argv'] for n in quality))
check('mypy_linux_target',commands[2]['argv'][commands[2]['argv'].index('--platform')+1]=='linux')
config=ast.parse((SUBJECT/'validate-final.py').read_text())
check('observer_reads_final_after',"ROOT=BASE/'final-after'" in (SUBJECT/'validate-final.py').read_text())
raw=(SUBJECT/'final-checks/pytest.stdout').read_text()
check('actual_296_pytest_summary',bool(re.search(r'^296 passed in 1\.40s$',raw,re.M)))
check('actual_296_progress_outcomes',sum(line.count('.') for line in raw.splitlines()[:-1])==296)
# All original 20 v2 test bodies and decorators, not merely names, preserved.
old=defs(V2/'after/scripts/tests/test_ubuntu_gnome_boundaries.py');new=defs(SUBJECT/'final-after/scripts/tests/test_ubuntu_gnome_boundaries.py')
for name,value in old.items():
 if name.startswith('test_'):check('old_boundary_oracle:'+name,new.get(name)==value)
# Legacy generic checker definitions unchanged except four deliberate extension points.
old=defs(SUBJECT/'preimages/scripts/check_portability.py');new=defs(SUBJECT/'final-after/scripts/check_portability.py')
allowed={'_native_package_steps','_check_artifacts','run_checks'}
for name,value in old.items():
 if name not in allowed:check('original_ci_policy:'+name,new.get(name)==value)
check('exact_checker_changed_functions',{n for n,v in old.items() if new.get(n)!=v}==allowed)
old=defs(SUBJECT/'preimages/scripts/tests/test_ci_workflow.py');new=defs(SUBJECT/'final-after/scripts/tests/test_ci_workflow.py')
for name,value in old.items():
 if name!='test_workflows_dir_contains_only_ci':check('original_ci_oracle:'+name,new.get(name)==value)
# Exact auxiliary workflow pins are independent literals in checker and oracle.
for n in ('ubuntu-gnome-prepare.yml','ubuntu-gnome-lifecycle.yml'):
 p=source_start['.github/workflows/'+n]
 for target in ('scripts/check_portability.py','scripts/tests/test_ci_workflow.py'):
  text=(SUBJECT/'final-after'/target).read_text();check('literal_workflow_pin:'+target+':'+n,p['sha256'] in text and str(p['bytes']) in text)
# Parsed source map is evidence of read-only AST traversal, not execution.
syntax={}
for n in s['files']:
 if n.endswith('.py'):
  tree=ast.parse((SUBJECT/'final-after'/n).read_text());syntax[n]=[{'kind':type(v).__name__,'name':getattr(v,'name',None),'line':v.lineno,'end':v.end_lineno} for v in tree.body]
source_end={n:pin(SUBJECT/'final-after'/n) for n in s['files']}
check('review_final_source_endpoints_equal',source_start==source_end)
(OUT/'data-joins.json').write_text(json.dumps({'scope':'Read-only exact data/AST joins; source HOLD verdict independent of passing retained-data checks','joins':rows,'pass_count':sum(x['pass'] for x in rows),'total':len(rows),'source_start':source_start,'source_end':source_end},indent=2)+'\n')
(OUT/'parsed-source-map.json').write_text(json.dumps(syntax,indent=2)+'\n')
print(json.dumps({'total':len(rows),'pass':sum(x['pass'] for x in rows),'failed':[r for r in rows if not r['pass']]}))
