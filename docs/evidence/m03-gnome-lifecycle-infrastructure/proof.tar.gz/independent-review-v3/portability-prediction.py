"""AST-only application of retained literal policy; no subject import/execution."""
from pathlib import Path
import ast,json,re
SUBJECT=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/ubuntu-gnome-lifecycle-preparation/v3/final-after')
OUT=Path(__file__).parent
pattern=re.compile(r'(?<![\w:/#.-])/(?:tmp|bin|usr|etc|var)(?![\w.-])')
rows=[]
for p in sorted((SUBJECT/'scripts').glob('ubuntu_gnome_*.py')):
 t=ast.parse(p.read_text());excluded=set()
 for n in ast.walk(t):
  if isinstance(n,(ast.Module,ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)) and n.body and isinstance(n.body[0],ast.Expr) and isinstance(n.body[0].value,ast.Constant) and isinstance(n.body[0].value.value,str):excluded.add(id(n.body[0].value))
  if isinstance(n,ast.arg) and n.annotation:excluded.update(id(x) for x in ast.walk(n.annotation))
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.returns:excluded.update(id(x) for x in ast.walk(n.returns))
  if isinstance(n,ast.AnnAssign):excluded.update(id(x) for x in ast.walk(n.annotation))
 for n in ast.walk(t):
  if isinstance(n,ast.Constant) and isinstance(n.value,str) and id(n) not in excluded and pattern.search(n.value):rows.append({'rule':'PORT-SRC-001','file':str(p.relative_to(SUBJECT)),'line':n.lineno,'literal':n.value})
  if isinstance(n,ast.Attribute) and n.attr=='chmod':rows.append({'rule':'PORT-SRC-004','file':str(p.relative_to(SUBJECT)),'line':n.lineno,'operation':'.chmod'})
 counts={rule:sum(x['rule']==rule for x in rows) for rule in sorted({x['rule'] for x in rows})}
(OUT/'portability-prediction.json').write_text(json.dumps({'scope':'Static prediction from unchanged source scanner, not an executed checker result; excludes any manual-separator predictions','counts':counts,'findings':rows},indent=2)+'\n')
print(json.dumps({'counts':counts,'total':len(rows)}))
