from pathlib import Path
import datetime,hashlib,json,os,signal,stat,subprocess,time
R=Path('/Users/tanishkalwad/jobapplyv2');O=Path(__file__).parent/'quality';O.mkdir(exist_ok=False)
def dump(n,x):(O/n).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def snap():
 rows={}
 for raw in subprocess.check_output(['git','ls-files','-z'],cwd=R).split(b'\0'):
  if not raw:continue
  p=R/os.fsdecode(raw);s=p.lstat();assert stat.S_ISREG(s.st_mode)
  b=p.read_bytes();rows[os.fsdecode(raw)]={'bytes':len(b),'mode':stat.S_IMODE(s.st_mode),'sha256':hashlib.sha256(b).hexdigest()}
 return {'files':rows,'status':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=R,text=True).strip()}
before=snap();dump('before.json',before);(O/'executed-wrapper.py').write_bytes(Path(__file__).read_bytes())
env=dict(os.environ);env['PATH']='/opt/homebrew/opt/node@24/bin:/Users/tanishkalwad/.local/share/uv/python/cpython-3.12.13-macos-aarch64-none/bin:'+env['PATH']
cmds=[['uv', 'run', '--no-sync', '--offline', 'ruff', 'check', '--config', 'pyproject.toml', 'scripts/check_portability.py', 'scripts/linux_gnome', 'scripts/tests'], ['uv', 'run', '--no-sync', '--offline', 'ruff', 'format', '--check', '--config', 'pyproject.toml', 'scripts/check_portability.py', 'scripts/linux_gnome', 'scripts/tests'], ['uv', 'run', '--no-sync', '--offline', 'mypy', '--config-file', 'pyproject.toml', '--platform', 'linux', 'scripts/check_portability.py', 'scripts/linux_gnome', 'scripts/tests'], ['pnpm', 'exec', 'prettier', '--check', 'package.json', 'scripts/verification-suites.json', 'scripts/python-test-inventory.v1.json', '.github/gnome/request-template.v1.json', '.github/workflows/ci.yml', '.github/workflows/ubuntu-gnome-prepare.yml', '.github/workflows/ubuntu-gnome-lifecycle.yml'], ['uv', 'run', '--no-sync', '--offline', 'pytest', '-c', 'pyproject.toml', '--rootdir=.', '--confcutdir=.', '-o', 'addopts=', '-ra', '--strict-markers', '--strict-config', '--disable-plugin-autoload', '-q', '--basetemp', '/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/gnome-v5-canonical-focus-v1/fixtures', 'scripts/tests/test_ci_auxiliary_workflows.py', 'scripts/tests/test_ci_native_package.py', 'scripts/tests/test_ci_workflow.py', 'scripts/tests/test_linux_gnome_isolation.py', 'scripts/tests/test_ubuntu_gnome_boundaries.py', 'scripts/tests/test_ubuntu_gnome_request.py', 'scripts/tests/test_ubuntu_gnome_review_regressions.py', 'scripts/tests/test_ubuntu_gnome_signed_indexes.py', 'scripts/tests/test_ubuntu_gnome_source_binding.py'], ['uv', 'run', '--no-sync', '--offline', 'python', 'scripts/check_portability.py', '--quiet'], ['uv', 'run', '--no-sync', '--offline', 'python', 'scripts/verify.py', '--suite', 'integrity']]
results=[]
for i,argv in enumerate(cmds):
 start=time.monotonic();sigs=[];timeout=False
 with (O/f'{i+1:02}.stdout').open('wb') as out,(O/f'{i+1:02}.stderr').open('wb') as err:
  p=subprocess.Popen(argv,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
  try:code=p.wait(timeout=180)
  except subprocess.TimeoutExpired:
   timeout=True
   for sig in [signal.SIGTERM,signal.SIGKILL]:
    if p.poll() is not None:break
    try:os.killpg(p.pid,sig);sigs.append(sig.name)
    except ProcessLookupError:pass
    try:p.wait(timeout=2)
    except subprocess.TimeoutExpired:pass
   code=p.wait(timeout=5)
 try:os.killpg(p.pid,0);group='PRESENT_AFTER_REAP_NO_SIGNAL'
 except ProcessLookupError:group='ABSENT'
 row={'argv':argv,'exit_code':code,'seconds':time.monotonic()-start,'timeout':timeout,'signals':sigs,'reaped':p.returncode is not None,'group':group};results.append(row);dump('results.json',results);print(json.dumps(row),flush=True)
 if code or group!='ABSENT':break
after=snap();dump('after.json',after);closure={'end_observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_seven_commands_closed_zero':len(results)==7 and all(x['exit_code']==0 and x['group']=='ABSENT' and not x['timeout'] and not x['signals'] for x in results),'source_bytes_fullmodes_status_head_tree_equal':before==after,'tracked_files':len(before['files'])};dump('closure.json',closure);print(json.dumps(closure),flush=True)
raise SystemExit(0 if all(closure[k] for k in ['all_seven_commands_closed_zero','source_bytes_fullmodes_status_head_tree_equal']) else 1)
