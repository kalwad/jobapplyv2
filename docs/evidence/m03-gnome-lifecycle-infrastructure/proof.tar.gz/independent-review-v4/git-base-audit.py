"""Read immutable local Git objects; never imports/executes candidate code."""
from pathlib import Path
import hashlib,json,os,subprocess
P=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/ubuntu-gnome-lifecycle-preparation/v4')
R=Path('/Users/tanishkalwad/jobapplyv2');OUT=Path(__file__).parent;HEAD='80e68ac9a24cd7ebf2874af625b866a055b9abe6';LIMIT=512*1024*1024
commands=[]
def git(args,data=None):
 c=subprocess.run(['/usr/bin/git','--no-pager','--no-optional-locks','-C',str(R),*args],input=data,stdin=None if data is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,env={'PATH':'/usr/bin:/bin','LC_ALL':'C','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0'},check=True)
 commands.append({'args':args,'exit_code':c.returncode,'stdout_bytes':len(c.stdout),'stdout_sha256':hashlib.sha256(c.stdout).hexdigest(),'stderr_bytes':len(c.stderr),'stderr_sha256':hashlib.sha256(c.stderr).hexdigest()})
 return c.stdout
raw=git(['ls-tree','-r','-z',HEAD]);tree=[]
for row in raw.split(b'\0'):
 if not row:continue
 meta,name=row.split(b'\t',1);mode,kind,oid=meta.decode().split();assert kind=='blob' and mode in {'100644','100755'}
 tree.append((name.decode(),mode,oid))
ids=sorted({r[2] for r in tree});body_input=('\n'.join(ids)+'\n').encode();sizes=git(['cat-file','--batch-check'],body_input);total=0
for row in sizes.decode().splitlines():
 _,kind,size=row.split();assert kind=='blob';total+=int(size)
assert total<=LIMIT
raw=git(['cat-file','--batch'],body_input);offset=0;blobs={}
for oid in ids:
 stop=raw.index(b'\n',offset);actual,kind,size=raw[offset:stop].decode().split();size=int(size);offset=stop+1;body=raw[offset:offset+size];offset+=size;assert raw[offset:offset+1]==b'\n';offset+=1
 assert actual==oid and kind=='blob' and len(body)==size
 blobs[oid]={'bytes':size,'sha256':hashlib.sha256(body).hexdigest()}
assert offset==len(raw)
base={n:{**blobs[oid],'mode':0o755 if mode=='100755' else 0o644} for n,mode,oid in tree}
overlay=json.loads((P/'SOURCE.json').read_text())['files'];expected={**base,**overlay};retained=json.loads((P/'isolation-proposal/COMPOSED-EXPECTED-SOURCE.json').read_text())['files'];joins=[]
for n,row in expected.items():joins.append({'path':n,'pass':row==retained.get(n)})
assert len(base)==2187 and len(expected)==2210 and expected.keys()==retained.keys()
result={'scope':'Actual local immutable Git80e68 blob/execute-class plus sealed38overlay reconstruct exact2210composition; not whole canonical mutable filesystem neutrality','base_commit':HEAD,'base_files':len(base),'unique_blobs':len(blobs),'unique_blob_bytes':total,'source_files':len(expected),'pass_count':sum(r['pass'] for r in joins),'joins':joins,'metadata_commands':commands}
(OUT/'git-base-joins.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ('base_files','unique_blobs','unique_blob_bytes','source_files','pass_count')}))
