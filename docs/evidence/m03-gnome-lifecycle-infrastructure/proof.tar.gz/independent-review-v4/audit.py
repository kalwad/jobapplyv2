"""Reviewer stdlib data/AST checks only; no candidate imports or execution."""
from pathlib import Path,PureWindowsPath
import ast,hashlib,json,re,stat,tarfile
P=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/ubuntu-gnome-lifecycle-preparation/v4')
C=P/'isolation-proposal';OUT=Path(__file__).parent;V3=P.parent/'v3'
rows=[]
def ck(name,ok,detail=None):rows.append({'name':name,'pass':bool(ok),'detail':detail})
def doc(p):return json.loads(p.read_bytes())
def pin(p):
 a=p.lstat()
 if not stat.S_ISREG(a.st_mode):raise ValueError('nonregular '+str(p))
 raw=p.read_bytes();b=p.lstat()
 if (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_mode)!=(b.st_dev,b.st_ino,b.st_size,b.st_mtime_ns,b.st_mode) or len(raw)!=a.st_size:raise ValueError('changed '+str(p))
 return {'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'mode':stat.S_IMODE(a.st_mode)}
def defs(p):
 return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef))}
source=doc(P/'SOURCE.json');adopt=doc(P/'ADOPTION.json');manifest=doc(P/'MANIFEST.json');seal=doc(P/'SEAL.json')
for n,h in {'SOURCE.json':'3e8e6dc3d025898c34f99576aa8a2a563c6f5bd0024245f5bad839139d82dc33','ADOPTION.json':'b116b78ce9d5ad875323947935459d7e3a210b3dcc0248630cef3d050553268f','MANIFEST.json':'2ec601aa613e44cb242630bc591f048f30481f2f2084810f441a0283017b6dd1','SEAL.json':'95eafe445e3df1ccfed706d7f4c01a0950d6afdf1e12935838921b635f9b8c19'}.items():ck('root_pin:'+n,pin(P/n)['sha256']==h)
ck('source_count',len(source['files'])==38)
start={n:pin(P/'final-after'/n) for n in source['files']}
for n,r in source['files'].items():
 ck('parent_source:'+n,start[n]==r)
 ck('child_source:'+n,pin(C/'final-v3-after'/n)==r)
for key,name in [('source','SOURCE.json'),('adoption','ADOPTION.json'),('handoff','HANDOFF.md'),('summary','SUMMARY.json'),('manifest','MANIFEST.json'),('archive','proof-source-and-data.tar.gz')]:ck('seal:'+key,pin(P/name)==seal[key])
ck('manifest_count',len(manifest['files'])==manifest['count']==345)
for n,r in manifest['files'].items():
 ck('safe_relative:'+n,not Path(n).is_absolute() and '..' not in Path(n).parts)
 ck('parent_member:'+n,pin(P/n)==r)
for n,r in doc(C/'FILES.json')['files'].items():ck('child_member:'+n,pin(C/n)==r)
ck('child_seal_pin',pin(C/'SOURCE-SEALED.json')['sha256']=='63e8e8ed46e25e821fe308c3ba34b49301423c1f1ebd1bf36365b0c14f58931f')
ck('child_parent_source_equal',doc(C/'SOURCE-SEALED.json')['files']==source['files'])
for r in adopt['files']:
 ck('adopt_after:'+r['path'],pin(Path(r['after']))==r['after_pin']==source['files'][r['path']])
 if r['before'] is not None:ck('adopt_before:'+r['path'],pin(Path(r['before']))==r['before_pin'])
ck('operations',len(adopt['files'])==31 and sum(r['operation']=='ADD' for r in adopt['files'])==23 and sum(r['operation']=='MODIFY' for r in adopt['files'])==8,adopt['operations'])
# Safe proof archive joins exact retained parent manifest plus itself, not any fixture/cache.
with tarfile.open(P/'proof-source-and-data.tar.gz','r:gz') as tf:
 seen=set()
 for member in tf:
  n=member.name;ck('archive_safe:'+n,member.isfile() and not Path(n).is_absolute() and '..' not in Path(n).parts and n not in seen);seen.add(n)
  data=tf.extractfile(member).read();expected=pin(P/n)
  ck('archive_member:'+n,{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mode':member.mode}==expected)
 ck('archive_exact_set',seen==set(manifest['files'])|{'MANIFEST.json'} and len(seen)==346)
# Whole composed finite physical projection, honest later seal observation rather than backdated QA start.
expected=doc(C/'COMPOSED-EXPECTED-SOURCE.json');repo=C/'composed-reviewed-final/repo'
ck('composed_counts',expected['baseline_files']==2187 and expected['total_expected_files']==len(expected['files'])==2210)
for n,r in expected['files'].items():ck('composed_member:'+n,pin(repo/n)==r)
for prefix in ('','composed-'):
 before=doc(C/(prefix+'source-before.json'));after=doc(C/(prefix+'source-after.json'))
 ck('seal_snapshot_equal:'+prefix,before['files']==after['files'] and after['unchanged_from_seal_before'])
 ck('seal_snapshot_source:'+prefix,before['files']==source['files'])
checks=doc(C/'FINAL-CHECKS.json')['checks'];ck('eight_checks_plus_node_version',set(checks)=={'ruff-final-v3','format-final-v3','mypy-final-v3','prettier-final-v3','full-pure-final-v3','canonical-portability-final-v3','canonical-integrity-final-v3','canonical-collect-final','node-version-final'})
for label,r in checks.items():
 ck('actual_closed:'+label,r['exit_code']==0 and r['direct_child_reaped'] and r['group_after_reap']=='ABSENT' and r['signals']==[] and r['error'] is None)
 ck('receipt:'+label,doc(C/'checks'/label/'receipt.json')==r)
 for st in ('stdout','stderr'):
  p=pin(C/'checks'/label/st);ck('raw:'+label+':'+st,{k:p[k] for k in ('bytes','sha256')}==r[st])
raw=(C/'checks/full-pure-final-v3/stdout').read_text();ck('404_summary',bool(re.search(r'^404 passed in 5\.75s$',raw,re.M)))
collect=(C/'checks/canonical-collect-final/stdout').read_text();ids=[s for s in collect.splitlines() if re.match(r'^(scripts|services|packages)/.+::',s)]
ck('collection2474',len(ids)==len(set(ids))==2474)
new=doc(P/'final-after/scripts/python-test-inventory.v1.json');old=doc(P/'preimages/scripts/python-test-inventory.v1.json')
ck('old_common2139',old['common']['count']==len(old['common']['node_ids'])==2139)
ck('new_common2472',new['common']['count']==len(new['common']['node_ids'])==2472)
ck('old_ids_preserved',set(old['common']['node_ids'])<=set(new['common']['node_ids']))
ck('unchanged_posix_catalog',old['posix_only_node_ids']==new['posix_only_node_ids'])
# Generic schema inspection records the exact two POSIX IDs without assuming a new label.
ck('collection_equals_catalog',set(ids)==set(new['common']['node_ids'])|set(new['posix_only_node_ids']))
addition=doc(C/'INVENTORY-ADDITION.json');delta=set(new['common']['node_ids'])-set(old['common']['node_ids'])
ck('exact333delta',len(delta)==333 and delta==set(addition['new_ids']))
for cat in (old,new):
 common=cat['common'];ck('catalog_digest:'+str(common['count']),hashlib.sha256(('\n'.join(common['node_ids'])+'\n').encode()).hexdigest()==common['sha256'])
# Old generic policy body predicates are preserved; only run_checks routing and export command literal extension changed.
olddefs=defs(V3/'final-after/scripts/check_portability.py');newdefs=defs(P/'final-after/scripts/check_portability.py')
for n,v in olddefs.items():
 if n!='run_checks':ck('prior_generic_definition:'+n,newdefs.get(n)==v)
# Original v3 evidence and five-finding review remain unchanged at known pins.
ck('prior_v3_SOURCE',pin(V3/'SOURCE.json')['sha256']=='73d439780520d31203c79a51cf0f8336ae7baeefa790caa8a17500463438fc51')
ck('prior_v3_review',pin(OUT.parents[0]/'v3/REVIEW.md')['sha256']=='e26fbf55fc89f8b3abed825f66f9af6de367f03bf5e797a10f187f203673dee3')
lex=[{'value':s,'drive':PureWindowsPath(s).drive,'root':PureWindowsPath(s).root,'is_absolute':PureWindowsPath(s).is_absolute()} for s in ('/home/japp-ci','/opt/japp-ci','/etc/gdm3/custom.conf')]
(OUT/'windows-lexical-observation.json').write_text(json.dumps({'scope':'Pure lexical stdlib observation, no host filesystem writes/native Windows actor','cases':lex},indent=2)+'\n')
end={n:pin(P/'final-after'/n) for n in source['files']};ck('review_source_endpoints',start==end)
(OUT/'data-joins.json').write_text(json.dumps({'scope':'Exact source/data joins, not source CLEAR or native evidence','total':len(rows),'pass_count':sum(r['pass'] for r in rows),'joins':rows,'source_start':start,'source_end':end},indent=2)+'\n')
print(json.dumps({'total':len(rows),'pass':sum(r['pass'] for r in rows),'fail':[r for r in rows if not r['pass']]}))
