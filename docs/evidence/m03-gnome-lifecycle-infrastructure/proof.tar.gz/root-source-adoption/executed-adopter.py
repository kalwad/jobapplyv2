from pathlib import Path,PurePosixPath
import datetime,hashlib,json,shutil,stat,subprocess

ROOT=Path('/Users/tanishkalwad/jobapplyv2')
BASE=Path(__file__).parent
SUBJECT=BASE/'ubuntu-gnome-lifecycle-preparation/v5'
FULL=BASE/'full-b28b2b9'
OUT=BASE/'gnome-v5-canonical-adoption-v1'

def pin(path):
    info=path.lstat();assert stat.S_ISREG(info.st_mode),path
    body=path.read_bytes()
    return {'bytes':len(body),'mode':stat.S_IMODE(info.st_mode),'sha256':hashlib.sha256(body).hexdigest()}

# The completed local campaign remains immutable; no source change while active.
closure=json.loads((FULL/'closure.json').read_bytes())
assert closure['all_commands_exit_zero'] and closure['source_bytes_modes_unchanged'] and closure['runtime_bytes_modes_unchanged'] and closure['commit_and_tree_equal_at_end_observation']
assert closure['git_status_before']==closure['git_status_after']==''
context=json.loads((FULL/'context.json').read_bytes());ending=json.loads((FULL/'end-context.json').read_bytes())
assert context['commit']==ending['commit']=='b28b2b9f245d057bea24b92f28ca131a7cf349c9'
assert context['tree']==ending['tree']=='c7cdd7158a70969d77765b143cd5e3b972db4ba3'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==context['commit']
assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)==''
assert pin(SUBJECT/'SOURCE.json')['sha256']=='d42eac5761a4d6295b5fca401021329504f5927912b5a5fd93d782bb066d8ba9'
assert pin(SUBJECT/'ADOPTION.json')['sha256']=='e87114e435dc511b8c5f7942b1d49300446fd0f3578a6163010162c67ba8b572'
review=BASE/'ubuntu-gnome-infrastructure-independent-review/v5'
assert pin(review/'REVIEW.md')['sha256']=='181da1d7dbb84c5c44362b67607e714244a70db528962fe8e269f21d1c766095'
assert pin(review/'MANIFEST.json')['sha256']=='728c21af3b2bfdd0047d45bc018ee7a65963fa24ec096ae8e9774fdf0c015f9e'
rows=json.loads((SUBJECT/'ADOPTION.json').read_bytes())['files'];assert len(rows)==31
assert sum(row['operation']=='ADD' for row in rows)==23
assert sum(row['operation']=='MODIFY' for row in rows)==8
paths=set()
for row in rows:
    rel=PurePosixPath(row['path']);assert not rel.is_absolute() and not set(rel.parts)&{'','..','.'} and row['path'] not in paths;paths.add(row['path'])
    source=Path(row['after']);assert source.is_relative_to(SUBJECT/'final-after') and pin(source)==row['after_pin']
    target=ROOT/str(rel)
    if row['operation']=='ADD':assert not target.exists() and not target.is_symlink() and row['before_pin'] is None
    else:assert pin(target)==row['before_pin'] and pin(Path(row['before']))==row['before_pin']
    for parent in [target.parent,*target.parent.parents]:
        if parent==ROOT:break
        if parent.exists():assert parent.is_dir() and not parent.is_symlink()
assert not (ROOT/'.github/gnome/requests').exists()
OUT.mkdir(exist_ok=False)
shutil.copy2(Path(__file__),OUT/'executed-adopter.py')
for name in ['SOURCE.json','ADOPTION.json','SEAL.json']:shutil.copy2(SUBJECT/name,OUT/name)
for row in rows:
    if row['operation']=='MODIFY':
        saved=OUT/'before'/row['path'];saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/row['path'],saved)
applied=[]
for row in rows:
    target=ROOT/row['path'];target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(row['after'],target);assert pin(target)==row['after_pin']
    applied.append({'path':row['path'],'operation':row['operation'],'after':pin(target)})
    (OUT/'progress.json').write_text(json.dumps(applied,indent=2)+'\n')
receipt={'observed_utc':datetime.datetime.now(datetime.UTC).isoformat(),'base_head':context['commit'],'review_report_sha256':pin(review/'REVIEW.md')['sha256'],'adoption_sha256':pin(SUBJECT/'ADOPTION.json')['sha256'],'applied':applied,'actual_paths':31,'add':23,'modify':8,'git_status_after':subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True),'candidate_download_install_vm_native_actors':0,'states_changed':False,'scope':'Guarded source adoption only; canonical affected/full checks and original native target proof still required.'}
(OUT/'APPLIED.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'applied_paths':31,'source_sha256':pin(SUBJECT/'SOURCE.json')['sha256'],'receipt':str(OUT/'APPLIED.json')}),flush=True)
