// PREPARATION ONLY. Root supplies the documented CUA app object after review/release.
// This factory does not find/select/open an app. No mzDir/mzSeq/fzDir/fzSeq globals.
function createV5Capture({app,outputDir,fs,emitImage,writeText}) {
  const expected='/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/m03-w11-macos-native-zoom/v5/captures';
  if(outputDir!==expected)throw Error('Exact fresh v5 capture directory required');
  if(!app||typeof app.getAXStateAndScreenshot!=='function')throw Error('Retained CUA app required');
  let sequence=0,current='',state='new';
  const events=[];
  async function initialize(){
    if(state!=='new')throw Error('One capture initialization only');
    state='checking';
    // Root observer must create the fresh directory once before this call.
    const info=await fs.lstat(outputDir);
    if(!info.isDirectory()||info.isSymbolicLink()||await fs.realpath(outputDir)!==expected||(await fs.readdir(outputDir)).length)throw Error('Fresh empty real output directory required');
    state='ready';
  }
  async function capture(slug,action){
    if(state!=='ready'||!/^[-a-z0-9]{1,80}$/.test(slug)||typeof action!=='string'||action.length>512)throw Error('Closed capture request required');
    const response=await app.getAXStateAndScreenshot({disableDiffing:true,emit:false});
    if(typeof response.state!=='string'||!response.state.startsWith('Window: "Desktop App", App: Desktop App.')||!response.screenshot)throw Error('Owned app AX and original screenshot required');
    const bytes=response.screenshot;
    const ext=bytes[0]===0xff&&bytes[1]===0xd8?'jpg':bytes[0]===0x89&&bytes[1]===0x50?'png':null;
    if(!ext)throw Error('Supported original image bytes required');
    const stem=String(++sequence).padStart(3,'0')+'-'+slug;
    // Every capture and event is append-only. A partial pair is retained as partial.
    await fs.writeFile(outputDir+'/'+stem+'.ax.txt',response.state,{flag:'wx'});
    await fs.writeFile(outputDir+'/'+stem+'.'+ext,bytes,{flag:'wx'});
    const event={utc:new Date().toISOString(),action,capture:stem,image_extension:ext};
    await fs.writeFile(outputDir+'/'+stem+'.event.json',JSON.stringify(event,null,2)+'\n',{flag:'wx'});
    events.push(event);current=response.state;
    if(emitImage)await emitImage(bytes);
    if(writeText)writeText(response.state);
    return {stem,state:current,event};
  }
  return Object.freeze({initialize,capture,getState:()=>current,getEvents:()=>events.map(e=>({...e}))});
}
