from pathlib import Path, PurePosixPath
from datetime import UTC, datetime
import hashlib, json, shutil, stat, sys, tarfile

E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
R=Path('/Users/tanishkalwad/jobapplyv2')
P=E/'m03-w11-macos-native-zoom-v5-preparation/v1'
O=E/'m03-w11-macos-native-zoom/v6'
def row(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink();b=p.read_bytes();return {'bytes':len(b),'mode':stat.S_IMODE(s.st_mode),'sha256':hashlib.sha256(b).hexdigest()}
def sha(p):return row(p)['sha256']
for name,h in [('SOURCE.json','cef429ca982d5ab05630714fa73dcee839297333f1d2f6f0810a3b91dea0d4e2'),('HANDOFF.md','308e43a2a975e7e150fc801c972e9b85b071d0a50f678d35801ac01d9da73e05'),('MANIFEST.json','4453bcb4399166961765b525a9ca3d53ab73c729e4ffaf6bc3c3a513f2cd80d3'),('proof.tar.gz','ee28bb8fe10d734b3045192891c337612b69ea4d30961996cb76d5bc1b2b2783')]:assert sha(P/name)==h
rows={v['path']:v for v in json.loads((P/'MANIFEST.json').read_text())['files']}
for n,v in rows.items():assert row(P/n)=={'bytes':v['bytes'],'mode':stat.S_IMODE(v['full_mode']),'sha256':v['sha256']}
seen=set()
with tarfile.open(P/'proof.tar.gz') as arc:
 for m in arc:
  n=m.name;assert m.isfile() and not m.islnk() and not m.issym() and not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and '\\' not in n and n not in seen;seen.add(n)
  p=P/n;f=arc.extractfile(m);assert f is not None and f.read()==p.read_bytes() and m.mode==stat.S_IMODE(p.lstat().st_mode)
assert seen==set(rows)|{'MANIFEST.json'}
pins=json.loads((P/'SOURCE-PREIMAGES.json').read_text());app=Path(pins['future_app_path']);runtime=R/'apps/desktop/src-tauri/runtime-payload'
snapshot={}
for key,base,expected in [('selected_source',R,pins['selected_source']),('runtime',runtime,pins['runtime']),('app',app,pins['app'])]:
 actual={n:row(base/n) for n in expected};assert actual==expected,key
 if key!='selected_source':assert {p.relative_to(base).as_posix() for p in base.rglob('*') if p.is_file()}==set(expected)
 snapshot[key]=actual
assert [len(snapshot[k]) for k in ['selected_source','runtime','app']]==[22,40,43]
phase=sys.argv[1];assert phase in ['before','after']
if phase=='before':
 assert not O.exists();O.mkdir();(O/'captures').mkdir()
 for n in ['PLAN.md','MEASUREMENT-POLICY.json','capture-helper.js','SOURCE-PREIMAGES.json']:shutil.copy2(P/n,O/n)
 shutil.copy2(Path(__file__),O/'observer-executed.py')
 shutil.copy2(E/'measure-mac-zoom-v6.cjs',O/'measure-planned.cjs')
 (O/'ROOT-REVIEW.md').write_text('Root reviewed frozen parent v5 plan/helper/pixel policy and the separately frozen v6 extension and exact selected preimages before native actions. All35 selected manifest files and36 safe original archive members join. Four content ratios retain original2±max(.1,onebaselinepixel) and reset1±max(.05,onepixel). Actual native Windowsharing pill and title geometry are prospective independent chrome controls within the captured frame, not a global window-position/OSDPI/nativezoom getter. Every collected frame must retain them. No source/font/style change, threshold retuning, reader/orphan or wholecanonical neutrality claim is allowed. App43/runtime40/selected22 source only; source role/fact provenance remains explicit. One600second monotonic native session, no retries/newsession at failure; root technical release is within the existing user authorization. Earlier v2/v3 failures and v4 policy refusal remain unchanged.\n')
else:
 assert json.loads((O/'before.json').read_text())['snapshot']==snapshot
(O/(phase+'.json')).write_text(json.dumps({'utc':datetime.now(UTC).isoformat(),'snapshot':snapshot,'scope':'Selected22 frontend/native source,40runtime,43app only; no whole-canonical/head/status neutrality claim.'},indent=2)+'\n')
print(json.dumps({'phase':phase,'counts':[22,40,43],'matches_declared_preimages':True,'original_manifest':len(rows),'safe_archive':len(seen)}))
