# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w14-inventory-property.spec.ts >> W14: final inventory hash refuses eventless native value drift
- Location: e2e/extension/extension-w14-inventory-property.spec.ts:69:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "ROOT_UNRESOLVED"
Received: "RECONCILED"
```

# Test source

```ts
  61  |           return digest;
  62  |         });
  63  |       }
  64  |       return native;
  65  |     },
  66  |   });
  67  | }
  68  | 
  69  | test("W14: final inventory hash refuses eventless native value drift", async ({
  70  |   extensionContext,
  71  |   extensionId,
  72  |   serviceWorker,
  73  | }, info) => {
  74  |   const h = await openHarness(
  75  |     extensionContext,
  76  |     extensionId,
  77  |     serviceWorker,
  78  |     "/native/",
  79  |   );
  80  |   const witness = await installW14NativeWitness(
  81  |     extensionContext,
  82  |     h.page,
  83  |     extensionId,
  84  |   );
  85  |   let pending: ReturnType<typeof dynReconcile> | undefined;
  86  |   try {
  87  |     await setFixture(
  88  |       h,
  89  |       '<form data-japp-application-root="true"><label for="first">First name</label><input id="first" name="first" required></form>',
  90  |     );
  91  |     const top = foundTopFrame(await scanFrames(h));
  92  |     const field = descriptorByLabel(top.descriptors, "First name");
  93  |     const tx = await approvedTransaction(field, "final-inventory-property", {
  94  |       kind: "TEXT",
  95  |       text: "Synthetic",
  96  |     });
  97  |     const execution = await dynExecute(h, [tx]);
  98  |     expect(firstDriverOutcome(execution)).toBe("VERIFIED");
  99  |     const baseline = reconciled(
  100 |       await dynReconcile(h, top.frame_context.frame_id),
  101 |     );
  102 |     expect(baseline.inventory.readiness).toBe("READY");
  103 |     const priorNative = await witness.snapshot();
  104 |     await witness.session.send("Runtime.evaluate", {
  105 |       contextId: witness.contextId,
  106 |       expression: `(${installResultHashPause.toString()})(${JSON.stringify("w11-inventory-v1\0")})`,
  107 |     });
  108 |     pending = dynReconcile(h, top.frame_context.frame_id);
  109 |     await expect
  110 |       .poll(
  111 |         async () => {
  112 |           const result = await witness.session.send("Runtime.evaluate", {
  113 |             contextId: witness.contextId,
  114 |             expression:
  115 |               "globalThis.__JAPP_W14_TEST_RESULT_HASH_PAUSE__?.reached === true",
  116 |             returnByValue: true,
  117 |           });
  118 |           return result.result.value === true;
  119 |         },
  120 |         { timeout: 5000 },
  121 |       )
  122 |       .toBe(true);
  123 |     const mutationRecords = await h.page.evaluate(() => {
  124 |       const observer = new MutationObserver(() => undefined);
  125 |       observer.observe(document, {
  126 |         subtree: true,
  127 |         childList: true,
  128 |         attributes: true,
  129 |         characterData: true,
  130 |       });
  131 |       const input = document.querySelector("input");
  132 |       if (input === null) throw new Error("native input missing");
  133 |       input.value = "Changed by site";
  134 |       const count = observer.takeRecords().length;
  135 |       observer.disconnect();
  136 |       return count;
  137 |     });
  138 |     await witness.session.send("Runtime.evaluate", {
  139 |       contextId: witness.contextId,
  140 |       expression: "globalThis.__JAPP_W14_TEST_RESULT_HASH_PAUSE__.release()",
  141 |     });
  142 |     const publication = await pending;
  143 |     pending = undefined;
  144 |     const current = await dynReconcile(h, top.frame_context.frame_id);
  145 |     const native = await witness.snapshot();
  146 |     const value = await h.page.locator("#first").inputValue();
  147 |     await recordIndependentEvidence(info, "inventory-eventless-value", {
  148 |       field,
  149 |       tx,
  150 |       execution,
  151 |       baseline,
  152 |       priorNative,
  153 |       mutationRecords,
  154 |       publication,
  155 |       current,
  156 |       native,
  157 |       value,
  158 |     });
  159 |     expect(mutationRecords).toBe(0);
  160 |     expect(value).toBe("Changed by site");
> 161 |     expect(publication.status).toBe("ROOT_UNRESOLVED");
      |                                ^ Error: expect(received).toBe(expected) // Object.is equality
  162 |     expect(reconciled(current).inventory.readiness).toBe("NOT_READY");
  163 |     expect(native.native_mutation_count).toBe(
  164 |       priorNative.native_mutation_count,
  165 |     );
  166 |   } finally {
  167 |     await witness.session.send("Runtime.evaluate", {
  168 |       contextId: witness.contextId,
  169 |       expression: "globalThis.__JAPP_W14_TEST_RESULT_HASH_PAUSE__?.restore()",
  170 |     });
  171 |     await pending?.catch(() => undefined);
  172 |     await witness.dispose();
  173 |     await h.page.close();
  174 |     await h.controller.close();
  175 |   }
  176 | });
  177 | 
```