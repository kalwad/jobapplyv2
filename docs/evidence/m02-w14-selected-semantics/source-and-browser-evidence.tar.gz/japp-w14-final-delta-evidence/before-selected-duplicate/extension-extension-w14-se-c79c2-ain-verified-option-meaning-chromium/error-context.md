# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w14-selected-duplicate.spec.ts >> W14: a duplicate selected raw value cannot retain verified option meaning
- Location: e2e/extension/extension-w14-selected-duplicate.spec.ts:22:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "NOT_READY"
Received: "READY"
```

# Test source

```ts
  9   |   descriptorByLabel,
  10  |   buildTransaction,
  11  |   dynExecute,
  12  |   dynReconcile,
  13  |   reconciled,
  14  | } from "./support/research-harness.ts";
  15  | import {
  16  |   countryPolicy,
  17  |   firstDriverOutcome,
  18  |   nativeSelectPhysical,
  19  |   recordIndependentEvidence,
  20  | } from "./support/independent-w14-evidence.ts";
  21  | 
  22  | test("W14: a duplicate selected raw value cannot retain verified option meaning", async ({
  23  |   extensionContext,
  24  |   extensionId,
  25  |   serviceWorker,
  26  | }, info) => {
  27  |   const h = await openHarness(
  28  |     extensionContext,
  29  |     extensionId,
  30  |     serviceWorker,
  31  |     "/native/",
  32  |   );
  33  |   const witness = await installW14NativeWitness(
  34  |     extensionContext,
  35  |     h.page,
  36  |     extensionId,
  37  |   );
  38  |   try {
  39  |     await setFixture(
  40  |       h,
  41  |       '<form data-japp-application-root="true"><label for="country">Country</label><select id="country" required><option value="">Choose</option><option value="US">United States</option><option value="CA">Canada</option></select></form>',
  42  |     );
  43  |     await h.page.evaluate(() => {
  44  |       const select = document.querySelector("select");
  45  |       if (select === null) throw new Error("native select missing");
  46  |       const meter = { input: 0, change: 0 };
  47  |       (
  48  |         window as unknown as { independentMeter: typeof meter }
  49  |       ).independentMeter = meter;
  50  |       select.addEventListener("input", () => {
  51  |         meter.input++;
  52  |       });
  53  |       select.addEventListener("change", () => {
  54  |         meter.change++;
  55  |       });
  56  |     });
  57  |     const top = foundTopFrame(await scanFrames(h));
  58  |     const field = descriptorByLabel(top.descriptors, "Country");
  59  |     const approval = await countryPolicy(field, "post-verified-duplicate");
  60  |     if (
  61  |       approval.status !== "RESOLVED" ||
  62  |       approval.resolution.optionResolution?.status !== "RESOLVED"
  63  |     )
  64  |       throw new Error("actual W09 option approval missing");
  65  |     expect(approval.resolution.decision.final_decision).toBe("FILL");
  66  |     const tx = await buildTransaction(
  67  |       field,
  68  |       {
  69  |         kind: "OPTION",
  70  |         value_digest: approval.resolution.optionResolution.valueDigest,
  71  |       },
  72  |       approval.resolution.decision,
  73  |       "post-verified-duplicate",
  74  |     );
  75  |     const execution = await dynExecute(h, [tx]);
  76  |     expect(firstDriverOutcome(execution)).toBe("VERIFIED");
  77  |     expect(
  78  |       reconciled(await dynReconcile(h, top.frame_context.frame_id)).inventory
  79  |         .readiness,
  80  |     ).toBe("READY");
  81  |     const prior = await nativeSelectPhysical(h);
  82  |     const priorNative = await witness.snapshot();
  83  |     await h.page.evaluate(() => {
  84  |       const select = document.querySelector("select");
  85  |       if (select === null) throw new Error("native select missing");
  86  |       select.add(new Option("Canada", "US"));
  87  |       select.selectedIndex = select.options.length - 1;
  88  |     });
  89  |     const current = await dynReconcile(h, top.frame_context.frame_id);
  90  |     const after = await nativeSelectPhysical(h);
  91  |     const native = await witness.snapshot();
  92  |     await recordIndependentEvidence(info, "selected-duplicate", {
  93  |       field,
  94  |       approval,
  95  |       tx,
  96  |       execution,
  97  |       prior,
  98  |       priorNative,
  99  |       current,
  100 |       after,
  101 |       native,
  102 |     });
  103 |     expect(after.value).toBe("US");
  104 |     expect(after.label).toBe("Canada");
  105 |     expect(after.meter).toEqual(prior.meter);
  106 |     expect(native.native_mutation_count).toBe(
  107 |       priorNative.native_mutation_count,
  108 |     );
> 109 |     expect(reconciled(current).inventory.readiness).toBe("NOT_READY");
      |                                                     ^ Error: expect(received).toBe(expected) // Object.is equality
  110 |     expect(reconciled(current).inventory.counts.required_unresolved).toBe(1);
  111 |   } finally {
  112 |     await witness.dispose();
  113 |     await h.page.close();
  114 |     await h.controller.close();
  115 |   }
  116 | });
  117 | 
```