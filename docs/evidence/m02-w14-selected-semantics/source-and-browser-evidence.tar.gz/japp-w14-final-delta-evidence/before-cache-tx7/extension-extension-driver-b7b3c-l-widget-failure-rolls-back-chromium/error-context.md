# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-drivers.spec.ts >> TX7: immediately-before-action re-resolution blocks semantic replacement, and partial widget failure rolls back
- Location: e2e/extension/extension-drivers.spec.ts:818:1

# Error details

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "UNIQUE"
```

# Test source

```ts
  781 |   const second = await execute(harness, combo, {
  782 |     kind: "OPTION",
  783 |     value_digest: await semanticDigest(
  784 |       "option-value-v1\0Harbor Point (synthetic)",
  785 |     ),
  786 |   });
  787 |   expect(second.result.outcome).toBe("VERIFIED");
  788 |   expect(await harness.page.locator("#cbx-input").inputValue()).toBe(
  789 |     "Harbor Point (synthetic)",
  790 |   );
  791 | 
  792 |   const missing = await execute(harness, combo, {
  793 |     kind: "OPTION",
  794 |     value_digest: await semanticDigest("option-value-v1\0Not present"),
  795 |   });
  796 |   expect(missing.result.outcome).not.toBe("VERIFIED");
  797 |   expect(await harness.page.locator("#cbx-input").inputValue()).toBe(
  798 |     "Harbor Point (synthetic)",
  799 |   );
  800 | 
  801 |   await harness.page.locator("#cbx-listbox").evaluate((list) => {
  802 |     list.removeAttribute("hidden");
  803 |     const duplicate = document.createElement("div");
  804 |     duplicate.setAttribute("role", "option");
  805 |     duplicate.setAttribute("data-value", "Harbor Point (synthetic)");
  806 |     duplicate.textContent = "Harbor Point duplicate";
  807 |     list.append(duplicate);
  808 |   });
  809 |   const ambiguous = await execute(harness, combo, {
  810 |     kind: "OPTION",
  811 |     value_digest: await semanticDigest(
  812 |       "option-value-v1\0Harbor Point (synthetic)",
  813 |     ),
  814 |   });
  815 |   expect(ambiguous.result.outcome).not.toBe("VERIFIED");
  816 | });
  817 | 
  818 | test("TX7: immediately-before-action re-resolution blocks semantic replacement, and partial widget failure rolls back", async ({
  819 |   extensionContext,
  820 |   extensionId,
  821 |   serviceWorker,
  822 | }) => {
  823 |   const harness = await openHarness(
  824 |     extensionContext,
  825 |     extensionId,
  826 |     serviceWorker,
  827 |     "/combobox/",
  828 |   );
  829 |   let scanned = await descriptors(harness);
  830 |   let combo = descriptorByLabel(scanned, "Office location");
  831 |   const priorDisplay = "Fable Crossing (synthetic)";
  832 |   const intendedDisplay = "Harbor Point (synthetic)";
  833 |   expect(
  834 |     (
  835 |       await execute(harness, combo, {
  836 |         kind: "OPTION",
  837 |         value_digest: await semanticDigest(`option-value-v1\0${priorDisplay}`),
  838 |       })
  839 |     ).result.outcome,
  840 |   ).toBe("VERIFIED");
  841 |   // Force the reviewed fixture back to its committed-value filtered window;
  842 |   // this makes the driver's reversible precondition probe the point where a
  843 |   // same-document semantic replacement can race the action.
  844 |   await harness.page.locator("#cbx-input").dispatchEvent("input");
  845 |   await harness.page.locator("#cbx-input").press("Escape");
  846 | 
  847 |   await harness.page.locator("#cbx-input").evaluate((input) => {
  848 |     let changed = false;
  849 |     const meter = { authorizedClears: 0, staleRestores: 0, optionCommits: 0 };
  850 |     (window as unknown as { staleProbeMeter: typeof meter }).staleProbeMeter =
  851 |       meter;
  852 |     document.addEventListener(
  853 |       "click",
  854 |       (event) => {
  855 |         if (
  856 |           changed &&
  857 |           event.target instanceof Element &&
  858 |           event.target.closest("[role='option']") !== null
  859 |         )
  860 |           meter.optionCommits++;
  861 |       },
  862 |       true,
  863 |     );
  864 |     input.addEventListener("input", () => {
  865 |       if (changed) {
  866 |         meter.staleRestores++;
  867 |         return;
  868 |       }
  869 |       if ((input as HTMLInputElement).value !== "") return;
  870 |       meter.authorizedClears++;
  871 |       changed = true;
  872 |       const label = document.querySelector("label[for='cbx-input']");
  873 |       if (label === null) throw new Error("combobox label missing");
  874 |       label.textContent = "Replacement office location";
  875 |     });
  876 |   });
  877 |   const staleAction = await execute(harness, combo, {
  878 |     kind: "OPTION",
  879 |     value_digest: await semanticDigest(`option-value-v1\0${intendedDisplay}`),
  880 |   });
> 881 |   expect(staleAction.result.resolution_result).not.toBe("UNIQUE");
      |                                                    ^ Error: expect(received).not.toBe(expected) // Object.is equality
  882 |   expect(staleAction.result.outcome).not.toBe("VERIFIED");
  883 |   expect(staleAction.undo_available).toBe(false);
  884 |   expect(
  885 |     await harness.page.evaluate(
  886 |       () =>
  887 |         (
  888 |           window as unknown as {
  889 |             staleProbeMeter: {
  890 |               authorizedClears: number;
  891 |               staleRestores: number;
  892 |               optionCommits: number;
  893 |             };
  894 |           }
  895 |         ).staleProbeMeter,
  896 |     ),
  897 |   ).toEqual({ authorizedClears: 1, staleRestores: 0, optionCommits: 0 });
  898 |   // Restoring the old display after a semantic replacement would itself be
  899 |   // an unauthorized write. The single authorized probe clear stays cleared.
  900 |   expect(await harness.page.locator("#cbx-input").inputValue()).toBe("");
  901 | 
  902 |   await harness.page.locator("label[for='cbx-input']").evaluate((label) => {
  903 |     label.textContent = "Office location";
  904 |   });
  905 |   // Explicit test-owned fixture reset: the independent partial-failure
  906 |   // case begins from the same prior display under the restored identity.
  907 |   await harness.page.locator("#cbx-input").fill(priorDisplay);
  908 |   await harness.page.locator("#cbx-input").press("Escape");
  909 |   scanned = await descriptors(harness);
  910 |   combo = descriptorByLabel(scanned, "Office location");
  911 |   await harness.page.locator("#cbx-input").evaluate((input) => {
  912 |     let clearCount = 0;
  913 |     input.addEventListener("input", () => {
  914 |       if ((input as HTMLInputElement).value !== "") return;
  915 |       clearCount += 1;
  916 |       if (clearCount !== 3) return;
  917 |       document
  918 |         .querySelector<HTMLElement>(
  919 |           "[role='option'][data-value='Harbor Point (synthetic)']",
  920 |         )
  921 |         ?.remove();
  922 |     });
  923 |   });
  924 |   const recovered = await execute(harness, combo, {
  925 |     kind: "OPTION",
  926 |     value_digest: await semanticDigest(`option-value-v1\0${intendedDisplay}`),
  927 |   });
  928 |   expect(recovered.result.outcome).toBe("FAILED");
  929 |   expect(recovered.result.recovery).toMatchObject({
  930 |     attempted: true,
  931 |     restored: true,
  932 |   });
  933 |   expect(recovered.undo_available).toBe(false);
  934 |   expect(await harness.page.locator("#cbx-input").inputValue()).toBe(
  935 |     priorDisplay,
  936 |   );
  937 | });
  938 | 
  939 | test("VIRT1/VIRT2: the 480-row windowed list finds one off-window exact target within a bound and refuses absence", async ({
  940 |   extensionContext,
  941 |   extensionId,
  942 |   serviceWorker,
  943 | }) => {
  944 |   // The W10 windowed-listbox driver legitimately walks up to 480 bounded
  945 |   // scroll windows with real settle polls, measured at ~25 s green on the
  946 |   // reference machine — inside the Playwright 30 s default only by margin.
  947 |   // Explicit bounded budget for exactly this scenario (M02-W09 KI-precedent
  948 |   // pattern: per-test budget, no global change, no assertion change).
  949 |   test.setTimeout(60_000);
  950 |   const harness = await openHarness(
  951 |     extensionContext,
  952 |     extensionId,
  953 |     serviceWorker,
  954 |     "/virtualized/",
  955 |   );
  956 |   const scanned = await descriptors(harness);
  957 |   const listbox = descriptorByLabel(scanned, "Assessment cohort");
  958 |   expect(await harness.page.locator("[role=option]").count()).toBeLessThan(30);
  959 |   const selected = await execute(
  960 |     harness,
  961 |     listbox,
  962 |     {
  963 |       kind: "OPTION",
  964 |       value_digest: await semanticDigest("option-value-v1\0COHORT-0417"),
  965 |     },
  966 |     undefined,
  967 |     100,
  968 |   );
  969 |   expect(selected.result.outcome).toBe("VERIFIED");
  970 |   await expect(harness.page.locator("#vl-committed")).toHaveText("COHORT-0417");
  971 |   expect(await harness.page.locator("[role=option]").count()).toBeLessThan(30);
  972 | 
  973 |   const absent = await execute(
  974 |     harness,
  975 |     listbox,
  976 |     {
  977 |       kind: "OPTION",
  978 |       value_digest: await semanticDigest("option-value-v1\0COHORT-9999"),
  979 |     },
  980 |     undefined,
  981 |     25,
```