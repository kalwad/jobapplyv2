# W05 current local full evidence review: PASS

Independent reconciliation: 48/48 checks passed against `185909baee1fdcbf21e779959f40bad30b0231c9` / tree `3c2ba3a601bd1b8c32bb11b52ca79e48d13b92ed`.

This report audits retained local data. It does not decide milestone acceptance, establish a new GUI execution, or validate native hosted platforms. Default benchmark observations are not a fresh 20-sample Gate A experiment.

The producer records the complete curated outer environment. It does not serialize every nested child environment or provide a whole dependency/cache/upfront native test-binary image. Its direct `subprocess.run` timeouts do not prove containment of all descendants.

Tool probe scope is literal: the Python-version probe hashes the resolved `uv` launcher, and pnpm/Node launcher hashes do not authenticate every nested executable. All historical source comparisons use immutable pinned Git objects, not a later mutable checkout.

## Failed checks

None.

## Raw-derived observations

Repository doctor: `pnpm run doctor`, exit 0, 7.542571000s; 28 ordinary PASS, no warnings/failures/N/A. It completed before aggregate start.

Aggregate: `pnpm verify`, exit 0, 1142.433118500s; exact 20 ACTIVE/PASS summary. Verify log: 695161 bytes, SHA-256 `d89f6b5111dfe97c1b3d93aa3a3a7959709e33ec2f908082e9cb29ea50c58a13`.

TypeScript unit summaries total 4006 ordinary passes. Python: 1679 exact collected POSIX IDs, comprising 1677 common IDs plus the declared FIFO/socket pair; actual summary `[('1679', '369.50')]` with no skip/deselection. All 15 registered Rust-stage commands occur in order; each of three desktop feature modes passes the same [183, 183, 183] case cohort with zero failed/ignored/measured/filtered cases. This is three executions of the same 183-case cohort.

Browser ordinary pass summaries by execution: `{'default': ['262'], 'controlled_inspection': ['2'], 'controlled_contact': ['62'], 'visual': ['3']}`. The default execution may already include visual cases; these are execution counts, not a claim of distinct cases across commands.

Printed timing scopes: default native128 1-sample / 0ms-settle value 836.1255000000001ms; separate 200 different W12 page observations with 75ms settlement / 20ms rerender have printed p95 875.4429579999996ms. These are log-record observations, without a fresh independent contact raw replay or 20-sample performance claim.

All 1905 tracked-file path/size/SHA-256 rows match both snapshots and independently authenticated immutable Git blobs. The unchanged runtime payload has 40 files / 29902573 bytes; closed physical read-back confirms the same bytes/modes, manifest `d274dcc7194722a4ec1549043543225d63bf48e5c6c8e55f4049eee4b5ceeea0` and main `fc2293a3d6425093c03ada543249ccdc2050038613cf984b3983aada18032c7c`.

Historical W04 auditor preparation retains its initial 41/42 collection-summary observer correction; the whole-line anchored expression is preserved here. That historical result is not a W05 attempt or outcome. All W05 checks in this report derive from its own closed records; no W04 execution credit is inherited. The canonical native cohort is183 per mode, not187; the separate outside selected four-case recovery derivative keeps its own execution identity.

See `findings.json`, `immutable-git-blob-closure.json`, `python-collected-node-ids.json`, and `native-mode-cases.json` for exact identities, raw-derived counts, and case joins. All failed checker attempts must remain historical if a later parser correction is required.
