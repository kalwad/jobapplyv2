"""Clean current-root doctor/full run with bounded snapshots and curated recorded env."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import platform
import shutil
import subprocess
import time

ap = argparse.ArgumentParser()
ap.add_argument('--expect-head', required=True)
ap.add_argument('--out-dir', type=Path, required=True)
args = ap.parse_args()
R = Path('/Users/tanishkalwad/jobapplyv2')
B = args.out_dir.resolve()
B.mkdir(exist_ok=False)
shutil.copy2(__file__, B / 'executed-wrapper.py')
def sha(p):
    return hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
def write(n,v):
    with (B/n).open('x') as f:
        json.dump(v,f,indent=2)
        f.write('\n')
env = {k: os.environ[k] for k in ['HOME','USER','LOGNAME','TMPDIR','LANG','LC_ALL','CARGO_HOME','RUSTUP_HOME','SDKROOT','DEVELOPER_DIR','MACOSX_DEPLOYMENT_TARGET','XDG_CACHE_HOME'] if k in os.environ}
env.update(PATH='/opt/homebrew/opt/node@24/bin:'+os.environ['PATH'], UV_OFFLINE='true', CARGO_NET_OFFLINE='true', COREPACK_ENABLE_NETWORK='0', GIT_CONFIG_GLOBAL='/dev/null', GIT_CONFIG_SYSTEM='/dev/null')
for key in ['JAPP_W13_PERFORMANCE_SAMPLES','JAPP_W14_REQUIRE_TARGET_PERFORMANCE','JAPP_W14_ARTIFACT_DIRECTORY','JAPP_W14_W06_ARTIFACT_DIRECTORY']:
    assert key not in env
def git(*argv):
    return subprocess.check_output(['git',*argv],cwd=R,env=env)
def snapshot():
    names=git('ls-files','-z').decode().rstrip('\0').split('\0')
    files={}
    for n in names:
        p=R/n
        assert p.is_file() and not p.is_symlink(),n
        files[n]={'bytes':p.stat().st_size,'sha256':sha(p)}
    return {'head':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'status':git('status','--porcelain=v1','--untracked-files=all').decode(),'files':files}
before=snapshot()
assert before['head']==args.expect_head and not before['status']
write('before.json',before)
runtime=R/'apps/desktop/src-tauri/runtime-payload'
def runtime_snapshot():
    rows={}
    for p in sorted(runtime.rglob('*')):
        assert not p.is_symlink()
        if p.is_file():rows[p.relative_to(runtime).as_posix()]={'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)}
    return rows
runtime_before=runtime_snapshot()
assert len(runtime_before)==40 and runtime_before['manifest.json']['sha256']=='d274dcc7194722a4ec1549043543225d63bf48e5c6c8e55f4049eee4b5ceeea0'
write('runtime-before.json',runtime_before)
probes={}
for name,argv in [('node',['node','--version']),('pnpm',['pnpm','--version']),('python',['uv','run','python','--version']),('uv',['uv','--version']),('rust',['rustc','--version'])]:
    exe=Path(shutil.which(argv[0],path=env['PATH'])).resolve(strict=True)
    p=subprocess.run(argv,cwd=R,env=env,capture_output=True,text=True,timeout=60,check=False)
    probes[name]={'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'executable':str(exe),'executable_sha256':sha(exe)}
    assert p.returncode==0
write('environment.json',{'platform':platform.platform(),'machine':platform.machine(),'complete_curated_inherited_environment':dict(env),'probes':probes,'wrapper_sha256':sha(B/'executed-wrapper.py'),'scope':'Current W04 canonical defaults; no20-sample GateA rerun, new GUI, whole dependency/cache or upfront complete binary image claim'})
records=[]
for label,argv,timeout in [('doctor',['pnpm','run','doctor'],300),('verify',['pnpm','verify'],3600)]:
    exe=Path(shutil.which(argv[0],path=env['PATH'])).resolve(strict=True)
    rec={'argv':argv,'cwd':str(R),'environment':dict(env),'executable':str(exe),'executable_sha256_before':sha(exe),'started_utc':datetime.now(timezone.utc).isoformat(),'timeout_seconds':timeout,'source_snapshot_sha256':sha(B/'before.json')}
    write(label+'-upfront.json',rec)
    start=time.monotonic()
    print('RUN '+label+' '+rec['started_utc'],flush=True)
    timed_out=False
    with (B/(label+'.log')).open('xb') as out:
        try:p=subprocess.run(argv,cwd=R,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=timeout,check=False);code=p.returncode
        except subprocess.TimeoutExpired:code=124;timed_out=True
    rec.update(exit_code=code,elapsed_seconds=time.monotonic()-start,ended_utc=datetime.now(timezone.utc).isoformat(),outer_timeout=timed_out,log_bytes=(B/(label+'.log')).stat().st_size,log_sha256=sha(B/(label+'.log')),executable_sha256_after=sha(exe))
    write(label+'-result.json',rec)
    records.append(rec)
    print(json.dumps({'label':label,'exit_code':code,'seconds':rec['elapsed_seconds']}),flush=True)
    if code:break
after=snapshot();write('after.json',after)
runtime_after=runtime_snapshot();write('runtime-after.json',runtime_after)
verdict={'source_unchanged':before==after,'runtime40_unchanged':runtime_before==runtime_after,'both_commands_executed':len(records)==2,'all_executed_commands_exit0':all(x['exit_code']==0 for x in records),'ended_utc':datetime.now(timezone.utc).isoformat(),'milestone_accepted':False,'gui_execution':False,'hosted_ci':False}
write('closure.json',verdict)
print(json.dumps(verdict),flush=True)
raise SystemExit(0 if all(verdict[k] for k in ['source_unchanged','runtime40_unchanged','both_commands_executed','all_executed_commands_exit0']) else 1)
