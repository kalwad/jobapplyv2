from pathlib import Path,PurePosixPath
import gzip,hashlib,io,json,shutil,tarfile
OUT=Path('/tmp/japp-m03-w05-full-reviewed-retained-20261019');OUT.mkdir(exist_ok=False)
H=lambda b:hashlib.sha256(b).hexdigest()
roots={
'raw':Path('/tmp/japp-m03-w05-clean-root-verification-v1-20261019'),
'actual-audit':Path('/tmp/japp-m03-w05-full-independent-audit-20261019'),
'audit-preparation':Path('/tmp/japp-m03-w05-full-audit-preparation-20261019'),
'wrapper-source-review':Path('/tmp/japp-m03-w05-clean-full-wrapper-independent-review-20261019'),
'ip-record-review':Path('/tmp/japp-m03-w05-ip-postintegration-independent-review-20261019')}
payload={};origins={}
def add(name,path):
 assert name not in payload
 q=PurePosixPath(name);assert not q.is_absolute() and '..' not in q.parts and str(q)==name
 assert path.is_file() and not path.is_symlink(),path
 b=path.read_bytes();payload[name]=b;origins[name]={'source':str(path),'bytes':len(b),'sha256':H(b)}
for prefix,root in roots.items():
 for p in sorted(root.rglob('*')):
  if p.is_file():add(prefix+'/'+p.relative_to(root).as_posix(),p)
add('raw/external-source-wrapper.py',Path('/tmp/japp-m03-w05-clean-root-verify-20261019.py'))
add('raw/external-outer.log',Path('/tmp/japp-m03-w05-clean-root-verification-v1-20261019.outer.log'))
add('retention-builder.py',Path('/tmp/japp-retain-m03-w05-full-reviewed-20261019.py'))
find=json.loads(payload['actual-audit/findings.json'])
assert find['decision']=='PASS' and find['passed']==find['total']==48
summary={'scope':'W05_CURRENT_LOCAL_CANONICAL_FULL_DATA_REVIEW','decision':'PASS','checks':48,'review_sha256':H(payload['actual-audit/REVIEW.md']),'auditor_source_sha256':'8833bfdb8ed962f851b9f812b8838d2e930be506834e844795d425c0b1e04989','head':find['head'],'tree':find['tree'],'raw_source_files':len([x for x in origins if x.startswith('raw/')]),'tracked_count':1905,'runtime_count':40,'doctor_passes':28,'active_suites_passed':20,'typescript_passes':4006,'python_passes':1679,'python_seconds':369.50,'native_same_cases_per_mode':[183,183,183],'browser_passes_by_execution':[262,2,62,3],'metric_scope':'Default native128 one sample/zero settle and separate contact200 printed record only; no fresh independent raw replay/20sample claim','hosted_ci_claim':False,'gui_execution_claim':False,'milestone_authority':'NONE','outside_recovery_187_cohort_inherited':False,'earlier_Windows_ci_failure_relabelled':False}
payload['summary.json']=(json.dumps(summary,indent=2,sort_keys=True)+'\n').encode()
payload['README.md']=b'''Finite W05 local full proof and independent actual-data review. All original bytes are preserved. The raw directory contains13 producer files plus the exact external wrapper source and closed outer log. The independent actual audit is first-attempt48/48 PASS; historical W04 collection observer/source history is retained as historical, with no inherited execution credit. Wrapper source review and IP-record review retain their own scopes and prior observer histories.\n\nThis archive contains no toolchain/cache/native binary images or runtime payload. Immutable Git blob closure and40-file runtime endpoint/read-back evidence are serialized in the actual audit; modes are observations there. Tar member metadata is normalized and does not claim original filesystem modes. Curated outer env/tool launcher probes are recorded; nested env, whole-cache/native binary identity and whole descendant containment are not claimed. All183 ordinary native cases execute in each feature mode; the outside187/four-selected derivative stays separate. Printed timing is default1sample/0settle plus separate contact200 record, not target20 or independent contact replay. No hosted Windows/Mac/Linux acceptance, GUI execution or milestone decision is made. Earlier Windows CI failure remains unchanged.\n'''
payload['auditor-invocation.DERIVED.json']=(json.dumps({'record_type':'DERIVED_FROM_ACTUAL_TOOL_RESPONSES_NOT_RAW_SUBPROCESS_STDOUT','argv':['python3','/tmp/japp-m03-w05-full-audit-preparation-20261019/audit-full.py','--confirm-root-reported-completed','--output','/tmp/japp-m03-w05-full-independent-audit-20261019'],'exit_code':0,'decision':'PASS','checks':48,'actual_output_report_sha256':summary['review_sha256'],'no_product_execution':True},indent=2)+'\n').encode()
payload['original-sources.json']=(json.dumps(origins,indent=2,sort_keys=True)+'\n').encode()
index={'scope':'Exact safe regular payload members; members.json excludes only itself','files':[{'path':name,'bytes':len(b),'sha256':H(b)} for name,b in sorted(payload.items())]}
payload['members.json']=(json.dumps(index,indent=2,sort_keys=True)+'\n').encode()
archive=OUT/'proof.tar.gz'
with archive.open('xb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tar:
   for name,b in sorted(payload.items()):
    info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(b))
outer={'archive':{'path':'proof.tar.gz','bytes':archive.stat().st_size,'sha256':H(archive.read_bytes()),'regular_member_count':len(payload),'payload_bytes':sum(len(b) for b in payload.values())},'files':[{'path':n,'bytes':len(b),'sha256':H(b)} for n,b in sorted(payload.items())],'scope':summary['scope'],'metadata':'Safe regular members only. Original payload bytes exact; tar metadata normalized. Exhaustive member list includes embedded self-excluded members.json.'}
(OUT/'retention-manifest.json').write_text(json.dumps(outer,indent=2,sort_keys=True)+'\n')
(OUT/'REVIEW.md').write_bytes(payload['actual-audit/REVIEW.md']);(OUT/'summary.json').write_bytes(payload['summary.json'])
# Read back the entire archive without extraction, preserving original records.
seen=set()
with tarfile.open(archive,'r:gz') as tar:
 for member in tar:
  name=member.name;q=PurePosixPath(name)
  assert member.isreg() and not q.is_absolute() and '..' not in q.parts and name not in seen
  seen.add(name);b=tar.extractfile(member).read();assert b==payload[name]
assert seen==set(payload)
for name,e in origins.items():assert Path(e['source']).read_bytes()==payload[name]
print(json.dumps({'archive':str(archive),**outer['archive'],'review_sha256':summary['review_sha256'],'retention_manifest_sha256':H((OUT/'retention-manifest.json').read_bytes()),'self_readback':'ALL_MEMBERS_AND_ORIGINALS_EXACT'},indent=2))
