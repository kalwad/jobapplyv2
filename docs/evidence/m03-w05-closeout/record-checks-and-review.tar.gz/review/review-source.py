from pathlib import Path,PurePosixPath
import collections,hashlib,json,re,subprocess,tarfile,shutil
R=Path('/Users/tanishkalwad/jobapplyv2');B='185909baee1fdcbf21e779959f40bad30b0231c9';TREE='3c2ba3a601bd1b8c32bb11b52ca79e48d13b92ed';O=Path('/tmp/japp-m03-w05-closeout-records-independent-review-20261019');O.mkdir(exist_ok=False)
H=lambda b:hashlib.sha256(b).hexdigest();checks=[]
def ck(i,v,d=None):checks.append({'id':i,'pass':bool(v),'evidence':d})
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
def load(p):return json.loads(p.read_bytes())
docs=['docs/PROJECT_STATUS.md','docs/TEST_EVIDENCE.md','docs/traceability.json','docs/REQUIREMENTS_TRACEABILITY.md','docs/KNOWN_ISSUES.md','docs/COMPATIBILITY_MATRIX.md'];dirs=['docs/evidence/m03-w05-closeout','docs/evidence/m03-w04-hosted-ci'];new=sorted(str(p.relative_to(R)) for d in dirs for p in (R/d).rglob('*') if p.is_file());selected=docs+new
initial={rel:{'bytes':len((R/rel).read_bytes()),'sha256':H((R/rel).read_bytes())} for rel in selected}
ck('baseline-head-tree',git('rev-parse','HEAD').decode().strip()==B and git('rev-parse','HEAD^{tree}').decode().strip()==TREE)
status=git('status','--porcelain=v1','--untracked-files=all').decode();rows=status.splitlines();tracked=[x[3:] for x in rows if not x.startswith('?? ')];untracked=[x[3:] for x in rows if x.startswith('?? ')]
ck('exact-six-docs-eleven-new-evidence',set(tracked)==set(docs) and set(untracked)==set(new) and len(new)==11,{'tracked':tracked,'new':new})
ck('no-staged-changes',git('diff','--cached','--name-only')==b'')
ck('no-product-test-policy-gate-old-evidence-delta',set(git('diff','--name-only').decode().splitlines())==set(docs),'All product/test/registry/CLAUDE/master/DECISIONS/gate/old-evidence tracked paths outside six docs remain untouched in current Git diff')
old={rel:git('show',B+':'+rel) for rel in docs};pre=Path('/tmp/japp-m03-w05-closeout-records-20261019');receipt=load(pre/'write-closure.json')
ck('writer-source-pin',H((pre/'executed-writer.py').read_bytes())=='739b3cb05e952ea8bcf14a840d78369aca951f8ad125f7e5ec1f8c8a2b83bdac' and (pre/'executed-writer.py').read_bytes()==Path('/tmp/japp-m03-w05-closeout-records-20261019.py').read_bytes())
ck('six-exact-immutable-preimages',all((pre/Path(rel).name).read_bytes()==old[rel] and receipt['preimages'][rel]=={'bytes':len(old[rel]),'sha256':H(old[rel])} for rel in docs))
x=json.loads(old['docs/traceability.json']);y=load(R/'docs/traceability.json');xp={z['id']:z for z in x['work_packages']};yp={z['id']:z for z in y['work_packages']}
ck('all193-requirements-identical',len(x['requirements'])==len(y['requirements'])==193 and x['requirements']==y['requirements'])
ck('top-level-review-hashes-gates-policy-identical',all(x[k]==y[k] for k in x if k!='work_packages'))
changed=[k for k in xp if xp[k]!=yp[k]];ck('exact-two-package-projection',changed==['M03-W05','M03-W06'],changed)
expected=json.loads(json.dumps(xp['M03-W05']));expected.update(current_state='VERIFIED',verified_revision='tree '+TREE,current_evidence=[{'path':'docs/TEST_EVIDENCE.md','heading':'### M03-W05'}]);ck('W05-only-state-tree-evidence',yp['M03-W05']==expected)
expected=json.loads(json.dumps(xp['M03-W06']));expected['current_state']='IN_PROGRESS';ck('W06-only-state',yp['M03-W06']==expected)
ck('other298-package-objects-identical',len(xp)==len(yp)==300 and all(xp[k]==yp[k] for k in xp if k not in changed))
counts=collections.Counter(z['current_state'] for z in y['work_packages']);ck('38-verified-W06-sole-IP',counts['VERIFIED']==38 and [z['id'] for z in y['work_packages'] if z['current_state']=='IN_PROGRESS']==['M03-W06'],dict(counts))
s=(R/'docs/PROJECT_STATUS.md').read_text();so=old['docs/PROJECT_STATUS.md'].decode()
def section(t,h):
 p=t.index(h);e=t.find('\n## ',p+len(h));return t[p:e if e>=0 else None]
ck('milestones-and-critical-gates-unchanged',section(s,'## Milestone table')==section(so,'## Milestone table') and section(s,'## Critical gates')==section(so,'## Critical gates'))
ck('M03-in-progress-release-not-ready', '| M03 | IN_PROGRESS |' in s and 'Overall release gate: NOT_READY' in s)
oldview=old['docs/REQUIREMENTS_TRACEABILITY.md'].decode();view=(R/'docs/REQUIREMENTS_TRACEABILITY.md').read_text();oldlines=oldview.splitlines();newlines=view.splitlines();delta=[(a,b) for a,b in zip(oldlines,newlines) if a!=b]
ck('generated-view-only-three-rows',len(oldlines)==len(newlines) and len(delta)==3 and delta[0]==('- Current package: `M03-W05`','- Current package: `M03-W06`') and delta[1][0].startswith('| M03-W05 |') and delta[2][0].startswith('| M03-W06 |'),delta)
issue=(R/'docs/KNOWN_ISSUES.md').read_text();prior=old['docs/KNOWN_ISSUES.md'].decode();ki108=issue[issue.index('### KI-0108'):issue.index('## M03-W03 validation findings')];ki109=issue[issue.index('### KI-0109'):issue.index('## Current browser validation regression')]
ck('KI108-only-fixed-current-browser-scope','- State: FIXED' in ki108 and 'Old255PASS/1FAIL and missing trace remain unchanged' in ki108 and 'current local W05 all20' in ki108)
ck('KI109-medium-in-progress-honest-loader','- Severity: MEDIUM' in ki109 and '- State: IN_PROGRESS' in ki109 and '0xc0000139' in ki109 and '3221225785' in ki109 and 'later all-features/SDK test modes and final desktop build are unexecuted' in ki109 and 'step26SKIPPED' in ki109)
ck('older-known-issue-history-identical',issue[issue.index('## M03-W03 validation findings'):]==prior[prior.index('## M03-W03 validation findings'):])
# Independently check finite archive copies, every safe member and self-excluded embedded index.
archives=[];stored={}
configs=[('docs/evidence/m03-w05-closeout/clean-full-and-review.tar.gz','37ecebce549472dc78aa010dcbc687a4b230d45d99baf4172878fe0683cde538',56,'members.json','/tmp/japp-m03-w05-full-reviewed-retained-20261019/proof.tar.gz'),('docs/evidence/m03-w04-hosted-ci/terminal-ci.tar.gz','f4b880dd5306c3f1bb8f4a3616c170a6dfce10db37d93b96173ddf6c00fa9d8e',471,'evidence-inputs.json','/tmp/japp-m03-w04-hosted-ci-2a327c6-20261019-retained/proof.tar.gz'),('docs/evidence/m03-w04-hosted-ci/independent-review.tar.gz','1bdd80c1329888f2eade4ee8d0042bd857672951d91b755f0a81c7e538d1b2d1',19,'review-inputs.json','/tmp/japp-m03-w04-terminal-ci-independent-review-20261019-retained/proof.tar.gz')]
for rel,pin,count,index,original in configs:
 p=R/rel;b=p.read_bytes();members={};bad=[]
 with tarfile.open(p,'r:gz') as t:
  for m in t:
   q=PurePosixPath(m.name)
   if not m.isreg() or q.is_absolute() or '..' in q.parts or str(q)!=m.name or m.name in members:bad.append(m.name)
   assert m.isreg();members[m.name]=t.extractfile(m).read()
 embedded=json.loads(members[index]);entries=embedded['files'];by={z['path']:z for z in entries};indexed=set(members)-{index}
 mismatch=[name for name in indexed if name not in by or len(members[name])!=by[name]['bytes'] or H(members[name])!=by[name]['sha256']]
 ok=H(b)==pin and len(members)==count and not bad and set(by)==indexed and not mismatch and Path(original).read_bytes()==b
 ck('archive-binding-'+str(count),ok,{'path':rel,'sha256':H(b),'bytes':len(b),'members':len(members),'payload_bytes':sum(map(len,members.values())),'safe_path_errors':bad,'index_hash_errors':mismatch,'original_copy_exact':Path(original).read_bytes()==b})
 archives.append(checks[-1]['evidence']);stored[rel]=members
full=stored[configs[0][0]];author=stored[configs[1][0]];review=stored[configs[2][0]]
for rel,ext in [('docs/evidence/m03-w05-closeout/full-retention-manifest.json','/tmp/japp-m03-w05-full-reviewed-retained-20261019/retention-manifest.json'),('docs/evidence/m03-w04-hosted-ci/collector-retention-manifest.json','/tmp/japp-m03-w04-hosted-ci-2a327c6-20261019-retained/manifest.json'),('docs/evidence/m03-w04-hosted-ci/review-retention-manifest.json','/tmp/japp-m03-w04-terminal-ci-independent-review-20261019-retained/manifest.json')]:
 ck('exact-retention-copy-'+Path(rel).name,(R/rel).read_bytes()==Path(ext).read_bytes())
for d in dirs:
 a=load(R/d/'artifacts.json');siblings={p.name for p in (R/d).iterdir() if p.is_file()}-{'artifacts.json'}
 ck('exhaustive-artifacts-'+Path(d).name,set(a)==siblings and all(a[n]=={'bytes':len((R/d/n).read_bytes()),'sha256':H((R/d/n).read_bytes())} for n in a))
f=json.loads(full['actual-audit/findings.json']);ci=json.loads(review['observations.json']);cichecks=json.loads(review['checks.json'])
ck('actual-full48-source-counts-preserved',f['decision']=='PASS' and f['passed']==f['total']==48 and f['head']==B and f['tree']==TREE and f['details']['typescript_unit']['total']==4006 and f['details']['python']['collected_count']==1679 and f['details']['native']['cases_per_mode']==[183,183,183])
ck('actual-CI74-remains-failure',cichecks['result']=='PASS' and len(cichecks['checks'])==74 and all(z['result']=='PASS' for z in cichecks['checks']) and ci['run']['conclusion']=='failure' and ci['run']['head_sha']=='2a327c6210bfb7236f3d8a572a3a62e9b7e13d63')
win=next(z for z in ci['platforms'] if z['platform']=='windows-2025');ck('Windows-failure-scope-retained',win['aggregate_passes']==19 and win['aggregate_exit']==1 and win['step26']=='skipped' and win['native_modes'][0]['status']=='FAILED_LOADER' and all(z['status']=='UNEXECUTED' for z in win['native_modes'][1:]) and win['Rust_commands_started']==12)
ck('actual-all-host-browser262-2-62-3',all([z['browser']['default'],z['browser']['controlled_public_research'],z['browser']['controlled_public_contact'],z['browser']['visual']]==[[262],[2],[62],[3]] for z in ci['platforms']))
ck('hosted-masking-and-single-desktop-clippy-qualification',all(text in (R/'docs/TEST_EVIDENCE.md').read_text()[:12000] for text in ['unique unredacted-ID equality is not claimed','Only one of the three strict Clippy commands is desktop','No failed native PE/DLL/trace bytes are inferred']))
ck('native-183-vs-selected4-not-whole187',all(text in (R/'docs/TEST_EVIDENCE.md').read_text()[:12000] for text in ['same183 native IDs','four-case×3','This is not187 executions']))
dec=load(R/'docs/evidence/m03-w05-closeout/decision.json');ck('delegated-decision-source-exact-no-manual-owner',dec['decision_maker']=='/root' and dec['authority']=='OD-037 / ADR-0008' and dec['manual_owner_click'] is False and dec['evaluated_commit']==B and dec['evaluated_tree']==TREE and dec['next_package']=='M03-W06' and dec['M03_accepted'] is False and dec['release_ready'] is False and dec['new_gui_or_hosted_PASS'] is False)
ck('decision-review-hash-joins',dec['full_data_review_sha256']==H(full['actual-audit/REVIEW.md']) and dec['real_recovery_review_sha256']=='17dc1c0a5503b374301abcd93759b3a393ef9dbd0fae7896df1736281cb0bab3')
ck('timing-and-platform-limitations-explicit',all(text in (R/'docs/TEST_EVIDENCE.md').read_text()[:12000] for text in ['No new20sample Gate A, independent contact raw replay or speed comparison','No final UI approval, packaged platform certification, M03 acceptance or release readiness']))
ck('all17-current-inputs-stable',all(initial[rel]=={'bytes':len((R/rel).read_bytes()),'sha256':H((R/rel).read_bytes())} for rel in selected))
passed=sum(z['pass'] for z in checks);verdict='CLEAR_SCOPED_METADATA' if passed==len(checks) else 'FINDINGS'
findings={'decision':verdict,'passed':passed,'total':len(checks),'baseline':B,'tree':TREE,'current_state':'38 VERIFIED; M03-W06 sole IN_PROGRESS; M03 IN_PROGRESS; release NOT_READY','checks':checks,'material_findings':[],'test_execution_performed_by_reviewer':False,'acceptance_authority':'NONE','record_validation_scope':'Root ongoing metadata checks are not inferred from the writer or this source review; actual receipts must remain separately recorded.'}
(O/'findings.json').write_text(json.dumps(findings,indent=2)+'\n');(O/'archive-bindings.json').write_text(json.dumps(archives,indent=2)+'\n');(O/'current-inputs.json').write_text(json.dumps(initial,indent=2,sort_keys=True)+'\n')
(O/'reviewed-records.diff').write_bytes(git('diff','--',*docs));(O/'writer-closure.json').write_bytes((pre/'write-closure.json').read_bytes())
(O/'closed-ci-review.md').write_bytes(review['review.md']);(O/'closed-full-review.md').write_bytes(full['actual-audit/REVIEW.md'])
report=f'''{verdict}: {passed}/{len(checks)} bounded source/data/metadata checks. No material record finding.\n\nThe root delta is exactly six current documentation files plus eleven new proof files. Relative to immutable185909/tree3c2, only W05 and W06 package projections change: W05 IN_PROGRESS→VERIFIED with evaluatedtree3c2 and evidence, W06 NOT_STARTED→IN_PROGRESS. All298 other package objects,193 requirement objects, review/mapping hashes, ownership/dependencies and critical-gate objects are identical. Generated view changes only the current-package line and those two rows. Milestone states and critical-gate status table are unchanged;38 packages are VERIFIED, W06 is sole IN_PROGRESS, M03 stays IN_PROGRESS and release NOT_READY. CLAUDE, master spec, DECISIONS/ADRs, product/test/registry and all old evidence paths have no tracked delta.\n\nThe local W05 decision correctly binds185909/tree3c2/1905 tracked files to first-attempt48/48 actual-data review9e4e and fullproof37ece. Actual doctor28/all20/TS4006/Python1679/native183×3/browser262+2+62+3 and source/runtime neutrality match that data. Separate outside four-case×3 recovery remains scoped, with no whole187, GUI, unsaved-editable-buffer or hosted-platform transfer. Default one-sample timing and printed contact200 remain narrower than target20/raw replay. The delegated record names /root under OD-037/ADR-0008 and claims no owner click, M03 acceptance or release readiness.\n\nThe independent hosted74/74 documentary review and original packet are retained unchanged: run39194489970 at2a327/tree4ce9 remains FAILURE, Ubuntu/macOS20PASS and Windows19PASS/Rust loader failure before any default library case; later Windows modes/final build unexecuted and step26SKIPPED. All-host current browser262+2+62+3 supports the scoped KI0108 cleanup closure. KI0109 is MEDIUM/IN_PROGRESS; actual DLL/export, failedPE and cause/fix are unobserved. Masked Python IDs and only one desktop strict-Clippy command are qualified explicitly. Earlier failures/cancelled runs and documentary observer correction histories are retained. No Windows acceptance or platform package certification follows.\n\nAll three copied archives are byte-identical to their sealed originals: full37ece56 members, hostedf4b880471 members and independent1bdd8019 members. Every member path/type/duplicate, size/hash and self-excluded embedded index was independently read back; all retention copies and both artifact inventories are exact/exhaustive. No large cache, binaries or other old archives were rescanned.\n\nThis is a bounded metadata/evidence truth review. It executes no product, test, compiler, actor, network/API operation or root write. Root's ongoing generation/check/test receipts are separate and are not inferred from this review; their actual completion is required before the planned commit. The evidence README's statement that record validation/different review follows before commit is a temporal statement preserved at this review point.\n'''
(O/'REVIEW.md').write_text(report);shutil.copyfile('/tmp/japp-review-m03-w05-closeout-records-20261019.py',O/'review-source.py')
manifest=[]
for q in sorted(O.rglob('*')):
 if q.is_file():b=q.read_bytes();manifest.append({'path':q.relative_to(O).as_posix(),'bytes':len(b),'sha256':H(b)})
(O/'review-members.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'decision':verdict,'passed':passed,'total':len(checks),'report':str(O/'REVIEW.md'),'report_sha256':H((O/'REVIEW.md').read_bytes()),'findings_sha256':H((O/'findings.json').read_bytes()),'manifest_sha256':H((O/'review-members.json').read_bytes()),'failed':[x for x in checks if not x['pass']]},indent=2))
