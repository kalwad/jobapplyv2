"""Actual metadata regression receipts; no product/full/GUI execution claim."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,time
R=Path('/Users/tanishkalwad/jobapplyv2');B=Path('/tmp/japp-m03-w05-closeout-record-checks-20261019');B.mkdir(exist_ok=False)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def dump(n,v):(B/n).write_text(json.dumps(v,indent=2)+'\n')
def snap():
 names=set(subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().rstrip('\0').split('\0'))|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=R).decode().rstrip('\0').split('\0'));names.discard('')
 return {n:{'bytes':(R/n).stat().st_size,'sha256':sha(R/n)} for n in sorted(names)}
shutil.copy2(__file__,B/'executed-wrapper.py');before=snap();dump('source-before.json',before)
env={k:os.environ[k] for k in ['HOME','USER','LOGNAME','TMPDIR','LANG','LC_ALL','CARGO_HOME','RUSTUP_HOME'] if k in os.environ};env.update(PATH='/opt/homebrew/opt/node@24/bin:'+os.environ['PATH'],UV_OFFLINE='true',CARGO_NET_OFFLINE='true',COREPACK_ENABLE_NETWORK='0',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_SYSTEM='/dev/null')
commands=[('metadata-pytest',['uv','run','pytest','scripts/tests/test_validate_status.py','scripts/tests/test_traceability.py','-q'],300),('status',['uv','run','python','scripts/validate_status.py'],60),('traceability',['pnpm','traceability:check'],60),('diff',['git','diff','--check'],60)]
results=[]
for name,argv,cap in commands:
 exe=Path(shutil.which(argv[0],path=env['PATH'])).resolve(strict=True);rec={'argv':argv,'cwd':str(R),'environment':dict(env),'timeout_seconds':cap,'tool':str(exe),'tool_sha256_before':sha(exe),'started_utc':datetime.now(timezone.utc).isoformat(),'source_before_sha256':sha(B/'source-before.json')};dump(name+'-upfront.json',rec);start=time.monotonic()
 with (B/(name+'.log')).open('xb') as out:
  try:code=subprocess.run(argv,cwd=R,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=cap,check=False).returncode;timedout=False
  except subprocess.TimeoutExpired:code=124;timedout=True
 rec.update(exit_code=code,timeout=timedout,elapsed_seconds=time.monotonic()-start,ended_utc=datetime.now(timezone.utc).isoformat(),log_bytes=(B/(name+'.log')).stat().st_size,log_sha256=sha(B/(name+'.log')),tool_sha256_after=sha(exe));dump(name+'-result.json',rec);results.append(rec);print(json.dumps({'command':name,'exit_code':code,'seconds':rec['elapsed_seconds']}),flush=True)
 if code:break
after=snap();dump('source-after.json',after);ok=before==after and len(results)==4 and all(r['exit_code']==0 and r['tool_sha256_before']==r['tool_sha256_after'] for r in results);dump('closure.json',{'all4commands_exit0':len(results)==4 and all(r['exit_code']==0 for r in results),'source_unchanged':before==after,'source_files':len(before),'verdict':ok,'scope':'Metadata regression only; no new product full/GUI/platform result','ended_utc':datetime.now(timezone.utc).isoformat()});raise SystemExit(0 if ok else 1)
