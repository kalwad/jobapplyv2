"""Guarded W05 closeout and independently audited historical CI record update."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib,json,re,shutil,subprocess,tarfile
R=Path('/Users/tanishkalwad/jobapplyv2');F=Path('/tmp/japp-m03-w05-clean-root-verification-v1-20261019')
HEAD='185909baee1fdcbf21e779959f40bad30b0231c9';TREE='3c2ba3a601bd1b8c32bb11b52ca79e48d13b92ed'
O=Path('/tmp/japp-m03-w05-closeout-records-20261019');E=R/'docs/evidence/m03-w05-closeout';C=R/'docs/evidence/m03-w04-hosted-ci'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(p.read_text())
def dump(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=True)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
def archive(src,dst,digest,count):
 assert sha(src)==digest
 with tarfile.open(src,'r:gz') as t:
  seen=set()
  for m in t.getmembers():
   q=PurePosixPath(m.name);assert m.isfile() and not q.is_absolute() and '..' not in q.parts and m.name not in seen
   seen.add(m.name);assert len(t.extractfile(m).read())==m.size
  assert len(seen)==count
 shutil.copy2(src,dst);assert sha(dst)==digest
assert git('rev-parse','HEAD')==HEAD and git('rev-parse','HEAD^{tree}')==TREE and not git('status','--porcelain=v1','--untracked-files=all')
assert sha(R/'docs/MASTER_IMPLEMENTATION_SPEC.md')=='3eba7bdfbbb1591b5ea54c31bc415fc0cbfd3c361d32005b328f27a12f3ac943'
closed=load(F/'closure.json');assert all(closed[k] is True for k in ['source_unchanged','runtime40_unchanged','both_commands_executed','all_executed_commands_exit0'])
before=load(F/'before.json');assert before==load(F/'after.json') and before['head']==HEAD and before['tree']==TREE and len(before['files'])==1905 and not before['status']
assert load(F/'doctor-result.json')['exit_code']==load(F/'verify-result.json')['exit_code']==0
raw=(F/'verify.log').read_text();assert len(re.findall(r'^[a-z0-9-]+\s+ACTIVE\s+PASS\s*$',raw,re.M))==20
assert len(re.findall(r'^test result: ok\. 183 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;',raw,re.M))==3 and '1679 passed' in raw
assert sha(Path('/tmp/japp-m03-w05-full-independent-audit-20261019/REVIEW.md'))=='9e4e0e04497eb7142e6ed75be7799b1dba6a513105f021078e87825fab28ce99'
assert Path('/tmp/japp-m03-w04-terminal-ci-independent-review-20261019/review.md').read_text().startswith('Independent documentary review PASS: 74/74 checks.')
assert not O.exists() and not E.exists() and not C.exists();O.mkdir();E.mkdir();C.mkdir()
tracked_docs=['docs/PROJECT_STATUS.md','docs/TEST_EVIDENCE.md','docs/traceability.json','docs/REQUIREMENTS_TRACEABILITY.md','docs/KNOWN_ISSUES.md','docs/COMPATIBILITY_MATRIX.md']
pre={n:{'bytes':(R/n).stat().st_size,'sha256':sha(R/n)} for n in tracked_docs}
for n in tracked_docs:shutil.copy2(R/n,O/Path(n).name)
archive(Path('/tmp/japp-m03-w05-full-reviewed-retained-20261019/proof.tar.gz'),E/'clean-full-and-review.tar.gz','37ecebce549472dc78aa010dcbc687a4b230d45d99baf4172878fe0683cde538',56)
shutil.copy2('/tmp/japp-m03-w05-full-reviewed-retained-20261019/retention-manifest.json',E/'full-retention-manifest.json')
archive(Path('/tmp/japp-m03-w04-hosted-ci-2a327c6-20261019-retained/proof.tar.gz'),C/'terminal-ci.tar.gz','f4b880dd5306c3f1bb8f4a3616c170a6dfce10db37d93b96173ddf6c00fa9d8e',471)
archive(Path('/tmp/japp-m03-w04-terminal-ci-independent-review-20261019-retained/proof.tar.gz'),C/'independent-review.tar.gz','1bdd80c1329888f2eade4ee8d0042bd857672951d91b755f0a81c7e538d1b2d1',19)
shutil.copy2('/tmp/japp-m03-w04-hosted-ci-2a327c6-20261019-retained/manifest.json',C/'collector-retention-manifest.json')
shutil.copy2('/tmp/japp-m03-w04-terminal-ci-independent-review-20261019-retained/manifest.json',C/'review-retention-manifest.json')
(E/'README.md').write_text('''# M03-W05 scoped closeout

Evaluated commit185909baee1fdcbf21e779959f40bad30b0231c9,
tree3c2ba3a601bd1b8c32bb11b52ca79e48d13b92ed,1905 tracked paths.
Actual clean doctor28 and all20 canonical suites pass. Different full-data review
passes48/48; all immutable source bytes and runtime40 match before/after.
Prior shipping/source/counterproof, canonical parallel183 per mode, serial183 per
mode and real selected4 recovery cases per mode remain separately source-bound in
../m03-w05-recovery. No whole187 execution is inferred.

/root records W05 VERIFIED under OD-037/ADR-0008 and continues W06 immediately.
No new GUI, unsaved editable-buffer action, native packaged platform support,
final UI baseline, M03 acceptance or release readiness is recorded. The separately
retained historical hosted2a327 run is Ubuntu/macOS PASS/Windows loaderFAIL;
its actual browser passes close KI-0108 only, and KI-0109 remains IN_PROGRESS.
Original failures, unavailable PE/DLL and narrower benchmark scopes are retained.
Current mapping requirements/hashes/ownership/dependencies stay unchanged.
Applicable record validation and different metadata review follow before commit.
''')
(C/'README.md').write_text('''# Actual terminal hosted CI for immutable2a327 source

Run39194489970 is FAILURE. Ubuntu and macOS pass all20 suites; Windows passes19
and fails the desktop default test loader with0xc0000139/3221225785 before any
library case. Later native modes and final app build are unexecuted; Windows
step26 is SKIPPED. Browser262+2+62+3 and Python1677 pass on Windows. POSIX Python
is1679; Ubuntu native137 and macOS138 pass in each of three modes. The raw masked
Python multisets differ only by the two declared FIFO/socket IDs; unique unredacted
hosted-ID equality is not claimed. Three strict Clippy commands cover three
workspaces, with only one desktop Clippy command.

All three actual PR merge checkouts bdeb5ddae0ade030b5d0be2aa95dd3a8288fc03b
have immutable tree4ce9cf0c1f5515252a029584f820ea674a66e05e, equal to evaluated
head2a327c6210bfb7236f3d8a572a3a62e9b7e13d63/1886 tracked files. Separate
independent documentary review passes74/74 without relabeling the CI outcome.
All365 Git trees and34 selected source blobs,471 author members,89 operation
receipts,388 raw references, official86-member ZIP and10-member visual-only
artifact are verified. No failed native PE/DLL, trace or error-context bytes exist
in that visual artifact. No cause, speed, GUI, package/platform or M03 PASS follows.
The old failed/cancelled runs remain historical; current local W05 is separate.
''')
dump(E/'decision.json',{'work_package':'M03-W05','decision':'VERIFIED','decision_maker':'/root','authority':'OD-037 / ADR-0008','manual_owner_click':False,'evaluated_commit':HEAD,'evaluated_tree':TREE,'source_files':1905,'doctor_pass':28,'active_suites_pass':20,'counts':{'Python':1679,'TypeScript':4006,'native_each_three_modes':183,'default_browser':262,'controlled_inspection':2,'controlled_contact':62,'visual':3},'full_data_review_sha256':'9e4e0e04497eb7142e6ed75be7799b1dba6a513105f021078e87825fab28ce99','real_recovery_review_sha256':'17dc1c0a5503b374301abcd93759b3a393ef9dbd0fae7896df1736281cb0bab3','next_package':'M03-W06','M03_accepted':False,'release_ready':False,'new_gui_or_hosted_PASS':False,'KI0108':'FIXED currentbrowserrevalidation','KI0109':'IN_PROGRESS Windowslibraryloaderfailure'})
for d in (E,C):dump(d/'artifacts.json',{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(d.iterdir()) if p.is_file()})
x=load(R/'docs/traceability.json');oldx=json.loads(json.dumps(x))
for row in x['work_packages']:
 if row['id']=='M03-W05':
  assert row['current_state']=='IN_PROGRESS';row.update(current_state='VERIFIED',verified_revision='tree '+TREE,current_evidence=[{'path':'docs/TEST_EVIDENCE.md','heading':'### M03-W05'}])
 elif row['id']=='M03-W06':assert row['current_state']=='NOT_STARTED';row['current_state']='IN_PROGRESS'
assert x['requirements']==oldx['requirements'] and x['review']==oldx['review']
assert [r for r in x['work_packages'] if r['id'] not in {'M03-W05','M03-W06'}]==[r for r in oldx['work_packages'] if r['id'] not in {'M03-W05','M03-W06'}]
dump(R/'docs/traceability.json',x)
p=R/'docs/PROJECT_STATUS.md';s=p.read_text();s=s.replace('Repository revision: M03-W04 VERIFIED at2a327c6/tree4ce9cf0; M03-W05 IN_PROGRESS; M02 ACCEPTED / Gate A PASS','Repository revision: M03-W05 VERIFIED at185909b/tree3c2ba3a; M03-W06 IN_PROGRESS; M02 ACCEPTED / Gate A PASS',1);s=s.replace('Current work package: M03-W05','Current work package: M03-W06',1)
a=s.index('## Active work\n');b=s.index('## Milestone table\n',a)
s=s[:a]+'''## Active work

- State: M03-W06 is the sole IN_PROGRESS package;38/300 packages VERIFIED. M00/M01/M02 remain ACCEPTED and Gate A PASS. M03 stays IN_PROGRESS;release NOT_READY.
- Completed prerequisite: W05 VERIFIED at185909b/tree3c2ba3a after actual doctor28/all20 PASS,Python1679/TypeScript4006/native183 in each of three modes/browser262+2+62+3, unchanged1905 source/runtime40 and different48/48 full-data review. Separately reviewed real four-case recovery proof each3 modes retains its own identity.
- Objective: actual macOS arm64 development package and common lifecycle contract, without interactive-terminal dependence. Reviewed cross-platform packaging/path source remains preparatory outside root; no package, native launch or W06 PASS is inferred from it. Apply and validate the reviewed Windows test-manifest correction while preserving its unconfirmed causal scope.
- Execution: continue all eligible work without routine approval prompts under OD-035–037. Measured evidence, different reviews, numerical/safety limits and exact ADR-0006/0007 waivers remain binding.
- Hosted2a327 run39194489970 is terminalFAILURE: Ubuntu/macOS20PASS;Windows19PASS/RustloaderFAIL before library tests. Browser262+2+62+3 passes on every host, closing KI-0108 after local/source/regression and different74/74 data review. KI-0109 tracks the distinct native loader issue; later Windows native modes/final build and step26 remain unexecuted/SKIPPED.
- Evidence: docs/evidence/m03-w05-closeout, docs/evidence/m03-w05-recovery and docs/evidence/m03-w04-hosted-ci. No new GUI/unsaved editable buffer, native Windows11/Ubuntu GNOME package, final UI baseline, M03 acceptance or release readiness is asserted.

'''+s[b:]
old='| `M03-W05` | IN_PROGRESS | — | — | Add crash/restart behavior |';assert s.count(old)==1;s=s.replace(old,'| `M03-W05` | VERIFIED | tree '+TREE+' | docs/TEST_EVIDENCE.md § M03-W05 | Add crash/restart behavior |',1)
old='| `M03-W06` | NOT_STARTED | — | — | Package development build |';assert s.count(old)==1;s=s.replace(old,'| `M03-W06` | IN_PROGRESS | — | — | Package development build |',1)
s=s.replace('Reason: M03-W05 is IN_PROGRESS after verified M03-W04.','Reason: M03-W06 is IN_PROGRESS after verified M03-W05.',1);p.write_text(s)
p=R/'docs/KNOWN_ISSUES.md';s=p.read_text();a=s.index('### KI-0108');b=s.index('## M03-W03 validation findings',a);part=s[a:b];assert part.count('- State: IN_PROGRESS')==1;part=part.replace('- State: IN_PROGRESS','- State: FIXED',1);part+='- Closure (2026-10-19UTC): actual source-bound run39194489970 browser262+2+62+3 passes on Windows, Ubuntu and macOS; current local W05 all20 also passes, with preserved source/counterproof and separate CI documentary74/74 review. This closes the cleanup/failure-artifact correction scope, while the new Windows Rust loader failure is KI-0109. Old255PASS/1FAIL and missing trace remain unchanged. See docs/evidence/m03-w04-hosted-ci and docs/evidence/m03-w05-closeout.\n\n';s=s[:a]+part+s[b:]
marker='## Current browser validation regression (2026-10-19UTC)';assert s.count(marker)==1
new='''## Current Windows native validation finding (2026-10-19UTC)

### KI-0109 — Desktop unit-test executable fails before startup on Windows

- Severity: MEDIUM
- State: IN_PROGRESS
- Discovered: 2026-10-19UTC in hosted run39194489970,Windows job117874182536
- Affects: M03 native test/build infrastructure / REQ-PLAT-013; Windows desktop library test executable
- Description: default cargo test links then exits0xc0000139 STATUS_ENTRYPOINT_NOT_FOUND before any library test summary. Windows aggregate is19PASS/RustFAIL; later all-features/SDK test modes and final desktop build are unexecuted. Three strict Clippy commands cover three workspaces, only one desktop. No failed-PE import, actual missing DLL/export or production-app failure is observed.
- Reproduction: immutable2a327/tree4ce9, actual PRmerge bdeb5ddae0ade030b5d0be2aa95dd3a8288fc03b; `cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml` launches japp_desktop-d259cde1f90c873d.exe and returns3221225785. Official logs ZIP72304ac2157ecb71b9a2192dab7ce9e228786d1b06a70867861ccb26f21d0e42 and exact raw lines are retained. The downloadable artifact has10visualPNGs, no native PE/DLL/trace.
- Workaround: none used; canonical failure remains failed, Windows step26SKIPPED. Mac/local results grant no Windows startup PASS.
- Resolution + evidence link: investigate the source-supported Common Controls v6 test-manifest gap and evaluate the separately reviewed target-scoped candidate with actual Windows PE/resource/unchanged native tests. Cause/fix and normal-app resource merging remain unvalidated. Add bounded failure-only native diagnostics without weakening canonical exit handling. See docs/evidence/m03-w04-hosted-ci and docs/TEST_EVIDENCE.md; current work continues in W06.

''';p.write_text(s.replace(marker,new+marker,1))
p=R/'docs/COMPATIBILITY_MATRIX.md';s=p.read_text();pos=s.index('\n## ');s=s[:pos]+'''
## M03-W05 scoped recovery and actual2a327 hosted result (2026-10-19UTC)

W05 is VERIFIED at185909b/tree3c2ba3a after current clean local doctor28/all20,
Python1679/TypeScript4006/native183 per three modes/browser262+2+62+3 and
independent48/48 review. Separate real selected4 recovery cases per mode pass;
no whole187 or new GUI/unsaved-buffer action is claimed. M03 remains IN_PROGRESS,
W06 begins and release stays NOT_READY.

Independent source-bound hosted2a327 run39194489970 is Ubuntu/macOS20PASS and
Windows19PASS/RustloaderFAIL before default library tests. Later Windows native
modes/final build are unexecuted, step26SKIPPED. Current browser groups pass on all
hosts, closing KI-0108 only; KI-0109 remains IN_PROGRESS. Actual artifacts include
10 visual PNGs, no failed native PE/DLL/trace. Hosted Python masked multisets differ
by the declared POSIX pair; no unique unredacted hosted-ID equality is claimed.
No cause, performance20-sample, native Windows11/default-GNOME package, final visual
baseline or certified platform/support row follows. Exact evidence is retained in
docs/evidence/m03-w05-closeout and docs/evidence/m03-w04-hosted-ci.
'''+s[pos:];p.write_text(s)
entry='''### M03-W05 — Verified bounded recovery; W06 development packaging begins (2026-10-19UTC)

- Evaluated source: commit185909baee1fdcbf21e779959f40bad30b0231c9/tree3c2ba3a601bd1b8c32bb11b52ca79e48d13b92ed,1905 tracked files; macOS arm64/Node24.18.0/pnpm11.17.0/Python3.12.13/uv0.11.32/Rust1.97.1. Actual clean `pnpm run doctor` exits0/28PASS7.542571s; no-argument `pnpm verify` exits0/all20 ACTIVE PASS1142.4331185s. All1905 source bytes match both snapshots and immutable Git blobs; staged40 runtime files/29,902,573bytes and modes remain exactd274/fc229. No new runtime build or GUI is inferred.
- Actual counts: TypeScript4006;Python1679PASS369.50s,exact1677common+FIFO/socket with no skip/deselection; all15Rust registry commands run, including strict checks and final build; the same183 native IDs pass in each default/all-features/direct SDK protocol mode with0failed/ignored/filtered. Browser execution counts262default8.8m/2inspection1.7s/62contact38.6s/3visual6.3s retain overlap rather than distinct-case credit.
- Different current full-data audit PASS48/48, first invocation0, REVIEW9e4e0e04497eb7142e6ed75be7799b1dba6a513105f021078e87825fab28ce99. Raw695161bytes/d89f6b5111dfe97c1b3d93aa3a3a7959709e33ec2f908082e9cb29ea50c58a13. Selected56safe-member raw/review/source-history archive37ecebce549472dc78aa010dcbc687a4b230d45d99baf4172878fe0683cde538/572626bytes is retained with exhaustive manifest in docs/evidence/m03-w05-closeout. Full curated outer env is recorded; nested environments/full cache images/upfront complete native images and whole-descendant timeout containment are not claimed.
- Required recovery behavior has separate reviewed shipping/source/counterproof closure, canonical parallel183×3, outside serial183×3 and actual private-owner four-case×3 evidence in docs/evidence/m03-w05-recovery. Its different17dc1c0a data review confirms two automatic replacements/terminal budget exhaustion, Quit during backoff, real24s delayed-driver fence and one failed replacement/no hidden loop,12selected executions/18registered native spawns. This is not187 executions, Wry/AppHandle/GUI, stalled-startup/late-ACK or editable unsaved-buffer proof; existing frontend stays mounted and has no editable product form. Numerical limits and original failures remain intact.
- Timing observations: ordinary default target1sample/zero-settle836.1255ms and separate200-page contact printedp95875.442958ms/75mssettle/20msrerender. No new20sample Gate A, independent contact raw replay or speed comparison is granted. M02/Gate A evidence is unchanged.
- Separate actual hosted39194489970 at head2a327/tree4ce9/1886files, testedmerge bdeb5ddae0ade030b5d0be2aa95dd3a8288fc03b: Ubuntu/macOS20PASS;Windows19PASS/RustloaderFAIL0xc0000139/3221225785 before any default library case. Later Windows native modes/finalbuild unexecuted and step26SKIPPED. Ubuntu native137×3/Mac138×3, Python1679/1679/1677,TS4006/browser262+2+62+3 all hosts. Masked hosted Python multisets differ only by declared POSIX FIFO/socket cases; unique unredacted-ID equality is not claimed. Only one of the three strict Clippy commands is desktop. No Windows native PASS transfers from Mac/local results.
- Different hosted documentary review PASS74/74 verifies471safe author members,89operationreceipts,388raw references,365Git trees/34selectedblobs, official86-member logs ZIP72304ac2157ecb71b9a2192dab7ce9e228786d1b06a70867861ccb26f21d0e42 and actual10visual-PNG artifact01c3173c. No failed native PE/DLL/trace bytes are inferred. Original observer/parser failures and old product failures remain. Authorpacketf4b880dd/7,960,344bytes and19-member reviewerpacket1bdd80c1/32,263bytes are in docs/evidence/m03-w04-hosted-ci. KI-0108 is FIXED by source/regression/local and actual all-host browser revalidation; distinct KI-0109 is IN_PROGRESS, with source-supported manifest candidate unvalidated on Windows and cause unconfirmed.
- Delegated decision: /root records W05 VERIFIED under OD-037/ADR-0008 after the required actual results and different reviews;38/300VERIFIED. W06 becomes sole IN_PROGRESS immediately for actual macOS arm64 development packaging/common lifecycle. All requirements, mapping hashes/history, ownership, gate effects and298other package objects stay exact; only W05/W06 current-state/evidence projection changes and its canonical view is regenerated. No final UI approval, packaged platform certification, M03 acceptance or release readiness follows. Applicable record checks and different metadata review follow before commit.

'''
p=R/'docs/TEST_EVIDENCE.md';s=p.read_text();assert s.count('## Entries\n\n')==1;p.write_text(s.replace('## Entries\n\n','## Entries\n\n'+entry,1))
dump(O/'write-closure.json',{'writer_sha256':sha(Path(__file__)),'preimages':pre,'state':'38VERIFIED/W06IP; metadata checks and different review REQUIRED before commit','product_source_changed':False,'requirements_and_review_mapping_unchanged':True,'recorded_utc':datetime.now(timezone.utc).isoformat()});shutil.copy2(__file__,O/'executed-writer.py')
print(json.dumps({'metadata_written':True,'W05':'VERIFIED','W06':'IN_PROGRESS','verified':38,'KI0108':'FIXED','KI0109':'IN_PROGRESS','checks_before_commit':'REQUIRED'}))
