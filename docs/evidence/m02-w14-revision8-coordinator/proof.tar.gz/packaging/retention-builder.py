"""Retain closed raw directories byte-for-byte; never runs product tools."""

from pathlib import Path, PurePosixPath
import argparse
import gzip
import hashlib
import io
import json
import stat
import tarfile


def sha(body):
    return hashlib.sha256(body).hexdigest()


def source_files(base):
    if base.is_symlink() or not base.is_dir():
        raise RuntimeError('REGULAR_SOURCE_DIRECTORY_REQUIRED:' + str(base))
    result = {}
    for path in sorted(base.rglob('*')):
        if path.is_symlink():
            raise RuntimeError('SOURCE_SYMLINK_REFUSED:' + str(path))
        if path.is_dir():
            continue
        if not stat.S_ISREG(path.lstat().st_mode):
            raise RuntimeError('SOURCE_REGULAR_FILE_REQUIRED:' + str(path))
        result[path.relative_to(base).as_posix()] = path.read_bytes()
    return result


def retain(output, sources, scope):
    if output.exists() or output.is_symlink():
        raise RuntimeError('FRESH_RETENTION_DIRECTORY_REQUIRED')
    snapshots = [(prefix, base, source_files(base)) for prefix, base in sources]
    payload = {}
    for prefix, base, members in snapshots:
        for path, body in members.items():
            name = prefix + '/' + path
            parsed = PurePosixPath(name)
            if parsed.is_absolute() or '..' in parsed.parts or '\\' in name or name in payload:
                raise RuntimeError('UNSAFE_OR_DUPLICATE_MEMBER:' + name)
            payload[name] = body
    payload['packaging/retention-builder.py'] = Path(__file__).read_bytes()
    declared = [{'path': name, 'bytes': len(body), 'sha256': sha(body)} for name, body in sorted(payload.items())]
    index = {'format_version': 'RETAINED_ORIGINAL_MEMBER_INVENTORY_1', 'authority': 'NONE', 'scope': scope, 'files': declared, 'self_exclusion': 'This index excludes itself; the outer retention manifest includes its exact hash and bytes.'}
    payload['retained-members.json'] = (json.dumps(index, indent=2) + '\n').encode()
    all_members = [{'path': name, 'bytes': len(body), 'sha256': sha(body)} for name, body in sorted(payload.items())]
    output.mkdir()
    archive = output / 'proof.tar.gz'
    with archive.open('xb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as tar:
        for name, body in sorted(payload.items()):
            item = tarfile.TarInfo(name)
            item.size = len(body)
            item.mode = 0o644
            item.mtime = 0
            tar.addfile(item, io.BytesIO(body))
    manifest = {'archive_path': 'proof.tar.gz', 'archive_sha256': sha(archive.read_bytes()), 'archive_bytes': archive.stat().st_size, 'regular_members': len(all_members), 'files': all_members, 'embedded_inventory': 'retained-members.json', 'scope': scope, 'authority': 'NONE'}
    (output / 'retention-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    # Exhaustively reread the archive and the still-closed source directories.
    found = {}
    with tarfile.open(archive, 'r:gz') as tar:
        for item in tar:
            path = PurePosixPath(item.name)
            if not item.isfile() or item.issym() or item.islnk() or path.is_absolute() or '..' in path.parts or item.name in found:
                raise RuntimeError('UNSAFE_ARCHIVE_MEMBER:' + item.name)
            stream = tar.extractfile(item)
            if stream is None:
                raise RuntimeError('UNREADABLE_ARCHIVE_MEMBER:' + item.name)
            found[item.name] = stream.read()
    if found != payload or len(found) != manifest['regular_members']:
        raise RuntimeError('ARCHIVE_PAYLOAD_MISMATCH')
    for prefix, base, members in snapshots:
        if source_files(base) != members:
            raise RuntimeError('SOURCE_CHANGED_DURING_RETENTION:' + str(base))
    summary = {'authority': 'NONE', 'result': 'BYTE_EXACT_RETENTION_PREPARED_PENDING_PEER_ARCHIVE_AUDIT', 'archive_sha256': manifest['archive_sha256'], 'archive_bytes': manifest['archive_bytes'], 'regular_members': len(found), 'original_source_files': sum(len(row[2]) for row in snapshots), 'source_directories': [str(row[1]) for row in snapshots], 'safe_unique_regular_members': True, 'outer_manifest_exhaustive_including_embedded_index': True, 'source_bytes_unchanged_during_retention': True, 'tests_builds_actors_browsers_root_writes': 0, 'scope': scope}
    (output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    (output / 'report.md').write_text('Byte-exact retention prepared; independent archive audit pending.\n\n' + scope + '\n\nArchive SHA-256: `' + manifest['archive_sha256'] + '`; ' + str(manifest['archive_bytes']) + ' bytes; ' + str(len(found)) + ' safe unique regular members. All original bytes, source paths, raw logs/rows/reports and existing history are preserved. Every member, including the embedded index, has an outer SHA/size entry. No tests, actors, builds, browsers or root writes occurred.\n')
    return summary


def main():
    parser = argparse.ArgumentParser()
    choice = parser.add_mutually_exclusive_group(required=True)
    choice.add_argument('--coordinator-only', action='store_true')
    choice.add_argument('--full-audit-is-sealed', action='store_true')
    args = parser.parse_args()
    if args.coordinator_only:
        result = retain(Path('/tmp/japp-w14-r8-coordinator-fc-retained'), [('proposal', Path('/tmp/japp-w14-r8-coordinator-proposal')), ('independent-review', Path('/tmp/japp-w14-r8-coordinator-independent-review'))], 'Historical reviewed revision8 coordinator for exact fc48930, including rejected revision1 findings and clear revision2 review. It remained UNEXECUTED and UNRELEASED because the matching frozen full run failed. No candidate/legacy output or comparison outcome is inherited or claimed; no W15/Gate A authority.')
    else:
        frozen = Path('/tmp/japp-w14-focus-frozen-20261016')
        before = json.loads((frozen / 'before.json').read_text())
        after = json.loads((frozen / 'after.json').read_text())
        complete = json.loads((frozen / 'completion.json').read_text())
        if before['head'] != 'fc48930fd880795f72972fd97e2e69d68e636855' or before['tree'] != 'cb787f46afec1281c87074a82fd31e23b37c865a' or after['head'] != before['head'] or after['tree'] != before['tree'] or before['status'] != '' or after['status'] != '' or before['tracked_files'] != after['tracked_files'] or complete['exit_code'] != 1:
            raise RuntimeError('EXACT_FAILED_NEUTRAL_FC_CLOSURE_REQUIRED')
        audit = Path('/tmp/japp-w14-fc-full-audit-preparation')
        if len(source_files(audit)) <= 3:
            raise RuntimeError('FINAL_AUDIT_REPORT_NOT_YET_RETAINED')
        result = retain(Path('/tmp/japp-w14-focus-frozen-fc-retained'), [('frozen-full', frozen), ('independent-audit', audit)], 'Closed historical full pnpm verify at clean fc48930fd880795f72972fd97e2e69d68e636855 / tree cb787f46afec1281c87074a82fd31e23b37c865a; exit1, tracked-neutral, ended2026-10-16T23:01:46Z. Preserve complete raw full output, original source/command/snapshots, all benchmark/contact rows/reports and final independent audit. The target native12820 performance failure remains a failure; other passing scopes cannot replace it. No new current-runtime, whole-pass, R8 comparison, native-platform, W15 or Gate A approval is inferred.')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
