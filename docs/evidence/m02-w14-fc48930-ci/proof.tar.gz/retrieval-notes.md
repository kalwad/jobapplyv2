# Retrieval and scope notes

All evidence requests were read-only GitHub connector or `gh api` GET operations for repository `kalwad/jobapplyv2`, exact run 38979349323 or exact head fc48930fd880795f72972fd97e2e69d68e636855. No run was retried, rerun, cancelled, or replaced. Status polling backed off from roughly one minute to three minutes while unchanged. Terminal raw logs were fetched once for each job and preserved byte-for-byte.

An initial supplemental source request guessed `packages/contracts/test/unit/infrastructure.test.ts` and returned HTTP 404. The raw error is `source-test_infrastructure.api.raw.json` with its `.stderr` file. The known historical source path is `packages/contracts/test/contract/infrastructure.test.ts`; its successful separate response is `source-infrastructure-actual.api.raw.json`. This source retrieval correction is not a CI failure or a retry of failed CI.

GitHub Git Data commit metadata, root tree metadata, and the exact root tree byte preimage are retained. This bundle is not a complete repository clone and does not contain every Git blob. Six relevant decoded source snapshots are independently checked against their Git blob SHA-1 identifiers and response sizes; their SHA-256 hashes appear in `source-files.json`.

Raw public CI output retains the producer's complete available stdout/stderr. No failure stack or terminal summary is missing on this run. Prior d99/918 failures remain separate historical archives and are not relabelled successful by this run. The previously stackless 918 contact test's underlying cause remains unproven.

The successful native CI evidence is limited to the exact fc tree. The native128 one-sample CI observations are distinct from the parent target-machine 20-sample campaign; later local source is not covered.
