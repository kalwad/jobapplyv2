from pathlib import Path
import json,tarfile,hashlib
P=Path('/tmp/japp-w14-acceptance-audit-20261017-ao4fj67t');R=Path('/Users/tanishkalwad/jobapplyv2')
def sha(p):return 'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()
x=json.loads((P/'candidate-evidence-index.json').read_text());y=json.loads((P/'canonical-benchmark-results-200.json').read_text());f=json.loads((P/'feature-crosswalk-clean730.json').read_text());m=json.loads((P/'mounted32-retention-independent-audit.json').read_text())
with tarfile.open(R/'docs/evidence/m02-w14-frozen-730c641/proof.tar.gz','r:gz') as t:c=json.load(t.extractfile('frozen-full/w14/canonical-execution.json'))
assert y['canonical_results']==[r['canonical_result'] for r in c['records']]
idx=x['execution_scope']['contact200']['per_case_result_index'];assert len(idx)==len(y['canonical_results'])==200
for i,(a,b,source) in enumerate(zip(idx,y['canonical_results'],c['records'],strict=True)):
 assert a['ordinal_in_canonical_execution']==i and a['result_id']==b['result_id'] and a['case_id']==b['case_id'] and a['case_digest']==b['case_digest']
 assert a['artifact_report_digests']==b['artifact_report_digests'] and a['observation_digest']==source['observation_digest']
assert len({r['result_id'] for r in idx})==len({r['case_id'] for r in idx})==200
assert len(f['w03_transition_clauses'])==67 and all(r['raw_pass_matches'] for c in f['w03_transition_clauses'] for r in c['fixture_source_refs'])
assert all(r['raw_pass_matches'] for a in f['features'] for k in ['fixture_refs','core_refs'] for r in a[k])
assert any(a['feature']=='Supported open shadow DOM' and len(a['core_refs'])>=19 for a in f['features'])
a=x['execution_scope']['mounted_original_mock_catalog']['current1d_retention_run'];assert a['independent_audit']['sha256']==sha(P/'mounted32-retention-independent-audit.json') and a['audit_passed']==m['checks_passed']==173 and m['checks_failed']==0
for key in ['predeclared_cohort','assessment','raw_attachment']:
 assert a[key]['sha256']==sha(Path(a[key]['path']))
for key in ['local_full','actual_legacy_R9','final_1d_native_CI']:
 v=x['immutable_evaluation_anchors'][key]['archive'];assert v['sha256']==sha(Path(v['path']))
assert x['accepted_scope']['adr_0007_source_digest'] is None and x['gate_state']=='IN_PROGRESS' and x['authority']=='NONE'
assert 'GateEvidenceBundleV2' not in x.get('artifact_kind','')
print('PASS: all200 exact canonical objects/IDs/rawdigests, all67 fixture mappings, all19 feature groups, current mounted173 proof and source archives; no gate authority/new schema/truncation')
