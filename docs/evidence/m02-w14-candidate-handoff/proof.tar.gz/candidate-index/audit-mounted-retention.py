from pathlib import Path
import json,gzip,hashlib,re,collections,subprocess,unicodedata
BASE=Path('/tmp/japp-w14-mounted-retention-20261017');OUT=Path('/tmp/japp-w14-acceptance-audit-20261017-ao4fj67t');ROOT=Path('/Users/tanishkalwad/jobapplyv2')
def sha(b):return 'sha256:'+hashlib.sha256(b).hexdigest()
def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def load(n):return json.loads((BASE/n).read_text())
def meta(p):b=p.read_bytes();return {'path':str(p),'digest':sha(b),'bytes':len(b)}
checks=[]
def check(name,ok,detail=None):
 checks.append({'check':name,'passed':bool(ok),'detail':detail})
 if not ok:raise AssertionError(name+': '+str(detail))
before=load('before.json');after=load('after.json');completion=load('completion.json');command=load('command.json');results=load('results.json');assessment=load('payload/assessment.json');raw=(BASE/'payload/mounted-run.json.gz').read_bytes();bundle=json.loads(gzip.decompress(raw));expected=load('payload/predeclared-cohort.json');rows=bundle['rows']
check('exit0/no timeout',completion['exit_code']==0 and completion['timed_out'] is False)
check('one ordinary test/no unexpected/skipped/flaky',results['stats']['expected']==1 and results['stats']['unexpected']==0 and results['stats']['skipped']==0 and results['stats']['flaky']==0,results['stats'])
check('exact final1d head/tree before and after',before['head']==after['head']=='1d490d1230b443c31fd4a9d8732064552affe149' and before['tree']==after['tree']=='ac98b18d71fffc6cc0ff7fc07ccd32ccda8133d9')
check('1534 tracked inventory exact endpoints',before['tracked_files']==after['tracked_files'] and len(before['tracked_files'])==1534)
check('actual status stable',before['status']==after['status']=='?? docs/evidence/m02-w14-1d490d-ci/')
check('wrapper digest',command['wrapper_sha256']==hashlib.sha256(Path('/tmp/japp-w14-mounted-retention-run-20261017.py').read_bytes()).hexdigest())
check('wrapper single unchanged spec trace on',command['argv']==['pnpm','exec','playwright','test','e2e/extension/extension-w14-w06.spec.ts','--trace','on','--output',str(BASE/'artifacts'),'--reporter=list,json'])
check('raw compressed digest',sha(raw)==assessment['compressed_bundle_digest'])
check('predeclared cohort exact raw expected',expected==bundle['expected'])
check('predeclared expected digest',sha(canonical(expected))==bundle['expected_digest'])
check('11 explicit synthetic facts',len(expected['facts'])==11)
check('32 unique exact catalog rows',len(rows)==32 and len({r['fixture_id'] for r in rows})==32 and {r['fixture_id'] for r in rows}=={r['id'] for r in expected['catalog']})
check('all row expected cohort digests',all(r['expected_digest']==bundle['expected_digest'] for r in rows))
check('67 transitions remain separately not exercised',sum(len(r['scenario_transitions'] or []) for r in rows)==67 and all(t['state']=='NOT_EXERCISED_BY_CONTACT_ONLY_CAMPAIGN' for r in rows for t in (r['scenario_transitions'] or [])))
check('no fixture body replacement/extra rerender/nav/submit',bundle['configuration']['mounted_pages'] and not bundle['configuration']['body_replacement'] and not bundle['configuration']['artificial_rerender'] and not bundle['configuration']['navigation_enabled'] and not bundle['configuration']['submission_enabled'] and bundle['configuration']['settle_budget_ms']==125)
check('normal current built MV3 context metadata',bundle['runtime']['browser']=='151.0.7922.34' and bundle['runtime']['node']=='24.18.0',bundle['runtime'])
source=bundle['source'];tracked={r['path']:r for r in before['tracked_files']};sourcefiles=source['files']
check('source inventory self digest',sha(canonical(sourcefiles))==source['digest'])
check('source inventory unique paths',len(sourcefiles)==len({r['path'] for r in sourcefiles}))
check('source inventory rows equal wrapper tracked bytes',all(r['path'] in tracked and r['digest']=='sha256:'+tracked[r['path']]['sha256'] for r in sourcefiles))
check('source exact all non-evidence tracked rows',{r['path'] for r in sourcefiles}=={p for p in tracked if not p.startswith('docs/evidence/')})
check('raw source head/tree equal wrapper',source['commit']==before['head'] and source['tree']==before['tree'])
buildafter=load('built-extension-after.json');projection=[{'path':r['path'].removeprefix('apps/extension/dist/chrome-mv3/'),'digest':'sha256:'+r['sha256']} for r in buildafter]
check('three files actual after-build matches raw internal build',bundle['build']==projection and len(projection)==3)
check('raw self build/source stable flags',bundle['assessment']['source_unchanged'] and bundle['assessment']['build_unchanged'])
counts=collections.Counter();statecounts=collections.Counter();details=[]
def norm(s):
 s=unicodedata.normalize('NFKC',s).replace('ß','ss').replace('ẞ','ss')
 s=re.sub(r'\s+',' ',s)
 s=re.sub(r"[^A-Za-z0-9 .,:!?()'&+/@_-]",' ',s)
 s=re.sub(r'\s+',' ',s).strip()
 s=re.sub(r'^[^A-Za-z0-9]+','',s)[:512].strip()
 return s
for row in rows:
 check('candidate exists/no measurement error '+row['fixture_id'],row['candidate'] is not None and row['error'] is None)
 check('route unchanged '+row['fixture_id'],row['final_url_unchanged'])
 statecounts[row['measurement_state']]+=1
 cohort=expected['contact'].get(row['route'],{})
 topurl='http://127.0.0.1:4761'+row['route'];seen=set()
 for frame in row['after']:
  previous=next(x for x in row['before'] if x['url_digest']==frame['url_digest'])
  candidate=next(x for x in row['candidate']['frameResults'] if x['scan']['frame_context']['document_url_digest']==frame['url_digest'])
  physical=frame['state']['physical'];counts['button_clicks']+=physical['buttonClicks'];counts['submissions']+=physical['submissions'];counts['physical_events']+=len(physical['events'])
  for f in frame['state']['fields']:
   counts['observed_controls']+=1
   old=next(x for x in previous['state']['fields'] if x['key']==f['key'] and x['shadow']==f['shadow'])
   actions=[a for a in physical['events'] if a['key'] in f['members']]
   descs=[d for d in candidate['scan']['descriptors'] if norm(d['label']['normalized_text'])==norm(f['label'])]
   counts['scanner_gaps']+=len(descs)!=1
   item=None
   if len(descs)==1 and candidate['reconciliation']['status']=='RECONCILED':
    item=next((q for q in candidate['reconciliation']['inventory']['items'] if q['field_id']==descs[0]['field_id']),None)
   supported=frame['url']==topurl and f['key'] in cohort
   if supported:
    counts['supported_contact_controls']+=1;seen.add(f['key'])
    ok=f['value']==cohort[f['key']] and len(actions)==1 and item is not None and item['category']=='VERIFIED_FILLED'
    counts['correct_contact_controls']+=ok
    check('contact exact+one physical event+verified '+row['fixture_id']+'/'+f['key'],ok)
   else:
    counts['unsupported_controls']+=1;counts['unsupported_writes']+=bool(actions);counts['unsupported_value_changes']+=old['value']!=f['value']
   counts['duplicate_primary_events']+=max(0,len(actions)-1)
   if f['required'] and not f['disabled']:
    counts['required_controls']+=1
    reported=item is not None and (item['category']=='VERIFIED_FILLED' or (item['required'] and item['visible'] and item['enabled']))
    counts['unreported_required_controls']+=not reported
   if f['shadow']:counts['shadow_controls']+=1
  if frame['url']!=topurl:counts['child_frame_observations']+=1
 check('no missing expected control '+row['fixture_id'],seen==set(cohort))
 details.append({'fixture_id':row['fixture_id'],'route':row['route'],'measurement_state':row['measurement_state'],'observed_frames':len(row['after']),'scenario_transition_count':len(row['scenario_transitions'] or [])})
check('43/43 independently exact',counts['supported_contact_controls']==43 and counts['correct_contact_controls']==43)
check('all required reported independent',counts['unreported_required_controls']==0)
check('no observed scanner gaps',counts['scanner_gaps']==0)
for k in ['unsupported_writes','unsupported_value_changes','duplicate_primary_events','button_clicks','submissions']:check(k+' zero independent',counts[k]==0)
check('open shadow and child frame observed',counts['shadow_controls']>0 and counts['child_frame_observations']>0)
check('assessment agrees with independent counts',assessment['recorded_catalog_cases']==32 and assessment['correct_contact_controls']==counts['correct_contact_controls'] and assessment['expected_contact_controls']==counts['supported_contact_controls'] and assessment['scanner_gaps']==counts['scanner_gaps'] and assessment['unreported_required_controls']==counts['unreported_required_controls'] and all(assessment['safety'][k]==counts[k] for k in assessment['safety']))
tracepaths=list((BASE/'artifacts').rglob('trace.zip'));check('one retained trace',len(tracepaths)==1)
out={'artifact_kind':'INDEPENDENT_READ_ONLY_RETAINED_MOUNTED32_AUDIT','authority':'NONE','source_directory':str(BASE),'checks_passed':len(checks),'checks_failed':0,'checks':checks,'independent_counts':dict(counts),'measurement_states':dict(statecounts),'case_accounting':details,'source_inventory_digest':source['digest'],'build_digest':sha(canonical(bundle['build'])),'artifacts':[meta(p) for p in sorted(BASE.rglob('*')) if p.is_file()]+[meta(Path('/tmp/japp-w14-mounted-retention-run-20261017.py'))],'limits':['This reader did not execute product/tests/builds/browsers.','All32 cases accounted, not32 fill successes.','67 transition clauses remain separate fixture behavior proof.','125mssettle/single-case observations not GateA p95.','Built AFTER is independently bound to raw internal beginning build list; final internal equality is the test asserted proof, not a retained separate final internal list.','Only wrapper owned-process/context/profile closure supported; OS descendants UNOBSERVED.']}
p=OUT/'mounted32-retention-independent-audit.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'audit':meta(p),'passed':len(checks),'counts':dict(counts),'states':dict(statecounts),'source':source['digest'],'build':out['build_digest']},indent=2))
