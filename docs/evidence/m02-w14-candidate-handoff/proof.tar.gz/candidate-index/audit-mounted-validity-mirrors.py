from pathlib import Path
import json,gzip,hashlib
P=Path('/tmp/japp-w14-acceptance-audit-20261017-ao4fj67t');p=Path('/tmp/japp-w14-mounted-retention-20261017/payload/mounted-run.json.gz');raw=p.read_bytes();x=json.loads(gzip.decompress(raw));valid=[];mirrors=[]
for r in x['rows']:
 cohort=x['expected']['contact'].get(r['route'],{});top='http://127.0.0.1:4761'+r['route']
 for frame in r['after']:
  if frame['url']!=top:continue
  for field in frame['state']['fields']:
   if field['key'] in cohort:valid.append({'fixture_id':r['fixture_id'],'key':field['key'],'valid':field['valid']})
  expected={'react-state-full-name':'Synthetic Applicant','react-state-email':'synthetic@example.invalid'} if r['route']=='/react/' else {'vue-state-full-name':'Synthetic Applicant'} if r['route']=='/vue/' else {}
  for m in frame['state']['mirrors']:
   if m['id'] in expected:mirrors.append({'fixture_id':r['fixture_id'],'id':m['id'],'observed_value':m['value'],'expected_value':expected[m['id']],'matched':m['value']==expected[m['id']]})
assert len(valid)==43 and all(r['valid'] for r in valid)
assert len(mirrors)==9 and len({r['fixture_id'] for r in mirrors})==6 and all(r['matched'] for r in mirrors)
out={'artifact_kind':'READ_ONLY_RETAINED_NATIVE_VALIDITY_FRAMEWORK_MIRROR_SUPPLEMENT','authority':'NONE','raw_digest':'sha256:'+hashlib.sha256(raw).hexdigest(),'checks_passed':2,'checks_failed':0,'supported_native_validity':valid,'actual_mounted_framework_mirrors':mirrors,'limits':['One retained final observation, not every original transition.','ThreeReact/twofields plus threeVue/onefield are six fixture rows/nine mirror observations, not nine independent forms.','No browser/product rerun.']}
f=P/'mounted32-validity-mirrors-supplement.json';f.write_text(json.dumps(out,indent=2)+'\n');print('PASS2:43/43 native-valid supported controls;9/9 exact real framework mirrors over6mounted rows; digest '+hashlib.sha256(f.read_bytes()).hexdigest())
