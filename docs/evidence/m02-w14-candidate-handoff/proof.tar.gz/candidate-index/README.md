# Outside-tree W14 candidate evidence proposal

This directory contains read-only evidence derivations and a source-backed acceptance checklist for root review. It changes no repository files, runs no product/test/browser actors, declares no gate decision, adds no canonical schema, and truncates no result set.

Start with `requirement-to-proof-checklist.md`, then `candidate-evidence-index.json` and `manual-synthetic-inspection-checklist.md`. `canonical-benchmark-results-200.json` preserves every exact nested BenchmarkResultV1 object from the clean730 canonical execution. Its200-row companion index preserves all IDs, case/observation digests and raw-report digests. `feature-crosswalk-clean730.json` joins all67 original fixture clauses and19 feature groups to exact ordinary PASS lines in the retained730 aggregate. It keeps direct fixture interactions, actual MV3 driver mechanics, W09 contact-policy execution and mounted framework observations separate.

`frozen-artifact-integrity-readonly.json` independently rehashes all103 frozen artifact preimages;683 record identities are not scored autofill controls. `mounted32-retention-independent-audit.json` independently audits root's unchanged current1d raw-retention run:173checksPASS;32cases=18contact-scored+14unsupported-only;144observed controls/43exactcontact/101unsupported unchanged;58required reported;childframe1/open-shadow1;measured safety0. The separate2-check validity/mirror supplement confirms43/43 native-valid supported controls and9/9 real framework mirrors over6React/Vue rows. These are retained-observation checks, not additional independent forms, transition certification or p95 measurements.

The initial mounted checker used a wrong punctuation normalization assumption and failed on the React email label semicolon. Its original source and failure record remain here. The corrected checker ports the documented scanner normalization; unchanged raw/product/cohort then pass. No product rerun repaired this checker failure.

The screenshot checklist documents an actual image-view inspection of a retained clean730 synthetic screenshot only. It is not a human usability study, new browser workflow, full manual Gate A approval or W15 verdict. Root remains responsible for the exact final package review and accepted scope/governance transition.

`derive-candidate-index.py` is the initial proposal generator, followed by explicitly preserved finalization from the new retained mounted run. Do not run it to overwrite the final proposal. `verify-proposal.py` independently checks the final proposal against the immutable canonical source and retained audit files. Actual audit commands run outside the project were:

- `python3 /tmp/japp-w14-acceptance-audit-20261017-ao4fj67t/derive-candidate-index.py` (initial proposal derivation; later regenerated after adding the shadow PASS crosswalk).
- `python3 /tmp/japp-w14-acceptance-audit-20261017-ao4fj67t/audit-mounted-retention.py` (first checker exit1 for normalization assumption; corrected checker exit0/173checks).
- `python3 /tmp/japp-w14-acceptance-audit-20261017-ao4fj67t/audit-mounted-validity-mirrors.py` (exit0/two retained-observation checks).
- `python3 /tmp/japp-w14-acceptance-audit-20261017-ao4fj67t/verify-proposal.py` (exit0; exact200 canonical objects and references,67clauses,19features,current audit/source hashes).

ADR0007's source digest is deliberately null until root integrates the accepted owner amendment. The current-source observation records the actual audit-start untracked CI directory. Root began editing waiver prose after the mounted run closed; this proposal does not claim those later edits passed verification. Final GateEvidenceBundleV2 COMPLETE/decision and genuine independent W15/owner review remain later deliverables. Its128-reference cap does not authorize discarding72 of200 results; choose a reviewed aggregate/index representation or explicit schema version at that stage.
