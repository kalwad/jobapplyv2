from pathlib import Path,PurePosixPath
import gzip,hashlib,io,json,tarfile
RAW=Path('/tmp/japp-w14-mounted-retention-20261017')
INDEX=Path('/tmp/japp-w14-acceptance-audit-20261017-ao4fj67t')
OUT=Path('/tmp/japp-w14-candidate-handoff-retained-20261017')
assert not OUT.exists();OUT.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
payload={}
def add(name,data):
 p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts and name not in payload
 payload[name]=data
for prefix,root in [('mounted-retention',RAW),('candidate-index',INDEX)]:
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink(),p
  if p.is_file():add(prefix+'/'+p.relative_to(root).as_posix(),p.read_bytes())
add('source/run-mounted-retention.py',Path('/tmp/japp-w14-mounted-retention-run-20261017.py').read_bytes())
add('source/retention-builder.py',Path(__file__).read_bytes())
rows=[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(payload.items())]
add('retained-members.json',(json.dumps({'files':rows},indent=2)+'\n').encode())
archive=OUT/'proof.tar.gz'
with archive.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as g:
  with tarfile.open(fileobj=g,mode='w',format=tarfile.PAX_FORMAT) as t:
   for n,b in sorted(payload.items()):
    info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b))
allrows=[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(payload.items())]
manifest={'archive_path':'proof.tar.gz','archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'regular_members':len(allrows),'files':allrows,'scope':'Source-bound W14 candidate handoff plus ONE unchanged mounted32 raw retention run; historical730/1d evaluations remain separately bound. Authority NONE; no W15/GateA or owner decision.'}
(OUT/'retention-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers();assert len(members)==len(allrows)
 for member,row in zip(members,allrows):
  assert member.isfile() and member.name==row['path'];b=t.extractfile(member).read();assert len(b)==row['bytes'] and sha(b)==row['sha256']
summary={'archive_sha256':manifest['archive_sha256'],'archive_bytes':manifest['archive_bytes'],'regular_members':manifest['regular_members'],'payload_bytes':sum(r['bytes'] for r in allrows),'mounted_run_head':'1d490d1230b443c31fd4a9d8732064552affe149','mounted_catalog_cases':32,'contact_scored_cases':18,'unsupported_only_cases':14,'observed_controls':144,'correct_contact_controls':43,'required_controls_reported':58,'all_measured_safety_counters':0,'raw_audit_checks':173,'canonical_case_results_preserved':200,'frozen_artifacts_verified':103,'fixture_clauses_crosswalked':67,'gate_authority':'NONE','archive_peer_review':'PENDING'}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(OUT/'report.md').write_text('W14 candidate handoff retention; authority NONE. Original mounted32 run, all raw output/trace/source endpoints, wrapper, full lossless200-result candidate index, frozen103 artifact checks,67-clause crosswalk, manual synthetic image checklist and mounted173-check audit/history are preserved byte-for-byte. The 32 catalog rows contain18 contact-scored and14 unsupported-only cases;43/43 contact controls,58 required reports and measured safety0 do not imply32 filled scenarios or autonomous67-clause transactions. Historical730/1d source anchors remain distinct; no W15 decision, owner approval, Gate A PASS or production support is claimed. Independent archive peer pending.\n')
print(json.dumps(summary,indent=2))
