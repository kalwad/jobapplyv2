from pathlib import Path
import hashlib,json,os,signal,subprocess,time
ROOT=Path('/Users/tanishkalwad/jobapplyv2')
OUT=Path('/tmp/japp-w14-mounted-retention-20261017')
NODE='/opt/homebrew/opt/node@24/bin/node'
HEAD='1d490d1230b443c31fd4a9d8732064552affe149'
ENV=os.environ.copy();ENV['PATH']=str(Path(NODE).parent)+os.pathsep+ENV['PATH']
ENV['PLAYWRIGHT_JSON_OUTPUT_NAME']=str(OUT/'results.json')
ENV['JAPP_W14_W06_ARTIFACT_DIRECTORY']=str(OUT/'payload')
ARGV=['pnpm','exec','playwright','test','e2e/extension/extension-w14-w06.spec.ts','--trace','on','--output',str(OUT/'artifacts'),'--reporter=list,json']
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT).decode().strip()
def snapshot():
 rows=[]
 for name in subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0'):
  if name:
   b=(ROOT/name).read_bytes();rows.append({'path':name,'bytes':len(b),'sha256':sha(b)})
 return {'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain=v1'),'tracked_files':rows,'captured_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
assert not OUT.exists()
before=snapshot();assert before['head']==HEAD
assert before['status']=='?? docs/evidence/m02-w14-1d490d-ci/'
OUT.mkdir();save('before.json',before)
save('command.json',{'argv':ARGV,'cwd':str(ROOT),'node_path':NODE,'wrapper_sha256':sha(Path(__file__).read_bytes()),'task_environment':{k:ENV[k] for k in ['PLAYWRIGHT_JSON_OUTPUT_NAME','JAPP_W14_W06_ARTIFACT_DIRECTORY']},'scope':'ONE_UNCHANGED_MOUNTED32_REPRODUCTION_FOR_RAW_ATTACHMENT_RETENTION; not full corpus score, transition certification or performance acceptance','started_at':before['captured_at']})
code=None;timed_out=False
with (OUT/'run.log').open('wb') as stream:
 proc=subprocess.Popen(ARGV,cwd=ROOT,env=ENV,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=proc.wait(timeout=480)
 except subprocess.TimeoutExpired:
  timed_out=True
  try:os.killpg(proc.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:
   try:os.killpg(proc.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   proc.wait(timeout=5)
  code=proc.returncode
  if code==0:code=124
finally_snapshot=snapshot();save('after.json',finally_snapshot)
build=[]
for p in sorted((ROOT/'apps/extension/dist/chrome-mv3').rglob('*')):
 if p.is_file():
  b=p.read_bytes();build.append({'path':p.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':sha(b)})
save('built-extension-after.json',build)
result={'exit_code':code,'timed_out':timed_out,'head_unchanged':before['head']==finally_snapshot['head'],'source_unchanged':before['tracked_files']==finally_snapshot['tracked_files'],'status_unchanged':before['status']==finally_snapshot['status'],'ended_at':finally_snapshot['captured_at'],'built_observation':'AFTER_FRESH_GLOBAL_SETUP_ONLY; test also independently compares its build endpoints','cleanup_scope':'normal fixture context/profile/owned child closure; OS descendants outside owned process group UNOBSERVED'}
save('completion.json',result);print(json.dumps(result),flush=True)
raise SystemExit(code if all(result[k] for k in ['head_unchanged','source_unchanged','status_unchanged']) else 2)
