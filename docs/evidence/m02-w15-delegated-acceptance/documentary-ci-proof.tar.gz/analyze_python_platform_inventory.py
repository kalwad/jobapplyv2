import collections,hashlib,json,re
from collect_ci import ROOT

report=json.loads((ROOT/'ci-review-report.json').read_text())
rows=[]
for host in report['hosts']:
 data=(ROOT/host['log']['log_path']).read_bytes()
 text=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',data.decode('utf-8',errors='replace'))
 lines=[re.sub(r'^\d{4}-\d{2}-\d{2}T\S+\s','',x) for x in text.splitlines()]
 starts=[i for i,l in enumerate(lines) if l.startswith('$ uv run pytest ') and '--collect-only -q' in l]
 assert len(starts)==1
 a=starts[0]
 b=next(i for i,l in enumerate(lines) if i>a and l.startswith('$ uv run pytest '))
 ids=[x for x in lines[a+1:b] if re.match(r'^(?:scripts/tests/|services/orchestrator/tests/).*::',x)]
 assert len(ids)==len(set(ids))
 expected=1490 if 'windows' in host['job_name'] else 1492
 assert len(ids)==expected==host['python_execution_summary']['passed']
 target=ROOT/('python-collected-ids-{}.json'.format(host['job_id']))
 target.write_text(json.dumps({'job_id':host['job_id'],'ids':ids,'collection_command_log_line':a+1,'execution_command_log_line':b+1},indent=2)+'\n')
 rows.append({'job_id':host['job_id'],'job_name':host['job_name'],'count':len(ids),'ids':ids,'retained_ids':str(target.relative_to(ROOT)),'retained_ids_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
windows=next(x for x in rows if 'windows' in x['job_name'])
posix=[x for x in rows if 'windows' not in x['job_name']]
assert set(posix[0]['ids'])==set(posix[1]['ids'])
assert set(windows['ids']).issubset(set(posix[0]['ids']))
extras=sorted(set(posix[0]['ids'])-set(windows['ids']))
assert len(extras)==2
result={'run_id':report['run_id'],'head_sha':report['head_sha'],'tree_sha':report['tree_sha'],'common_count':1490,'posix_count':1492,'windows_count':1490,'posix_inventories_equal':True,'windows_equals_common_posix_subset':True,'posix_only_exact_test_ids':extras,'hosts':[{k:x[k] for k in ['job_id','job_name','count','retained_ids','retained_ids_sha256']} for x in rows],'scope':'Actual collect-only IDs joined to each completed execution count. Platform-scoped POSIX-only IDs are not skipped Windows tests. No collection or test command was run by this collector.','authority':'NONE'}
(ROOT/'python-platform-inventory.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
