import json
from collect_ci import api, capture, ROOT, EXPECTED_HEAD, EXPECTED_TREE

commit, _ = api('repos/kalwad/jobapplyv2/git/commits/' + EXPECTED_HEAD, 'expected-head-git-commit')
assert commit['sha'] == EXPECTED_HEAD
assert commit['tree']['sha'] == EXPECTED_TREE
inventory, _ = api('repos/kalwad/jobapplyv2/git/trees/' + EXPECTED_TREE + '?recursive=1', 'expected-recursive-tree')
assert inventory['sha'] == EXPECTED_TREE and inventory.get('truncated') is False
pull, _ = api('repos/kalwad/jobapplyv2/pulls/1', 'pull1-current-context')
local, _ = capture(['/usr/bin/git', '-C', '/Users/tanishkalwad/jobapplyv2', 'ls-tree', '-rz', '--full-tree', EXPECTED_HEAD], 'expected-local-ls-tree')
local_rows = []
for row in local.split(b'\0'):
    if row:
        left, path = row.split(b'\t', 1)
        mode, object_type, sha = left.decode().split()
        local_rows.append({'path': path.decode(), 'mode': mode, 'type': object_type, 'sha': sha})
api_rows = [{k:row[k] for k in ['path','mode','type','sha']} for row in inventory['tree'] if row['type'] != 'tree']
assert sorted(local_rows, key=lambda x:x['path']) == sorted(api_rows, key=lambda x:x['path'])
summary = {
    'expected_head_sha': EXPECTED_HEAD,
    'expected_tree_sha': EXPECTED_TREE,
    'head_commit_api_tree_verified': True,
    'recursive_tree_truncated': inventory.get('truncated'),
    'git_tracked_rows': len(local_rows),
    'github_recursive_nontree_rows': len(api_rows),
    'local_commit_tree_inventory_equals_github_tree': True,
    'pull_head_observed': pull['head']['sha'],
    'pull_base_observed': pull['base']['sha'],
    'pull_merge_commit_observed': pull.get('merge_commit_sha'),
    'actual_tested_checkout_sha': None,
    'actual_tested_checkout_status': 'PENDING_CLOSED_JOB_LOG',
    'source_of_tree_equality': 'Exact Git object identities and complete recursive API tree match historical local git ls-tree for expected commit; this is not an assumption that PR checkout uses the head commit.',
    'authority': 'NONE', 'owner_decision': 'PENDING'
}
(ROOT/'head-tree-binding.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
print(json.dumps({'candidate_relevant_paths':[x['path'] for x in local_rows if x['path'].startswith('.github/workflows/') or 'verify' in x['path'] or 'doctor' in x['path'] or x['path'] in ['package.json','playwright.config.ts','pyproject.toml'] or 'legacy-browser-cleanup.test.mjs' in x['path']]}))
