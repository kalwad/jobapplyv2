import base64,hashlib,json,pathlib
from collect_ci import api, ROOT, EXPECTED_HEAD, EXPECTED_TREE

inventory_path=sorted((ROOT/'commands').glob('*expected-recursive-tree.stdout'))[-1]
inventory=json.loads(inventory_path.read_text())
by_path={x['path']:x for x in inventory['tree'] if x['type']=='blob'}
paths=['.github/workflows/ci.yml','.nvmrc','.python-version','rust-toolchain.toml','package.json','playwright.config.ts','pyproject.toml','scripts/doctor.py','scripts/verify.py','e2e/extension/legacy-paired-options-r10/legacy-browser-cleanup.test.mjs','e2e/extension/legacy-paired-options-r10/legacy-browser.mjs']
rows=[]
for path in paths:
    entry=by_path[path]
    blob,_=api('repos/kalwad/jobapplyv2/git/blobs/'+entry['sha'],'source-blob-'+str(len(rows)+1))
    assert blob['sha']==entry['sha'] and blob['encoding']=='base64'
    data=base64.b64decode(blob['content'])
    assert len(data)==blob['size']==entry['size']
    actual_git_sha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    assert actual_git_sha==entry['sha']
    out=ROOT/'source'/path
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_bytes(data)
    rows.append({'path':path,'git_blob_sha':entry['sha'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'exact_git_blob_verified':True})
manifest={'head_sha':EXPECTED_HEAD,'tree_sha':EXPECTED_TREE,'selected_source_count':len(rows),'files':rows,'scope':'Selected workflow/config/aggregate/doctor/Node-only test sources only. Complete tracked inventory is independently bound by Git object identities; all tracked source bytes are not copied here.','authority':'NONE'}
(ROOT/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'source_count':len(rows),'all_exact_git_blobs':True,'source_bytes':sum(x['bytes'] for x in rows)}))
