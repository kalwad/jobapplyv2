import collections,hashlib,json,pathlib,re
from collect_ci import ROOT,EXPECTED_HEAD,EXPECTED_TREE,RUN

ANSI=re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
TIMESTAMP=re.compile(r'^\d{4}-\d{2}-\d{2}T\S+\s')

def normalize(data):
 return '\n'.join(TIMESTAMP.sub('',ANSI.sub('',line)) for line in data.decode('utf-8',errors='replace').splitlines())

def span(lines,start,end):
 starts=[i for i,x in enumerate(lines) if x==start]
 if len(starts)!=1:return []
 a=starts[0]
 ends=[i for i,x in enumerate(lines) if i>a and x==end]
 return lines[a+1:ends[0] if ends else len(lines)]

def summary_rows(lines):
 rows=[]
 for line in lines:
  m=re.match(r'^\s*Tests\s+(.*?)\s+\((\d+)\)\s*$',line)
  if m:
   counts={kind:int(number) for number,kind in re.findall(r'(\d+)\s+(passed|failed|skipped|todo)',m.group(1))}
   total=int(m.group(2))
   rows.append({'passed':counts.get('passed',0),'failed':counts.get('failed',0),'skipped':counts.get('skipped',0),'todo':counts.get('todo',0),'total':total,'reported_counts_reconcile':sum(counts.values())==total,'line':line})
 return rows

def browser_summary(lines):
 counts={}
 for line in lines:
  m=re.match(r'^\s*(\d+)\s+(passed|failed|skipped|flaky)(?:\s|$)',line)
  if m:counts[m.group(2)]=int(m.group(1))
 if counts:
  return {'status':'RESULT_SUMMARY_OBSERVED','passed':counts.get('passed',0),'failed':counts.get('failed',0),'skipped':counts.get('skipped',0),'flaky':counts.get('flaky',0),'total':sum(counts.values()),'summary_lines':[l for l in lines if re.match(r'^\s*\d+\s+(passed|failed|skipped|flaky)(?:\s|$)',l)]}
 return {'status':'NO_RESULT_SUMMARY','passed':None,'failed':None,'skipped':None,'flaky':None,'total':None,'summary_lines':[]}

snap=json.loads(sorted(ROOT.glob('snapshot-*.json'))[-1].read_text())
assert snap['status']=='completed' and str(snap['run_id'])==RUN and snap['run_attempt']==1
jobs_json=json.loads(sorted((ROOT/'commands').glob('*jobs-attempt1.stdout'))[-1].read_text())
jobs={x['id']:x for x in jobs_json['jobs']}
logs=json.loads((ROOT/'closed-job-logs.json').read_text())['jobs']
assert len(logs)==len(jobs)==3
binding=json.loads((ROOT/'head-tree-binding.json').read_text())
merge_object_paths=sorted((ROOT/'commands').glob('*observed-pr-merge-git-commit.stdout'))
if merge_object_paths:
 merge_obj=json.loads(merge_object_paths[-1].read_text())
else:
 merge_object_paths=sorted((ROOT/'commands').glob('*actual-tested-merge-git-commit.stdout'))
 assert merge_object_paths
 merge_obj=json.loads(merge_object_paths[-1].read_text())
hosts=[]
for row in logs:
 job=jobs[row['job_id']]
 raw=(ROOT/row['log_path']).read_bytes()
 assert len(raw)==row['log_bytes'] and hashlib.sha256(raw).hexdigest()==row['log_sha256']
 text=normalize(raw);lines=text.splitlines()
 checkout=[]
 for i,line in enumerate(lines):
  if 'log -1 --format=%H' in line:
   candidates=[x.strip() for x in lines[i+1:i+4] if re.fullmatch(r'[0-9a-f]{40}',x.strip())]
   checkout.extend(candidates)
 assert len(checkout)==1
 assert checkout[0]==merge_obj['sha'] and merge_obj['tree']['sha']==EXPECTED_TREE
 doctor=[]
 for i,line in enumerate(lines):
  m=re.fullmatch(r'summary: (\d+) pass, (\d+) warning, (\d+) fail, (\d+) not-yet-applicable',line)
  if m:doctor.append({'passed':int(m[1]),'warnings':int(m[2]),'failed':int(m[3]),'not_yet_applicable':int(m[4]),'log_line':i+1,'text':line})
 assert len(doctor)==1
 units=summary_rows(span(lines,'$ pnpm exec turbo run test --force -- --reporter=default','$ pnpm generate:contracts --check'))
 unit_counts={k:sum(x[k] for x in units) for k in ['passed','failed','skipped','todo','total']}
 unit_counts.update({'observed_workspace_report_count':len(units),'all_observed_reports_reconcile':all(x['reported_counts_reconcile'] for x in units),'observations':units,'scope':'Observed root Turbo unit-ts report summaries only; aborted or unreported workspace results are not invented.'})
 default=browser_summary(span(lines,'$ pnpm exec playwright test','$ pnpm --filter @japp/extension exec vitest run test/m02-w14/public-inspection/scope.test.ts --reporter=default'))
 default['source_text_module_discovery_error']=any("SyntaxError: The requested module 'node:vm' does not provide an export named 'SourceTextModule'" in x for x in span(lines,'$ pnpm exec playwright test','$ pnpm --filter @japp/extension exec vitest run test/m02-w14/public-inspection/scope.test.ts --reporter=default'))
 research=browser_summary(span(lines,'$ pnpm exec playwright test --config e2e/extension/public-research/playwright.config.ts','$ pnpm exec playwright test --config e2e/extension/public-research/playwright.config.ts --list'))
 contact=browser_summary(span(lines,'$ pnpm exec playwright test --config e2e/extension/public-contact/playwright.config.ts --reporter=list,json','$ pnpm exec playwright test --config e2e/extension/public-contact/playwright.config.ts --reporter=list,json --list'))
 py_summaries=[]
 for i,line in enumerate(lines):
  m=re.fullmatch(r'=+\s*(\d+) passed in ([0-9.]+)s(?: \([^)]*\))?\s*=+',line)
  if m:py_summaries.append({'passed':int(m[1]),'duration_seconds':float(m[2]),'log_line':i+1,'text':line,'skipped':0,'failed':0})
 assert len(py_summaries)<=1
 py_collect=[{'collected':int(m[1]),'log_line':i+1,'text':line} for i,line in enumerate(lines) for m in [re.search(r'^collected (\d+) items',line)] if m]
 outcomes=[]
 for i,line in enumerate(lines):
  m=re.match(r'^(\S+)\s+(ACTIVE|NOT_YET_APPLICABLE)\s+(PASS|FAIL|NOT_YET_APPLICABLE)(?:\s+(.*))?$',line)
  if m:outcomes.append({'suite_id':m[1],'state':m[2],'result':m[3],'detail':m[4] or '', 'log_line':i+1})
 active=[x for x in outcomes if x['state']=='ACTIVE']
 exits=[int(m[1]) for x in lines for m in [re.fullmatch(r'verification exit code: (\d+)',x)] if m]
 scaling=[{'log_line':i+1,'text':line} for i,line in enumerate(lines) if re.match(r'^W13_(?:SCALING|TARGET)(?:_|\s|$)',line.lstrip())]
 fail_details=[{'log_line':i+1,'text':line} for i,line in enumerate(lines) if 'SourceTextModule' in line or 'Test timed out in' in line or 'Test timeout of ' in line or line.lstrip().startswith('FAIL  ') or re.match(r'^\s*\d+\) .* › ',line)]
 clean=[{k:s.get(k) for k in ['name','status','conclusion','started_at','completed_at']} for s in job['steps'] if s['name']=='Assert verification left no tracked changes']
 host={'job_id':job['id'],'job_name':job['name'],'job_status':job['status'],'job_conclusion':job['conclusion'],'started_at':job['started_at'],'completed_at':job['completed_at'],'checkout_sha':checkout[0],'tested_tree_sha':merge_obj['tree']['sha'],'tested_tree_equals_head_tree':True,'doctor':doctor[0],'root_unit_ts':unit_counts,'default_browser':default,'controlled_research_browser':research,'controlled_contact_browser':contact,'python_execution_summary':py_summaries[0] if py_summaries else None,'python_collection_observations':py_collect,'python_status':'COMPLETE' if py_summaries else 'INCOMPLETE_NO_FINAL_SUMMARY','aggregate_active_suite_count':len(active),'aggregate_active_outcomes':dict(collections.Counter(x['result'] for x in active)),'aggregate_outcomes':outcomes,'aggregate_exit_codes':exits,'aggregate_summary_status':'COMPLETE' if len(active)==19 and len(exits)==1 else 'INCOMPLETE_NO_FINAL_AGGREGATE_CLAIM','native128_ci_log_observations':scaling,'native128_scope':'CI one-sample profile only, not local 20-sample p95 acceptance; absent rows are not zero timings.','tracked_clean_step':clean,'failure_details':fail_details,'log':row}
 hosts.append(host)
report={'run_id':int(RUN),'run_attempt':1,'run_url':'https://github.com/kalwad/jobapplyv2/actions/runs/'+RUN,'run_status':snap['status'],'run_conclusion':snap['conclusion'],'head_sha':EXPECTED_HEAD,'tree_sha':EXPECTED_TREE,'tested_checkout_sha':merge_obj['sha'],'tested_checkout_tree':merge_obj['tree']['sha'],'tested_checkout_parents':[x['sha'] for x in merge_obj['parents']],'tested_checkout_tree_equals_head_tree':merge_obj['tree']['sha']==EXPECTED_TREE,'head_sha_is_tested_merge_parent':EXPECTED_HEAD in [x['sha'] for x in merge_obj['parents']],'complete_git_inventory_rows':binding['git_tracked_rows'],'complete_github_git_inventory_equal_local_historical_commit':binding['local_commit_tree_inventory_equals_github_tree'],'hosts':hosts,'all_host_jobs_success':all(x['job_conclusion']=='success' for x in hosts),'authority':'NONE','owner_decision':'PENDING','gate_a_status':'IN_PROGRESS','scope':'Read-only actual native repository CI evidence. No workflow mutation, rerun, retry, dispatch, cancellation, browser, build, or test actor was invoked by this collector. Workflow platform-condition skips are separate from test skip counts. No packaged-app or Windows 11 end-user claim. No owner or independent final gate decision.'}
(ROOT/'ci-review-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'run_id':int(RUN),'conclusion':report['run_conclusion'],'tested_checkout_sha':report['tested_checkout_sha'],'tree_equals_head':report['tested_checkout_tree_equals_head_tree'],'all_hosts_success':report['all_host_jobs_success'],'hosts':[{'id':x['job_id'],'conclusion':x['job_conclusion'],'unit_ts':{k:x['root_unit_ts'][k] for k in ['passed','failed','skipped','total','observed_workspace_report_count']},'active_outcomes':x['aggregate_active_outcomes'],'python':x['python_execution_summary'],'default_browser':x['default_browser'],'research':x['controlled_research_browser'],'contact':x['controlled_contact_browser']} for x in hosts]},indent=2))
