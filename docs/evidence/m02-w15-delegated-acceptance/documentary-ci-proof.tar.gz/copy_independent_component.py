import hashlib,json,os,pathlib,stat,sys
from collect_ci import ROOT
assert len(sys.argv)==6
source=pathlib.Path(sys.argv[1]);target=ROOT/sys.argv[2]
assert not target.exists() and target.parent==ROOT
expected_sha=sys.argv[3];expected_bytes=int(sys.argv[4]);scope=sys.argv[5]
manifest_name='review-output-manifest.json'

def read_regular(p):
 before=p.lstat();assert stat.S_ISREG(before.st_mode)
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  parts=[]
  while True:
   part=os.read(fd,1024*1024)
   if not part:break
   parts.append(part)
  after=os.fstat(fd)
 finally:os.close(fd)
 final=p.lstat()
 keys=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 assert keys(before)==keys(after)==keys(final)
 return b''.join(parts)

mb=read_regular(source/manifest_name)
assert len(mb)==expected_bytes and hashlib.sha256(mb).hexdigest()==expected_sha
manifest=json.loads(mb);captured={}
for row in manifest['files']:
 relative=pathlib.PurePosixPath(row['path'])
 assert not relative.is_absolute() and '..' not in relative.parts and row['path'] not in captured
 data=read_regular(source/row['path'])
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 captured[row['path']]=data
assert manifest_name not in captured
captured[manifest_name]=mb
target.mkdir()
for name,data in captured.items():
 p=target/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
for row in manifest['files']:
 data=read_regular(target/row['path'])
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
closure={'source_root':str(source),'source_manifest_sha256':expected_sha,'source_manifest_bytes':expected_bytes,'source_files':len(manifest['files']),'copied_manifest_and_all_files_verified':True,'scope':scope,'authority':'NONE','owner_decision':'PENDING'}
(target/'copy-closure.json').write_text(json.dumps(closure,indent=2)+'\n')
print(json.dumps({'copied_component':str(target.relative_to(ROOT)),'source_files':len(manifest['files']),'manifest_sha256':expected_sha,'authority':'NONE'}))
