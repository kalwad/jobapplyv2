# Independent closed Ubuntu result review

**ONE_CLOSED_HOST_VERIFIED**. All 67 comparisons verified; no discrepancy found. This finite review covers only Ubuntu job `117558330019`, completed successfully at `2026-10-18T02:12:39Z`, in run `39087938620`, attempt `1`.

The actual checkout appears directly after `git log -1 --format=%H` in raw log lines 134–135: `4b345ab5df25d9ad30beaf38e94a8a2b0a9a185c`. Its captured Git object has tree `85dd2cd9bc8969b448277560f0b107ca3e962b83` and current head `0f91158f68fa4fac4c5786b97b8d539d103d53ed` as a parent. This establishes tree equality for this actual Ubuntu checkout.

Actual raw log and captured terminal job evidence support:

- Doctor: 27 pass, 0 warning, 0 fail, 1 not-yet-applicable.
- Root TypeScript: 3,905 passed across 14 reconciled workspace summaries; zero failed, skipped, or todo.
- Default browser: 246 actual passing case rows and matching result summary. Controlled research/contact browser: 2 and 62 actual passing case rows with matching summaries. All three report zero failures, skips, or flaky results.
- Python: 1,492 unique collected IDs, 1,492 items in actual execution, and all 1,492 passed. Zero test skips or failures.
- Aggregate: 19 ACTIVE suites PASS; visual remains NOT_YET_APPLICABLE. Verification exit code is 0. The captured Ubuntu job object records a successful tracked-clean step and no failed/cancelled step.

Native128 complete rows at lines 1471–1473 equal all final rows at line 1474. Line 1475 reports one actual 128-control observation: `970.1078830000006 ms`. Actual work is 128 attempted/physical actions, 512 re-resolutions, 768 descriptors, 128 identity pairs, one index rebuild, 511 index hits, three enumerations, and 384 candidates. Both the retained report and interpreted profile match those raw observations and line mappings. An additional independent read-only profile review found no mismatch.

This native observation uses foreground posture and zero settle budget, with lower-bound and NOT_GATE_A_FINAL_EVIDENCE labels retained. CDP CPU/heap telemetry covers the main page. The exact copied benchmark source enforces the 1,500 ms threshold only when sample count is 20; this actual one-sample CI profile neither enforces nor satisfies that acceptance gate.

`closed-ubuntu-review.json` contains full comparisons and raw evidence references. `input-manifest.json` contains exact bytes/SHA-256 for all 18 finite inputs, and `reviewed-inputs/` retains those exact bytes so later collector appends cannot change this review. The raw jobs response is retained as an input container; only Ubuntu’s job object was evaluated. Recomputed Python IDs are retained separately.

Scope: **ONE closed Ubuntu host**. macOS/Windows results are unobserved in this review. The captured overall run is still in progress with no conclusion; no whole-run success or archive closure is claimed. Prior evaluated `95f5` behavior and authority are not transferred.

Authority: **NONE**. Owner decision: **PENDING**. Gate A remains IN_PROGRESS. This is not final Gate A review or owner approval.

Only already captured evidence was interpreted. No API/network, browser, build, test, dispatch, rerun, retry, cancellation, collector, or closure-validator invocation occurred. All writes were confined to this fresh sibling directory; the prior static review was not modified.
