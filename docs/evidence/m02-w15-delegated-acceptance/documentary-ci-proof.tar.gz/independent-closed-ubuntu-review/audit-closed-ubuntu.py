from pathlib import Path
from collections import Counter
import datetime
import hashlib
import json
import re

BASE = Path('/tmp/japp-m02-w15-0f91158-ci-20261018')
OUT = Path('/tmp/japp-m02-w15-0f91158-ci-independent-closed-review-20261018')
HEAD = '0f91158f68fa4fac4c5786b97b8d539d103d53ed'
TREE = '85dd2cd9bc8969b448277560f0b107ca3e962b83'
MERGE = '4b345ab5df25d9ad30beaf38e94a8a2b0a9a185c'
RUN = 39087938620
JOB = 117558330019
inputs = {}
checks = []
findings = []
evidence = {}

def read(path):
    if path not in inputs:
        inputs[path] = (BASE / path).read_bytes()
    return inputs[path]

def obj(path):
    return json.loads(read(path))

def identity(path):
    data = read(path)
    return {'path': path, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def check(label, value, detail=None):
    checks.append({'check': label, 'verified': bool(value), 'detail': detail})
    if not value:
        findings.append({'check': label, 'detail': detail})

def captured_command(stem, endpoint):
    rec = obj('commands/' + stem + '.record.json')
    expected = ['/opt/homebrew/bin/gh', 'api', '-H', 'Accept: application/vnd.github+json', endpoint]
    check(stem + ': exact read-only capture command', rec['argv'] == expected and rec['exit_code'] == 0 and rec['cwd'] == str(BASE) and rec['scope'] == 'READ_ONLY_GITHUB_API_NO_DISPATCH_NO_RETRY_NO_CANCEL_NO_ACCEPTANCE_AUTHORITY')
    for stream in ['stdout', 'stderr']:
        check(stem + ': captured ' + stream + ' byte count and SHA256', rec[stream] == identity('commands/' + stem + '.' + stream))
    check(stem + ': empty captured stderr', len(read('commands/' + stem + '.stderr')) == 0)
    return rec

snapshot = obj('snapshot-0008.json')
check('bounded snapshot current run/head/tree and pending authority', snapshot['run_id'] == RUN and snapshot['run_attempt'] == 1 and snapshot['head_sha'] == snapshot['expected_head_sha'] == HEAD and snapshot['expected_source_tree'] == TREE and snapshot['status'] == 'in_progress' and snapshot['conclusion'] is None and snapshot['authority'] == 'NONE' and snapshot['owner_decision'] == 'PENDING')
run_record = captured_command('0034-run', f'repos/kalwad/jobapplyv2/actions/runs/{RUN}')
jobs_record = captured_command('0035-jobs-attempt1', f'repos/kalwad/jobapplyv2/actions/runs/{RUN}/attempts/1/jobs?per_page=100')
check('snapshot binds exact captured run and jobs records', snapshot['records'] == [run_record, jobs_record])
run = obj('commands/0034-run.stdout')
check('captured run exact current identity and remains unfinished', run['id'] == RUN and run['run_attempt'] == 1 and run['head_sha'] == HEAD and run['status'] == 'in_progress' and run['conclusion'] is None)
jobs = obj('commands/0035-jobs-attempt1.stdout')
selected_jobs = [j for j in jobs['jobs'] if j['id'] == JOB]
check('exactly one selected Ubuntu job object', len(selected_jobs) == 1)
job = selected_jobs[0]
check('Ubuntu terminal success and exact run identity', job['run_id'] == RUN and job['name'] == 'doctor + verify (ubuntu-24.04)' and job['status'] == 'completed' and job['conclusion'] == 'success' and job['started_at'] == '2026-10-18T01:50:43Z' and job['completed_at'] == '2026-10-18T02:12:39Z')
snapshot_job = next(j for j in snapshot['jobs'] if j['id'] == JOB)
check('selected snapshot job matches raw job terminal object', all(snapshot_job[k] == job[k] for k in ['id', 'name', 'status', 'conclusion', 'started_at', 'completed_at']))
log_record = captured_command('0036-closed-job-117558330019-log', f'repos/kalwad/jobapplyv2/actions/jobs/{JOB}/logs')
closed = obj('closed-job-logs.json')
closed_rows = [j for j in closed['jobs'] if j['job_id'] == JOB]
check('bounded closed-log manifest contains this single actual closed host', len(closed['jobs']) == len(closed_rows) == 1)
closed_row = closed_rows[0]
check('closed-log manifest exact job and raw log binding', closed_row['job_name'] == job['name'] and closed_row['status'] == job['status'] and closed_row['conclusion'] == job['conclusion'] and closed_row['started_at'] == job['started_at'] and closed_row['completed_at'] == job['completed_at'] and closed_row['record_path'] == 'commands/0036-closed-job-117558330019-log.record.json' and closed_row['log_path'] == log_record['stdout']['path'] and closed_row['log_bytes'] == log_record['stdout']['bytes'] and closed_row['log_sha256'] == log_record['stdout']['sha256'])
log_bytes = read(closed_row['log_path'])
raw_lines = log_bytes.decode().splitlines()
lines = [re.sub(r'^\d{4}-\d{2}-\d{2}T\S+\s', '', re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', line)) for line in raw_lines]

def observed_lines(pattern):
    return [{'log_line': i + 1, 'text': line} for i, line in enumerate(lines) if re.search(pattern, line)]

def span(start, finish):
    starts = [i for i, line in enumerate(lines) if line == start]
    check('exact one command span start: ' + start, len(starts) == 1)
    first = starts[0]
    ends = [i for i, line in enumerate(lines) if i > first and line == finish]
    check('exact one command span end: ' + finish, len(ends) == 1)
    last = ends[0]
    return [(i + 1, lines[i]) for i in range(first + 1, last)]

checkout_commands = [i for i, line in enumerate(lines) if line == '[command]/usr/bin/git log -1 --format=%H']
check('actual checkout logged immediately after git log command', len(checkout_commands) == 1 and lines[checkout_commands[0] + 1] == MERGE)
evidence['checkout'] = {'command_log_line': checkout_commands[0] + 1, 'sha_log_line': checkout_commands[0] + 2, 'actual_checkout_sha': lines[checkout_commands[0] + 1]}
captured_command('0007-observed-pr-merge-git-commit', f'repos/kalwad/jobapplyv2/git/commits/{MERGE}')
merge = obj('commands/0007-observed-pr-merge-git-commit.stdout')
check('actual logged merge checkout has exact current tree and head parent', merge['sha'] == MERGE and merge['tree']['sha'] == TREE and [p['sha'] for p in merge['parents']] == ['4745149f4b5da7190b5b0c68753f8ec07bed572d', HEAD])

report = obj('ci-progress-report-1.json')
profile_report = obj('native-profiles-progress-1.json')
check('progress report is this one closed host with no whole-run success claim', report['run_id'] == RUN and report['run_attempt'] == 1 and report['head_sha'] == HEAD and report['tree_sha'] == TREE and report['run_status'] == 'in_progress' and report['run_conclusion'] is None and len(report['hosts']) == 1 and report['all_host_jobs_success'] is False and report['authority'] == 'NONE' and report['owner_decision'] == 'PENDING' and report['gate_a_status'] == 'IN_PROGRESS')
host = report['hosts'][0]
check('derived host/report current job/checkout/tree bindings', host['job_id'] == JOB and host['job_name'] == job['name'] and host['job_status'] == job['status'] and host['job_conclusion'] == job['conclusion'] and host['log'] == closed_row and host['checkout_sha'] == report['tested_checkout_sha'] == MERGE and host['tested_tree_sha'] == report['tested_checkout_tree'] == TREE and host['tested_tree_equals_head_tree'] is True and report['tested_checkout_tree_equals_head_tree'] is True and report['head_sha_is_tested_merge_parent'] is True)

doctor = observed_lines(r'^summary: \d+ pass, \d+ warning, \d+ fail, \d+ not-yet-applicable$')
check('actual doctor 27 pass / 0 warning / 0 fail / 1 not-yet-applicable', len(doctor) == 1 and doctor[0]['text'] == 'summary: 27 pass, 0 warning, 0 fail, 1 not-yet-applicable')
check('doctor derived report exact raw observation', all(host['doctor'][k] == v for k, v in {'passed': 27, 'warnings': 0, 'failed': 0, 'not_yet_applicable': 1, **doctor[0]}.items()))
evidence['doctor'] = doctor

root_span = span('$ pnpm exec turbo run test --force -- --reporter=default', '$ pnpm generate:contracts --check')
root_results = []
for number, line in root_span:
    match = re.match(r'^\s*Tests\s+(.+?)\s+\((\d+)\)\s*$', line)
    if match:
        counts = {'passed': 0, 'failed': 0, 'skipped': 0, 'todo': 0}
        for value, kind in re.findall(r'(\d+)\s+(passed|failed|skipped|todo)', match[1]):
            counts[kind] += int(value)
        root_results.append({'log_line': number, 'text': line, **counts, 'total': int(match[2]), 'reconciles': sum(counts.values()) == int(match[2])})
root_totals = {k: sum(row[k] for row in root_results) for k in ['passed', 'failed', 'skipped', 'todo', 'total']}
check('actual 14 root TypeScript reports reconcile to 3905 pass and zero failed/skipped/todo', len(root_results) == 14 and root_totals == {'passed': 3905, 'failed': 0, 'skipped': 0, 'todo': 0, 'total': 3905} and all(row['reconciles'] for row in root_results))
check('derived root TypeScript totals and exact summary observations', all(host['root_unit_ts'][k] == v for k, v in root_totals.items()) and host['root_unit_ts']['observed_workspace_report_count'] == len(root_results) and host['root_unit_ts']['all_observed_reports_reconcile'] is True and [r['line'] for r in host['root_unit_ts']['observations']] == [r['text'] for r in root_results])
evidence['root_typescript'] = {'totals': root_totals, 'raw_summaries': root_results}

browser_evidence = {}
browser_spans = [
    ('default_browser', '$ pnpm exec playwright test', '$ pnpm exec playwright test --list', 246),
    ('controlled_research_browser', '$ pnpm exec playwright test --config e2e/extension/public-research/playwright.config.ts', '$ pnpm exec playwright test --config e2e/extension/public-research/playwright.config.ts --list', 2),
    ('controlled_contact_browser', '$ pnpm exec playwright test --config e2e/extension/public-contact/playwright.config.ts --reporter=list,json', '$ pnpm exec playwright test --config e2e/extension/public-contact/playwright.config.ts --reporter=list,json --list', 62)
]
for key, start, finish, expected in browser_spans:
    rows = span(start, finish)
    summaries = []
    counts = {'passed': 0, 'failed': 0, 'skipped': 0, 'flaky': 0}
    for number, line in rows:
        match = re.match(r'^\s*(\d+)\s+(passed|failed|skipped|flaky)(?:\s|$)', line)
        if match:
            counts[match[2]] += int(match[1])
            summaries.append({'log_line': number, 'text': line})
    actual_cases = [{'log_line': number, 'text': line} for number, line in rows if re.match(r'^\s*✓\s+\d+\s', line)]
    check(key + ': actual execution case rows and zero-skip result summary', len(actual_cases) == expected and counts == {'passed': expected, 'failed': 0, 'skipped': 0, 'flaky': 0})
    check(key + ': derived report exact counts and summary lines', all(host[key][k] == v for k, v in counts.items()) and host[key]['total'] == expected and host[key]['summary_lines'] == [r['text'] for r in summaries])
    browser_evidence[key] = {'counts': counts, 'execution_case_count': len(actual_cases), 'summaries': summaries, 'case_row_first': actual_cases[0], 'case_row_last': actual_cases[-1]}
evidence['browsers'] = browser_evidence

collect_starts = [i for i, line in enumerate(lines) if line.startswith('$ uv run pytest ') and '--collect-only -q' in line]
execute_starts = [i for i, line in enumerate(lines) if line.startswith('$ uv run pytest ') and '--collect-only' not in line]
check('actual Python has one collection and one execution command', len(collect_starts) == len(execute_starts) == 1 and collect_starts[0] < execute_starts[0])
python_ids = [{'log_line': i + 1, 'test_id': lines[i]} for i in range(collect_starts[0] + 1, execute_starts[0]) if re.match(r'^(?:scripts/tests/|services/orchestrator/tests/).*::', lines[i])]
collection_summary = observed_lines(r'^1492 tests collected in ')
execution_collection = observed_lines(r'^collected 1492 items$')
python_summary = observed_lines(r'^=+\s+1492 passed in 360\.32s \(0:06:00\)\s+=+$')
check('1492 unique actual Python collected IDs and actual 1492 passed execution', len(python_ids) == len({r['test_id'] for r in python_ids}) == 1492 and len(collection_summary) == len(execution_collection) == len(python_summary) == 1 and execute_starts[0] < python_summary[0]['log_line'] - 1)
check('derived Python report exact execution/collection observations and zero failed/skipped', host['python_status'] == 'COMPLETE' and all(host['python_execution_summary'][k] == v for k, v in {'passed': 1492, 'duration_seconds': 360.32, 'skipped': 0, 'failed': 0, **python_summary[0]}.items()) and host['python_collection_observations'] == [{'collected': 1492, **execution_collection[0]}])
evidence['python'] = {'unique_collection_ids': len(python_ids), 'collection_summary': collection_summary, 'execution_collection': execution_collection, 'execution_summary': python_summary, 'zero_skip_basis': 'The execution collected all 1492 IDs and reported all 1492 passed with no other outcome category in its final summary.'}

summary_headers = [i for i, line in enumerate(lines) if line == '== verification summary ==']
check('one actual aggregate verification summary', len(summary_headers) == 1)
suite_rows = []
for i in range(summary_headers[0] + 1, len(lines)):
    match = re.match(r'^(\S+)\s+(ACTIVE|NOT_YET_APPLICABLE)\s+(PASS|FAIL|NOT_YET_APPLICABLE)(?:\s+(.*))?$', lines[i])
    if match:
        suite_rows.append({'suite_id': match[1], 'state': match[2], 'result': match[3], 'detail': (match[4] or '').strip(), 'log_line': i + 1})
    if lines[i].startswith('verification exit code:'):
        break
active_rows = [r for r in suite_rows if r['state'] == 'ACTIVE']
visual = [r for r in suite_rows if r['suite_id'] == 'visual']
exit_observations = observed_lines(r'^verification exit code: ')
check('actual 19 ACTIVE suites PASS, visual NYA, aggregate exit 0', len(suite_rows) == 20 and len(active_rows) == 19 and all(r['result'] == 'PASS' for r in active_rows) and len(visual) == 1 and visual[0]['state'] == visual[0]['result'] == 'NOT_YET_APPLICABLE' and len(exit_observations) == 1 and exit_observations[0]['text'] == 'verification exit code: 0')
check('derived aggregate exact raw outcomes and exit code', host['aggregate_active_suite_count'] == 19 and host['aggregate_active_outcomes'] == {'PASS': 19} and host['aggregate_outcomes'] == suite_rows and host['aggregate_exit_codes'] == [0] and host['aggregate_summary_status'] == 'COMPLETE')
evidence['aggregate'] = {'suite_rows': suite_rows, 'exit_observations': exit_observations}

clean_steps = [s for s in job['steps'] if s['name'] == 'Assert verification left no tracked changes']
check('actual Ubuntu tracked-clean step completed successfully', len(clean_steps) == 1 and clean_steps[0]['status'] == 'completed' and clean_steps[0]['conclusion'] == 'success')
check('derived tracked-clean step matches captured job object', host['tracked_clean_step'] == [{k: clean_steps[0][k] for k in ['name', 'status', 'conclusion', 'started_at', 'completed_at']}])
check('Ubuntu job has no failed/cancelled steps and report has no failure details', not [s for s in job['steps'] if s['conclusion'] in ['failure', 'cancelled']] and host['failure_details'] == [])
evidence['tracked_clean'] = {'captured_step': clean_steps[0], 'raw_command_lines': observed_lines(r'^\$porcelain =|^if \(\$porcelain\)')}

native_observations = observed_lines(r'^W13_(SCALING_COMPLETED_ROW|SCALING|TARGET_P95) ')
decoded = [{'marker': row['text'].split(' ', 1)[0], 'payload': json.loads(row['text'].split(' ', 1)[1]), 'log_line': row['log_line']} for row in native_observations]
completed = [r for r in decoded if r['marker'] == 'W13_SCALING_COMPLETED_ROW']
final = [r for r in decoded if r['marker'] == 'W13_SCALING']
target = [r for r in decoded if r['marker'] == 'W13_TARGET_P95']
check('native actual markers are three complete rows, one final set, one target summary', len(completed) == 3 and len(final) == len(target) == 1)
rows = final[0]['payload']['rows']
check('native actual completed rows exactly equal final rows', [r['payload']['row'] for r in completed] == rows and [r['control_count'] for r in rows] == [8, 32, 128] and [r['payload']['iteration'] for r in completed] == [1, 2, 3])
native = rows[2]
work = native['scanner_work']
workload = {
    '128_attempted_and_physical_actions': native['control_count'] == native['actions_attempted'] == native['physical_actions_count'] == 128,
    '512_reresolutions': work['reresolution_calls'] == 512,
    '768_descriptors': work['descriptors_built'] == 768,
    '128_identity_pairs': work['identity_pairs_examined'] == 128,
    'one_index_rebuild': work['index_rebuilds'] == 1,
    '511_index_hits': work['index_hits'] == 511,
    'three_enumerations': work['candidate_enumerations'] == 3,
    '384_candidates': work['candidates_examined'] == 384,
    'zero_settle_budget': native['settle_budget_ms'] == 0,
    'completed_rows_equal_final_rows': [r['payload']['row'] for r in completed] == rows,
    'reported_p95_matches_single_observation': target[0]['payload']['samples'] == 1 and target[0]['payload']['p95_ms'] == native['total_wall_clock_ms']
}
check('native actual 128 workload and single 970.107883 ms observation', all(workload.values()) and native['total_wall_clock_ms'] == 970.1078830000006 and target[0]['payload']['threshold_ms'] == 1500 and target[0]['payload']['settle_budget_ms'] == 0)
check('native foreground lower-bound main-page telemetry scope', all(r['payload']['declared_application_tab_posture'] == 'FOREGROUND' for r in completed) and native['evidence_scope'] == 'LOWER_BOUND_NO_ASYNC_RERENDER_DELAY' and native['cpu_source'] == 'CHROMIUM_CDP_PERFORMANCE_TASK_DURATION_MAIN_PAGE' and native['heap_source'] == 'CHROMIUM_CDP_PERFORMANCE_JS_HEAP_USED_SIZE_MAIN_PAGE' and all(r['payload']['labels'] == ['DEVELOPMENT', 'HARNESS_VALIDATION', 'NOT_GATE_A_FINAL_EVIDENCE'] for r in completed + final))
check('progress report retains every raw native observation exactly', host['native128_ci_log_observations'] == native_observations)
check('native profile report exact current identity, one host, input-report hash, pending authority', profile_report['run_id'] == RUN and profile_report['run_attempt'] == 1 and profile_report['head_sha'] == HEAD and profile_report['tree_sha'] == TREE and profile_report['input_report'] == 'ci-progress-report-1.json' and profile_report['input_report_sha256'] == identity('ci-progress-report-1.json')['sha256'] and profile_report['observed_closed_host_count'] == len(profile_report['profiles']) == 1 and profile_report['authority'] == 'NONE' and profile_report['owner_decision'] == 'PENDING')
profile = profile_report['profiles'][0]
check('native interpreted profile exact job, raw row, observations, and workload', profile['job_id'] == JOB and profile['job_name'] == job['name'] and profile['job_conclusion'] == 'success' and profile['actual_samples'] == 1 and profile['reported_p95_ms'] == native['total_wall_clock_ms'] and profile['single_observation_exceeds_1500'] is False and profile['row'] == native and profile['workload_checks'] == workload and profile['raw_measurement_log_lines'] == {'scaling': final[0]['log_line'], 'target': target[0]['log_line'], 'completed': [r['log_line'] for r in completed]})
check('native interpreted profile preserves no 20-sample acceptance or enforced threshold claim', profile['threshold_enforced_by_this_profile'] is False and profile['target_20_sample_acceptance_claim'] is False and profile['posture'] == 'FOREGROUND')
benchmark_path = 'source/e2e/extension/extension-benchmark.spec.ts'
benchmark = read(benchmark_path)
benchmark_manifest = obj('supplemental-source-manifest.json')
benchmark_row = benchmark_manifest['files'][0]
check('copied benchmark source exact current manifest and Git blob', benchmark_manifest['head_sha'] == HEAD and benchmark_manifest['tree_sha'] == TREE and benchmark_manifest['authority'] == 'NONE' and benchmark_row['path'] == 'e2e/extension/extension-benchmark.spec.ts' and benchmark_row['bytes'] == len(benchmark) and benchmark_row['sha256'] == hashlib.sha256(benchmark).hexdigest() and benchmark_row['git_blob_sha'] == hashlib.sha1(b'blob ' + str(len(benchmark)).encode() + b'\0' + benchmark).hexdigest())
benchmark_text = benchmark.decode()
check('source enforces 1500 ms only in sampleCount 20 branch', 'if (sampleCount === 20) {\n    expect(process.platform).toBe("darwin");\n    expect(p95).toBeLessThanOrEqual(1500);\n  }' in benchmark_text and 'Number(process.env.JAPP_W13_PERFORMANCE_SAMPLES ?? "1")' in benchmark_text)
evidence['native'] = {'observations': native_observations, 'rows': rows, 'target': target[0]['payload'], 'workload_checks': workload, 'profile_limits': 'One foreground, zero-settle lower-bound CI observation. Main-page CDP CPU/heap telemetry only. No enforced 1500 ms assertion in one-sample mode; no 20-sample target-machine acceptance.'}

development = observed_lines(r'^W13_DEVELOPMENT ')
check('one actual development manifest observation', len(development) == 1)
development_payload = json.loads(development[0]['text'].split(' ', 1)[1])
manifest = development_payload['manifest']
check('actual development manifest repeats exact tested checkout/tree and no gate authority', manifest['repository']['commit'] == MERGE and manifest['repository']['tree'] == TREE and manifest['source_state'] == 'CLEAN' and manifest['authority'] == 'NONE' and manifest['labels'] == ['DEVELOPMENT', 'HARNESS_VALIDATION', 'NOT_GATE_A_FINAL_EVIDENCE'])

result = {
    'review_kind': 'INDEPENDENT_CLOSED_RESULT_REVIEW_ONE_UBUNTU_HOST_ONLY',
    'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'input_root': str(BASE), 'review_root': str(OUT),
    'run_id': RUN, 'run_attempt': 1, 'head_sha': HEAD, 'tree_sha': TREE,
    'reviewed_job_id': JOB, 'reviewed_job_name': job['name'], 'reviewed_job_status': job['status'], 'reviewed_job_conclusion': job['conclusion'],
    'tested_checkout_sha': MERGE, 'tested_checkout_tree': merge['tree']['sha'], 'tested_checkout_tree_equals_current_head_tree': merge['tree']['sha'] == TREE,
    'status': 'ONE_CLOSED_HOST_VERIFIED' if not findings else 'CONCRETE_FINDINGS',
    'verified_check_count': sum(r['verified'] for r in checks), 'check_count': len(checks), 'findings': findings, 'checks': checks, 'evidence': evidence,
    'summary': {'doctor': {'passed': 27, 'warning': 0, 'failed': 0, 'not_yet_applicable': 1}, 'root_typescript_passed': root_totals['passed'], 'default_browser_passed': browser_evidence['default_browser']['counts']['passed'], 'controlled_research_browser_passed': browser_evidence['controlled_research_browser']['counts']['passed'], 'controlled_contact_browser_passed': browser_evidence['controlled_contact_browser']['counts']['passed'], 'python_collected_unique': len(python_ids), 'python_execution_passed': 1492, 'active_suites': len(active_rows), 'active_suite_results': dict(Counter(r['result'] for r in active_rows)), 'visual_state': visual[0]['result'], 'aggregate_exit_code': 0, 'tracked_clean_step_success': clean_steps[0]['conclusion'] == 'success', 'actual_native128_samples': 1, 'actual_native128_ms': native['total_wall_clock_ms'], 'target_20_sample_acceptance_claim': False},
    'scope': 'Exactly one actual closed Ubuntu host; finite snapshot 0008 and its exact raw records. macOS and Windows outcomes remain unobserved in this review. This is neither final whole-run closure nor archive audit.',
    'whole_run_success_claim': False, 'other_closed_host_outcomes_reviewed': False,
    'historical_outcome_or_authority_transfer': False, 'gate_a_final_review': False,
    'authority': 'NONE', 'owner_decision': 'PENDING', 'gate_a_status': 'IN_PROGRESS',
    'actor_scope': 'Independent static interpretation of already captured inputs only. No network/API/browser/build/test/workflow dispatch/rerun/retry/cancellation; no collector or closure-validator invocation. Writes confined to this fresh sibling directory; prior frozen static directory untouched.',
    'inputs': sorted([identity(p) for p in inputs], key=lambda r: r['path'])
}
OUT.mkdir(exist_ok=True)
(OUT / 'closed-ubuntu-review.json').write_text(json.dumps(result, indent=2) + '\n')
(OUT / 'input-manifest.json').write_text(json.dumps({'input_root': str(BASE), 'scope': 'ONE_CLOSED_UBUNTU_HOST_ONLY', 'files': result['inputs'], 'authority': 'NONE', 'owner_decision': 'PENDING'}, indent=2) + '\n')
(OUT / 'python-collected-ids-recomputed.json').write_text(json.dumps({'job_id': JOB, 'unique_count': len(python_ids), 'observations': python_ids, 'authority': 'NONE'}, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'verified_check_count': result['verified_check_count'], 'check_count': result['check_count'], 'summary': result['summary'], 'findings': findings, 'input_count': len(result['inputs']), 'output': str(OUT)}, indent=2))
