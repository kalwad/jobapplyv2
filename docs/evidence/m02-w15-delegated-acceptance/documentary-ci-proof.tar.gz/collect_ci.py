#!/usr/bin/python3
import datetime as dt
import hashlib
import json
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path('/tmp/japp-m02-w15-0f91158-ci-20261018')
RUN = '39087938620'
REPO = 'kalwad/jobapplyv2'
EXPECTED_HEAD = '0f91158f68fa4fac4c5786b97b8d539d103d53ed'
EXPECTED_TREE = '85dd2cd9bc8969b448277560f0b107ca3e962b83'

def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def capture(argv, label):
    directory = ROOT / 'commands'
    directory.mkdir(parents=True, exist_ok=True)
    existing = sorted(directory.glob('*.record.json'))
    number = len(existing) + 1
    stem = '{:04d}-{}'.format(number, label)
    start = utc()
    tick = time.monotonic()
    process = subprocess.run(argv, cwd=str(ROOT), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    elapsed = time.monotonic() - tick
    end = utc()
    outpath = directory / (stem + '.stdout')
    errpath = directory / (stem + '.stderr')
    outpath.write_bytes(process.stdout)
    errpath.write_bytes(process.stderr)
    record = {
        'argv': argv, 'cwd': str(ROOT), 'started_at_utc': start,
        'ended_at_utc': end, 'elapsed_seconds': elapsed,
        'exit_code': process.returncode,
        'stdout': {'path': str(outpath.relative_to(ROOT)), 'bytes': len(process.stdout), 'sha256': digest(process.stdout)},
        'stderr': {'path': str(errpath.relative_to(ROOT)), 'bytes': len(process.stderr), 'sha256': digest(process.stderr)},
        'scope': 'READ_ONLY_GITHUB_API_NO_DISPATCH_NO_RETRY_NO_CANCEL_NO_ACCEPTANCE_AUTHORITY'
    }
    (directory / (stem + '.record.json')).write_text(json.dumps(record, indent=2) + '\n')
    if process.returncode != 0:
        raise RuntimeError('{} exited {}'.format(label, process.returncode))
    return process.stdout, record

def api(endpoint, label):
    output, record = capture(['/opt/homebrew/bin/gh', 'api', '-H', 'Accept: application/vnd.github+json', endpoint], label)
    return json.loads(output), record

def snapshot():
    run, run_record = api('repos/{}/actions/runs/{}'.format(REPO, RUN), 'run')
    jobs, jobs_record = api('repos/{}/actions/runs/{}/attempts/1/jobs?per_page=100'.format(REPO, RUN), 'jobs-attempt1')
    binding = {
        'run_id': run.get('id'), 'run_attempt': run.get('run_attempt'),
        'head_sha': run.get('head_sha'), 'head_branch': run.get('head_branch'),
        'event': run.get('event'), 'path': run.get('path'),
        'expected_head_sha': EXPECTED_HEAD,
        'head_matches': run.get('head_sha') == EXPECTED_HEAD,
        'expected_source_tree': EXPECTED_TREE,
        'tested_checkout_tree': None,
        'source_binding_status': 'PENDING_ACTUAL_CHECKOUT_AND_GIT_TREE_EVIDENCE',
        'status': run.get('status'), 'conclusion': run.get('conclusion'),
        'created_at': run.get('created_at'), 'updated_at': run.get('updated_at'),
        'jobs_total_count': jobs.get('total_count'),
        'jobs': [{k: j.get(k) for k in ('id','name','status','conclusion','started_at','completed_at','runner_name','runner_group_name','labels')} for j in jobs.get('jobs',[])],
        'records': [run_record, jobs_record], 'observed_at_utc': utc(),
        'authority': 'NONE', 'owner_decision': 'PENDING',
        'sample_scope': 'CI native128 timing is one sample per host, not the local 20-sample performance gate'
    }
    path = ROOT / ('snapshot-{:04d}.json'.format(len(list(ROOT.glob('snapshot-*.json'))) + 1))
    path.write_text(json.dumps(binding, indent=2) + '\n')
    print(json.dumps({'snapshot': str(path), 'run_id': binding['run_id'], 'run_attempt': binding['run_attempt'], 'head_matches': binding['head_matches'], 'status': binding['status'], 'conclusion': binding['conclusion'], 'jobs': binding['jobs']}, indent=2))
    if not binding['head_matches'] or binding['run_attempt'] != 1:
        raise RuntimeError('unexpected run head or attempt')
    if len(binding['jobs']) != jobs.get('total_count'):
        raise RuntimeError('jobs pagination incomplete')

if __name__ == '__main__':
    if len(sys.argv) != 2 or sys.argv[1] != 'snapshot':
        raise SystemExit('usage: collect_ci.py snapshot')
    snapshot()
