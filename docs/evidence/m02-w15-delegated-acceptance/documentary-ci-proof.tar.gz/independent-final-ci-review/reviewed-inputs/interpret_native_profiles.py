import hashlib,json,math,pathlib,sys
from collect_ci import ROOT

assert len(sys.argv)==3
report_path=ROOT/sys.argv[1]
out_path=ROOT/sys.argv[2]
assert not out_path.exists(), 'never overwrite a prior profile interpretation'
report=json.loads(report_path.read_text())
profiles=[]
for host in report['hosts']:
 observations=host['native128_ci_log_observations']
 decoded=[]
 for observed in observations:
  marker,payload=observed['text'].lstrip().split(' ',1)
  decoded.append({'marker':marker,'payload':json.loads(payload),'log_line':observed['log_line']})
 final=[x for x in decoded if x['marker']=='W13_SCALING']
 target=[x for x in decoded if x['marker']=='W13_TARGET_P95']
 completed=[x for x in decoded if x['marker']=='W13_SCALING_COMPLETED_ROW']
 assert len(final)==len(target)==1
 rows=final[0]['payload']['rows']
 assert [x['control_count'] for x in rows]==[8,32,128]
 assert len(completed)==len(rows)==3
 for number,(actual,row) in enumerate(zip(completed,rows),1):
  assert actual['payload']['iteration']==number
  assert actual['payload']['declared_application_tab_posture']=='FOREGROUND'
  assert actual['payload']['row']==row
 native=[x for x in rows if x['control_count']==128]
 times=sorted(x['total_wall_clock_ms'] for x in native)
 calculated=times[math.ceil(0.95*len(times))-1]
 t=target[0]['payload']
 assert len(native)==t['samples']==1
 assert math.isclose(calculated,t['p95_ms'],rel_tol=0,abs_tol=1e-9)
 assert t['threshold_ms']==1500 and t['settle_budget_ms']==0
 r=native[0];work=r['scanner_work']
 checks={
  '128_attempted_and_physical_actions':r['actions_attempted']==r['physical_actions_count']==128,
  '512_reresolutions':work['reresolution_calls']==512,
  '768_descriptors':work['descriptors_built']==768,
  '128_identity_pairs':work['identity_pairs_examined']==128,
  'one_index_rebuild':work['index_rebuilds']==1,
  '511_index_hits':work['index_hits']==511,
  'three_enumerations':work['candidate_enumerations']==3,
  '384_candidates':work['candidates_examined']==384,
  'zero_settle_budget':r['settle_budget_ms']==0,
  'completed_rows_equal_final_rows':True,
  'reported_p95_matches_single_observation':True
 }
 assert all(checks.values())
 profiles.append({'job_id':host['job_id'],'job_name':host['job_name'],'job_conclusion':host['job_conclusion'],'actual_samples':1,'reported_p95_ms':t['p95_ms'],'single_observation_exceeds_1500':t['p95_ms']>1500,'threshold_enforced_by_this_profile':False,'threshold_assertion_source':'The frozen benchmark source enforces p95 <= 1500 only when sampleCount is 20; CI uses the actual one-sample profile observed here.','target_20_sample_acceptance_claim':False,'posture':'FOREGROUND','workload_checks':checks,'row':r,'raw_measurement_log_lines':{'scaling':final[0]['log_line'],'target':target[0]['log_line'],'completed':[x['log_line'] for x in completed]},'scope':'One lower-bound zero-settle CI observation; CDP CPU/heap telemetry covers the main page only. No target-machine 20-sample gate or total-process resource claim.'})
result={'run_id':report['run_id'],'run_attempt':report['run_attempt'],'head_sha':report['head_sha'],'tree_sha':report['tree_sha'],'input_report':str(report_path.relative_to(ROOT)),'input_report_sha256':hashlib.sha256(report_path.read_bytes()).hexdigest(),'observed_closed_host_count':len(profiles),'profiles':profiles,'authority':'NONE','owner_decision':'PENDING'}
out_path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'closed_hosts':len(profiles),'profiles':[{k:x[k] for k in ['job_id','job_name','actual_samples','reported_p95_ms','single_observation_exceeds_1500','threshold_enforced_by_this_profile','target_20_sample_acceptance_claim']} for x in profiles]},indent=2))
