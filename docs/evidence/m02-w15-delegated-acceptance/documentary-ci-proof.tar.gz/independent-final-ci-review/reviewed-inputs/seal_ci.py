import datetime as dt,gzip,hashlib,io,json,os,pathlib,stat,tarfile
from collect_ci import ROOT,EXPECTED_HEAD,EXPECTED_TREE

OUT=pathlib.Path(str(ROOT)+'-retained')

def read_regular(path):
    before=path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('non-regular evidence input: '+str(path))
    fd=os.open(path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0))
    try:
        opened=os.fstat(fd)
        if (opened.st_dev,opened.st_ino)!=(before.st_dev,before.st_ino):
            raise RuntimeError('input identity changed')
        chunks=[]
        while True:
            chunk=os.read(fd,1024*1024)
            if not chunk:
                break
            chunks.append(chunk)
        after=os.fstat(fd)
    finally:
        os.close(fd)
    final=path.lstat()
    keys=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    if keys(before)!=keys(after) or keys(before)!=keys(final):
        raise RuntimeError('input mutated while captured')
    return b''.join(chunks)

def all_files():
    found=[]
    for path in sorted(ROOT.rglob('*')):
        if path.is_symlink():
            raise RuntimeError('symlink evidence input')
        if path.is_file():
            relative=path.relative_to(ROOT).as_posix()
            if relative=='proof-inputs.json' or relative.startswith('__pycache__/'):
                continue
            p=pathlib.PurePosixPath(relative)
            if p.is_absolute() or '..' in p.parts or not p.parts:
                raise RuntimeError('unsafe evidence member')
            found.append((relative,path))
    return found

report=json.loads((ROOT/'ci-review-report.json').read_text())
assert report['head_sha']==EXPECTED_HEAD and report['tree_sha']==EXPECTED_TREE
assert report['run_id']==39087938620 and report['run_attempt']==1
assert report['run_status']=='completed' and len(report['hosts'])==3
assert all(x['job_status']=='completed' for x in report['hosts'])
assert report['authority']=='NONE' and report['owner_decision']=='PENDING'
assert not OUT.exists(), 'sealed output already exists; never overwrite a prior evidence archive'
rows=[]
for name,path in all_files():
    data=read_regular(path)
    rows.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'version':1,'scope':'Exact finite CI documentary input list, captured after actual terminal states. Historical failed or cancelled CI is not acceptance.','head_sha':EXPECTED_HEAD,'tree_sha':EXPECTED_TREE,'run_id':39087938620,'run_attempt':1,'file_count':len(rows),'files':rows,'authority':'NONE','owner_decision':'PENDING'}
manifest_data=(json.dumps(manifest,indent=2)+'\n').encode()
(ROOT/'proof-inputs.json').write_bytes(manifest_data)
OUT.mkdir()
archive=OUT/'proof.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as zipped:
        with tarfile.open(fileobj=zipped,mode='w',format=tarfile.PAX_FORMAT) as tar:
            for row in rows+[{'path':'proof-inputs.json','bytes':len(manifest_data),'sha256':hashlib.sha256(manifest_data).hexdigest()}]:
                data=read_regular(ROOT/row['path'])
                assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
                info=tarfile.TarInfo(row['path'])
                info.size=len(data);info.mode=0o644;info.uid=0;info.gid=0;info.uname='';info.gname='';info.mtime=0
                tar.addfile(info,io.BytesIO(data))
for row in rows:
    data=read_regular(ROOT/row['path'])
    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
assert [n for n,p in all_files()]==[row['path'] for row in rows], 'evidence input set changed during sealing'
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers()
    assert len(members)==len(rows)+1 and len({m.name for m in members})==len(members)
    expected={r['path']:r for r in rows}
    expected['proof-inputs.json']={'path':'proof-inputs.json','bytes':len(manifest_data),'sha256':hashlib.sha256(manifest_data).hexdigest()}
    for member in members:
        assert member.isfile() and member.name in expected
        data=tar.extractfile(member).read()
        row=expected[member.name]
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
archive_data=archive.read_bytes()
outer={'archive':'proof.tar.gz','archive_bytes':len(archive_data),'archive_sha256':hashlib.sha256(archive_data).hexdigest(),'members':len(rows)+1,'source_manifest_sha256':hashlib.sha256(manifest_data).hexdigest(),'head_sha':EXPECTED_HEAD,'tree_sha':EXPECTED_TREE,'run_id':39087938620,'run_attempt':1,'actual_run_conclusion':report['run_conclusion'],'authority':'NONE','owner_decision':'PENDING','captured_at_utc':dt.datetime.now(dt.timezone.utc).isoformat()}
(OUT/'manifest.json').write_text(json.dumps(outer,indent=2)+'\n')
print(json.dumps(outer,indent=2))
