from pathlib import Path
from collections import Counter
from decimal import Decimal
import base64
import datetime
import hashlib
import json
import re

BASE = Path('/tmp/japp-m02-w15-0f91158-ci-20261018')
OUT = Path('/tmp/japp-m02-w15-0f91158-ci-independent-final-review-20261018')
HEAD = '0f91158f68fa4fac4c5786b97b8d539d103d53ed'
TREE = '85dd2cd9bc8969b448277560f0b107ca3e962b83'
MERGE = '4b345ab5df25d9ad30beaf38e94a8a2b0a9a185c'
RUN = 39087938620
EXPECTED = {
 117558330019: {'name': 'doctor + verify (ubuntu-24.04)', 'completed_at': '2026-10-18T02:12:39Z', 'python': 1492, 'native_decimal': '970.1078830000006'},
 117558330149: {'name': 'doctor + verify (windows-2025)', 'completed_at': '2026-10-18T02:30:01Z', 'python': 1490, 'native_decimal': '1059.0313999999998'},
 117558330187: {'name': 'doctor + verify (macos-15)', 'completed_at': '2026-10-18T02:30:14Z', 'python': 1492, 'native_decimal': '2345.9348750000026'},
}
inputs = {}
checks = []
findings = []
evidence = {}

def read(path):
    if path not in inputs:
        inputs[path] = (BASE / path).read_bytes()
    return inputs[path]

def obj(path):
    return json.loads(read(path))

def identity(path):
    data = read(path)
    return {'path': path, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def check(name, condition, detail=None):
    checks.append({'check': name, 'verified': bool(condition), 'detail': detail})
    if not condition:
        findings.append({'check': name, 'detail': detail})

def record_at(path):
    rec = obj(path)
    check(path + ': exit 0 / correct evidence root / captured scope', rec['exit_code'] == 0 and rec['cwd'] == str(BASE) and rec['scope'] == 'READ_ONLY_GITHUB_API_NO_DISPATCH_NO_RETRY_NO_CANCEL_NO_ACCEPTANCE_AUTHORITY')
    for stream in ['stdout', 'stderr']:
        check(path + ': exact ' + stream + ' bytes and SHA256', rec[stream] == identity(rec[stream]['path']))
    return rec

def api_record(stem, endpoint):
    rec = record_at('commands/' + stem + '.record.json')
    check(stem + ': exact read-only API endpoint', rec['argv'] == ['/opt/homebrew/bin/gh', 'api', '-H', 'Accept: application/vnd.github+json', endpoint])
    check(stem + ': empty captured stderr', read(rec['stderr']['path']) == b'')
    return rec

snapshot = obj('snapshot-0013.json')
run_rec = api_record('0047-run', f'repos/kalwad/jobapplyv2/actions/runs/{RUN}')
jobs_rec = api_record('0048-jobs-attempt1', f'repos/kalwad/jobapplyv2/actions/runs/{RUN}/attempts/1/jobs?per_page=100')
run = obj(run_rec['stdout']['path'])
jobs_response = obj(jobs_rec['stdout']['path'])
check('terminal snapshot exact current run/head/tree and successful state', snapshot['run_id'] == RUN and snapshot['run_attempt'] == 1 and snapshot['head_sha'] == snapshot['expected_head_sha'] == HEAD and snapshot['expected_source_tree'] == TREE and snapshot['status'] == 'completed' and snapshot['conclusion'] == 'success' and snapshot['authority'] == 'NONE' and snapshot['owner_decision'] == 'PENDING' and snapshot['records'] == [run_rec, jobs_rec])
check('terminal captured run exact current head/attempt/success', run['id'] == RUN and run['run_attempt'] == 1 and run['head_sha'] == HEAD and run['status'] == 'completed' and run['conclusion'] == 'success')
jobs = {row['id']: row for row in jobs_response['jobs']}
check('terminal captured jobs are exactly the three expected native hosts', jobs_response['total_count'] == len(jobs_response['jobs']) == len(jobs) == 3 and set(jobs) == set(EXPECTED))
closed = obj('closed-job-logs.json')
closed_rows = {row['job_id']: row for row in closed['jobs']}
check('closed log inventory exactly three current hosts', len(closed['jobs']) == len(closed_rows) == 3 and set(closed_rows) == set(EXPECTED))
report = obj('ci-review-report.json')
profiles_report = obj('native-profiles-final.json')
platform = obj('python-platform-inventory.json')
recurrence = obj('recurrence-observations.json')
closure = obj('ci-closure.json')
check('final CI report exact current run/head/tree and all-host actual success', report['run_id'] == RUN and report['run_attempt'] == 1 and report['head_sha'] == HEAD and report['tree_sha'] == TREE and report['run_status'] == 'completed' and report['run_conclusion'] == 'success' and report['all_host_jobs_success'] is True and report['authority'] == 'NONE' and report['owner_decision'] == 'PENDING' and report['gate_a_status'] == 'IN_PROGRESS' and len(report['hosts']) == 3)
hosts = {row['job_id']: row for row in report['hosts']}
profile_rows = {row['job_id']: row for row in profiles_report['profiles']}
check('final host and native profile sets exactly expected', set(hosts) == set(profile_rows) == set(EXPECTED))
check('final native profiles bind exact final report/current identity/pending authority', profiles_report['run_id'] == RUN and profiles_report['run_attempt'] == 1 and profiles_report['head_sha'] == HEAD and profiles_report['tree_sha'] == TREE and profiles_report['input_report'] == 'ci-review-report.json' and profiles_report['input_report_sha256'] == identity('ci-review-report.json')['sha256'] and profiles_report['observed_closed_host_count'] == 3 and profiles_report['authority'] == 'NONE' and profiles_report['owner_decision'] == 'PENDING')
api_record('0007-observed-pr-merge-git-commit', f'repos/kalwad/jobapplyv2/git/commits/{MERGE}')
merge = obj('commands/0007-observed-pr-merge-git-commit.stdout')
check('captured tested merge exact current tree and head parent', merge['sha'] == MERGE and merge['tree']['sha'] == TREE and [row['sha'] for row in merge['parents']] == ['4745149f4b5da7190b5b0c68753f8ec07bed572d', HEAD])
check('final tested checkout fields match captured Git object', report['tested_checkout_sha'] == MERGE and report['tested_checkout_tree'] == TREE and report['tested_checkout_parents'] == [row['sha'] for row in merge['parents']] and report['tested_checkout_tree_equals_head_tree'] is True and report['head_sha_is_tested_merge_parent'] is True)

normalized_by_job = {}
python_ids_by_job = {}
host_results = []

def review_host(job_id):
    expect = EXPECTED[job_id]
    job = jobs[job_id]
    host = hosts[job_id]
    closed_row = closed_rows[job_id]
    profile = profile_rows[job_id]
    prefix = str(job_id) + ': '
    def verify(label, condition, detail=None):
        check(prefix + label, condition, detail)
    verify('actual terminal current-run job success', job['run_id'] == RUN and job['name'] == expect['name'] and job['status'] == 'completed' and job['conclusion'] == 'success' and job['completed_at'] == expect['completed_at'])
    snap_job = next(row for row in snapshot['jobs'] if row['id'] == job_id)
    verify('snapshot selected job equals captured terminal job', all(snap_job[k] == job[k] for k in ['id', 'name', 'status', 'conclusion', 'started_at', 'completed_at']))
    rec = record_at(closed_row['record_path'])
    verify('exact current job closed-log API and record identity', rec['argv'] == ['/opt/homebrew/bin/gh', 'api', '-H', 'Accept: application/vnd.github+json', f'repos/kalwad/jobapplyv2/actions/jobs/{job_id}/logs'] and rec['stdout']['path'] == closed_row['log_path'] and rec['stdout']['bytes'] == closed_row['log_bytes'] and rec['stdout']['sha256'] == closed_row['log_sha256'] and read(rec['stderr']['path']) == b'')
    verify('closed manifest and final report exact terminal object/log binding', closed_row['job_name'] == job['name'] and closed_row['status'] == job['status'] and closed_row['conclusion'] == job['conclusion'] and closed_row['started_at'] == job['started_at'] and closed_row['completed_at'] == job['completed_at'] and host['job_name'] == job['name'] and host['job_status'] == 'completed' and host['job_conclusion'] == 'success' and host['started_at'] == job['started_at'] and host['completed_at'] == job['completed_at'] and host['log'] == closed_row)
    lines = [re.sub(r'^\d{4}-\d{2}-\d{2}T\S+\s', '', re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', line)) for line in read(closed_row['log_path']).decode().splitlines()]
    normalized_by_job[job_id] = lines
    def observations(pattern):
        return [{'log_line': i + 1, 'text': line} for i, line in enumerate(lines) if re.search(pattern, line)]
    def span(start, end):
        starts = [i for i, line in enumerate(lines) if line == start]
        verify('one exact command span start: ' + start, len(starts) == 1)
        ends = [i for i, line in enumerate(lines) if starts and i > starts[0] and line == end]
        verify('one exact command span end: ' + end, len(ends) == 1)
        return [(i + 1, lines[i]) for i in range(starts[0] + 1, ends[0])]
    result = {'job_id': job_id, 'job_name': job['name'], 'status': job['status'], 'conclusion': job['conclusion'], 'completed_at': job['completed_at']}
    checkout_commands = [i for i, line in enumerate(lines) if line.startswith('[command]') and line.endswith(' log -1 --format=%H')]
    verify('actual raw checkout logged after Git command equals current merge', len(checkout_commands) == 1 and lines[checkout_commands[0] + 1] == MERGE and host['checkout_sha'] == MERGE and host['tested_tree_sha'] == TREE and host['tested_tree_equals_head_tree'] is True)
    result['checkout'] = {'command_log_line': checkout_commands[0] + 1, 'sha_log_line': checkout_commands[0] + 2, 'sha': lines[checkout_commands[0] + 1], 'tree': TREE}
    doctor = observations(r'^summary: \d+ pass, \d+ warning, \d+ fail, \d+ not-yet-applicable$')
    verify('actual doctor 27/0/0/1 and exact final report observation', len(doctor) == 1 and doctor[0]['text'] == 'summary: 27 pass, 0 warning, 0 fail, 1 not-yet-applicable' and all(host['doctor'][k] == value for k, value in {'passed': 27, 'warnings': 0, 'failed': 0, 'not_yet_applicable': 1, **doctor[0]}.items()))
    result['doctor'] = doctor[0]
    root = span('$ pnpm exec turbo run test --force -- --reporter=default', '$ pnpm generate:contracts --check')
    ts_rows = []
    for number, line in root:
        match = re.match(r'^\s*Tests\s+(.+?)\s+\((\d+)\)\s*$', line)
        if match:
            counts = {'passed': 0, 'failed': 0, 'skipped': 0, 'todo': 0}
            for value, kind in re.findall(r'(\d+)\s+(passed|failed|skipped|todo)', match[1]):
                counts[kind] += int(value)
            ts_rows.append({'log_line': number, 'text': line, **counts, 'total': int(match[2]), 'reconciles': sum(counts.values()) == int(match[2])})
    totals = {k: sum(row[k] for row in ts_rows) for k in ['passed', 'failed', 'skipped', 'todo', 'total']}
    verify('actual root TS fourteen summaries / 3905 passed / zero failed skipped todo', len(ts_rows) == 14 and totals == {'passed': 3905, 'failed': 0, 'skipped': 0, 'todo': 0, 'total': 3905} and all(row['reconciles'] for row in ts_rows))
    verify('root TS final report equals raw per-workspace observations', all(host['root_unit_ts'][k] == value for k, value in totals.items()) and host['root_unit_ts']['observed_workspace_report_count'] == 14 and host['root_unit_ts']['all_observed_reports_reconcile'] is True and len(host['root_unit_ts']['observations']) == len(ts_rows) and all(all(reported[k] == raw[k] for k in ['passed', 'failed', 'skipped', 'todo', 'total']) and reported['line'] == raw['text'] and reported['reported_counts_reconcile'] == raw['reconciles'] for reported, raw in zip(host['root_unit_ts']['observations'], ts_rows)))
    result['root_typescript'] = {'totals': totals, 'summaries': ts_rows}
    result['browsers'] = {}
    browser_spans = [
      ('default_browser', '$ pnpm exec playwright test', '$ pnpm exec playwright test --list', 246),
      ('controlled_research_browser', '$ pnpm exec playwright test --config e2e/extension/public-research/playwright.config.ts', '$ pnpm exec playwright test --config e2e/extension/public-research/playwright.config.ts --list', 2),
      ('controlled_contact_browser', '$ pnpm exec playwright test --config e2e/extension/public-contact/playwright.config.ts --reporter=list,json', '$ pnpm exec playwright test --config e2e/extension/public-contact/playwright.config.ts --reporter=list,json --list', 62),
    ]
    for key, start, end, expected in browser_spans:
        rows = span(start, end)
        counts = {'passed': 0, 'failed': 0, 'skipped': 0, 'flaky': 0}
        summaries = []
        for number, line in rows:
            match = re.match(r'^\s*(\d+)\s+(passed|failed|skipped|flaky)(?:\s|$)', line)
            if match:
                counts[match[2]] += int(match[1])
                summaries.append({'log_line': number, 'text': line})
        actual_cases = [{'log_line': number, 'text': line} for number, line in rows if re.match(r'^\s*(?:✓|ok)\s+\d+\s', line)]
        verify(key + ': actual execution rows and zero-skip summary', len(actual_cases) == expected and counts == {'passed': expected, 'failed': 0, 'skipped': 0, 'flaky': 0})
        verify(key + ': final report exact counts and summary text', all(host[key][k] == value for k, value in counts.items()) and host[key]['total'] == expected and host[key]['summary_lines'] == [row['text'] for row in summaries])
        result['browsers'][key] = {'counts': counts, 'actual_passing_case_count': len(actual_cases), 'summaries': summaries, 'first_actual_case': actual_cases[0], 'last_actual_case': actual_cases[-1]}
    collect_commands = [i for i, line in enumerate(lines) if line.startswith('$ uv run pytest ') and '--collect-only -q' in line]
    execute_commands = [i for i, line in enumerate(lines) if line.startswith('$ uv run pytest ') and '--collect-only' not in line]
    verify('one actual Python collection and execution command', len(collect_commands) == len(execute_commands) == 1 and collect_commands[0] < execute_commands[0])
    ids = [lines[i] for i in range(collect_commands[0] + 1, execute_commands[0]) if re.match(r'^(?:scripts/tests/|services/orchestrator/tests/).*::', lines[i])]
    python_ids_by_job[job_id] = ids
    python_count = expect['python']
    collected_footer = observations(r'^' + str(python_count) + r' tests collected in ')
    execution_collection = observations(r'^collected ' + str(python_count) + r' items$')
    execution_footer = observations(r'^=+\s+' + str(python_count) + r' passed in [\d.]+s(?: \([^)]*\))?\s+=+$')
    verify('actual unique collected IDs equal all-passed execution count / zero skips', len(ids) == len(set(ids)) == python_count and len(collected_footer) == len(execution_collection) == len(execution_footer) == 1)
    actual_duration = float(re.search(r' passed in ([\d.]+)s', execution_footer[0]['text'])[1])
    verify('final Python report exact raw execution/collection observations', host['python_status'] == 'COMPLETE' and all(host['python_execution_summary'][k] == value for k, value in {'passed': python_count, 'skipped': 0, 'failed': 0, 'duration_seconds': actual_duration, **execution_footer[0]}.items()) and host['python_collection_observations'] == [{'collected': python_count, **execution_collection[0]}])
    retained_path = f'python-collected-ids-{job_id}.json'
    retained = obj(retained_path)
    verify('retained actual collected ID file equals raw collection with exact command lines', retained['job_id'] == job_id and retained['ids'] == ids and retained['collection_command_log_line'] == collect_commands[0] + 1 and retained['execution_command_log_line'] == execute_commands[0] + 1)
    platform_host = next(row for row in platform['hosts'] if row['job_id'] == job_id)
    verify('platform inventory retained IDs hash and count exact', platform_host['job_name'] == job['name'] and platform_host['count'] == python_count and platform_host['retained_ids'] == retained_path and platform_host['retained_ids_sha256'] == identity(retained_path)['sha256'])
    result['python'] = {'unique_collected_ids': len(ids), 'collected_footer': collected_footer, 'execution_collection': execution_collection, 'execution_footer': execution_footer, 'zero_skip_basis': 'All actual collected execution items appear in the passed count; final execution footer contains only passed category.', 'retained_ids': identity(retained_path)}
    summary_starts = [i for i, line in enumerate(lines) if line == '== verification summary ==']
    verify('one actual aggregate verification summary', len(summary_starts) == 1)
    suite_rows = []
    for i in range(summary_starts[0] + 1, len(lines)):
        match = re.match(r'^(\S+)\s+(ACTIVE|NOT_YET_APPLICABLE)\s+(PASS|FAIL|NOT_YET_APPLICABLE)(?:\s+(.*))?$', lines[i])
        if match:
            suite_rows.append({'suite_id': match[1], 'state': match[2], 'result': match[3], 'detail': (match[4] or '').strip(), 'log_line': i + 1})
        if lines[i].startswith('verification exit code:'):
            break
    active = [row for row in suite_rows if row['state'] == 'ACTIVE']
    visual = [row for row in suite_rows if row['suite_id'] == 'visual']
    exit_rows = observations(r'^verification exit code: ')
    verify('actual nineteen ACTIVE PASS / visual NYA / aggregate exit zero', len(suite_rows) == 20 and len(active) == 19 and all(row['result'] == 'PASS' for row in active) and len(visual) == 1 and visual[0]['state'] == visual[0]['result'] == 'NOT_YET_APPLICABLE' and len(exit_rows) == 1 and exit_rows[0]['text'] == 'verification exit code: 0')
    verify('final report exact aggregate raw outcomes and exit', host['aggregate_active_suite_count'] == 19 and host['aggregate_active_outcomes'] == {'PASS': 19} and host['aggregate_outcomes'] == suite_rows and host['aggregate_exit_codes'] == [0] and host['aggregate_summary_status'] == 'COMPLETE')
    clean = [step for step in job['steps'] if step['name'] == 'Assert verification left no tracked changes']
    verify('actual terminal tracked-clean step completed successfully / no failed steps', len(clean) == 1 and clean[0]['status'] == 'completed' and clean[0]['conclusion'] == 'success' and not [step for step in job['steps'] if step['conclusion'] in ['failure', 'cancelled']])
    verify('final report exact tracked-clean status and no failure details', host['tracked_clean_step'] == [{key: clean[0][key] for key in ['name', 'status', 'conclusion', 'started_at', 'completed_at']}] and host['failure_details'] == [])
    result['aggregate'] = {'suite_rows': suite_rows, 'exit_rows': exit_rows, 'tracked_clean_actual_step': clean[0]}
    raw_markers = observations(r'^W13_(SCALING_COMPLETED_ROW|SCALING|TARGET_P95) ')
    decoded = [{'marker': row['text'].split(' ', 1)[0], 'payload': json.loads(row['text'].split(' ', 1)[1]), 'log_line': row['log_line']} for row in raw_markers]
    completed = [row for row in decoded if row['marker'] == 'W13_SCALING_COMPLETED_ROW']
    final = [row for row in decoded if row['marker'] == 'W13_SCALING']
    target = [row for row in decoded if row['marker'] == 'W13_TARGET_P95']
    verify('actual native marker set complete and finite', len(completed) == 3 and len(final) == len(target) == 1)
    rows = final[0]['payload']['rows']
    native = rows[2]
    work = native['scanner_work']
    workload = {
      '128_attempted_and_physical_actions': native['control_count'] == native['actions_attempted'] == native['physical_actions_count'] == 128,
      '512_reresolutions': work['reresolution_calls'] == 512,
      '768_descriptors': work['descriptors_built'] == 768,
      '128_identity_pairs': work['identity_pairs_examined'] == 128,
      'one_index_rebuild': work['index_rebuilds'] == 1,
      '511_index_hits': work['index_hits'] == 511,
      'three_enumerations': work['candidate_enumerations'] == 3,
      '384_candidates': work['candidates_examined'] == 384,
      'zero_settle_budget': native['settle_budget_ms'] == 0,
      'completed_rows_equal_final_rows': [row['payload']['row'] for row in completed] == rows,
      'reported_p95_matches_single_observation': target[0]['payload']['samples'] == 1 and target[0]['payload']['p95_ms'] == native['total_wall_clock_ms'],
    }
    raw_target = next(row for row in raw_markers if row['text'].startswith('W13_TARGET_P95 '))
    decimal_target = json.loads(raw_target['text'].split(' ', 1)[1], parse_float=Decimal)
    verify('actual native complete/final row equality and exact workload', [row['control_count'] for row in rows] == [8, 32, 128] and [row['payload']['iteration'] for row in completed] == [1, 2, 3] and all(workload.values()))
    verify('actual one-sample native timing exact raw decimal and singleton p95', str(decimal_target['p95_ms']) == expect['native_decimal'] and target[0]['payload']['samples'] == 1 and target[0]['payload']['p95_ms'] == native['total_wall_clock_ms'] and target[0]['payload']['threshold_ms'] == 1500 and target[0]['payload']['settle_budget_ms'] == 0)
    verify('actual native foreground / lower-bound / main-page telemetry labels', all(row['payload']['declared_application_tab_posture'] == 'FOREGROUND' for row in completed) and native['evidence_scope'] == 'LOWER_BOUND_NO_ASYNC_RERENDER_DELAY' and native['cpu_source'] == 'CHROMIUM_CDP_PERFORMANCE_TASK_DURATION_MAIN_PAGE' and native['heap_source'] == 'CHROMIUM_CDP_PERFORMANCE_JS_HEAP_USED_SIZE_MAIN_PAGE' and all(row['payload']['labels'] == ['DEVELOPMENT', 'HARNESS_VALIDATION', 'NOT_GATE_A_FINAL_EVIDENCE'] for row in completed + final))
    verify('final report retains exact raw native markers and line mappings', host['native128_ci_log_observations'] == raw_markers)
    verify('final native profile exact raw row, workloads, timing, job, and measurement lines', profile['job_name'] == job['name'] and profile['job_conclusion'] == 'success' and profile['actual_samples'] == 1 and profile['reported_p95_ms'] == native['total_wall_clock_ms'] and profile['row'] == native and profile['workload_checks'] == workload and profile['raw_measurement_log_lines'] == {'scaling': final[0]['log_line'], 'target': target[0]['log_line'], 'completed': [row['log_line'] for row in completed]})
    verify('final native profile discloses actual overrun and no enforced threshold / target gate claim', profile['single_observation_exceeds_1500'] == (native['total_wall_clock_ms'] > 1500) and profile['threshold_enforced_by_this_profile'] is False and profile['target_20_sample_acceptance_claim'] is False and profile['posture'] == 'FOREGROUND')
    development = observations(r'^W13_DEVELOPMENT ')
    verify('one actual development manifest observation', len(development) == 1)
    development_manifest = json.loads(development[0]['text'].split(' ', 1)[1])['manifest']
    verify('actual development manifest exact tested commit/tree and no authority', development_manifest['repository']['commit'] == MERGE and development_manifest['repository']['tree'] == TREE and development_manifest['source_state'] == 'CLEAN' and development_manifest['authority'] == 'NONE' and development_manifest['labels'] == ['DEVELOPMENT', 'HARNESS_VALIDATION', 'NOT_GATE_A_FINAL_EVIDENCE'])
    result['native128'] = {'raw_observations': raw_markers, 'complete_final_rows': rows, 'target': target[0]['payload'], 'raw_p95_decimal': str(decimal_target['p95_ms']), 'workload_checks': workload, 'single_observation_exceeds_1500': native['total_wall_clock_ms'] > 1500, 'samples': 1, 'threshold_enforced': False, 'target_20_sample_acceptance_claim': False, 'scope': 'One foreground zero-settle lower-bound CI observation, main-page CDP telemetry only.'}
    return result

for job_id in EXPECTED:
    host_results.append(review_host(job_id))

posix_a = set(python_ids_by_job[117558330019])
windows = set(python_ids_by_job[117558330149])
posix_b = set(python_ids_by_job[117558330187])
extras = sorted(posix_a - windows)
expected_extras = ['scripts/tests/test_v14_migration.py::test_atomic_adoption_rejects_non_regular_source[fifo]', 'scripts/tests/test_v14_migration.py::test_atomic_adoption_rejects_non_regular_source[socket]']
check('actual POSIX collected sets equal, Windows is exact common 1490, only FIFO/socket pair differs', posix_a == posix_b and windows <= posix_a and len(posix_a) == 1492 and len(windows) == 1490 and extras == expected_extras and len(posix_a & posix_b & windows) == 1490)
check('final platform inventory exact current identity and raw platform set results', platform['run_id'] == RUN and platform['head_sha'] == HEAD and platform['tree_sha'] == TREE and platform['common_count'] == platform['windows_count'] == 1490 and platform['posix_count'] == 1492 and platform['posix_inventories_equal'] is True and platform['windows_equals_common_posix_subset'] is True and platform['posix_only_exact_test_ids'] == extras and platform['authority'] == 'NONE')
check('final recurrence report exact current identity and no authority', recurrence['run_id'] == RUN and recurrence['head_sha'] == HEAD and recurrence['authority'] == 'NONE' and len(recurrence['observations']) == 2 and {row['job_id'] for row in recurrence['observations']} == {117558330149, 117558330187})
label_correction = obj('closure-source-label-correction.json')
for row in recurrence['observations']:
    lines = normalized_by_job[row['job_id']]
    raw = row['actual_current_log_observation']
    check(str(row['job_id']) + ': recurrence exact current raw passing log line and generic scope', lines[raw['log_line'] - 1] == raw['text'] and row['job_name'] == EXPECTED[row['job_id']]['name'] and row['current_status'] == 'PASS_NO_TIMEOUT_RECORDED' and row['scope'] == label_correction['new_label'])
    match = re.match(r'^\s*✓ test/m02-w11/dynamic-protocol\.test\.ts \(29 tests\)', raw['text']) if row['job_id'] == 117558330187 else re.match(r'^\s*ok\s+\d+.*default loopback and inspect-only builds refuse a canonical contact preparation', raw['text'])
    check(str(row['job_id']) + ': recurrence actual passing test/module marker', match is not None)
evidence['platform_python'] = {'common_count': 1490, 'posix_count': 1492, 'windows_count': 1490, 'posix_only_ids': extras, 'test_skips': 0}
evidence['recurrence'] = recurrence['observations']

artifact_rec = api_record('0054-terminal-run-artifacts', f'repos/kalwad/jobapplyv2/actions/runs/{RUN}/artifacts?per_page=100')
artifacts = obj(artifact_rec['stdout']['path'])
check('actual terminal artifact API zero artifacts and capture follows terminal snapshot', artifacts == {'total_count': 0, 'artifacts': []} and artifact_rec['started_at_utc'] > snapshot['observed_at_utc'])
evidence['artifacts'] = {'actual_api_response': artifacts, 'capture_record': identity('commands/0054-terminal-run-artifacts.record.json'), 'trace_or_screenshot_bytes_claimed': False}

record_paths = sorted(p for p in (BASE / 'commands').glob('*.record.json') if int(p.name.split('-', 1)[0]) <= 56)
check('finite recorded collector command sequence exactly 0001 through 0056', len(record_paths) == 56 and [int(p.name.split('-', 1)[0]) for p in record_paths] == list(range(1, 57)))
records = [record_at(str(p.relative_to(BASE))) for p in record_paths]
check('all recorded API commands are implicit read-only GET without mutation flags', all(rec['argv'][-1].startswith('repos/kalwad/jobapplyv2/') and all(flag not in rec['argv'] for flag in ['--method', '-X', '--field', '-f', '--raw-field', '-F']) for rec in records if rec['argv'][:2] == ['/opt/homebrew/bin/gh', 'api']))
validator_records = [rec for rec in records if rec['argv'] == ['/usr/bin/python3', str(BASE / 'validate_final_closure.py')]]
check('one captured final closure-validator invocation, only after all terminal inputs', len(validator_records) == 1 and validator_records[0] == obj('commands/0056-validate-final-ci-closure.record.json') and validator_records[0]['started_at_utc'] > artifact_rec['ended_at_utc'] and validator_records[0]['exit_code'] == 0 and read(validator_records[0]['stderr']['path']) == b'')
validator_output = obj(validator_records[0]['stdout']['path'])
check('successful captured validator output matches current closure/recurrence results', validator_output['closure_validated'] is True and validator_output['recurrence'] == recurrence['observations'] and validator_output['selected_source_blobs'] == 12 and validator_output['all_three_hosts_success'] is True and validator_output['artifacts'] == 0)
check('closure final current identities / all-three results / limits / pending authority', closure['run_id'] == RUN and closure['run_attempt'] == 1 and closure['head_sha'] == HEAD and closure['tree_sha'] == TREE and closure['tested_merge_sha'] == MERGE and closure['all_three_host_jobs_actual_success'] is True and closure['all_three_19_active_suites_actual_pass'] is True and closure['all_three_actual_tracked_clean_steps_success'] is True and closure['common_python_count'] == 1490 and closure['posix_python_count'] == 1492 and closure['selected_exact_source_blob_count'] == 12 and closure['complete_git_inventory_rows'] == 1671 and closure['artifact_total_count'] == 0 and closure['authority'] == 'NONE' and closure['owner_decision'] == 'PENDING' and closure['gate_a_status'] == 'IN_PROGRESS' and 'does not enforce or satisfy the local 20-sample p95 gate' in closure['native128_scope'])
check('closure command/API counts equal exact pre-validation finite records', closure['collector_command_count_before_this_validation_record_is_written'] == len(records) - 1 == 55 and closure['github_api_reads_before_this_validation_record_is_written'] == sum(rec['argv'][:2] == ['/opt/homebrew/bin/gh', 'api'] for rec in records[:-1]) == 48)
for row in closure['bound_reports']:
    check('closure exact bound report bytes/SHA256: ' + row['path'], identity(row['path']) == row)

static = obj('independent-source-review/source-review.json')
check('frozen static source component identity/status/pending authority with no outcome transfer', identity('independent-source-review/source-review.json')['sha256'] == 'af121660bbef9ce0abfeba813c3ad425d7b66745690eb7a42f6338c8ec60b0d8' and static['status'] == 'SOURCE_CLEAR_WITHIN_STATIC_SCOPE' and static['exact_current_head'] == HEAD and static['exact_current_tree'] == TREE and static['authority'] == 'NONE' and static['owner_decision'] == 'PENDING' and static['behavioral_pass_inferred'] is False and static['gate_a_final_review'] is False)
for row in static['inputs']:
    check('frozen static source input still exact: ' + row['path'], identity(row['path']) == row)
check('static source comparison preserves documentary-only delta and separate evaluated proof', static['summary']['current_nontree_git_entries'] == 1671 and static['summary']['changed_nontree_paths'] == 19 and static['summary']['all_changed_paths_within_docs'] is True and static['summary']['non_doc_entry_equality_including_trees'] is True and static['summary']['selected_exact_source_blobs'] == 12 and static['separate_evaluated_implementation']['outcome_authority_transferred'] is False)
check('exact corrected current validator hash matches frozen pre-invocation review', identity('validate_final_closure.py')['sha256'] == label_correction['after_sha256'] == '25793c08273a26fcd28b8d2edac28af08a4db69d3bfc52eb43c57440d3ae8410' and static['reviewed_at_utc'] < validator_records[0]['started_at_utc'] and label_correction['validator_invoked_before_correction'] is False and label_correction['api_or_product_test_behavior_changed'] is False)
intermediate = read(label_correction['uninvoked_preimage'])
validator_source = read('validate_final_closure.py')
check('exact retained validator label-only correction precedes captured successful invocation', hashlib.sha256(intermediate).hexdigest() == label_correction['before_sha256'] and validator_source == intermediate.replace(label_correction['old_label'].encode(), label_correction['new_label'].encode(), 1) and label_correction['old_label'].encode() not in validator_source)
evidence['validator'] = {'captured_invocation_record': identity('commands/0056-validate-final-ci-closure.record.json'), 'captured_success_output': identity('commands/0056-validate-final-ci-closure.stdout'), 'current_source': identity('validate_final_closure.py'), 'first_and_only_captured_invocation': True, 'corrected_label_verified_before_invocation': True, 'prior_static_original_finding_retained_as_resolved': static['resolved_findings']}

source_rows = []
for name in ['source-manifest.json', 'supplemental-source-manifest.json']:
    source_manifest = obj(name)
    check(name + ': exact current head/tree/no authority', source_manifest['head_sha'] == HEAD and source_manifest['tree_sha'] == TREE and source_manifest['authority'] == 'NONE')
    for row in source_manifest['files']:
        data = read('source/' + row['path'])
        check('current exact copied Git blob and SHA256: ' + row['path'], len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'] and hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == row['git_blob_sha'])
        source_rows.append(row)
check('exactly twelve unique current source blobs', len(source_rows) == len({row['path'] for row in source_rows}) == 12)
benchmark = read('source/e2e/extension/extension-benchmark.spec.ts').decode()
check('frozen benchmark only enforces 1500ms in sampleCount20 Darwin branch', 'if (sampleCount === 20) {\n    expect(process.platform).toBe("darwin");\n    expect(p95).toBeLessThanOrEqual(1500);\n  }' in benchmark and 'Number(process.env.JAPP_W13_PERFORMANCE_SAMPLES ?? "1")' in benchmark)
mac_native = next(row['native128'] for row in host_results if row['job_id'] == 117558330187)
check('macOS actual single-observation over1500 is explicitly disclosed with no gate acceptance', mac_native['single_observation_exceeds_1500'] is True and mac_native['raw_p95_decimal'] == '2345.9348750000026' and mac_native['threshold_enforced'] is False and mac_native['target_20_sample_acceptance_claim'] is False)

result = {
 'review_kind': 'INDEPENDENT_ALL_THREE_CLOSED_NATIVE_CI_DOCUMENTARY_REVIEW',
 'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'input_root': str(BASE), 'review_root': str(OUT), 'run_id': RUN, 'run_attempt': 1, 'head_sha': HEAD, 'tree_sha': TREE,
 'status': 'ALL_THREE_CLOSED_NATIVE_CI_VERIFIED' if not findings else 'CONCRETE_FINDINGS',
 'verified_check_count': sum(row['verified'] for row in checks), 'check_count': len(checks), 'findings': findings, 'checks': checks,
 'hosts': host_results, 'evidence': evidence,
 'native128_disclosure': {'macos_actual_single_observation_ms': '2345.9348750000026', 'macos_observation_exceeds_1500': True, 'all_hosts_actual_samples_each': 1, 'one_sample_profile_enforces_threshold': False, 'local_20_sample_gate_satisfied': False, 'scope': 'One foreground zero-settle lower-bound CI observation per host. Main-page CDP CPU/heap telemetry only. macOS exceeds1500ms and is disclosed; CI one-sample profile neither enforces nor satisfies local20samplep95acceptance.'},
 'actual_artifact_count': 0, 'trace_or_screenshot_bytes_claimed': False,
 'source_identity_scope': 'Frozen static component independently proved 19 documentation-only changed paths and identical non-document Git entries versus evaluated95f5. Every frozen source input and twelve exact copied source blobs remain byte-identical. Prior evaluated behavior/outcomes are separate proof; current CI outcomes come only from these three current closed raw logs and terminal records.',
 'historical_outcome_or_authority_transfer': False,
 'scope': 'Final independent documentary CI review of all three actual closed native repository jobs only. This does not supply Gate A final evidence, local20samplep95acceptance, packaged-app/Windows11 certification, final Gate A verdict, or owner approval. Archive integrity is outside this phase.',
 'authority': 'NONE', 'owner_decision': 'PENDING', 'gate_a_status': 'IN_PROGRESS', 'gate_a_final_review': False,
 'actor_scope': 'Only already captured finite evidence interpreted. No network/API/browser/build/product test/workflowdispatch/rerun/retry/cancellation; no collector or closure-validator invocation by this reviewer. Writes confined to fresh final-review sibling; prior static and Ubuntu-only components untouched.',
 'inputs': sorted([identity(path) for path in inputs], key=lambda row: row['path']),
}
OUT.mkdir(exist_ok=True)
(OUT / 'final-ci-review.json').write_text(json.dumps(result, indent=2) + '\n')
(OUT / 'input-manifest.json').write_text(json.dumps({'input_root': str(BASE), 'scope': 'ALL_THREE_CLOSED_NATIVE_CI_DOCUMENTARY_ONLY', 'files': result['inputs'], 'authority': 'NONE', 'owner_decision': 'PENDING'}, indent=2) + '\n')
(OUT / 'python-platform-ids-recomputed.json').write_text(json.dumps({'run_id': RUN, 'hosts': [{'job_id': job_id, 'ids': ids} for job_id, ids in python_ids_by_job.items()], 'common_count': len(windows), 'posix_only_ids': extras, 'authority': 'NONE'}, indent=2) + '\n')
for path, data in inputs.items():
    target = OUT / 'reviewed-inputs' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
print(json.dumps({'status': result['status'], 'verified_check_count': result['verified_check_count'], 'check_count': result['check_count'], 'findings': findings, 'input_count': len(result['inputs']), 'native128_disclosure': result['native128_disclosure'], 'output': str(OUT)}, indent=2))
