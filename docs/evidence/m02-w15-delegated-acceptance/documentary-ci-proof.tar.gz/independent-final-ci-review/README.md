# Independent final closed native CI documentary review

**ALL_THREE_CLOSED_NATIVE_CI_VERIFIED**. All 456 comparisons verified; no findings. The first independent analysis attempt exited 0 with empty stderr. Two additional read-only subset reviews found no discrepancy in native profiles or Python inventories/recurrence observations.

Run `39087938620`, attempt `1`, actually completed successfully for current head `0f91158f68fa4fac4c5786b97b8d539d103d53ed` and tree `85dd2cd9bc8969b448277560f0b107ca3e962b83`. Terminal snapshot 13 and exact captured run/jobs responses record all three native jobs as completed/success:

| Host | Job | Completed UTC | Python passed | Native128, one sample |
|---|---|---|---:|---:|
| Ubuntu 24.04 | 117558330019 | 02:12:39 | 1492 | 970.107883 ms |
| Windows 2025 | 117558330149 | 02:30:01 | 1490 | 1059.031400 ms |
| macOS 15 | 117558330187 | 02:30:14 | 1492 | **2345.934875 ms** |

**The macOS single observation exceeds 1500 ms.** This is disclosed in the actual raw log and final profile. Each host supplies one native128 sample. The copied exact benchmark source enforces the 1500 ms assertion only for 20 samples on Darwin. One-sample CI neither enforces nor satisfies the local 20-sample p95 gate.

All three raw checkout logs record actual merge checkout `4b345ab5df25d9ad30beaf38e94a8a2b0a9a185c`. The captured merge Git object has the exact current tree and current head as a parent. Each actual development manifest repeats that commit/tree. The frozen static source review independently proved that all 19 changed paths versus evaluated `95f5` are under `docs` and every non-document Git entry is unchanged. Its exact source inputs and all twelve copied source blobs remain byte-identical. Current behavioral results come from these three current closed logs; prior evaluated outcomes or authority do not transfer.

For every host, raw evidence and final reports agree on doctor **27 pass / 0 warning / 0 fail / 1 not-yet-applicable**, **19 ACTIVE suites PASS**, visual **NOT_YET_APPLICABLE**, verification exit **0**, and a successful actual tracked-clean step. Root TypeScript has **3905 passed** across fourteen reconciled workspace summaries. Default browser has **246** actual passing case rows; controlled research/contact browser has **2 / 62**. These results have zero failed, skipped, todo, or flaky test outcomes in the applicable summaries. Platform-conditioned workflow step skips remain distinct from test skips.

Python raw collected IDs equal their retained files in order and their actual execution counts. Ubuntu and macOS inventories equal exactly at 1492; Windows is the complete 1490-ID common set. The only POSIX additions are `test_atomic_adoption_rejects_non_regular_source[fifo]` and `[socket]`. They are not skipped Windows tests. All collected items passed in execution, with zero failures/skips. Current recurrence observations match Windows refusal case line 2007 and macOS dynamic-protocol module line 746; the macOS complete NOT_READY inventory case also passes at line 747.

Native complete row objects equal final row objects for controls 8, 32, and 128 on each host. Each native128 workload has **128 attempted/physical actions, 512 re-resolutions, 768 descriptors, 128 identity pairs, one rebuild, 511 index hits, three enumerations, 384 candidates**. Report/profile raw marker text and line mappings match. Foreground posture, zero settle, lower-bound scope, and NOT_GATE_A_FINAL_EVIDENCE labels are retained. CDP CPU/heap measurements cover the main page. Exact raw timing lexemes are retained in the JSON report; macOS is `2345.9348750000026`.

The actual terminal artifacts API returned exactly **zero artifacts**. No trace or screenshot bytes are claimed. All 56 captured collector command records and their stdout/stderr hashes match. The corrected validator source SHA-256 `25793c08273a26fcd28b8d2edac28af08a4db69d3bfc52eb43c57440d3ae8410` matches the frozen review before invocation. Its only captured invocation follows terminal inputs and zero-artifact response, exits 0, and emits current bound labels/results. The original stale-label finding remains preserved as resolved, with both uninvoked preimages and correction evidence.

`final-ci-review.json` contains complete checks and host evidence. `input-manifest.json` lists exact byte counts/SHA-256 for **210 finite inputs**, retained byte-for-byte under `reviewed-inputs/`. The original analysis command record/stdout/stderr, audit source, recomputed Python ID sets, and additional subset-review notes are retained. No analysis failure occurred.

Authority: **NONE**. Owner decision: **PENDING**. Gate A: **IN_PROGRESS**. This final documentary CI review does not supply final Gate A verdict, owner approval, local 20-sample performance acceptance, packaged-app/Windows 11 certification, or archive integrity review.

Only already captured evidence was interpreted. No network/API, browser, build, product test, workflow dispatch, rerun, retry, cancellation, collector, or closure-validator invocation occurred by this reviewer. All writes were confined to this fresh final-review sibling; prior static and Ubuntu-only components remain unchanged.
