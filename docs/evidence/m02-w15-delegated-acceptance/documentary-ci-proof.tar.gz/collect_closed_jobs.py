import hashlib,json,pathlib
from collect_ci import capture, ROOT

jobs_path=sorted((ROOT/'commands').glob('*jobs-attempt1.stdout'))[-1]
jobs=json.loads(jobs_path.read_text())['jobs']
manifest_path=ROOT/'closed-job-logs.json'
manifest=json.loads(manifest_path.read_text()) if manifest_path.exists() else {'jobs':[],'scope':'Actual closed-job log downloads only; no workflow dispatch, rerun, retry, or cancellation.'}
existing={row['job_id'] for row in manifest['jobs']}
for job in jobs:
    if job['status'] != 'completed' or job['id'] in existing:
        continue
    output,record=capture(['/opt/homebrew/bin/gh','api','-H','Accept: application/vnd.github+json','repos/kalwad/jobapplyv2/actions/jobs/{}/logs'.format(job['id'])], 'closed-job-{}-log'.format(job['id']))
    manifest['jobs'].append({'job_id':job['id'],'job_name':job['name'],'status':job['status'],'conclusion':job.get('conclusion'),'started_at':job.get('started_at'),'completed_at':job.get('completed_at'),'log_bytes':len(output),'log_sha256':hashlib.sha256(output).hexdigest(),'log_path':record['stdout']['path'],'record_path':str(pathlib.Path(record['stdout']['path']).with_suffix('.record.json'))})
    manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'closed_logs_collected':len(manifest['jobs']),'closed_jobs':[{k:j[k] for k in ['job_id','job_name','conclusion','log_bytes']} for j in manifest['jobs']]},indent=2))
