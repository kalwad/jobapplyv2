from pathlib import Path
from collections import defaultdict
import base64
import datetime
import difflib
import hashlib
import json

BASE = Path('/tmp/japp-m02-w15-0f91158-ci-20261018')
OUT = Path('/tmp/japp-m02-w15-0f91158-ci-independent-source-review-20261018')
HEAD = '0f91158f68fa4fac4c5786b97b8d539d103d53ed'
TREE = '85dd2cd9bc8969b448277560f0b107ca3e962b83'
BEFORE_HEAD = '95f5b09f43d9bef06d6158ea0bb8b9e0e3aa9123'
BEFORE_TREE = 'b85166b035fbf90a1b8c85d54f52461ccc422dd6'
MERGE = '4b345ab5df25d9ad30beaf38e94a8a2b0a9a185c'
RUN = 39087938620
raw_inputs = {}
checks = []
findings = []
resolved_findings = []

def read(path):
    if path not in raw_inputs:
        raw_inputs[path] = (BASE / path).read_bytes()
    return raw_inputs[path]

def obj(path):
    return json.loads(read(path))

def identity(path):
    data = read(path)
    return {'path': path, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def check(name, condition, detail=None):
    checks.append({'check': name, 'verified': bool(condition), 'detail': detail})
    if not condition:
        findings.append({'id': name, 'severity': 'source-integrity', 'detail': detail})

def command(stem, expected_argv):
    record_path = f'commands/{stem}.record.json'
    record = obj(record_path)
    check(f'{stem}: exact captured command', record['argv'] == expected_argv,
          {'captured_argv': record['argv'], 'expected_argv': expected_argv})
    check(f'{stem}: successful capture', record['exit_code'] == 0)
    check(f'{stem}: source capture scope', record['scope'] == 'READ_ONLY_GITHUB_API_NO_DISPATCH_NO_RETRY_NO_CANCEL_NO_ACCEPTANCE_AUTHORITY')
    check(f'{stem}: source capture cwd', record['cwd'] == str(BASE))
    for stream in ['stdout', 'stderr']:
        path = f'commands/{stem}.{stream}'
        check(f'{stem}: {stream} exact bytes/SHA256', identity(path) == record[stream],
              {'actual': identity(path), 'recorded': record[stream]})
    check(f'{stem}: empty captured stderr', len(read(f'commands/{stem}.stderr')) == 0)
    return obj(f'commands/{stem}.stdout') if stem != '0006-expected-local-ls-tree' else read(f'commands/{stem}.stdout')

def api(endpoint):
    return ['/opt/homebrew/bin/gh', 'api', '-H', 'Accept: application/vnd.github+json', endpoint]

def git_tree_inventory(data, expected_sha, label):
    check(f'{label}: root identity and complete recursive response', data['sha'] == expected_sha and data['truncated'] is False)
    paths = [r['path'] for r in data['tree']]
    check(f'{label}: no duplicate or unsafe paths', len(paths) == len(set(paths)) and all(p and not p.startswith('/') and '..' not in p.split('/') for p in paths))
    rows = {r['path']: {k: r[k] for k in ['mode', 'type', 'sha']} for r in data['tree']}
    directories = {'': expected_sha}
    directories.update({p: r['sha'] for p, r in rows.items() if r['type'] == 'tree'})
    children = defaultdict(list)
    for path, row in rows.items():
        parent, _, leaf = path.rpartition('/')
        children[parent].append((leaf, row))
    tree_results = []
    for parent, sha in sorted(directories.items()):
        payload = b''
        for leaf, row in sorted(children[parent], key=lambda x: (x[0] + ('/' if x[1]['type'] == 'tree' else '')).encode()):
            payload += format(int(row['mode'], 8), 'o').encode() + b' ' + leaf.encode() + b'\0' + bytes.fromhex(row['sha'])
        actual_sha = hashlib.sha1(b'tree ' + str(len(payload)).encode() + b'\0' + payload).hexdigest()
        tree_results.append({'path': parent or '<root>', 'expected_sha': sha, 'reconstructed_sha': actual_sha, 'equal': sha == actual_sha, 'direct_child_count': len(children[parent])})
    check(f'{label}: every tree object reconstructs exactly', all(r['equal'] for r in tree_results),
          {'tree_objects_including_root': len(tree_results), 'mismatches': [r for r in tree_results if not r['equal']]})
    return rows, tree_results

head = command('0003-expected-head-git-commit', api(f'repos/kalwad/jobapplyv2/git/commits/{HEAD}'))
tree = command('0004-expected-recursive-tree', api(f'repos/kalwad/jobapplyv2/git/trees/{TREE}?recursive=1'))
local_raw = command('0006-expected-local-ls-tree', ['/usr/bin/git', '-C', '/Users/tanishkalwad/jobapplyv2', 'ls-tree', '-rz', '--full-tree', HEAD])
merge = command('0007-observed-pr-merge-git-commit', api(f'repos/kalwad/jobapplyv2/git/commits/{MERGE}'))
before_head = command('0008-evaluated-implementation-git-commit', api(f'repos/kalwad/jobapplyv2/git/commits/{BEFORE_HEAD}'))
before_tree = command('0009-evaluated-implementation-recursive-tree', api(f'repos/kalwad/jobapplyv2/git/trees/{BEFORE_TREE}?recursive=1'))
check('head API identity and tree binding', head['sha'] == HEAD and head['tree']['sha'] == TREE and [r['sha'] for r in head['parents']] == [BEFORE_HEAD])
check('evaluated implementation API identity and tree binding', before_head['sha'] == BEFORE_HEAD and before_head['tree']['sha'] == BEFORE_TREE)
check('observed merge API identity and tree equality', merge['sha'] == MERGE and merge['tree']['sha'] == TREE and [r['sha'] for r in merge['parents']] == ['4745149f4b5da7190b5b0c68753f8ec07bed572d', HEAD])

current_rows, current_tree_objects = git_tree_inventory(tree, TREE, 'current Git recursive tree')
before_rows, before_tree_objects = git_tree_inventory(before_tree, BEFORE_TREE, 'evaluated implementation Git recursive tree')
current_nontree = {p: r for p, r in current_rows.items() if r['type'] != 'tree'}
before_nontree = {p: r for p, r in before_rows.items() if r['type'] != 'tree'}
local_rows = {}
check('historical local ls-tree has terminal NUL', local_raw.endswith(b'\0'))
local_count = 0
for raw in local_raw.rstrip(b'\0').split(b'\0'):
    metadata, path = raw.split(b'\t', 1)
    mode, typ, sha = metadata.decode().split(' ')
    path = path.decode()
    local_count += 1
    local_rows[path] = {'mode': mode, 'type': typ, 'sha': sha}
check('1671 exact historical local Git entries equal current API non-tree entries', local_count == len(local_rows) == len(current_nontree) == 1671 and local_rows == current_nontree,
      {'local_raw_rows': local_count, 'local_unique_rows': len(local_rows), 'current_api_nontree_rows': len(current_nontree)})

def within_docs(path):
    return path == 'docs' or path.startswith('docs/')

changes = [{'path': p, 'before': before_nontree.get(p), 'after': current_nontree.get(p)} for p in sorted(set(before_nontree) | set(current_nontree)) if before_nontree.get(p) != current_nontree.get(p)]
non_docs_before = {p: r for p, r in before_rows.items() if not within_docs(p)}
non_docs_current = {p: r for p, r in current_rows.items() if not within_docs(p)}
delta = obj('documentary-tree-delta.json')
check('19 changed non-tree paths all within docs', len(changes) == 19 and all(within_docs(r['path']) for r in changes), {'changed_path_count': len(changes), 'changed_paths': changes})
check('every non-doc Git entry including subtree identities identical', non_docs_before == non_docs_current,
      {'before_entries_including_trees': len(non_docs_before), 'after_entries_including_trees': len(non_docs_current), 'nontree_entries': sum(r['type'] != 'tree' for r in non_docs_current.values())})
check('documentary delta captured report matches independently recomputed difference',
      delta['evaluated_implementation_head'] == BEFORE_HEAD and delta['evaluated_implementation_tree'] == BEFORE_TREE and delta['documentary_head'] == HEAD and delta['documentary_tree'] == TREE and delta['before_tracked_entries'] == len(before_nontree) == 1658 and delta['after_tracked_entries'] == len(current_nontree) == 1671 and delta['changed_paths'] == changes and delta['all_changes_within_docs'] is True and delta['all_non_docs_git_entries_identical'] is True and delta['authority'] == 'NONE' and delta['owner_decision'] == 'PENDING')

binding = obj('head-tree-binding.json')
observed = obj('observed-pr-merge-object.json')
check('captured binding summary matches static evidence and preserves checkout pending',
      binding['expected_head_sha'] == HEAD and binding['expected_tree_sha'] == TREE and binding['git_tracked_rows'] == binding['github_recursive_nontree_rows'] == 1671 and binding['local_commit_tree_inventory_equals_github_tree'] is True and binding['head_commit_api_tree_verified'] is True and binding['recursive_tree_truncated'] is False and binding['pull_head_observed'] == HEAD and binding['pull_merge_commit_observed'] == MERGE and binding['actual_tested_checkout_sha'] is None and binding['actual_tested_checkout_status'] == 'PENDING_CLOSED_JOB_LOG' and binding['authority'] == 'NONE' and binding['owner_decision'] == 'PENDING')
check('captured merge summary matches static object without checkout claim', observed['observed_pr_merge_sha'] == MERGE and observed['observed_pr_merge_tree'] == TREE and observed['tree_equals_expected'] is True and observed['actual_tested_checkout_claim'] is False)

source_results = []
selected_manifest = obj('source-manifest.json')
supplemental_manifest = obj('supplemental-source-manifest.json')
for manifest in [selected_manifest, supplemental_manifest]:
    check('source manifest exact current head/tree and no authority ' + ('selected' if manifest is selected_manifest else 'supplemental'), manifest['head_sha'] == HEAD and manifest['tree_sha'] == TREE and manifest['authority'] == 'NONE')
selected_rows = selected_manifest['files']
supplemental_rows = supplemental_manifest['files']
check('12 unique selected plus supplemental sources', selected_manifest['selected_source_count'] == len(selected_rows) == 11 and len(supplemental_rows) == 1 and len({r['path'] for r in selected_rows + supplemental_rows}) == 12)
for index, row in enumerate(selected_rows + supplemental_rows):
    stem = f'{index + 10:04d}-source-blob-{index + 1}' if index < 11 else '0021-benchmark-source-blob'
    blob = command(stem, api(f"repos/kalwad/jobapplyv2/git/blobs/{row['git_blob_sha']}"))
    decoded = base64.b64decode(blob['content'])
    copied = read('source/' + row['path'])
    sha1 = hashlib.sha1(b'blob ' + str(len(copied)).encode() + b'\0' + copied).hexdigest()
    sha256 = hashlib.sha256(copied).hexdigest()
    result = {'path': row['path'], 'bytes': len(copied), 'sha256': sha256, 'git_blob_sha': sha1,
              'git_tree_sha': current_nontree[row['path']]['sha'],
              'api_blob_sha': blob['sha'], 'api_decoded_bytes': len(decoded),
              'copied_equals_api_decoded': copied == decoded,
              'all_static_matches': copied == decoded and len(copied) == row['bytes'] == blob['size'] and sha256 == row['sha256'] and sha1 == row['git_blob_sha'] == current_nontree[row['path']]['sha'] == blob['sha'] and row['exact_git_blob_verified'] is True and blob['encoding'] == 'base64'}
    source_results.append(result)
    check('exact Git blob and SHA256: ' + row['path'], result['all_static_matches'], result)

derivation = obj('collector-derivation.json')
adaptation = obj('closure-source-adaptation.json')
label_correction = obj('closure-source-label-correction.json')
check('collector derivation binds current identity and pending authority', derivation['run_id'] == RUN and derivation['head_sha'] == HEAD and derivation['tree_sha'] == TREE and derivation['evaluated_implementation_head'] == BEFORE_HEAD and derivation['evaluated_implementation_run'] == 39084518359 and derivation['authority'] == 'NONE' and derivation['owner_decision'] == 'PENDING')
collector_results = []
for row in derivation['files']:
    actual = identity(row['file'])
    expected = label_correction['after_sha256'] if row['file'] == adaptation['source'] else row['current_initial_source_sha256']
    collector_results.append({**actual, 'recorded_expected_current_sha256': expected, 'matches': actual['sha256'] == expected})
    check('collector recorded current source SHA256: ' + row['file'], actual['sha256'] == expected, collector_results[-1])
preimage = identity(adaptation['uninvoked_initial_preimage'])
check('retained validator initial preimage matches derivation and adaptation before hash', preimage['sha256'] == adaptation['before_sha256'] == next(r['current_initial_source_sha256'] for r in derivation['files'] if r['file'] == adaptation['source']))
check('closure source adaptation count and non-transfer assertions', adaptation['actual_current_git_inventory_count'] == 1671 and adaptation['api_or_product_test_behavior_changed'] is False and adaptation['historical_result_transfer'] is False)
validator = read(adaptation['source']).decode()
original = read(adaptation['uninvoked_initial_preimage']).decode()
intermediate = read(label_correction['uninvoked_preimage']).decode()
intermediate_identity = identity(label_correction['uninvoked_preimage'])
check('retained intermediate validator matches original adaptation after and label correction before', intermediate_identity['sha256'] == adaptation['after_sha256'] == label_correction['before_sha256'])
check('label correction changes only the exact stale provenance narrative before invocation',
      label_correction['source'] == adaptation['source'] and label_correction['validator_invoked_before_correction'] is False and label_correction['historical_log_or_result_import_found'] is False and label_correction['api_or_product_test_behavior_changed'] is False and label_correction['authority'] == 'NONE' and intermediate.count(label_correction['old_label']) == 1 and intermediate.count(label_correction['new_label']) == 0 and validator == intermediate.replace(label_correction['old_label'], label_correction['new_label'], 1))
source_diff = '\n'.join(difflib.unified_diff(original.splitlines(), validator.splitlines(), fromfile=adaptation['uninvoked_initial_preimage'], tofile=adaptation['source'])) + '\n'
correction_diff = '\n'.join(difflib.unified_diff(intermediate.splitlines(), validator.splitlines(), fromfile=label_correction['uninvoked_preimage'], tofile=adaptation['source'])) + '\n'
stale = 'Current behavior comes from this exact 95f5 closed log only.'
if stale in validator:
    findings.append({'id': 'stale-prior-head-recurrence-label', 'severity': 'provenance-label', 'path': adaptation['source'], 'line': next(i for i, l in enumerate(validator.splitlines(), 1) if stale in l), 'observed_sha256': identity(adaptation['source'])['sha256'], 'detail': 'Uninvoked current validator reads current ROOT logs but would describe recurrence evidence as exact 95f5 closed log. This is stale narrative, not a detected old-log import. Correct label and preserve adaptation record before eventual invocation.'})
elif stale in intermediate:
    resolved_findings.append({'id': 'stale-prior-head-recurrence-label', 'severity': 'provenance-label', 'path': adaptation['source'], 'line': next(i for i, l in enumerate(intermediate.splitlines(), 1) if stale in l), 'observed_pre_correction_sha256': intermediate_identity['sha256'], 'observed_pre_correction_bytes': intermediate_identity['bytes'], 'corrected_source_sha256': identity(adaptation['source'])['sha256'], 'corrected_source_bytes': identity(adaptation['source'])['bytes'], 'resolution': 'Exact label-only correction verified against retained uninvoked intermediate source. Original finding retained; no historical log/result import was detected.', 'original_label': label_correction['old_label'], 'corrected_label': label_correction['new_label'], 'invocation_status': 'UNINVOKED_AS_RECORDED'})
current_collector_texts = {r['file']: read(r['file']).decode() for r in derivation['files']}
check('current executable collector sources contain no prior full head, prior run, or prior numeric timing observation',
      all(token not in text for text in current_collector_texts.values() for token in [BEFORE_HEAD, '39084518359', '2423.20975']))
check('collector core binds exact current output root/run/head/tree',
      f"ROOT = pathlib.Path('{BASE}')" in current_collector_texts['collect_ci.py'] and f"RUN = '{RUN}'" in current_collector_texts['collect_ci.py'] and f"EXPECTED_HEAD = '{HEAD}'" in current_collector_texts['collect_ci.py'] and f"EXPECTED_TREE = '{TREE}'" in current_collector_texts['collect_ci.py'])
check('current seal source enforces no authority and pending owner for current run',
      "assert report['authority']=='NONE' and report['owner_decision']=='PENDING'" in current_collector_texts['seal_ci.py'] and "'run_id':39087938620" in current_collector_texts['seal_ci.py'])

result = {
    'review_kind': 'INDEPENDENT_STATIC_SOURCE_EVIDENCE_REVIEW_ONLY',
    'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_root': str(BASE),
    'review_root': str(OUT),
    'exact_current_head': HEAD, 'exact_current_tree': TREE, 'current_run_id': RUN, 'run_attempt': 1,
    'separate_evaluated_implementation': {'head': BEFORE_HEAD, 'tree': BEFORE_TREE, 'outcome_authority_transferred': False},
    'status': 'CONCRETE_FINDING' if findings else 'SOURCE_CLEAR_WITHIN_STATIC_SCOPE',
    'static_check_count': len(checks), 'static_verified_check_count': sum(r['verified'] for r in checks),
    'findings': findings, 'resolved_findings': resolved_findings, 'checks': checks, 'source_blobs': source_results, 'collector_current_source_identities': collector_results,
    'summary': {'current_nontree_git_entries': len(current_nontree), 'current_recursive_tree_objects_including_root': len(current_tree_objects), 'evaluated_nontree_git_entries': len(before_nontree), 'evaluated_recursive_tree_objects_including_root': len(before_tree_objects), 'changed_nontree_paths': len(changes), 'all_changed_paths_within_docs': all(within_docs(r['path']) for r in changes), 'non_doc_entry_equality_including_trees': non_docs_before == non_docs_current, 'selected_exact_source_blobs': len(source_results), 'observed_merge_tree_equals_current_tree': merge['tree']['sha'] == TREE},
    'authority': 'NONE', 'owner_decision': 'PENDING', 'gate_a_final_review': False,
    'actual_tested_checkout_status': 'PENDING_CLOSED_JOB_LOG',
    'current_final_closure_validator_status': 'UNINVOKED_AS_SUPPLIED_FOR_THIS_REVIEW',
    'behavioral_pass_inferred': False, 'current_ci_outcome_inferred': False,
    'source_reuse_limits': ['Historical original collector bytes are not supplied in the allowed scope; historical SHA256 values are treated as derivation assertions, while every current source hash and retained validator preimage are independently checked.', 'Source reuse and shared code identity cannot transfer evaluated implementation outcomes, historical authority, owner approval, or actual tested-checkout identity.', 'Only captured immutable source inputs were read. No network, API, browser, build, product test, workflow dispatch, rerun, retry, or cancellation occurred; neither collector nor closure-validator code was invoked.'],
    'inputs': sorted([identity(p) for p in raw_inputs], key=lambda r: r['path'])
}
OUT.mkdir(exist_ok=True)
(OUT / 'source-review.json').write_text(json.dumps(result, indent=2) + '\n')
(OUT / 'input-manifest.json').write_text(json.dumps({'source_root': str(BASE), 'inputs': result['inputs'], 'authority': 'NONE'}, indent=2) + '\n')
(OUT / 'validator-adaptation-reviewed.diff').write_text(source_diff)
(OUT / 'validator-label-correction-reviewed.diff').write_text(correction_diff)
(OUT / 'tree-object-reconstruction.json').write_text(json.dumps({'current': current_tree_objects, 'evaluated_implementation': before_tree_objects, 'authority': 'NONE'}, indent=2) + '\n')
(OUT / 'changed-paths-recomputed.json').write_text(json.dumps(changes, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'static_verified_check_count': result['static_verified_check_count'], 'static_check_count': result['static_check_count'], 'summary': result['summary'], 'findings': findings, 'inputs_count': len(result['inputs']), 'output': str(OUT)}, indent=2))
