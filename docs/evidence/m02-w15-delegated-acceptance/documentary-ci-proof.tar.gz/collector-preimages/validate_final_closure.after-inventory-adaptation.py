import hashlib,json,pathlib,re
from collect_ci import ROOT,EXPECTED_HEAD,EXPECTED_TREE

def identity(path):
 data=path.read_bytes()
 return {'path':str(path.relative_to(ROOT)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
report=json.loads((ROOT/'ci-review-report.json').read_text())
profiles=json.loads((ROOT/'native-profiles-final.json').read_text())
platform=json.loads((ROOT/'python-platform-inventory.json').read_text())
assert profiles['input_report_sha256']==identity(ROOT/'ci-review-report.json')['sha256']
assert report['run_conclusion']=='success' and report['run_status']=='completed'
assert report['all_host_jobs_success'] and len(report['hosts'])==3
assert report['head_sha']==EXPECTED_HEAD and report['tree_sha']==EXPECTED_TREE
assert report['tested_checkout_tree_equals_head_tree'] and report['head_sha_is_tested_merge_parent']
assert report['complete_git_inventory_rows']==1671 and report['complete_github_git_inventory_equal_local_historical_commit']
for host in report['hosts']:
 assert host['job_status']=='completed' and host['job_conclusion']=='success'
 assert {k:host['doctor'][k] for k in ['passed','warnings','failed','not_yet_applicable']}=={'passed':27,'warnings':0,'failed':0,'not_yet_applicable':1}
 assert host['root_unit_ts']['passed']==host['root_unit_ts']['total']==3905
 assert host['root_unit_ts']['observed_workspace_report_count']==14
 assert host['root_unit_ts']['all_observed_reports_reconcile']
 assert host['root_unit_ts']['failed']==host['root_unit_ts']['skipped']==host['root_unit_ts']['todo']==0
 for key,count in [('default_browser',246),('controlled_research_browser',2),('controlled_contact_browser',62)]:
  assert host[key]['passed']==host[key]['total']==count
  assert host[key]['failed']==host[key]['skipped']==host[key]['flaky']==0
 assert not host['default_browser']['source_text_module_discovery_error']
 assert host['aggregate_active_suite_count']==19 and host['aggregate_active_outcomes']=={'PASS':19}
 assert host['aggregate_exit_codes']==[0]
 assert len(host['aggregate_outcomes'])==20
 nya=[x for x in host['aggregate_outcomes'] if x['state']=='NOT_YET_APPLICABLE']
 assert len(nya)==1 and nya[0]['suite_id']=='visual' and nya[0]['result']=='NOT_YET_APPLICABLE'
 assert host['python_status']=='COMPLETE'
 assert host['python_execution_summary']['passed']==(1490 if 'windows' in host['job_name'] else 1492)
 assert host['python_execution_summary']['skipped']==host['python_execution_summary']['failed']==0
 assert len(host['tracked_clean_step'])==1 and host['tracked_clean_step'][0]['conclusion']=='success'
 assert not host['failure_details']
assert profiles['observed_closed_host_count']==3
assert all(x['actual_samples']==1 and all(x['workload_checks'].values()) and not x['threshold_enforced_by_this_profile'] and not x['target_20_sample_acceptance_claim'] for x in profiles['profiles'])
assert platform['common_count']==platform['windows_count']==1490 and platform['posix_count']==1492
assert platform['posix_inventories_equal'] and platform['windows_equals_common_posix_subset']

recurrence=[]
for host in report['hosts']:
 if not any(x in host['job_name'] for x in ['macos','windows']):continue
 data=(ROOT/host['log']['log_path']).read_bytes()
 text=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',data.decode('utf-8',errors='replace'))
 lines=[re.sub(r'^\d{4}-\d{2}-\d{2}T\S+\s','',x) for x in text.splitlines()]
 if 'macos' in host['job_name']:
  matched=[{'log_line':i+1,'text':l} for i,l in enumerate(lines) if re.match(r'^\s*✓ test/m02-w11/dynamic-protocol\.test\.ts \(29 tests\)',l)]
  label='Existing dynamic-protocol module containing complete NOT_READY inventory'
 else:
  matched=[{'log_line':i+1,'text':l} for i,l in enumerate(lines) if re.match(r'^\s*ok\s+\d+.*default loopback and inspect-only builds refuse a canonical contact preparation',l)]
  label='Existing default loopback and inspect-only canonical-contact refusal test'
 assert len(matched)==1
 recurrence.append({'job_id':host['job_id'],'job_name':host['job_name'],'prior_failure_scope':label,'current_status':'PASS_NO_TIMEOUT_RECORDED','actual_current_log_observation':matched[0],'scope':'Current behavior comes from this exact 95f5 closed log only. The historical failed run is separate and no result is transferred.'})
(ROOT/'recurrence-observations.json').write_text(json.dumps({'run_id':report['run_id'],'head_sha':EXPECTED_HEAD,'observations':recurrence,'authority':'NONE'},indent=2)+'\n')

source_rows=[]
for name in ['source-manifest.json','supplemental-source-manifest.json']:
 source=json.loads((ROOT/name).read_text())
 for row in source['files']:
  data=(ROOT/'source'/row['path']).read_bytes()
  assert hashlib.sha256(data).hexdigest()==row['sha256'] and len(data)==row['bytes']
  assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['git_blob_sha']
  source_rows.append(row)
assert len(source_rows)==len({x['path'] for x in source_rows})==12
records=[json.loads(p.read_text()) for p in sorted((ROOT/'commands').glob('*.record.json'))]
for record in records:
 assert record['exit_code']==0
 for stream in ['stdout','stderr']:
  actual=identity(ROOT/record[stream]['path'])
  assert all(actual[k]==record[stream][k] for k in ['path','bytes','sha256'])
artifacts=json.loads(sorted((ROOT/'commands').glob('*terminal-run-artifacts.stdout'))[-1].read_text())
assert artifacts['total_count']==len(artifacts['artifacts'])==0
closure={'run_id':report['run_id'],'run_attempt':report['run_attempt'],'run_url':report['run_url'],'head_sha':EXPECTED_HEAD,'tree_sha':EXPECTED_TREE,'tested_merge_sha':report['tested_checkout_sha'],'all_three_host_jobs_actual_success':True,'all_three_19_active_suites_actual_pass':True,'all_three_actual_tracked_clean_steps_success':True,'common_python_count':1490,'posix_python_count':1492,'selected_exact_source_blob_count':12,'complete_git_inventory_rows':1671,'artifact_total_count':0,'artifact_scope':'Actual terminal artifacts API returned zero artifacts; no trace or screenshot bytes are claimed.','native128_scope':'Each CI host has one sample; actual per-host timings and any threshold-overrun observations are retained in native-profiles-final.json. CI one-sample mode does not enforce or satisfy the local 20-sample p95 gate.','collector_command_count_before_this_validation_record_is_written':len(records),'github_api_reads_before_this_validation_record_is_written':sum(x['argv'][:2]==['/opt/homebrew/bin/gh','api'] for x in records),'bound_reports':[identity(ROOT/name) for name in ['ci-review-report.json','native-profiles-final.json','python-platform-inventory.json','recurrence-observations.json','head-tree-binding.json','source-manifest.json','supplemental-source-manifest.json']],'collector_scope':'Read-only actual native repository CI. No workflow dispatch, rerun, retry, cancellation, browser, build, or test actor. Platform-conditioned workflow-step skips are separate from zero test skips. No packaged-app or Windows 11 end-user claim.','authority':'NONE','owner_decision':'PENDING','gate_a_status':'IN_PROGRESS'}
(ROOT/'ci-closure.json').write_text(json.dumps(closure,indent=2)+'\n')
print(json.dumps({'closure_validated':True,'recurrence':recurrence,'selected_source_blobs':12,'all_three_hosts_success':True,'artifacts':0},indent=2))
