# Supplemental W14 review — d99c592

**Subsequent safety amendment:** after the source-only review below, a separate author-independent actual-MV3 review confirmed the native `setCustomValidity()` publication race at this same commit (new HIGH KI-0091). Values and MutationObserver records stayed unchanged while native acceptance became rejected; execute/undo and W11 could publish stale verified/readiness evidence. This supersedes the overall no-new-defect conclusion below. The outside two-file correction and unchanged independent six-probe red/green evidence are described in `/tmp/japp-w14-native-validity-fix/SCOPE.md`; patch SHA256 `56382908665d5fd4c8543df701b67498b3f222bafc768164a15607755b0d21e8`. Root was still frozen when the correction was prepared; no integration or final gate result is inferred.

Reviewed commit: `d99c5921338984d6727a0a81bc38d7c628b41199`, PR #1. The checkout was clean at both inspected endpoints. This review performed only source/evidence reads and lightweight in-memory comparisons. No root files, Git index, build outputs or ignored outputs were changed; no tests, builds or browsers were launched. The retry succeeded without another quota error.

This is supplemental M02-W14 review, not a formal M02-W15 start or Gate A decision. I previously contributed the finite functional correction and delegated its collision implementation; this report must not be treated as the separate final independent approval of those contributions.

## Findings

No new concrete implementation defect was found within the reviewed scope. The local corrections have substantive retained evidence at their declared scopes. Their evidence does not complete the outstanding public, comparison, platform or final gate obligations below.

### Direct pinned compiler correction

`packages/contracts/test/contract/infrastructure.test.ts:122–170` resolves `rustup which rustc` from the repository with a bounded lookup, requires an absolute result, and uses that exact compiler/arguments/output directory for a successful valid-source compilation before testing the unchanged invalid source. The invalid source must still fail with `ADAPTER_EXIT_NONZERO`; missing executable, timeout, stderr and output failures are distinct failures in `support/process.ts:42–68`. The 30-second negative bound, 45-second case bound and mandatory bounded cleanup remain.

The retained Windows archive matches SHA-256 `7b25aed2f140a93c72a48e3682454d6ff658a771022a650acfcea809eadd6fc2` and its declared 104112 bytes. Its 16 safe, unique regular members, listed member sizes/hashes and embedded inventory agree. Retained after-source bytes match the committed test. Logs directly substantiate the local 8/8 focused and 2524/2524 complete contract results.

The old native Windows log establishes a 30.008-second probe and cleanup `EPERM`, with 2523/2524 contracts passing. Cleanup masks the underlying exception, so proxy/compiler lifetime remains a diagnosis rather than an established cause. No corrected native Windows execution is retained. KI-0090's `IN_PROGRESS` state and explicit pending confirmation are appropriate.

### Functional correction and runtime evidence

All eight after-source files in `docs/evidence/m02-w14-functional-corrections/proof.tar.gz` match the current committed files byte-for-byte. The archive/member hashes match the retention manifest (42 regular members). Source review confirms:

- Mounted contact decisions refresh the target through the existing W08 re-resolution endpoint, require the same session/frame/document/durable field ID, and refuse missing/ambiguous targets. The helper does not introduce a full-document scan or alternate write path.
- Validation clearing retains bounded local reference/component observations. Stable help/ownership text, reference strings, root, roles and classes must remain exact; only previously observed rejected error components becoming empty can supply clearing evidence. Exact settled evidence is carried through W11 and undo. Post-await property/index fences remain.
- Reconciliation retains separate physical collision observations with report-only item IDs and explicit required/optional uncertainty. These IDs do not enter field addresses, action selection or duplicate-action authority. Genuine application-root and capacity refusals remain separate.

The retained functional proof contains the actual original W06 32-case/43-control pass, the original P8 refusal/RECONCILED/NOT_READY behavior with stronger collision-count/removal assertions, six document/shadow composite positives/negatives, raw responses, and both honest outside-checkout setup failures. W06's source/build before/after inventories are equal. The report correctly discloses that the earlier combined P8/composite run was operationally held unchanged but did not independently capture whole-source pre/post inventories.

Production extension source, generated contracts and schema/catalog inputs have no changes from `b8b1423` through this revision. The frozen `b8b1423` retained aggregate archive/member hashes agree (14 regular members). Its raw log directly records all 19 active suites PASS, 228 default browser tests, 61 then-required controlled contact tests, 1454 Python tests and exit 0. Visual remains explicitly NOT_YET_APPLICABLE. This is evidence for that frozen checkpoint and the unchanged runtime scope; it is not a completed full-aggregate result for the later test/harness corrections.

### Semantic freeze and SHA optimization

The current v1 generator, catalog and generated TypeScript/Python semantic runtime bytes are exactly the W13 `4d6a3e57` preimages. Their SHA-256 hashes respectively are `d69b85650c220435e06a69186f099e89aa857834354394e47f86966fa821bc02`, `31722639c611cc94bfd9cc31a6e631433c6b145d2b2d8c9d5446aac31d3db1c3`, `449d3a34473791fc3b880fd76685f59e46fc7f2d8b75ed4572a4cee04b89848f`, and `832cf9bc405416a345f0fb62c7eff821bba4e041894a3d876ccf58d85883b549`.

A read-only TypeScript AST comparison found zero changed bodies among the shared v1/v2 predicate functions. The v2 additions are the gate holdout/completeness/integrity helpers and its separately named validator. The loader requires exact inherited v1 rule bindings. This supports the claim that owner-waiver semantics were added through a new version rather than rewriting frozen v1 semantics.

The SHA helper's bounded integer encoding preserves the 128-bit prefix's two leading zero bits and 26-character body. Its buffer never approaches the 32-bit shift limit. Public async rejection identity, exact-input cache keying, LRU limits and rejected-promise retirement remain intact; no DOM/currentness or action authority is derived from the cache. The retained optimization archive hashes agree (10 regular members); reference tests include byte/bit patterns, short/full buffers, Unicode, cache boundaries and failure channels. No new source defect was identified in this change.

### Later public observer correction

Source review confirms that native associated-label text is preserved literally, with alternative ARIA/wrapping/placeholder channels recorded separately. The read-only HTTP drain has a fixed 5000ms/50ms/100-poll bound and runs before the existing strict network-closure fence. A quiescent observation alone does not authorize actions. The controlled-suite minimum increases to 62 rather than reducing a threshold. Detailed public/comparison evidence completeness is separately reviewed by the fresh evidence auditor.

## Outstanding requirements and limits

- The retained current public campaign has zero action requests/scored cases and null accuracy/site acceptance. Refusal/interference observations substantiate the boundaries they exercise, not public fill accuracy or acceptance.
- Actual normal-user Simplify comparison remains zero cases. The synthetic four-example legacy component comparison supports its narrowly declared results, not broad or two-product superiority.
- Corrected native Windows confirmation is absent from the retained compiler correction proof. Local macOS contract success does not substitute for it.
- Root's current frozen verification run was active during review. I did not treat an in-progress run as PASS or mutate outputs to inspect it.
- Formal M02-W15 review and Gate A decision remain incomplete. The owner holdout waiver is accepted; it supplies no passing execution, numeric waiver or comparison result. M02-W14/Gate A `IN_PROGRESS`, W15 `NOT_STARTED` and release `NOT_READY` remain the appropriate documented posture.

Reviewed source includes current transaction/undo publication, component clearing, dynamic collision reconciliation, mounted target refresh, SHA helper/reference tests, v1/v2 semantic inheritance and compiler infrastructure. Reviewed retained evidence includes the functional, SHA optimization, frozen aggregate and Windows compiler archives/manifests. No new reproduction was necessary or executed during the frozen root run.
