"""Read-only bounded source/closed-case audit; no product imports or actors."""
import hashlib,json,re
from collections import Counter
from pathlib import Path
O=Path(__file__).resolve().parent;C=Path('/tmp/japp-m03-w06-owned-forced-case-v3-20261019');F=Path('/tmp/japp-m03-w06-owned-forced-case-20261019')
S=Path('/tmp/japp-m03-w06-package-lifecycle-runner-source-v3-20261019');S2=Path('/tmp/japp-m03-w06-package-lifecycle-runner-source-v2-20261019');G=Path('/tmp/japp-m03-w06-forced-config-v3-20261019')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def img(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def load(p):return json.loads(p.read_bytes())
def rows(p):return [json.loads(s) for s in p.read_text().splitlines()]
def put(n,v):(O/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
assert sha(S/'run_case.py')=='6da3caec71ac175e8971d4566749f04f5467a35b8ad5df5222808c96460310af'
old=(S2/'run_case.py').read_text();new=(S/'run_case.py').read_text();needle='env = {"PATH": "/usr/bin:/bin", "GIT_OPTIONAL_LOCKS": "0", "GIT_CONFIG_NOSYSTEM": "1",'
replacement='env = {"HOME": str(Path.home()), "PATH": "/usr/bin:/bin", "GIT_OPTIONAL_LOCKS": "0", "GIT_CONFIG_NOSYSTEM": "1",'
assert old.count(needle)==1 and old.replace(needle,replacement,1)==new
for p in (S2/'observer').iterdir():assert sha(p)==sha(S/'observer'/p.name)
for name in ['generate_config.py','append_command.py']:assert sha(S2/name)==sha(S/name)
config=load(C/'config.executed.json');assert config==load(G/'case.config.json') and config['case']=='FORCED_PARENT' and config['runner_sha256']==sha(S/'run_case.py')
outer=load(C/'outer.upfront.json');outcome=load(C/'outer.result.json');worker=load(C/'worker.result.json');force=load(C/'owned-parent.result.json');worker_launch=load(C/'worker.launch.json')
assert outer['config_sha256']==sha(G/'case.config.json')=='a729cf85d384b6a44d8ee8ff02057254af5ac84a4d8d9fe5a9de1c8ca7ef76e2'
assert outer['work_seconds']==330 and outer['total_seconds']==360 and outcome['status']=='WORKER_CLOSED' and outcome['exit_code']==0 and outcome['within_total_bound'] is True
assert outcome['elapsed_seconds']==31.42477833398152 and outcome['owned_worker_cleanup']=={'owned_handle':True,'term':False,'kill':False,'exit':0,'reaped':True}
assert worker['observer_exit']==0 and worker['GUI']==worker['authenticated_positive_HTTP']==worker['raw_ACK']=='UNOBSERVED' and worker['native_UI_receipts']==[]
for key,code in [('owned_observer_cleanup',0),('owned_app_direct_cleanup',-9)]:assert worker[key]=={'owned_handle':True,'term':False,'kill':False,'exit':code,'reaped':True}
assert worker['status']=='MECHANICAL_OBSERVER_CLOSED_MANUAL_REVIEW_REQUIRED' and worker['case_acceptance']=='NOT_DECIDED'
app=force['app_identity'];service=force['service_identity'];assert app['pid']==70344 and service['pid']==70354 and force['port']==56907
assert app['ppid']==worker_launch['owned_pid']==70340 and app['pgid']==app['pid'] and service['ppid']==app['pid'] and service['pgid']==service['pid']
assert app['executable']==config['bindings']['main']['original'] and service['executable']==config['bindings']['service']['original']
launch=load(C/'launch.receipt.json');assert launch==load(C/'launch.receipt.upfront.json')==worker['registered_launch'] and launch['identity']==app and launch['method']=='OWNED_POPEN_NOT_LS'
app_up=load(C/'app.upfront.json');assert app_up['argv']==[app['executable']] and app_up['environment']=={'PATH':'/usr/bin:/bin','LANG':'en_US.UTF-8'}
assert force['pass'] is True and force['declared_bound_seconds']==12 and force['parent_exit_code']==-9 and force['parent_wait_included'] is True
assert force['before_signal_monotonic']<=force['after_signal_monotonic']<=force['parent_wait_started']<=force['parent_wait_finished']
wait_ms=1000*(force['parent_wait_finished']-force['parent_wait_started']);assert 4<wait_ms<5
observations=force['observations'];assert len(observations)==5 and all(v is True for k,v in observations[-1].items() if k!='monotonic')
assert force['elapsed_ms']<12000 and force['elapsed_ms']>=1000*(observations[-1]['monotonic']-force['before_signal_monotonic'])
assert observations[0]['app_pid_absent'] is True and observations[0]['service_pid_absent'] is False and observations[0]['listener_closed'] is False
controls=rows(C/'control.jsonl');commands=[r['command'] for r in controls]
assert commands==worker['commands']==['unauthorized','port-exclusive','force-parent','wait-exit','port-released','finish']
events=rows(C/'observer/events.jsonl');counts=Counter(r['kind'] for r in events)
assert [r['sequence'] for r in events]==list(range(1,len(events)+1)) and len(events)==54
assert all(a['monotonic']<=b['monotonic'] for a,b in zip(events,events[1:]))
assert counts['APP_IDENTITY']==counts['NEW_SERVICE_IDENTITY']==counts['GUI_ACTION_ARMED']==counts['REGISTERED_EXIT_OBSERVED']==counts['CLOSED_PORT_REBOUND_AND_RELEASED']==counts['OBSERVATION_CLOSED']==1
assert counts['HTTP_NEGATIVE']==6 and counts['SAMPLE']==35 and counts['ROOT_COMMAND']==6 and not counts['OWNED_SERVICE_CRASH_SENT'] and not counts['OBSERVATION_INCOMPLETE']
http=[r['data'] for r in events if r['kind']=='HTTP_NEGATIVE']
assert {(r['path'],r['credential_mode']) for r in http}=={(p,c) for p in ['/health','/ready','/version'] for c in ['absent','synthetic_wrong']}
assert all(r['status']==401 and r['pid']==service['pid'] and r['port']==force['port'] for r in http)
exclusive=next(r for r in events if r['kind']=='LISTENER_EXCLUSIVE_BIND');assert exclusive['data']['port']==force['port'] and exclusive['data']['errno']==48
saved_service=next(r['data'] for r in events if r['kind']=='NEW_SERVICE_IDENTITY');assert saved_service==service
armed=next(r for r in events if r['kind']=='GUI_ACTION_ARMED');registered=next(r for r in events if r['kind']=='REGISTERED_EXIT_OBSERVED')
assert armed['monotonic']<force['before_signal_monotonic']<registered['monotonic'] and registered['data']['bound_seconds']==12 and registered['data']['elapsed_seconds']<12
rebound=next(r for r in events if r['kind']=='CLOSED_PORT_REBOUND_AND_RELEASED');assert rebound['data']['port']==force['port'] and registered['sequence']<rebound['sequence']
assert events[-1]['kind']=='OBSERVATION_CLOSED' and events[-1]['data']['current_service_present'] is False
final_sample=[r['data'] for r in events if r['kind']=='SAMPLE'][-1]
assert final_sample['app_present'] is False and final_sample['current_service'] is None and final_sample['ports_closed']=={str(force['port']):True} and final_sample['observed_other_children']==[]
assert len(final_sample['registered_services'])==1 and all(final_sample['registered_services'][0][k] is False for k in ['same_process_present','numeric_pid_present','group_present'])
# Raw listener witnesses are independently bound and target only the registered service.
listener_witness=[]
for p in sorted((C/'observer').glob('*.command.json')):
 cmd=load(p);result=load(p.with_name(p.name.replace('.command.json','.command.result.json')))
 assert cmd['argv'][0]=='/usr/sbin/lsof' and str(service['pid']) in cmd['argv']
 if result['returncode']==0:listener_witness.append(cmd)
assert listener_witness
before=load(C/'before.json');after=load(C/'after.json');assert before==after and before['tracked_count']==len(before['source_modes'])==1946 and len(before['files'])==43 and len(before['runtime_files'])==40
assert before['head']==config['expected_head'] and before['tree']==config['expected_tree']
source_manifest=Path(config['bindings']['source_manifest']['original']);assert sha(source_manifest)==config['bindings']['source_manifest']['sha256']=='15843b4b13bbf8ad8bbe4d37f1f3b8405977f6b71ac5c45ff0d9445f871dde3c'
source=load(source_manifest);assert len(source)==1946 and {r['path'] for r in before['source_modes']}==set(source)
for prefix in ['before','after']:
 assert (C/(prefix+'-status.stdout')).read_text()==config['expected_status']
 assert (C/(prefix+'-git.stdout')).read_text().splitlines()==[config['expected_head'],config['expected_tree']]
 tracked=(C/(prefix+'-tracked.stdout')).read_bytes().decode().rstrip('\0').split('\0');assert len(tracked)==len(set(tracked))==1946 and set(tracked)==set(source)
 for kind in ['git','status','tracked']:
  assert load(C/(prefix+'-'+kind+'.result.json'))['exit_code']==0
  env=load(C/(prefix+'-'+kind+'.upfront.json'))['environment'];assert env['HOME']=='/Users/tanishkalwad' and env['GIT_CONFIG_GLOBAL']=='/dev/null'
upfront=load(C/'observer/upfront.json');assert upfront['source_files']['observe_package.py']=='53ed0f5c33bb73de71e0c4660e9388a90640e9b49ff0e94d05cefb873a928526'
assert upfront['package_tree']==before['files'] and load(C/'observer.config.json')['bindings']['launch_receipt']['sha256']==sha(C/'launch.receipt.json')
assert not (C/'app.stdout').read_bytes() and not (C/'app.stderr').read_bytes() and not (C/'worker.stderr').read_bytes() and not (C/'observer.stderr').read_bytes()
failed=load(F/'worker.result.json');failed_outer=load(F/'outer.result.json');assert failed['status']=='INCOMPLETE' and failed['error']['detail']=='Actual source Git pins/status differ'
assert failed['owned_observer_cleanup']['owned_handle'] is False and failed['owned_app_direct_cleanup']['owned_handle'] is False and failed_outer['owned_worker_cleanup']['reaped'] is True
assert not (F/'app.upfront.json').exists() and not (F/'observer.upfront.json').exists()
failed_status=(F/'before-status.stdout').read_text();assert failed_status.replace('?? .claude/\n','',1)==config['expected_status']
assert 'HOME' not in load(F/'before-status.upfront.json')['environment']
put('source-failure-history.json',{'scope':'Distinct preserved harness/setup events, not product runtime failures','initial_copy2_failure':{'note':img(Path('/tmp/japp-m03-w06-actual-package-case-inputs-20261019/preparation-failure-note.txt')),'original_source':img(Path('/tmp/japp-m03-w06-actual-package-case-inputs-20261019/executed-preparation.py')),'fact_limit':'Authored note and original partial files. Original tool response is in conversation, not a retained raw stderr file. No pins/config/actor launched. Correction bytes-only copyfile, no system flag/mode claim.'},'base_case_preflight':{'worker':img(F/'worker.result.json'),'outer':img(F/'outer.result.json'),'raw_status':img(F/'before-status.stdout'),'actual_error':'Git pins/status differ; only extra ?? .claude/ relative to expected canonical status','owned_apps':0,'observers':0,'worker_reaped':True,'source_correction':'Single readonly Git HOME context restoration. No explicit new exclusion or product/runtime/source change.'},'root_reported_reversal_needle_and_missing_pin_attempt':{'evidence_kind':'Parent conversational report, authored note pending; not presented as retained raw stderr','actors_reported':0},'v3_source_delta':{'from':'f3264f7ca8e4191859bb06980820f572b3d1733863760f904ed7b0061833d309','to':sha(S/'run_case.py'),'exact_one_HOME_addition':True,'other_helpers_exact':True}})
put('derived-case-data.json',{'scope':'Actual one owned Popen forced-parent mechanical lifecycle case; no LaunchServices/UI claim','runner_sha256':sha(S/'run_case.py'),'case_config_sha256':outer['config_sha256'],'elapsed_seconds':outcome['elapsed_seconds'],'app_pid':app['pid'],'worker_pid':worker_launch['owned_pid'],'service_pid':service['pid'],'listener':force['port'],'source_gated_identity_checks':'Pinned executable/birth/UID plus actual held Popen; raw numeric UID is not an emitted field','parent_exit_code':force['parent_exit_code'],'parent_wait_ms':wait_ms,'signal_to_all_registered_absent_ms':force['elapsed_ms'],'bound_seconds':12,'observed_registered_exit_seconds':registered['data']['elapsed_seconds'],'six_negative_HTTP401':True,'exclusive_bind_errno':exclusive['data']['errno'],'port_rebound_after_exit':True,'same_source1946_app43_runtime40_and_modes_prepost':True,'owned_handle_receipts_all_reaped':True,'fallback_cleanup_signals_sent':False,'observer_events':dict(counts),'commands':commands,'GUI':'UNOBSERVED','positive_authenticated_HTTP':'UNOBSERVED','raw_ACK':'UNOBSERVED','unseen_descendants':'UNOBSERVED'})
put('findings.json',{'decision':'CLEAR_WITHIN_ACTUAL_OWNED_FORCED_PARENT_CASE_SCOPE','actionable_findings':[],'actual_result':'Outer0/worker0/observer0; actual held app SIGKILL-9, registered app/service/group/listener absent in219.148709ms including4.563584ms parentwait, below12s. No fallback cleanup signals.','source_input_integrity':'Runner6da3 exact single HOME delta from reviewedf326; observer53ed and helpers exact; source1946/app43/runtime40+modes beforeafter equal','prior_history':'Initial copy2/SIP receipt copy failure and base-case HOME-context preflight failure preserved separately with zero app/observer. Root conversational-only needle/pin attempt labeled as such.','limits':['No reviewer app/service/native/GUI/test/import/build action or root edit','One FORCED_PARENT own-Popen case only; GUI, positive authenticated HTTP, raw ACK and unseen descendants remain UNOBSERVED','Actual registered cleanup is not a complete OS descendant/spawn trace','No Close/Quit/LaunchServices/Unicode/restart-budget/W06 verification/platform/milestone acceptance inferred','Direct numeric UID value is not in emitted identity receipt; successful source-gated UID checks are distinguished from raw UID observation']})
(O/'REVIEW.md').write_text('Actual owned forced-parent data CLEAR within its single-case scope. Bound runner6da3 differs from reviewedf326 only by restoring HOME for read-only Git context; observer53ed and other helpers remain exact. Outer/worker/observer close0. Actual held Popen parent70344 exits-9; registered service70354, its group and listener56907 become absent in219.148709ms including4.563584ms parent wait, within12s. Six absent/wrong credential requests return401, exclusive bind returnsEADDRINUSE, observer records registered exit and the port is rebound/released. All owned handle receipts are reaped without fallback signals. Source1946, app43, runtime40 and modes match before/after.\n\nThe earlier case fails Git preflight before any app/observer; its raw extra ?? .claude/ and missing HOME context remain separate. Initial copy2/SIP failure is preserved via original source/partial files/authored note, not invented raw stderr. The root-reported reversal needle/missing-pin attempt is conversational evidence only.\n\nNo reviewer imports/builds/tests/actors/GUI/root writes occurred. This is one own-Popen forced-parent case, with GUI, positive authenticated HTTP, raw ACK and unseen descendants unobserved. It grants no LaunchServices/Close/Quit/restart-budget/Unicode, W06 verification, platform or milestone acceptance.\n')
inputs=[]
for d in [C,F]:
 for p in sorted(d.rglob('*')):
  if p.is_file():inputs.append(img(p))
for d in [S,G]:
 for p in sorted(d.rglob('*')):
  if p.is_file():inputs.append(img(p))
put('input-bindings.json',inputs)
files=[img(p) for p in sorted(O.iterdir()) if p.is_file() and p.name!='retention-manifest.json']
put('retention-manifest.json',{'scope':'Compact independent review and exact original references, no author payload/app/runtime duplication','files':files})
print(json.dumps({'review':img(O/'REVIEW.md'),'findings':img(O/'findings.json'),'retention':img(O/'retention-manifest.json'),'inputs':len(inputs),'actual_event_count':len(events)},indent=2))
