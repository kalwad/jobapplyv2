"""Read/hash/AST-only reviewer; imports no observer or product module."""
from pathlib import Path
import ast
import hashlib
import json
import shutil

SOURCE = Path('/tmp/japp-m03-w06-macos-package-lifecycle-preparation-20261019')
OUT = Path(__file__).parent
checks = []

def check(name, ok, detail=None):
    checks.append({'name':name, 'pass':bool(ok), 'detail':detail})

def sha(data):
    return hashlib.sha256(data).hexdigest()

manifest = json.loads((SOURCE/'retention-manifest.json').read_text())
check('exact eight declared payload members', len(manifest['files'])==8 and len({r['path'] for r in manifest['files']})==8)
for row in manifest['files']:
    path=Path(row['path'])
    path.relative_to(SOURCE)
    data=path.read_bytes()
    check('exact payload: '+path.relative_to(SOURCE).as_posix(), not path.is_symlink() and len(data)==row['bytes'] and sha(data)==row['sha256'])
check('exact closed packet paths', {p.resolve() for p in SOURCE.rglob('*') if p.is_file()} == {Path(r['path']).resolve() for r in manifest['files']} | {(SOURCE/'retention-manifest.json').resolve()})
check('requested plan pin', sha((SOURCE/'PLAN.md').read_bytes())=='2f8d577c4f7c02639932253cd593407f49e4b03ba4956ea0a3767bf668b9249b')
check('requested observer pin', sha((SOURCE/'observer/observe_package.py').read_bytes())=='9accb1d936c7d6faa50a2f88a94496cade12de2b2189d267068eb9e2b50c5987')
check('requested preparation pin', sha((SOURCE/'PREPARATION.json').read_bytes())=='b118371372da7b2c7e6007841452b0cb2bb3bc8d28b3d7bcf2260bbf54f764c8')
preparation=json.loads((SOURCE/'PREPARATION.json').read_text())
borrowed={'japp_mac_probe.py':'/tmp/japp-m03-w03-canonical-close-v4-20261019/retained/source/japp_mac_probe.py',
          'japp_probe_core.py':'/tmp/japp-m03-w03-canonical-close-v4-20261019/retained/source/japp_probe_core.py',
          'macos_package.py':'/tmp/japp-m03-w06-w08-current-registry-join-proposal-20261019/overlay/scripts/macos_package.py'}
for name, original in borrowed.items():
    check('borrowed helper byte equality: '+name, (SOURCE/'observer'/name).read_bytes()==Path(original).read_bytes())
for name in ('observe_package.py',*borrowed):
    module=ast.parse((SOURCE/'observer'/name).read_text())
    check('stdlib AST parse only: '+name, isinstance(module,ast.Module))
template=json.loads((SOURCE/'observer/config.template.json').read_text())
check('template explicitly nonexecutable', template['schema']=='SOURCE_ONLY_TEMPLATE_NOT_EXECUTABLE' and template['app_pid'] is None)
check('no actual outcomes claimed', preparation['actual_runtime_or_package_results']=='NONE' and preparation['native_actor_count']==0 and preparation['native_build_count']==0)
snap=OUT/'reviewed-inputs'
snap.mkdir()
for path in sorted(SOURCE.rglob('*')):
    if path.is_symlink(): raise ValueError('Link in reviewed inputs')
    if path.is_file():
        dest=snap/path.relative_to(SOURCE)
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(path,dest)
        if path.read_bytes()!=dest.read_bytes(): raise ValueError('Source changed while copying')
result={'scope':'Independent read/hash/AST and manual source review only; no proposal import or actor execution',
        'checks':checks, 'passed':sum(r['pass'] for r in checks), 'total':len(checks),
        'findings':[
          {'id':'W06_OBSERVER_001','priority':'P2','file':'observer/observe_package.py','lines':[257,265],
           'issue':'Potentially slow executable hashing and receipt flush intervene between process revalidation and numeric SIGKILL; no final identity or case-deadline fence.',
           'direction':'Complete slow work and intent receipt first, then fresh exact child/app/UID checks and active deadline immediately before signaling.'},
          {'id':'W06_OBSERVER_002','priority':'P2','file':'observer/observe_package.py','lines':[200,216],
           'issue':'wait_for checks deadline before sample only; a slow sample can cross until and still emit bounded success.',
           'direction':'Check the post-sample time against the original cutoff before listener/replacement/exit success credit.'}
        ]}
(OUT/'findings.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':result['passed'],'total':result['total'],'material_source_findings':len(result['findings'])}))
