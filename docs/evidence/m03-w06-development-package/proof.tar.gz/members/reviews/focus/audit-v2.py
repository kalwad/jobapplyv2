"""Read only closed focus records and current inventory; no product imports/reruns."""
import hashlib,json,re,shlex
from pathlib import Path
B=Path('/tmp/japp-m03-w06-canonical-adoption-20261019');R=Path('/Users/tanishkalwad/jobapplyv2');O=Path(__file__).resolve().parent
P=B/'checks';N=B/'native-focused'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def image(p):return {'bytes':p.stat().st_size,'sha256':sha(p)}
def load(p):return json.loads(p.read_bytes())
def put(n,o):(O/n).write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
sources=load(B/'source-after.json');assert len(sources)==1946
for d in [P,N]:assert load(d/'source-before.json')==load(d/'source-after.json')==sources
assert load(N/'runtime-before.json')==load(N/'runtime-after.json') and len(load(N/'runtime-before.json'))==40
commands=[]
for name in ['ruff','format','mypy','affected-pytest','portability','collection']:
 u=load(P/(name+'-upfront.json'));r=load(P/(name+'-result.json'));log=P/(name+'.log')
 assert all(r[k]==v for k,v in u.items())
 assert r['exit_code']==0 and not r['timeout'] and r['tool_sha256_before']==r['tool_sha256_after']==sha(Path(r['tool']))
 assert r['log_bytes']==log.stat().st_size and r['log_sha256']==sha(log) and r['elapsed_seconds']<r['timeout_seconds']
 commands.append({'label':name,'argv':r['argv'],'exit_code':0,'elapsed_seconds':r['elapsed_seconds'],'log':{'path':str(log),**image(log)}})
assert re.search(r'^112 passed in 2\.83s$',(P/'affected-pytest.log').read_text(),re.M)
c=load(P/'actual-collected-ids.json');raw=[x.strip() for x in (P/'collection.log').read_text().splitlines() if '::' in x]
assert len(raw)==len(set(raw))==c['count']==len(c['node_ids'])==1801 and set(raw)==set(c['node_ids'])
assert c['source_parser_sha256']==sources['scripts/verify.py']['sha256']==sha(R/'scripts/verify.py')
assert '--disable-plugin-autoload' in commands[-1]['argv'] and '--collect-only' in commands[-1]['argv']
old=load(B/'inventory-before.json');new=load(O/'inventory-reviewed.json');update=load(B/'inventory-update.json');oldids=set(old['common']['node_ids']);newids=set(new['common']['node_ids']);added=newids-oldids;posix=old['posix_only_node_ids']
assert sha(B/'inventory-before.json')==sources['scripts/python-test-inventory.v1.json']['sha256']
assert old['common']['count']==len(oldids)==1687 and new['common']['count']==len(newids)==1799
assert len(added)==112 and not oldids-newids and new['posix_only_node_ids']==posix and len(posix)==2 and not newids.intersection(posix)
assert set(raw)==newids|set(posix) and new['common']['node_ids']==sorted(new['common']['node_ids'])
assert new['common']['sha256']==hashlib.sha256(('\n'.join(new['common']['node_ids'])+'\n').encode()).hexdigest()
assert update['inventory_sha256']==sha(O/'inventory-reviewed.json')==sha(R/'scripts/python-test-inventory.v1.json')
assert update['common_sha256']==new['common']['sha256'] and set(update['added_ids'])==added and update['removed_ids']==[]
expect=load(Path('/tmp/japp-m03-w06-w08-current-adoption-preparation-20261019/expected-python-additions.json'))
assert set(expect['node_ids'])==added and set(expect['prior_ten_current_ids_preserved']).issubset(newids)
assert {i.split('::')[0] for i in added}=={a for a in commands[3]['argv'] if a.endswith('.py')}
for platform,entry in update['platform_loader_results'].items():
 ids=sorted(newids|(set(posix) if platform in ['darwin','linux'] else set()))
 assert entry['count']==len(ids) and entry['sha256']==hashlib.sha256(('\n'.join(ids)+'\n').encode()).hexdigest() and entry['exact_ids_match'] is True
fresh=load(B/'source-for-fresh-build.json');assert len(fresh)==1946 and {k for k in set(fresh)|set(sources) if fresh.get(k)!=sources.get(k)}=={'scripts/python-test-inventory.v1.json'}
assert fresh['scripts/python-test-inventory.v1.json']==image(O/'inventory-reviewed.json')
u=load(N/'upfront.json');r=load(N/'result.json');assert all(r[k]==v for k,v in u.items())
assert r['exit_code']==0 and r['owned_leader_reaped'] is True and r['owned_group_after']=='GONE' and r['cleanup']==[]
assert r['log_bytes']==(N/'rust.log').stat().st_size and r['log_sha256']==sha(N/'rust.log') and r['wrapper_sha256']==sha(N/'executed-wrapper.py') and r['tool_sha256']==sha(Path(r['tool']))
assert 'RUST_TEST_THREADS' not in r['environment'] and r['environment']['CARGO_BUILD_JOBS']=='2'
text=(N/'rust.log').read_text();markers=list(re.finditer(r'^\$ (.+)$',text,re.M));argvs=[shlex.split(m[1]) for m in markers]
registry=next(s for s in load(R/'scripts/verification-suites.json')['suites'] if s['id']=='rust')['commands']
assert len(registry)==15 and len(argvs)==17 and argvs[0]==['uv','run','python','scripts/verify.py','--suite','rust']
nested=shlex.split(load(R/'apps/desktop/package.json')['scripts']['build']);assert nested==['vite','build','--config','vite.desktop.config.ts'] and argvs.count(nested)==1
nested_index=argvs.index(nested);assert argvs[nested_index-1]==['pnpm','--filter','@japp/desktop','build']
assert [a for a in argvs[1:] if a!=nested]==registry
summaries=[];catalogs=[];physical=[]
for i,m in enumerate(markers):
 if i==0:continue
 segment=text[m.end():markers[i+1].start() if i+1<len(markers) else len(text)];argv=argvs[i]
 summary=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',segment)
 assert all(set(s[1:])=={'0'} for s in summary)
 if argv[:2]==['cargo','test'] and 'apps/desktop/src-tauri/Cargo.toml' in argv:
  names=re.findall(r'^test (\S+) \.\.\. ok$',segment,re.M)
  assert len(names)==len(set(names))==232 and summary==[('232','0','0','0','0'),('0','0','0','0','0'),('0','0','0','0','0')]
  catalogs.append(names);physical+=re.findall(r'Running unittests \S+ \((apps/desktop/src-tauri/target/debug/deps/[^)]+)\)',segment)
 summaries.append({'argv':argv,'passed_summary_counts':[int(s[0]) for s in summary]})
assert len(catalogs)==3 and set(catalogs[0])==set(catalogs[1])==set(catalogs[2]) and len(physical)==6
assert re.search(r'^rust\s+ACTIVE\s+PASS\s*$',text,re.M) and 'verification exit code: 0' in text
put('derived-focus-data.json',{'python_commands':commands,'affected_python_passed':112,'affected_pytest_seconds':2.83,'actual_collection':1801,'inventory':{'old_common':1687,'new_common':1799,'added':112,'removed':0,'old_ten_windows_cases_preserved':True,'posix_exact':posix,'inventory_sha256':sha(O/'inventory-reviewed.json'),'platform_arithmetic':'Mac/Linux1801; Windows1799 is a loader projection, not foreign execution'},'native':{'registered_commands':15,'raw_command_traces':17,'extra_traces':'outer verifier and exact nested Vite build','all_registered_argv_exact':True,'outer_exit_code':0,'elapsed_seconds':r['elapsed_seconds'],'desktop_three_modes_passed_each':232,'three_actual_PASS_sets_unique_and_equal':True,'ignored_failed_filtered_each':0,'parallel_scope':'No RUST_TEST_THREADS; ordinary default test parallelism, Cargo jobs2','source1946_unchanged':True,'oldruntime40_closed_prepost_equal':True,'owned_leader_reaped':True,'owned_group_after':'GONE','escaped_descendants':'UNOBSERVED','physical_paths_in_closed_log':physical,'physical_image_timing':'No upfront physical image map; later retention is POST_EXECUTION without execution-byte-equality claim','command_summaries':summaries}})
put('native-passed-identities.json',{'scope':'Actual raw PASS lines from each of three closed Mac commands','count_each':232,'all_three_sets_equal':True,'names':sorted(catalogs[0])})
inputs=[]
for d in [P,N]:
 for f in sorted(d.iterdir()):
  if f.is_file():inputs.append({'path':str(f),**image(f)})
for f in [B/'inventory-before.json',B/'inventory-update.json',B/'source-after.json',B/'source-for-fresh-build.json',Path('/tmp/japp-m03-w06-w08-current-adoption-preparation-20261019/expected-python-additions.json')]:inputs.append({'path':str(f),**image(f)})
put('input-bindings.json',inputs)
put('findings.json',{'decision':'CLEAR_WITHIN_CLOSED_FOCUS_DATA_SCOPE','actionable_findings':[],'actual':{'source_files':1946,'python_focus_commands0':6,'affected_package_tests_passed':112,'canonical_unique_collection':1801,'inventory_common':1799,'POSIX_only':2,'added112_no_removals':True,'Windows10_preserved':True,'native_registered_commands0':15,'same_desktop232_PASS_each3':True,'runtime40_closed_prepost_unchanged':True},'limitations':['No product imports, tests, builds, native actors or canonical writes by reviewer','Collection1801 is not1801Python executed PASS;112affected tests only','All15Rust commands/232each3 are Mac ordinary parallel regression scope, not whole20/GUI/foreign package validation','No upfront physical test images in focus; later COW retention is post-execution only','Closed runtime40 snapshot is not a live freeze after the fresh builder replaces stage','No fresh package, raw ACK/UI/lifecycle/platform/milestone acceptance inferred'],'audit_parser_preparation_failure':'audit-v1-failure.json; fixed exact nested Vite trace handling, no product reruns'})
(O/'REVIEW.md').write_text('Closed focus data CLEAR. Six Python focus commands have exact upfront/result/log/tool joins and zero exits;112 affected package tests passed in2.83s and canonical collection produced1801 unique IDs. Inventory adds exactly those112, preserves all1687 prior common IDs including ten Windows correction cases and exact two POSIX IDs, and matches the declared digest. Only inventory bytes differ between the closed1946-source focus and the subsequent fresh-build source pin.\n\nThe Rust log contains all15 registered commands, all zero, with the same232 unique desktop PASS identities in each of three modes, no ignored/failed/filtered tests, ordinary default test parallelism and two Cargo jobs. Closed source1946/runtime40 maps match before/after; the owned leader/group receipt is closed. No upfront physical test image map exists in this focus; later retention remains post-execution. The audit v1 parser failure (one nested Vite command trace) is preserved and corrected without product reruns.\n\nThis review ran no product imports/tests/builds/actors/root writes. It grants no whole20, fresh package, GUI/lifecycle, foreign-host or milestone acceptance; old closed runtime40 is not a live freeze during fresh build.\n')
print(json.dumps({'findings':image(O/'findings.json'),'review':image(O/'REVIEW.md'),'source':1946,'affected_python_passed':112,'collection':1801,'native_each_mode':232,'registered_native_commands':15},indent=2))
