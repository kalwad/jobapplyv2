"""Source-only mechanical inspection, with no proposal imports or actors."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re
import shutil

OLD = Path('/tmp/japp-m03-w06-macos-package-lifecycle-preparation-20261019')
SOURCE = Path('/tmp/japp-m03-w06-macos-package-lifecycle-observer-correction-20261019')
OUT=Path(__file__).parent
checks=[]

def sha(data): return hashlib.sha256(data).hexdigest()
def check(name,ok): checks.append({'name':name,'pass':bool(ok)})

old=(OLD/'observer/observe_package.py').read_text()
new=(SOURCE/'observe_package.py').read_text()
check('exact reviewed original observer',sha(old.encode())=='9accb1d936c7d6faa50a2f88a94496cade12de2b2189d267068eb9e2b50c5987')
check('exact corrected observer',sha(new.encode())=='53ed0f5c33bb73de71e0c4660e9388a90640e9b49ff0e94d05cefb873a928526')
expected=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),
             fromfile=str(OLD/'observer/observe_package.py'),tofile=str(SOURCE/'observe_package.py')))
diff=(SOURCE/'observer-correction.diff').read_text()
check('entire exact diff joins retained before/after bytes',expected==diff)
check('exact three manually reviewed hunks',len(re.findall(r'^@@ ',diff,re.M))==3)
module=ast.parse(new)
check('stdlib AST parse only',isinstance(module,ast.Module))
old_module=ast.parse(old)
constants=lambda m:{n.targets[0].id:ast.dump(n.value,include_attributes=False) for n in m.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
check('all module policy bounds unchanged',constants(module)==constants(old_module))
top=lambda m:{n.name:ast.dump(n,include_attributes=False) for n in m.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name!='observe'}
check('all top-level helpers outside observe exact AST',top(module)==top(old_module))
manifest=json.loads((SOURCE/'retention-manifest.json').read_text())
for row in manifest['files']:
    p=Path(row['path'])
    if not p.is_absolute(): p=SOURCE/p
    data=p.read_bytes()
    check('correction payload binding '+p.name,len(data)==row['bytes'] and sha(data)==row['sha256'])
check('correction exact three payload files',len(manifest['files'])==3)
for row in json.loads((OLD/'retention-manifest.json').read_text())['files']:
    data=Path(row['path']).read_bytes()
    check('original packet remains exact '+Path(row['path']).name,len(data)==row['bytes'] and sha(data)==row['sha256'])
check('original manifest remains exact',sha((OLD/'retention-manifest.json').read_bytes())=='da51afed171c942e7e828c6fccf5ed8718eb3682d395607df4499a75cb73145e')
source_lines=new.splitlines()
kill_index=next(i for i,line in enumerate(source_lines) if 'os.kill(service.pid, signal.SIGKILL)' in line)
check('no hash or output between final deadline and signal',source_lines[kill_index-2].strip()=='if time.monotonic() >= deadline:' and 'raise ValueError' in source_lines[kill_index-1])
check('fresh app identity follows intent receipt',new.index('emit("BEFORE_OWNED_SERVICE_CRASH"')<new.index('current_app = probe.identity(app.pid)',new.index('elif command == "crash-service"')))
check('post-sample cutoff precedes success branches','current, port = sample()\n            if time.monotonic() >= until:\n                raise ValueError("Declared observation deadline exceeded after sample: " + kind)\n' in new)
check('exit checks cutoff before receipt','observed_at = time.monotonic()\n                if observed_at >= until:\n                    raise ValueError("Declared observation deadline exceeded after exit checks")\n                emit("REGISTERED_EXIT_OBSERVED"' in new)
snapshot=OUT/'reviewed-correction'
snapshot.mkdir()
for path in sorted(SOURCE.iterdir()):
    if not path.is_file() or path.is_symlink(): raise ValueError('Unexpected correction member')
    shutil.copyfile(path,snapshot/path.name)
    if path.read_bytes()!=(snapshot/path.name).read_bytes(): raise ValueError('Copy drift')
result={'scope':'Bounded independent source-only review; no proposal import, tests or native actors',
        'checks':checks,'passed':sum(c['pass'] for c in checks),'total':len(checks),'findings':[],
        'closed_prior_findings':['W06_OBSERVER_001','W06_OBSERVER_002'],
        'remaining_limits':['Numeric PID revalidation and signaling are not atomic','No native runtime/GUI/LaunchServices/ACK/build acceptance','Future actual current head/source/package/outer runner must be bound before execution']}
(OUT/'findings.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':result['passed'],'total':result['total'],'all_pass':all(c['pass'] for c in checks)}))
