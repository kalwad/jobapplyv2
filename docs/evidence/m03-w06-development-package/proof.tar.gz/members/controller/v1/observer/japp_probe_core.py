"""Pure ownership and timing rules for the explicitly test-only native observer."""

from __future__ import annotations

import subprocess
from contextlib import suppress
from dataclasses import asdict, dataclass
from typing import Protocol

MAX_BOUND = 30
MAX_PORT = 65535
ZOMBIE_STATUS = 5
KILLED_EXIT = -9


@dataclass(frozen=True, slots=True)
class Identity:
    pid: int
    ppid: int
    pgid: int
    start_seconds: int
    start_microseconds: int
    executable: str
    status: int = 2


class Child(Protocol):
    pid: int

    def poll(self) -> int | None: ...
    def kill(self) -> None: ...
    def wait(self, timeout: float) -> int: ...


class Probe(Protocol):
    def identity(self, pid: int) -> Identity | None: ...
    def present(self, pid: int) -> bool: ...
    def group_present(self, pgid: int) -> bool: ...
    def socket_closed(self, port: int) -> bool: ...


class Clock(Protocol):
    def now(self) -> float: ...
    def pause(self, seconds: float) -> None: ...


def same_process(saved: Identity, current: Identity | None) -> bool:
    return current is not None and (
        saved.pid,
        saved.pgid,
        saved.start_seconds,
        saved.start_microseconds,
        saved.executable,
    ) == (
        current.pid,
        current.pgid,
        current.start_seconds,
        current.start_microseconds,
        current.executable,
    )


def absence(
    app: Identity, service: Identity, port: int, probe: Probe
) -> dict[str, bool]:
    return {
        "app_pid_absent": not probe.present(app.pid),
        "service_pid_absent": not probe.present(service.pid),
        "service_group_absent": not probe.group_present(service.pgid),
        "listener_closed": probe.socket_closed(port),
    }


def force_owned_parent(  # noqa: PLR0913, PLR0917 - explicit injected ownership/timing boundary.
    child: Child,
    app: Identity,
    service: Identity,
    port: int,
    probe: Probe,
    clock: Clock,
    seconds: float,
) -> dict[str, object]:
    if not 0 < seconds <= MAX_BOUND or not 0 < port <= MAX_PORT:
        raise ValueError("Invalid declared observation bound")
    started = clock.now()
    deadline = started + seconds
    current = probe.identity(app.pid)
    if (
        child.pid != app.pid
        or child.poll() is not None
        or not same_process(app, current)
        or current is None
        or current.status == ZOMBIE_STATUS
        or clock.now() >= deadline
    ):
        raise ValueError("Owned app identity no longer authorizes forcekill")
    child.kill()
    signalled = clock.now()
    code: int | None = None
    wait_started = clock.now()
    with suppress(subprocess.TimeoutExpired):
        remaining = deadline - clock.now()
        if remaining > 0:
            code = child.wait(timeout=min(2.0, remaining))
    wait_finished = clock.now()
    observations: list[dict[str, object]] = []
    observed = absence(app, service, port, probe)
    while True:
        observations.append({"monotonic": clock.now(), **observed})
        if all(observed.values()) or clock.now() >= deadline:
            break
        clock.pause(min(0.05, deadline - clock.now()))
        observed = absence(app, service, port, probe)
    return {
        "before_signal_monotonic": started,
        "after_signal_monotonic": signalled,
        "parent_wait_started": wait_started,
        "parent_wait_finished": wait_finished,
        "parent_wait_included": True,
        "parent_exit_code": code,
        "elapsed_ms": (clock.now() - started) * 1000,
        "declared_bound_seconds": seconds,
        "observations": observations,
        "pass": code == KILLED_EXIT
        and all(observed.values())
        and clock.now() <= deadline,
        "app_identity": asdict(app),
        "service_identity": asdict(service),
        "port": port,
    }
