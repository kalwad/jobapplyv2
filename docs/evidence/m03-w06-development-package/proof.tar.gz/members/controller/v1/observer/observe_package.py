"""UNINVOKED W06 passive native observer; root performs all GUI/launch actions.

Only crash-service can signal: one saved, UID/birth/path-bound immediate service
child. Never forces an observed app PID, reads IPC/token state or launches an app.
Owned forced-parent proof reuses the separately retained W03 Popen controller.
"""
from __future__ import annotations

import argparse
import ctypes
import errno
import hashlib
import http.client
import json
import os
import selectors
import signal
import socket
import sys
import time
from dataclasses import asdict
from pathlib import Path

from japp_mac_probe import BsdInfo, MacProbe
from japp_probe_core import Identity, same_process
from macos_package import inventory

REQUIRED = {"main", "service", "runtime_manifest", "package_tree", "source_manifest",
            "static_report", "build_report", "python", "lsof", "launch_receipt"}
MAX_INPUT = 512 * 1024 * 1024
CASE_SECONDS = 180
# Three bind attempts per initial/startup and at most two automatic replacements.
# A PID is an observed process identity, not an observed private generation field.
MAX_SERVICE_IDENTITIES = 9


def digest(path: Path, deadline: float | None = None) -> str:
    deadline = deadline if deadline is not None else time.monotonic() + 30
    before = path.lstat()
    if path.is_symlink() or not path.is_file() or before.st_size > MAX_INPUT:
        raise ValueError("Bound regular file required")
    h = hashlib.sha256()
    with path.open("rb") as source:
        opened = os.fstat(source.fileno())
        if (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino):
            raise ValueError("Input replaced before read")
        total = 0
        while data := source.read(16384):
            total += len(data)
            if total > before.st_size or time.monotonic() >= deadline:
                raise ValueError("Input grew while bound")
            h.update(data)
        after = os.fstat(source.fileno())
    final = path.lstat()
    if any((s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns) !=
           (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
           for s in (after, final)) or total != before.st_size:
        raise ValueError("Input changed while bound")
    return h.hexdigest()


def validate(config: dict[str, object]) -> list[dict[str, object]]:
    deadline = time.monotonic() + 60
    if config.get("schema") != "W06_MAC_PASSIVE_OBSERVER_V1":
        raise ValueError("Actual source-bound config required; template is not executable")
    bound = config["bindings"]
    if not isinstance(bound, dict) or set(bound) != REQUIRED:
        raise ValueError("Exact input roles required")
    for row in bound.values():
        if not isinstance(row, dict) or set(row) != {"original", "retained", "sha256"}:
            raise ValueError("Original/upfront-copy/hash required")
        for name in ("original", "retained"):
            path = Path(row[name])
            if not path.is_absolute() or digest(path, deadline) != row["sha256"]:
                raise ValueError("Actual input/upfront bytes differ")
    if Path(sys.executable).resolve() != Path(bound["python"]["original"]).resolve():
        raise ValueError("Interpreter differs from bound image")
    if bound["lsof"]["original"] != "/usr/sbin/lsof":
        raise ValueError("Observer lsof path differs")
    bundle, upfront = Path(config["app_bundle"]), Path(config["upfront_bundle"])
    if bundle == upfront:
        raise ValueError("Distinct actual and upfront app images required")
    expected = json.loads(Path(bound["package_tree"]["original"]).read_text())
    actual = inventory(bundle)
    if actual != expected or inventory(upfront) != expected:
        raise ValueError("Actual whole bundle differs from upfront package tree")
    if time.monotonic() >= deadline:
        raise ValueError("Whole input verification deadline exceeded")
    for role in ("main", "service", "runtime_manifest"):
        original = Path(bound[role]["original"])
        retained = Path(bound[role]["retained"])
        if original.relative_to(bundle) != retained.relative_to(upfront):
            raise ValueError("Bound runtime/main is not at the same upfront bundle path")
    return actual


def owned_uid(probe: MacProbe, saved: Identity) -> bool:
    info = BsdInfo()
    count = probe.lib.proc_pidinfo(saved.pid, 3, 0, ctypes.byref(info), ctypes.sizeof(info))
    return (count == ctypes.sizeof(info) and info.pid == saved.pid
            and (info.start_seconds, info.start_microseconds) ==
            (saved.start_seconds, saved.start_microseconds) and info.uid == os.getuid())


def observe(config_path: Path, output: Path) -> None:
    if not output.is_absolute() or output.exists():
        raise ValueError("Fresh absolute case directory required")
    raw = config_path.read_bytes()
    if len(raw) > 1024 * 1024:
        raise ValueError("Config exceeds bound")
    config = json.loads(raw)
    actual_tree = validate(config)  # BEFORE native observer construction or lsof.
    bound = config["bindings"]
    output.mkdir(mode=0o700)
    (output / "config.executed.json").write_bytes(raw)
    own_sources = {p.name: digest(p) for p in Path(__file__).parent.glob("*.py")}
    (output / "upfront.json").write_text(json.dumps({
        "source_files": own_sources, "input_bindings": bound,
        "package_tree": actual_tree, "argv": sys.argv,
        "environment": {"observer_tools": {"PATH": "/usr/bin:/bin"}},
        "scope": "No app launch/GUI/private IPC or credential access",
        "limits": {"case_seconds": CASE_SECONDS, "service_identities": MAX_SERVICE_IDENTITIES,
                   "explicit_service_crash_commands": 3},
    }, indent=2) + "\n")
    probe = MacProbe()
    app = probe.identity(config["app_pid"])
    if app is None or app.executable != bound["main"]["original"] or not owned_uid(probe, app):
        raise ValueError("Registered actual native launch identity differs")
    started = time.monotonic()
    deadline = started + CASE_SECONDS
    services: list[Identity] = []
    other_children: dict[int, Identity] = {}
    ports: set[int] = set()
    sequence = 0
    crash_commands = 0
    armed_at: float | None = None
    events = (output / "events.jsonl").open("x")

    def emit(kind: str, value: object) -> None:
        nonlocal sequence
        sequence += 1
        if sequence > 4096 or events.tell() > 32 * 1024 * 1024:
            raise ValueError("Observer receipt bound exceeded")
        row = {"sequence": sequence, "kind": kind, "utc_ns": time.time_ns(),
               "monotonic": time.monotonic(), "data": value}
        text = json.dumps(row)
        events.write(text + "\n")
        events.flush()
        sys.stdout.write(text + "\n")
        sys.stdout.flush()

    def sample() -> tuple[Identity | None, int | None]:
        current_app = probe.identity(app.pid)
        matches: list[Identity] = []
        if current_app is not None:
            if not same_process(app, current_app) or not owned_uid(probe, app):
                raise ValueError("App PID was reused or identity changed")
            for pid in probe.children(app.pid):
                child = probe.identity(pid)
                if child is None:
                    continue
                if child.executable == bound["service"]["original"]:
                    if child.ppid != app.pid or child.pgid != child.pid or not owned_uid(probe, child):
                        raise ValueError("Service parent/group/UID mismatch")
                    matches.append(child)
                    if not any(same_process(child, saved) for saved in services):
                        if len(services) >= MAX_SERVICE_IDENTITIES:
                            raise ValueError("Observed service identity inventory exceeds bound")
                        services.append(child)
                        emit("NEW_SERVICE_IDENTITY", asdict(child))
                else:
                    if len(other_children) >= 512:
                        raise ValueError("Observed child inventory exceeds bound")
                    other_children[child.pid] = child
            if len(matches) > 1:
                raise ValueError("Concurrent exact service children observed")
        listener = None
        current = matches[0] if matches else None
        if current is not None:
            listener = probe.listener(current.pid, output / f"listener-{sequence + 1}.stdout")
            if listener is not None:
                ports.add(listener)
        emit("SAMPLE", {"app_present": current_app is not None,
            "current_service": asdict(current) if current else None, "port": listener,
            "registered_services": [{"saved": asdict(saved),
                "same_process_present": same_process(saved, probe.identity(saved.pid)),
                "numeric_pid_present": probe.present(saved.pid),
                "group_present": probe.group_present(saved.pgid)} for saved in services],
            "observed_other_children": [asdict(v) for v in other_children.values()],
            "ports_closed": {str(p): probe.socket_closed(p) for p in ports},
            "unobserved_descendants": "UNOBSERVED"})
        return current, listener

    def wait_for(kind: str, seconds: float, anchor: float | None = None) -> None:
        wait_started = anchor if anchor is not None else time.monotonic()
        if wait_started + seconds > deadline or time.monotonic() >= wait_started + seconds:
            raise ValueError("Insufficient remaining case budget for full observation window")
        until = wait_started + seconds
        previous_count = len(services)
        while time.monotonic() < until:
            current, port = sample()
            if time.monotonic() >= until:
                raise ValueError("Declared observation deadline exceeded after sample: " + kind)
            if kind == "terminal" and len(services) != previous_count:
                raise ValueError("Replacement observed during terminal window")
            if kind == "listener" and current is not None and port is not None:
                return
            if kind == "replacement" and len(services) > previous_count and port is not None:
                return
            if kind == "exit" and not probe.present(app.pid) and all(
                not probe.present(s.pid) and not probe.group_present(s.pgid) for s in services
            ) and all(not probe.present(s.pid) for s in other_children.values()) and all(
                probe.socket_closed(p) for p in ports
            ):
                observed_at = time.monotonic()
                if observed_at >= until:
                    raise ValueError("Declared observation deadline exceeded after exit checks")
                emit("REGISTERED_EXIT_OBSERVED", {"bound_seconds": seconds,
                    "elapsed_seconds": observed_at - wait_started,
                    "scope": "Only registered identities/groups/ports; not unseen descendants"})
                return
            time.sleep(min(0.1, max(0, until - time.monotonic())))
        if kind != "terminal":
            raise ValueError("Declared observation deadline exceeded: " + kind)
        if any(probe.present(saved.pid) for saved in services):
            raise ValueError("Registered service remains at terminal window end")
        emit("NO_REPLACEMENT_SEEN", {"seconds": seconds,
            "elapsed_seconds": time.monotonic() - wait_started,
            "scope": "Sampled interval, not a complete OS spawn trace"})

    try:
        emit("APP_IDENTITY", asdict(app))
        wait_for("listener", 20)
        reader = selectors.DefaultSelector()
        reader.register(sys.stdin, selectors.EVENT_READ)
        with reader:
            while time.monotonic() < deadline:
                if not reader.select(min(0.1, max(0, deadline - time.monotonic()))):
                    continue
                command = sys.stdin.readline().strip()
                if not command:
                    raise ValueError("Control stream closed before explicit finish")
                emit("ROOT_COMMAND", command)
                if command == "sample":
                    sample()
                elif command in {"arm-close", "arm-quit"}:
                    armed_at = time.monotonic()
                    emit("GUI_ACTION_ARMED", {"action": command, "GUI_action": "ROOT_REQUIRED",
                        "armed_monotonic": armed_at})
                elif command == "wait-exit":
                    if armed_at is None:
                        raise ValueError("Native action must be armed before teardown observation")
                    wait_for("exit", 12, armed_at)
                elif command == "wait-replacement":
                    wait_for("replacement", 30)
                elif command == "observe-terminal":
                    wait_for("terminal", 30)
                elif command == "crash-service":
                    if crash_commands >= 3:
                        raise ValueError("Three declared service-loss injections already used")
                    service, _port = sample()
                    if service is None or digest(Path(service.executable)) != bound["service"]["sha256"]:
                        raise ValueError("Bound service bytes no longer authorize injection")
                    emit("BEFORE_OWNED_SERVICE_CRASH", asdict(service))
                    current_app = probe.identity(app.pid)
                    current = probe.identity(service.pid)
                    if current is None or current.ppid != app.pid or not (
                        same_process(app, current_app) and owned_uid(probe, app)
                        and same_process(service, current) and owned_uid(probe, service)
                    ):
                        raise ValueError("Saved service identity no longer authorizes injection")
                    if time.monotonic() >= deadline:
                        raise ValueError("Case deadline no longer authorizes injection")
                    os.kill(service.pid, signal.SIGKILL)
                    crash_commands += 1
                    emit("OWNED_SERVICE_CRASH_SENT", {"pid": service.pid})
                elif command == "unauthorized":
                    service, port = sample()
                    if service is None or port is None:
                        raise ValueError("Owned listener required for negative HTTP probe")
                    for path in ("/health", "/ready", "/version"):
                        for wrong in (False, True):
                            connection = http.client.HTTPConnection("127.0.0.1", port, timeout=0.5)
                            try:
                                headers = {"Authorization": "Bearer synthetic-wrong-token"} if wrong else {}
                                connection.request("GET", path, headers=headers)
                                response = connection.getresponse()
                                body = response.read(8193)
                                emit("HTTP_NEGATIVE", {"pid": service.pid, "port": port,
                                    "path": path, "credential_mode": "synthetic_wrong" if wrong else "absent",
                                    "status": response.status, "body_bytes": len(body),
                                    "body_sha256": hashlib.sha256(body).hexdigest()})
                                if len(body) > 8192 or response.status != 401:
                                    raise ValueError("Unauthenticated boundary did not reject within bound")
                            finally:
                                connection.close()
                    if not same_process(service, probe.identity(service.pid)):
                        raise ValueError("Service changed during negative HTTP observation")
                elif command == "port-exclusive":
                    service, port = sample()
                    if service is None or port is None:
                        raise ValueError("Saved listener required for exclusive-bind observation")
                    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as owned_socket:
                        try:
                            owned_socket.bind(("127.0.0.1", port))
                        except OSError as error:
                            if error.errno != errno.EADDRINUSE:
                                raise
                            emit("LISTENER_EXCLUSIVE_BIND", {"port": port, "errno": error.errno,
                                "scope": "Existing listener exclusivity, not allocator collision retry"})
                        else:
                            raise ValueError("Declared listener did not retain exclusive port ownership")
                    if not same_process(service, probe.identity(service.pid)):
                        raise ValueError("Service changed during exclusive-bind observation")
                elif command == "port-released":
                    if probe.present(app.pid) or any(probe.present(s.pid) for s in services):
                        raise ValueError("Registered app/service must be absent before port rebind")
                    for port in sorted(ports):
                        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as owned_socket:
                            owned_socket.bind(("127.0.0.1", port))
                        emit("CLOSED_PORT_REBOUND_AND_RELEASED", {"port": port,
                            "scope": "Owned non-listening socket; no foreign listener termination"})
                elif command == "finish":
                    final = sample()
                    validate(config)
                    emit("OBSERVATION_CLOSED", {"current_service_present": final[0] is not None,
                        "GUI": "SEPARATE_ROOT_EVIDENCE_REQUIRED", "raw_ACK": "UNOBSERVED",
                        "authenticated_positive_HTTP": "SEPARATE_NATIVE_UI_ENGINE_RESULT_REQUIRED",
                        "case_acceptance": "NOT_DECIDED_BY_OBSERVER"})
                    return
                else:
                    raise ValueError("Unknown fixed observer command")
        raise ValueError("Whole observer deadline exceeded")
    except BaseException as error:
        emit("OBSERVATION_INCOMPLETE", {"type": type(error).__name__, "detail": str(error),
            "root_native_UI_teardown_required": True})
        raise
    finally:
        events.close()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    observe(args.config, args.output)


if __name__ == "__main__":
    main()
