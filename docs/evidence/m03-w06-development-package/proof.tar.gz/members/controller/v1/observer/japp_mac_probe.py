"""Read-only macOS process and socket observations for retained test identities."""

from __future__ import annotations

import ctypes
import errno
import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

from japp_probe_core import Identity

MAX_CHILDREN = 512
BSD_INFO_SIZE = 136
MAX_PORT = 65535


class BsdInfo(ctypes.Structure):
    _fields_ = [
        ("flags", ctypes.c_uint32),
        ("status", ctypes.c_uint32),
        ("xstatus", ctypes.c_uint32),
        ("pid", ctypes.c_uint32),
        ("ppid", ctypes.c_uint32),
        ("uid", ctypes.c_uint32),
        ("gid", ctypes.c_uint32),
        ("ruid", ctypes.c_uint32),
        ("rgid", ctypes.c_uint32),
        ("svuid", ctypes.c_uint32),
        ("svgid", ctypes.c_uint32),
        ("reserved", ctypes.c_uint32),
        ("comm", ctypes.c_char * 16),
        ("name", ctypes.c_char * 32),
        ("nfiles", ctypes.c_uint32),
        ("pgid", ctypes.c_uint32),
        ("jobc", ctypes.c_uint32),
        ("tdev", ctypes.c_uint32),
        ("tpgid", ctypes.c_uint32),
        ("nice", ctypes.c_int32),
        ("start_seconds", ctypes.c_uint64),
        ("start_microseconds", ctypes.c_uint64),
    ]


def loopback_listener(stdout: str, pid: int) -> int | None:
    owners = [line[1:] for line in stdout.splitlines() if line.startswith("p")]
    if not owners and not stdout:
        return None
    if owners != [str(pid)]:
        raise ValueError("Listener observation does not match saved service PID")
    ports: set[int] = set()
    for line in stdout.splitlines():
        if not line.startswith("n"):
            continue
        host, separator, raw_port = line[1:].rpartition(":")
        if not separator or host != "127.0.0.1" or not raw_port.isdecimal():
            raise ValueError("Service listener is not exact IPv4 loopback")
        port = int(raw_port)
        if not 0 < port <= MAX_PORT:
            raise ValueError("Invalid listener port")
        ports.add(port)
    if len(ports) != 1:
        raise ValueError("Service listener is absent or ambiguous")
    return ports.pop()


class MacProbe:
    def __init__(self) -> None:
        if sys.platform != "darwin" or ctypes.sizeof(BsdInfo) != BSD_INFO_SIZE:
            raise ValueError("This proof adapter requires the retained macOS ABI")
        self.lib = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True)
        self.lib.proc_pidinfo.argtypes = [
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_uint64,
            ctypes.c_void_p,
            ctypes.c_int,
        ]
        self.lib.proc_pidinfo.restype = ctypes.c_int
        self.lib.proc_pidpath.argtypes = [
            ctypes.c_int,
            ctypes.c_void_p,
            ctypes.c_uint32,
        ]
        self.lib.proc_pidpath.restype = ctypes.c_int
        self.lib.proc_listchildpids.argtypes = [
            ctypes.c_int,
            ctypes.c_void_p,
            ctypes.c_int,
        ]
        self.lib.proc_listchildpids.restype = ctypes.c_int

    def identity(self, pid: int) -> Identity | None:
        if pid <= 0:
            raise ValueError("Positive saved PID required")
        info = BsdInfo()
        ctypes.set_errno(0)
        count = int(
            self.lib.proc_pidinfo(pid, 3, 0, ctypes.byref(info), ctypes.sizeof(info))
        )
        if count == 0 and ctypes.get_errno() in {errno.ESRCH, errno.ENOENT}:
            return None
        if count != ctypes.sizeof(info) or int(info.pid) != pid:
            if not self.present(pid):
                return None
            raise ValueError("Saved process identity could not be observed")
        path = ctypes.create_string_buffer(4096)
        if int(self.lib.proc_pidpath(pid, path, len(path))) <= 0:
            if not self.present(pid):
                return None
            raise ValueError("Saved executable identity could not be observed")
        executable = path.value.decode("utf-8", "strict")
        return Identity(
            pid,
            int(info.ppid),
            int(info.pgid),
            int(info.start_seconds),
            int(info.start_microseconds),
            executable,
            int(info.status),
        )

    def children(self, pid: int) -> list[int]:
        buffer = (ctypes.c_int * MAX_CHILDREN)()
        count = int(self.lib.proc_listchildpids(pid, buffer, ctypes.sizeof(buffer)))
        # Apple's wrapper returns a PID count, not a byte count.
        if count < 0 or count >= MAX_CHILDREN:
            raise ValueError("Child identity inventory unavailable or exceeds bound")
        return [int(buffer[index]) for index in range(count) if buffer[index] > 0]

    def present(self, pid: int) -> bool:
        if pid <= 0:
            raise ValueError("Positive saved PID required")
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
        return True

    def group_present(self, pgid: int) -> bool:
        if pgid <= 0:
            raise ValueError("Positive saved group required")
        try:
            os.killpg(pgid, 0)
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
        return True

    def socket_closed(self, port: int) -> bool:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as connection:
            connection.settimeout(0.1)
            return connection.connect_ex(("127.0.0.1", port)) == errno.ECONNREFUSED

    def listener(self, pid: int, output: Path) -> int | None:
        argv = [
            "/usr/sbin/lsof",
            "-nP",
            "-a",
            "-p",
            str(pid),
            "-iTCP",
            "-sTCP:LISTEN",
            "-F",
            "pn",
        ]
        receipt = output.with_suffix(".command.json")
        with receipt.open("x") as retained:
            retained.write(
                json.dumps(
                    {
                        "argv": argv,
                        "monotonic_before": time.monotonic(),
                        "utc_ns": time.time_ns(),
                    }
                )
                + "\n"
            )
        command = subprocess.run(  # noqa: S603 - fixed read-only lsof on saved PID.
            argv,
            capture_output=True,
            timeout=2,
            check=False,
            env={"PATH": "/usr/bin:/bin"},
        )
        with output.open("xb") as retained_stdout:
            retained_stdout.write(command.stdout)
        with output.with_suffix(output.suffix + ".stderr").open(
            "xb"
        ) as retained_stderr:
            retained_stderr.write(command.stderr)
        with receipt.with_suffix(".result.json").open("x") as retained_result:
            retained_result.write(
                json.dumps(
                    {
                        "returncode": command.returncode,
                        "monotonic_after": time.monotonic(),
                        "utc_ns": time.time_ns(),
                    }
                )
                + "\n"
            )
        if command.returncode == 1 and not command.stdout:
            return None
        if command.returncode != 0:
            raise ValueError("Owned listener observation failed")
        return loopback_listener(command.stdout.decode("utf-8", "strict"), pid)


class RealClock:
    def now(self) -> float:
        return time.monotonic()

    def pause(self, seconds: float) -> None:
        time.sleep(seconds)
