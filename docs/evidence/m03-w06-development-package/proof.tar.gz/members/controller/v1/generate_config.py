"""Filesystem-only configuration generation for a future released case.

Reads actual supplied pins; creates no app/service/tool process. Null template
inputs refuse. Hashes are bindings to supplied observations, not new build facts.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import stat
import time
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROLES={"main","service","runtime_manifest","source_manifest","static_report","build_report","python","lsof","git"}
DIRECTORIES=("source_root","canonical_root","app_bundle","upfront_bundle","staged_runtime")
DEADLINE=None


def digest(path: Path) -> str:
    if DEADLINE is None or time.monotonic()>=DEADLINE:
        raise TimeoutError("Configuration binding budget exceeded")
    metadata=path.lstat()
    if not stat.S_ISREG(metadata.st_mode) or metadata.st_size>512*1024*1024:
        raise ValueError("Bound regular input required")
    h=hashlib.sha256()
    with path.open("rb") as f:
        initial=os.fstat(f.fileno())
        if (initial.st_dev,initial.st_ino)!=(metadata.st_dev,metadata.st_ino):
            raise ValueError("Input replaced")
        for chunk in iter(lambda:f.read(65536),b""):
            if time.monotonic()>=DEADLINE:
                raise TimeoutError("Configuration binding budget exceeded")
            h.update(chunk)
        final=os.fstat(f.fileno())
    stable=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns)
    if stable(metadata)!=stable(final) or stable(metadata)!=stable(path.lstat()):
        raise ValueError("Input changed")
    return h.hexdigest()


def main() -> None:
    global DEADLINE
    DEADLINE=time.monotonic()+60
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pins",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    raw=args.pins.read_bytes()
    if len(raw)>1024*1024:
        raise ValueError("Actual pins exceed1MiB")
    pins=json.loads(raw)
    if pins.get("schema")!="W06_ACTUAL_PACKAGE_PIN_INPUT_V1" or set(pins["bindings"])!=ROLES:
        raise ValueError("Actual closed pins required; null template refuses")
    if pins.get("reviewed_runner_sha256")!=digest(HERE/"run_case.py"):
        raise ValueError("Exact independently reviewed runner pin required")
    for name in DIRECTORIES:
        p=Path(pins[name])
        if not p.is_absolute() or p.is_symlink() or not p.is_dir():
            raise ValueError("Actual absolute directory required")
    out=args.output
    protected=[HERE,*(Path(pins[n]) for n in DIRECTORIES)]
    if not out.is_absolute() or out.exists() or any(out.resolve().is_relative_to(p.resolve()) for p in protected):
        raise ValueError("Fresh configuration directory outside inputs required")
    bindings={}
    for role,row in pins["bindings"].items():
        if set(row)!={"original","retained"}:
            raise ValueError("Actual original/upfront paths required")
        original,retained=(Path(row[n]) for n in ("original","retained"))
        if not original.is_absolute() or not retained.is_absolute() or original.resolve()==retained.resolve():
            raise ValueError("Distinct absolute paths required")
        observed=digest(original)
        if digest(retained)!=observed:
            raise ValueError("Actual/upfront bytes differ")
        bindings[role]={**row,"sha256":observed}
    report=json.loads(Path(bindings["static_report"]["original"]).read_text())
    if report.get("status")!="PACKAGE_STATIC_INSPECTION_PASS_LIFECYCLE_PENDING":
        raise ValueError("Actual static report required before configuration")
    if not pins.get("expected_head") or not pins.get("expected_tree") or not isinstance(pins.get("expected_status"),str):
        raise ValueError("Actual source head/tree/exact status pins required")
    out.mkdir(mode=0o700)
    (out/"pins.executed.json").write_bytes(raw)
    package_tree=json.dumps(report["files"],indent=2)+"\n"
    for name in ("package-tree.json","package-tree.upfront.json"):
        (out/name).write_text(package_tree,encoding="utf-8")
    bindings["package_tree"]={"original":str(out/"package-tree.json"),"retained":str(out/"package-tree.upfront.json"),"sha256":digest(out/"package-tree.json")}
    config={k:pins[k] for k in (*DIRECTORIES,"case","expected_head","expected_tree","expected_status")}
    config.update(schema="W06_ACTUAL_PACKAGE_CASE_V1",target="aarch64-apple-darwin",bindings=bindings,runner_sha256=digest(HERE/"run_case.py"))
    (out/"case.config.json").write_text(json.dumps(config,indent=2)+"\n",encoding="utf-8")
    (out/"generation.json").write_text(json.dumps({"scope":"FILESYSTEM_ONLY_ACTUAL_PIN_BINDING_NOT_BUILD_EXECUTION", "utc_ns":time.time_ns(),"pins_sha256":hashlib.sha256(raw).hexdigest(),"generator_sha256":digest(Path(__file__).resolve()),"runner_sha256":config["runner_sha256"]},indent=2)+"\n",encoding="utf-8")


if __name__=="__main__":
    main()
