"""Bounded W06 own-package lifecycle controller. SOURCE ONLY until released.

No build, signing, credentials or discovery scans. LS launches/actions belong to
root's actual own-app UI. Only FORCED_PARENT creates an owned app Popen handle.
The outer process owns only its worker; native teardown remains explicit.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import signal
import stat
import subprocess
import sys
import time
from dataclasses import asdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
TOTAL_SECONDS = 360
WORK_SECONDS = 350  # Reserve TERM5/KILL5; neither adds observation credit.
MAX_LOG = 32 * 1024 * 1024
CASES = {"LS_CLOSE", "LS_QUIT", "RESTART_BUDGET", "FORCED_PARENT", "UNICODE_SPACES", "PORT_RELAUNCH"}
ROLES = {"main", "service", "runtime_manifest", "package_tree", "source_manifest",
         "static_report", "build_report", "python", "lsof", "git"}
OBSERVER = {"observe_package.py": "53ed0f5c33bb73de71e0c4660e9388a90640e9b49ff0e94d05cefb873a928526",
            "japp_mac_probe.py": "c6c4264a052473976e95bad9583a40c48eca9b133595e3a7a7576b909d2bcbfb",
            "japp_probe_core.py": "0931af93ff3b5ad61d38b5f46ca366478be32206e97c5946c5e2080e2dac85ee",
            "macos_package.py": "89a1013eef9fad43766d39ec12ed1a157eed9bf10461ab24a6b9952c688b7720"}
FIXED = {"sample", "arm-close", "arm-quit", "wait-exit", "crash-service",
         "wait-replacement", "observe-terminal", "unauthorized", "port-exclusive",
         "port-released", "finish"}
APP_ENV = {"PATH": "/usr/bin:/bin", "LANG": "en_US.UTF-8"}


def write(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def tick(deadline: float) -> None:
    if time.monotonic() >= deadline:
        raise TimeoutError("Unextended outer work deadline exceeded")


def digest(path: Path, deadline: float) -> str:
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_size > 512 * 1024 * 1024:
        raise ValueError("Bound regular file required")
    h = hashlib.sha256()
    total = 0
    with path.open("rb") as stream:
        opened = os.fstat(stream.fileno())
        if (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino):
            raise ValueError("File replaced before read")
        while chunk := stream.read(65536):
            tick(deadline)
            total += len(chunk)
            if total > before.st_size:
                raise ValueError("File grew")
            h.update(chunk)
        after = os.fstat(stream.fileno())
    final = path.lstat()
    identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_mode)
    if total != before.st_size or any(identity(s) != identity(before) for s in (after, final)):
        raise ValueError("File bytes/metadata changed during binding")
    return h.hexdigest()


def bind(row: dict, deadline: float) -> dict:
    if set(row) != {"original", "retained", "sha256"} or len(row["sha256"]) != 64:
        raise ValueError("Exact original/retained/SHA binding required")
    original, retained = Path(row["original"]), Path(row["retained"])
    if not original.is_absolute() or not retained.is_absolute() or original.resolve() == retained.resolve():
        raise ValueError("Distinct absolute original/upfront copy required")
    if any(digest(p, deadline) != row["sha256"] for p in (original, retained)):
        raise ValueError("Bound image/receipt changed")
    return dict(row)


def load_config(path: Path) -> tuple[dict, bytes]:
    if sys.version_info[:3] != (3, 12, 13) or sys.flags.optimize:
        raise ValueError("Ordinary pinned Python3.12.13 required")
    raw = path.read_bytes()
    if len(raw) > 1024 * 1024:
        raise ValueError("Config exceeds1MiB")
    c = json.loads(raw)
    if c.get("schema") != "W06_ACTUAL_PACKAGE_CASE_V1" or c.get("case") not in CASES:
        raise ValueError("Actual closed case config required; template refuses")
    if set(c["bindings"]) != ROLES or c.get("target") != "aarch64-apple-darwin":
        raise ValueError("Exact roles/target required")
    if not c.get("expected_head") or not c.get("expected_tree") or not isinstance(c.get("expected_status"), str):
        raise ValueError("Explicit actual source head/tree/status required")
    if len(c.get("runner_sha256", "")) != 64:
        raise ValueError("Reviewed runner pin required")
    for name in ("source_root", "canonical_root", "app_bundle", "upfront_bundle", "staged_runtime"):
        p = Path(c[name])
        if not p.is_absolute() or p.is_symlink() or not p.is_dir():
            raise ValueError("Actual absolute input directory required: " + name)
    return c, raw


def stop_owned(child: subprocess.Popen | None) -> dict:
    record = {"owned_handle": child is not None, "term": False, "kill": False, "exit": None, "reaped": False}
    if child is None:
        return record
    if child.poll() is None:
        child.terminate()
        record["term"] = True
        try:
            child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            child.kill()
            record["kill"] = True
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                record["wait_failed"] = True
    record["exit"] = child.returncode
    record["reaped"] = child.poll() is not None
    return record


def git_receipt(c: dict, out: Path, label: str, args: list[str], deadline: float) -> str:
    tick(deadline)
    argv = [c["bindings"]["git"]["original"], "--no-optional-locks", "-c", "core.fsmonitor=false", "-C", c["source_root"], *args]
    env = {"PATH": "/usr/bin:/bin", "GIT_OPTIONAL_LOCKS": "0", "GIT_CONFIG_NOSYSTEM": "1",
           "GIT_CONFIG_GLOBAL": "/dev/null"}
    write(out / (label + ".upfront.json"), {"argv": argv, "cwd": str(out), "environment": dict(env)})
    result = subprocess.run(argv, cwd=out, env=dict(env), capture_output=True,
                            timeout=min(10, max(0.001, deadline-time.monotonic())), check=False)
    (out/(label+".stdout")).write_bytes(result.stdout)
    (out/(label+".stderr")).write_bytes(result.stderr)
    write(out/(label+".result.json"), {"exit_code": result.returncode})
    if result.returncode:
        raise ValueError("Bound read-only Git failed")
    return result.stdout.decode("utf-8", "strict")


def verify(c: dict, out: Path, label: str, deadline: float) -> dict:
    if platform.system() != "Darwin" or platform.machine() != "arm64":
        raise ValueError("Actual native Mac arm64 required")
    if digest(Path(__file__).resolve(), deadline) != c["runner_sha256"]:
        raise ValueError("Reviewed runner changed")
    for name, expected in OBSERVER.items():
        if digest(HERE/"observer"/name, deadline) != expected:
            raise ValueError("Reviewed observer/helper changed")
    if {p.name for p in (HERE/"observer").iterdir()} != set(OBSERVER):
        raise ValueError("Unexpected observer input")
    for row in c["bindings"].values():
        bind(row, deadline)
    if Path(sys.executable).resolve() != Path(c["bindings"]["python"]["original"]).resolve():
        raise ValueError("Interpreter differs from pinned actual image")
    if c["bindings"]["lsof"]["original"] != "/usr/sbin/lsof":
        raise ValueError("Fixed OS lsof required")
    head_tree = git_receipt(c, out, label+"-git", ["rev-parse", "HEAD", "HEAD^{tree}"], deadline).splitlines()
    status = git_receipt(c, out, label+"-status", ["status", "--porcelain=v1", "--untracked-files=normal"], deadline)
    if head_tree != [c["expected_head"], c["expected_tree"]] or status != c["expected_status"]:
        raise ValueError("Actual source Git pins/status differ")
    logical = json.loads(Path(c["bindings"]["source_manifest"]["original"]).read_text())
    if isinstance(logical, dict) and "files" not in logical:
        logical = {"files": [{"path": name, **row} for name,row in logical.items()]}
    seen = set()
    source = Path(c["source_root"])
    for row in logical["files"]:
        name = row["path"]
        relative = Path(name)
        if relative.is_absolute() or ".." in relative.parts or name in seen or set(row)!={"path","bytes","sha256"}:
            raise ValueError("Unsafe or duplicate logical source path")
        seen.add(name)
        p = source/relative
        if p.stat().st_size != row["bytes"] or digest(p, deadline) != row["sha256"]:
            raise ValueError("Logical source differs: " + name)
    tracked = set(git_receipt(c, out, label+"-tracked", ["ls-files", "--cached", "--others", "--exclude-standard", "-z"], deadline).rstrip("\0").split("\0"))
    if not seen or tracked != seen:
        raise ValueError("Logical map must exactly cover actual tracked and declared untracked source")
    # Import only the already byte-bound passive helpers. No native probe yet.
    sys.path.insert(0, str(HERE/"observer"))
    from macos_package import inspect_package, inventory
    app, upfront, stage = (Path(c[n]) for n in ("app_bundle", "upfront_bundle", "staged_runtime"))
    expected = json.loads(Path(c["bindings"]["package_tree"]["original"]).read_text())
    package = inspect_package(app, stage, c["bindings"]["runtime_manifest"]["sha256"])
    if package["files"] != expected or inventory(upfront) != expected:
        raise ValueError("Actual/upfront whole app differs from built static tree")
    modes = lambda root: [{"path": p.relative_to(root).as_posix(), "mode": stat.S_IMODE(p.lstat().st_mode)}
                          for p in sorted(root.rglob("*"))]
    app_modes = modes(app)
    if app_modes != modes(upfront):
        raise ValueError("Actual/upfront bundle modes differ")
    report = json.loads(Path(c["bindings"]["static_report"]["original"]).read_text())
    if (report.get("status") != "PACKAGE_STATIC_INSPECTION_PASS_LIFECYCLE_PENDING"
            or report.get("files") != expected or not report.get("bytes_unchanged_during_signature_inspection")
            or report.get("runtime_manifest_sha256") != c["bindings"]["runtime_manifest"]["sha256"]
            or report.get("signature_inspection", {}).get("exit_code") != 0):
        raise ValueError("Actual byte/signature static barrier not passed")
    build = json.loads(Path(c["bindings"]["build_report"]["original"]).read_text())
    if (build.get("schema") != "W06_FRESH_BUILD_BINDINGS_V1" or build.get("head") != c["expected_head"]
            or build.get("tree") != c["expected_tree"] or build.get("source_manifest_sha256") != c["bindings"]["source_manifest"]["sha256"]
            or build.get("target") != c["target"] or build.get("files") != expected
            or build.get("runtime_manifest_sha256") != c["bindings"]["runtime_manifest"]["sha256"]):
        raise ValueError("Fresh actual build/source/runtime/package join differs")
    required = {"contracts-wheel", "orchestrator-wheel", "runtime-build", "tauri-app-build",
                "codesign-display", "codesign-entitlements", "macho-dependencies"}
    if set(build["records"]) != required:
        raise ValueError("Actual closed build/static receipt roles required")
    for role, row in build["records"].items():
        bind(row, deadline)
        receipt = json.loads(Path(row["original"]).read_text())
        if receipt.get("exit_code") != 0 or receipt.get("role") != role:
            raise ValueError("Bound actual build/static receipt did not close successfully")
        if not isinstance(receipt.get("argv"),list) or not receipt["argv"]:
            raise ValueError("Bound actual argv required")
        for stream in ("stdout", "stderr"):
            bind(receipt[stream], deadline)
        refs = receipt.get("actual_upfront_and_result_refs", [])
        if len(refs) < 2 or len(refs) > 64:
            raise ValueError("Original actual command/upfront/result references required")
        for reference in refs:
            bind(reference, deadline)
    if build.get("macho_result") != "ARM64_BUNDLE_OR_APPLE_ROOTS_ONLY":
        raise ValueError("Actual static Mach-O dependency adjudication required")
    for role in ("main", "service", "runtime_manifest"):
        original = Path(c["bindings"][role]["original"])
        retained = Path(c["bindings"][role]["retained"])
        if original.relative_to(app) != retained.relative_to(upfront):
            raise ValueError("Main/runtime paths do not join the upfront app")
    if package["main_executable"] != c["bindings"]["main"]["original"]:
        raise ValueError("Actual Info.plist main differs")
    manifest = json.loads(Path(c["bindings"]["runtime_manifest"]["original"]).read_text())
    if manifest.get("target") != c["target"]:
        raise ValueError("Fresh runtime target differs")
    if c["case"] == "UNICODE_SPACES" and not (" " in str(app) and not str(app).isascii()):
        raise ValueError("Unicode/spaces case requires actual corresponding app path")
    tick(deadline)
    result = {"head": head_tree[0], "tree": head_tree[1], "tracked_count": len(seen),
              "source_modes": [{"path": name, "mode": stat.S_IMODE((source/name).lstat().st_mode)} for name in sorted(seen)],
              "files": expected, "modes": app_modes, "runtime_files": package["runtime_files"],
              "case_acceptance": "NOT_DECIDED", "raw_ACK": "UNOBSERVED"}
    write(out/(label+".json"), result)
    return result


def worker(config_path: Path, out: Path, start: float) -> None:
    c, raw = load_config(config_path)
    deadline = start + WORK_SECONDS
    observer = app_child = None
    status = {"status": "INCOMPLETE", "case_acceptance": "NOT_DECIDED", "raw_ACK": "UNOBSERVED",
              "unobserved_descendants": "UNOBSERVED", "native_UI_teardown_required_on_failure": True}
    events = out/"controller.events.jsonl"
    def emit(kind: str, data: object) -> None:
        with events.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps({"kind": kind, "utc_ns": time.time_ns(), "monotonic": time.monotonic(), "data": data})+"\n")
    try:
        before = verify(c, out, "before", deadline)
        write(out/"config.executed.json", c)
        emit("PREFLIGHT_CLOSED_BEFORE_LAUNCH", {"config_sha256": hashlib.sha256(raw).hexdigest(), "before": before})
        control = out/"control.jsonl"
        control.write_text("", encoding="utf-8")
        from japp_mac_probe import MacProbe, RealClock
        from japp_probe_core import Identity, force_owned_parent, same_process
        from observe_package import owned_uid
        probe = MacProbe()
        registered_at = time.time_ns()
        launch = None
        seen_commands = []
        ui_receipts = []
        def observed_events() -> list[dict]:
            raw_events=(out/"observer/events.jsonl").read_bytes()
            if len(raw_events)>MAX_LOG:
                raise ValueError("Observer event input exceeds bound")
            return [json.loads(line) for line in raw_events.splitlines(keepends=True) if line.endswith(b"\n")]
        if c["case"] == "FORCED_PARENT":
            argv = [c["bindings"]["main"]["original"]]
            write(out/"app.upfront.json", {"argv": argv, "cwd": c["app_bundle"], "environment": dict(APP_ENV)})
            app_child = subprocess.Popen(argv, cwd=c["app_bundle"], env=dict(APP_ENV),
                stdin=subprocess.DEVNULL, stdout=(out/"app.stdout").open("xb"), stderr=(out/"app.stderr").open("xb"), start_new_session=True)
            app = probe.identity(app_child.pid)
            if app is None or app.executable != c["bindings"]["main"]["original"] or not owned_uid(probe, app):
                raise ValueError("Owned app identity unavailable")
            launch = {"schema": "W06_ACTUAL_LAUNCH_V1", "method": "OWNED_POPEN_NOT_LS", "app_pid": app_child.pid,
                      "identity": asdict(app), "registered_utc_ns": registered_at, "upfront": str(out/"app.upfront.json")}
            write(out/"launch.receipt.json", launch)
        else:
            emit("ROOT_LAUNCH_REQUIRED", {"method": "ACTUAL_OWN_APP_LAUNCHSERVICES_GUI", "bundle": c["app_bundle"],
                 "control": str(control), "scope": "No terminal open/exec, Codex screen, CDP or profile workaround"})
        consumed = 0
        observer_started = None
        while True:
            tick(deadline)
            data = control.read_bytes()
            if len(data) > 1024*1024:
                raise ValueError("Control file exceeds1MiB")
            lines = data.splitlines(keepends=True)
            if len(lines) > 64:
                raise ValueError("At most64 fixed control messages")
            if launch is not None and observer is None:
                receipt = out/"launch.receipt.json"
                retained = out/"launch.receipt.upfront.json"
                retained.write_bytes(receipt.read_bytes())
                config = {"schema": "W06_MAC_PASSIVE_OBSERVER_V1", "case_id": c["case"],
                    "app_bundle": c["app_bundle"], "upfront_bundle": c["upfront_bundle"], "app_pid": launch["app_pid"],
                    "bindings": {k:v for k,v in c["bindings"].items() if k != "git"}}
                config["bindings"]["launch_receipt"] = {"original": str(receipt), "retained": str(retained),
                    "sha256": digest(receipt, deadline)}
                write(out/"observer.config.json", config)
                argv = [c["bindings"]["python"]["original"], "-B", str(HERE/"observer/observe_package.py"),
                        "--config", str(out/"observer.config.json"), "--output", str(out/"observer")]
                env = {"PATH": "/usr/bin:/bin", "PYTHONDONTWRITEBYTECODE": "1", "PYTHONNOUSERSITE": "1"}
                write(out/"observer.upfront.json", {"argv": argv, "cwd": str(HERE/"observer"), "environment": dict(env)})
                observer = subprocess.Popen(argv, cwd=HERE/"observer", env=dict(env), stdin=subprocess.PIPE,
                    stdout=(out/"observer.stdout").open("xb"), stderr=(out/"observer.stderr").open("xb"), start_new_session=True)
                observer_started = time.monotonic()
                emit("OWNED_OBSERVER_STARTED", {"pid": observer.pid, "config": str(out/"observer.config.json")})
            for line in lines[consumed:]:
                if not line.endswith(b"\n"):
                    break
                consumed += 1
                if len(line) > 65536:
                    raise ValueError("Control message exceeds bound")
                message = json.loads(line)
                command = message["command"]
                if command == "register-launch":
                    if launch is not None or c["case"] == "FORCED_PARENT":
                        raise ValueError("Launch registration already closed")
                    row = bind(message["receipt"], deadline)
                    launch = json.loads(Path(row["original"]).read_text())
                    if (launch.get("schema") != "W06_ACTUAL_LAUNCH_V1" or launch.get("method") != "ACTUAL_OWN_APP_LAUNCHSERVICES_GUI"
                            or launch.get("app_bundle") != c["app_bundle"] or launch.get("config_sha256") != hashlib.sha256(raw).hexdigest()
                            or launch.get("action_started_utc_ns", 0) < registered_at
                            or launch.get("action_finished_utc_ns", 0) < launch.get("action_started_utc_ns", 0)):
                        raise ValueError("Actual fresh root GUI launch receipt required")
                    bind(launch["native_UI_receipt"], deadline)
                    app = probe.identity(launch["app_pid"])
                    if (app is None or app.executable != c["bindings"]["main"]["original"] or not owned_uid(probe,app)
                            or app.start_seconds*10**9+app.start_microseconds*1000 < registered_at):
                        raise ValueError("Registered launch is not a fresh owned bound app")
                    launch["registered_identity"] = asdict(app)
                    write(out/"launch.receipt.json", launch)
                    emit("ROOT_LAUNCH_REGISTERED", {"identity": asdict(app), "launch_attestation": "ROOT_UI_RECEIPT_NOT_OS_ATTESTATION"})
                    continue
                if observer is None or observer.poll() is not None:
                    raise ValueError("Live owned observer required")
                if command == "ui-receipt":
                    ui_receipts.append(bind(message["receipt"], deadline))
                    emit("ROOT_NATIVE_UI_RECEIPT", ui_receipts[-1])
                    continue
                if command == "force-parent":
                    if c["case"] != "FORCED_PARENT" or app_child is None:
                        raise ValueError("No owned app Popen authority")
                    records = observed_events()
                    samples = [r["data"] for r in records if r["kind"] == "SAMPLE"]
                    latest = samples[-1]
                    service = Identity(**latest["current_service"])
                    if not same_process(service,probe.identity(service.pid)) or not owned_uid(probe,service):
                        raise ValueError("Fresh exact service identity required")
                    observer.stdin.write(b"arm-quit\n"); observer.stdin.flush()
                    arm_until = min(deadline, time.monotonic()+2)
                    while time.monotonic() < arm_until:
                        rows = observed_events()
                        if any(r["kind"]=="GUI_ACTION_ARMED" and r["monotonic"]>=records[-1]["monotonic"] for r in rows):
                            break
                        time.sleep(.02)
                    else:
                        raise ValueError("Observer did not arm actual forced action")
                    if time.monotonic()+12 > deadline:
                        raise ValueError("Full force observation window unavailable")
                    result = force_owned_parent(app_child, app, service, latest["port"], probe, RealClock(),12)
                    write(out/"owned-parent.result.json", result)
                    if not result["pass"]:
                        raise ValueError("Actual owned force/cleanup observation failed")
                    seen_commands.append(command)
                    continue
                if command not in FIXED:
                    raise ValueError("Unknown fixed control command")
                if command == "crash-service" and c["case"] != "RESTART_BUDGET":
                    raise ValueError("Case has no service-loss injection")
                observer.stdin.write((command+"\n").encode()); observer.stdin.flush()
                seen_commands.append(command)
                emit("ROOT_COMMAND_FORWARDED", command)
                if command == "finish":
                    observer.stdin.close()
                    code = observer.wait(timeout=min(65,max(.001,deadline-time.monotonic())))
                    if code:
                        raise ValueError("Observer failed; preserve raw outcome")
                    after = verify(c, out,"after",deadline)
                    if before != after:
                        raise ValueError("Source/package modes or bytes changed")
                    required = {"unauthorized", "port-exclusive", "wait-exit", "port-released", "finish"}
                    required.add("force-parent" if c["case"]=="FORCED_PARENT" else "arm-close" if c["case"]=="LS_CLOSE" else "arm-quit")
                    if not required.issubset(seen_commands) or (not ui_receipts and c["case"]!="FORCED_PARENT"):
                        raise ValueError("Actual mechanical commands/UI receipts incomplete")
                    if c["case"]=="RESTART_BUDGET" and not (seen_commands.count("crash-service")==3 and seen_commands.count("wait-replacement")==2 and seen_commands.count("observe-terminal")==1 and len(ui_receipts)>=3):
                        raise ValueError("Actual restart inventory incomplete")
                    status.update(status="MECHANICAL_OBSERVER_CLOSED_MANUAL_REVIEW_REQUIRED", observer_exit=code,
                        commands=seen_commands, native_UI_receipts=ui_receipts, registered_launch=launch,
                        GUI="UNOBSERVED" if not ui_receipts else "SEPARATE_ROOT_RAW_RECEIPTS_REQUIRE_REVIEW",
                        authenticated_positive_HTTP="UNOBSERVED" if not ui_receipts else "SEPARATE_ROOT_UI_ENGINE_EVIDENCE_REQUIRES_REVIEW")
                    return
            if observer is not None and observer.poll() is not None:
                raise ValueError("Observer exited before explicit successful finish")
            if observer_started is not None and time.monotonic()-observer_started > 310:
                raise TimeoutError("Observer verification/active interval deadline exceeded")
            if any(p.stat().st_size>MAX_LOG for pattern in ("*.stdout","*.stderr") for p in out.glob(pattern)):
                raise ValueError("Owned raw-output bound exceeded")
            time.sleep(.05)
    except BaseException as error:
        status["error"] = {"type":type(error).__name__,"detail":str(error)}
        raise
    finally:
        status["owned_observer_cleanup"] = stop_owned(observer)
        # Never signal an LS app or arbitrary registered service during failure cleanup.
        status["owned_app_direct_cleanup"] = stop_owned(app_child)
        write(out/"worker.result.json",status)


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--worker",action="store_true",help=argparse.SUPPRESS)
    parser.add_argument("--started",type=float,help=argparse.SUPPRESS)
    args=parser.parse_args()
    if args.worker:
        signal.signal(signal.SIGTERM,lambda *_: (_ for _ in ()).throw(TimeoutError("Owned worker termination requested")))
        worker(args.config,args.output,args.started)
        return
    started=time.monotonic()
    c,raw=load_config(args.config)
    if digest(Path(__file__).resolve(),started+10)!=c["runner_sha256"]:
        raise ValueError("Reviewed runner mismatch before output/process")
    bind(c["bindings"]["python"],started+15)
    if Path(sys.executable).resolve()!=Path(c["bindings"]["python"]["original"]).resolve():
        raise ValueError("Pinned actual interpreter required before owned worker")
    out=args.output
    protected=[HERE,*(Path(c[n]) for n in ("canonical_root","source_root","app_bundle","upfront_bundle","staged_runtime"))]
    if not out.is_absolute() or out.exists() or any(out.resolve().is_relative_to(p.resolve()) for p in protected):
        raise ValueError("Fresh outside protected input roots required")
    out.mkdir(mode=0o700)
    argv=[sys.executable,"-I","-B",str(Path(__file__).resolve()),"--worker","--started",str(started),"--config",str(args.config.resolve()),"--output",str(out)]
    env={"PATH":"/usr/bin:/bin","PYTHONDONTWRITEBYTECODE":"1","PYTHONNOUSERSITE":"1"}
    write(out/"outer.upfront.json",{"argv":argv,"cwd":str(HERE),"environment":dict(env),"config_sha256":hashlib.sha256(raw).hexdigest(),"work_seconds":WORK_SECONDS,"total_seconds":TOTAL_SECONDS})
    child=None
    result={"status":"INCOMPLETE","native_UI_teardown_may_be_required":True,"unobserved_descendants":"UNOBSERVED","case_acceptance":"NOT_DECIDED"}
    try:
        with (out/"worker.stdout").open("xb") as stdout,(out/"worker.stderr").open("xb") as stderr:
            child=subprocess.Popen(argv,cwd=HERE,env=dict(env),stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
            write(out/"worker.launch.json",{"owned_pid":child.pid,"monotonic":time.monotonic()})
            while child.poll() is None:
                tick(started+WORK_SECONDS)
                if stdout.tell()>MAX_LOG or stderr.tell()>MAX_LOG:
                    raise ValueError("Outer owned raw-output bound exceeded")
                time.sleep(.05)
            code=child.returncode
            result.update(status="WORKER_CLOSED" if code==0 else "WORKER_FAILED",exit_code=code)
    finally:
        result["owned_worker_cleanup"]=stop_owned(child)
        result["elapsed_seconds"]=time.monotonic()-started
        result["within_total_bound"]=result["elapsed_seconds"]<=TOTAL_SECONDS
        write(out/"outer.result.json",result)
    if result.get("exit_code")!=0 or not result["within_total_bound"] or not result["owned_worker_cleanup"]["reaped"]:
        raise SystemExit(1)


if __name__=="__main__":
    main()
