"""Append one fixed control message to an already-owned actual case directory."""
from __future__ import annotations
import argparse
import json
import os
import stat
from pathlib import Path


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case-output",type=Path,required=True)
    parser.add_argument("--json",required=True)
    args=parser.parse_args()
    out=args.case_output
    if not out.is_absolute() or out.is_symlink() or not out.is_dir() or out.stat().st_uid!=os.getuid():
        raise ValueError("Actual owned absolute case output required")
    message=json.loads(args.json)
    allowed={"register-launch","ui-receipt","sample","arm-close","arm-quit","wait-exit",
             "crash-service","wait-replacement","observe-terminal","unauthorized",
             "port-exclusive","port-released","force-parent","finish"}
    command=message.get("command")
    if command not in allowed or set(message)!=({"command","receipt"} if command in {"register-launch","ui-receipt"} else {"command"}):
        raise ValueError("Exact fixed command shape required")
    data=(json.dumps(message,separators=(",",":"))+"\n").encode()
    if len(data)>65536 or not (out/"outer.upfront.json").is_file():
        raise ValueError("Actual bounded outer case required")
    control=out/"control.jsonl"
    fd=os.open(control,os.O_WRONLY|os.O_APPEND|os.O_NOFOLLOW)
    try:
        info=os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid() or info.st_size+len(data)>1024*1024:
            raise ValueError("Owned bounded control file required")
        if os.write(fd,data)!=len(data):
            raise OSError("Partial control append; case must remain incomplete")
        os.fsync(fd)
    finally:
        os.close(fd)


if __name__=="__main__":
    main()
