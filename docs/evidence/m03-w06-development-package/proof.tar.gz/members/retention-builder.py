"""Finite evidence retention only. Never imports/executes any selected source."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import os
import stat
import tarfile

OUT=Path('/tmp/japp-m03-w06-development-package-ip-retained-20261019')
if OUT.exists(): raise RuntimeError('Fresh finite packet directory required')
OUT.mkdir()
MEMBERS=OUT/'members';MEMBERS.mkdir()
selected={};copies=[];omitted=[]

def sha(data): return hashlib.sha256(data).hexdigest()
def safe(name):
    p=PurePosixPath(name)
    return not p.is_absolute() and name==p.as_posix() and '..' not in p.parts and all(part not in ('','.') for part in p.parts)
def add(path,label):
    path=Path(path);name='members/'+label
    if not safe(name) or name in selected: raise RuntimeError('Unsafe/duplicate member '+name)
    meta=path.lstat()
    if not stat.S_ISREG(meta.st_mode) or meta.st_size>2*1024*1024: raise RuntimeError('Unexpected nonfinite payload '+str(path))
    data=path.read_bytes();after=path.lstat()
    identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_mode)
    if identity(meta)!=identity(after) or len(data)!=meta.st_size: raise RuntimeError('Source changed')
    dest=OUT/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    row={'bytes':len(data),'sha256':sha(data)}
    selected[name]=row;copies.append({'source':str(path),'member':name,**row,'source_mode':oct(stat.S_IMODE(meta.st_mode))})
def tree(root,label):
    root=Path(root)
    for p in sorted(root.rglob('*')):
        if p.is_symlink(): raise RuntimeError('Link in finite source '+str(p))
        if p.is_file(): add(p,label+'/'+p.relative_to(root).as_posix())
def flat(root,label,allowed=None):
    root=Path(root)
    for p in sorted(root.iterdir()):
        if p.is_file() and (allowed is None or p.suffix in allowed):add(p,label+'/'+p.name)
def generated(name,value):
    data=(value if isinstance(value,str) else json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
    member='members/'+name
    if not safe(member) or member in selected:raise RuntimeError('Duplicate generated member')
    dest=OUT/member;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    selected[member]={'bytes':len(data),'sha256':sha(data)}

tree('/tmp/japp-m03-w06-canonical-adoption-20261019','adoption')
build=Path('/tmp/japp-m03-w06-current-macos-build-20261019')
flat(build,'build',{'.json','.log','.py'})
tree(build/'static-inspection','build/static-inspection')
flat(build/'runtime-build','build/runtime-build')
flat(build/'runtime-build/inputs','build/runtime-build/inputs')
for p in sorted((build/'wheels').glob('*.whl')):add(p,'build/wheels/'+p.name)
for name in ('app-upfront','fresh-payload','prior-root-app','prior-root-stage','runtime-build/build-env',
             'runtime-build/dist','runtime-build/pyinstaller-work','runtime-build/runtime-stage',
             'runtime-build/spec','runtime-build/uv-cache'):
    omitted.append({'source':str(build/name),'reason':'Physical package/runtime/cache/build directory intentionally not traversed or archived; applicable actual image manifests/receipts retained separately.'})

for label,root in [('controller/v1','/tmp/japp-m03-w06-package-lifecycle-runner-source-20261019'),
                   ('controller/v2','/tmp/japp-m03-w06-package-lifecycle-runner-source-v2-20261019'),
                   ('controller/v3','/tmp/japp-m03-w06-package-lifecycle-runner-source-v3-20261019'),
                   ('observer/original','/tmp/japp-m03-w06-macos-package-lifecycle-preparation-20261019'),
                   ('observer/correction','/tmp/japp-m03-w06-macos-package-lifecycle-observer-correction-20261019'),
                   ('reviews/observer-original','/tmp/japp-m03-w06-macos-package-lifecycle-independent-review-20261019'),
                   ('reviews/observer-correction','/tmp/japp-m03-w06-macos-package-lifecycle-correction-independent-review-20261019'),
                   ('reviews/focus','/tmp/japp-m03-w06-canonical-focus-independent-review-20261019'),
                   ('reviews/build','/tmp/japp-m03-w06-current-macos-build-independent-review-20261019'),
                   ('reviews/adoption-build-source','/tmp/japp-m03-w06-current-adoption-and-build-v2-review-20261019'),
                   ('reviews/initial-build-source','/tmp/japp-m03-w06-build-current-macos-source-review-20261019'),
                   ('reviews/input-sanity','/tmp/japp-m03-w06-package-case-sanity-review-20261019'),
                   ('reviews/actual-forced','/tmp/japp-m03-w06-owned-forced-data-independent-review-20261019'),
                   ('case/preflight-failure','/tmp/japp-m03-w06-owned-forced-case-20261019'),
                   ('case/actual-v3','/tmp/japp-m03-w06-owned-forced-case-v3-20261019'),
                   ('history/controller-preparation','/tmp/japp-m03-w06-controller-preparation-history-20261019')]:
    tree(root,label)

for label,root in [('inputs/initial-sip-preparation','/tmp/japp-m03-w06-actual-package-case-inputs-20261019'),
                   ('inputs/actual-v2','/tmp/japp-m03-w06-actual-package-case-inputs-v2-20261019')]:
    root=Path(root)
    for p in sorted(root.rglob('*')):
        if p.is_symlink():raise RuntimeError('Unexpected input link')
        if not p.is_file():continue
        if p.name in {'097-python3.12','098-lsof','099-git'}:
            omitted.append({'source':str(p),'bytes':p.stat().st_size,'reason':'OS/interpreter tool image intentionally excluded from Git payload; actual used input files are durably retained under the whole input113 manifest. Initial SIP partial tool bytes are not relabeled complete execution evidence.'})
        else:add(p,label+'/'+p.relative_to(root).as_posix())

for case,label in [('japp-m03-w06-owned-forced-case-20261019','case/preflight-config'),
                   ('japp-m03-w06-owned-forced-case-v3-20261019','case/actual-config')]:
    argv=json.loads((Path('/tmp')/case/'outer.upfront.json').read_text())['argv']
    config=Path(argv[argv.index('--config')+1])
    flat(config.parent,label)

outer_files=[
 'japp-m03-w06-canonical-native-focus-20261019.py','japp-m03-w06-canonical-native-focus-20261019.outer.log',
 'japp-m03-w06-canonical-python-focus-20261019.py','japp-m03-w06-canonical-python-focus-20261019.outer.log',
 'japp-m03-w06-build-current-macos-20261019.py','japp-m03-w06-build-current-macos-v2-20261019.py',
 'japp-m03-w06-current-macos-build-20261019.outer.log',
 'japp-m03-w06-prepare-actual-forced-pins-20261019.py','japp-m03-w06-prepare-actual-forced-pins-v2-20261019.py',
 'japp-m03-w06-owned-forced-case-20261019.outer.stderr','japp-m03-w06-owned-forced-case-20261019.outer.stdout',
 'japp-m03-w06-owned-forced-case-v3-20261019.outer.stderr','japp-m03-w06-owned-forced-case-v3-20261019.outer.stdout',
 'japp-m03-w06-owned-forced-case-v3-20261019.control.stderr','japp-m03-w06-owned-forced-case-v3-20261019.control.stdout']
for name in outer_files:add(Path('/tmp')/name,'outer-commands/'+name)
add('/tmp/japp-m03-w06-clean-root-verify-20261019.py','future-full/uninvoked-clean-root-verify.py')
tree('/tmp/japp-m03-w06-clean-full-wrapper-independent-review-20261019','reviews/future-full-wrapper-source')

durable=Path('/Users/tanishkalwad/jobapplyv2-evidence/m03-w06-development-package-20261019/manifest.json')
native=Path('/Users/tanishkalwad/jobapplyv2-evidence/m03-w06-focus-native-images-20261019/manifest.json')
if sha(durable.read_bytes())!='90e971e1ab0bcea4040745b0060708200bdaf38606e11079c7a67e03b2923e8c':raise RuntimeError('Durable image manifest drift')
if sha(native.read_bytes())!='31037198cbf1c7bc4eb69ad755ecaf095a7a9ead86c0bc84ec661e17f03d6390':raise RuntimeError('Native image manifest drift')
add(durable,'omissions/durable-app-stage-input-manifest.json')
add(native,'omissions/postexecuted-native6-manifest.json')
durable_data=json.loads(durable.read_text())
copy_counts={r['label']:len(r['files']) for r in durable_data['copies']}
if sorted(copy_counts.values())!=[40,43,113]:raise RuntimeError('Unexpected durable image counts')
generated('omitted-images.json',{'scope':'Outside retained image references; physical image bytes are NOT in this archive. Manifest bytes are copied exact. No new full-image hash pass or pre-execution native-image credit is implied by packaging.',
    'durable_complete_package':{'manifest':str(durable),'sha256':sha(durable.read_bytes()),'copy_counts':copy_counts,
        'timing':'Durable copy after actual case; actual app original/upfront comparison occurred before launch and after the case. Tool retention was bytes-only, not original-tool mode equivalence.'},
    'focused_native6':{'manifest':str(native),'sha256':sha(native.read_bytes()),'count':6,'timing':'Post-execution image retention, no upfront physical image map in focus.'},
    'omitted_locations':omitted})

summary={'scope':'W06 IN_PROGRESS evidence only; no milestone verification/approval',
 'source':{'head':'c4f7d9ca6df70f3d7f8a8f8d10806453e69687e6','tree':'b7b7bbcf7d508309bd6c3e511bb924a0ad2338d3','logical_files':1946,'candidate_status':'Exactly recorded dirty32, not a clean checkpoint','focus_to_build_change':'Inventory update only; both original maps retained'},
 'focused_checks':{'python_affected_passed':112,'collected_unique_common_ids':1801,'previous_common_ids_preserved':1687,'desktop_rust_passed_per_mode':[232,232,232],'modes':['default','all-features','tauri/custom-protocol'],'default_test_parallelism':True,'whole_current20':'NOT_ESTABLISHED_BY_THIS_PACKET'},
 'fresh_build_static':{'outer_commands_zero_exit':31,'inner_hash_locked_runtime_stages_zero_exit':6,'runtime_files':40,'signed_app_files':43,'macho_members_arm64':4,'apple_root_dependency_loads':25,'dylib_self_ids_not_loads':2,'LC_RPATH':0,'static_codesign_deep_strict_exit':0,'runtime_bytes_modes_equal_pre_post_signing':True,'offline_claim':False,'scope':'Actual hash-locked commands and authorized pinned installs; static declarations are not dynamic loader resolution or distribution signing.'},
 'actual_forced_case':{'count':1,'outer_worker_observer_exit':[0,0,0],'owned_parent_exit':-9,'registered_cleanup_ms':219.148709,'included_parent_wait_ms':4.563584,'declared_bound_seconds':12,'negative_401_requests':6,'exclusive_bind':'EADDRINUSE','port_rebound_and_released':True,'source_app_runtime_bytes_modes_unchanged':True,'GUI':'UNOBSERVED','LaunchServices':'UNOBSERVED','authenticated_positive_HTTP':'UNOBSERVED','raw_private_ACK':'UNOBSERVED','unseen_descendants':'UNOBSERVED'},
 'failure_history':{'initial_copy2_SIP':'Original script/partial nonbinary files/authored note; raw CLI error remains conversational, no reconstructed raw stderr','first_outer_preflight':'Raw failure retained; zero app/observer handles, worker reaped; HOME omission exposed globally ignored .claude path','root_reversal_and_missing_pin_refusals':'Conversational only; no fabricated local raw evidence','actual_v3':'One actual native case; initial preflight did not execute an app/observer'},
 'unproven':['GUI/Ready/service+API/Checked-at UI','LS launch/Close/Quit','restart-budget native UI','Unicode native launch','allocator random-port collision','raw ACK capture','complete descendants','DeveloperID/notarization/Gatekeeper','foreign-host acceptance','W06 verification','M03/Gate acceptance'],
 'review_reports':{label:next(r for r in copies if r['member']==member)['sha256'] for label,member in [('focus','members/reviews/focus/REVIEW.md'),('build','members/reviews/build/REVIEW.md'),('actual_forced','members/reviews/actual-forced/REVIEW.md')]}}
generated('summary.json',summary)
readme='''# W06 development package — IN_PROGRESS evidence\n\nThis finite packet retains exact selected source/adoption/focus/build/static/owned-forced records and their independent source/data reviews. It is not W06 verification or a complete current all20 run. Source is the exactly recorded dirty1946-file c4f7d9/b7b7 candidate, not a clean checkpoint.\n\nClosed evidence:112 affected Python passes and1801 common IDs;232 desktop tests per mode across three modes; fresh31-command Mac build and six hash-locked runtime stages; runtime40/signed app43 with byte/mode equality; static deep-strict ad-hoc signing; four arm64 Mach-O files,25 Apple-root dependency loads, two self IDs and no LC_RPATH. Authorized pinned inner installs are not mislabeled offline. Focus native6 images are retained after execution, without upfront physical-image provenance.\n\nOne actual own-Popen forced-parent case closes outer/worker/observer0: held parent exits-9, registered app/service/group/listener absence219.148709ms including4.563584ms wait within12s; six absent/wrong credential401 responses, exclusive bind and rebound/release. Source/app/runtime/modes remain exact. No GUI/Ready UI/positive authenticated HTTP, LaunchServices/Close/Quit, restart-budget UI, Unicode launch, allocator random-port collision, raw private ACK, complete descendants, foreign-host or distribution acceptance is established. Root's reported locked own-app UI is conversational evidence only; no screenshot/launch is fabricated.\n\nFailure history stays separate: original copy2/SIP preparation retains source/partial files/authored note, not reconstructed raw stderr; first outer raw Git preflight failed before app/observer due missing HOME; root's wrong-needle/missing-pin refusals are conversation-only. The exact6862/f326/6da3 controller and9acc/53ed observer history is retained. Corrected v3 ran the first actual package process case once.\n\nPhysical app43/stage40/input113 and postexecuted native6 images are deliberately outside Git, with exact copied manifests and explicit omitted-images index/recovery paths. This tar does not contain those images or caches. Own wheel bytes, finite raw logs/maps/scripts/receipts are present. Metadata/raw bytes are never replaced by derived summaries; source-copies.json binds every original selected source. Native/cache directories were not recursively archived.\n\nThe archive was locally read back as safe unique regular files with exhaustive hashes and exact embedded/outer closure. This is retention verification, not a fresh product execution or a new Gate/owner decision. No product source/root state was changed by the packager.\n'''
generated('README.md',readme)
add(Path(__file__),'retention-builder.py')
generated('source-copies.json',{'scope':'Every copied source byte exact; generated derived files are separately named, not raw stdout','files':copies})
generated('members.json',{'scope':'Exhaustive regular members excluding only this members.json; outer manifest includes it','files':dict(selected)})
archive=OUT/'proof.tar.gz'
with archive.open('wb') as f,gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
    for name,row in sorted(selected.items()):
        data=(OUT/name).read_bytes()
        if sha(data)!=row['sha256'] or len(data)!=row['bytes']:raise RuntimeError('Staged drift')
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
        tar.addfile(info,io.BytesIO(data))
seen={}
with tarfile.open(archive,'r:gz') as tar:
    for member in tar.getmembers():
        if not safe(member.name) or not member.isfile() or member.name in seen:raise RuntimeError('Unsafe archive')
        data=tar.extractfile(member).read();seen[member.name]={'bytes':len(data),'sha256':sha(data)}
if seen!=selected:raise RuntimeError('Archive member closure failed')
embedded=json.loads((OUT/'members/members.json').read_text())['files']
if embedded!={k:v for k,v in selected.items() if k!='members/members.json'}:raise RuntimeError('Embedded closure failed')
for row in copies:
    data=Path(row['source']).read_bytes()
    if len(data)!=row['bytes'] or sha(data)!=row['sha256']:raise RuntimeError('Original source drift')
archive_binding={'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())}
manifest={'archive':archive_binding,'files':selected,'safe_regular_members':len(selected),'payload_bytes':sum(r['bytes'] for r in selected.values()),'scope':'Finite W06 IP actual evidence; physical images omitted explicitly; source/copy/archive hashes readback exact; no product rerun or W06 verification'}
(OUT/'retention-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
(OUT/'README.md').write_text(readme)
(OUT/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
(OUT/'artifact.json').write_text(json.dumps({'scope':'DERIVED adoption descriptor, not raw execution/Gate evidence verdict','archive':archive_binding,'members':len(selected),'payload_bytes':manifest['payload_bytes'],'status':'W06_IN_PROGRESS','physical_images_in_archive':False,'outside_durable_manifests':[str(durable),str(native)],'whole_current20':'PENDING'},indent=2)+'\n')
print(json.dumps({'output':str(OUT),'archive':archive_binding,'members':len(selected),'payload_bytes':manifest['payload_bytes'],'original_copies':len(copies),'self_verified':'SAFE_EXHAUSTIVE_REGULAR_CLOSURE_AND_SOURCE_BYTES'}))
