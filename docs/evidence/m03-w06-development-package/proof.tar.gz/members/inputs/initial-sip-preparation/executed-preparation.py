"""Bind existing actual build records. No processes or package actors."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
B = Path('/tmp/japp-m03-w06-current-macos-build-20261019')
A = Path('/tmp/japp-m03-w06-canonical-adoption-20261019')
OUT = Path('/tmp/japp-m03-w06-actual-package-case-inputs-20261019')
OUT.mkdir()
(OUT/'retained').mkdir()
(OUT/'derived').mkdir()
(OUT/'executed-preparation.py').write_bytes(Path(__file__).read_bytes())
copies = {}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def bind(original):
    original = original.resolve(strict=True)
    assert original.is_file() and not original.is_symlink()
    if original not in copies:
        retained = OUT/'retained'/(f'{len(copies):03d}-' + original.name)
        shutil.copy2(original, retained)
        assert sha(original) == sha(retained)
        copies[original] = retained
    return {'original': str(original), 'retained': str(copies[original]), 'sha256': sha(original)}


head, tree = subprocess.check_output(['/usr/bin/git', 'rev-parse', 'HEAD', 'HEAD^{tree}'], cwd=ROOT, text=True).splitlines()
status = subprocess.check_output(['/usr/bin/git', 'status', '--porcelain=v1', '--untracked-files=normal'], cwd=ROOT, text=True)
assert head == 'c4f7d9ca6df70f3d7f8a8f8d10806453e69687e6'
static = json.loads((B/'static-inspection/inspection.json').read_text())
assert static['status'] == 'PACKAGE_STATIC_INSPECTION_PASS_LIFECYCLE_PENDING'
records = {}
mapping = {'contracts-wheel': 'contracts-wheel', 'orchestrator-wheel': 'service-wheel', 'runtime-build': 'runtime-build', 'tauri-app-build': 'app-build', 'codesign-display': 'codesign-display', 'codesign-entitlements': 'codesign-entitlements'}
for role, label in mapping.items():
    rec = json.loads((B/(label+'-result.json')).read_text())
    assert rec['exit_code'] == 0 and rec['owned_group_after'] == 'GONE'
    references = [B/(label+'-upfront.json'), B/(label+'-result.json')]
    if role == 'runtime-build':
        runtime = B/'runtime-build'
        references += [runtime/'build-proof.json', runtime/'staging-result.json', runtime/'builder-executed.py', B/'build-inputs.json']
        proof = json.loads((runtime/'build-proof.json').read_text())
        assert len(proof['commands']) == 6 and all(r['exit_code'] == 0 for r in proof['commands'])
        references += sorted((runtime/'inputs').iterdir())
        references += sorted(runtime.glob('*.stdout')) + sorted(runtime.glob('*.stderr'))
    merged = bind(B/(label+'.log'))
    derived = {'scope': 'DERIVED normal form of exact executed combined-output command; no new execution.', 'role': role, 'argv': rec['argv'], 'exit_code': rec['exit_code'], 'stream_mode': 'MERGED_STDOUT_STDERR_SINGLE_ARTIFACT; stdout and stderr fields both bind the same existing merged log, not separate streams', 'stdout': merged, 'stderr': merged, 'actual_upfront_and_result_refs': [bind(p) for p in references]}
    p = OUT/'derived'/(role+'.json')
    dump(p, derived)
    records[role] = bind(p)
references = []
commands = []
for p in sorted(B.glob('macho-*-result.json')):
    rec = json.loads(p.read_text())
    assert rec['exit_code'] == 0
    commands.append(rec['argv'])
    references += [p, p.with_name(p.name.replace('-result.json', '-upfront.json')), p.with_name(p.name.replace('-result.json', '.log'))]
assert len(commands) == 16
references.append(B/'dependency-declarations-review.json')
derived = {'scope': 'DERIVED_COMPOSITE of sixteen actual commands and static load-command adjudication; argv is an actual command-set list, not one invented process. No loader-resolution trace.', 'role': 'macho-dependencies', 'argv': commands, 'exit_code': 0, 'stream_mode': 'COMPOSITE_ROLE_POINTS_TO_FIRST_EXISTING_MERGED_LOG; exhaustive 16 logs referenced below; no independent stderr', 'stdout': bind(B/'macho-001-deps.log'), 'stderr': bind(B/'macho-001-deps.log'), 'actual_upfront_and_result_refs': [bind(p) for p in references]}
p = OUT/'derived/macho-dependencies.json'
dump(p, derived)
records['macho-dependencies'] = bind(p)
app = Path(json.loads((B/'closure.json').read_text())['app'])
upfront = B/'app-upfront'/app.name
source = A/'source-for-fresh-build.json'
runtime_rel = 'Contents/Resources/runtime/manifest.json'
report = {'schema': 'W06_FRESH_BUILD_BINDINGS_V1', 'scope': 'DERIVED actual source/build/static join. Pinned inner dependency downloads occurred in fresh cache; no enforced-offline claim. Static dependency declarations only; launch pending.', 'head': head, 'tree': tree, 'source_manifest_sha256': sha(source), 'target': 'aarch64-apple-darwin', 'runtime_manifest_sha256': sha(app/runtime_rel), 'files': static['files'], 'macho_result': 'ARM64_BUNDLE_OR_APPLE_ROOTS_ONLY', 'records': records}
p = OUT/'derived/build-report.json'
dump(p, report)
bindings = {'main': {'original': str(app/'Contents/MacOS/japp-desktop'), 'retained': str(upfront/'Contents/MacOS/japp-desktop')}, 'service': {'original': str(app/'Contents/Resources/runtime/japp-orchestrator/japp-orchestrator'), 'retained': str(upfront/'Contents/Resources/runtime/japp-orchestrator/japp-orchestrator')}, 'runtime_manifest': {'original': str(app/runtime_rel), 'retained': str(upfront/runtime_rel)}}
for role, original in {'source_manifest': source, 'static_report': B/'static-inspection/inspection.json', 'build_report': p, 'python': ROOT/'.venv/bin/python', 'lsof': Path('/usr/sbin/lsof'), 'git': Path('/usr/bin/git')}.items():
    row = bind(original)
    bindings[role] = {key: row[key] for key in ['original', 'retained']}
pins = {'schema': 'W06_ACTUAL_PACKAGE_PIN_INPUT_V1', 'case': 'FORCED_PARENT', 'reviewed_runner_sha256': 'FILL_REVIEWED_CORRECTED_RUNNER_BEFORE_GENERATOR', 'source_root': str(ROOT), 'canonical_root': str(ROOT), 'app_bundle': str(app), 'upfront_bundle': str(upfront), 'staged_runtime': str(ROOT/'apps/desktop/src-tauri/runtime-payload'), 'expected_head': head, 'expected_tree': tree, 'expected_status': status, 'bindings': bindings}
dump(OUT/'actual-pins-pending-runner.json', pins)
dump(OUT/'preparation.json', {'scope': 'Filesystem/read-only Git binding only; no app, service, GUI, config generator or observer invocation.', 'head': head, 'tree': tree, 'roles': len(bindings), 'retained_files': len(copies), 'derived_build_report_sha256': sha(p), 'pending': 'Exact corrected runner review/hash and generator invocation before native actor.'})
print('Prepared actual9roles/build7roles; no actors/config-generator invoked; runner pin pending')
