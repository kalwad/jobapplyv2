from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,time,sys
R=Path('/Users/tanishkalwad/jobapplyv2');B=Path('/tmp/japp-m03-w06-canonical-adoption-20261019/checks');B.mkdir(exist_ok=False)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def put(n,v):(B/n).write_text(json.dumps(v,indent=2)+'\n')
def source():
 names=set()
 for argv in [['git','ls-files','-z'],['git','ls-files','--others','--exclude-standard','-z']]:names.update(n for n in subprocess.check_output(argv,cwd=R).decode().split('\0') if n)
 return {n:{'bytes':(R/n).stat().st_size,'sha256':sha(R/n)} for n in sorted(names)}
env={k:os.environ[k] for k in ['HOME','USER','LOGNAME','TMPDIR','LANG','LC_ALL','CARGO_HOME','RUSTUP_HOME'] if k in os.environ};env.update(PATH='/opt/homebrew/opt/node@24/bin:'+os.environ['PATH'],UV_OFFLINE='true',CARGO_NET_OFFLINE='true',COREPACK_ENABLE_NETWORK='0',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_SYSTEM='/dev/null')
before=source();assert len(before)==1946;put('source-before.json',before);shutil.copy2(__file__,B/'executed-wrapper.py')
sys.path.insert(0,str(R/'scripts'));import verify
relatives=tuple(sorted({p.relative_to(R).as_posix() for g in verify.PY_TEST_FILE_GLOBS for p in R.glob(g) if p.is_file()}))
changed=['scripts/build-linux-service-runtime.py', 'scripts/build-windows-runtime.py', 'scripts/linux_package.py', 'scripts/macos_package.py', 'scripts/tests/test_linux_builder_environment.py', 'scripts/tests/test_linux_package.py', 'scripts/tests/test_linux_parser_and_cli.py', 'scripts/tests/test_linux_parser_records.py', 'scripts/tests/test_macos_package.py', 'scripts/tests/test_windows_builder.py', 'scripts/tests/test_windows_package.py', 'scripts/windows_package.py']
commands=[('ruff',['uv','run','ruff','check',*changed],60),('format',['uv','run','ruff','format','--check',*changed],60),('mypy',['uv','run','mypy',*changed],120),('affected-pytest',['uv', 'run', 'pytest', 'scripts/tests/test_linux_builder_environment.py', 'scripts/tests/test_linux_package.py', 'scripts/tests/test_linux_parser_and_cli.py', 'scripts/tests/test_linux_parser_records.py', 'scripts/tests/test_macos_package.py', 'scripts/tests/test_windows_builder.py', 'scripts/tests/test_windows_package.py', '-q'],180),('portability',['uv','run','python','scripts/check_portability.py'],60),('collection',list(verify._canonical_pytest_command(relatives,collect_only=True)),120)]
records=[]
for name,argv,cap in commands:
 tool=Path(shutil.which(argv[0],path=env['PATH'])).resolve();rec={'argv':argv,'cwd':str(R),'environment':dict(env),'tool':str(tool),'tool_sha256_before':sha(tool),'started_utc':datetime.now(timezone.utc).isoformat(),'timeout_seconds':cap};put(name+'-upfront.json',rec);start=time.monotonic()
 with (B/(name+'.log')).open('xb') as out:
  try:code=subprocess.run(argv,cwd=R,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=cap,check=False).returncode;timedout=False
  except subprocess.TimeoutExpired:code=124;timedout=True
 rec.update(exit_code=code,timeout=timedout,elapsed_seconds=time.monotonic()-start,ended_utc=datetime.now(timezone.utc).isoformat(),log_bytes=(B/(name+'.log')).stat().st_size,log_sha256=sha(B/(name+'.log')),tool_sha256_after=sha(tool));put(name+'-result.json',rec);records.append(rec);print(json.dumps({'name':name,'exit_code':code,'seconds':rec['elapsed_seconds']}),flush=True)
 if code:break
if len(records)==6 and records[-1]['exit_code']==0:
 ids,reason=verify._parse_pytest_collection_output((B/'collection.log').read_text(),relatives);assert reason is None,reason;put('actual-collected-ids.json',{'node_ids':ids,'count':len(ids),'source_parser_sha256':sha(R/'scripts/verify.py'),'test_relatives':relatives})
after=source();put('source-after.json',after);ok=before==after and len(records)==6 and all(r['exit_code']==0 and r['tool_sha256_before']==r['tool_sha256_after'] for r in records);put('closure.json',{'all6commands_exit0':len(records)==6 and all(r['exit_code']==0 for r in records),'source1946_unchanged':before==after,'verdict':ok,'scope':'Affected Python/policy/collection only; no full/nativeWindows/PowerShell validation'});raise SystemExit(0 if ok else 1)
