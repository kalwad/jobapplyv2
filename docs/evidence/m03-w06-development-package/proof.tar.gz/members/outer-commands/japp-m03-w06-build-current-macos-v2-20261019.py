"""Fresh wheels/runtime/app plus static receipts. Never launches the app."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import signal
import stat
import subprocess
import sys
import time
import traceback

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
OUT = Path('/tmp/japp-m03-w06-current-macos-build-20261019')
CONFIG = Path(sys.argv[1])
cfg = json.loads(CONFIG.read_text())


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()


def write(p, value):
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def source_map():
    names = subprocess.check_output(['git', 'ls-files', '-c', '-o', '--exclude-standard', '-z'], cwd=ROOT).decode().rstrip('\0').split('\0')
    return {n: {'bytes': (ROOT/n).stat().st_size, 'sha256': sha(ROOT/n)} for n in sorted(set(names))}


def tree(base):
    result = {}
    for p in sorted(base.rglob('*')):
        if p.is_symlink():
            raise ValueError('Unexpected symlink: ' + str(p))
        if p.is_dir():
            continue
        st = p.stat()
        assert stat.S_ISREG(st.st_mode)
        result[p.relative_to(base).as_posix()] = {'bytes': st.st_size, 'sha256': sha(p), 'mode': stat.S_IMODE(st.st_mode)}
    return result


assert not OUT.exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == cfg['head']
expected = json.loads(Path(cfg['source_manifest']).read_text())
assert source_map() == expected
OUT.mkdir()
(OUT/'executed-wrapper.py').write_bytes(Path(__file__).read_bytes())
(OUT/'config.json').write_bytes(CONFIG.read_bytes())
write(OUT/'source-before.json', expected)
env = {k: os.environ[k] for k in ['HOME', 'USER', 'LOGNAME', 'TMPDIR', 'LANG', 'LC_ALL', 'CARGO_HOME', 'RUSTUP_HOME'] if k in os.environ}
env.update(PATH='/opt/homebrew/opt/node@24/bin:' + os.environ['PATH'], UV_OFFLINE='true', CARGO_NET_OFFLINE='true', CARGO_BUILD_JOBS='2', COREPACK_ENABLE_NETWORK='0')
records = []


def run(label, argv, timeout=120, cwd=ROOT):
    exe = Path(shutil.which(argv[0], path=env['PATH']) or argv[0]).resolve(strict=True)
    rec = {'argv': argv, 'cwd': str(cwd), 'environment': dict(env), 'started_utc': now(), 'timeout_seconds': timeout, 'tool': str(exe), 'tool_sha256_before': sha(exe)}
    write(OUT/(label+'-upfront.json'), rec)
    tick = time.monotonic()
    cleanup = []
    failure = None
    with (OUT/(label+'.log')).open('xb') as output:
        process = subprocess.Popen(argv, cwd=cwd, env=dict(env), stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        def group_alive():
            process.poll()
            try:
                os.killpg(process.pid, 0)
                return True
            except ProcessLookupError:
                return False
        try:
            rec.update(owned_pid=process.pid, owned_new_session_group=process.pid)
            write(OUT/(label+'-launch.json'), {'owned_pid': process.pid, 'owned_new_session_group': process.pid, 'utc': now()})
            process.wait(timeout=timeout)
            group_deadline = time.monotonic() + 2
            while group_alive() and time.monotonic() < group_deadline:
                time.sleep(0.05)
            if group_alive():
                raise RuntimeError('Owned command group outlived its direct child')
        except BaseException as error:
            failure = error
            rec['wait_error'] = {'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()}
            for sig, seconds in [(signal.SIGTERM, 10), (signal.SIGKILL, 5)]:
                if not group_alive():
                    break
                try:
                    os.killpg(process.pid, sig)
                    cleanup.append({'signal': int(sig), 'owned_pgid': process.pid, 'utc': now()})
                except ProcessLookupError:
                    break
                deadline = time.monotonic() + seconds
                while group_alive() and time.monotonic() < deadline:
                    time.sleep(0.05)
        rec.update(exit_code=process.poll(), timeout=isinstance(failure, subprocess.TimeoutExpired), owned_leader_reaped=process.returncode is not None, owned_group_after='PRESENT' if group_alive() else 'GONE', cleanup=cleanup, cleanup_scope='OWNED_NEW_SESSION_GROUP_ONLY; descendants outside that group UNOBSERVED')
    rec.update(elapsed_seconds=time.monotonic()-tick, ended_utc=now(), tool_sha256_after=sha(exe), log_sha256=sha(OUT/(label+'.log')))
    write(OUT/(label+'-result.json'), rec)
    records.append(rec)
    write(OUT/'commands.json', records)
    print(label, rec['exit_code'], rec['elapsed_seconds'], flush=True)
    if failure is not None:
        raise failure
    assert rec['exit_code'] == 0 and rec['tool_sha256_before'] == rec['tool_sha256_after'], label


try:
    for label, argv in [('uv-version', ['uv', '--version']), ('python-version', [str(ROOT/'.venv/bin/python'), '--version']), ('node-version', ['node', '--version']), ('pnpm-version', ['pnpm', '--version']), ('rust-version', ['rustc', '--version']), ('cargo-version', ['cargo', '--version']), ('tauri-version', ['pnpm', '--filter', '@japp/desktop', 'exec', 'tauri', '--version'])]:
        run(label, argv, 30)
    wheels = OUT/'wheels'
    run('contracts-wheel', ['uv', 'build', '--wheel', '--package', 'japp-contracts', '--out-dir', str(wheels), '--offline'], 120)
    run('service-wheel', ['uv', 'build', '--wheel', '--package', 'orchestrator', '--out-dir', str(wheels), '--offline'], 120)
    contracts = wheels/'japp_contracts-0.0.1-py3-none-any.whl'
    service = wheels/'orchestrator-0.0.1-py3-none-any.whl'
    requirements = Path('/tmp/japp-m03-w02-service-proposal/proof/wheel-runtime-requirements.txt')
    write(OUT/'build-inputs.json', {'wheels': {str(p): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in [contracts, service]}, 'runtime_requirements': {'path': str(requirements), 'sha256': sha(requirements)}, 'inner_builder_environment': 'Fresh curated environment and cache, hash-required installs; outer UV_OFFLINE is not inherited, so pinned dependency downloads are possible.'})
    payload = OUT/'fresh-payload'
    run('runtime-build', [str(ROOT/'.venv/bin/python'), 'scripts/build-service-runtime.py', '--contracts-wheel', str(contracts), '--contracts-sha256', sha(contracts), '--orchestrator-wheel', str(service), '--orchestrator-sha256', sha(service), '--runtime-requirements', str(requirements), '--python', '/Users/tanishkalwad/.local/share/uv/python/cpython-3.12.13-macos-aarch64-none/bin/python3.12', '--uv', '/Users/tanishkalwad/.local/bin/uv', '--work-dir', str(OUT/'runtime-build'), '--destination', str(payload), '--target', 'aarch64-apple-darwin'], 1800)
    fresh = tree(payload)
    write(OUT/'fresh-payload.json', fresh)
    stage = ROOT/'apps/desktop/src-tauri/runtime-payload'
    write(OUT/'prior-stage.json', tree(stage))
    assert (stage/'.gitignore').read_bytes() == (payload/'.gitignore').read_bytes()
    stage.rename(OUT/'prior-root-stage')
    shutil.copytree(payload, stage, copy_function=shutil.copy2)
    assert tree(stage) == fresh
    write(OUT/'staged-before-build.json', tree(stage))
    app = ROOT/'apps/desktop/src-tauri/target/debug/bundle/macos/Desktop App.app'
    if app.exists():
        app.rename(OUT/'prior-root-app')
    assert not app.exists()
    run('app-build', ['pnpm', '--filter', '@japp/desktop', 'exec', 'tauri', 'build', '--debug', '--bundles', 'app', '--config', str(ROOT/'packaging/macos-local.config.json'), '--ci', '--', '--locked', '--offline'], 900)
    image = tree(app)
    write(OUT/'app-upfront.json', image)
    saved = OUT/'app-upfront'/app.name
    saved.parent.mkdir()
    run('retain-app-image', ['/bin/cp', '-cR', str(app), str(saved)], 180, OUT)
    assert tree(saved) == image
    write(OUT/'staged-after-build.json', tree(stage))
    write(OUT/'packaged-runtime-after-signing.json', tree(app/'Contents/Resources/runtime'))
    # This equality is checked before any launch and is never repaired by rehashing.
    assert tree(stage) == fresh == tree(app/'Contents/Resources/runtime'), 'Signing/package changed compile-bound runtime'
    run('static-package', [str(ROOT/'.venv/bin/python'), 'scripts/macos_package.py', '--app', str(app), '--staged-runtime', str(stage), '--compiled-manifest-sha256', sha(stage/'manifest.json'), '--output', str(OUT/'static-inspection')], 120)
    run('codesign-display', ['/usr/bin/codesign', '--display', '--verbose=4', str(app)], 30)
    run('codesign-entitlements', ['/usr/bin/codesign', '--display', '--entitlements', ':-', str(app)], 30)
    macho = []
    magics = {b'\xfe\xed\xfa\xce', b'\xce\xfa\xed\xfe', b'\xfe\xed\xfa\xcf', b'\xcf\xfa\xed\xfe', b'\xca\xfe\xba\xbe', b'\xbe\xba\xfe\xca', b'\xca\xfe\xba\xbf', b'\xbf\xba\xfe\xca'}
    for rel in image:
        p = app/rel
        with p.open('rb') as f:
            magic = f.read(4)
        if magic in magics:
            macho.append(rel)
            n = len(macho)
            run(f'macho-{n:03}-file', ['/usr/bin/file', '-b', str(p)], 30)
            run(f'macho-{n:03}-arch', ['/usr/bin/lipo', '-archs', str(p)], 30)
            run(f'macho-{n:03}-deps', ['/usr/bin/otool', '-L', str(p)], 30)
            run(f'macho-{n:03}-loads', ['/usr/bin/otool', '-l', str(p)], 30)
    write(OUT/'macho-files.json', macho)
    after = source_map()
    write(OUT/'source-after.json', after)
    assert after == expected
    assert tree(app) == image and tree(saved) == image and tree(stage) == fresh
    write(OUT/'closure.json', {'scope': 'Fresh current Mac arm64 wheels/runtime/ad-hoc app build and static inspector only. No app/service launch, GUI, lifecycle, cross-platform or milestone credit.', 'source_files': len(expected), 'source_unchanged': True, 'runtime_files': len(fresh), 'app_files': len(image), 'macho_files': len(macho), 'upfront_saved_app': str(saved), 'app': str(app), 'inner_builder_offline_enforced': False, 'whole_descendant_timeout_containment': False, 'dependency_resolution_review_pending': True})
    print('CLOSED current fresh Mac build/static commands; NOT_LAUNCHED; dependency paths require inspection', flush=True)
except BaseException as error:
    write(OUT/'failure.json', {'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc(), 'scope': 'Failure retained; no launch or acceptance. Owned partial outputs/stage retained for inspection.'})
    raise
