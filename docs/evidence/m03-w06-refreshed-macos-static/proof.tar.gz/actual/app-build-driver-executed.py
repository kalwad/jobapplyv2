from pathlib import Path
from datetime import UTC,datetime
import hashlib,json,os,signal,shutil,stat,subprocess,time
ROOT=Path('/Users/tanishkalwad/jobapplyv2')
OUT=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/mac-package-refreshed')
def tree(root):
    result={}
    for p in sorted(root.rglob('*')):
        s=p.lstat()
        if stat.S_ISDIR(s.st_mode):continue
        assert stat.S_ISREG(s.st_mode) and not p.is_symlink()
        result[p.relative_to(root).as_posix()]={'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
    return result
def source():
    result={}
    for name in subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).split(b'\0'):
        if name:
            p=ROOT/os.fsdecode(name);s=p.lstat();assert stat.S_ISREG(s.st_mode)
            result[os.fsdecode(name)]={'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
    return result
def git(arg):return subprocess.check_output(['git',*arg],cwd=ROOT,text=True).strip()
assert git(['status','--porcelain'])==''
assert not (OUT/'app-build-results.json').exists()
(OUT/'app-build-driver-executed.py').write_bytes(Path(__file__).read_bytes())
before={'source':source(),'runtime':tree(ROOT/'apps/desktop/src-tauri/runtime-payload'),'git_status':git(['status','--porcelain']),'commit':git(['rev-parse','HEAD']),'tree':git(['rev-parse','HEAD^{tree}'])}
(OUT/'app-build-before.json').write_text(json.dumps(before,indent=2)+'\n')
env=dict(os.environ);env['PATH']='/opt/homebrew/opt/node@24/bin:'+env['PATH']
records=[]
def run(name,argv,budget):
    tick=time.monotonic();start=datetime.now(UTC).isoformat()
    with (OUT/(name+'.log')).open('wb') as f:
        child=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
        sigs=[];expired=False
        try:code=child.wait(timeout=budget)
        except subprocess.TimeoutExpired:
            expired=True
            for sig in [signal.SIGTERM,signal.SIGKILL]:
                try:os.killpg(child.pid,sig);sigs.append(sig.name)
                except ProcessLookupError:pass
                if sig==signal.SIGTERM:time.sleep(1)
            code=child.wait(timeout=10)
    try:os.killpg(child.pid,0);group='PRESENT_AFTER_REAP_NO_SIGNAL'
    except ProcessLookupError:group='ABSENT'
    row={'name':name,'argv':argv,'cwd':str(ROOT),'start_utc':start,'end_utc':datetime.now(UTC).isoformat(),'seconds':time.monotonic()-tick,'exit_code':code,'timeout':expired,'direct_child_reaped':child.returncode is not None,'observed_group':group,'outer_cleanup_signals':sigs}
    records.append(row);(OUT/'app-build-results.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
    if code!=0 or expired or group!='ABSENT':raise SystemExit(1)
run('app-build',['pnpm','--filter','@japp/desktop','tauri','build','--debug','--config','../../packaging/macos-local.config.json'],600)
built=ROOT/'apps/desktop/src-tauri/target/debug/bundle/macos/Desktop App.app'
launch=OUT/'launch space 应用/Desktop App.app'
assert not launch.exists();launch.parent.mkdir(exist_ok=False);shutil.copytree(built,launch)
assert tree(built)==tree(launch)
manifest=hashlib.sha256((ROOT/'apps/desktop/src-tauri/runtime-payload/manifest.json').read_bytes()).hexdigest()
run('static-inspection',['/Users/tanishkalwad/.local/share/uv/python/cpython-3.12.13-macos-aarch64-none/bin/python3.12',str(ROOT/'scripts/macos_package.py'),'--app',str(launch),'--staged-runtime',str(ROOT/'apps/desktop/src-tauri/runtime-payload'),'--output',str(OUT/'static-inspection'),'--compiled-manifest-sha256',manifest],60)
after={'source':source(),'runtime':tree(ROOT/'apps/desktop/src-tauri/runtime-payload'),'git_status':git(['status','--porcelain']),'commit':git(['rev-parse','HEAD']),'tree':git(['rev-parse','HEAD^{tree}'])}
(OUT/'app-build-after.json').write_text(json.dumps(after,indent=2)+'\n')
closure={'end_utc':datetime.now(UTC).isoformat(),'source_count':len(before['source']),'runtime_count':len(before['runtime']),'source_runtime_modes_status_head_tree_unchanged':before==after,'app_files':len(tree(launch)),'app_bytes':sum(x['bytes'] for x in tree(launch).values()),'launch_app':str(launch),'compiled_manifest_sha256':manifest,'gui_lifecycle':'PENDING'}
(OUT/'app-build-closure.json').write_text(json.dumps(closure,indent=2)+'\n');print(json.dumps(closure),flush=True)
raise SystemExit(0 if before==after else 1)
