from pathlib import Path
from datetime import UTC, datetime
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
OUT = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/mac-package-refreshed')
PY = '/Users/tanishkalwad/.local/share/uv/python/cpython-3.12.13-macos-aarch64-none/bin/python3.12'
UV = '/Users/tanishkalwad/.local/bin/uv'
OUT.mkdir(exist_ok=False)
(OUT / 'runtime-driver-executed.py').write_bytes(Path(__file__).read_bytes())

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

inputs = ['uv.lock', 'scripts/build-service-runtime.py', 'scripts/wheel_only_runtime_lock.py', 'scripts/service-build-tools.requirements.lock', 'packaging/native-project-wheels.json', 'packaging/native-project-wheels/japp_contracts-0.0.1-py3-none-any.whl', 'packaging/native-project-wheels/orchestrator-0.0.1-py3-none-any.whl']
before = {p: {'bytes': (ROOT/p).stat().st_size, 'sha256': digest(ROOT/p)} for p in inputs}
(OUT/'runtime-selected-inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
commands=[]

def run(label, argv, budget):
    tick=time.monotonic()
    row={'label':label,'argv':argv,'cwd':str(ROOT),'start_utc':datetime.now(UTC).isoformat(),'budget_seconds':budget}
    with (OUT/(label+'.log')).open('wb') as f:
        child=subprocess.Popen(argv,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
        signals=[]
        timed_out=False
        try:
            code=child.wait(timeout=budget)
        except subprocess.TimeoutExpired:
            timed_out=True
            for sig in [signal.SIGTERM,signal.SIGKILL]:
                try: os.killpg(child.pid,sig);signals.append(sig.name)
                except ProcessLookupError:pass
                if sig==signal.SIGTERM:time.sleep(1)
            code=child.wait(timeout=10)
    try:os.killpg(child.pid,0); group='PRESENT_AFTER_REAP_NO_SIGNAL'
    except ProcessLookupError:group='ABSENT'
    row.update(exit_code=code,timeout=timed_out,seconds=time.monotonic()-tick,end_utc=datetime.now(UTC).isoformat(),direct_child_reaped=child.returncode is not None,observed_group=group,outer_cleanup_signals=signals,log_sha256=digest(OUT/(label+'.log')))
    commands.append(row)
    (OUT/'runtime-driver-results.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if code!=0 or timed_out or group!='ABSENT':raise SystemExit(1)

run('runtime-export',[UV,'export','--locked','--no-dev','--no-emit-workspace','--format','requirements-txt','--output-file',str(OUT/'runtime-export.txt')],60)
run('runtime-wheel-lock',[PY,str(ROOT/'scripts/wheel_only_runtime_lock.py'),'--lock',str(ROOT/'uv.lock'),'--exported',str(OUT/'runtime-export.txt'),'--destination',str(OUT/'runtime-wheels.requirements.lock'),'--receipt',str(OUT/'runtime-lock-receipt.json')],60)
wheels=json.loads((ROOT/'packaging/native-project-wheels.json').read_text())
run('native-runtime-build',[PY,str(ROOT/'scripts/build-service-runtime.py'),'--contracts-wheel',str(ROOT/wheels['contracts']['path']),'--contracts-sha256',wheels['contracts']['sha256'],'--orchestrator-wheel',str(ROOT/wheels['orchestrator']['path']),'--orchestrator-sha256',wheels['orchestrator']['sha256'],'--runtime-requirements',str(OUT/'runtime-wheels.requirements.lock'),'--python',PY,'--uv',UV,'--work-dir',str(OUT/'runtime-build'),'--destination',str(OUT/'runtime-payload'),'--target','aarch64-apple-darwin'],1900)
after={p:{'bytes':(ROOT/p).stat().st_size,'sha256':digest(ROOT/p)} for p in inputs}
(OUT/'runtime-selected-inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
closure={'end_utc':datetime.now(UTC).isoformat(),'selected_inputs_unchanged':before==after,'all_three_driver_phases_pass':len(commands)==3,'manifest_sha256':digest(OUT/'runtime-payload/manifest.json'),'scope':'Selected native-runtime build inputs only; no complete-current-tree or GUI acceptance claim'}
(OUT/'runtime-driver-closure.json').write_text(json.dumps(closure,indent=2)+'\n')
print(json.dumps(closure),flush=True)
raise SystemExit(0 if before==after else 1)
