from pathlib import Path
import hashlib,json,plistlib,stat,zipfile
R=Path('/Users/tanishkalwad/jobapplyv2');B=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');V=B/'mac-package-refreshed';O=B/'mac-package-refreshed-independent-review'
def j(p):return json.loads(p.read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while d:=f.read(1024*1024):h.update(d)
 return h.hexdigest()
def inventory(root):
 result={}
 for p in sorted(root.rglob('*')):
  s=p.lstat()
  if stat.S_ISDIR(s.st_mode):continue
  assert stat.S_ISREG(s.st_mode) and not p.is_symlink()
  result[p.relative_to(root).as_posix()]={'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'sha256':sha(p)}
 return result
checks=[]
def ck(name,value,detail=None):checks.append({'name':name,'pass':bool(value),'detail':detail})
G=j(B/'ci-204bc06/immutable-git-source-sha256.json');git=G['files'];ck('Immutable2070source bound204bc/tree5b5b',G['commit']=='204bc06a374631f4b40d4fc382f573a77ef9242a' and G['tree']=='5b5bfeda09b60654adce335e0e21cd9ad056e120' and len(git)==2070)
a=j(V/'runtime-selected-inputs-before.json');z=j(V/'runtime-selected-inputs-after.json');ck('Sevenselected runtime input endpoints equal',len(a)==7 and a==z)
for name,pin in a.items():ck('Runtime input belongs to immutable204bc '+name,pin['bytes']==git[name]['bytes'] and pin['sha256']==git[name]['sha256'])
rc=j(V/'runtime-driver-closure.json');rr=j(V/'runtime-driver-results.json');ck('Three actual runtime driver phases',len(rr)==3 and [x['label'] for x in rr]==['runtime-export','runtime-wheel-lock','native-runtime-build'])
for row in rr:
 ck(row['label']+' zeroexit/reaped/groupAbsent/no timeout/signals',row['exit_code']==0 and row['direct_child_reaped'] and row['observed_group']=='ABSENT' and not row['timeout'] and not row['outer_cleanup_signals'])
 ck(row['label']+' rawlog digest',sha(V/(row['label']+'.log'))==row['log_sha256'])
ck('Selected input closure honest scope',rc['selected_inputs_unchanged'] and rc['all_three_driver_phases_pass'] and 'Selected' in rc['scope'])
build=j(V/'runtime-build/build-proof.json');ck('Executed builder pin matches immutable source',sha(V/'runtime-build/builder-executed.py')==build['builder_script_sha256']==git['scripts/build-service-runtime.py']['sha256'])
ck('Six inner runtime build phases',len(build['commands'])==6 and [x['label'] for x in build['commands']]==['01-venv','02-runtime-install','03-build-install','04-wheels-install','05-resolved-pins','06-native-build'])
for row in build['commands']:
 ck(row['label']+' zeroexit chronological',row['exit_code']==0 and row['start_utc']<row['end_utc'])
 for channel in ['stdout','stderr']:ck(row['label']+' '+channel+' digest',sha(V/'runtime-build'/(row['label']+'.'+channel))==row[channel+'_sha256'])
 ck(row['label']+' explicit selectedenv',row['environment']['PATH']=='/bin:/usr/bin' and row['environment']['PYTHONNOUSERSITE']=='1' and row['environment']['PYTHONHASHSEED']=='0')
ck('Runtime and build dependency installs requirehashes',all('--require-hashes' in row['argv'] for row in build['commands'][1:3]))
ck('Projectwheel install nodeps', '--no-deps' in build['commands'][3]['argv'])
lock=j(V/'runtime-lock-receipt.json');ck('Wheel lock binds exact committed uvlock',lock['uv_lock_sha256']==git['uv.lock']['sha256'])
ck('Wheel lock binds actual export',lock['actual_export_sha256']==sha(V/'runtime-export.txt'))
ck('Wheel lock has14packages noresolve/sdist',len(lock['packages'])==14 and lock['resolution_performed'] is False and lock['sdist_hashes_authorized']==0)
ck('Runtime requirement exact across copiedwork input',lock['wheel_only_sha256']==sha(V/'runtime-wheels.requirements.lock')==sha(V/'runtime-build/inputs/runtime-wheels.requirements.lock')==build['source_inputs']['runtime_requirements_sha256'])
ck('Buildrequirement exact committed input',sha(V/'runtime-build/inputs/service-build-tools.requirements.lock')==build['source_inputs']['build_requirements_sha256']==git['scripts/service-build-tools.requirements.lock']['sha256'])
wheel=j(R/'packaging/native-project-wheels.json');sources={}
for name in ['contracts','orchestrator']:
 row=wheel[name];p=V/'runtime-build/inputs'/Path(row['path']).name
 ck(name+' purewheel pin selectedsource',sha(p)==row['sha256']==git[row['path']]['sha256']==build['source_inputs'][name+'_wheel_sha256'])
 with zipfile.ZipFile(p) as zf:
  names=zf.namelist();ck(name+' wheel unique relative regular names',len(names)==len(set(names)) and all(not n.startswith('/') and '..' not in Path(n).parts and not stat.S_ISLNK(i.external_attr>>16) for n,i in zip(names,zf.infolist(),strict=True)))
  if name=='orchestrator':
   members=[n for n in names if n.startswith('orchestrator/') and (n.endswith('.py') or n.endswith('/py.typed'))]
   expected={n.removeprefix('services/orchestrator/src/'):v for n,v in git.items() if n.startswith('services/orchestrator/src/orchestrator/') and (n.endswith('.py') or n.endswith('/py.typed'))}
   ck('Current18package source/resource wheel coverage',len(members)==len(expected)==18 and set(members)==set(expected))
   for n in members:
    b=zf.read(n);pin=expected[n];same=len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'];ck('Current wheel source byte match '+n,same);sources[n]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
ck('All selected wheel source input records match copied work',build['source_inputs']['contracts_wheel_sha256']==wheel['contracts']['sha256'] and build['source_inputs']['orchestrator_wheel_sha256']==wheel['orchestrator']['sha256'])
adopt=j(V/'runtime-adoption.json');before=j(V/'app-build-before.json');after=j(V/'app-build-after.json');appclose=j(V/'app-build-closure.json');apprecords=j(V/'app-build-results.json')
ck('Current clean app before/after source runtime modes status HEADtree equal',before==after and before['git_status']=='' and before['commit']==G['commit'] and before['tree']==G['tree'])
ck('All2070actualsource match immutable Git sizes/hashes/executablebits',set(before['source'])==set(git) and all(x['bytes']==git[n]['bytes'] and x['sha256']==git[n]['sha256'] and bool(x['mode']&0o111)==(git[n]['git_mode']=='100755') for n,x in before['source'].items()))
ck('Actual appbuild source2070 runtime40',appclose['source_count']==len(before['source'])==2070 and appclose['runtime_count']==len(before['runtime'])==40 and appclose['source_runtime_modes_status_head_tree_unchanged'])
ck('Two actual app phases',len(apprecords)==2 and [x['name'] for x in apprecords]==['app-build','static-inspection'])
for row in apprecords:ck(row['name']+' zeroexit/reaped/groupAbsent/no timeout/signals',row['exit_code']==0 and row['direct_child_reaped'] and row['observed_group']=='ABSENT' and not row['timeout'] and not row['outer_cleanup_signals'])
ck('Freshruntime adoption matches appbuild runtime',adopt['fresh']==before['runtime'] and adopt['same_tracked_gitignore'] and adopt['runtime_count']==40)
manifest=j(V/'runtime-payload/manifest.json');manifestsha=sha(V/'runtime-payload/manifest.json')
ck('Actual compiled manifest ad2 matches all receipts',manifestsha==rc['manifest_sha256']==adopt['new_manifest_sha256']==appclose['compiled_manifest_sha256']=='ad2c977971924201a3d1eb7b8c6631db2c8739831f5fe131f2448e0b7914abd9')
ck('Actual manifest arm64 target39declared payload records',manifest['target']=='aarch64-apple-darwin' and len(manifest['files'])==39 and manifest['source_inputs']==build['source_inputs'])
inspect=j(V/'static-inspection/inspection.json');ck('Executed inspector matches immutable source',inspect['executed_inspector_sha256']==sha(V/'static-inspection/inspector-executed.py')==git['scripts/macos_package.py']['sha256'])
ck('Static inspector explicitly lifecyclepending',inspect['status']=='PACKAGE_STATIC_INSPECTION_PASS_LIFECYCLE_PENDING' and inspect['bytes_unchanged_during_signature_inspection'])
ck('App43before/after staticinspection byte inventories same',len(inspect['files'])==43 and inspect['files']==inspect['baseline_app_files'])
ck('Stage40before/afterstatic and embedded runtime same',len(inspect['stage_files'])==len(inspect['runtime_files'])==40 and inspect['baseline_stage_files']==inspect['stage_files']==inspect['runtime_files'])
ck('Manifest39payload plusmanifest exactly40runtime',sorted(manifest['files'],key=lambda x:x['path'])==[x for x in inspect['runtime_files'] if x['path']!='manifest.json'])
sign=inspect['signature_inspection'];ck('Actual deepstrict signatureverification PASS',sign['argv'][:4]==['/usr/bin/codesign','--verify','--deep','--strict'] and sign['exit_code']==0 and not sign['timeout'])
ck('Codesign raw channels hash exact',sha(V/'static-inspection/codesign.stdout')==sign['stdout_sha256'] and sha(V/'static-inspection/codesign.stderr')==sign['stderr_sha256'])
app=Path(appclose['launch_app']);appnow=inventory(app);stagenow=inventory(V/'runtime-payload');runtime=inventory(R/'apps/desktop/src-tauri/runtime-payload')
ck('Actual app currently43regular files/80530670bytes',len(appnow)==appclose['app_files']==43 and sum(x['bytes'] for x in appnow.values())==appclose['app_bytes']==80530670)
ck('Actual app current sizehash matches staticinspection', {n:{'bytes':v['bytes'],'sha256':v['sha256']} for n,v in appnow.items()}=={x['path']:{'bytes':x['bytes'],'sha256':x['sha256']} for x in inspect['files']})
ck('Freshstage current40records equals beforepackage runtime modes',stagenow==before['runtime'])
ck('Canonical runtime currently40records equals tested runtime modes',runtime==before['runtime'])
ck('Packagedruntime currently40records equals staged modes',inventory(app/'Contents/Resources/runtime')==before['runtime'])
info=plistlib.loads((app/'Contents/Info.plist').read_bytes());ck('Actual plist bundleID/macOS14',info['CFBundleIdentifier']=='dev.jobapply.desktop' and info['LSMinimumSystemVersion']=='14.0')
main=app/'Contents/MacOS'/info['CFBundleExecutable'];ck('Actual main executable currentbe0474',sha(main)=='be0474f4a05f1315fcef71327021c830a17811f2e8a45e3d5d1233f1d7580596' and bool(main.stat().st_mode&0o111))
entry=manifest['entrypoint'];ck('Stage actual entrypoint matches manifestreceipt',sha(V/'runtime-payload'/entry)==j(V/'runtime-build/staging-result.json')['entrypoint_sha256'])
gui=j(V/'gui-launch-attempt-1.json');ck('Actual firstGUIattempt locked noPASS',gui['outcome']=='MAC_LOCKED_GUI_NOT_OBSERVED' and not gui['gui_pass'] and gui['no_alternate_unlock_route_used'] and gui['native_package_static_scope_only'])
ck('No failed checks',all(x['pass'] for x in checks))
report={'scope':'INDEPENDENT_REFRESHED_LOCAL_MACOS_RUNTIME_AND_APP_STATIC_DATA_REVIEW_NO_GUI_ACCEPTANCE','verdict':'CLEAR' if all(x['pass'] for x in checks) else 'HOLD','checks':checks,'build_runtime_context':'Runtime was built23:54 before final204bc commit with seven selected input guards. Those seven exact inputs and18orchestrator source/resource wheel members are bound retrospectively to immutable204bc; no entire-source runtime-build upfront identity is claimed.','app_context':{'head':before['commit'],'tree':before['tree'],'source_count':2070,'runtime_count':40,'app_files':43,'app_bytes':appclose['app_bytes'],'main_sha256':sha(main),'manifest_sha256':manifestsha,'launch_app':str(app)},'runtime_driver_phases':rr,'app_driver_phases':apprecords,'wheel_source_matches':sources,'actual_current_app_inventory':appnow,'gui_attempt':gui,'limits':['No fresh GUI/Ready/Close/Quit/service crash or forced-parent lifecycle PASS; first current GUI attempt records MacLOCKED.','Old35b GUI evidence remains historical and is not transferred to this changed main executable.','Localdebug/ad-hoc signature verification is not notarization/distribution/Gatekeeper acceptance.','Three runtime driver and two app driver outer groups are observed; six inner commands do not have independent group/reap receipts.','Runtime full permission modes are retained; static app byte baselines do not record complete app permission-mode endpoints. Current observed app modes are a separate after-only read.','Hash-locked wheels and minimal recorded build env are not complete interpreter/SDK/shared-library closure or network-offline proof.','No frozen-payload execution or generation/model qualification is performed by this review or inferred from purewheel source coverage.','No foreign-platform GUI/certification or milestone/release acceptance.'],'states':{'M03-W06':'IN_PROGRESS','M03':'IN_PROGRESS','verified':38,'release':'NOT_READY'}}
(O/'actual-data-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'verdict':report['verdict'],'checks':len(checks),'passed':sum(x['pass'] for x in checks),'failed':[x['name'] for x in checks if not x['pass']],'wheel_sources':len(sources)}))
