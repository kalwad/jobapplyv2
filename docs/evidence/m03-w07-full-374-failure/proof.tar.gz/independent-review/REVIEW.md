# Independent actual clean-full review: failure confirmed

Verdict: **CONFIRMED_ACTUAL_FULL_FAILURE_PYTHON_OPERATION_ORDER**. The actual clean aggregate failed. Doctor exits zero; verification exits one. The final matrix has **nineteen ACTIVE suites passing and Python failing**. Python reports **one failed, 2,787 passed in 444.92 seconds**. The 4,746 passing record-consistency joins in this review establish that these results are accurately bound and retained; they do not turn the failed run into a pass.

The failed node is `scripts/tests/test_ubuntu_gnome_boundaries.py::test_imports_do_not_load_platform_gi_or_spawn_actor`. Its existing assertion at line 72 requires `guest.OPERATIONS[-1] == "finish"`; the actual observed value is `shell_check_observe`. Exact immutable source shows the base operations tuple ending in `finish`, followed by `OPERATIONS += SHELL_OPERATIONS`. The appended operations therefore break this existing terminal-order contract. This review did not import or execute the guest helper and makes no further claim about an unobserved native dispatch outcome. The original failure, test and source remain unchanged; a future correction needs a separate source/revision and fresh validation.

## Immutable source and physical endpoints

The tested commit is `374b6fe484b5dd82c4a7fa1d751a77369ec79431`, tree `a77820bb5430ec8bebcfb17c8010b0764011fabe`, with **2,338 tracked source files**. `immutable-git-source-sha256.json`, SHA-256 `60f2d16e4b16012462cd73a0bb591e9cf88587f3ff57fc2c3171c9b688dbf475`, independently commits every local Git blob's size, SHA-256, object ID and regular/executable Git class. All 572,407,788 blob bytes have verified Git SHA-1 framing. The commit object's framing and exact tree field are also verified. The map was delivered frozen for CI reuse and was not rewritten during this review.

The exact exported Python catalog body has SHA-256 `691537e00c2b306233b17cc77a6ed79d5c1122ca87d492f5b4adaf4b78a244db`; its size, Git blob framing and 2,786 common plus two POSIX IDs are bound to the immutable source. The total of 2,788 agrees with the actual aggregate's pass/fail total, and the failed node is in that catalog. The condensed passing-test log is not represented as an individual-ID execution proof for every passing case.

Actual physical source full modes are recorded separately from Git's normalized permission classes. Independent initial and final observations match all 2,338 source bodies/full modes and all forty runtime-payload bodies/full modes. Both have clean status, the expected HEAD/tree, and equal optional index-content pins. The root's full before/after snapshots independently match, including clean status and immediate end-context commit/tree equality. The final independent observation is at **2026-10-29T21:03:13.396564+00:00**. These are finite endpoints, not an assertion of no transient writes or any later canonical state.

Eight reviewer-owned read-only Git children are recorded reaped with exit zero, original groups absent and no signals. Git optional locks and filesystem monitoring were disabled for those reads. No Git/ref/index writes were requested. The body map proves local immutable content; it does not by itself establish hosted CI terminal results or platform execution.

## Actual campaign and custody

The exact executed wrapper equals `run-clean-full-corrected-current-v1.py`. It starts clean, snapshots source/runtime, launches doctor and verification sequentially, records their real exits, checks each original group after direct-child reaping, and retains end snapshots even after failure. The closed records are:

- Doctor: exit 0, 7.888529749936424 seconds, direct child reaped, original group absent.
- Verification: exit 1, 1,326.053786084056 seconds, direct child reaped, original group absent.

No timeout or cleanup signal occurred. Closure is **2026-10-29T21:01:36.443560+00:00**. `all_commands_exit_zero` correctly remains false. The matrix contains all twenty frozen registry suite IDs, with only Python marked FAIL. The failure is not relabeled as a skip, expected failure or observer classification issue. The failed aggregate still ran its subsequent Rust, portability, traceability, status and integrity suites; those recorded passing states are retained without implying aggregate success.

Custody conclusions are bounded to the recorded outer command groups and this review's owned readers. They do not assert a global process inventory or independently certify every nested browser/native actor. No extra verification, test, browser or native actor was launched by this review.

## Actual visual outputs retained and inspected

While verification was still running, a separate strict inert observer required an anchored actual `17 passed (...)` visual summary followed by the actual Python command. It retained **all 67** original visual outputs, with equal source/copy byte and full-mode endpoints: nineteen PNG capture paths, fourteen catalog metadata records, thirty-three exact attachment aliases and one run marker. The root's separate 33-file retention and complete 67-entry inventory match this copy. All nineteen PNG paths were visually inspected; they contain fifteen unique PNG bodies.

The captures show readable navigation, route headings, version values, cards and truthful unavailable-feature states at the wide/narrow layouts and the browser text-resize scenario, without visible overlap or clipped text in the full-page views. One 640x2420 resize capture was displayed downsampled to 542x2048; its entire image was inspected, without asserting a native ink-size ratio from that view. Narrow layouts intentionally stack vertically and retain vertical scrolling.

`visual-review.json` records **419** integrity, artifact, selected-source and metadata checks. All fourteen metadata records bind the exact tested commit/tree and their twenty selected source bodies. PNG dimensions, sizes and hashes match. Their existing state remains `CAPTURED_NOT_REVIEWED`, `NOT_APPROVED`, with `frozen_design_system=false`, `actual_native_ipc=false` and `native_service_proven=false`. This independent finite visual review does not change those parent fields or grant design approval. The Windows user-agent fixture does not turn the recorded Darwin host into a native Windows execution.

The visual marker and seventeen passing visual cases establish that browser fixture slice only. They do not qualify native desktop/service behavior, a default-GNOME or Windows 11 environment, feature completeness, native 200-percent measurements, accessibility readers or a successful full aggregate. Matching historical PNG bodies is reproducibility evidence, not proof that the historical or current aggregate passed.

## Reader history and remaining work

An initial tool-owned bounded visual wait and two subsequently owned waits returned WAIT before the required markers; no stale files were retained as current. Their sources and available raw receipts are preserved. A separate stricter observer source was used for successful retention, preserving the earlier source unchanged. All three measured observer children are reaped, groups absent, with no signals/timeouts and an unchanged immutable map. Nonexecuting inspection/progress-message corrections are recorded in `history/observer-notes.md`.

No canonical source, original cache, runtime, Git ref or held workspace was changed. No unknown cache was unmarshaled and no application helper was executed. CI's separate direct-source-versus-merge observer classification issue remains outside this local failure verdict; actual hosted outcomes need their own closed-data review. The separately sealed wheel metadata peer review is also independent of this result and does not activate dependencies.

The required next work is the separately prepared operation-order correction and a new clean aggregate/CI campaign. This packet preserves the failed S374b6fe run permanently. It grants no milestone, gate, native-platform or finished-product completion claim.
