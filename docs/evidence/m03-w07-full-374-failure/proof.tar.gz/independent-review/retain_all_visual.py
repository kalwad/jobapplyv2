"""Bounded inert visual-output observer; does not launch browser or source."""
from pathlib import Path
from datetime import UTC, datetime
import hashlib,json,stat,time
H=Path(__file__).resolve().parent
F=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/full-374b6fe')
S=Path('/Users/tanishkalwad/jobapplyv2/test-results/visual')
deadline=time.monotonic()+50
while True:
    log=(F/'verify.log').read_text(errors='replace')
    if '17 passed' in log and '$ uv run pytest -c pyproject.toml' in log:break
    if time.monotonic()>=deadline:
        print(json.dumps({'state':'WAITING_FOR_ACTUAL_VISUAL17_AND_PYTHON_START','full_verdict':None}));raise SystemExit(0)
    time.sleep(1)
def record(p,root):
    s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink();b=p.read_bytes()
    return {'path':p.relative_to(root).as_posix(),'bytes':len(b),'full_mode':s.st_mode,'sha256':hashlib.sha256(b).hexdigest()}
paths=sorted(p for p in S.rglob('*') if p.is_file());rows=[record(p,S) for p in paths]
assert len(rows)==67
selected=[r for r in rows if 'attachments' not in Path(r['path']).parts and r['path']!='.last-run.json']
aliases=[r for r in rows if 'attachments' in Path(r['path']).parts]
assert len(selected)==len(aliases)==33 and sum(r['path'].endswith('.png') for r in selected)==19 and sum(r['path'].endswith('.json') for r in selected)==14
assert all(r['sha256'] in {q['sha256'] for q in selected} for r in aliases)
D=H/'all-visual';D.mkdir(exist_ok=False)
for p,r in zip(paths,rows,strict=True):
    q=D/r['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes());q.chmod(stat.S_IMODE(r['full_mode']));assert record(q,D)==r
assert [record(p,S) for p in paths]==rows
result={'utc':datetime.now(UTC).isoformat(),'actual_visual17_and_Python_start_seen':True,'full_closed_at_observation':(F/'closure.json').exists(),'full_verdict':None,'all_original_files':rows,'selected_count':33,'alias_count':33,'marker_count':1,'selected_png':19,'selected_metadata':14,'all_aliases_exact_duplicate_bodies':True,'all_original_copy_endpoint_bytes_fullmodes_equal':True,'scope':'Inert file retention after actual visual suite/Python markers; no full-outcome, native-GUI or browser-custody inference.'}
(H/'visual-retention.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='all_original_files'}))
