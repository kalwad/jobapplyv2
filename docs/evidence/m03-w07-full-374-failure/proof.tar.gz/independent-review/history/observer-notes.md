# Reader history

An early read-only inspection attempted `load_config.py`; the actual function resides in the frozen `collect-next-head.py` and was subsequently read there without import/execution. A human-readable progress message briefly gave the total blob bytes with an incorrect commit-size subtraction; the exact sum was immediately checked and corrected to572407788. The immutable map itself was always correct and unchanged.

The first visual wait ran through the tool-owned interpreter and returned WAIT after its bounded50seconds; no independent interpreterPID/group was recorded. Two later owned attempts have complete WAIT stdout/receipts. No current captures were copied until the distinct strict observer saw an anchored actual17-passed visual line followed by Python start. Earlier sources remain unchanged. No wait is represented as a visual or full PASS. `source-phase-status.json` is the earlier preparation-complete/full-pending snapshot, not the final verdict.
