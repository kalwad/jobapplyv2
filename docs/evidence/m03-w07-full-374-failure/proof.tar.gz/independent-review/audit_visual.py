"""Inert all67/19PNG/14metadata source and visual-review records."""
from pathlib import Path
import hashlib,json,struct
H=Path(__file__).resolve().parent
ret=json.loads((H/'visual-retention.json').read_text());mapping=json.loads((H/'immutable-git-source-sha256.json').read_text())
rows=ret['all_original_files'];D=H/'all-visual';checks=[]
def ck(n,v):checks.append({'name':n,'pass':bool(v)});assert v,n
for r in rows:
    p=D/r['path'];b=p.read_bytes();ck('retained fullmode/body '+r['path'],len(b)==r['bytes'] and p.stat().st_mode==r['full_mode'] and hashlib.sha256(b).hexdigest()==r['sha256'])
selected=[r for r in rows if 'attachments' not in Path(r['path']).parts and r['path']!='.last-run.json']
pngs=[r for r in selected if r['path'].endswith('.png')];metas=[r for r in selected if r['path'].endswith('.json')]
ck('all67 composition',len(rows)==67 and len(selected)==33 and len(pngs)==19 and len(metas)==14)
ck('marker actual passed',json.loads((D/'.last-run.json').read_text())=={'status':'passed','failedTests':[]})
meta_rows=[]
for r in metas:
    p=D/r['path'];j=json.loads(p.read_text());source=j['source'];observed=j['observed'];art=j['artifact'];png=p.parent/art['filename'];body=png.read_bytes()
    ck('metadata preserves unapproved browser scope '+r['path'],j['schema']=='DESKTOP_SHELL_CAPTURE_V1' and j['state']=='CAPTURED_NOT_REVIEWED' and j['approval']=='NOT_APPROVED' and j['frozen_design_system'] is False and j['actual_native_ipc'] is False and j['native_service_proven'] is False)
    ck('actual100light reduced motion metadata '+r['path'],j['requested_zoom_percent']==100 and j['requested_theme']=='light' and j['full_page'] is True and observed['device_scale_factor']==observed['visual_scale']==1 and observed['root_font_size']=='16px' and observed['prefers_light'] and observed['reduced_motion'])
    ck('exact source commit metadata '+r['path'],source['git_revision']==mapping['commit'] and source['git_tree']==mapping['tree'] and source['selected_sources_match_revision'] and source['selected_source_status']=='')
    for f in source['files']:
        pin=mapping['files'][f['path']];ck('selected source body '+f['path']+' for '+r['path'],f['bytes']==pin['bytes'] and f['sha256']==pin['sha256'])
    srcbody=json.dumps(source['files'],ensure_ascii=False,separators=(',',':')).encode()
    ck('selected source inventory hash '+r['path'],hashlib.sha256(srcbody).hexdigest()==source['source_sha256'])
    ck('actual PNG metadata join '+r['path'],len(body)==art['bytes'] and hashlib.sha256(body).hexdigest()==art['sha256'] and body[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack('>II',body[16:24])==(art['png_width'],art['png_height']) and observed['viewport']['width']==art['png_width'])
    meta_rows.append({'path':r['path'],'fixture_id':j['fixture_id'],'viewport':observed['viewport'],'png_dimensions':[art['png_width'],art['png_height']],'source_files':len(source['files']),'state':j['state'],'approval':j['approval'],'actual_native_ipc':j['actual_native_ipc']})
notes=[]
for r in pngs:
    b=(D/r['path']).read_bytes();dims=struct.unpack('>II',b[16:24])
    notes.append({'path':r['path'],'sha256':r['sha256'],'png_dimensions':list(dims),'entire_capture_visually_inspected':True,'finding':None,'observation':'Navigation, headings, cards and available/unavailable states readable; no visible overlap or text clipping in the full-page capture. Narrow layout stacks vertically.' if 'resize-200' not in r['path'] else 'Entire tall resize scenario inspected; navigation, Diagnostics, version values and capability text readable without visible overlap. Viewer downsampled640x2420to542x2048; no native scale/ink-ratio claim.'})
result={'verdict':'CLEAR_FINITE_BROWSER_RENDER_CAPTURE_REVIEW','checks':len(checks),'all_visual_files_retained':67,'capture_png_paths_inspected':19,'unique_png_bodies':len({r['sha256'] for r in pngs}),'catalog_metadata':14,'exact_attachment_aliases':33,'marker_passed':True,'all14_metadata_source_bindings':True,'state_preserved':'CAPTURED_NOT_REVIEWED / NOT_APPROVED / frozen_design_system=false','native_IPC_and_service_proof':False,'full_campaign_verdict':None,'scope':'Actual browser fixture captures and source bindings; no design approval, native desktop/service/platform certification, feature completion or final aggregate verdict.'}
(H/'visual-review.json').write_text(json.dumps({'result':result,'checks':checks,'metadata':meta_rows,'visual_inspection':notes},indent=2)+'\n');print(json.dumps(result,indent=2))
