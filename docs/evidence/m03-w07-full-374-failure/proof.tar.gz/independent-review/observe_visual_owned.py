"""Owner of one <=50s inert visual-retention attempt, never a browser owner."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
H=Path(__file__).resolve().parent
out=H/'qa'/sys.argv[1];out.mkdir(parents=True,exist_ok=False)
pin=hashlib.sha256((H/'immutable-git-source-sha256.json').read_bytes()).hexdigest()
args=['/Users/tanishkalwad/.local/share/uv/python/cpython-3.12.13-macos-aarch64-none/bin/python3.12','-I','-S','-B',str(H/'retain_all_visual.py')]
start=time.monotonic()
with (out/'stdout').open('wb') as stdout,(out/'stderr').open('wb') as stderr:
    child=subprocess.Popen(args,cwd=H,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
    code=child.wait(timeout=55)
try:os.killpg(child.pid,0);group='PRESENT'
except ProcessLookupError:group='ABSENT'
receipt={'argv':args,'pid':child.pid,'pgid':child.pid,'reaped':child.returncode is not None,'exit_code':code,'group_after_wait':group,'signals':[],'timeout':False,'seconds':time.monotonic()-start,'immutable_source_map_equal':hashlib.sha256((H/'immutable-git-source-sha256.json').read_bytes()).hexdigest()==pin,'scope':'One bounded inert file observer; no browser/native/runtime/source execution or full-outcome claim.'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));assert code==0 and receipt['reaped'] and group=='ABSENT' and receipt['immutable_source_map_equal']
