"""Finite independent review of an actual failed aggregate, preserving failure."""
from pathlib import Path
import ast,hashlib,json,re,stat
H=Path(__file__).resolve().parent
checks=[]
def read(n):return json.loads((H/n).read_text())
def ck(n,v):checks.append({'name':n,'pass':bool(v)});assert v,n
def meta(p):
    s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink();b=p.read_bytes();return {'bytes':len(b),'full_mode':s.st_mode,'sha256':hashlib.sha256(b).hexdigest()}
for r in read('copied-members.json'):
    pin={k:r[k] for k in ('bytes','full_mode','sha256')}
    ck('exact retained copy '+r['path'],meta(H/r['path'])==pin)
    ck('closed origin '+r['path'],meta(Path(r['origin']))==pin)
mapping=read('immutable-git-source-sha256.json');initial=read('initial-source-runtime.json');final=read('final-source-runtime.json')
ck('immutable map pinned',meta(H/'immutable-git-source-sha256.json')['sha256']=='60f2d16e4b16012462cd73a0bb591e9cf88587f3ff57fc2c3171c9b688dbf475' and mapping['blob_count']==len(mapping['files'])==2338 and mapping['all_git_blob_SHA1_framings_verified'] and sum(v['bytes'] for v in mapping['files'].values())==572407788)
ck('fixed source epoch',mapping['commit']=='374b6fe484b5dd82c4a7fa1d751a77369ec79431' and mapping['tree']=='a77820bb5430ec8bebcfb17c8010b0764011fabe')
for n,pin in mapping['files'].items():
    actual=initial['source'][n];ck('physical source versus immutable body '+n,actual['bytes']==pin['bytes'] and actual['sha256']==pin['sha256'] and bool(actual['full_mode']&0o111)==(pin['git_mode']=='100755'))
ck('independent endpoints source runtime Git',initial['source']==final['source'] and initial['runtime']==final['runtime'] and len(final['runtime'])==40 and initial['head']==final['head']==mapping['commit'] and initial['tree']==final['tree']==mapping['tree'] and initial['status']==final['status']=='')
ck('independent optional index content endpoint',initial['index']==final['index'] and final['index_content_pin_equal_initial'])
custodies=read('git-read-closures.json')+[mapping['git_batch_custody']]+read('final-git-read-closures.json')
ck('eight own readonly Git children',len(custodies)==8)
for r in custodies:ck('own Git custody '+str(r['pid']),r['reaped'] and r['exit_code']==0 and r['group_after_wait']=='ABSENT' and not r['signals'])
b=read('reference/full/before.json');a=read('reference/full/after.json');c=read('reference/full/closure.json');context=read('reference/full/context.json');end=read('reference/full/end-context.json');rows=read('reference/full/results.json')
ck('root source runtime snapshot equality',b==a and len(b['source'])==2338 and len(b['runtime'])==40 and b['git_status']=='')
for n,r in b['source'].items():ck('root source snapshot versus independent '+n,{k:r[k] for k in ('bytes','full_mode','sha256')}==initial['source'][n] and r['mode']==stat.S_IMODE(r['full_mode']))
runtime={('apps/desktop/src-tauri/runtime-payload/'+n):{k:r[k] for k in ('bytes','full_mode','sha256')} for n,r in b['runtime'].items()}
ck('root runtime versus independent',runtime==initial['runtime'])
ck('root commit tree immediate equality',context['commit']==end['commit']==mapping['commit'] and context['tree']==end['tree']==mapping['tree'])
ck('actual doctor0 verify1',len(rows)==2 and [r['name'] for r in rows]==['doctor','verify'] and [r['exit_code'] for r in rows]==[0,1])
for r in rows:ck('actual closed owned stage '+r['name'],r['direct_child_reaped'] and r['observed_group']=='ABSENT' and not r['timeout'] and not r['outer_cleanup_signals'])
ck('actual closure preserves failure',c['all_commands_exit_zero'] is False and c['source_count']==2338 and c['runtime_count']==40 and c['source_bytes_modes_unchanged'] and c['runtime_bytes_modes_unchanged'] and c['commit_and_tree_equal_at_end_observation'] and c['git_status_before']==c['git_status_after']=='')
ck('exact original executed wrapper',(H/'reference/full/wrapper-executed.py').read_bytes()==(H/'reference/original-full-wrapper.py').read_bytes())
log=(H/'reference/full/verify.log').read_text();registry=read('reference/source/scripts/verification-suites.json')
summary=log.split('== verification summary ==')[-1];actual={m.group(1):m.group(2) for m in re.finditer(r'(?m)^([^\s]+)[ \t]+ACTIVE[ \t]+(PASS|FAIL)[ \t]*',summary)}
ck('20 ACTIVE results nineteenPASS and pythonFAIL',set(actual)=={s['id'] for s in registry['suites']} and len(actual)==20 and sum(v=='PASS' for v in actual.values())==19 and {k for k,v in actual.items() if v=='FAIL'}=={'python'})
node='scripts/tests/test_ubuntu_gnome_boundaries.py::test_imports_do_not_load_platform_gi_or_spawn_actor'
ck('actual one failed2787passed','1 failed, 2787 passed in 444.92s' in log and re.findall(r'(?m)^FAILED (.+)$',log)==[node] and 'verification exit code: 1' in log)
ck('actual exact expected versus observed regression',"assert guest.OPERATIONS[-1] == \"finish\"" in log and "AssertionError: assert 'shell_check_observe' == 'finish'" in log and 'scripts/tests/test_ubuntu_gnome_boundaries.py:72: AssertionError' in log)
cat=read('immutable-python-test-inventory.v1.json');expected=set(cat['common']['node_ids'])|set(cat['posix_only_node_ids'])
ck('catalog totals support failure count',len(cat['common']['node_ids'])==2786 and len(cat['posix_only_node_ids'])==2 and len(expected)==2788 and node in expected)
for name in ('scripts/tests/test_ubuntu_gnome_boundaries.py','scripts/linux_gnome/ubuntu_gnome_guest.py','scripts/verification-suites.json'):
    pin=mapping['files'][name];actualmeta=meta(H/'reference/source'/name);ck('exact failure or registry source '+name,actualmeta['bytes']==pin['bytes'] and actualmeta['sha256']==pin['sha256'])
guest=(H/'reference/source/scripts/linux_gnome/ubuntu_gnome_guest.py').read_text();tree=ast.parse(guest)
ops=next(n for n in tree.body if isinstance(n,ast.AnnAssign) and isinstance(n.target,ast.Name) and n.target.id=='OPERATIONS')
ck('source base operations ends finish',isinstance(ops.value,ast.Tuple) and ast.literal_eval(ops.value)[-1]=='finish')
ck('source then appends shell operations',any(isinstance(n,ast.AugAssign) and isinstance(n.target,ast.Name) and n.target.id=='OPERATIONS' and isinstance(n.op,ast.Add) and isinstance(n.value,ast.Name) and n.value.id=='SHELL_OPERATIONS' for n in tree.body))
visual=read('visual-review.json');ret=read('visual-retention.json');rootret=read('reference/root-retained-visual/retention.json')
ck('finite independent visual419 checks',visual['result']['checks']==419 and all(r['pass'] for r in visual['checks']) and visual['result']['capture_png_paths_inspected']==19 and visual['result']['unique_png_bodies']==15 and all(r['entire_capture_visually_inspected'] and r['finding'] is None for r in visual['visual_inspection']))
marker=re.search(r'(?m)^[ \t]*17 passed \([^\r\n]+\)[ \t]*$',log)
ck('actual anchored visual17 followed by Python',marker is not None and log.find('$ uv run pytest -c pyproject.toml',marker.end())>=0 and ret['actual_visual17_and_Python_start_seen'] and ret['full_closed_at_observation'] is False)
own={r['path']:r for r in ret['all_original_files']};rootall={r['path']:{k:r[k] for k in ('path','bytes','full_mode','sha256')} for r in rootret['all_original_files']}
ck('all67 root and different-reader copies match',own==rootall and len(own)==67 and rootret['selected_count']==33 and rootret['png']==19 and rootret['metadata']==14 and rootret['excluded_attachment_aliases_are_exact_duplicate_bodies'])
ck('root retainer source exact',(H/'reference/full/retention-observer-executed.py').read_bytes()==(H/'reference/root-visual-retainer.py').read_bytes())
visual_receipts=sorted((H/'qa').glob('*/receipt.json'));ck('three measured visual observers closed',len(visual_receipts)==3)
for p in visual_receipts:
    r=json.loads(p.read_text());ck('own visual custody '+p.parent.name,r['reaped'] and r['exit_code']==0 and r['group_after_wait']=='ABSENT' and not r['signals'] and not r['timeout'] and r['immutable_source_map_equal'])
out={'verdict':'CONFIRMED_ACTUAL_FULL_FAILURE_PYTHON_OPERATION_ORDER','data_joins':len(checks),'all_record_consistency_checks_pass':True,'commit':mapping['commit'],'tree':mapping['tree'],'immutable_blob_count':2338,'immutable_blob_bytes':572407788,'runtime_files':40,'actual_doctor_exit':0,'actual_verify_exit':1,'active_suites':20,'passed_suites':19,'failed_suites':['python'],'actual_python_passed':2787,'actual_python_failed':1,'actual_python_seconds':444.92,'failed_node':node,'expected_final_operation':'finish','actual_final_operation':'shell_check_observe','own_and_root_source_runtime_Git_endpoints_equal':True,'own_index_content_endpoints_equal':True,'all67_visual_outputs_retained':True,'all19_PNG_paths_visually_inspected':True,'visual_data_checks':419,'visual_native_IPC_or_service_qualification':False,'scope':'Actual local failed aggregate on fixed2338-file source, not successful completion, CI terminal verdict, native Windows/GNOME certification, design approval, runtime activation or release.'}
(H/'data-review.json').write_text(json.dumps({'result':out,'checks':checks},indent=2)+'\n');print(json.dumps(out,indent=2))
