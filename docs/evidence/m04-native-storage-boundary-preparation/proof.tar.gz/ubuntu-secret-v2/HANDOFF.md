# Ubuntu Secret Service v2 delta-review handoff

Immutable v1 remains held for the two confirmed P2 findings. This independent-revision candidate addresses prompt-custody admission before CreateItem/Delete and branch-specific AlreadyAbsent cleanup effects. Root is the sole canonical writer; all current work and execution were outside the repository, with no native credential activity or status credit.

Review `PRODUCTION-DELTA.patch`, `ORACLE-CORRECTION.patch`, `TEST-BODY-JOINS.json`, `AUTHORIZATION.md` and the copied independent v1 HOLD packet. The GIO file, Cargo files, dependency graph, runner and budgets remain unchanged. Of 36 original bodies, 35 are byte-identical in final v2; root explicitly authorized strengthening the one false timeout cleanup tail, preserving its name, timeout/Unknown/no-repeat assertions and original body in history. Fifteen cases are appended. No skips or removed tests are present.

Actual pre-implementation RED: `quality/red-v1-prompt-custody` runs unchanged v1 production and original 36 bodies plus 13 appended cases, producing 36 PASS / 13 FAIL. All 13 added bodies are unchanged in final green. Two supplemental cases were added later for known-dismissal retry and no admission after cancellation. `red-v1-expanded/quality/control` repeats original v1 production/oracles with all 15 final additions, yielding 38 PASS / 13 FAIL; this is a later expanded control.

Actual final command: pinned Python 3.12 `-I -S -B run_quality.py green-v2-complete`. Its five recorded Rust 1.97.1 commands all exit 0; 51 units PASS, four unique privacy/affinity compile-fail PASS (two repeat in default docs). Six scoped input files have identical bytes/full modes before/after. Each actual direct child is reaped, owned group observed absent and no signals sent.

Exact-final mutation controls, with all 51 final bodies and every other source/runner/Cargo file unchanged:

- `negative-prompt-custody/quality/control`: remove only pre-call unknown-prompt admission; actual 41 PASS / 10 FAIL, exit 101.
- `negative-absent-effect/quality/control`: replace only AlreadyAbsent's final effect mapping with Applied; actual 48 PASS / 3 FAIL, exit 101.

Both derivatives retain unchanged bytes/full modes during execution, reaped children, absent groups and zero cleanup signals. Their failed unit steps run no doctests. `INPUTS.json` binds the final six inputs; `CHECKS.json` records author joins, with independent v2 review explicitly pending. `SOURCE.json` seals regular evidence/source bytes/full modes; the proof additionally contains SOURCE. The full original v1 proof is an opaque inherited member, not extracted or executed in v2.

Known cleanup paths remain bounded and retryable. Unknown-prompt paths now preserve session/profile custody and require host-initiated observed dedicated connection closure; ordinary cleanup/new private calls remain refused through failed or ambiguous closure observations. A locally observed closed flag permanently revokes further operations on the connection; it is not a bus-daemon acknowledgement. AlreadyAbsent refuses late cleanup with NotApplied and no Delete call. This is fake-boundary/source evidence only.

No native GIO loading/link execution, D-Bus, keyring/credential read/write/delete, service activation, prompt invocation/unlock, installation, network fetch, canonical/dependency/schema/status changes or acceptance occurred. Original host lifetime/effective-user/profile/connection acquisition, packaging/ABI/link/runtime, buffer/timeout and certified-target limitations remain. Root should use a different source/data reviewer to verify both fixes, the narrow oracle authorization and exact RED/GREEN/mutation joins before any adoption.
