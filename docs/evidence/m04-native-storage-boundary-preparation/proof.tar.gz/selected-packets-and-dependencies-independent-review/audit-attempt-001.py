"""Data-only packet audit. Subject files are never imported or executed."""
from pathlib import Path, PurePosixPath
import base64
import csv
import datetime
import hashlib
import io
import json
import re
import stat
import struct
import sys
import tarfile
import traceback
import zipfile

BASE = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
OUT = Path(__file__).parent
RUN = OUT / ('checks-run-%03d.json' % (1 + len(list(OUT.glob('checks-run-*.json')))))
checks = []
observations = {}

def sha(body):
    return hashlib.sha256(body).hexdigest()

def check(name, condition, evidence=None):
    row = {'name': name, 'matched': bool(condition)}
    if evidence is not None:
        row['evidence'] = evidence
    checks.append(row)

def safe(rel):
    p = PurePosixPath(rel)
    return bool(rel) and str(p) == rel and not p.is_absolute() and '..' not in p.parts and '\\' not in rel

def desc(path):
    meta = path.lstat()
    if not stat.S_ISREG(meta.st_mode):
        raise ValueError('input not a regular file: ' + str(path))
    return {'bytes': meta.st_size, 'mode': stat.S_IMODE(meta.st_mode), 'sha256': sha(path.read_bytes())}

def relative_desc(root, rel):
    if not safe(rel):
        raise ValueError('unsafe relative input: ' + rel)
    p = root / rel
    for parent in p.parents:
        if parent == root:
            break
        if not stat.S_ISDIR(parent.lstat().st_mode):
            raise ValueError('symlink/non-directory parent: ' + str(parent))
    return desc(p)

def load(path):
    return json.loads(path.read_bytes())

def metadata(row):
    return {key: row[key] for key in ['bytes', 'mode', 'sha256']}

def persist(exception=None):
    result = {
        'scope': 'INDEPENDENT_DATA_ONLY_SELECTED_PACKET_AND_DEPENDENCY_RETENTION_REVIEW_NO_SUBJECT_EXECUTION',
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'audit_script_sha256': sha(Path(__file__).read_bytes()),
        'reconciliation_count': len(checks), 'matched_count': sum(x['matched'] for x in checks),
        'all_matched': all(x['matched'] for x in checks) and exception is None,
        'failed_assumptions_or_joins': [x for x in checks if not x['matched']],
        'exception': exception, 'observations': observations, 'checks': checks,
        'subject_imports_or_execution': False, 'native_actors_or_installs': False,
        'network_or_signals': False, 'canonical_or_original_packet_writes': False,
        'formal_m04_or_activation_claim': False,
    }
    RUN.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'run_file': str(RUN), **{k: result[k] for k in ['reconciliation_count', 'matched_count', 'all_matched', 'failed_assumptions_or_joins', 'exception']}, 'observations': observations}, indent=2))
    return result

def fail(exc_type, exc, tb):
    persist({'type': exc_type.__name__, 'message': str(exc), 'traceback': ''.join(traceback.format_exception(exc_type, exc, tb))})

sys.excepthook = fail
all_inputs = {}
outer_bodies = {}
for name in ['m04-sdk-private-startup-evidence-v1', 'm04-windows-profile-authority-evidence-v1']:
    root = BASE / name
    artifact = load(root / 'artifact.json')
    retained = load(root / 'retention-manifest.json')
    summary = load(root / 'summary.json')
    for filename in ['README.md', 'artifact.json', 'retention-manifest.json', 'summary.json', 'proof.tar.gz']:
        all_inputs[str(root / filename)] = desc(root / filename)
    check('outer artifact exact bytes/mode/hash ' + name, desc(root / artifact['path']) == metadata(artifact) and artifact['path'] == 'proof.tar.gz')
    expected = {}
    for row in retained['members']:
        rel = row['path']
        check('outer declared safe unique path ' + name + ' ' + rel, safe(rel) and rel not in expected)
        expected[rel] = row
        original = Path(row['source_path'])
        check('original retained location outside canonical ' + name + ' ' + rel, original.is_absolute() and original.is_relative_to(BASE))
        actual = desc(original)
        all_inputs[str(original)] = actual
        check('outer manifest joins original full metadata ' + name + ' ' + rel, actual == metadata(row))
    bodies = {}
    with tarfile.open(fileobj=io.BytesIO((root / 'proof.tar.gz').read_bytes()), mode='r:gz') as archive:
        for member in archive:
            rel = member.name
            valid = safe(rel) and member.isreg() and not member.issym() and not member.islnk() and rel not in bodies and rel in expected
            check('outer safe unique regular member ' + name + ' ' + rel, valid)
            if not valid:
                raise ValueError('unexpected/unsafe outer member: ' + rel)
            body = archive.extractfile(member).read()
            bodies[rel] = body
            check('outer member bytes/fullmode/size ' + name + ' ' + rel, {'bytes': len(body), 'mode': member.mode, 'sha256': sha(body)} == metadata(expected[rel]))
            check('outer member exact original body ' + name + ' ' + rel, body == Path(expected[rel]['source_path']).read_bytes())
    check('outer exhaustive membership/count/size ' + name, set(bodies) == set(expected) and len(bodies) == retained['safe_regular_members'] and sum(map(len, bodies.values())) == retained['total_uncompressed_bytes'])
    outer_bodies[name] = bodies
    observations[name] = {'archive': metadata(artifact), 'members': len(bodies), 'uncompressed_bytes': sum(map(len, bodies.values())), 'summary': summary}

sdk_name = 'm04-sdk-private-startup-evidence-v1'
sdk_root = BASE / 'm04-sdk-private-startup-preparation-v2'
sdk = outer_bodies[sdk_name]
sdk_summary = observations[sdk_name]['summary']
source = json.loads(sdk['prepared/SOURCE.json'])
source_sha = sha(sdk['prepared/SOURCE.json'])
check('SDK exact retained preparation SOURCE seal', source_sha == sdk_summary['source_sha256'] == '9da9d30b4e46a374b356a387031d023c787ca20429c66d0621385d7025c3c781')
check('SDK all 2423 declared source pins', len(source['files']) == sdk_summary['recorded_source_files'] == 2423)
source_index = {}
for row in source['files']:
    rel = row['path']
    check('SDK declared pin safe and unique ' + rel, safe(rel) and rel not in source_index)
    source_index[rel] = metadata(row)
    actual = relative_desc(sdk_root, rel)
    all_inputs[str(sdk_root / rel)] = actual
    check('SDK current complete source pin bytes/modes ' + rel, actual == metadata(row))
for rel, body in sdk.items():
    if rel.startswith('prepared/'):
        original_rel = rel.removeprefix('prepared/')
        if original_rel in source_index:
            check('SDK selected original source seal join ' + rel, len(body) == source_index[original_rel]['bytes'] and sha(body) == source_index[original_rel]['sha256'])
binary = source['binary']
binary_actual = relative_desc(sdk_root, binary['path'])
all_inputs[str(sdk_root / binary['path'])] = binary_actual
check('SDK omitted binary remains exact outside', binary_actual == metadata(binary) and binary['bytes'] == 32804984)
check('SDK binary body explicitly omitted', all(row['source_path'] != str(sdk_root / binary['path']) for row in load(BASE / sdk_name / 'retention-manifest.json')['members']) and '32,804,984-byte' in (BASE / sdk_name / 'README.md').read_text() and 'Their bytes are not claimed included' in (BASE / sdk_name / 'README.md').read_text())
check('SDK complete derivative selected omission explicit', sdk_summary['selected_retention_only'] is True and sdk_summary['all_source_pins_rechecked'] is True and 'complete2423-file derivative' in (BASE / sdk_name / 'README.md').read_text())
before = json.loads(sdk['actual/before.json'])
after = json.loads(sdk['actual/after.json'])
check('SDK actor exact full source endpoints', before == after == source['files'])
actor = json.loads(sdk['actual/result.json'])
check('SDK summary actor is exact receipt', sdk_summary['actual_result'] == actor)
check('SDK recorded outer closed result', actor['exit_code'] == 0 and actor['direct_child_reaped'] is True and actor['native_group'] == 'ABSENT' and actor['signals'] == [] and actor['reason'] is None and actor['final_oracle_pass'] is True and actor['binary_unchanged'] is True and actor['source_bytes_modes_unchanged'] is True and abs(actor['seconds'] - 4.275210542) < 1e-9 and all(v == 'ABSENT' for v in actor['known_child_groups'].values()))
for stream in ['stdout', 'stderr']:
    body = sdk['actual/sdk.' + stream]
    check('SDK actual raw ' + stream + ' joins receipt', len(body) == actor[stream]['bytes'] and sha(body) == actor[stream]['sha256'])
review = json.loads(sdk['independent-review/data-review.json'])
review_manifest = json.loads(sdk['independent-review/manifest.json'])
check('SDK different review exact seal and 33 joins', sha(sdk['independent-review/manifest.json']) == sdk_summary['independent_review_manifest_sha256'] and review['source_sha256'] == source_sha and review['source_records_verified'] == 2423 and review['pass'] is True and len(review['checks']) == 33 and all(r['pass'] for r in review['checks']) and review_manifest['passing_independent_joins'] == 33)
for row in review_manifest['input_pins'] + review_manifest['review_artifact_pins']:
    p = Path(row['path'])
    actual = desc(p)
    all_inputs[str(p)] = actual
    check('SDK review pin exact original ' + str(p), actual == metadata(row))
actual_rows = [p for p in sdk if p.startswith('actual/')]
check('SDK exact ten actor files retained', len(actual_rows) == len(review['actual_evidence_pins']) == 10)
for row in review['actual_evidence_pins']:
    rel = 'actual/' + Path(row['path']).name
    check('SDK actor file joins different review ' + rel, rel in sdk and len(sdk[rel]) == row['bytes'] and sha(sdk[rel]) == row['sha256'])
events = [json.loads(line) for line in sdk['actual/sdk.stdout'].splitlines()]
scenarios = [e['data'] for e in events if e['stage'] == 'scenario']
check('SDK actual scenario transcript joins review', scenarios == review['actual_scenarios'] and len(scenarios) == 3)
expected_terminal = {'normal': ('Ok(Closed)', False, []), 'replay': ('Ok(Refused)', False, []), 'partial': ('Err(Protocol)', True, ['SIGKILL'])}
for scenario in scenarios:
    value = scenario['result']['Ok']
    terminal, timed, signals = expected_terminal[scenario['mode']]
    check('SDK scenario precise retained outcome ' + scenario['mode'], value['pass'] is True and value['terminal'] == terminal and value['actual_timeout'] is timed and value['signals'] == signals and value['child_reaped'] is True and value['child_group_absent'] is True and value['synthetic_directory_removed'] is True and value['ciphertext']['plaintext_header_absent'] is True and value['ciphertext']['synthetic_marker_absent'] is True)
final = [e['data'] for e in events if e['stage'] == 'final'][0]
check('SDK no false native/product/universal proof', final['pass'] is True and all(final[k] is False for k in ['held_fd_sqlcipher_vfs_proof', 'keychain_called', 'native_credential_proof', 'production_service_started', 'universal_descendant_proof', 'window_created']) and sdk_summary['canonical_activation'] is False and sdk_summary['milestone_credit'] is False and sdk_summary['native_credentials'] is False)
green = json.loads(sdk['prepared/quality/v2-root-findings-green/results.json'])
red = json.loads(sdk['prepared/quality/v2-root-findings-red/results.json'])
check('SDK original red and green test outcomes preserved', b'8 passed; 0 failed' in sdk['prepared/quality/v2-root-findings-green/pure-tests.stdout'] and b'5 passed; 3 failed' in sdk['prepared/quality/v2-root-findings-red/pure-tests.stdout'])
check('SDK green strict command closure', len(green['commands']) == 4 and green['source_bytes_modes_unchanged'] is True and all(c['exit_code'] == 0 and c['direct_child_reaped'] is True and c['observed_group'] == 'ABSENT' and not c['cleanup_signals'] for c in green['commands']))
check('SDK historical preparation wording unchanged', b'NO_LIVE_SDK_ACTOR' in sdk['prepared/SOURCE.json'] and sdk['prepared/README.md'] == (sdk_root / 'README.md').read_bytes() and 'remain historical' in (BASE / sdk_name / 'README.md').read_text())
observations['sdk_actual'] = {'source_count': len(source_index), 'binary': binary, 'actual_files': len(actual_rows), 'review_joins': 33, 'scenario_modes': [r['mode'] for r in scenarios]}

win_name = 'm04-windows-profile-authority-evidence-v1'
win = outer_bodies[win_name]
win_summary = observations[win_name]['summary']
win_source = json.loads(win['prepared/SOURCE.json'])
win_handoff = json.loads(win['prepared/HANDOFF.json'])
check('Windows nested exact requested source/proof', sha(win['prepared/SOURCE.json']) == win_summary['source_sha256'] == win_handoff['SOURCE_sha256'] == 'aee70263d0e72feb86e7100821a92ac258c2be877b597e78413bcb7b45cf5423' and sha(win['prepared/proof.tar.gz']) == win_summary['original_proof_sha256'] == win_handoff['archive_sha256'] == '4850a6235a64ace75ad395206298d0885ae7098a21ff07838a3d63b1e0089fc6')
expected = {row['path']: metadata(row) for row in win_source['files']}
win_root = BASE / 'm04-windows-profile-authority-preparation/v2'
expected['SOURCE.json'] = desc(win_root / 'SOURCE.json')
nested = {}
with tarfile.open(fileobj=io.BytesIO(win['prepared/proof.tar.gz']), mode='r:gz') as archive:
    for member in archive:
        rel = member.name
        valid = safe(rel) and member.isreg() and not member.islnk() and not member.issym() and rel not in nested and rel in expected
        check('Windows nested safe unique regular ' + rel, valid)
        if not valid:
            raise ValueError('unsafe nested member')
        body = archive.extractfile(member).read()
        nested[rel] = body
        original = relative_desc(win_root, rel)
        all_inputs[str(win_root / rel)] = original
        check('Windows nested original/seal/fullmode join ' + rel, {'bytes': len(body), 'mode': member.mode, 'sha256': sha(body)} == expected[rel] == original)
check('Windows nested exhaustive 162 members', set(nested) == set(expected) and len(nested) == win_handoff['safe_regular_members'] == 162)
win_review = json.loads(win['independent-review/review-data.json'])
check('Windows unchanged review seal/968 joins', sha(win['independent-review/REVIEW-MANIFEST.json']) == win_summary['independent_review_manifest_sha256'] and win_review['reconciliation_count'] == win_review['matched_count'] == 968 and win_review['all_matched'] is True and win_review['actionable_findings'] == [])
quality = json.loads(nested['quality/final-v2/results.json'])
check('Windows exact 64/41/4 actual data and five closed commands', win_summary['fake_unit_tests'] == 64 and win_summary['preserved_baseline_tests'] == 41 and win_summary['distinct_compile_fail_cases'] == 4 and b'64 passed; 0 failed' in nested['quality/final-v2/fake-tests.stdout'] and b'4 passed; 0 failed' in nested['quality/final-v2/native-privacy-doctests.stdout'] and len(quality['commands']) == 5 and all(c['exit_code'] == 0 and c['direct_child_reaped'] and c['observed_group'] == 'ABSENT' and c['cleanup_signals'] == [] and c['timeout'] is False for c in quality['commands']))
check('Windows mutant result preserved', b'61 passed; 3 failed' in nested['negative-control/stdout.log'])
check('Windows no false native/activation/M04 claim', win_summary['native_windows_execution'] is False and win_summary['canonical_activation'] is False and win_summary['milestone_credit'] is False and win_handoff['windows_cross_target_compilation'] is False and 'no Windows cross-compilation' in (BASE / win_name / 'README.md').read_text())
check('Windows source history unchanged', win['prepared/README.md'] == (win_root / 'README.md').read_bytes() and win_source['production_selection'] == 'UNAVAILABLE_REAL_PROFILE_IDENTITY_AND_WINDOWS_VALIDATION_PENDING')

dep_root = BASE / 'm04-sqlcipher-crossplatform-dependencies-v1'
dep_source = load(dep_root / 'SOURCE.json')
check('dependencies exact SOURCE requested digest', sha((dep_root / 'SOURCE.json').read_bytes()) == 'dc15d145de1abdfa0c79a4f71bf9c3977ae247c4899f47c9311c4a667c302b9b')
dep_entries = {}
for row in dep_source['files']:
    rel = row['path']
    check('dependency safe unique SOURCE path ' + rel, safe(rel) and rel not in dep_entries)
    actual = relative_desc(dep_root, rel)
    dep_entries[rel] = metadata(row)
    all_inputs[str(dep_root / rel)] = actual
    check('dependency full bytes/modes source join ' + rel, actual == metadata(row))
all_inputs[str(dep_root / 'SOURCE.json')] = desc(dep_root / 'SOURCE.json')
check('all15 dependency files exhaust directory', len(dep_entries) == 15 and set(dep_entries) == {p.name for p in dep_root.iterdir() if p.name != 'SOURCE.json'})
release_body = (dep_root / 'pypi-release-original.json').read_bytes()
release = json.loads(release_body)
receipt = load(dep_root / 'pypi-request-receipt.json')
check('retained official release metadata receipt body', receipt['sha256'] == sha(release_body) and receipt['bytes'] == len(release_body) and receipt['status'] == 200 and receipt['url'] == 'https://pypi.org/pypi/sqlcipher3/0.6.4/json' and release['info']['version'] == '0.6.4')
inspection = load(dep_root / 'inspection.json')
wheel_total = 0
native_kinds = []
for wheel in inspection['wheels']:
    name = wheel['filename']
    original = [r for r in release['urls'] if r['filename'] == name]
    check('unique official wheel release row ' + name, len(original) == 1)
    published = original[0]
    body = (dep_root / name).read_bytes()
    wheel_total += len(body)
    check('wheel official size/hash/url join ' + name, len(body) == published['size'] == wheel['published_size'] == wheel['download']['bytes'] and sha(body) == published['digests']['sha256'] == wheel['download']['sha256'] and published['url'] == wheel['download']['url'] and published['url'].startswith('https://files.pythonhosted.org/') and published['packagetype'] == 'bdist_wheel' and published['yanked'] is False)
    members = {}
    with zipfile.ZipFile(io.BytesIO(body)) as archive:
        for member in archive.infolist():
            rel = member.filename
            p = PurePosixPath(rel)
            valid = not p.is_absolute() and '..' not in p.parts and '\\' not in rel and rel not in members and not member.flag_bits & 1 and not stat.S_ISLNK(member.external_attr >> 16)
            check('wheel safe member ' + name + ' ' + rel, valid)
            if not valid:
                raise ValueError('unsafe wheel member')
            if member.is_dir():
                continue
            data = archive.read(member)
            members[rel] = {'bytes': len(data), 'sha256': sha(data), 'zip_mode': member.external_attr >> 16}
            check('wheel complete member metadata ' + name + ' ' + rel, members[rel] == wheel['members'].get(rel) and len(data) == member.file_size)
        check('wheel exhaustive member map ' + name, members == wheel['members'])
        record = 'sqlcipher3-0.6.4.dist-info/RECORD'
        seen = set()
        for rel, digest, size in csv.reader(io.StringIO(archive.read(record).decode())):
            check('RECORD safe unique member ' + name + ' ' + rel, rel not in seen and rel in members)
            seen.add(rel)
            if rel == record:
                check('RECORD self-row blank digest/size ' + name, digest == size == '')
            else:
                actual = members[rel]
                encoded = base64.urlsafe_b64encode(bytes.fromhex(actual['sha256'])).decode().rstrip('=')
                check('RECORD exact digest and length ' + name + ' ' + rel, digest == 'sha256=' + encoded and size == str(actual['bytes']))
        check('RECORD exhaustive membership ' + name, seen == set(members) and wheel['record_exact'] is True)
        native = [n for n in members if n.endswith(('.pyd', '.so'))]
        check('one native member ' + name, native == [wheel['native_member']])
        data = archive.read(native[0])
        if 'win_amd64' in name:
            offset = struct.unpack_from('<I', data, 0x3c)[0]
            valid = data[:2] == b'MZ' and data[offset:offset+4] == b'PE\0\0' and struct.unpack_from('<H', data, offset+4)[0] == 0x8664 and struct.unpack_from('<H', data, offset+24)[0] == 0x20b
            kind = 'PE32+'
        elif 'manylinux' in name:
            valid = data[:6] == b'\x7fELF\x02\x01' and struct.unpack_from('<H', data, 18)[0] == 62
            kind = 'ELF64little'
        else:
            valid = data[:4] == b'\xcf\xfa\xed\xfe' and struct.unpack_from('<I', data, 4)[0] == 0x100000c
            kind = 'MachO64little'
        check('native architecture header ' + name, valid and wheel['native_architecture']['kind'] == kind)
        native_kinds.append(kind)
        readable = load(dep_root / (name + '.readable-metadata.json'))
        expected_readable = {n: archive.read(n).decode() for n in members if n.endswith(('/METADATA', '/WHEEL')) or 'license' in n.lower() or n.lower().endswith(('copying', 'notice'))}
        check('complete readable metadata/excerpts ' + name, readable == expected_readable)
        meta = archive.read('sqlcipher3-0.6.4.dist-info/METADATA').decode()
        wheelmeta = archive.read('sqlcipher3-0.6.4.dist-info/WHEEL').decode()
        check('wheel nonpure/version/dependency/license scope ' + name, 'Root-Is-Purelib: false' in wheelmeta and wheelmeta == wheel['wheel_metadata'] and '\nVersion: 0.6.4\n' in meta and '\nRequires-Dist:' not in meta and 'sqlcipher3-0.6.4.dist-info/licenses/LICENSE' in members)
check('three wheel bodies and total size', len(inspection['wheels']) == 3 and wheel_total == 12833394)
old_mac = BASE / 'm04-sqlcipher-foundation/provenance/sqlcipher3-0.6.4-cp312-cp312-macosx_11_0_arm64.whl'
new_mac = dep_root / old_mac.name
check('Mac wheel exact earlier tested release digest', desc(old_mac)['sha256'] == desc(new_mac)['sha256'] == '1607fe61ddcd0a9731a062735e84f997515c0f2503ac158d57564e13b0799d9e')
sdist = load(dep_root / 'sdist-inspection.json')
body = (dep_root / 'sqlcipher3-0.6.4.tar.gz').read_bytes()
published = [r for r in release['urls'] if r['filename'] == 'sqlcipher3-0.6.4.tar.gz'][0]
check('sdist official complete size/hash/url join', len(body) == published['size'] == sdist['download']['bytes'] == 2707971 and sha(body) == published['digests']['sha256'] == sdist['download']['sha256'] and published['url'] == sdist['download']['url'] and published['packagetype'] == 'sdist' and published['yanked'] is False)
expected_sdist = {r['path']: metadata(r) for r in sdist['members']}
sdist_bodies = {}
seen = set()
with tarfile.open(fileobj=io.BytesIO(body), mode='r:gz') as archive:
    for member in archive:
        rel = member.name
        p = PurePosixPath(rel)
        valid = not p.is_absolute() and '..' not in p.parts and '\\' not in rel and p.parts[0] == 'sqlcipher3-0.6.4' and rel not in seen and (member.isdir() or member.isreg()) and not member.issym() and not member.islnk()
        check('sdist safe unique regular/directory ' + rel, valid)
        seen.add(rel)
        if not valid:
            raise ValueError('unsafe sdist member')
        if member.isdir():
            continue
        data = archive.extractfile(member).read()
        sdist_bodies[rel] = data
        check('sdist member full body and mode ' + rel, {'bytes': len(data), 'mode': member.mode, 'sha256': sha(data)} == expected_sdist.get(rel))
check('sdist complete36 members and uncompressed count', set(sdist_bodies) == set(expected_sdist) and len(sdist_bodies) == sdist['safe_regular_members'] == 36 and sum(map(len, sdist_bodies.values())) == sdist['total_uncompressed_regular_bytes'] == 10677369)
for key, text in sdist['retained_text_excerpts'].items():
    rel = key.removesuffix('.first-16384-bytes')
    data = sdist_bodies['sqlcipher3-0.6.4/' + rel]
    if key.endswith('.first-16384-bytes'):
        data = data[:16384]
    check('sdist exact bounded excerpt ' + key, data.decode() == text)
texts = sdist['retained_text_excerpts']
check('sdist static build/version observations exact', 'openssl/3.6.0' in texts['conanfile.py'] and 'version = "0.6.4"' in texts['pyproject.toml'] and "VERSION = '0.6.3'" in texts['setup.py'])
transcript = load(dep_root / 'command-result-transcription.json')
check('CLI outcomes explicitly transcription not logs', transcript['scope'] == 'TOOL_RESULT_TRANSCRIPTION_NOT_ORIGINAL_RAW_LOG_OR_PROCESS_GROUP_OBSERVATION' and [r['session_id'] for r in transcript['commands']] == [64326, 22992] and all(r['exit_code'] == 0 for r in transcript['commands']) and 'POST_COMPLETION' in dep_source['scope'])
wheel_transcribed = json.loads(transcript['commands'][0]['tool_stdout_transcription'])
sdist_transcribed = json.loads(transcript['commands'][1]['tool_stdout_transcription'])
check('CLI transcription data joins retained artifacts', wheel_transcribed == {'downloaded': 3, 'all_record_joins': True, 'bytes': wheel_total, 'native_formats': native_kinds} and sdist_transcribed == {'safe_regular_members': 36, 'bytes': len(body), 'sha256': sha(body), 'text_keys': sorted(texts)})
readme = (dep_root / 'README.md').read_text()
check('dependencies claim limits explicit', inspection['not_zetetic_supported_binary_claim'] is True and all(term in readme for term in ['no claim of a Zetetic-supported binary', 'not a pinned reproducible build closure', 'does not complete', 'No wheel was installed/imported', 'explicitly a transcription', 'not a contemporaneous executed-script attestation']))
observations['dependencies'] = {'source_records': len(dep_entries), 'wheels': len(inspection['wheels']), 'wheel_body_bytes': wheel_total, 'native_header_kinds': native_kinds, 'sdist_regular_members': len(sdist_bodies), 'sdist_compressed_bytes': len(body), 'sdist_uncompressed_bytes': sum(map(len, sdist_bodies.values())), 'transcription_only_sessions': [64326, 22992]}
check('all recorded input bytes/modes unchanged at review end', all(desc(Path(path)) == expected for path, expected in all_inputs.items()))
observations['input_file_pins'] = all_inputs
result = persist()
if not result['all_matched']:
    raise SystemExit(1)
