from pathlib import Path, PurePosixPath
import base64, csv, datetime, hashlib, io, json, stat, struct, urllib.parse, urllib.request, zipfile
OUT=Path(__file__).parent
PINS={
 'sqlcipher3-0.6.4-cp312-cp312-win_amd64.whl':'ff612c1f731a1870457a3fa4c0095bf27ce13ad7e2035ec3f98a489e2d6ccf5c',
 'sqlcipher3-0.6.4-cp312-cp312-manylinux_2_28_x86_64.whl':'27b4d537011dc57f25dd6e5b8a9dd8e9ca7470d7286618be83113cc46aabcf6d',
 'sqlcipher3-0.6.4-cp312-cp312-macosx_11_0_arm64.whl':'1607fe61ddcd0a9731a062735e84f997515c0f2503ac158d57564e13b0799d9e',
}
def digest(b):return hashlib.sha256(b).hexdigest()
def dump(n,v): (OUT/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
class Gate(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):
  raise ValueError('Redirect refused; no unreviewed target request')
OPENER=urllib.request.build_opener(Gate())
def fetch(url,host,cap):
 u=urllib.parse.urlsplit(url)
 assert u.scheme=='https' and u.hostname==host and u.port in (None,443) and not u.username and not u.password
 with OPENER.open(urllib.request.Request(url,headers={'User-Agent':'jobapplyv2-dependency-metadata-inspection/1'}),timeout=30) as r:
  assert r.status==200
  b=r.read(cap+1);assert len(b)<=cap
  return b,{'url':url,'status':r.status,'bytes':len(b),'sha256':digest(b),'date':r.headers.get('Date'),'content_type':r.headers.get('Content-Type')}
raw,receipt=fetch('https://pypi.org/pypi/sqlcipher3/0.6.4/json','pypi.org',2*1024**2)
(OUT/'pypi-release-original.json').write_bytes(raw)
dump('pypi-request-receipt.json',receipt)
metadata=json.loads(raw);assert metadata['info']['version']=='0.6.4'
rows=[]
for name,pin in PINS.items():
 matches=[x for x in metadata['urls'] if x['filename']==name];assert len(matches)==1
 row=matches[0];assert row['digests']['sha256']==pin and not row['yanked'] and row['packagetype']=='bdist_wheel'
 blob,rec=fetch(row['url'],'files.pythonhosted.org',16*1024**2)
 assert digest(blob)==pin and len(blob)==row['size']
 (OUT/name).write_bytes(blob)
 with zipfile.ZipFile(io.BytesIO(blob)) as z:
  infos=z.infolist();assert 1<=len(infos)<=128
  names=[x.filename for x in infos];assert len(set(names))==len(names)
  members={};total=0
  for inf in infos:
   p=PurePosixPath(inf.filename)
   assert not p.is_absolute() and '..' not in p.parts and '\\' not in inf.filename
   assert not inf.flag_bits&1 and not stat.S_ISLNK(inf.external_attr>>16)
   assert inf.file_size<=32*1024**2
   total+=inf.file_size;assert total<=96*1024**2
   if inf.is_dir():continue
   body=z.read(inf);assert len(body)==inf.file_size
   members[inf.filename]={'bytes':len(body),'sha256':digest(body),'zip_mode':inf.external_attr>>16}
  record='sqlcipher3-0.6.4.dist-info/RECORD';assert record in members
  record_rows=list(csv.reader(io.StringIO(z.read(record).decode('utf-8'))));seen=set()
  for n,h,s in record_rows:
   assert n not in seen and n in members;seen.add(n)
   if n==record: assert h==s=='';continue
   algorithm,value=h.split('=',1);assert algorithm=='sha256'
   observed=base64.urlsafe_b64encode(bytes.fromhex(members[n]['sha256'])).decode().rstrip('=')
   assert observed==value and str(members[n]['bytes'])==s
  assert seen==set(members)
  wheel=z.read('sqlcipher3-0.6.4.dist-info/WHEEL').decode();meta=z.read('sqlcipher3-0.6.4.dist-info/METADATA').decode()
  assert 'Root-Is-Purelib: false' in wheel and 'Version: 0.6.4' in meta
  native=[n for n in members if n.endswith(('.pyd','.so'))];assert len(native)==1
  b=z.read(native[0]);format_info={}
  if 'win_amd64' in name:
   assert b[:2]==b'MZ';offset=struct.unpack_from('<I',b,0x3c)[0];assert offset+26<=len(b) and b[offset:offset+4]==b'PE\0\0'
   machine=struct.unpack_from('<H',b,offset+4)[0];magic=struct.unpack_from('<H',b,offset+24)[0]
   assert machine==0x8664 and magic==0x20b
   format_info={'kind':'PE32+','machine_hex':hex(machine),'scope':'Header architecture only; imports/loader/runtime untested'}
  elif 'manylinux' in name:
   assert b[:6]==b'\x7fELF\x02\x01' and struct.unpack_from('<H',b,18)[0]==62
   format_info={'kind':'ELF64little','machine':62,'scope':'Header architecture only; GNU symbol requirements/loader/runtime untested'}
  else:
   assert b[:4]==b'\xcf\xfa\xed\xfe' and struct.unpack_from('<I',b,4)[0]==0x100000c
   format_info={'kind':'MachO64little','cpu_hex':'0x100000c','scope':'Header architecture only; this download is not a new runtime execution'}
  readable={n:z.read(n).decode('utf-8') for n in members if n.endswith(('/METADATA','/WHEEL')) or 'license' in n.lower() or n.lower().endswith(('copying','notice'))}
  dump(name+'.readable-metadata.json',readable)
  rows.append({'filename':name,'download':rec,'published_size':row['size'],'upload_time_iso_8601':row['upload_time_iso_8601'],'members':members,'record_exact':True,'native_member':native[0],'native_architecture':format_info,'wheel_metadata':wheel})
dump('inspection.json',{'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'DATA_ONLY_OFFICIAL_PROJECT_RELEASE_WHEELS_NO_INSTALL_IMPORT_NATIVE_EXECUTION_OR_CANONICAL_WRITE','package_project':'https://pypi.org/project/sqlcipher3/0.6.4/','upstream_binding_project':'https://github.com/coleifer/sqlcipher3','not_zetetic_supported_binary_claim':True,'release_info':{k:metadata['info'].get(k) for k in ['name','version','requires_python','requires_dist','license','license_expression','project_urls']},'wheels':rows,'limits':['Official project release is not a Zetetic commercial support or redistribution approval.','No runtime, encryption, platform certification, dependency lock change, SBOM completion or M04 credit.','Native member header checks do not validate imports, complete ABI, GNU version nodes, signatures or runtime loading.']})
print(json.dumps({'downloaded':len(rows),'all_record_joins':True,'bytes':sum(x['download']['bytes'] for x in rows),'native_formats':[x['native_architecture']['kind'] for x in rows]}))
