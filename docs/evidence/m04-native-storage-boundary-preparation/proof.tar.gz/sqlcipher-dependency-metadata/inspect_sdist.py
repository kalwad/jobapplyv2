from pathlib import Path, PurePosixPath
import datetime, hashlib, io, json, stat, tarfile, urllib.parse, urllib.request
OUT=Path(__file__).parent
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(n,v):(OUT/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
meta=json.loads((OUT/'pypi-release-original.json').read_bytes())
a=[r for r in meta['urls'] if r['filename']=='sqlcipher3-0.6.4.tar.gz'];assert len(a)==1
r=a[0];assert r['packagetype']=='sdist' and not r['yanked'] and r['size']<8*1024**2
u=urllib.parse.urlsplit(r['url']);assert u.scheme=='https' and u.hostname=='files.pythonhosted.org' and not u.username and not u.password and u.port in (None,443)
class Gate(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*a,**kw):raise ValueError('Redirect refused')
opener=urllib.request.build_opener(Gate())
with opener.open(r['url'],timeout=30) as response:
 assert response.status==200
 b=response.read(8*1024**2+1);assert len(b)==r['size'] and sha(b)==r['digests']['sha256']
 request={'url':r['url'],'status':response.status,'date':response.headers.get('Date'),'bytes':len(b),'sha256':sha(b),'upload_time_iso_8601':r['upload_time_iso_8601']}
(OUT/r['filename']).write_bytes(b)
rows=[];texts={};names=set();total=0
with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as ar:
 for m in ar:
  p=PurePosixPath(m.name);assert not p.is_absolute() and '..' not in p.parts and '\\' not in m.name and p.parts[0]=='sqlcipher3-0.6.4'
  assert m.name not in names;names.add(m.name);assert len(names)<=256
  if m.isdir():continue
  assert m.isfile() and m.size<=24*1024**2
  total+=m.size;assert total<=64*1024**2
  data=ar.extractfile(m).read();assert len(data)==m.size
  rows.append({'path':m.name,'bytes':m.size,'mode':m.mode,'sha256':sha(data)})
  rel='/'.join(p.parts[1:])
  if rel in {'LICENSE','pyproject.toml','setup.py','conanfile.py','README.md','MANIFEST.in'} or rel.startswith('.github/workflows/'):
   assert len(data)<128*1024;texts[rel]=data.decode()
  if rel=='vendor/sqlite3.c':
   texts['vendor/sqlite3.c.first-16384-bytes']=data[:16384].decode()
  if rel=='vendor/sqlite3.h':texts['vendor/sqlite3.h.first-16384-bytes']=data[:16384].decode()
dump('sdist-inspection.json',{'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'DATA_ONLY_NO_EXTRACTION_IMPORT_BUILD_OR_EXECUTION','download':request,'safe_regular_members':len(rows),'total_uncompressed_regular_bytes':total,'members':rows,'retained_text_excerpts':texts,'limits':['Source distribution hash and static contents do not attest that a wheel was reproducibly built from it.','Bundled native dependency license/SBOM and runtime loading remain separate; no redistribution approval.']})
print(json.dumps({'safe_regular_members':len(rows),'bytes':len(b),'sha256':sha(b),'text_keys':sorted(texts)}))
