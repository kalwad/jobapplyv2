"""Independent read-only GUI receipt joins. No launch, imports, probes or signals."""
from pathlib import Path
from datetime import datetime
import hashlib
import json
import re
import stat
import tarfile

R=Path('/Users/tanishkalwad/jobapplyv2')
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
B=E/'mac-package-refreshed/fresh-native-gui-9872'
OUT=E/'fresh-native-gui-9872-review'
checks=[]
def sha(data):return hashlib.sha256(data).hexdigest()
def check(label,value):checks.append({'check':label,'pass':bool(value)})
def load(name):return json.loads((B/name).read_bytes())
check('sealedGUIsource',sha((B/'SOURCE.json').read_bytes())=='80f4bd8ec99aa7687e59f2a0a83cf259f74edcb0f098dca85f71153ab09c62c7')
source=load('SOURCE.json')['files']
check('32unique payloads',len(source)==32 and len({r['path'] for r in source})==32)
for row in source:
    p=B/row['path'];info=p.lstat()
    check('payload '+row['path'],stat.S_ISREG(info.st_mode) and info.st_size==row['bytes'] and stat.S_IMODE(info.st_mode)==row['mode'] and sha(p.read_bytes())==row['sha256'])
start=load('start-observation.json');end=load('23-after-source-observation.json');closure=load('24-lifecycle-closure.json')
check('recordedclean9872headtree',start['head']==end['head']=='9872acaf6191ce77fd1c077ef27ea972b71b8315' and start['tree']==end['tree']=='f2d982dfe441ca6a98c2f9ae2862c3efd1e4373a' and start['git_status']==end['git_status']=='')
check('postlaunchbaselineexplicit','not a pre-launch' in start['boundary'])
check('43app endpointsfullmode',len(start['app_files'])==43 and start['app_files']==end['app_files'])
app=Path(start['app_path'])
check('app current exactdomain',{str(p.relative_to(app)) for p in app.rglob('*') if p.is_file()}==set(start['app_files']))
for name,row in end['app_files'].items():
    p=app/name;i=p.lstat()
    check('app '+name,stat.S_ISREG(i.st_mode) and i.st_size==row['bytes'] and stat.S_IMODE(i.st_mode)==row['mode'] and sha(p.read_bytes())==row['sha256'])
full=json.loads((E/'full-9872aca/after.json').read_bytes())
check('2141source40runtimecleanfulljoins',len(end['source'])==2141 and len(end['runtime'])==40 and end['source']==full['source'] and end['runtime']==full['runtime'])
for name,row in end['runtime'].items():
    check('runtime embeddedfullmode '+name,end['app_files']['Contents/Resources/runtime/'+name]==row)
static_path=R/'docs/evidence/m03-w06-refreshed-macos-static/proof.tar.gz'
check('priorstaticproofidentity',sha(static_path.read_bytes())=='78f2ee13722824baeae10ee715f41878947be0d66004c76287ab363f33b8bb15')
with tarfile.open(static_path) as z:
    inspection=json.loads(z.extractfile('static-inspection/inspection.json').read())
    prior=json.loads(z.extractfile('actual/app-build-after.json').read())
    check('prior43staticbuildbytes', {row['path']:{'bytes':row['bytes'],'sha256':row['sha256']} for row in inspection['baseline_app_files']}=={n:{'bytes':r['bytes'],'sha256':r['sha256']} for n,r in start['app_files'].items()})
    changed={n for n in prior['source'].keys()&end['source'].keys() if prior['source'][n]!=end['source'][n]}
    check('onlytestsanddocschangefrom204build',changed=={'apps/desktop/src-tauri/src/service/platform_adapters/app_owner_tests.rs','services/orchestrator/tests/test_runtime_metadata.py','docs/PROJECT_STATUS.md','docs/TEST_EVIDENCE.md','docs/KNOWN_ISSUES.md'} and not prior['source'].keys()-end['source'].keys() and not any(n.startswith(('apps/desktop/','services/orchestrator/','packaging/')) for n in end['source'].keys()-prior['source'].keys()))
    (OUT/'static-reference.json').write_text(json.dumps({'proof_sha256':sha(static_path.read_bytes()),'inspection':inspection,'app_build_after':prior},indent=2)+'\n')
archive=E/'m04-native-path-consumer-preparation/canonical-9872-source.tar'
check('immutable9872archivepin',sha(archive.read_bytes())=='27d9b0c6cec32e553a33f29485c2992addf3b61151d6ce06f4975fdfeb831a02')
normalized={}
with tarfile.open(archive) as z:
    members={m.name:m for m in z.getmembers() if m.isfile()}
    check('exactimmutable source domain',set(members)==set(end['source']))
    for name,m in members.items():
        data=z.extractfile(m).read();safe=tarfile.data_filter(m,str(OUT/'never-extracted'))
        row={'bytes':len(data),'git_archive_mode':stat.S_IMODE(m.mode),'normalized_archive_mode':stat.S_IMODE(safe.mode),'canonical_endpoint_mode':end['source'][name]['mode'],'sha256':sha(data)}
        normalized[name]=row
        check('immutable source '+name,row['bytes']==end['source'][name]['bytes'] and row['sha256']==end['source'][name]['sha256'] and bool(row['git_archive_mode']&0o111)==bool(end['source'][name]['mode']&0o111))
(OUT/'source-reference.json').write_text(json.dumps({'archive_sha256':sha(archive.read_bytes()),'head':end['head'],'tree':end['tree'],'normalized_source':normalized},indent=2)+'\n')
cohort_names=['05-ready-processes-auth','06-forced-service-before','09-before-close','13-relaunch-processes-auth','18-forced-app-before','21-post-proof-relaunch-processes']
cohorts=[load(n+'.json') for n in cohort_names]
app_image=str(app/'Contents/MacOS/japp-desktop');service_image=str(app/'Contents/Resources/runtime/japp-orchestrator/japp-orchestrator')
for name,cohort in zip(cohort_names,cohorts,strict=True):
    a,c=cohort['processes']
    check('exactimage/parent/groups '+name,a['command']==app_image and c['command']==service_image and c['ppid']==a['pid'] and a['pgid']==a['pid'] and c['pgid']==c['pid'] and f"127.0.0.1:{cohort['port']} (LISTEN)" in cohort['network_stdout'])
initial=cohorts[0];recovered=cohorts[2]
check('sameapp-newservice-newport',initial['processes'][0]==recovered['processes'][0] and initial['processes'][1]['pid']!=recovered['processes'][1]['pid'] and initial['port']!=recovered['port'])
sent=load('06-forced-service-sent.json')
check('serviceonlysignal',sent['signal']=='SIGKILL to observed service only' and sent['processes']==cohorts[1]['processes'] and 'signal_sent_utc' in sent)
requests=initial['unauthorized_requests']+cohorts[3]['unauthorized_requests']
check('12401requests',len(requests)==12 and all(r['status']==401 and r['response_bytes']<=4096 and re.fullmatch('[a-f0-9]{64}',r['response_sha256']) for r in requests))
for cohort in (initial,cohorts[3]):
    check('sixauthcombinations '+cohort['utc'], {(r['path'],r['authorization']) for r in cohort['unauthorized_requests']}=={(p,a) for p in ['/api/v1/health','/api/v1/ready','/api/v1/version'] for a in ['absent','known invalid synthetic token']})
for name in ['11-after-close-processes','16-after-quit-processes','18-forced-app-result','22-final-cleanup']:
    row=load(name+'.json')
    check('closedknowncohort '+name,row['passed'] and row['remaining']==[] and row['exclusive_bind_succeeded_and_released'] and row['seconds_until_observed_groups_absent']<12)
check('appaloneforced',cohorts[4]['signal']=='SIGKILL to observed app only')
forced=load('18-forced-app-result.json')
check('forcepollmeasurement',0.296478<=forced['seconds_until_observed_groups_absent']<0.296480)
check('separatelaunchdifferentids',set(p['pid'] for p in cohorts[4]['processes']).isdisjoint(p['pid'] for p in cohorts[5]['processes']))
pids=sorted({p['pid'] for c in cohorts for p in c['processes']});groups=sorted({p['pgid'] for c in cohorts for p in c['processes']});ports=sorted({c['port'] for c in cohorts})
check('finalobservedcohortclosure',closure['observed_pid_set']==pids and closure['observed_group_set']==groups and not closure['final_remaining_cohort_or_exact_images'])
check('fiveportsreleased',len(ports)==5 and closure['final_port_bind_checks']==[{'port':p,'exclusive_bind_succeeded_and_released':True} for p in ports])
texts={p.name:p.read_text() for p in B.glob('*.txt')}
for name in ['02-keyboard-tab.txt','03-keyboard-shift-tab.txt','04-keyboard-refresh.txt','08-recovered-ready.txt','12-relaunch-ready.txt','17-before-forced-app.txt','20-post-proof-relaunch-ready.txt']:
    check('nativeversionsready '+name,all(v in texts[name] for v in ['text 0.0.1','text 2.12.4','text Ready','text 1.0.0','Unavailable in this build','Not evaluated']))
check('keyboardfocusreversal',texts['02-keyboard-tab.txt'].endswith('The focused UI element is 41 button Check again') and texts['03-keyboard-shift-tab.txt'].endswith('The focused UI element is 14 link Diagnostics, Value: tauri://localhost#diagnostics'))
def checked(name):return datetime.fromisoformat(re.findall(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d+Z',texts[name])[0])
check('refreshcheckedatadvances',checked('04-keyboard-refresh.txt')>checked('02-keyboard-tab.txt'))
check('crashstatetitleandnewreadytimestamp','Restarting local service' in texts['07-after-service-crash.txt'] and checked('08-recovered-ready.txt')>checked('04-keyboard-refresh.txt'))
check('closequitobserved', 'App quit' in texts['10-after-close-observation.txt'] and 'Quit Desktop App, ID: terminate:' in texts['14-app-quit-menu.txt'] and 'procNotFound' in texts['15-after-quit-observation.txt'])
check('postproofstartingkeptdistinct','Starting local service' in texts['19-after-forced-app-ax.txt'] and 'Home · Desktop app' in texts['19-after-forced-app-ax.txt'] and 'text Ready' in texts['20-post-proof-relaunch-ready.txt'])
check('rawJPEGimagesretainedunderoriginalnames',all((B/n).read_bytes().startswith(b'\xff\xd8\xff') and (B/n).read_bytes().endswith(b'\xff\xd9') for n in ['01-ready.png','08-recovered-ready.png']))
result={'scope':'Independent read-only joins; screenshots separately visually inspected; no fresh actor execution','passed':sum(c['pass'] for c in checks),'total':len(checks),'checks':checks}
(OUT/'checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':result['passed'],'total':result['total'],'failures':[c['check'] for c in checks if not c['pass']]}))
assert all(c['pass'] for c in checks)
