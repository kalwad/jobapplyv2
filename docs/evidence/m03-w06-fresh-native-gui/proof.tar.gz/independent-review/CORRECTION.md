# Review observer correction

The initial independent audit (2275/2301 joins) made two incorrect assumptions. All 26 failures are retained in initial-review-checks.json with initial-audit.py; no product or GUI actor was rerun.

Twenty-five historical evidence files are physically read-only (0444) at the recorded clean-full and GUI-end endpoints. Git stores executable class, not complete permission bits; its tar 0664 and safe-extraction 0644 are not the canonical full-mode oracle. The corrected audit checks immutable Git bytes/executable class separately and exact clean-full→GUI-end full-mode equality. Every source byte already matched.

The two original .png-named screenshot files contain JPEG/JFIF bytes. Both were visually inspected successfully. The corrected check recognizes their actual JPEG magic; the original names, bodies, hashes and sealed 32-payload manifest remain unchanged. The evidence proposal labels MIME image/jpeg. No image transformation or lifecycle failure is inferred from the filename mismatch.

The corrected same-byte audit passes 2301/2301 joins. The later supplemental host-context observation is separate from this original audit and is not backdated to GUI startup.
