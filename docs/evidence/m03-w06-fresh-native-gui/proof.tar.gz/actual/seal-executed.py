"""Pure retained-data/source/known-process closure; no launch or signal."""
from pathlib import Path
import datetime
import hashlib
import json
import socket
import stat
import subprocess

R=Path('/Users/tanishkalwad/jobapplyv2')
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
B=E/'mac-package-refreshed/fresh-native-gui-9872'
def sha(data):return hashlib.sha256(data).hexdigest()
def snap(base, paths):
 result={}
 for name in paths:
  path=base/name;i=path.lstat();assert stat.S_ISREG(i.st_mode)
  result[str(name)]={'bytes':i.st_size,'mode':stat.S_IMODE(i.st_mode),'sha256':sha(path.read_bytes())}
 return result
start=json.loads((B/'start-observation.json').read_bytes())
app=Path(start['app_path'])
appafter=snap(app,start['app_files'])
assert start['app_files']==appafter
assert len([p for p in app.rglob('*') if p.is_file()])==len(appafter)==43
fullafter=json.loads((E/'full-9872aca/after.json').read_bytes())
source=snap(R,fullafter['source'])
runtime=snap(R/'apps/desktop/src-tauri/runtime-payload',fullafter['runtime'])
status=subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)
assert source==fullafter['source'] and runtime==fullafter['runtime'] and status==''
record={'recorded_utc':datetime.datetime.now(datetime.UTC).isoformat(),'source':source,'runtime':runtime,'git_status':status,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=R,text=True).strip(),'app_files':appafter,'boundary':'Actual end of fresh GUI exercise, separate later observation from full aggregate endpoint'}
(B/'23-after-source-observation.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
names=['05-ready-processes-auth','06-forced-service-before','09-before-close','13-relaunch-processes-auth','18-forced-app-before','21-post-proof-relaunch-processes']
cohort=[json.loads((B/(name+'.json')).read_bytes()) for name in names]
pids={r['pid'] for c in cohort for r in c['processes']};groups={r['pgid'] for c in cohort for r in c['processes']};ports=sorted({c['port'] for c in cohort})
raw=subprocess.check_output(['/bin/ps','-axo','pid=,ppid=,pgid=,comm='],text=True,timeout=3)
remaining=[]
for line in raw.splitlines():
 p=line.strip().split(None,3)
 if len(p)==4 and (int(p[0]) in pids or int(p[2]) in groups or p[3] in {cohort[0]['processes'][0]['command'],cohort[0]['processes'][1]['command']}):
  remaining.append({'pid':int(p[0]),'ppid':int(p[1]),'pgid':int(p[2]),'command':p[3]})
bindings=[]
for port in ports:
 with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as sock:
  sock.settimeout(1)
  try:sock.bind(('127.0.0.1',port));free=True
  except OSError:free=False
 bindings.append({'port':port,'exclusive_bind_succeeded_and_released':free})
assert not remaining and all(row['exclusive_bind_succeeded_and_released'] for row in bindings)
before=cohort[0];restarted=cohort[2]
assert before['processes'][0]==restarted['processes'][0]
assert before['processes'][1]['pid']!=restarted['processes'][1]['pid'] and before['port']!=restarted['port']
requests=before['unauthorized_requests']+cohort[3]['unauthorized_requests']
assert len(requests)==12 and all(r['status']==401 for r in requests)
assert all(json.loads((B/(name+'.json')).read_bytes())['passed'] for name in ['11-after-close-processes','16-after-quit-processes','18-forced-app-result','22-final-cleanup'])
text={p.name:p.read_text() for p in B.glob('*.txt')}
assert 'Restarting local service' in text['07-after-service-crash.txt']
assert all('text Ready' in text[name] for name in ['02-keyboard-tab.txt','04-keyboard-refresh.txt','08-recovered-ready.txt','12-relaunch-ready.txt','17-before-forced-app.txt','20-post-proof-relaunch-ready.txt'])
closure={'scope':'Actual fresh macOS CUA/packaged app lifecycle, not foreign-platform or release certification','utc':datetime.datetime.now(datetime.UTC).isoformat(),'app_files':43,'app_bytes_modes_equal_postlaunch_to_end':start['app_files']==appafter,'source2141_runtime40_bytes_modes_equal_clean_full_after':source==fullafter['source'] and runtime==fullafter['runtime'],'current_git_status':status,'same_app_new_service_pid_and_port_after_crash':True,'unauthorized_requests':12,'all_401':True,'observed_pid_set':sorted(pids),'observed_group_set':sorted(groups),'final_remaining_cohort_or_exact_images':remaining,'final_port_bind_checks':bindings,'GUI_observations':['nativeapp0.0.1/Tauri2.12.4/service0.0.1/API1.0.0 Ready','Tab Check again; ShiftTab Diagnostics; Tab+Return newerCheckedAt','Restarting title after owned serviceSIGKILL then refreshedReady','Close observedAppquit then known groups absent','exactpathrelaunch Ready and nativeAppMenu Quit then known groups absent','owned appSIGKILL followed known app/service groups absent and prior portbindfree','postproofgetAX observed separate newStarting launch; preserved independently and keyboardQuit cleanup confirmed'],'limits':['Initial app43 snapshot is postlaunch, not prelaunch; earlier separate static package inventory supplies build binding','No controlled PATH or raw LaunchServices provenance measurement','No kernel creation-time/process-handle or universal escaped-descendant guarantee','NormalClose/Quit poll timers start at post-UI observation and are not shutdown latency','Post-force AX observation showed a separate launch; cause is not attested','No foreign platform/Keychain/model/AI qualification/wholeproject completion claim']}
(B/'24-lifecycle-closure.json').write_text(json.dumps(closure,indent=2)+'\n')
(B/'README.md').write_text('Fresh GUI lifecycle at current9872 sources and unchanged204-built production package. User manually unlocked Mac after four held exact-app CUA attempts. CUA exact-path launch observed Starting, then actual native DiagnosticsReadyversions. Keyboard focus reverses and Return refresh advances checked timestamp. Twelve direct loopback requests (missing and fixed-invalid synthetic authorization, three routes before crash/afterrelaunch) return401; no realtoken/argv/environment read. An observed exact owned service alone receivesSIGKILL; windowtitleRestarting is retained, then actual refreshReady with sameapp/newservicePID+port. NormalClose and nativeMenuQuit each lead to observed known groups absent/portfree. Owned app alone then receivesSIGKILL; its known app/service groups disappear and oldportbinds within0.296479s of signal-helper observation. This is a scoped process observation, not kernelcreation/escaped-descendant attestation.\n\nA subsequent CUA getAX after that closed proof unexpectedly observes a separate newStarting launch;19/20/21 are preserved, no cause is invented, and finalkeyboardQuit22 plus finalcohort scan leave allobservedPIDs/groups/exactimages absent and allfive priorports bindable/released. NormalClose/Quit timers measure post-UI polls, not end-to-endshutdownlatency. The final UI action uses keyboardQuit with process-observed closure; no furtherCUAquery was made because the postforcequery had observed anotherlaunch. NativeOSServices submenu entries in14are incidental own-app menu text and carry no productbehavior claim.\n\nAll43app file bytes/fullmodes equal postlaunch andend; all2141canonical source/40runtimebytes/fullmodes equal cleanfullafter, currenthead9872/treef2d9/statusclean atGUIend. Initial fullaggregate context and endpoint joins remain separate. Earlier staticbuild/signature/currentwheel proof remains at docs/evidence/m03-w06-refreshed-macos-static. No controlledGUIenvironment/PATH/rawLaunchServices-provenance, no universaldescendant/heldprocesshandle, no actualWindows11/GNOME, noKeychain/modelqualification/milestone/release approval is implied. Freshnative actor source/body receipts are retained; one initialHomeAX is tool-outputonly, not reconstructed.\n')
(B/'seal-executed.py').write_bytes(Path(__file__).read_bytes())
rows=[]
for p in sorted(B.iterdir()):
 if p.is_file() and p.name not in {'SOURCE.json','HANDOFF.json'}:
  i=p.lstat();rows.append({'path':p.name,'bytes':i.st_size,'mode':stat.S_IMODE(i.st_mode),'sha256':sha(p.read_bytes())})
(B/'SOURCE.json').write_text(json.dumps({'scope':'Requires different read-only review; freshGUIevidence only','files':rows},indent=2)+'\n')
handoff={'source_sha256':sha((B/'SOURCE.json').read_bytes()),'files':len(rows),'app43_unchanged':True,'source2141_runtime40_unchanged':True,'known_cohort_final_absent':True,'all_five_prior_ports_exclusive_bind_and_release':True,'independent_review':'PENDING','no_milestone_promotion':True}
(B/'HANDOFF.json').write_text(json.dumps(handoff,indent=2)+'\n')
print(json.dumps(handoff))
