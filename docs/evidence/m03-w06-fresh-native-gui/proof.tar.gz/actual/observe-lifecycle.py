"""Exact disposable product bundle only; no argv, environment or token reads."""
from pathlib import Path
import datetime
import hashlib
import http.client
import json
import os
import re
import signal
import socket
import subprocess
import sys
import time

OUT = Path(__file__).parent
APP = str(OUT.parent/'launch space 应用/Desktop App.app/Contents/MacOS/japp-desktop')
SERVICE = str(OUT.parent/'launch space 应用/Desktop App.app/Contents/Resources/runtime/japp-orchestrator/japp-orchestrator')

def save(name, value):
    with (OUT/(name+'.json')).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def observe():
    raw = subprocess.check_output(['/bin/ps','-axo','pid=,ppid=,pgid=,comm='],text=True,timeout=3)
    rows=[]
    for line in raw.splitlines():
        p=line.strip().split(None,3)
        if len(p)==4:
            rows.append({'pid':int(p[0]),'ppid':int(p[1]),'pgid':int(p[2]),'command':p[3]})
    return rows

def live():
    rows=observe();apps=[r for r in rows if r['command']==APP]
    assert len(apps)==1
    app=apps[0];children=[r for r in rows if r['ppid']==app['pid']]
    assert len(children)==1 and children[0]['command']==SERVICE
    child=children[0]
    network=subprocess.check_output(['/usr/sbin/lsof','-nP','-a','-p',str(child['pid']),'-iTCP','-sTCP:LISTEN'],text=True,timeout=3)
    lines=[s for s in network.splitlines() if 'TCP ' in s]
    assert len(lines)==1
    ports=re.findall(r'TCP 127\.0\.0\.1:(\d+) \(LISTEN\)',network)
    assert len(ports)==1
    relevant=[r for r in observe() if r['pid'] in {app['pid'],child['pid']}]
    assert relevant==[app,child]
    return {'utc':datetime.datetime.now(datetime.UTC).isoformat(),'processes':[app,child],'network_stdout':network,'port':int(ports[0]),'scope':'Observed exact image/parent/group equality twice; no kernel creation-time or escaped-descendant attestation'}

def exited(before):
    ids={r['pid'] for r in before['processes']};groups={r['pgid'] for r in before['processes']}
    start=time.monotonic();deadline=start+12
    while True:
        remaining=[r for r in observe() if r['pid'] in ids or r['pgid'] in groups]
        if not remaining or time.monotonic()>=deadline:break
        time.sleep(0.05)
    with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as sock:
        sock.settimeout(1)
        try:sock.bind(('127.0.0.1',before['port']));bound=True
        except OSError:bound=False
    return {'utc':datetime.datetime.now(datetime.UTC).isoformat(),'seconds_until_observed_groups_absent':time.monotonic()-start,'remaining':remaining,'exclusive_bind_succeeded_and_released':bound,'passed':not remaining and bound,'scope':'Known observed app/service groups and exact prior port only; no universal escaped-descendant proof'}

def main():
    operation=sys.argv[1];stem=sys.argv[2]
    assert re.fullmatch('[a-z0-9-]{1,60}',stem)
    if operation=='exited':
        before=json.loads((OUT/(sys.argv[3]+'.json')).read_bytes());record=exited(before);save(stem,record);print(json.dumps(record));assert record['passed'];return
    record=live()
    if operation=='auth':
        results=[]
        for endpoint in ['/api/v1/health','/api/v1/ready','/api/v1/version']:
            for invalid in [False,True]:
                headers={'Authorization':'Bearer '+'0'*64} if invalid else {}
                connection=http.client.HTTPConnection('127.0.0.1',record['port'],timeout=2)
                try:
                    connection.request('GET',endpoint,headers=headers);response=connection.getresponse();data=response.read(4097)
                    assert len(data)<=4096
                    results.append({'path':endpoint,'authorization':'known invalid synthetic token' if invalid else 'absent','status':response.status,'response_bytes':len(data),'response_sha256':hashlib.sha256(data).hexdigest()})
                finally:connection.close()
        record['unauthorized_requests']=results
        save(stem,record);print(json.dumps(record));assert all(r['status']==401 for r in results);return
    if operation in {'crash-service','force-parent'}:
        target=record['processes'][1 if operation=='crash-service' else 0]
        record['signal']='SIGKILL to '+('observed service only' if operation=='crash-service' else 'observed app only')
        save(stem+'-before',record)
        assert [r for r in observe() if r['pid'] in {p['pid'] for p in record['processes']}]==record['processes']
        os.kill(target['pid'],signal.SIGKILL)
        record['signal_sent_utc']=datetime.datetime.now(datetime.UTC).isoformat()
        if operation=='force-parent':
            result=exited(record);save(stem+'-result',result);print(json.dumps(result));assert result['passed']
        else:save(stem+'-sent',record);print(json.dumps({'signal':record['signal'],'pid':target['pid'],'prior_port':record['port']}))
        return
    assert operation=='observe'
    save(stem,record);print(json.dumps(record))

if __name__=='__main__':main()
