"""Finite stdlib source/data joins; no subject import, execution or extraction."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import re
import stat
import tarfile

E = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
P = E / 'm04-common-secret-bridge-preparation/v1'
OUT = Path(__file__).parent
checks = []

def load(p):
    return json.loads(p.read_text())

def pin(p):
    info = p.lstat()
    assert stat.S_ISREG(info.st_mode), str(p)
    return {'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode),
            'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}

def check(name, passed, detail=None):
    checks.append({'name': name, 'pass': bool(passed), 'detail': detail})

def safe(name):
    return bool(name) and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts and '\\' not in name and '\0' not in name

source = load(P / 'SOURCE.json')
records = source['records']
check('exact_SOURCE_pin', pin(P / 'SOURCE.json')['sha256'] == '1d316ebb9d81ebd8c2c2cb7dd118987b255161decae367cc7a779321e741d740')
check('209_loose_records_bytes_full_modes_safe_regular', len(records) == 209 and all(safe(n) and pin(P / n) == row for n, row in records.items()))
archive_record = load(P / 'ARCHIVE.json')
handoff = load(P / 'HANDOFF.json')
proof = pin(P / 'proof.tar.gz')
check('exact_proof_hash_size_and_receipt_joins', proof['sha256'] == '23fbb2132589a82804d4b0e9d692e77d2df5380a45250df84afa0981c3d325ad' and proof['bytes'] == 406639 and all(v['archive_sha256'] == proof['sha256'] and v['archive_bytes'] == proof['bytes'] and v['SOURCE_sha256'] == pin(P / 'SOURCE.json')['sha256'] for v in (archive_record, handoff)))
with gzip.open(P / 'proof.tar.gz', 'rb') as compressed:
    raw = compressed.read(8 * 1024 * 1024 + 1)
assert len(raw) <= 8 * 1024 * 1024
logical = {}
with tarfile.open(fileobj=io.BytesIO(raw), mode='r:') as archive:
    for member in archive:
        assert member.isreg() and safe(member.name) and member.name not in logical
        assert set(member.pax_headers) <= {'mtime', 'path'}
        if 'path' in member.pax_headers:
            assert member.pax_headers['path'] == member.name and safe(member.name)
        body = archive.extractfile(member).read()
        logical[member.name] = {'bytes': len(body), 'mode': member.mode, 'sha256': hashlib.sha256(body).hexdigest()}
expected = dict(records, **{'SOURCE.json': pin(P / 'SOURCE.json')})
check('210_logical_archive_members_bytes_full_modes_SOURCE_join', logical == expected and len(logical) == 210)
receipt_table = {r['name']: {k: r[k] for k in ('bytes', 'mode', 'sha256')} for r in archive_record['members']}
check('ARCHIVE_member_table_and_payload_sum_join', receipt_table == logical and len(archive_record['members']) == 210 and sum(r['bytes'] for r in logical.values()) == archive_record['uncompressed_bytes'] == 1984732)

# Inspect the physical stream as well: only local PAX metadata and regular files.
offset = 0
pending = {}
physical = {}
types = {}
octal = lambda b: int(b.strip(b'\0 ') or b'0', 8)
while offset + 512 <= len(raw):
    header = raw[offset:offset + 512]
    if not any(header):
        assert len(raw) - offset >= 1024 and not any(raw[offset:])
        break
    assert sum(header[:148]) + 8 * 32 + sum(header[156:]) == octal(header[148:156])
    size = octal(header[124:136])
    body = raw[offset + 512:offset + 512 + size]
    assert len(body) == size
    next_offset = offset + 512 + ((size + 511) // 512) * 512
    assert not any(raw[offset + 512 + size:next_offset])
    kind = header[156:157]
    types[kind.decode()] = types.get(kind.decode(), 0) + 1
    if kind == b'x':
        assert not pending
        cursor = 0
        while cursor < len(body):
            space = body.index(b' ', cursor)
            length = int(body[cursor:space])
            row = body[space + 1:cursor + length]
            assert row.endswith(b'\n') and cursor + length <= len(body)
            key, value = row[:-1].decode().split('=', 1)
            assert key not in pending and key in ('mtime', 'path')
            if key == 'mtime':
                assert re.fullmatch(r'-?\d+(\.\d+)?', value)
            else:
                assert safe(value)
            pending[key] = value
            cursor += length
        assert cursor == len(body)
    else:
        assert kind == b'0'
        name = header[:100].split(b'\0')[0].decode()
        prefix = header[345:500].split(b'\0')[0].decode()
        if prefix:
            name = prefix + '/' + name
        name = pending.get('path', name)
        assert safe(name) and name not in physical
        physical[name] = {'bytes': size, 'mode': octal(header[100:108]), 'sha256': hashlib.sha256(body).hexdigest()}
        pending = {}
    offset = next_offset
assert not pending
check('raw_tar_checksums_lengths_padding_PAX_types_resolved_path_join', physical == logical and types == {'x': 210, '0': 210}, {'physical_types': types, 'raw_bytes': len(raw)})

parents = load(P / 'PARENT-INPUTS.json')
check('all_seven_original_parent_pins_unchanged', len(parents) == 7 and all(pin(Path(n)) == {k: row[k] for k in ('bytes', 'mode', 'sha256')} for n, row in parents.items()))
common_parent = E / 'm04-native-secret-common-preparation/v1'
bridge_parent = E / 'm04-private-storage-bridge/v3'
common_files = [n[len('vendor/common/'):] for n in records if n.startswith('vendor/common/')]
check('all_20_common_sources_manifests_locks_exact_parent_copy', len(common_files) == 20 and all(pin(P / 'vendor/common' / n) == pin(common_parent / n) for n in common_files))
check('bridge_source_fixture_lock_exact_parent_copy', all(pin(P / 'vendor/bridge' / n) == pin(bridge_parent / n) for n in ('src/lib.rs', 'fixture/native_fixture.rs', 'Cargo.lock')))
check('bridge_manifest_only_shared_keychain_dependency_path_changed', (P / 'vendor/bridge/Cargo.toml').read_text() == (bridge_parent / 'Cargo.toml').read_text().replace('path = "../../m04-keychain-preparation"', 'path = "../common/vendor/keychain"'))
check('retained_parent_SOURCE_seals_exact', pin(P / 'parent-seals/common/SOURCE.json') == pin(common_parent / 'SOURCE.json') and pin(P / 'parent-seals/bridge/SOURCE.json') == pin(bridge_parent / 'SOURCE.json'))
check('our_common_review_retained_exact', all(pin(P / 'parent-seals/common-review' / n) == pin(E / 'm04-native-secret-common-independent-review/v1' / n) for n in ('REVIEW.md', 'manifest.json')))

Q = P / 'quality/check-v2'
N = P / 'negative-flattened-failure'
R = N / 'quality/actual'
green, mutant = load(Q / 'results.json'), load(R / 'results.json')
for label, root, folder, result in [('green', P, Q, green), ('mutant', N, R, mutant)]:
    check(label + '_31_input_endpoints_current_and_retained_source_exact', len(result['before']) == 31 and result['before'] == result['after'] and result['source_bytes_modes_unchanged'] and all(pin(root / name) == row == pin(folder / 'source' / name) for name, row in result['before'].items()))
    check(label + '_actual_wrapper_source_body_pin', result['wrapper_source_sha256'] == pin(root / 'run_quality.py')['sha256'] == pin(folder / 'source/run_quality.py')['sha256'])
    check(label + '_commands_closed_and_raw_stdout_stderr_hashes', all(row['direct_child_reaped'] and row['observed_group'] == 'ABSENT' and not row['timeout'] and not row['cleanup_signals'] and row['stdout_sha256'] == pin(folder / (row['name'] + '.stdout'))['sha256'] and row['stderr_sha256'] == pin(folder / (row['name'] + '.stderr'))['sha256'] for row in result['commands']))
check('green_eight_expected_commands_all_zero', [r['name'] for r in green['commands']] == ['ruff', 'ruff-format', 'new-rustfmt', 'clippy', 'metadata', 'integration', 'unchanged-bridge', 'unchanged-common'] and all(r['exit_code'] == 0 for r in green['commands']))
check('mutant_only_integration_expected_test_failure_101', len(mutant['commands']) == 1 and mutant['commands'][0]['name'] == 'integration' and mutant['commands'][0]['exit_code'] == 101 and '--test' in mutant['commands'][0]['argv'])
metadata = load(Q / 'metadata.stdout')
dependency_join = load(P / 'DEPENDENCY-JOIN.json')
keychains = [v for v in metadata['packages'] if v['name'] == 'japp-synthetic-keychain-preparation']
assert len(keychains) == 1
keychain = keychains[0]
nodes = {v['id']: v for v in metadata['resolve']['nodes']}
packages = {v['name']: v for v in metadata['packages']}
deps = [('japp-native-secret-common-preparation', 'keychain'), ('japp-private-storage-bridge-preparation', 'japp_synthetic_keychain_preparation'), ('japp-common-secret-bridge-preparation', 'keychain')]
check('actual_metadata_single_shared_Keychain_package_identity', all(any(d['name'] == name and d['pkg'] == keychain['id'] for d in nodes[packages[package]['id']]['deps']) for package, name in deps) and keychain['manifest_path'] == str(P / 'vendor/common/vendor/keychain/Cargo.toml') and dependency_join['keychain_package_id'] == keychain['id'] and dependency_join['metadata_stdout_sha256'] == pin(Q / 'metadata.stdout')['sha256'])
src, changed = (P / 'src/lib.rs').read_text(), (N / 'src/lib.rs').read_text()
check('exact_one_line_flattened_failure_mutation', src.count('.map_err(PrepareFailure::Secret)?;') == 1 and changed == src.replace('.map_err(PrepareFailure::Secret)?;', '.map_err(|_| PrepareFailure::Bridge(bridge::Failure::Unavailable))?;'))
green_inputs = green['before']
mutant_inputs = mutant['before']
check('all_other_30_mutant_inputs_including_tests_budgets_protocol_exact', set(green_inputs) == set(mutant_inputs) and [n for n in green_inputs if green_inputs[n] != mutant_inputs[n]] == ['src/lib.rs'])
stdout, redout = (Q / 'integration.stdout').read_text(), (R / 'integration.stdout').read_text()
test_rows = lambda text: re.findall(r'^test ([a-zA-Z0-9_]+) \.\.\. (ok|FAILED)$', text, re.M)
gtests, rtests = test_rows(stdout), test_rows(redout)
check('actual_21_unique_green_tests_and_same_21_mutant_tests', len(gtests) == 21 and len(set(n for n, _ in gtests)) == 21 and all(status == 'ok' for _, status in gtests) and [n for n, _ in gtests] == [n for n, _ in rtests] and '21 passed; 0 failed' in stdout)
check('actual_behavioral_RED_6_PASS_15_FAIL_not_compile_failure', len(rtests) == 21 and sum(status == 'FAILED' for _, status in rtests) == 15 and '6 passed; 15 failed' in redout and 'lost exact secret refusal: Unavailable' in (R / 'integration.stderr').read_text())
children = {}
for label, folder in [('green', Q), ('mutant', R)]:
    rows = re.findall(r'^owned_frame_sink pid=(\d+) exit=0 direct_child_reaped=true group=ABSENT signals=NONE$', (folder / 'integration.stderr').read_text(), re.M)
    children[label] = rows
check('three_green_and_three_mutant_synthetic_parser_child_receipts', all(len(v) == 3 and len(set(v)) == 3 for v in children.values()) and len(set(children['green'] + children['mutant'])) == 6, children)
bridgeout, commonout = (Q / 'unchanged-bridge.stdout').read_text(), (Q / 'unchanged-common.stdout').read_text()
ok_counts = lambda text: [int(n) for n in re.findall(r'test result: ok\. (\d+) passed; 0 failed', text)]
check('actual_154_unchanged_parent_units_plus_11_compilefails', ok_counts(bridgeout) == [5, 1] and ok_counts(commonout) == [13, 21, 51, 64, 4, 2, 2, 2] and sum([5, 13, 21, 51, 64]) == 154)
draft = load(P / 'quality/check-v1/results.json')
check('initial_style_failure_preserved_distinct_from_behavioral_RED', [r['exit_code'] for r in draft['commands']] == [0, 0, 0, 101] and 'unused import: `Write`' in (P / 'quality/check-v1/clippy.stderr').read_text() and 'unreachable pattern' in (P / 'quality/check-v1/clippy.stderr').read_text())
linkage = load(P / 'linkage/result.json')
check('data_only_linkage_receipt_binary_output_pins', all(row['exit_code'] == 0 and row['direct_child_reaped'] and row['observed_group'] == 'ABSENT' and not row['cleanup_signals'] and pin(Path(row['argv'][-1])) == row['binary'] and row['stdout_sha256'] == pin(P / 'linkage' / (Path(row['argv'][-1]).name + '.stdout'))['sha256'] and row['stderr_sha256'] == pin(P / 'linkage' / (Path(row['argv'][-1]).name + '.stderr'))['sha256'] for row in linkage['commands']))
check('HANDOFF_scoped_no_native_or_acceptance_claim', handoff['native_credential_calls'] is False and handoff['SQLCipher_or_private_application_data_calls'] is False and handoff['canonical_writes_or_default_selection'] is False and handoff['M04_credit'] is False)
report = {'decision': 'CLEAR_SCOPED_SOURCE_AND_DATA' if all(v['pass'] for v in checks) else 'HOLD_JOIN_FAILURE', 'checks': checks, 'pass_count': sum(v['pass'] for v in checks), 'fail_count': sum(not v['pass'] for v in checks), 'input_SOURCE': pin(P / 'SOURCE.json'), 'input_proof': proof, 'retained_records': len(records), 'archive_regular_members': len(logical), 'scope': 'Only read source and retained data; no subject import/execution, credential/GIO/D-Bus/native/SQLCipher/private-AppData/network/canonical actor, or source mutation. Only this new review directory is written.', 'remaining_gaps': ['Canonical dependency/module integration and fresh affected checks', 'Trusted host profile plus same-thread native owner/request/cleanup integration', 'Genuine native credential evidence on each supported platform', 'Connection to encrypted service startup and native child/path custody', 'No M04 completion or product acceptance']}
(OUT / 'data-review.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({'decision': report['decision'], 'pass': report['pass_count'], 'fail': report['fail_count'], 'failures': [v for v in checks if not v['pass']]}, indent=2))
