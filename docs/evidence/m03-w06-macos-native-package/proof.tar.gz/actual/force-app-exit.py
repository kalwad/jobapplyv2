from pathlib import Path
import datetime
import json
import os
import re
import signal
import socket
import subprocess
import time

OUT = Path(__file__).parent
APP = str(OUT / 'launch space 应用/Desktop App.app/Contents/MacOS/japp-desktop')
SERVICE = str(OUT / 'launch space 应用/Desktop App.app/Contents/Resources/runtime/japp-orchestrator/japp-orchestrator')

def observe():
    raw = subprocess.check_output(['/bin/ps', '-axo', 'pid=,ppid=,pgid=,comm='], text=True, timeout=2)
    result = []
    for line in raw.splitlines():
        p = line.strip().split(None, 3)
        if len(p) == 4:
            result.append({'pid': int(p[0]), 'ppid': int(p[1]), 'pgid': int(p[2]), 'command': p[3]})
    return result

rows = observe()
apps = [r for r in rows if r['command'] == APP]
assert len(apps) == 1
app = apps[0]
children = [r for r in rows if r['ppid'] == app['pid']]
assert len(children) == 1 and children[0]['command'] == SERVICE
child = children[0]
network = subprocess.check_output(['/usr/sbin/lsof', '-nP', '-a', '-p', str(child['pid']), '-iTCP', '-sTCP:LISTEN'], text=True, timeout=3)
ports = re.findall(r'TCP 127\.0\.0\.1:(\d+) \(LISTEN\)', network)
assert len(ports) == 1
port = int(ports[0])
assert [r for r in observe() if r['pid'] in {app['pid'], child['pid']}] == [app, child]
record = {'utc': datetime.datetime.now(datetime.UTC).isoformat(), 'before': [app, child], 'network': network,
          'signal': 'SIGKILL to app only', 'port': port, 'scope': 'observed app/service identities and groups; no escaped-descendant proof'}
(OUT / 'forced-app-before.json').write_text(json.dumps(record, indent=2) + '\n')
start = time.monotonic()
os.kill(app['pid'], signal.SIGKILL)
deadline = start + 12
while True:
    rows = observe()
    remaining = [r for r in rows if r['pid'] in {app['pid'], child['pid']} or r['pgid'] in {app['pgid'], child['pgid']}]
    if not remaining or time.monotonic() >= deadline:
        break
    time.sleep(min(0.05, max(0, deadline - time.monotonic())))
record['seconds_until_observed_groups_absent'] = time.monotonic() - start
record['remaining'] = remaining
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
    sock.settimeout(1)
    try:
        sock.bind(('127.0.0.1', port))
        record['exclusive_bind_succeeded_and_released'] = True
    except OSError as error:
        record['exclusive_bind_succeeded_and_released'] = False
        record['bind_errno'] = error.errno
record['passed'] = not remaining and record['exclusive_bind_succeeded_and_released']
(OUT / 'forced-app-result.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2), flush=True)
raise SystemExit(0 if record['passed'] else 1)
