from pathlib import Path
import hashlib, json, shutil, stat, tarfile, io
E = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
old = E / 'w07-packaging-corrections'
new = E / 'w07-packaging-corrections-v2'
new.mkdir(exist_ok=False)
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
source = json.loads((old / 'SOURCE.json').read_text())
assert sha(old / 'SOURCE.json') == 'c79c2b374e9e1ed14398e9372bbb9a50cb422cba2320c3eaa4d5d0a432ab2cc7'
for row in source['files']:
    p = old / row['path']
    assert sha(p) == row['sha256'] and stat.S_IMODE(p.stat().st_mode) == row['mode']
    target = new / row['path']
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, target)
(new / 'REPACK.md').write_text('Archive-only v2 correction: the original v1 SOURCE/proof remain unchanged outside. Its 0666 empty uv-lock file was normalized to0644 in the archive without explicit per-row archive-mode metadata. This derivative preserves all57 original retained file bytes/fullmodes and archives those exact modes, adding this receipt and the actual repacker source. No code, test, command result, inventory or raw evidence is changed or reexecuted. The original sealer source remains historical v1 source. Different review found one archive-mode join mismatch, not a product/QA failure. This receipt supersedes only that archive-mode projection.\n')
shutil.copy2(Path(__file__), new / 'repack-executed.py')
rows = source['files'] + [{'path': p.name, 'bytes': p.stat().st_size, 'mode': stat.S_IMODE(p.stat().st_mode), 'sha256': sha(p)} for p in [new / 'REPACK.md', new / 'repack-executed.py']]
source.update(files=rows, archive_permissions='EXACT_SOURCE_MODES_PRESERVED', historical_source_sha256=sha(old / 'SOURCE.json'), historical_proof_sha256=sha(old / 'proof.tar.gz'))
(new / 'SOURCE.json').write_text(json.dumps(source, indent=2) + '\n')
with tarfile.open(new / 'proof.tar.gz', 'w:gz') as tar:
    for row in rows + [{'path': 'SOURCE.json', 'mode': 0o644}]:
        p = new / row['path']
        body = p.read_bytes()
        member = tarfile.TarInfo(row['path'])
        member.mode = row['mode']
        member.size = len(body)
        member.mtime = 0
        tar.addfile(member, io.BytesIO(body))
(new / 'HANDOFF.json').write_text(json.dumps({'source_sha256': sha(new / 'SOURCE.json'), 'proof_sha256': sha(new / 'proof.tar.gz'), 'proof_bytes': (new / 'proof.tar.gz').stat().st_size, 'safe_regular_members': len(rows) + 1, 'original_retained_files_unchanged': 57, 'archive_modes_preserved': True, 'product_actor_reruns': 0}, indent=2) + '\n')
print((new / 'HANDOFF.json').read_text())
