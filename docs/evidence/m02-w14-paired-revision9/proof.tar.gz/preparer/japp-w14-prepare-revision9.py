from pathlib import Path
import datetime
import difflib
import hashlib
import json
import shutil
import stat
import subprocess

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
REL = Path('e2e/extension/legacy-paired-options')
SRC = ROOT / REL
OUT = Path('/tmp/japp-w14-paired-revision9')
OLD_LOCK = 'sha256:0f22812dc44aa46fda51b78ef666738a924e00e0deaaaff977bc33d82729ab3a'
OLD_RUNTIME = 'sha256:8c61ebee8af7823f2812c514fb2bbb5eb0ca44c95b919a5ac3919eb9b5fec9cc'
NEW_RUNTIME = 'sha256:3b6c0e0c0950b03e3bb9e1f12b27bb8d385174c36fb4b68ef3345597aa8b3502'
NAMES = ['campaign.lock.json', 'campaign.lock.sha256', 'predeclaration.json', 'source-bindings.json', 'playwright.config.ts', 'PREEXECUTION.md']
sha = lambda body: 'sha256:' + hashlib.sha256(body).hexdigest()
encode = lambda value: json.dumps(value, indent=2, ensure_ascii=False) + '\n'
canonical = lambda value: json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()
read = lambda path: json.loads(path.read_text())
assert not OUT.exists()
assert sha((SRC / 'campaign.lock.json').read_bytes()) == OLD_LOCK
assert (SRC / 'campaign.lock.sha256').read_text() == OLD_LOCK + '\n'
lock = read(SRC / 'campaign.lock.json')
for row in lock['files']:
    assert sha((SRC / row['path']).read_bytes()) == row['sha256'], row['path']
bindings = read(SRC / 'source-bindings.json')
decl = read(SRC / 'predeclaration.json')
assert decl['preexecution_source_revision'] == 8
assert bindings['candidate_runtime_inventory_digest'] == sha(canonical(bindings['candidate_runtime_sources'])) == OLD_RUNTIME
policy = bindings['candidate_runtime_inventory_policy']
paths = []
def walk(relative):
    directory = ROOT / relative
    assert directory.is_dir() and not directory.is_symlink()
    for path in sorted(directory.iterdir(), key=lambda entry: entry.name):
        assert not path.is_symlink()
        if path.is_dir():
            if path.name not in policy['excluded_directory_names']:
                walk(path.relative_to(ROOT).as_posix())
        elif path.is_file():
            if not any(path.name.endswith(suffix) for suffix in policy['excluded_file_suffixes']):
                paths.append(path.relative_to(ROOT).as_posix())
        else:
            raise AssertionError('nonregular runtime source: ' + str(path))
for directory in policy['directories']:
    walk(directory)
paths.extend(policy['files'])
paths.sort()
assert len(paths) == len(set(paths)) == 355
assert paths == [row['path'] for row in bindings['candidate_runtime_sources']]
assert set(policy['required_runtime_paths']) <= set(paths)
old_by_path = {row['path']: row['sha256'] for row in bindings['candidate_runtime_sources']}
files = []
changes = []
total = 0
for path in paths:
    source = ROOT / path
    assert source.is_file() and not source.is_symlink()
    body = source.read_bytes()
    digest = sha(body)
    files.append({'path': path, 'sha256': digest})
    total += len(body)
    if digest != old_by_path[path]:
        changes.append({'path': path, 'before_sha256': old_by_path[path], 'after_sha256': digest})
assert len(changes) == 1 and changes[0]['path'] == 'apps/extension/src/driver-engine.ts'
assert changes[0]['before_sha256'] == 'sha256:9fc5287957ad148aad2cc449244427c9a2d731470dd267088396b534ed340ed4'
assert sha(canonical(files)) == NEW_RUNTIME and total == 3371960
assert (ROOT / 'apps/extension/src/driver-engine.ts').read_bytes() == Path('/tmp/japp-w14-build-result-concurrency/driver-engine.corrected-afterimage.ts').read_bytes()
assert sha((ROOT / bindings['native_observer']['helper_path']).read_bytes()) == bindings['native_observer']['helper_sha256']
for row in bindings['legacy_sources']:
    assert sha((Path('/tmp/japp-legacy-cleanroom.ByLBQU') / row['path']).read_bytes()) == row['sha256']
frozen = {name: sha((SRC / name).read_bytes()) for name in ['paired-inputs.json', 'paired-oracles.json', 'legacy-projections.json']}
OUT.mkdir()
pre = OUT / 'source-preimages' / REL
pre.mkdir(parents=True)
for name in NAMES:
    shutil.copyfile(SRC / name, pre / name)
proposed = OUT / 'proposed' / REL
shutil.copytree(SRC, proposed)
history = proposed / 'preexecution-history/revision-8'
history.mkdir()
for name in NAMES:
    shutil.copyfile(pre / name, history / name)
prior_actual = decl['preexecution_prior_actual_campaign'].copy()
assert prior_actual['source_revision'] == 7 and prior_actual['campaign_lock_digest'] == 'sha256:e5b9a8dd4163a6f3c9e61782ef808692ebf65da0997fdfdb486d77e671b50042'
prior_actual['relationship'] = 'HISTORICAL_ACTUAL_RESULTS_NOT_REBOUND_OR_INHERITED_BY_REVISION_9'
decl.update({
    'preexecution_source_revision': 9,
    'preexecution_source_revision_reason': 'CURRENT_RESULT_METADATA_HASH_JOIN_OPTIMIZATION_AFTER_UNEXECUTED_REVISION_8',
    'preexecution_previous_campaign_lock_digest': OLD_LOCK,
    'preexecution_runtime_review_record': 'SEPARATE_EXACT_SOURCE_AND_DECLARATION_REVIEW_REQUIRED_BEFORE_EXECUTION',
    'preexecution_no_paired_system_run_declared': True,
    'preexecution_rebind_prepared_at': datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00', 'Z'),
    'preexecution_runtime_inventory_correction': 'Revision8 was reviewed but never executed: candidate0/legacy0 under lock0f22812dc44aa46fda51b78ef666738a924e00e0deaaaff977bc33d82729ab3a. Revision9 binds the single-file bounded concurrent immutable result-metadata hash computation, preserving rejection order and existing publication witnesses. Actual revision7 candidate4/legacy4 observations remain historical under locke5b9a8dd4163a6f3c9e61782ef808692ebf65da0997fdfdb486d77e671b50042. Both actors must execute afresh; no old outcome or timing is inherited. Inputs, oracles, projections, vendor sources, observer, actor code and control assertions remain exact.',
    'candidate_runtime_inventory_policy': policy,
    'candidate_runtime_inventory_digest': NEW_RUNTIME,
    'candidate_runtime_inventory_count': 355,
    'preexecution_prior_actual_campaign': prior_actual,
    'preexecution_prior_unexecuted_campaign': {'source_revision': 8, 'campaign_lock_digest': OLD_LOCK, 'candidate_cases_executed': 0, 'legacy_cases_executed': 0, 'relationship': 'SUPERSEDED_WITHOUT_ANY_ACTOR_EXECUTION_OR_INHERITED_OUTCOME'},
})
(proposed / 'predeclaration.json').write_text(encode(decl))
config = (SRC / 'playwright.config.ts').read_text()
assert config.count('declaration.preexecution_source_revision !== 8') == 1
assert config.count('sha256:e5b9a8dd4163a6f3c9e61782ef808692ebf65da0997fdfdb486d77e671b50042') == 1
config = config.replace('declaration.preexecution_source_revision !== 8', 'declaration.preexecution_source_revision !== 9').replace('sha256:e5b9a8dd4163a6f3c9e61782ef808692ebf65da0997fdfdb486d77e671b50042', OLD_LOCK)
(proposed / 'playwright.config.ts').write_text(config)
intro = f'''# Paired explicit-option pre-execution source revision 9

Revision 9 declares fresh candidate 4 and legacy 4 executions after the reviewed bounded result-metadata hash optimization. The current runtime is 355 files / `{NEW_RUNTIME}` (3,371,960 bytes). Only `apps/extension/src/driver-engine.ts` changes from revision 8. No revision 9 actor has run at authoring.

Revision 8 was reviewed but never executed: candidate 0 / legacy 0 under `{OLD_LOCK}`. Its coordinator was never released because the matching frozen fc48930 full run failed its native128 target performance assertion. Its exact six metadata/configuration/checklist files are preserved under `preexecution-history/revision-8/`. That failed full run remains historical and is not converted into a pass by the separately scoped isolated target result. Actual revision 7 candidate 4 / legacy 4 observations remain historical under `sha256:e5b9a8dd4163a6f3c9e61782ef808692ebf65da0997fdfdb486d77e671b50042` in `docs/evidence/m02-w14-revision7-actual`; no old outcome, pass or timing is inherited.

Frozen inputs/oracles/projections, all 31 vendor sources, native observer, actor implementations, source/control assertions and previous history bytes remain exact. Configuration requires revision 9 and the exact revision 8 predecessor lock. Coordinator/worker fresh absolute outside-output checks are unchanged; parent commands strip `TEST_WORKER_INDEX`. Separate exact-byte independent source/declaration review, clean committed source and fresh build provenance are required before both new actors execute. No formal W15 or Gate A authority is granted.

## Historical revision 8 preparation record

'''
oldmd = (SRC / 'PREEXECUTION.md').read_text()
(proposed / 'PREEXECUTION.md').write_text(intro + oldmd.split('\n\n', 1)[1].replace('PARENT_REVIEWED_REVISION_8_SHA256_DIGEST', 'PARENT_REVIEWED_REVISION_9_SHA256_DIGEST'))
node = '/opt/homebrew/opt/node@24/bin/node'
prettier = str(ROOT / 'node_modules/prettier/bin/prettier.cjs')
format_cmd = [node, prettier, '--config', str(ROOT / '.prettierrc.json'), '--ignore-path', '/dev/null', '--write', str(proposed / 'predeclaration.json'), str(proposed / 'playwright.config.ts'), str(proposed / 'PREEXECUTION.md')]
result = subprocess.run(format_cmd, cwd=OUT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
(OUT / 'format-preparation.log').write_bytes(result.stdout)
bindings.update({'predeclaration_digest': sha((proposed / 'predeclaration.json').read_bytes()), 'candidate_runtime_sources': files, 'candidate_runtime_inventory_policy': policy, 'candidate_runtime_inventory_digest': NEW_RUNTIME})
(proposed / 'source-bindings.json').write_text(encode(bindings))
result = subprocess.run([node, prettier, '--config', str(ROOT / '.prettierrc.json'), '--ignore-path', '/dev/null', '--write', str(proposed / 'source-bindings.json')], cwd=OUT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
(OUT / 'format-bindings.log').write_bytes(result.stdout)
payload = []
for path in sorted(proposed.rglob('*')):
    assert not path.is_symlink()
    if path.is_dir():
        continue
    assert stat.S_ISREG(path.lstat().st_mode)
    relative = path.relative_to(proposed).as_posix()
    if relative not in ['campaign.lock.json', 'campaign.lock.sha256']:
        payload.append({'path': relative, 'sha256': sha(path.read_bytes())})
assert len(payload) == 65 and len({row['path'] for row in payload}) == 65
lock.update({'status': 'FROZEN_BEFORE_EITHER_NEW_RUN_REVISION_9_CURRENT_RESULT_METADATA_HASH_JOIN', 'files': payload})
(proposed / 'campaign.lock.json').write_text(encode(lock))
new_lock = sha((proposed / 'campaign.lock.json').read_bytes())
(proposed / 'campaign.lock.sha256').write_text(new_lock + '\n')
changed = []
patch = []
for path in sorted(proposed.rglob('*')):
    if not path.is_file():
        continue
    relative = path.relative_to(proposed)
    original = SRC / relative
    before = original.read_bytes() if original.exists() else b''
    after = path.read_bytes()
    if before == after:
        continue
    full = (REL / relative).as_posix()
    changed.append({'path': full, 'exists_before': original.exists(), 'before_sha256': sha(before) if original.exists() else None, 'after_sha256': sha(after), 'before_bytes': len(before), 'after_bytes': len(after)})
    patch.append(f'diff --git a/{full} b/{full}\n')
    if not original.exists():
        patch.append('new file mode 100644\n')
    patch.extend(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile='a/' + full if original.exists() else '/dev/null', tofile='b/' + full))
assert len(changed) == 12
patch_bytes = ''.join(patch).encode()
(OUT / 'revision9-proposal.patch').write_bytes(patch_bytes)
manifest = {'format_version': 'W14_PAIRED_REVISION9_PREEXECUTION_PROPOSAL_1', 'authority': 'NONE', 'status': 'OUTSIDE_SOURCE_ONLY_BEFORE_EITHER_REVISION_9_ACTOR_EXECUTION_PENDING_PEER_REVIEW', 'source_head': 'fc48930fd880795f72972fd97e2e69d68e636855', 'source_state': 'CURRENT_ROOT_HAS_ONLY_REVIEWED_ENGINE_OPTIMIZATION_RUNTIME_DELTA_FROM_FC', 'prior_lock_digest': OLD_LOCK, 'proposed_lock_digest': new_lock, 'proposed_lock_payload_files': 65, 'candidate_runtime_inventory_digest': NEW_RUNTIME, 'candidate_runtime_inventory_count': 355, 'candidate_runtime_total_bytes': total, 'runtime_file_changes': changes, 'frozen_data_unchanged': frozen, 'revision8_history_exact': NAMES, 'revision8_execution': {'candidate': 0, 'legacy': 0, 'coordinator_released': False}, 'last_actual_campaign_revision': 7, 'native_observer_unchanged': bindings['native_observer']['helper_sha256'], 'legacy_sources_verified_unchanged': len(bindings['legacy_sources']), 'actors_assertions_freshness_logic_unchanged': True, 'separate_source_peer_review': 'PENDING', 'candidate_revision9_runs': 0, 'legacy_revision9_runs': 0, 'builds_started': 0, 'browsers_started': 0, 'tests_started': 0, 'root_writes': 0, 'formatting_only_outside_files': True, 'patch_sha256': sha(patch_bytes), 'changed_files': changed}
(OUT / 'source-manifest.json').write_text(encode(manifest))
(OUT / 'runtime-inventory.json').write_text(encode({'policy': policy, 'files': files, 'digest': NEW_RUNTIME, 'total_bytes': total}))
for name in NAMES:
    assert (SRC / name).read_bytes() == (pre / name).read_bytes() == (history / name).read_bytes()
for row in lock['files']:
    assert sha((proposed / row['path']).read_bytes()) == row['sha256']
for row in files:
    assert sha((ROOT / row['path']).read_bytes()) == row['sha256']
print(encode({'output': str(OUT), 'patch_sha256': sha(patch_bytes), 'lock': new_lock, 'runtime': NEW_RUNTIME, 'runtime_bytes': total, 'runtime_changes': changes, 'changed_files': len(changed), 'payload_files': len(payload), 'execution': 'NONE'}))
