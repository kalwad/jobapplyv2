# Revision 9 source-only paired declaration proposal

This proposal changes exactly twelve paths: six current metadata/config/checklist files and six new byte-identical revision8 history files. There are65 lock payload files,67 safe unique regular proposed files total. `proposal-payload-manifest.json` binds every proposed file's exact SHA and byte count, including the current lock/sidecar. No actor, build, test or root write occurred; only outside-file formatting and its ten-file static check were run.

Revision8 is explicitly UNEXECUTED: candidate0/legacy0 and coordinator unreleased. Its exact lock `sha256:0f22812dc44aa46fda51b78ef666738a924e00e0deaaaff977bc33d82729ab3a`, sidecar, declaration, bindings, config and checklist are preserved under `preexecution-history/revision-8/`. The latest actual paired campaign remains revision7 under e5b9; its results/timing are historical and never inherited. The new declaration separately records both facts.

The new closed runtime inventory is355 files /3,371,960bytes /`sha256:3b6c0e0c0950b03e3bb9e1f12b27bb8d385174c36fb4b68ef3345597aa8b3502`. Exactly one runtime file changes: engine9fc52879... becomes22071b77f7610b315dc58f51275d3703f895c92f5f6c919f2efbbd275a312557, matching the independently reviewed corrected optimization afterimage. Every other current runtime file remains exact. The preparer independently enumerates all closed policy directories/files and required paths, not merely the old list, then compares the canonical digest.

Frozen input/oracle/projection bytes, native observer, all31 vendor sources, actor code, control assertions, prior histories and coordinator freshness behavior remain unchanged. Config changes only required revision9 and exact predecessor0f228. Both new actors still require independent source/declaration review, clean committed source, actual fresh-build provenance and fresh outputs. No new result or outcome is predeclared.

Patch: `revision9-proposal.patch`, `sha256:e2fe3704eced7dc659052bd35e7dceffbf5472bf8bc68851ffaf378a9df88637`.
Lock: `sha256:72a68f2929823583c878a20dc8c9b57414f65a5ca59cf21b144c5e1af6466a5a`.

`source-preimages/` contains exact six current root bytes captured before refresh; `proposed/` contains all afterimages. `source-manifest.json`, `runtime-inventory.json`, `proposal-payload-manifest.json` and format records provide exhaustive bindings. The standalone preparer is `/tmp/japp-w14-prepare-revision9.py`. Peer source review is pending. This declaration grants no W15/Gate A authority, full current regression pass, public/Simplify result or inherited comparison outcome.
