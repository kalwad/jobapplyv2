# Independent completed full-result audit — frozen fc48930

**Full verification failed.** The 2026-10-16T22:44:34Z–23:01:46Z run exited 1: 18 of 19 ACTIVE suites passed; e2e-browser failed solely at the native128 performance assertion. Default browser results are **241 PASS / 1 FAIL**. Visual remains NOT_YET_APPLICABLE.

The 20 native128 samples independently yield p95 **1527.9433329999993 ms** (rank 19), above the unchanged 1500 ms threshold by 27.943333 ms. Raw scaling retains this failure even though the assertion prevents W13_TARGET_P95 output. Physical action and scanner-work checks remain consistent. This is zero-settle lower-bound harness evidence, insufficient for final full-settlement Gate A performance. No benchmark rerun occurred; contact timing does not offset the failure.

Evidence integrity is confirmed at commit `fc48930fd880795f72972fd97e2e69d68e636855`, tree `cb787f46afec1281c87074a82fd31e23b37c865a`. The pinned wrapper, full command, flags, clean endpoints, timestamps and tracked neutrality agree. All **1478 Git blobs / 164406037 bytes** were independently read through git cat-file: every byte count and SHA256 matches BOTH frozen snapshots, and Git object hashes also match. All 26 safe regular input members remain identical across audit attempts. The later authorized driver-engine edit observed in attempt 2 is outside the frozen run and is not a neutrality failure.

Other results are 3859 unit passes, 1454 Python passes in 299.26 s, 62 contact-controlled browser passes and two separate inspect-only passes. All six permanent native-validity and eight focus-value cases pass. Default discovery was not executed after browser failure: verify.run_suite stops before proofs on nonzero command exit. This is recorded as unexecuted, never discovery PASS.

Contact200 raw classifications, counts, input/oracle/state/scorer commitments, timestamps, physical/native joins, execution/report/manifest hashes and producer source/build/declaration invariance reconcile independently:

- 200 scored cases; 4020 logical and 4060 native controls.
- Precision 1485/1485; required recall 1275/1275; required reporting 770/770; persistence 1485/1485.
- Preservation 90/90, zero protected writes or violations; the immutable W13 incorrect-abstention count of 90 remains preserved.
- 1485 native physical actions; zero orphan, unsafe, duplicate, navigation or submission actions.
- p95 **871.287416999985 ms**, from 200 different synthetic contact pages with 75 ms settlement and 20 ms rerender. This is distinct from native128.

Two checker assumptions were corrected transparently: controlled contact count is 62 plus separate inspection 2; default listing is omitted after browser failure. Attempt 1 checker, plan, output and stderr remain retained; attempt 2 has an exact correction diff. No product assertion, threshold or raw artifact changed. The original unbounded failure excerpt is retained; the final excerpt is confined to the browser command. Current-root diagnostics after the later edit remain visible; immutable Git-blob checks establish historical source identity.

Limits: canonical runner PASS covers its declared safety thresholds; accuracy, persistence, reporting and preservation were checked separately. Contact coverage is narrower than the W06 corpus and excludes separately tested features. Native witnesses cover installed APIs in one extension realm with documented other-realm, retained-reference and uninstalled-surface limits. Contact build invariance uses the producer's before inventory and end digest; later controlled builds cannot reproduce that historical boundary. No current Windows aggregate, public scored coverage, actual R8 comparison, Simplify result, formal W15 decision or Gate A approval follows. ADR-0006 waives holdout and per-W stops only. Failed full closure cannot release the prepared exact-fc R8 coordinator.

See summary.json, immutable-git-blob-checks.json, input-inventory.json, native128-failure.json and both checker attempts. This audit performed read-only Git/artifact operations and wrote reports outside root; no root changes, tests, builds, browsers or benchmark reruns.
