from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import stat
import subprocess
import time

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
OUT = Path(__file__).parent

def snapshot():
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).split(b'\0')
    result = {}
    for raw in paths:
        if raw:
            path = ROOT / os.fsdecode(raw)
            info = path.lstat()
            assert stat.S_ISREG(info.st_mode)
            result[os.fsdecode(raw)] = {'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    runtime = ROOT / 'apps/desktop/src-tauri/runtime-payload'
    staged = {}
    for path in sorted(runtime.rglob('*')):
        info = path.lstat()
        if stat.S_ISDIR(info.st_mode):
            continue
        assert stat.S_ISREG(info.st_mode)
        staged[path.relative_to(runtime).as_posix()] = {'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    return {'source': result, 'runtime': staged, 'git_status': subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True), 'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(), 'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip()}

assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True) == ' M e2e/extension/extension-drivers.spec.ts\n'
before = snapshot()
(OUT / 'before.json').write_text(json.dumps(before, indent=2, sort_keys=True) + '\n')
(OUT / 'context.json').write_text(json.dumps({'start_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'scope': 'Actual canonical repaired driver spec; no experimental imports, probes or latency. All13 scenarios with original deadline and strengthened rollback oracle.'}, indent=2) + '\n')
env = dict(os.environ)
env['PATH'] = '/opt/homebrew/opt/node@24/bin:' + env['PATH']
results = []
for name, argv in [('format', ['pnpm','exec','prettier','--check','e2e/extension/extension-drivers.spec.ts']), ('lint', ['pnpm','exec','eslint','e2e/extension/extension-drivers.spec.ts','--max-warnings=0']), ('typecheck', ['pnpm','exec','tsc','--noEmit','-p','tsconfig.json']), ('browser', ['pnpm','exec','playwright','test','e2e/extension/extension-drivers.spec.ts'])]:
    start = time.monotonic()
    with (OUT / (name + '.log')).open('wb') as output:
        child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        timeout = False
        signals = []
        try:
            code = child.wait(timeout=600)
        except subprocess.TimeoutExpired:
            timeout = True
            for sig in [signal.SIGTERM, signal.SIGKILL]:
                try:
                    os.killpg(child.pid, sig)
                    signals.append(sig.name)
                except ProcessLookupError:
                    pass
                if sig == signal.SIGTERM:
                    time.sleep(1)
            code = child.wait(timeout=10)
    try:
        os.killpg(child.pid, 0)
        group = 'PRESENT_AFTER_DIRECT_CHILD_REAP; NO_POST_REAP_SIGNAL'
    except ProcessLookupError:
        group = 'ABSENT'
    row = {'name': name, 'argv': argv, 'exit_code': code, 'timeout': timeout, 'seconds': time.monotonic() - start, 'direct_child_reaped': child.returncode is not None, 'observed_group': group, 'outer_cleanup_signals': signals}
    results.append(row)
    (OUT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    if code != 0 or timeout or group != 'ABSENT':
        break
after = snapshot()
(OUT / 'after.json').write_text(json.dumps(after, indent=2, sort_keys=True) + '\n')
closure = {'end_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'source_files': len(before['source']), 'runtime_files': len(before['runtime']), 'source_runtime_status_head_tree_equal': before == after, 'all_four_commands_closed_zero': len(results) == 4 and all(r['exit_code'] == 0 for r in results), 'all_children_reaped_groups_absent_no_timeout_or_signals': all(r['direct_child_reaped'] and r['observed_group'] == 'ABSENT' and not r['timeout'] and not r['outer_cleanup_signals'] for r in results)}
(OUT / 'closure.json').write_text(json.dumps(closure, indent=2) + '\n')
print(json.dumps(closure), flush=True)
raise SystemExit(0 if all(closure[key] for key in ('source_runtime_status_head_tree_equal', 'all_four_commands_closed_zero', 'all_children_reaped_groups_absent_no_timeout_or_signals')) else 1)
