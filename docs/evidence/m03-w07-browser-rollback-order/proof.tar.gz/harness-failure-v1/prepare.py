from pathlib import Path
import hashlib
import json
import os

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
OUT = Path(__file__).parent
subject = ROOT / 'e2e/extension/extension-drivers.spec.ts'
original = subject.read_text()
(OUT / 'original.spec.ts.txt').write_bytes(subject.read_bytes())
start = original.index('test("FW3/VAL1/VAL2/DATE2:')
end = original.index('\ntest(', start + 1)
before = original[start:end]
old = '''  await react.page.evaluate(() => {
    for (const eventName of ["input", "change"]) {
      document.addEventListener(
        eventName,
        (event) => {
          if ((event.target as HTMLElement).id === "react-full-name") {
            event.stopImmediatePropagation();
          }
        },
        true,
      );
    }
    window.setTimeout(() => {
      document
        .getElementById("react-rerender")
        ?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    }, 20);
  });'''
new = '''  await react.page.evaluate(() => {
    let rerenderScheduled = false;
    for (const eventName of ["input", "change"]) {
      document.addEventListener(
        eventName,
        (event) => {
          if ((event.target as HTMLElement).id === "react-full-name") {
            event.stopImmediatePropagation();
            // Arm the rollback after the write, regardless of request preparation.
            if (!rerenderScheduled) {
              rerenderScheduled = true;
              window.setTimeout(() => {
                document
                  .getElementById("react-rerender")
                  ?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
              }, 20);
            }
          }
        },
        true,
      );
    }
  });'''
assert before.count(old) == 1
after = before.replace(old, new)
after = after.replace('  expect(rollback.result.outcome).toBe("FAILED");', '''  await expect(react.page.locator("#react-render-count")).toHaveText("2");
  await expect(react.page.locator("#react-state-full-name")).toHaveText("");
  expect(rollback.result.outcome).toBe("FAILED");''')
fixed = original[:start] + after + original[end:]
(OUT / 'fixed.spec.ts.txt').write_text(fixed)
probe = '''  await react.page.evaluate(() => {
    const root = document.documentElement;
    root.dataset.rollbackOrder = "";
    for (const type of ["input", "change", "click"]) {
      document.addEventListener(type, (event) => {
        const id = (event.target as HTMLElement).id;
        if (id === "react-full-name" || id === "react-rerender") {
          root.dataset.rollbackOrder += `${event.type}:${id};`;
        }
      }, true);
    }
  });
'''
latency = '''  // Controlled experiment only: preparation latency, not settle budget.
  await react.page.evaluate(() => new Promise<void>((resolve) => {
    window.setTimeout(resolve, 100);
  }));
'''
observation = '''  console.log("ROLLBACK_ORDER_PROBE", await react.page.evaluate(() => ({
    events: document.documentElement.dataset.rollbackOrder,
    renderCount: document.getElementById("react-render-count")?.textContent,
    committed: document.getElementById("react-state-full-name")?.textContent,
    domValue: (document.getElementById("react-full-name") as HTMLInputElement).value,
  })), rollback.result.outcome);
'''
for name, body in [('baseline', original), ('fixed', fixed)]:
    index = body.index('test("FW3/VAL1/VAL2/DATE2:')
    final = body[:index] + body[index:].replace('  await react.page.evaluate(() => {', probe + '  await react.page.evaluate(() => {', 1)
    index = final.index('test("FW3/VAL1/VAL2/DATE2:')
    final = final[:index] + final[index:].replace('  const rollback = await execute(', latency + '  const rollback = await execute(', 1)
    final = final.replace('  expect(rollback.result.outcome).toBe("FAILED");', observation + '  expect(rollback.result.outcome).toBe("FAILED");', 1)
    # Import-only relocation; real product and real owned browser fixture unchanged.
    final = final.replace('"../../', f'"{ROOT}/').replace('"./support/extension-test.ts"', f'"{ROOT}/e2e/extension/support/extension-test.ts"')
    folder = OUT / name
    folder.mkdir()
    (folder / 'extension-drivers.spec.ts').write_text(final)
    config = f'''import base from "{ROOT}/playwright.config.ts";
import {{ defineConfig }} from "{ROOT}/node_modules/@playwright/test";
export default defineConfig({{
  ...base,
  testDir: "{folder}",
  outputDir: "{OUT / (name + '-artifacts')}",
  globalSetup: "{ROOT}/e2e/extension/support/global-setup.ts",
  webServer: (Array.isArray(base.webServer) ? base.webServer : [base.webServer]).map((entry) => ({{ ...entry, cwd: "{ROOT}" }})),
}});
'''
    (OUT / (name + '.config.ts')).write_text(config)
os.symlink(ROOT / 'node_modules', OUT / 'node_modules', target_is_directory=True)
records = {}
for path in sorted(OUT.rglob('*')):
    if path.is_file() and 'node_modules' not in path.parts:
        records[path.relative_to(OUT).as_posix()] = {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
(OUT / 'preparation.json').write_text(json.dumps({'scope': 'Controlled synthetic preparation-latency experiment. No assertion removal or deadline increase. Does not prove original hosted event ordering.', 'files': records}, indent=2) + '\n')
