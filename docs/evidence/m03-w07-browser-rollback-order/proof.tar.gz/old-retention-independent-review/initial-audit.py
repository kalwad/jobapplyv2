"""Read pinned local source and saved data only; no Playwright import/actor."""
from pathlib import Path
import hashlib,json,re
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');R=Path('/Users/tanishkalwad/jobapplyv2');B=E/'ci-07eb77b';O=Path(__file__).parent;checks=[];bindings=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
def check(n,v):checks.append({'name':n,'pass':bool(v)})
immutable=json.loads((B/'immutable-git-source-sha256.json').read_bytes())
repo_files=['playwright.config.ts','e2e/extension/public-research/playwright.config.ts','e2e/extension/public-contact/playwright.config.ts','.github/workflows/ci.yml','scripts/verification-suites.json','scripts/tests/test_ci_workflow.py','e2e/extension/support/extension-test.ts','e2e/extension/support/global-setup.ts','scripts/verify.py','pnpm-lock.yaml']
texts={}
for name in repo_files:
    p=R/name;body=p.read_bytes();pin=immutable['files'][name];check('exact frozen07eb selected source '+name,len(body)==pin['bytes']and sha(body)==pin['sha256']);texts[name]=body.decode();bindings.append({'path':str(p),'bytes':len(body),'sha256':sha(body),'binding':'Exact tested07eb immutable Git body'})
dependency=R/'node_modules/.pnpm/playwright@1.62.0/node_modules/playwright'
dep_files=['package.json','lib/runner/index.js','lib/common/index.js','lib/cli/testActions.js','lib/worker/workerProcessEntry.js']
dep={}
for name in dep_files:
    p=dependency/name;body=p.read_bytes();dep[name]=body.decode();bindings.append({'path':str(p),'bytes':len(body),'sha256':sha(body),'binding':'Selected local installed Playwright1.62 source; not a hosted file-byte receipt'})
check('local pinned Playwright version',json.loads(dep['package.json'])['version']=='1.62.0'and'playwright@1.62.0:'in texts['pnpm-lock.yaml'])
raw=(B/'closed-jobs/123216775676.log').read_bytes();plain='\n'.join(re.sub(r'^\d{4}-\d\d-\d\dT[^ ]+ ','',x)for x in raw.decode().splitlines());plain=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',plain)
check('official hosted installed runner1.62',bool(re.search(r'@playwright/test 1\.62\.0\s+PASS\s+installed 1\.62\.0',plain)))
check('all four browser suite actual argv retained',all('$ '+c+'\n'in plain for c in ['pnpm exec playwright test','pnpm exec playwright test --config e2e/extension/public-research/playwright.config.ts','pnpm exec playwright test --config e2e/extension/public-contact/playwright.config.ts --reporter=list,json','pnpm exec playwright test e2e/visual --output test-results/visual']))
check('frozen configs own sibling output roots','outputDir: "./test-results/browser"'in texts['playwright.config.ts']and'outputDir: "../../../test-results/public-research"'in texts['e2e/extension/public-research/playwright.config.ts']and'outputDir: "../../../test-results/public-contact"'in texts['e2e/extension/public-contact/playwright.config.ts'])
check('pinned CLI resolves explicit output from cwd','outputDir: options.output ? import_path.default.resolve(process.cwd(), options.output) : void 0'in dep['lib/cli/testActions.js'])
check('pinned config gives CLI output first precedence','outputDir: takeFirst(configCLIOverrides.outputDir, pathResolve(configDir, projectConfig.outputDir), pathResolve(configDir, config.outputDir)'in dep['lib/common/index.js'])
runner=dep['lib/runner/index.js'];a=runner.index('function createRemoveOutputDirsTask()');b=runner.index('function createListFilesTask()',a);clear=runner[a:b]
check('cleanup operates only filtered project outputs','testRun.filteredProjects.forEach((p) => outputDirs.add(p.project.outputDir))'in clear and'removeFolders4([outputDir])'in clear)
a=runner.index('const tasks = options.listMode ? [');b=runner.index('const testRun =',a);tasks=runner[a:b]
check('list tasks exclude global setup and cleanup','createGlobalSetupTasks(config2)'in tasks.split('] : [')[1]and'createGlobalSetupTasks'in tasks.split('] : [')[0]is False)
check('raw contact effective output/preservation','"outputDir": "/Users/runner/work/jobapplyv2/jobapplyv2/test-results/public-contact"'in plain and'"preserveOutput": "always"'in plain)
check('normal worker preservation defaults always','preserveOutput: takeFirst(userConfig.preserveOutput, "always")'in dep['lib/common/index.js']and'if (!preserveOutput)'in dep['lib/worker/workerProcessEntry.js'])
worker=dep['lib/worker/workerProcessEntry.js'];check('standard trace merge precedes attachment append','await mergeTraceFiles(tracePath, this._temporaryTraceFiles);\n    this._testInfo.attachments.push({ name: "trace", path: tracePath'in worker)
a=runner.index('const attachmentGroups = groupAttachments(result.attachments)');b=runner.index('lines.push(...resultLines)',a);reporter=runner[a:b]
check('list reporter emits metadata paths without stat probe','else if (attachment.path)'in reporter and'relativeFilePath(screen, config2, attachment.path)'in reporter and'stat('not in reporter and'access('not in reporter)
fixture=texts['scripts/tests/test_ci_workflow.py'];a=fixture.index('def test_artifact_path_matches_playwright_output_config(');b=fixture.index('\ndef ',a+5);fixture=fixture[a:b]
check('generic cleanup regression fixture isolates cwd/output','fixture_root = tmp_path / "playwright-retention"'in fixture and'cwd=fixture_root'in fixture and'artifact_root = fixture_root / "test-results"'in fixture)
check('custom Chromium profile deletion is only fresh temp child','mkdtempSync(join(tmpdir(), profilePrefix))'in texts['e2e/extension/support/extension-test.ts']and'await rm(userDataDir,'in texts['e2e/extension/support/extension-test.ts'])
members=json.loads((B/'artifacts/12868823468-members.json').read_bytes());check('all66 retained Mac members are visual only',len(members)==66 and all(r['path'].startswith('visual/')for r in members))
check('nonhidden browser attachment refs absent from actual ZIP members',all(not any(x in r['path']for x in('trace.zip','error-context.md','test-failed-'))for r in members)and'test-results/browser/extension-extension-driver-8fe2f-jected-matches-never-verify-chromium/trace.zip'in plain)
check('actual uploader selected whole test-results root with66files','path: test-results/'in plain and'With the provided path, there will be 66 files uploaded'in plain and'Artifact ID 12868823468'in plain)
for name in ['closed-jobs/123216775676.log','artifacts/12868823468-members.json','artifacts/12868823468.zip']:
    p=B/name;body=p.read_bytes();bindings.append({'path':str(p),'bytes':len(body),'sha256':sha(body),'binding':'Saved original official log/API-digest-matched artifact data'})
result={'scope':'Pinned-source and saved-data retention inspection; no subject imports or actors','verdict':'RETENTION_CAUSE_UNOBSERVED_WITH_SOURCE_CONSTRAINTS','checks':checks,'passed':sum(c['pass']for c in checks),'total':len(checks),'bindings':bindings,'source_excerpts':{'clear_output':clear,'list_vs_execute_tasks':tasks,'fixture':fixture,'list_reporter':reporter},'unknowns':['No retained intermediate browser output-directory inventory/stat receipt','No failure screenshot/error-context/trace body remains; old event ordering unavailable','No proved actor/stage removed or failed to persist the bodies','Local pinned package source is bound but its hosted installed bytes were not independently retained'],'no_subject_execution':True,'canonical_writes':0}
(O/'checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':result['passed'],'total':len(checks),'failures':[c['name']for c in checks if not c['pass']]}));assert all(c['pass']for c in checks)
