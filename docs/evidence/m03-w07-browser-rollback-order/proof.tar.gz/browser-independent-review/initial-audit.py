"""Read retained records and source as data; never import or run the subject."""
from pathlib import Path, PurePosixPath
import datetime
import hashlib
import json
import re
import stat
import subprocess
import zipfile

E = Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028')
ROOT = Path('/Users/tanishkalwad/jobapplyv2')
OUT = Path(__file__).parent
V = E / 'browser-rollback-order-v3'
C = E / 'browser-rollback-canonical-v1'
SUBJECT = 'e2e/extension/extension-drivers.spec.ts'
checks = []

def check(name, value, detail=None):
    checks.append({'name': name, 'pass': bool(value), 'detail': detail})

def read(path):
    return path.read_text()

def load(path):
    return json.loads(read(path))

def pin(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode), str(path)
    return {'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode),
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def target(text):
    start = text.index('test("FW3/VAL1/VAL2/DATE2:')
    end = text.index('\ntest(', start + 1)
    return text[:start], text[start:end], text[end:]

old = read(V / 'original.spec.ts.txt')
fixed = read(V / 'fixed.spec.ts.txt')
old_parts, fixed_parts = target(old), target(fixed)
check('only_target_test_changes', old_parts[0] == fixed_parts[0] and old_parts[2] == fixed_parts[2])
names = lambda text: re.findall(r'^test\("([^"\n]+)', text, re.M)
check('all_13_test_names_preserved', names(old) == names(fixed) and len(names(old)) == 13)
added = ('  await expect(react.page.locator("#react-render-count")).toHaveText("2");\n'
         '  await expect(react.page.locator("#react-state-full-name")).toHaveText("");\n')
old_handler = '''  await react.page.evaluate(() => {
    for (const eventName of ["input", "change"]) {
      document.addEventListener(
        eventName,
        (event) => {
          if ((event.target as HTMLElement).id === "react-full-name") {
            event.stopImmediatePropagation();
          }
        },
        true,
      );
    }
    window.setTimeout(() => {
      document
        .getElementById("react-rerender")
        ?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    }, 20);
  });'''
new_handler = '''  await react.page.evaluate(() => {
    let rerenderScheduled = false;
    for (const eventName of ["input", "change"]) {
      document.addEventListener(
        eventName,
        (event) => {
          if ((event.target as HTMLElement).id === "react-full-name") {
            event.stopImmediatePropagation();
            // Arm the rollback after the write, regardless of request preparation.
            if (!rerenderScheduled) {
              rerenderScheduled = true;
              window.setTimeout(() => {
                document
                  .getElementById("react-rerender")
                  ?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
              }, 20);
            }
          }
        },
        true,
      );
    }
  });'''
check('exact_narrow_source_delta', old.count(old_handler) == 1 and fixed == old.replace(old_handler, new_handler).replace('  expect(rollback.result.outcome).toBe("FAILED");', added + '  expect(rollback.result.outcome).toBe("FAILED");'))
check('125ms_settle_and_all_old_assertions_retained',
      fixed_parts[1].replace(new_handler, old_handler).replace(added, '') == old_parts[1]
      and '    undefined,\n    125,\n' in fixed_parts[1])

probe = '''  await react.page.evaluate(() => {
    const root = document.documentElement;
    root.dataset.rollbackOrder = "";
    for (const type of ["input", "change", "click"]) {
      document.addEventListener(type, (event) => {
        const id = (event.target as HTMLElement).id;
        if (id === "react-full-name" || id === "react-rerender") {
          root.dataset.rollbackOrder += `${event.type}:${id};`;
        }
      }, true);
    }
  });
'''
latency = '''  // Controlled experiment only: preparation latency, not settle budget.
  await react.page.evaluate(() => new Promise<void>((resolve) => {
    window.setTimeout(resolve, 100);
  }));
'''
observation = '''  console.log("ROLLBACK_ORDER_PROBE", await react.page.evaluate(() => ({
    events: document.documentElement.dataset.rollbackOrder,
    renderCount: document.getElementById("react-render-count")?.textContent,
    committed: document.getElementById("react-state-full-name")?.textContent,
    domValue: (document.getElementById("react-full-name") as HTMLInputElement).value,
  })), rollback.result.outcome);
'''
for name, original in [('baseline', old), ('fixed', fixed)]:
    experimental = read(V / name / 'extension-drivers.spec.ts')
    normal = experimental
    for block in (probe, latency, observation):
        assert normal.count(block) == 1
        normal = normal.replace(block, '')
    normal = normal.replace('"' + str(ROOT) + '/e2e/extension/support/extension-test.ts"', '"./support/extension-test.ts"').replace('"' + str(ROOT) + '/', '"../../')
    check(name + '_only_identical_probe_latency_observation_import_relocation', normal == original)
    config = read(V / (name + '.config.ts'))
    expected = f'''import base from "{ROOT}/playwright.config.ts";
import {{ defineConfig }} from "@playwright/test";
export default defineConfig({{
  ...base,
  testDir: "{V / name}",
  outputDir: "{V / (name + '-artifacts')}",
  globalSetup: "{ROOT}/e2e/extension/support/global-setup.ts",
  webServer: (Array.isArray(base.webServer) ? base.webServer : [base.webServer]).map((entry) => ({{ ...entry, cwd: "{ROOT}" }})),
}});
'''
    check(name + '_exact_config_base_fixture_product_reuse', config == expected)

prep = load(V / 'preparation.json')
check('preparation_9_file_byte_pins', len(prep['files']) == 9 and all({k: pin(V / name)[k] for k in ('bytes', 'sha256')} == row for name, row in prep['files'].items()))
snapshots = {}
for dirname in ('browser-rollback-order-v1', 'browser-rollback-order-v2', 'browser-rollback-order-v3', 'browser-rollback-canonical-v1'):
    p = E / dirname
    before, after = load(p / 'before.json'), load(p / 'after.json')
    snapshots[dirname] = before
    closure, results = load(p / 'closure.json'), load(p / 'results.json')
    check(dirname + '_endpoint_equality_counts_closure', before == after and len(before['source']) == 2187 and len(before['runtime']) == 40 and closure['source_runtime_status_head_tree_equal'])
    check(dirname + '_direct_children_closed_no_signals_or_timeouts', all(r['direct_child_reaped'] and r['observed_group'] == 'ABSENT' and not r['timeout'] and not r['outer_cleanup_signals'] for r in results))
    if dirname.endswith(('v1', 'v2')) and 'order' in dirname:
        check(dirname + '_harness_failure_preserved_not_product_red', [r['exit_code'] for r in results] == [1, 1] and not closure['expected_baseline_failed_fixed_passed'])

base = snapshots['browser-rollback-order-v3']
canonical = snapshots['browser-rollback-canonical-v1']
check('all_three_experiment_full_snapshots_equal', all(snapshots['browser-rollback-order-' + v] == base for v in ('v1', 'v2')))
diffs = [k for k in base['source'] if base['source'][k] != canonical['source'][k]]
check('canonical_snapshot_only_intended_spec_diff', diffs == [SUBJECT] and base['runtime'] == canonical['runtime'] and base['commit'] == canonical['commit'] and base['tree'] == canonical['tree'] and base['git_status'] == '' and canonical['git_status'] == ' M ' + SUBJECT + '\n', diffs)
check('snapshot_spec_original_fixed_sha_modes', base['source'][SUBJECT] == pin(V / 'original.spec.ts.txt') and canonical['source'][SUBJECT] == pin(V / 'fixed.spec.ts.txt'))
current_source = {name: pin(ROOT / name) for name in canonical['source']}
current_runtime = {name: pin(ROOT / 'apps/desktop/src-tauri/runtime-payload' / name) for name in canonical['runtime']}
check('all_2187_current_physical_bytes_full_modes_join', current_source == canonical['source'])
check('all_40_current_runtime_bytes_full_modes_join', current_runtime == canonical['runtime'])
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT, text=True)
current_git = {'commit': git('rev-parse', 'HEAD').strip(), 'tree': git('rev-parse', 'HEAD^{tree}').strip(), 'git_status': git('status', '--porcelain')}
check('current_git_endpoints_join', all(current_git[k] == canonical[k] for k in current_git))
check('canonical_spec_exact_fixed_without_experimental_edits', (ROOT / SUBJECT).read_bytes() == (V / 'fixed.spec.ts.txt').read_bytes() and all(x not in fixed for x in ('ROLLBACK_ORDER_PROBE', 'rollbackOrder', 'Controlled experiment only', str(ROOT))))
v3results = load(V / 'results.json')
check('v3_expected_actual_argv_red_green', [r['exit_code'] for r in v3results] == [1, 0] and all(r['argv'] == ['pnpm', 'exec', 'playwright', 'test', '--config', str(V / (r['name'] + '.config.ts')), '--grep', 'FW3/VAL1/VAL2/DATE2'] for r in v3results))
stripansi = lambda text: re.sub(r'\x1b\[[0-9;]*m', '', text)
bl, fl = (stripansi(read(V / (n + '.log'))) for n in ('baseline', 'fixed'))
check('v3_raw_control_event_order_dom_and_outcome', "events: 'click:react-rerender;input:react-full-name;change:react-full-name;'" in bl and "renderCount: '2'" in bl and "committed: ''" in bl and "domValue: 'Transient only'" in bl and '} VERIFIED' in bl and 'Received: "VERIFIED"' in bl and '1 failed' in bl)
check('v3_raw_fixed_event_order_dom_and_outcome', "events: 'input:react-full-name;change:react-full-name;click:react-rerender;'" in fl and "renderCount: '2'" in fl and "committed: ''" in fl and "domValue: ''" in fl and '} FAILED' in fl and '1 passed' in fl)
trace = next(V.rglob('trace.zip'))
with zipfile.ZipFile(trace) as archive:
    infos = archive.infolist()
    safe = all(not PurePosixPath(i.filename).is_absolute() and '..' not in PurePosixPath(i.filename).parts and '\\' not in i.filename and stat.S_ISREG(i.external_attr >> 16) for i in infos)
    trace_rows = [json.loads(line) for i in infos if i.filename.endswith('.trace') for line in archive.read(i).decode().splitlines()]
    source_join = any(i.file_size == len((V / 'baseline/extension-drivers.spec.ts').read_bytes()) and archive.read(i) == (V / 'baseline/extension-drivers.spec.ts').read_bytes() for i in infos if i.filename.startswith('resources/src@'))
    probe_join = any(r.get('type') == 'stdout' and stripansi(r.get('text', '')) in bl and 'ROLLBACK_ORDER_PROBE' in r.get('text', '') for r in trace_rows)
    check('retained_baseline_trace_safe_regular_source_probe_chromium_join', safe and source_join and probe_join and any(r.get('type') == 'context-options' and r.get('browserName') == 'chromium' and r.get('channel') == 'chromium' for r in trace_rows), {'zip_members': len(infos), 'json_trace_events': len(trace_rows)})
for v, failure in [('v1', "Cannot use 'import.meta' outside a module"), ('v2', 'Directory import')]:
    check(v + '_actual_harness_diagnostic_both_variants', all(failure in read(E / ('browser-rollback-order-' + v) / (name + '.log')) for name in ('baseline', 'fixed')))
cr = load(C / 'results.json')
expected_argv = [
 ['pnpm','exec','prettier','--check',SUBJECT],
 ['pnpm','exec','eslint',SUBJECT,'--max-warnings=0'],
 ['pnpm','exec','tsc','--noEmit','-p','tsconfig.json'],
 ['pnpm','exec','playwright','test',SUBJECT]]
check('canonical_actual_four_commands_zero_exact_argv', [r['argv'] for r in cr] == expected_argv and all(r['exit_code'] == 0 for r in cr) and load(C / 'closure.json')['all_four_commands_closed_zero'])
browser_log = stripansi(read(C / 'browser.log'))
check('canonical_raw_13_cases_pass_and_strict_outputs', 'Running 13 tests using 1 worker' in browser_log and '13 passed' in browser_log and all(name in browser_log for name in names(fixed)) and 'All matched files use Prettier code style!' in read(C / 'format.log') and (C / 'lint.log').stat().st_size == 0 and (C / 'typecheck.log').stat().st_size == 0)
retention = E / 'old-ci-browser-retention-review-v1/REVIEW.md'
check('historical_retention_review_exact_root_pin_and_unknown_scope', pin(retention)['sha256'] == '15c4938aee0b1a42e7c3aa74296f8ff88c9248bb09020abca1c95797064ab34f' and 'RETENTION_CAUSE_UNOBSERVED_WITH_SOURCE_CONSTRAINTS' in read(retention))
inputs = {}
symlinks = {}
for dirname in ('browser-rollback-order-v1', 'browser-rollback-order-v2', 'browser-rollback-order-v3', 'browser-rollback-canonical-v1'):
    p = E / dirname
    for path in sorted(p.rglob('*')):
        info = path.lstat()
        if stat.S_ISREG(info.st_mode):
            inputs[str(path.relative_to(E))] = pin(path)
        elif stat.S_ISLNK(info.st_mode):
            symlinks[str(path.relative_to(E))] = str(path.readlink())
inputs[str(retention.relative_to(E))] = pin(retention)
for name in ('apps/mock-ats-lab/site/src/pages/react-page.ts', 'packages/extension-driver/src/engine.ts', 'playwright.config.ts', 'e2e/extension/support/extension-test.ts'):
    if (ROOT / name).is_file():
        inputs[str(ROOT / name)] = pin(ROOT / name)
report = {'decision': 'CLEAR_SCOPED_SOURCE_AND_DATA' if all(r['pass'] for r in checks) else 'HOLD_REVIEW_JOIN_FAILURE',
          'scope': 'Read-only retained source/data review. No candidate import, browser/subject/test actor, network, native operation, signal or canonical mutation. No final root packet existed at review time; no archive/global-seal claim.',
          'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'checks': checks, 'pass_count': sum(r['pass'] for r in checks), 'fail_count': sum(not r['pass'] for r in checks),
          'input_regular_files': inputs, 'observed_symlinks_not_followed': symlinks,
          'captured_live_git': current_git,
          'claims_not_established': ['Original hosted event ordering or causal diagnosis', 'Original missing-attachment actor or stage', 'Platform/package/milestone/M04 acceptance', 'Unretained process telemetry beyond retained runner receipts']}
(OUT / 'data-review.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({'decision': report['decision'], 'pass': report['pass_count'], 'fail': report['fail_count'], 'failures': [r for r in checks if not r['pass']], 'input_files': len(inputs)}, indent=2))
