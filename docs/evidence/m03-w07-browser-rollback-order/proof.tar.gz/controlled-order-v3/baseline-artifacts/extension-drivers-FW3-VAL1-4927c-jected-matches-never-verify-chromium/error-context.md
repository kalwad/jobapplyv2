# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension-drivers.spec.ts >> FW3/VAL1/VAL2/DATE2: immediate-only or site-rejected matches never verify
- Location: ../jobapplyv2-evidence/resume-20261028/browser-rollback-order-v3/baseline/extension-drivers.spec.ts:616:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "FAILED"
Received: "VERIFIED"
```

# Test source

```ts
  575 |   await expect(react.page.locator("#react-state-full-name")).toHaveText("");
  576 |   await react.page.locator("#react-rerender").dispatchEvent("click");
  577 |   expect(await react.page.locator("#react-full-name").inputValue()).toBe("");
  578 | 
  579 |   const vuePage = await extensionContext.newPage();
  580 |   await vuePage.goto(`${LAB_ORIGIN}/vue/`);
  581 |   await expect(vuePage.locator("html")).toHaveAttribute(
  582 |     CONTENT_READY_ATTRIBUTE,
  583 |     CONTENT_READY_VALUE,
  584 |   );
  585 |   const vueTabId = await tabIdForPage(serviceWorker, vuePage);
  586 |   const vue: Harness = {
  587 |     page: vuePage,
  588 |     controller: react.controller,
  589 |     tabId: vueTabId,
  590 |   };
  591 |   scanned = await descriptors(vue);
  592 |   await vue.page.evaluate(() => {
  593 |     window.setTimeout(() => {
  594 |       document
  595 |         .getElementById("vue-rerender")
  596 |         ?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
  597 |     }, 20);
  598 |   });
  599 |   const vueResult = await execute(
  600 |     vue,
  601 |     descriptorByLabel(scanned, "Full name (required)"),
  602 |     { kind: "TEXT", text: "Synthetic Vue" },
  603 |     undefined,
  604 |     125,
  605 |   );
  606 |   expect(vueResult.result.outcome).toBe("VERIFIED");
  607 |   await expect(vue.page.locator("#vue-state-full-name")).toHaveText(
  608 |     "Synthetic Vue",
  609 |   );
  610 |   await vue.page.locator("#vue-rerender").dispatchEvent("click");
  611 |   expect(await vue.page.locator("#vue-full-name").inputValue()).toBe(
  612 |     "Synthetic Vue",
  613 |   );
  614 | });
  615 | 
  616 | test("FW3/VAL1/VAL2/DATE2: immediate-only or site-rejected matches never verify", async ({
  617 |   extensionContext,
  618 |   extensionId,
  619 |   serviceWorker,
  620 | }) => {
  621 |   const react = await openHarness(
  622 |     extensionContext,
  623 |     extensionId,
  624 |     serviceWorker,
  625 |     "/react/",
  626 |   );
  627 |   const scannedReact = await descriptors(react);
  628 |   await react.page.evaluate(() => {
  629 |     const root = document.documentElement;
  630 |     root.dataset.rollbackOrder = "";
  631 |     for (const type of ["input", "change", "click"]) {
  632 |       document.addEventListener(type, (event) => {
  633 |         const id = (event.target as HTMLElement).id;
  634 |         if (id === "react-full-name" || id === "react-rerender") {
  635 |           root.dataset.rollbackOrder += `${event.type}:${id};`;
  636 |         }
  637 |       }, true);
  638 |     }
  639 |   });
  640 |   await react.page.evaluate(() => {
  641 |     for (const eventName of ["input", "change"]) {
  642 |       document.addEventListener(
  643 |         eventName,
  644 |         (event) => {
  645 |           if ((event.target as HTMLElement).id === "react-full-name") {
  646 |             event.stopImmediatePropagation();
  647 |           }
  648 |         },
  649 |         true,
  650 |       );
  651 |     }
  652 |     window.setTimeout(() => {
  653 |       document
  654 |         .getElementById("react-rerender")
  655 |         ?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
  656 |     }, 20);
  657 |   });
  658 |   // Controlled experiment only: preparation latency, not settle budget.
  659 |   await react.page.evaluate(() => new Promise<void>((resolve) => {
  660 |     window.setTimeout(resolve, 100);
  661 |   }));
  662 |   const rollback = await execute(
  663 |     react,
  664 |     descriptorByLabel(scannedReact, "Full name (required)"),
  665 |     { kind: "TEXT", text: "Transient only" },
  666 |     undefined,
  667 |     125,
  668 |   );
  669 |   console.log("ROLLBACK_ORDER_PROBE", await react.page.evaluate(() => ({
  670 |     events: document.documentElement.dataset.rollbackOrder,
  671 |     renderCount: document.getElementById("react-render-count")?.textContent,
  672 |     committed: document.getElementById("react-state-full-name")?.textContent,
  673 |     domValue: (document.getElementById("react-full-name") as HTMLInputElement).value,
  674 |   })), rollback.result.outcome);
> 675 |   expect(rollback.result.outcome).toBe("FAILED");
      |                                   ^ Error: expect(received).toBe(expected) // Object.is equality
  676 |   expect(rollback.result.reason_codes).toContain("PERSISTENCE_NOT_VERIFIED");
  677 |   expect(await react.page.locator("#react-full-name").inputValue()).toBe("");
  678 | 
  679 |   await replaceBody(
  680 |     react,
  681 |     `<main><form>
  682 |       <label for="rejected">Rejected value</label>
  683 |       <input id="rejected" aria-describedby="rejected-error">
  684 |       <p id="rejected-error" class="error"></p>
  685 |       <label for="date">Bounded date</label>
  686 |       <input id="date" type="date" min="2030-01-01">
  687 |     </form></main>`,
  688 |   );
  689 |   await react.page.locator("#rejected").evaluate((input) => {
  690 |     input.addEventListener("input", () => {
  691 |       const error = document.getElementById("rejected-error");
  692 |       if (error === null) throw new Error("rejection surface missing");
  693 |       error.textContent = "Rejected by synthetic site rule";
  694 |     });
  695 |   });
  696 |   const scanned = await descriptors(react);
  697 |   const rejected = await execute(
  698 |     react,
  699 |     descriptorByLabel(scanned, "Rejected value"),
  700 |     { kind: "TEXT", text: "matching-dom-value" },
  701 |   );
  702 |   expect(rejected.result.outcome).toBe("NEEDS_REVIEW");
  703 |   expect(rejected.result.reason_codes).toContain("SITE_REJECTED");
  704 |   expect(JSON.stringify(rejected)).not.toContain("matching-dom-value");
  705 |   expect(JSON.stringify(rejected)).not.toContain("Rejected by synthetic");
  706 | 
  707 |   const invalidDate = await execute(
  708 |     react,
  709 |     descriptorByLabel(scanned, "Bounded date"),
  710 |     { kind: "DATE", iso_date: "2027-01-01" },
  711 |   );
  712 |   expect(invalidDate.result.outcome).not.toBe("VERIFIED");
  713 |   expect(invalidDate.result.site_acceptance).toBe("REJECTED");
  714 | });
  715 | 
  716 | test("SEL2/SEL3/RAD2: missing, disabled, disappearing, and duplicate semantic options are never guessed", async ({
  717 |   extensionContext,
  718 |   extensionId,
  719 |   serviceWorker,
  720 | }) => {
  721 |   const harness = await openHarness(
  722 |     extensionContext,
  723 |     extensionId,
  724 |     serviceWorker,
  725 |     "/native/",
  726 |   );
  727 |   await replaceBody(
  728 |     harness,
  729 |     `<main><form>
  730 |       <label for="choice">Exact choice</label>
  731 |       <select id="choice"><option value="" selected>Choose exactly</option><option value="unrelated">Only unrelated</option><option value="disabled" disabled>Disabled target</option></select>
  732 |       <fieldset><legend>Duplicate radio</legend>
  733 |         <label><input type="radio" name="dup" value="same"> First</label>
  734 |         <label><input type="radio" name="dup" value="same"> Second</label>
  735 |       </fieldset>
  736 |     </form></main>`,
  737 |   );
  738 |   const scanned = await descriptors(harness);
  739 |   const choice = descriptorByLabel(scanned, "Exact choice");
  740 |   const missing = await execute(harness, choice, {
  741 |     kind: "OPTION",
  742 |     value_digest: await semanticDigest("option-value-v1\0missing"),
  743 |   });
  744 |   expect(missing.result.outcome).not.toBe("VERIFIED");
  745 |   expect(await harness.page.locator("#choice").inputValue()).toBe("");
  746 |   const disabled = await execute(harness, choice, {
  747 |     kind: "OPTION",
  748 |     value_digest: await semanticDigest("option-value-v1\0disabled"),
  749 |   });
  750 |   expect(disabled.result.outcome).not.toBe("VERIFIED");
  751 |   expect(await harness.page.locator("#choice").inputValue()).toBe("");
  752 | 
  753 |   const radio = await execute(
  754 |     harness,
  755 |     descriptorByLabel(scanned, "Duplicate radio"),
  756 |     {
  757 |       kind: "OPTION",
  758 |       value_digest: await semanticDigest("option-value-v1\0same"),
  759 |     },
  760 |   );
  761 |   expect(radio.result.outcome).not.toBe("VERIFIED");
  762 |   expect(await harness.page.locator("input[type=radio]:checked").count()).toBe(
  763 |     0,
  764 |   );
  765 | 
  766 |   await harness.page.locator("option[value='disabled']").evaluate((option) => {
  767 |     option.remove();
  768 |   });
  769 |   const vanished = await execute(harness, choice, {
  770 |     kind: "OPTION",
  771 |     value_digest: await semanticDigest("option-value-v1\0disabled"),
  772 |   });
  773 |   expect(vanished.result.outcome).not.toBe("VERIFIED");
  774 |   expect(await harness.page.locator("#choice").inputValue()).toBe("");
  775 | });
```