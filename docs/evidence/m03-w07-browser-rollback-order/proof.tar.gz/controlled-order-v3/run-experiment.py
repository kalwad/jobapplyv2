from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import stat
import subprocess
import time

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
OUT = Path(__file__).parent

def snapshot():
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).split(b'\0')
    result = {}
    for raw in paths:
        if raw:
            path = ROOT / os.fsdecode(raw)
            info = path.lstat()
            assert stat.S_ISREG(info.st_mode)
            result[os.fsdecode(raw)] = {'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    runtime = ROOT / 'apps/desktop/src-tauri/runtime-payload'
    staged = {}
    for path in sorted(runtime.rglob('*')):
        info = path.lstat()
        if stat.S_ISDIR(info.st_mode):
            continue
        assert stat.S_ISREG(info.st_mode)
        staged[path.relative_to(runtime).as_posix()] = {'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    return {'source': result, 'runtime': staged, 'git_status': subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True), 'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(), 'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip()}

assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True) == ''
before = snapshot()
(OUT / 'before.json').write_text(json.dumps(before, indent=2, sort_keys=True) + '\n')
(OUT / 'context.json').write_text(json.dumps({'start_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'scope': 'Real owned bundled Chromium; original production; controlled 100ms preparation latency in both variants, unchanged125ms settle budget and all original assertions.'}, indent=2) + '\n')
env = dict(os.environ)
env['PATH'] = '/opt/homebrew/opt/node@24/bin:' + env['PATH']
results = []
for name in ('baseline', 'fixed'):
    argv = ['pnpm', 'exec', 'playwright', 'test', '--config', str(OUT / (name + '.config.ts')), '--grep', 'FW3/VAL1/VAL2/DATE2']
    start = time.monotonic()
    with (OUT / (name + '.log')).open('wb') as output:
        child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        timeout = False
        signals = []
        try:
            code = child.wait(timeout=600)
        except subprocess.TimeoutExpired:
            timeout = True
            for sig in [signal.SIGTERM, signal.SIGKILL]:
                try:
                    os.killpg(child.pid, sig)
                    signals.append(sig.name)
                except ProcessLookupError:
                    pass
                if sig == signal.SIGTERM:
                    time.sleep(1)
            code = child.wait(timeout=10)
    try:
        os.killpg(child.pid, 0)
        group = 'PRESENT_AFTER_DIRECT_CHILD_REAP; NO_POST_REAP_SIGNAL'
    except ProcessLookupError:
        group = 'ABSENT'
    row = {'name': name, 'argv': argv, 'exit_code': code, 'timeout': timeout, 'seconds': time.monotonic() - start, 'direct_child_reaped': child.returncode is not None, 'observed_group': group, 'outer_cleanup_signals': signals}
    results.append(row)
    (OUT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    if timeout or group != 'ABSENT':
        break
after = snapshot()
(OUT / 'after.json').write_text(json.dumps(after, indent=2, sort_keys=True) + '\n')
closure = {'end_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'source_files': len(before['source']), 'runtime_files': len(before['runtime']), 'source_runtime_status_head_tree_equal': before == after, 'expected_baseline_failed_fixed_passed': len(results) == 2 and [r['exit_code'] for r in results] == [1, 0], 'all_children_reaped_groups_absent_no_timeout_or_signals': all(r['direct_child_reaped'] and r['observed_group'] == 'ABSENT' and not r['timeout'] and not r['outer_cleanup_signals'] for r in results)}
(OUT / 'closure.json').write_text(json.dumps(closure, indent=2) + '\n')
print(json.dumps(closure), flush=True)
raise SystemExit(0 if all(closure[key] for key in ('source_runtime_status_head_tree_equal', 'expected_baseline_failed_fixed_passed', 'all_children_reaped_groups_absent_no_timeout_or_signals')) else 1)
