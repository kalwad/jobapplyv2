import base from "/Users/tanishkalwad/jobapplyv2/playwright.config.ts";
import { defineConfig } from "@playwright/test";
export default defineConfig({
  ...base,
  testDir: "/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/browser-rollback-order-v3/baseline",
  outputDir: "/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/browser-rollback-order-v3/baseline-artifacts",
  globalSetup: "/Users/tanishkalwad/jobapplyv2/e2e/extension/support/global-setup.ts",
  webServer: (Array.isArray(base.webServer) ? base.webServer : [base.webServer]).map((entry) => ({ ...entry, cwd: "/Users/tanishkalwad/jobapplyv2" })),
});
