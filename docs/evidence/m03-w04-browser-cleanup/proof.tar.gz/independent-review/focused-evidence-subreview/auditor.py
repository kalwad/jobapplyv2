"""Read retained bounded evidence only; never invoke candidate code or Git."""
from pathlib import Path
import ast
import collections
import datetime
import hashlib
import json
import re

P = Path('/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019')
O = Path('/tmp/japp-windows-cleanup-evidence-subreview')
O.mkdir(exist_ok=False)
checks = []
inputs = {}


def data(rel):
    b = (P / rel).read_bytes()
    inputs[str(rel)] = {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
    return b


def obj(rel):
    return json.loads(data(rel))


def ck(name, passed, detail=None):
    checks.append({'name': name, 'passed': bool(passed), 'detail': detail})


def sha(b):
    return hashlib.sha256(b).hexdigest()


freeze = obj('source-freeze-v1.json')
base = obj('base-source-manifest.json')
patch = data('candidate-v1.patch')
ck('requested freeze identity', inputs['source-freeze-v1.json']['sha256'] == '650df4548f43c9161f4a368f37dd3c8622b7335d9803ce9c286f8405fe1a1d9a')
ck('requested patch identity', sha(patch) == freeze['patch_sha256'] == '6fe044bc100ccf4e96b435ea7395a970af5361b569e6e00a6828bb4123c84ed5')
ck('requested immutable base', freeze['base_commit'] == 'c5766246f8b81f32fbfb2eebbacb96c0ba9f5307')
ck('manifest self digest', sha(json.dumps(freeze['entries'], sort_keys=True, separators=(',', ':')).encode()) == freeze['source_manifest_sha256'])
expected_paths = [
    'apps/extension/test/m02-w15/inherited-fixture-cleanup.test.ts',
    'apps/extension/test/m02-w15/owned-browser-retirement.test.ts',
    'e2e/extension/support/extension-test.ts',
    'playwright.config.ts',
    'scripts/tests/test_ci_workflow.py',
    'scripts/tests/test_suite_states.py',
    'scripts/verification-suites.json',
]
ck('seven expected changed paths', freeze['changed'] == expected_paths)
ck('base and candidate manifest counts', len(base) == 1822 and len(freeze['entries']) == freeze['source_count'] == 1823)
ck('only seven changes in declared manifests', sorted(k for k in set(base) | set(freeze['entries']) if base.get(k) != freeze['entries'].get(k)) == expected_paths)
ck('1816 unchanged manifest entries', sum(v == freeze['entries'].get(k) for k, v in base.items()) == freeze['unchanged_old'] == 1816)
for path in expected_paths:
    b = data('source/' + path)
    ck('frozen changed file: ' + path, len(b) == freeze['entries'][path]['bytes'] and sha(b) == freeze['entries'][path]['sha256'])
    if path in base:
        old = data('preimages/' + path)
        ck('retained base preimage: ' + path, len(old) == base[path]['bytes'] and sha(old) == base[path]['sha256'])

# Apply the seven retained unified diffs in memory to the six preimages and
# new empty source, checking all context/removal lines. No tar/cache scan.
sections = re.split(r'(?=^diff --git )', patch.decode(), flags=re.M)[1:]
reconstructed = []
for section in sections:
    lines = section.splitlines(keepends=True)
    m = re.fullmatch(r'diff --git a/(.+) b/(.+)\n', lines[0])
    if not m or m[1] != m[2]:
        raise ValueError('Unexpected patch path form')
    path = m[2]
    old = data('preimages/' + path).decode().splitlines(keepends=True) if path in base else []
    out = []
    pos = 0
    i = 1
    while i < len(lines):
        h = re.match(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', lines[i])
        if not h:
            i += 1
            continue
        start = int(h[1]) - (1 if int(h[1]) else 0)
        out.extend(old[pos:start])
        pos = start
        i += 1
        while i < len(lines) and not lines[i].startswith('@@ '):
            line = lines[i]
            if line.startswith('\\ No newline'):
                raise ValueError('Unexpected missing newline patch')
            if line.startswith(' '):
                if old[pos] != line[1:]:
                    raise ValueError('Context mismatch: ' + path)
                out.append(old[pos]); pos += 1
            elif line.startswith('-'):
                if old[pos] != line[1:]:
                    raise ValueError('Removal mismatch: ' + path)
                pos += 1
            elif line.startswith('+'):
                out.append(line[1:])
            else:
                raise ValueError('Unexpected diff line: ' + repr(line))
            i += 1
    out.extend(old[pos:])
    reconstructed.append(path)
    ck('patch reconstructs exact frozen file: ' + path, sha(''.join(out).encode()) == freeze['entries'][path]['sha256'])
ck('patch contains exactly seven expected paths', reconstructed == expected_paths)

command_names = [
    '00-tools', '01-baseline28', '02-red10', '03-green44', '04-retention-red',
    '05-format-ts', '06-format-py', '07-retention-green', '08-green44-formatted',
    '09-typecheck', '10-python-contracts', '11-lint-ts', '12-ruff', '13-portability',
    '14-lint-ts-corrected', '15-portability-owned-git',
    '16-python-contracts-owned-git', '17-final44', '18-diff-check', '19-typecheck-final',
]
expected_exits = [0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 2, 0, 0, 0, 0, 0, 0]
commands = {}
final_map = {k: v['sha256'] for k, v in freeze['entries'].items()}
base_map = {k: v['sha256'] for k, v in base.items()}
for n, expected_exit in zip(command_names, expected_exits):
    prefix = 'commands/' + n + '/'
    c = obj(prefix + 'command.json')
    end = obj(prefix + 'completion.json')
    before = obj(prefix + 'source-before.json')
    after = obj(prefix + 'source-after.json')
    stdout = data(prefix + 'stdout.log')
    stderr = data(prefix + 'stderr.log')
    ck(n + ' raw log hashes', sha(stdout) == end['stdout_sha256'] and sha(stderr) == end['stderr_sha256'])
    ck(n + ' command and completion metadata', all(end.get(k) == v for k, v in c.items()) and end['exit_code'] == expected_exit)
    ck(n + ' owned candidate cwd', Path(c['cwd']).resolve() == (P / 'source').resolve())
    ck(n + ' recorded source neutrality', end['source_unchanged'] == (before == after) and (before == after) == (n not in ('05-format-ts', '06-format-py')))
    ck(n + ' bounded snapshot path scope', set(before) <= set(final_map) and set(after) <= set(final_map))
    ck(n + ' timestamps', datetime.datetime.fromisoformat(end['utc_end']) >= datetime.datetime.fromisoformat(c['utc_start']) and end['elapsed_seconds'] >= 0)
    if int(n[:2]) >= 14:
        ck(n + ' exact final source binding', before == after == final_map)
    commands[n] = {'command': c, 'completion': end, 'before': before, 'after': after, 'stdout': stdout.decode(), 'stderr': stderr.decode()}
ck('baseline exact base binding', commands['01-baseline28']['before'] == base_map)
ck('targeted RED only adds test to base', {k: v for k, v in commands['02-red10']['before'].items() if k in base_map} == base_map)
ck('targeted RED test source retained', sha(data('regression-tests-red-preimage.ts')) == commands['02-red10']['before'][expected_paths[1]])
ck('retention RED Python test source retained', sha(data('retention-red-test-preimage.py')) == commands['04-retention-red']['before']['scripts/tests/test_ci_workflow.py'])
ck('retention RED old production config and suite registry', all(commands['04-retention-red']['before'][k] == base_map[k] for k in ('playwright.config.ts', 'scripts/verification-suites.json')))
ck('retention GREEN exact final source except separate unit lint fix', [k for k in final_map if commands['07-retention-green']['before'].get(k) != final_map[k]] == [expected_paths[0]])
ck('retention Python RED and GREEN test same AST', ast.dump(ast.parse(data('retention-red-test-preimage.py'))) == ast.dump(ast.parse(data('source/scripts/tests/test_ci_workflow.py'))))

results = {}
for name, counts in [
    ('baseline28.json', {'passed': 28}), ('red10.json', {'failed': 10, 'skipped': 6}),
    ('green44.json', {'passed': 44}), ('green44-final.json', {'passed': 44}),
    ('green44-final-source.json', {'passed': 44}),
]:
    d = obj(name)
    rows = [a for r in d['testResults'] for a in r['assertionResults']]
    ck(name + ' individual status counts', dict(collections.Counter(a['status'] for a in rows)) == counts)
    ck(name + ' unique result identities', len({a['fullName'] for a in rows}) == len(rows))
    ck(name + ' summary consistent', d['numPassedTests'] == counts.get('passed', 0) and d['numFailedTests'] == counts.get('failed', 0) and d['numPendingTests'] == counts.get('skipped', 0) and d['numTotalTests'] == len(rows) and d['success'] == (counts.get('failed', 0) == 0))
    results[name] = (d, rows)
baseline_names = {a['fullName'] for a in results['baseline28.json'][1]}
final_rows = results['green44-final-source.json'][1]
ck('original 28 identities preserved and pass in final', baseline_names == {a['fullName'] for a in final_rows if 'inherited owned fixture cleanup' in a['fullName']} and all(a['status'] == 'passed' for a in final_rows if a['fullName'] in baseline_names))
new_names = {a['fullName'] for a in final_rows} - baseline_names
ck('all 16 new test identities included in final', new_names == {a['fullName'] for a in results['red10.json'][1]} and len(new_names) == 16)
pattern = commands['02-red10']['command']['argv'][commands['02-red10']['command']['argv'].index('--testNamePattern') + 1]
ck('ten RED failures precisely selected, six explicitly filtered', all((a['status'] == 'failed') == bool(re.search(pattern, a['fullName'])) for a in results['red10.json'][1]))
ck('RED failures are assertion/expected-failure signals', all(a['failureMessages'] and ('AssertionError:' in a['failureMessages'][0] or 'Error: EXPECTED_FIXTURE_FAILURE' in a['failureMessages'][0]) for a in results['red10.json'][1] if a['status'] == 'failed'))
for command, result_name in [('01-baseline28', 'baseline28.json'), ('02-red10', 'red10.json'), ('03-green44', 'green44.json'), ('08-green44-formatted', 'green44-final.json'), ('17-final44', 'green44-final-source.json')]:
    c = commands[command]
    d = results[result_name][0]
    t = d['startTime'] / 1000
    ck(command + ' intended JSON result and clock binding', '--outputFile=' + str(P / result_name) in c['command']['argv'] and datetime.datetime.fromisoformat(c['command']['utc_start']).timestamp() <= t <= datetime.datetime.fromisoformat(c['completion']['utc_end']).timestamp())

ck('Python final contract summary', re.search(r'\b355 passed, 1 deselected in [\d.]+s', commands['16-python-contracts-owned-git']['stdout']) is not None)
ck('Python retention excluded by exact selector', commands['16-python-contracts-owned-git']['command']['argv'][-2:] == ['-k', 'not test_artifact_path_matches_playwright_output_config'])
ck('retention separately GREEN', re.search(r'\b1 passed in [\d.]+s', commands['07-retention-green']['stdout']) is not None and '-p' in commands['07-retention-green']['command']['argv'] and 'retention_capture' in commands['07-retention-green']['command']['argv'])
ck('retention RED actual artifact loss', 'deleted the default failure artifact default-evidence.marker' in commands['04-retention-red']['stdout'] and '1 failed in' in commands['04-retention-red']['stdout'])
ck('initial failures retained', '3 failed, 352 passed, 1 deselected' in commands['10-python-contracts']['stdout'] and 'git diff failed (fail closed)' in commands['10-python-contracts']['stdout'] and 'no-empty-function' in commands['11-lint-ts']['stdout'] and 'git ls-files failed' in commands['13-portability']['stderr'])
preservation = obj('assertion-preservation.json')
ck('retained assertion preservation report', preservation['original_assertion_expressions'] == preservation['current_assertion_expressions'] == len(preservation['old']) == len(preservation['current']) == 39 and preservation['old'] == preservation['current'] and preservation['equal_after_only_rmSync_to_rm_and_format_normalization'] is True)

# Four installed-runner invocations are real CLI cleanup evidence using tiny
# synthetic tests, not real extension browser/native-Windows execution.
capture_source = data('retention_capture.py').decode()
ck('capture adapter calls original unchanged and returns result', 'result=original(argv,**kwargs)' in capture_source and 'return result' in capture_source)
capture_rows = []
outputs = []
for i, dirname in enumerate(('browser', 'public-research', 'public-contact', 'visual'), 1):
    rel = f'retention-cli-captures/{i:02}/'
    c = obj(rel + 'command.json')
    raw = data(rel + 'stdout.json')
    report = json.loads(raw)
    stderr = data(rel + 'stderr.log')
    ck(f'CLI {i} raw result hash and stderr', sha(raw) == c['stdout_sha256'] and stderr == b'')
    expected_stats = {'expected': 0 if i == 1 else 1, 'unexpected': 1 if i == 1 else 0, 'skipped': 0, 'flaky': 0}
    ck(f'CLI {i} expected result and pinned version', c['returncode'] == (1 if i == 1 else 0) and all(report['stats'][k] == v for k, v in expected_stats.items()) and report['config']['version'] == '1.62.0' and report['errors'] == [])
    dirs = {Path(v['outputDir']) for v in report['config']['projects']}
    ck(f'CLI {i} exact sibling output', len(dirs) == 1 and next(iter(dirs)).name == dirname and next(iter(dirs)).parent.name == 'test-results')
    output = next(iter(dirs)); outputs.append(output)
    ck(f'CLI {i} exact executable and config argv binding', c['argv'][0] == 'node' and c['argv'][1].endswith('/source/node_modules/@playwright/test/cli.js') and report['config']['argv'][1:] == c['argv'][1:] and report['config']['configFile'] == c['argv'][4])
    capture_rows.append({'index': i, 'returncode': c['returncode'], 'stats': expected_stats, 'output_dir': str(output)})
ck('four outputs share only common artifact parent', len(set(outputs)) == 4 and len({v.parent for v in outputs}) == 1 and all(not a.is_relative_to(b) for a in outputs for b in outputs if a != b))
ck('visual actual output override retained', obj('retention-cli-captures/04/command.json')['argv'][-2:] == ['--output', 'test-results/visual'])
marker = next(outputs[0].rglob('default-evidence.marker'))
trace = marker.with_name('trace.zip')
ck('retention marker and trace remain present', marker.read_bytes() == b'original default failure artifact' and trace.is_file() and trace.stat().st_size > 0)

summary = {
    'created_at': datetime.datetime.now(datetime.UTC).isoformat(),
    'scope': 'Bounded independent retained-evidence audit; source semantics reviewed separately by parent.',
    'status': 'CLEAR' if all(c['passed'] for c in checks) else 'FINDINGS',
    'checks_passed': sum(c['passed'] for c in checks),
    'checks_total': len(checks),
    'expected_base_commit': freeze['base_commit'],
    'patch_sha256': sha(patch),
    'freeze_sha256': inputs['source-freeze-v1.json']['sha256'],
    'results': {'original': '28 PASS', 'specific_red': '10 assertion failures, six explicitly filtered', 'final': '44 PASS, zero pending', 'contracts': '355 PASS, one retention test deselected and separately PASS', 'retention': 'four real pinned Playwright CLI runs: intentional failure, then three passes'},
    'capture_rows': capture_rows,
    'limitations': [
        'No candidate tests, actor, browser, compiler, Git command, API, root write, full source archive extraction, or dependency cache hashing was performed by this reviewer.',
        'Six preimages and seven changed source files were read and hashed; unchanged source equality was checked through retained manifests/snapshots, not by rereading the entire candidate checkout or immutable Git objects.',
        'Retained source snapshots are scoped to declared base paths plus the added test; they do not inventory generated output or ignored files.',
        'Early retention GREEN predates only a separate inherited unit-test lint fix; production/config/registry/Python inputs equal final. Final44, contracts, lint, portability, diff, and typecheck bind to complete final source.',
        'Current run-command.py has later environment capture fields absent from early records. Its current bytes are not claimed as the historical wrapper source for every invocation.',
        'The original assertion-preservation report was checked for internal identity; parent owns independent production/source-semantics review.',
        'Four CLI retention invocations use synthetic tests without browser launch. They establish runner cleanup behavior, not native Windows browser behavior.',
        'Real failed-fixture trace, unchanged Workday replay, later sibling runs, and native Windows confirmation are excluded; pending work is not PASS.',
    ],
    'checks': checks,
}
(O / 'findings.json').write_text(json.dumps(summary, indent=2) + '\n')
(O / 'input-identities.json').write_text(json.dumps(inputs, sort_keys=True, indent=2) + '\n')
failed = [c for c in checks if not c['passed']]
report = f"""Bounded Windows browser cleanup evidence subreview: {summary['status']}

{summary['checks_passed']}/{summary['checks_total']} checks passed for patch `{summary['patch_sha256']}` on base `{summary['expected_base_commit']}`. The requested source-freeze SHA-256 matches exactly. All seven changed source files and six preimages match the frozen manifests; applying the retained patch in memory reproduces the seven frozen files.

Retained results support 28 original PASS, 10 selected assertion failures with six explicitly filtered tests, and final 44 PASS with no pending tests. The original 28 identities persist in final. Final contract evidence is 355 PASS with one retention test deselected; that retention test separately passes. Earlier three Git-setup failures, lint failure, and portability failure remain retained.

The retention RED log identifies deletion of the original default-failure marker. The four real Playwright 1.62.0 CLI captures show the intentional failure followed by three passes and resolve to sibling browser, public-research, public-contact, and visual directories. The final retention test checks the original marker and trace bytes after each invocation; both remain present. This is synthetic runner cleanup evidence without browser launch.

Completed commands 14–19 bind exactly to the frozen 1823-entry source map, and all 20 audited commands' raw stdout/stderr hashes and completion claims match their retained records. Earlier retention GREEN differs from final only in the separate inherited unit-test file subsequently corrected for lint; its production/config/registry/Python source matches final.

No material source/evidence mismatch found in this bounded scope. Parent owns production/source semantics. No product reruns or root writes were performed. Real failed-fixture trace, unchanged Workday replay, later sibling runs, and native Windows confirmation were excluded; pending work is not PASS. Full unchanged-source/blob and dependency-cache verification were outside scope. The current wrapper's later capture fields are not represented as historical wrapper bytes for early records.
"""
if failed:
    report += '\nFailed checks:\n' + '\n'.join('- ' + c['name'] for c in failed) + '\n'
(O / 'report.md').write_text(report)
(O / 'auditor.py').write_bytes(Path(__file__).read_bytes())
seal = {x.name: {'bytes': x.stat().st_size, 'sha256': sha(x.read_bytes())} for x in sorted(O.iterdir()) if x.is_file()}
(O / 'seal.json').write_text(json.dumps(seal, sort_keys=True, indent=2) + '\n')
print(json.dumps({'status': summary['status'], 'passed': summary['checks_passed'], 'total': summary['checks_total'], 'failed': failed, 'directory': str(O), 'report_sha256': sha((O / 'report.md').read_bytes()), 'findings_sha256': sha((O / 'findings.json').read_bytes())}))
