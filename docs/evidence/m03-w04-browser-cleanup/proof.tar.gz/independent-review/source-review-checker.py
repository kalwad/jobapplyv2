"""Independent bounded source reading only; no product imports or execution."""
from pathlib import Path
import ast
import hashlib
import json
import re

packet = Path('/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019')
out = Path('/tmp/japp-m03-w03-windows-browser-cleanup-independent-review-20261019')
if out.exists():
    raise RuntimeError('FRESH_REVIEW_OUTPUT_REQUIRED')
out.mkdir()
checks = []
def check(name, passed, observed=None):
    checks.append({'name': name, 'pass': bool(passed), 'observed': observed})
def sha(body):
    return hashlib.sha256(body).hexdigest()
def body(path, old=False):
    return (packet / ('preimages' if old else 'source') / path).read_bytes()

freeze_bytes = (packet / 'source-freeze-v1.json').read_bytes()
freeze = json.loads(freeze_bytes)
base = json.loads((packet / 'base-source-manifest.json').read_bytes())
patch = (packet / 'candidate-v1.patch').read_bytes()
check('exact_frozen_manifest', sha(freeze_bytes) == '650df4548f43c9161f4a368f37dd3c8622b7335d9803ce9c286f8405fe1a1d9a')
check('exact_frozen_patch', sha(patch) == '6fe044bc100ccf4e96b435ea7395a970af5361b569e6e00a6828bb4123c84ed5')
changes = sorted(p for p in freeze['entries'] if base.get(p) != freeze['entries'][p])
deleted = sorted(set(base) - set(freeze['entries']))
added = sorted(set(freeze['entries']) - set(base))
check('six_mod_one_add_no_deletion', len(base) == 1822 and len(freeze['entries']) == 1823 and len(changes) == 7 and len(added) == 1 and not deleted and changes == sorted(freeze['changed']), {'changed': changes, 'added': added, 'deleted': deleted})
check('1816_old_metadata_entries_unchanged', sum(freeze['entries'].get(p) == r for p, r in base.items()) == 1816)
for path in changes:
    b = body(path)
    check('actual_changed_file:' + path, len(b) == freeze['entries'][path]['bytes'] and sha(b) == freeze['entries'][path]['sha256'])
    if path in base:
        old = body(path, True)
        check('original_preimage:' + path, len(old) == base[path]['bytes'] and sha(old) == base[path]['sha256'])

# Independent lexical assertion comparison. Preserve bytes inside string and
# template literals; normalize only inter-token whitespace/comments and the
# exact rmSync identifier. No TypeScript/compiler module is imported.
token_re = re.compile(r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|`(?:\\.|[^`\\])*`|[A-Za-z_$][A-Za-z0-9_$]*|\d+(?:\.\d+)?|[^\s]')
def assertions(source):
    tokens = [m.group() for m in token_re.finditer(source) if not m.group().startswith(('//', '/*'))]
    result = []
    def close(index):
        depth = 0
        for j in range(index, len(tokens)):
            if tokens[j] == '(':
                depth += 1
            elif tokens[j] == ')':
                depth -= 1
                if depth == 0:
                    return j + 1
        raise ValueError('UNBALANCED_ASSERTION')
    for i, token in enumerate(tokens[:-1]):
        if token != 'expect' or tokens[i+1] != '(':
            continue
        end = close(i+1)
        methods = 0
        while end + 1 < len(tokens) and tokens[end] == '.':
            end += 2
            if end < len(tokens) and tokens[end] == '(':
                end = close(end)
                methods += 1
        if methods:
            result.append(''.join('rm' if t == 'rmSync' else t for t in tokens[i:end]))
    return result
path = 'apps/extension/test/m02-w15/inherited-fixture-cleanup.test.ts'
old_assertions = assertions(body(path, True).decode())
new_assertions = assertions(body(path).decode())
check('39_original_assertions_exact_literals_preserved', len(old_assertions) == len(new_assertions) == 39 and old_assertions == new_assertions, {'old_count':len(old_assertions),'new_count':len(new_assertions)})
(out / 'independent-assertion-expressions.json').write_text(json.dumps({'old':old_assertions,'new':new_assertions,'normalization':'Only comments/inter-token whitespace and exact rmSync identifier; string/template literal bytes preserved.'},indent=2)+'\n')

registry_path = 'scripts/verification-suites.json'
old_registry = json.loads(body(registry_path, True))
new_registry = json.loads(body(registry_path))
def diffs(a,b,path=''):
    if type(a) is not type(b):
        return [path]
    if isinstance(a,dict):
        return [r for k in sorted(set(a)|set(b)) for r in ([path+'/'+k] if k not in a or k not in b else diffs(a[k],b[k],path+'/'+k))]
    if isinstance(a,list):
        if len(a)!=len(b):
            return [path]
        return [r for i,(x,y) in enumerate(zip(a,b)) for r in diffs(x,y,path+'/'+str(i))]
    return [] if a==b else [path]
delta = diffs(old_registry,new_registry)
old_suites = {r['id']:r for r in old_registry['suites']}
new_suites = {r['id']:r for r in new_registry['suites']}
check('registry_no_ids_owners_proofs_or_timeout_change', old_suites.keys()==new_suites.keys() and all({k:v for k,v in a.items() if k not in {'commands','artifacts'}}=={k:v for k,v in new_suites[i].items() if k not in {'commands','artifacts'}} for i,a in old_suites.items()))
check('registry_exact_visual_output_append', new_suites['visual']['commands']==[old_suites['visual']['commands'][0]+['--output','test-results/visual']])
check('registry_all_other_commands_unchanged', all(a['commands']==new_suites[i]['commands'] for i,a in old_suites.items() if i!='visual'))
check('registry_only_three_intended_changes', len(delta)==3 and sum('/artifacts/' in p for p in delta)==2 and sum('/commands/' in p for p in delta)==1, delta)
for path in ['scripts/tests/test_ci_workflow.py','scripts/tests/test_suite_states.py']:
    def ids(data):
        tree=ast.parse(data)
        return [(n.name,ast.dump(n.args),[ast.dump(d) for d in n.decorator_list]) for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')]
    check('python_test_identities_preserved:'+path,ids(body(path,True))==ids(body(path)))

fixture=body('e2e/extension/support/extension-test.ts').decode()
old_fixture=body('e2e/extension/support/extension-test.ts',True).decode()
check('same_exact_owned_profile_creation_and_retry_budget', 'mkdtempSync(join(tmpdir(), profilePrefix))' in fixture and all(fixture.count(x)==old_fixture.count(x)==1 for x in ['recursive: true,','force: true,','maxRetries: 10,','retryDelay: 100,']))
check('context_close_instrumentation_retained', fixture.count('await context?.close();')==1 and 'errors.push(error);' in fixture)
check('no_targetclosed_error_swallow_branch', not any(t in fixture for t in ['TargetClosedError','isTargetClosedError','error.message.includes','instanceof Error']))
check('exact_owner_captured_before_use',fixture.index('ownedBrowser = context.browser();')<fixture.index('await use(context);'))
check('context_browser_rm_order_and_listener_cleanup',fixture.index('await context?.close();')<fixture.index('await ownedBrowser?.close();')<fixture.index('await removeProfile();')<fixture.index('ownedBrowser?.off("disconnected", onDisconnected)'))
check('context_isClosed_not_used_for_retirement','isClosed(' not in fixture)
check('no_new_forbidden_probe_or_process_authority',all(x not in fixture for x in ['constructor.name','newPage(','newBrowserCDPSession','process.kill','process.pid','_browser','_channel','_connection']))
check('original_network_isolation_and_outer_primary_cause_preserved',fixture[fixture.index('const offenders: string[]'):]==old_fixture[old_fixture.index('const offenders: string[]'):])
check('no_deadline_added_or_increased',len(re.findall(r'timeout|Timeout|setTimeout',fixture))==len(re.findall(r'timeout|Timeout|setTimeout',old_fixture)))
for path in ['e2e/extension/public-research/playwright.config.ts','e2e/extension/public-contact/playwright.config.ts','.github/workflows/ci.yml','scripts/python-test-inventory.v1.json']:
    check('unchanged_control_or_inventory_metadata:'+path,base[path]==freeze['entries'][path])

record={'scope':'SOURCE_ONLY_BOUNDED_INDEPENDENT_REVIEW_NO_ACTOR_COMPILER_TEST_OR_ROOT_WRITE','status':'CLEAR' if all(c['pass'] for c in checks) else 'FINDING','checks':checks,'checks_passed':sum(c['pass'] for c in checks),'checks_total':len(checks),'base_commit':freeze['base_commit'],'base_tree':freeze['base_tree'],'patch_sha256':sha(patch),'freeze_sha256':sha(freeze_bytes),'runtime_windows_validation':'NOT_CLAIMED','real_trace_and_workday_replay':'PENDING_AUTHOR_TERMINAL_RECORDS','limits':['Unchanged1816 entries compared as frozen manifest metadata, not whole-cache/whole-archive fresh hashing.','Only7 changed files and6 preimages independently hashed here; selected pinned SDK source was read separately.','An author test-wrapper file updated later must not be called the exact historical wrapper source for earlier commands.']}
(out/'source-findings.json').write_text(json.dumps(record,indent=2)+'\n')
(out/'source-review-checker.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({k:record[k] for k in ['status','checks_passed','checks_total']}))
