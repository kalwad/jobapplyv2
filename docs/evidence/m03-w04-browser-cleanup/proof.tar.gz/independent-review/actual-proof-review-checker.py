"""Read and independently reconcile closed actor records; never run actors."""
from pathlib import Path, PurePosixPath
from collections import Counter
import hashlib
import json
import re
import stat
import tarfile
import zipfile

packet = Path('/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019')
out = Path('/tmp/japp-m03-w03-windows-browser-cleanup-independent-review-20261019')
freeze = json.loads((packet/'source-freeze-v1.json').read_bytes())
base = json.loads((packet/'base-source-manifest.json').read_bytes())
checks=[]
def check(name,ok,observed=None):checks.append({'name':name,'pass':bool(ok),'observed':observed})
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):
    path=packet/p
    if path.is_symlink() or not path.is_file():raise ValueError('REGULAR_FILE_REQUIRED:'+str(p))
    return path.read_bytes()
def data(p):return json.loads(read(p))
def tests(suite):
    for spec in suite.get('specs',[]):
        for test in spec.get('tests',[]):yield spec,test
    for nested in suite.get('suites',[]):yield from tests(nested)

command_names=['20-proof-list','21-real-intentional-failure','22-later-research','23-later-contact','24-later-visual','25-proof-list-after-siblings','26-later-visual-corrected-cwd','27-proof-list-after-corrected-visual','28-wd-exact-list','29-wd-exact-replay']
for name in command_names:
    folder='commands/'+name+'/'
    command=data(folder+'command.json');completion=data(folder+'completion.json')
    check(name+':logs_exact_hashes',all(sha(read(folder+stream+'.log'))==completion[stream+'_sha256'] for stream in ['stdout','stderr']))
    check(name+':exact_command_and_frozen_source_endpoints',all(completion[k]==command[k] for k in command) and data(folder+'source-before.json')==data(folder+'source-after.json')=={path:row['sha256'] for path,row in freeze['entries'].items()} and completion['source_unchanged'] is True)
    check(name+':expected_exit_and_no_retry_modification',completion['exit_code']==(1 if name=='21-real-intentional-failure' else 0) and '--retries' not in command['argv'])

failed=data('real-proof/actual-report.json');failed_tests=list(tests(failed))
check('actual_failed_fixture_one_test_one_result_only',len(failed_tests)==1 and len(failed_tests[0][1]['results'])==1 and failed['stats']['unexpected']==1 and failed['stats']['expected']==failed['stats']['flaky']==failed['stats']['skipped']==0 and failed['errors']==[])
spec,test=failed_tests[0];result=test['results'][0]
check('sole_failure_is_intentional_body_assertion_not_cleanup',result['status']=='failed' and result['retry']==0 and len(result['errors'])==1 and 'REAL_FIXTURE_BODY_ERROR_RETAINED' in result['errors'][0]['message'] and 'intentional negative assertion' in result['errors'][0]['message'] and 'EXTENSION_CONTEXT_' not in result['errors'][0]['message'])
check('actual_config_and_trace_posture',failed['config']['version']=='1.62.0' and failed['config']['forbidOnly'] is True and all(p['retries']==0 and p['timeout']==30000 for p in failed['config']['projects']))
events=data('real-proof/owned-retirement-events.json');phases=[r['phase'] for r in events['events']]
check('real_context_close_and_owned_browser_close_both_resolve',phases==['fresh-launch','body-before-intentional-failure','context-close-start','disconnected','context-close-resolved','owned-browser-close-start','owned-browser-close-resolved'],phases)
check('captured_fresh_browser_connected_then_disconnected',events['events'][0]['ownedBrowserPresent'] is True and events['events'][0]['connected'] is True and events['events'][0]['profileExists'] is True and events['events'][-1]['connected'] is False)
owned=Path(events['profile'])
check('only_exact_observed_owned_profile_absence_checked',owned.name.startswith('japp-m02-w07-profile-') and not owned.exists(),str(owned))

retention=data('real-artifact-retention-result.json');before=retention['actual_failure_artifacts_before'];after=retention['after_three_sibling_cleanup_and_list']
check('all_five_actual_failure_artifacts_byte_identical',len(before)==5 and before==after and all(len(read('real-proof/'+name))==row['bytes'] and sha(read('real-proof/'+name))==row['sha256'] for name,row in before.items()))
check('actual_artifact_types_screenshots_error_context_trace',sum(name.endswith('.png') for name in before)==2 and sum(name.endswith('/trace.zip') for name in before)==1 and sum(name.endswith('/error-context.md') for name in before)==1 and 'test-results/browser/.last-run.json' in before)
proof_root=(packet/'real-proof').resolve()
expected_outputs=[]
for label,file,child in [('research','real-proof/later-research-report.json','public-research'),('contact','real-proof/later-contact-report.json','public-contact'),('visual','real-proof/later-visual-corrected-report.json','visual')]:
    report=data(file);rows=list(tests(report))
    dirs={Path(p['outputDir']).resolve() for p in report['config']['projects']}
    check('later_'+label+'_one_expected_synthetic_CLI_pass',report['stats']['expected']==1 and report['stats']['unexpected']==report['stats']['flaky']==report['stats']['skipped']==0 and len(rows)==1 and rows[0][1]['results'][0]['retry']==0)
    check('later_'+label+'_exact_same_root_output',dirs=={proof_root/'test-results'/child})
    expected_outputs.extend(dirs)
check('default_and_three_later_outputs_are_disjoint_siblings',{Path(p['outputDir']).resolve() for p in failed['config']['projects']}=={proof_root/'test-results/browser'} and len(set(expected_outputs))==3 and all(p.parent==proof_root/'test-results' for p in expected_outputs))
bad_visual=data('real-proof/later-visual-report.json')
check('wrong_cwd_visual_retained_excluded_and_corrected',all(not Path(p['outputDir']).resolve().is_relative_to(proof_root) for p in bad_visual['config']['projects']) and data('commands/24-later-visual/command.json')['cwd']!=str(packet/'real-proof') and Path(data('commands/26-later-visual-corrected-cwd/command.json')['cwd']).resolve()==proof_root)

trace_name=next(name for name in before if name.endswith('/trace.zip'))
trace_path=packet/'real-proof'/trace_name
actor_trace=[]
with zipfile.ZipFile(trace_path) as archive:
    infos=archive.infolist();names=[i.filename for i in infos]
    safe=all(not PurePosixPath(n).is_absolute() and all(p not in ('','..') for p in PurePosixPath(n).parts) and '\\' not in n for n in names)
    regular=all(not i.is_dir() and stat.S_IFMT(i.external_attr>>16) in [0,stat.S_IFREG] for i in infos)
    check('trace_zip_safe_regular_unique_and_all_crc_valid',safe and regular and len(names)==len(set(names)) and archive.testzip() is None,{'members':len(names),'sha256':sha(trace_path.read_bytes())})
    trace_lines=[json.loads(line) for n in names if n.endswith('.trace') for line in archive.read(n).decode().splitlines() if line]
    headers=[r for r in trace_lines if r.get('type')=='context-options' and r.get('origin')=='library']
    check('real_chromium_trace_exact_local_platform_context',len(headers)==1 and headers[0]['browserName']=='chromium' and headers[0]['playwrightVersion']=='1.62.0' and headers[0]['platform']=='darwin' and headers[0]['options']['userDataDir']==events['profile'],headers)
    actions=Counter(r.get('class','')+'.'+r.get('method','') for r in trace_lines if r.get('type')=='before' and r.get('class')!='')
    snapshots=sum(r.get('type')=='frame-snapshot' for r in trace_lines)
    check('trace_contains_actual_page_actions_and_DOM_snapshots',actions['BrowserContext.newPage']==1 and actions['Frame.goto']==1 and actions['Frame.expect']==1 and actions['Frame.title']==1 and snapshots>=1,{'actions':dict(actions),'frame_snapshots':snapshots})
    check('trace_contains_nonempty_network_and_no_fake_video_HAR',any(n.endswith('.network') and len(archive.read(n))>0 for n in names) and not any(n.endswith(('.webm','.har')) for n in names))
    resources=[archive.read(n) for n in names if n.startswith('resources/src@')]
    check('trace_embeds_exact_frozen_fixture_and_exact_failed_proof',read('source/e2e/extension/support/extension-test.ts') in resources and read('real-proof/failed-fixture.proof.ts') in resources)
    actor_trace={'sha256':sha(trace_path.read_bytes()),'members':len(names),'actions':dict(actions),'frame_snapshots':snapshots,'platform':headers[0]['platform'],'profile':events['profile']}
check('no_actual_video_or_HAR_files_claimed',not list((packet/'real-proof/test-results').rglob('*.webm')) and not list((packet/'real-proof/test-results').rglob('*.har')))

wd=data('wd-actual-report.json');wdtests=list(tests(wd));listing=data('wd-list.json');listed=list(tests(listing))
title='WD1–WD10/XATS: observed contradictory, single-signal, login, CAPTCHA and unknown surfaces pause without action'
check('exact_WD_discovery_and_execution_identity',len(listed)==len(wdtests)==1 and listed[0][0]['title']==wdtests[0][0]['title']==title and wdtests[0][0]['file']=='extension/extension-research.spec.ts')
wdr=wdtests[0][1]['results']
check('actual_WD_one_attempt_PASS_retry0_no_skips_or_errors',wd['stats']['expected']==1 and wd['stats']['unexpected']==wd['stats']['flaky']==wd['stats']['skipped']==0 and wd['errors']==[] and len(wdr)==1 and wdr[0]['status']=='passed' and wdr[0]['retry']==0 and wdr[0]['errors']==[],{'reported_test_result_duration_ms':wdr[0]['duration'],'whole_report_duration_ms':wd['stats']['duration'],'body_only_duration_measured':False})
wd_path='e2e/extension/extension-research.spec.ts'
current=read('source/'+wd_path)
original=None
with tarfile.open(packet/'base-source.tar','r:') as archive:
    for member in archive:
        if member.name.removeprefix('./')==wd_path:
            if not member.isfile():raise ValueError('BASE_WD_REGULAR_SOURCE_REQUIRED')
            original=archive.extractfile(member).read();break
check('entire_actual_WD_source_identical_to_original_base',original==current and sha(current)==base[wd_path]['sha256']==freeze['entries'][wd_path]['sha256'],{'path':wd_path,'bytes':len(current),'sha256':sha(current)})
closure=data('actors-closure.json')
check('observed_terminal_ports_free_and_children_returned',closure['all_browser_and_server_subprocess_invocations_returned'] is True and closure['no_background_job_spawned_by_wrapper'] is True and closure['own_fresh_profile_removed'] is True and all(r['port'] in [4761,4762] and r['exit_code']==1 and r['stdout']==r['stderr']=='' for r in closure['listener_ports']))
check('same_frozen_patch_and_source_manifest_still_exact',sha(read('candidate-v1.patch'))=='6fe044bc100ccf4e96b435ea7395a970af5361b569e6e00a6828bb4123c84ed5' and sha(read('source-freeze-v1.json'))=='650df4548f43c9161f4a368f37dd3c8622b7335d9803ce9c286f8405fe1a1d9a')

result={'scope':'INDEPENDENT_CLOSED_REAL_TRACE_AND_UNCHANGED_WD_REPLAY_DATA_REVIEW_NO_RERUN','status':'CLEAR' if all(r['pass'] for r in checks) else 'FINDING','checks_passed':sum(r['pass'] for r in checks),'checks_total':len(checks),'checks':checks,'actual_trace':actor_trace,'WD_reported_result_duration_ms':wdr[0]['duration'],'WD_body_only_timing_claimed':False,'native_Windows_validation':'NOT_PERFORMED_OR_CLAIMED','limits':['Actual intentional body failure checks trace/lifecycle preservation, not a reproduction of Windows sharing-lock failure.','Later sibling cleanup commands use actual pinned CLI with tiny synthetic tests; only failedfixture/WD run are real browser actors.','Wrong-cwd visual24 retained and excluded; corrected26 plus list27 completes same-root check.','Trace source/build identity is post-execution resource observation; no prelaunch full-runtime digest claim.','Terminal ports and ownedprofile absence are bounded observations, not an exhaustive OS descendant census.']}
(out/'actual-proof-findings.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'actual-proof-review-checker.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({k:result[k] for k in ['status','checks_passed','checks_total']}))
