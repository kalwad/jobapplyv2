"""Curate only finite immutable author records and sealed independent review."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import tarfile

packet = Path('/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019')
review = Path('/tmp/japp-m03-w03-windows-browser-cleanup-independent-review-20261019')
out = Path('/tmp/japp-m03-w03-windows-browser-cleanup-reviewed-retained-20261019')
if out.exists():
    raise RuntimeError('FRESH_RETAINED_OUTPUT_REQUIRED')
def sha(b):return hashlib.sha256(b).hexdigest()
selected={}
def add(name,path,expected=None):
    p=PurePosixPath(name)
    if p.is_absolute() or any(part in ('','.','..') for part in p.parts) or '\\' in name or name in selected:
        raise ValueError('UNSAFE_OR_DUPLICATE_MEMBER:'+name)
    if path.is_symlink() or not path.is_file():raise ValueError('REGULAR_FILE_REQUIRED:'+str(path))
    b=path.read_bytes()
    if expected and (len(b)!=expected['bytes'] or sha(b)!=expected['sha256']):
        raise ValueError('SELECTED_INPUT_DRIFT:'+str(path))
    selected[name]=b

manifest_bytes=(packet/'retention-manifest-v2.json').read_bytes()
if sha(manifest_bytes)!='b2624c3ae4a10d2b3ac9c6609fffe4d7267b19bd712c081d22ffe182497f4862':
    raise ValueError('AUTHOR_FINITE_MANIFEST_PIN_DRIFT')
author=json.loads(manifest_bytes)
if author['file_count']!=300 or author['total_bytes']!=18258751:
    raise ValueError('FINITE_AUTHOR_SCOPE_DRIFT')
for row in author['records']:add('candidate/'+row['path'],packet/row['path'],row)
add('candidate/retention-manifest-v2.json',packet/'retention-manifest-v2.json')
seal_bytes=(review/'review-member-manifest.json').read_bytes()
if sha(seal_bytes)!='0649c244f79975a2237cfeeae5a0c7126e348cb217dd7adfa7bff361939c3bb3':
    raise ValueError('REVIEW_SEAL_PIN_DRIFT')
seal=json.loads(seal_bytes)
for row in seal['files']:add('independent-review/'+row['path'],review/row['path'],row)
add('independent-review/review-member-manifest.json',review/'review-member-manifest.json')
add('retention-builder.py',Path(__file__))
records=[{'path':name,'bytes':len(b),'sha256':sha(b)} for name,b in sorted(selected.items())]
selected['retained-members.json']=(json.dumps({'self_excluded':'retained-members.json','files':records},indent=2)+'\n').encode()
out.mkdir()
archive=out/'proof.tar.gz'
with archive.open('wb') as stream:
    with gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w',format=tarfile.PAX_FORMAT) as tar:
            for name,b in sorted(selected.items()):
                info=tarfile.TarInfo(name);info.size=len(b);info.mtime=0;info.mode=0o644
                info.uid=info.gid=0;info.uname=info.gname=''
                tar.addfile(info,io.BytesIO(b))
files=[{'path':name,'bytes':len(b),'sha256':sha(b)} for name,b in sorted(selected.items())]
whole=archive.read_bytes()
outer={'archive_path':'proof.tar.gz','archive_sha256':sha(whole),'archive_bytes':len(whole),'regular_members':len(files),'files':files,'embedded_inventory':'retained-members.json','scope':'Finite local Windows-browser fixture repair source v1 and actual Mac actor/focused evidence plus independent review and exact root one-line annotation/full typecheck retry. Original REDs/setup/lint/portability failures, wrong-cwd visual24, strict mypyFAIL and reviewer projection correction preserved. Author300 records exact;368MB setup archive/dependencies/build/cache/privateGit excluded by reference. No native Windows acceptance, deeper cause, KI0108 closure, canonical full/Gate approval or actor rerun.','authority':'NONE'}
(out/'retention-manifest.json').write_text(json.dumps(outer,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers()
    if len(members)!=len(files) or len({m.name for m in members})!=len(files):raise ValueError('ARCHIVE_MEMBER_CLOSURE_FAILURE')
    for member in members:
        if not member.isfile() or tar.extractfile(member).read()!=selected[member.name]:raise ValueError('ARCHIVE_RAW_COPY_FAILURE')
(out/'report.md').write_bytes((review/'report.md').read_bytes())
(out/'summary.json').write_bytes((review/'summary.json').read_bytes())
print(json.dumps({'directory':str(out),'archive_sha256':outer['archive_sha256'],'archive_bytes':len(whole),'regular_members':len(files),'payload_bytes':sum(r['bytes'] for r in files),'manifest_sha256':sha((out/'retention-manifest.json').read_bytes())},indent=2))
