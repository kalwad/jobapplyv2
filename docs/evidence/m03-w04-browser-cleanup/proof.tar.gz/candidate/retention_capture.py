from pathlib import Path
import json,hashlib
out=Path(__file__).resolve().parent/'retention-cli-captures'; out.mkdir(exist_ok=True)
def pytest_runtest_setup(item):
 if item.name != 'test_artifact_path_matches_playwright_output_config': return
 module=item.module; original=module.run_bounded_process; count=0
 def capture(argv,**kwargs):
  nonlocal count
  count+=1; result=original(argv,**kwargs); p=out/f'{count:02}'; p.mkdir(exist_ok=False)
  (p/'stdout.json').write_text(result.stdout); (p/'stderr.log').write_text(result.stderr)
  (p/'command.json').write_text(json.dumps({'argv':argv,'cwd':str(kwargs['cwd']),'timeout_seconds':kwargs['timeout_seconds'],'returncode':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout.encode()).hexdigest()},indent=2)+'\n'); return result
 module.run_bounded_process=capture
