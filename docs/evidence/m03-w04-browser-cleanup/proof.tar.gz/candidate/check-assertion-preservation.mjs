import ts from './source/node_modules/typescript/lib/typescript.js';
import {readFileSync,writeFileSync} from 'node:fs';
const packet=new URL('./',import.meta.url);
function assertions(path) {
 const source=ts.createSourceFile(path,readFileSync(new URL(path,packet),'utf8'),ts.ScriptTarget.Latest,true);
 const rows=[]; function visit(node) { if(ts.isCallExpression(node)&&ts.isPropertyAccessExpression(node.expression)&&/^expect\(/.test(node.expression.getText(source))) rows.push(node.getText(source).replaceAll('rmSync','rm').replace(/\s+/g,'')); ts.forEachChild(node,visit); } visit(source); return rows;
}
const old=assertions('preimages/apps/extension/test/m02-w15/inherited-fixture-cleanup.test.ts'); const current=assertions('source/apps/extension/test/m02-w15/inherited-fixture-cleanup.test.ts');
const outcome={original_assertion_expressions:old.length,current_assertion_expressions:current.length,equal_after_only_rmSync_to_rm_and_format_normalization:JSON.stringify(old)===JSON.stringify(current),old,current};
writeFileSync(new URL('assertion-preservation.json',packet),JSON.stringify(outcome,null,2)+'\n'); if(!outcome.equal_after_only_rmSync_to_rm_and_format_normalization) process.exitCode=1;
console.log(JSON.stringify({original:old.length,current:current.length,equal:outcome.equal_after_only_rmSync_to_rm_and_format_normalization}));
