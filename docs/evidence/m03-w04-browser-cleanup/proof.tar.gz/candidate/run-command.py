import pathlib,subprocess,json,datetime,time,hashlib,os,sys
packet=pathlib.Path(__file__).resolve().parent; source=packet/'source'; name=sys.argv[1]; argv=sys.argv[2:]; command_cwd=source
if argv[:1]==['--cwd']: command_cwd=pathlib.Path(argv[1]); argv=argv[2:]
out=packet/'commands'/name; out.mkdir(parents=True,exist_ok=False)
base=json.loads((packet/'base-source-manifest.json').read_text()); paths=set(base)|{'apps/extension/test/m02-w15/owned-browser-retirement.test.ts'}
def snapshot():
 return {p:hashlib.sha256((source/p).read_bytes()).hexdigest() for p in sorted(paths) if (source/p).is_file()}
env=dict(os.environ); env['PATH']='/opt/homebrew/opt/node@24/bin:'+env['PATH']; env['UV_NO_SYNC']='1'; env['PYTHONDONTWRITEBYTECODE']='1'; env['CARGO_BUILD_JOBS']='2'
before=snapshot(); (out/'source-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n'); start=time.monotonic(); record={'utc_start':datetime.datetime.now(datetime.UTC).isoformat(),'argv':argv,'cwd':str(command_cwd),'environment':{k:env.get(k) for k in ['PATH','UV_NO_SYNC','PYTHONDONTWRITEBYTECODE','CARGO_BUILD_JOBS','PLAYWRIGHT_BROWSERS_PATH','NODE_OPTIONS','PLAYWRIGHT_JSON_OUTPUT_FILE','PYTHONPATH']}}
(out/'command.json').write_text(json.dumps(record,indent=2)+'\n')
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 try: r=subprocess.run(argv,cwd=command_cwd,env=env,stdout=stdout,stderr=stderr,timeout=360); record['exit_code']=r.returncode
 except subprocess.TimeoutExpired: record['exit_code']=None; record['timeout']=360
record['elapsed_seconds']=time.monotonic()-start; record['utc_end']=datetime.datetime.now(datetime.UTC).isoformat(); after=snapshot(); (out/'source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n'); record['source_unchanged']=before==after; record['stdout_sha256']=hashlib.sha256((out/'stdout.log').read_bytes()).hexdigest(); record['stderr_sha256']=hashlib.sha256((out/'stderr.log').read_bytes()).hexdigest(); (out/'completion.json').write_text(json.dumps(record,indent=2)+'\n'); print(json.dumps({k:record[k] for k in ["argv","exit_code","elapsed_seconds","source_unchanged"]})); sys.exit(0)
