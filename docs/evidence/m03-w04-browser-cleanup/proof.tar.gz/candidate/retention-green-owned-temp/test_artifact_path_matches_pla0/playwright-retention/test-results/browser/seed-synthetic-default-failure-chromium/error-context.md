# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: seed.spec.mjs >> synthetic default failure
- Location: synthetic/seed.spec.mjs:3:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "failure"
Received: "intentional negative fixture"
```

# Test source

```ts
  1 | import { test, expect } from "file:///private/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019/source/node_modules/%40playwright/test/index.mjs";
  2 | import { writeFileSync } from "node:fs";
  3 | test("synthetic default failure", async ({}, testInfo) => {
  4 |   writeFileSync(testInfo.outputPath("default-evidence.marker"), "original default failure artifact");
> 5 |   expect("intentional negative fixture").toBe("failure");
    |                                          ^ Error: expect(received).toBe(expected) // Object.is equality
  6 | });
  7 | 
```