import { test, expect } from "file:///private/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019/source/node_modules/%40playwright/test/index.mjs";
import { writeFileSync } from "node:fs";
test("synthetic default failure", async ({}, testInfo) => {
  writeFileSync(testInfo.outputPath("default-evidence.marker"), "original default failure artifact");
  expect("intentional negative fixture").toBe("failure");
});
