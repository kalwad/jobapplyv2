import { test } from "file:///private/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019/source/node_modules/%40playwright/test/index.mjs";
test("synthetic controlled pass", () => {});
