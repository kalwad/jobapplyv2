import original from "/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019/source/e2e/extension/public-contact/playwright.config.ts";
export default { ...original, testDir: "/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019/real-proof/synthetic", testMatch: "*.spec.mjs", globalSetup: undefined, webServer: undefined, reporter: [["json"]] };
