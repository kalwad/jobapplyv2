import original from "/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019/source/playwright.config.ts";
export default {
  ...original,
  testDir: "/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019/real-proof",
  testMatch: "*.proof.ts",
  globalSetup: "/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019/source/e2e/extension/support/global-setup.ts",
  webServer: original.webServer.map(server => ({ ...server, cwd: "/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019/source" })),
  reporter: [["json"]],
};
