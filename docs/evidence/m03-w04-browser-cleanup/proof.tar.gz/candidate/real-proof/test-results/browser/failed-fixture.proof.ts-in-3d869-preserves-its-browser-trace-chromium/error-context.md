# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: failed-fixture.proof.ts >> intentional failed real fixture preserves its browser trace
- Location: ../real-proof/failed-fixture.proof.ts:32:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "intentional negative assertion"
Received: "REAL_FIXTURE_BODY_ERROR_RETAINED"
```

# Test source

```ts
  1  | import { chromium } from "/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019/source/node_modules/@playwright/test/index.mjs";
  2  | import { existsSync, writeFileSync } from "node:fs";
  3  | import { test, expect, LAB_ORIGIN } from "/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019/source/e2e/extension/support/extension-test.ts";
  4  | const evidencePath = "/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019/real-proof/owned-retirement-events.json";
  5  | const evidence: { profile?: string; events: unknown[] } = { events: [] };
  6  | const record = (event: unknown) => { evidence.events.push(event); writeFileSync(evidencePath, JSON.stringify(evidence, null, 2)); };
  7  | // Evidence-only wrappers delegate to the exact public methods on the newly
  8  | // launched owner. No private SDK APIs, error matching, or user profile access.
  9  | const launch = chromium.launchPersistentContext.bind(chromium);
  10 | chromium.launchPersistentContext = async (...args) => {
  11 |   const context = await launch(...args);
  12 |   evidence.profile = String(args[0]);
  13 |   const browser = context.browser();
  14 |   record({ phase: "fresh-launch", ownedBrowserPresent: browser !== null, connected: browser?.isConnected(), profileExists: existsSync(evidence.profile) });
  15 |   browser?.on("disconnected", () => record({ phase: "disconnected", connected: browser.isConnected() }));
  16 |   const closeContext = context.close.bind(context);
  17 |   context.close = async (...options) => {
  18 |     record({ phase: "context-close-start", connected: browser?.isConnected() });
  19 |     try { await closeContext(...options); record({ phase: "context-close-resolved" }); }
  20 |     catch (error) { record({ phase: "context-close-rejected", error: String(error) }); throw error; }
  21 |   };
  22 |   if (browser) {
  23 |     const closeBrowser = browser.close.bind(browser);
  24 |     browser.close = async (...options) => {
  25 |       record({ phase: "owned-browser-close-start", connected: browser.isConnected() });
  26 |       try { await closeBrowser(...options); record({ phase: "owned-browser-close-resolved", connected: browser.isConnected() }); }
  27 |       catch (error) { record({ phase: "owned-browser-close-rejected", connected: browser.isConnected(), error: String(error) }); throw error; }
  28 |     };
  29 |   }
  30 |   return context;
  31 | };
  32 | test("intentional failed real fixture preserves its browser trace", async ({ extensionContext }) => {
  33 |   const page = await extensionContext.newPage();
  34 |   await page.goto(`${LAB_ORIGIN}/native/`);
  35 |   await expect(page.locator("body")).toBeVisible();
  36 |   record({ phase: "body-before-intentional-failure", title: await page.title() });
> 37 |   expect("REAL_FIXTURE_BODY_ERROR_RETAINED").toBe("intentional negative assertion");
     |                                              ^ Error: expect(received).toBe(expected) // Object.is equality
  38 | });
  39 | 
```