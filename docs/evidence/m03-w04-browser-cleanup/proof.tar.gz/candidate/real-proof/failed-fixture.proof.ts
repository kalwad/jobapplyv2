import { chromium } from "/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019/source/node_modules/@playwright/test/index.mjs";
import { existsSync, writeFileSync } from "node:fs";
import { test, expect, LAB_ORIGIN } from "/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019/source/e2e/extension/support/extension-test.ts";
const evidencePath = "/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019/real-proof/owned-retirement-events.json";
const evidence: { profile?: string; events: unknown[] } = { events: [] };
const record = (event: unknown) => { evidence.events.push(event); writeFileSync(evidencePath, JSON.stringify(evidence, null, 2)); };
// Evidence-only wrappers delegate to the exact public methods on the newly
// launched owner. No private SDK APIs, error matching, or user profile access.
const launch = chromium.launchPersistentContext.bind(chromium);
chromium.launchPersistentContext = async (...args) => {
  const context = await launch(...args);
  evidence.profile = String(args[0]);
  const browser = context.browser();
  record({ phase: "fresh-launch", ownedBrowserPresent: browser !== null, connected: browser?.isConnected(), profileExists: existsSync(evidence.profile) });
  browser?.on("disconnected", () => record({ phase: "disconnected", connected: browser.isConnected() }));
  const closeContext = context.close.bind(context);
  context.close = async (...options) => {
    record({ phase: "context-close-start", connected: browser?.isConnected() });
    try { await closeContext(...options); record({ phase: "context-close-resolved" }); }
    catch (error) { record({ phase: "context-close-rejected", error: String(error) }); throw error; }
  };
  if (browser) {
    const closeBrowser = browser.close.bind(browser);
    browser.close = async (...options) => {
      record({ phase: "owned-browser-close-start", connected: browser.isConnected() });
      try { await closeBrowser(...options); record({ phase: "owned-browser-close-resolved", connected: browser.isConnected() }); }
      catch (error) { record({ phase: "owned-browser-close-rejected", connected: browser.isConnected(), error: String(error) }); throw error; }
    };
  }
  return context;
};
test("intentional failed real fixture preserves its browser trace", async ({ extensionContext }) => {
  const page = await extensionContext.newPage();
  await page.goto(`${LAB_ORIGIN}/native/`);
  await expect(page.locator("body")).toBeVisible();
  record({ phase: "body-before-intentional-failure", title: await page.title() });
  expect("REAL_FIXTURE_BODY_ERROR_RETAINED").toBe("intentional negative assertion");
});
