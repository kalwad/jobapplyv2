import { test } from "/tmp/japp-m03-w03-windows-browser-cleanup-candidate-20261019/source/node_modules/@playwright/test/index.mjs";
test("later sibling output cleanup", () => {});
