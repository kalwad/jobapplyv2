# Outside Windows cleanup/artifact candidate — local proof complete

The seven-path patch is `candidate-v1.patch`, SHA-256
`6fe044bc100ccf4e96b435ea7395a970af5361b569e6e00a6828bb4123c84ed5`.
`source-freeze-v1.json` binds 1823 paths from immutable committed
c5766246f8b81f32fbfb2eebbacb96c0ba9f5307: 1816 old paths unchanged,
six modified old paths and one added regression module. `final-source/` retains
exact final affected bytes. Parent owns all canonical integration; the candidate
uses only an outside private Git index/refs and owned dependency/venv copies.
The six canonical affected preimages still matched at the final read observation.
Root W04 work is concurrent; no globally clean/unchanged root claim is made.

The fixture keeps Context.close first for its instrumentation and preserves EVERY
Context.close rejection, including the old canonical TargetClosed. It then closes
the captured exact owned Browser and awaits terminal disconnect on successful
close, and finally awaits fs.promises.rm with original 10 retries/100ms settings.
Unexpected pre-cleanup disconnection, missing owner, generic close/removal errors
and original primary/nested aggregate ordering remain explicit failures.
No error classifier/probe, private SDK API, newPage-after-close, retries, deadline
increase, global process kill or profile workaround is added.

Actual validation: original unchanged28 PASS; tests-first16 discovered, selected10
behavioral regressions FAIL and6 unselected; final44/44 PASS including all16 new.
All39 original assertion expressions are preserved after only rmSync→rm and
format normalization. Final Python contract checks355 PASS, with the existing
retention case separately PASS. Typecheck, ESLint, Ruff, formatting, portability
and diff checks PASS. The expected two REDs and actual initial setup/lint failures
remain raw in commands; summary.json identifies their corrected reruns.

The real negative fixture actually failed exactly its intended original assertion
(exit1). Its Context.close resolved; actual owned Browser disconnected/close
resolved and its freshly recorded profile was removed. Its trace.zip contains
library-origin Chromium context data, network data, four DOM frame snapshots and
resource bytes; screenshots and error-context are retained. No video or HAR was
emitted or claimed. All five failure files survived later actual controlled
sibling cleanup, corrected same-root visual cleanup and subsequent --list byte
exact. Initial visual command24 used source cwd, placing output outside the proof
root; that observation is retained and excluded. Corrected26/27 bind the claim.

The unchanged original WD case was discovered exactly once at line585 and passed
once, retry0. Its reporter TestResult.duration was1132ms for the reported CASE,
including fixture/case work; no separate body timing is claimed. A prior progress
message called that body time: this is the explicit correction.

All actual actor scopes returned; recorded terminal event/close and profile result,
empty final scoped-process observation and released4761/4762 listeners establish
the replay window is released. No further actors, tests or mutations are planned.

This is finite local Mac fixture/artifact evidence, not a canonical/full project
or hosted Windows PASS. KI0108 still requires actual Windows revalidation. The old
Windows cause is not explained or normalized; original missing trace bytes remain
missing in the official frozen packet. Selected runtime sources, versions, owned
reanchors, exact outer commands, raw outputs and before/after source identities
are retained; complete dependencies/browser executable images were not imaged
upfront. Post-execution trace bytes are not served-input identity evidence.

`retention-manifest.json` covers this finite packet and affected source copies.
Owned full dependencies, venv, generated builds/caches/private Git are excluded
and represented by explicit references; no900MB dependency packet is recreated.

## Finite retention metadata correction

The first manifest inadvertently included the complete368,537,600-byte Git
extraction archive used during setup. No additional copy of that archive is
needed for review: its identity remains in preparation.json and the original
v1 manifest, while immutable c576 Git objects are the source reference.
The authoritative finite review set is retention-manifest-v2.json, which
excludes that archive as well as owned dependencies/build/cache/private Git.
Original v1 metadata and all source, command, failure and artifact bytes remain
unchanged. This is a retention-scope correction only; no validation/actor rerun,
source mutation or new acceptance claim occurred after the original seal.
