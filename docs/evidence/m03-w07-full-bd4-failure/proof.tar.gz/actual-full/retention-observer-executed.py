from pathlib import Path
import datetime
import hashlib
import json
import shutil
import stat

E=Path(__file__).parent
F=E/'full-bd4cffd'
S=Path('/Users/tanishkalwad/jobapplyv2/test-results/visual')
D=F/'retained-visual'
P=E/'full-f5a05ba/retained-visual'
log=(F/'verify.log').read_text()
assert '17 passed' in log and '$ uv run pytest -c pyproject.toml' in log
assert not (F/'closure.json').exists()
D.mkdir()
def record(path,base):
    info=path.lstat();assert stat.S_ISREG(info.st_mode)
    body=path.read_bytes()
    return {'path':path.relative_to(base).as_posix(),'bytes':len(body),'mode':stat.S_IMODE(info.st_mode),'sha256':hashlib.sha256(body).hexdigest()}
paths=[]
for path in sorted(S.rglob('*')):
    if path.is_dir() and not path.is_symlink():continue
    paths.append(path)
all_rows=[record(p,S) for p in paths]
chosen=[p for p in paths if 'attachments' not in p.relative_to(S).parts and p.relative_to(S).as_posix()!='.last-run.json']
assert len(paths)==67 and len(chosen)==33
assert sum(p.suffix=='.png' for p in chosen)==19 and sum(p.suffix=='.json' for p in chosen)==14
rows=[record(p,S) for p in chosen]
hashes={r['sha256'] for r in rows}
excluded=[record(p,S) for p in paths if p not in chosen]
aliases=[r for r in excluded if 'attachments' in Path(r['path']).parts]
assert len(aliases)==33 and all(r['sha256'] in hashes for r in aliases)
for source,r in zip(chosen,rows,strict=True):
    dest=D/r['path'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
    assert record(dest,D)==r and record(source,S)==r
assert [record(p,S) for p in paths]==all_rows
png=[]
for r in rows:
    if Path(r['path']).suffix!='.png':continue
    prior=P/r['path'];assert prior.is_file()
    png.append({'path':r['path'],'equal_prior':prior.read_bytes()==(D/r['path']).read_bytes()})
assert len(png)==19
summary={'observed_utc':datetime.datetime.now(datetime.UTC).isoformat(),'aggregate_state_at_retention':'RUNNING; actual visual17PASS and Pythonexecution begun; no finalaggregateoutcome','context':json.loads((F/'context.json').read_text()),'original_output_root':str(S),'all_original_files':all_rows,'selected_files':rows,'excluded_original_files':excluded,'selected_count':33,'png':19,'metadata':14,'unique_bodies':len(hashes),'excluded_attachment_aliases_are_exact_duplicate_bodies':True,'all_selected_original_retained_bytes_fullmodes_join':True,'prior_png_comparisons':png,'all_png_equal_prior':all(r['equal_prior'] for r in png),'executed_observer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(D/'retention.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
(F/'retention-observer-executed.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'retained':len(rows),'png':19,'metadata':14,'all_png_equal_prior':summary['all_png_equal_prior'],'manifest_sha256':hashlib.sha256((D/'retention.json').read_bytes()).hexdigest()}))
