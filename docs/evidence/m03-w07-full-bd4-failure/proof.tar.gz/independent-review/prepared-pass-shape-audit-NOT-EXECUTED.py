"""Independent bd4 retained-data review. No subject actors; wait for actual closure."""
from pathlib import Path
import collections,datetime,hashlib,json,os,re,shlex,stat,struct,subprocess
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');P=E/'full-bd4cffd';OUT=Path(__file__).parent;ROOT=Path('/Users/tanishkalwad/jobapplyv2');HEAD='bd4cffd7f61f99f77520e7dc522f852488cdd9d3';TREE='75d79ae7fc14e9a02c1f326e5376b16d74a7736e';rows=[]
def ck(n,v,d=None):rows.append({'name':n,'pass':bool(v),'detail':d})
def doc(p):return json.loads(p.read_bytes())
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode);b=p.read_bytes();z=p.lstat();assert (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_mode)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns,z.st_mode) and len(b)==a.st_size
 return {'bytes':len(b),'mode':stat.S_IMODE(a.st_mode),'sha256':hashlib.sha256(b).hexdigest()}
assert (P/'closure.json').is_file() and (P/'after.json').is_file() and (P/'end-context.json').is_file(), 'Actual full closure required; no incomplete PASS'
initial={str(q.relative_to(P)):pin(q) for q in sorted(P.rglob('*')) if q.is_file()}
before,after=doc(P/'before.json'),doc(P/'after.json');ctx,end=doc(P/'context.json'),doc(P/'end-context.json');closure=doc(P/'closure.json');results=doc(P/'results.json')
ck('source2294',len(before['source'])==len(after['source'])==2294);ck('runtime40',len(before['runtime'])==len(after['runtime'])==40);ck('all_snapshot_equal',before==after)
for n,r in before['source'].items():ck('source_endpoint:'+n,r==after['source'].get(n))
for n,r in before['runtime'].items():ck('runtime_endpoint:'+n,r==after['runtime'].get(n))
ck('clean_status_endpoints',before['git_status']==after['git_status']=='')
ck('context_heads',ctx['commit']==end['commit']==HEAD and ctx['tree']==end['tree']==TREE)
ck('closure_all_true',all(closure[k] is True for k in ('source_bytes_modes_unchanged','runtime_bytes_modes_unchanged','commit_and_tree_equal_at_end_observation','all_commands_exit_zero')))
ck('context_time_order',datetime.datetime.fromisoformat(ctx['start_utc'])<datetime.datetime.fromisoformat(end['observed_utc'])<=datetime.datetime.fromisoformat(closure['end_utc']))
ck('exact_outer_commands',[r['argv'] for r in results]==[['pnpm','run','doctor'],['pnpm','verify']])
for r in results:ck('closed:'+r['name'],r['exit_code']==0 and r['timeout'] is False and r['direct_child_reaped'] is True and r['observed_group']=='ABSENT' and r['outer_cleanup_signals']==[])
ck('outer_elapsed_within_actual_budgets',0<results[0]['seconds']<180 and 0<results[1]['seconds']<2700)
wrapper=(P/'wrapper-executed.py').read_text();ck('explicit_end_pointer_observation',"(OUT / 'end-context.json')" in wrapper and "['git', 'rev-parse', 'HEAD^{tree}']" in wrapper)
# Reuse this reviewer's actual immutable local Git2294 body stream from the collector preparation.
# Its complete framed SHA1/size/SHA256 result is independent of the root full-run observer.
collector_map=doc(E/'ci-bd4cffd-immutable-git-source-sha256.json');observed=collector_map['files']
ck('immutable_body_map_exact_published_pin',pin(E/'ci-bd4cffd-immutable-git-source-sha256.json')['sha256']=='b80b386f8b3dc610548e06f5ce27befc87644758454dbc86805e98cc89a48f6c')
ck('immutable_exact2294_paths',collector_map['commit']==HEAD and collector_map['tree']==TREE and collector_map['blob_count']==2294 and len(observed)==2294 and set(observed)==set(before['source']))
ck('immutable_all_framing_and_custody',collector_map['all_git_blob_SHA1_framings_verified'] and collector_map['git_batch_custody']['reaped'] is True and collector_map['git_batch_custody']['exit_code']==0 and collector_map['git_batch_custody']['group_after_wait']=='ABSENT' and not collector_map['git_batch_custody']['signals'])
for n,row in observed.items():
 snapshot=before['source'][n];ck('immutable_body:'+n,snapshot['bytes']==row['bytes'] and snapshot['sha256']==row['sha256']);ck('immutable_execute_class:'+n,bool(snapshot['mode']&0o111)==(row['git_mode']=='100755'))
inventory_bytes=(E/'windows11-param-id-composition-v2/after-inventory.json').read_bytes();registry_bytes=(E/'windows11-native-vm-preparation/v2/after/scripts/verification-suites.json').read_bytes()
for name,body in [('scripts/python-test-inventory.v1.json',inventory_bytes),('scripts/verification-suites.json',registry_bytes)]:ck('immutable_metadata_body:'+name,len(body)==observed[name]['bytes'] and hashlib.sha256(body).hexdigest()==observed[name]['sha256'])
inventory=json.loads(inventory_bytes)
(OUT/'immutable-source-joins.json').write_text(json.dumps({'commit':HEAD,'tree':TREE,'scope':'Actual immutable local Git2294 bodies and encoded executable classes from this reviewer earlier bounded stream, reused without later worktree reads','files':observed,'git_batch_custody':collector_map['git_batch_custody']},indent=2)+'\n')
# Bind the unchanged staged payload to earlier separately reviewed endpoints.
for earlier in ('full-80e68ac','full-9872aca'):
 prior=doc(E/earlier/'before.json')['runtime'];ck('runtime_baseline:'+earlier,prior==before['runtime'])
package=doc(E/'mac-package-refreshed/app-build-before.json');ck('runtime_package_binding',package['runtime']==before['runtime'])
ck('runtime_manifest',before['runtime']['manifest.json']['sha256']=='ad2c977971924201a3d1eb7b8c6631db2c8739831f5fe131f2448e0b7914abd9')
ck('runtime_size',sum(r['bytes'] for r in before['runtime'].values())==29903346)
# Parse actual logs, not fixture strings echoed during tests.
log=(P/'verify.log').read_text();lines=log.splitlines();doctor=(P/'doctor.log').read_text();ck('doctor28',bool(re.search(r'^summary: 28 pass, 0 warning, 0 fail, 0 not-yet-applicable$',doctor,re.M)))
summary=log.split('== verification summary ==')[-1];suite_rows=[m.groups() for m in re.finditer(r'^([a-z0-9-]+)\s+(ACTIVE)\s+(PASS)\s*$',summary,re.M)]
expected_suites=['toolchain','format','lint','typecheck','unit-ts','contract-gen','fixture-corpus','evaluation-corpus','contract','build','e2e-browser','w14-public-controlled','w14-public-contact-controlled','visual','python','rust','portability','traceability','status','integrity'];ck('20_active_pass',[r[0] for r in suite_rows]==expected_suites and 'verification exit code: 0' in summary)
collect_index=next(i for i,r in enumerate(lines) if r.startswith('$ uv run pytest ') and '--collect-only' in r);collect_end=next(i for i in range(collect_index+1,len(lines)) if lines[i].startswith('2624 tests collected'))
collected=[r for r in lines[collect_index+1:collect_end] if re.match(r'^(scripts|services|packages)/.+::',r)];ck('2624_collection',len(collected)==len(set(collected))==2624)
expected=sorted(inventory['common']['node_ids']+inventory['posix_only_node_ids']);ck('collection_catalog',sorted(collected)==expected and inventory['common']['count']==2622 and len(inventory['posix_only_node_ids'])==2)
collected_digest=hashlib.sha256(('\n'.join(sorted(collected))+'\n').encode()).hexdigest();ck('collection_digest_matches_immutable_catalog',collected_digest==hashlib.sha256(('\n'.join(expected)+'\n').encode()).hexdigest())
execution_index=next(i for i in range(collect_end+1,len(lines)) if lines[i].startswith('$ uv run pytest ') and '--collect-only' not in lines[i]);cargs=shlex.split(lines[collect_index][2:]);eargs=shlex.split(lines[execution_index][2:]);ck('execution_same_argv',[s for s in cargs if s not in ('--collect-only','-q')]==eargs)
python_actual_summaries=re.findall(r'^=+ (2624 passed in [^\n]+?) =+$',log,re.M);ck('2624_actual_pass',len(python_actual_summaries)==1)
# Fresh TypeScript unit tasks: exclude other later focused suites and cached typechecking.
start=log.index('$ pnpm exec turbo run test --force --concurrency=2 -- --reporter=default');stop=log.index('$ pnpm exec turbo run build --force');ts=log[start:stop];counts=re.findall(r'^(@japp/[^:]+):test:\s+Tests\s+([0-9]+) passed \(\2\)\s*$',ts,re.M)
ck('ts15_4006',len(counts)==len({n for n,_ in counts})==15 and sum(int(c) for _,c in counts)==4006);ck('ts_zero_cached','Cached:    0 cached, 15 total' in ts)
browser_summaries={n:[r.strip() for r in lines if re.fullmatch(r'\s*'+str(n)+r' passed \([^\n]+\)',r)] for n in [278,2,62,17]};ck('browser_actual278_2_62_17',all(len(v)==1 for v in browser_summaries.values()))
# Exact native test sets per executed feature argv, plus separate unit/contract.
feature_args=['$ cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml','$ cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml --all-features','$ cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml --features tauri/custom-protocol'];native=[]
for command in feature_args:
 i=lines.index(command);j=next((n for n in range(i+1,len(lines)) if lines[n].startswith('$ ')),len(lines));section=lines[i+1:j];cases=re.findall(r'^test (.+) \.\.\. ok$', '\n'.join(section),re.M);native.append(set(cases));ck('native342:'+command,len(cases)==len(set(cases))==342 and any('test result: ok. 342 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in r for r in section))
ck('same342_three_modes',native[0]==native[1]==native[2]);ck('separate_native1','test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in log);ck('separate_contract10','test result: ok. 10 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in log)
# Finite stable visual retention, with explicit duplicate aliases and prior captures.
ret=P/'retained-visual';r=doc(ret/'retention.json');ck('retention_pin',pin(ret/'retention.json')['sha256']==hashlib.sha256((ret/'retention.json').read_bytes()).hexdigest());ck('retention_context',r['context']==ctx)
ck('retention_counts',r['selected_count']==33 and r['png']==19 and r['metadata']==14 and r['unique_bodies']==29 and len(r['selected_files'])==33 and len(r['excluded_original_files'])==34)
bodycounts=collections.Counter();selected={q['path']:q for q in r['selected_files']};pngs=[]
for q in r['selected_files']:
 n=q['path'];ck('retained_visual:'+n,pin(ret/n)=={k:q[k] for k in ('bytes','mode','sha256')});bodycounts[q['sha256']]+=1
 if n.endswith('.png'):
  b=(ret/n).read_bytes();ck('PNG_signature:'+n,b[:8]==b'\x89PNG\r\n\x1a\n' and b[12:16]==b'IHDR');pngs.append(n);ck('prior2ea_png:'+n,pin(E/'full-2ea0fde/retained-visual'/n)['sha256']==q['sha256'])
ck('29unique_bodies',len(bodycounts)==29);ck('PNG19',len(pngs)==19)
ck('retained_exact_file_set',{str(q.relative_to(ret)) for q in ret.rglob('*') if q.is_file()}==set(selected)|{'retention.json'})
aliases=[q for q in r['excluded_original_files'] if '/attachments/' in q['path']];marker=[q for q in r['excluded_original_files'] if q['path']=='.last-run.json'];ck('excluded_shape',len(aliases)==33 and len(marker)==1)
for q in aliases:
 directory=q['path'].split('/attachments/')[0];matches=[s for n,s in selected.items() if str(Path(n).parent)==directory and all(s[k]==q[k] for k in ('bytes','mode','sha256'))];ck('exact_alias_body:'+q['path'],len(matches)==1)
ck('full67_inventory',len(set(selected)|{q['path'] for q in r['excluded_original_files']})==67 and {q['path']:q for q in r['all_original_files']}=={q['path']:q for q in r['selected_files']+r['excluded_original_files']})
ck('observer_exact_body',pin(P/'retention-observer-executed.py')['sha256']==r['executed_observer_sha256'])
watch=doc(OUT/'visual-watch-records/watch-bd4-visual-v1.json');watch_stdout=doc(OUT/'visual-watch-records/watch-bd4-visual-v1.stdout');ck('visual_watch_actual_child_closed0',watch['outcome']=='RETAINED' and watch['exit_code']==0 and watch['direct_child_reaped'] is True and pin(OUT/'visual-watch-records/watch-bd4-visual-v1.stderr')['bytes']==0)
ck('visual_watch_retention_body_and_counts',pin(OUT/'visual-watch-records/retain-bd4-visual-v1.py')['sha256']==r['executed_observer_sha256'] and watch_stdout['retained']==33 and watch_stdout['png']==19 and watch_stdout['metadata']==14 and watch_stdout['manifest_sha256']==pin(ret/'retention.json')['sha256'])
ck('visual_watch_timing_and_honest_wait',datetime.datetime.fromisoformat(ctx['start_utc'])<datetime.datetime.fromisoformat(watch['start_utc'])<datetime.datetime.fromisoformat(r['observed_utc'])<=datetime.datetime.fromisoformat(watch['end_utc'])<datetime.datetime.fromisoformat(end['observed_utc']) and watch['seconds']<2700)

ck('all19_prior_records',r['all_png_equal_prior'] is True and len(r['prior_png_comparisons'])==19 and all(q['equal_prior'] is True for q in r['prior_png_comparisons']) and {q['path'] for q in r['prior_png_comparisons']}==set(pngs))
ck('retention_not_backdated',r['aggregate_state_at_retention'].startswith('RUNNING;') and datetime.datetime.fromisoformat(ctx['start_utc'])<datetime.datetime.fromisoformat(r['observed_utc'])<datetime.datetime.fromisoformat(end['observed_utc']))
registry=json.loads(registry_bytes)
ck('all20_summary_exact_immutable_registry',[r[0] for r in suite_rows]==[s['id'] for s in registry['suites']])
command_lines=[(i,shlex.split(line[2:])) for i,line in enumerate(lines) if line.startswith('$ ')]
cursor=-1;suite_command_joins=[]
def strip_canonical_config(args):
 result=[];i=0
 while i<len(args):
  if args[i] in ('--config','--config-file') and i+1<len(args) and args[i+1]=='pyproject.toml':i+=2
  else:result.append(args[i]);i+=1
 return result
for suite in registry['suites']:
 observed_commands=[]
 for declared in suite['commands']:
  candidates=[]
  for index,args in command_lines:
   if index<=cursor:continue
   actual=strip_canonical_config(args) if suite['id']=='python' else args
   matches=(actual[:len(declared)]==declared)
   if matches:candidates.append((index,args))
  ck('normal_registry_command:'+suite['id']+':'+str(len(observed_commands)),bool(candidates),{'declared':declared,'observed':candidates[0][1] if candidates else None})
  if candidates:cursor=candidates[0][0];observed_commands.append(candidates[0][1])
 suite_command_joins.append({'id':suite['id'],'declared_commands':len(suite['commands']),'observed_commands':observed_commands,'proofs':suite['proofs'],'builtin':suite.get('builtin')})
ck('toolchain_six_actual_commands',all(any(args==expected for _,args in command_lines) for expected in [['node','--version'],['pnpm','--version'],['uv','run','python','--version'],['uv','--version'],['rustup','show','active-toolchain'],['cargo','--version']]))
integrity_start=lines.index('$ git ls-files')
integrity_end=lines.index('== verification summary ==')
integrity_paths=[line for line in lines[integrity_start+1:integrity_end] if line.strip()]
ck('integrity_actual2294_listing_exact_source_paths',len(integrity_paths)==2294 and set(integrity_paths)==set(before['source']))
strict_prefix=['uv','run','pytest','-c','pyproject.toml','--rootdir=.','--confcutdir=.','-o','addopts=','-ra','--strict-markers','--strict-config','--disable-plugin-autoload','--collect-only','-q']
ck('Python_canonical_strict_collection_prefix_and_exact_file_set',cargs[:len(strict_prefix)]==strict_prefix and cargs[len(strict_prefix):]==sorted({n.split('::',1)[0] for n in collected}))
old_inventory=doc(E/'ci-f5a05ba/actual-source-python-inventory.json');mapping=doc(E/'windows-pytest-param-id-preparation/v1/id-mapping.json');old_mapped=(set(old_inventory['common']['node_ids'])-{mapping['old_id']})|{mapping['new_id']};added_ids=set(inventory['common']['node_ids'])-old_mapped
new147=[l for l in (E/'windows11-native-vm-preparation/v2/pure-actual-v2/07-exact-collection.stdout').read_text().splitlines() if l.startswith('scripts/tests/') and '::' in l]
ck('all_prior2477_one_exact_ID_mapping_plus147',old_mapped<=set(inventory['common']['node_ids']) and old_inventory['posix_only_node_ids']==inventory['posix_only_node_ids'] and len(added_ids)==147 and added_ids==set(new147))
ck('no_prior2255_source_path_dropped',set(doc(E/'ci-f5a05ba/immutable-git-source-sha256.json')['files'])<=set(observed))
def between(first,last):return log[log.index(first):log.index(last,log.index(first)+len(first))]
typecheck_section=between('$ pnpm exec turbo run typecheck\n','$ pnpm exec tsc -p tsconfig.json');typecheck_cache=re.findall(r'Cached:\s+(\d+) cached, 15 total',typecheck_section);ck('normal_typecheck15_success_cache_disclosed','Tasks:    15 successful, 15 total' in typecheck_section and len(typecheck_cache)==1)
ck('normal_fixture_exact165_and_evaluation218_proofs',sum(int(n) for n in re.findall(r'^\s+Tests\s+(\d+) passed',between('$ pnpm --filter @japp/test-fixtures exec vitest run test/m02-w01','$ pnpm --filter @japp/evaluation-corpus corpus:check'),re.M))==165 and bool(re.search(r'^\s+Tests\s+218 passed',between('$ pnpm --filter @japp/evaluation-corpus test','$ pnpm --filter @japp/contracts exec vitest run test/contract'),re.M)))
ck('normal_contract745_and_build3_task_proofs',bool(re.search(r'^\s+Tests\s+745 passed',between('$ pnpm --filter @japp/contracts exec vitest run test/contract','$ pnpm exec turbo run build --force'),re.M)) and 'Tasks:    3 successful, 3 total' in between('$ pnpm exec turbo run build --force\n','$ pnpm exec playwright test\n'))
browser_identity_sets={}
for label,run_command,list_command,count in [
 ('browser','$ pnpm exec playwright test\n','$ pnpm exec playwright test --list',278),
 ('public','$ pnpm exec playwright test --config e2e/extension/public-research/playwright.config.ts\n','$ pnpm exec playwright test --config e2e/extension/public-research/playwright.config.ts --list',2),
 ('contact','$ pnpm exec playwright test --config e2e/extension/public-contact/playwright.config.ts --reporter=list,json\n','$ pnpm exec playwright test --config e2e/extension/public-contact/playwright.config.ts --reporter=list,json --list',62),
 ('visual','$ pnpm exec playwright test e2e/visual --output test-results/visual\n','$ pnpm exec playwright test e2e/visual --output test-results/visual --list',17)]:
 i=log.index(run_command);j=log.index(list_command,i+len(run_command));k=log.find('\n$ ',j+len(list_command));k=len(log) if k<0 else k
 executed=re.findall(r'^  [✓✔]\s+\d+ (?:\[.*?\] › )?(?:e2e/)?(.+:\d+:\d+ › .+) \([\d.]+(?:ms|s|m)\)$',log[i:j],re.M)
 listed=re.findall(r'^  (?:\[.*?\] › )?(.+:\d+:\d+ › .+)$',log[j:k],re.M)
 if label in ('public','contact'):
  # Normalize the location prefix only; test titles can themselves contain '/'.
  executed=[value.split(':',1)[0].rsplit('/',1)[-1]+':'+value.split(':',1)[1] for value in executed]
 ck('normal_discovery_identity_proof:'+label,len(executed)==len(set(executed))==len(listed)==len(set(listed))==count and set(executed)==set(listed))
 browser_identity_sets[label]=executed
ck('normal_W14_pure_scope4_contact2_proofs',bool(re.search(r'^\s+Tests\s+4 passed',between('$ pnpm --filter @japp/extension exec vitest run test/m02-w14/public-inspection/scope.test.ts','$ pnpm --filter @japp/extension build\n'),re.M)) and bool(re.search(r'^\s+Tests\s+2 passed',between('$ pnpm --filter @japp/extension exec vitest run test/m02-w14/public-contact/protocol.test.ts','$ pnpm --filter @japp/extension exec wxt build -b chrome -c test/m02-w14/public-contact/wxt.config.ts'),re.M)))
original_observation=doc(OUT/'original-visual-observation.json');ck('all67_original_visual_observation',original_observation['original67_exact'] and original_observation['source_retention_manifest_sha256']==pin(ret/'retention.json')['sha256'] and original_observation['actual_full_closed_at_observation'] is False and len(original_observation['rows'])==67)
ck('original_visual_observed_during_full',datetime.datetime.fromisoformat(r['observed_utc'])<datetime.datetime.fromisoformat(original_observation['observed_utc'])<datetime.datetime.fromisoformat(end['observed_utc']))
for item in r['all_original_files']:
 path=OUT/'original-visual-observed'/item['path'];ck('all67_original_visual_actual_body:'+item['path'],pin(path)=={k:item[k] for k in ('bytes','mode','sha256')})
ck('excluded_visual_scope_explicit',len(aliases)==33 and len(marker)==1, 'All67 original bodies including excluded duplicate aliases and runner marker independently copied during active Python phase; no later canonical test-results reads.')
final={str(q.relative_to(P)):pin(q) for q in sorted(P.rglob('*')) if q.is_file()};ck('review_evidence_unchanged',initial==final)
report={'scope':'Independent retained-data and immutable local Git review; actual2294-body stream reused, no current worktree/actor/full-native/platform acceptance claim','total':len(rows),'pass_count':sum(r['pass'] for r in rows),'joins':rows,'evidence_pins':initial,'normal_suite_command_joins':suite_command_joins,'actual_browser_case_IDs':browser_identity_sets,'parsed_counts':{'typescript':counts,'python_collection_sha256':collected_digest,'native_case_sets_equal':native[0]==native[1]==native[2],'native_unique_cases':len(native[0]),'suite_names':[q[0] for q in suite_rows],'outer_seconds':{q['name']:q['seconds'] for q in results},'actual_python_summary':python_actual_summaries,'browser_actual_summaries':browser_summaries,'typecheck_cached_task_count':typecheck_cache}}
(OUT/'data-joins.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'total':len(rows),'pass':sum(r['pass'] for r in rows),'failed':[r for r in rows if not r['pass']]}))
