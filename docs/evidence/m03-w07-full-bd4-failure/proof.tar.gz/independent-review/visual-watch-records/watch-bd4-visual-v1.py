from pathlib import Path
import datetime,json,subprocess,time
E=Path(__file__).parent
F=E/'full-bd4cffd'
old=(E/'retain-f5a-visual.py').read_text()
new=old.replace("F=E/'full-f5a05ba'","F=E/'full-bd4cffd'").replace("P=E/'full-2ea0fde/retained-visual'","P=E/'full-f5a05ba/retained-visual'")
assert new!=old and "F=E/'full-f5a05ba'" not in new
script=E/'retain-bd4-visual-v1.py'
assert not script.exists()
script.write_text(new)
start=time.monotonic()
receipt={'start_utc':datetime.datetime.now(datetime.UTC).isoformat(),'scope':'read log, retain ignored current visual outputs outside only after actual visual17PASS and Python start','retention_script':str(script),'outcome':'WAITING'}
record=E/'watch-bd4-visual-v1.json'
record.write_text(json.dumps(receipt,indent=2)+'\n')
while time.monotonic()-start<2700:
    log=(F/'verify.log').read_text()
    if '17 passed' in log and '$ uv run pytest -c pyproject.toml' in log:
        with (E/'watch-bd4-visual-v1.stdout').open('xb') as out,(E/'watch-bd4-visual-v1.stderr').open('xb') as err:
            child=subprocess.Popen(['/Users/tanishkalwad/.local/share/uv/python/cpython-3.12.13-macos-aarch64-none/bin/python3.12','-I','-S','-B',str(script)],stdout=out,stderr=err,stdin=subprocess.DEVNULL)
            code=child.wait(timeout=30)
        receipt.update(outcome='RETAINED' if code==0 else 'RETENTION_FAILED',exit_code=code,direct_child_reaped=child.returncode is not None,seconds=time.monotonic()-start,end_utc=datetime.datetime.now(datetime.UTC).isoformat())
        record.write_text(json.dumps(receipt,indent=2)+'\n')
        print(json.dumps(receipt),flush=True)
        raise SystemExit(code)
    if (F/'closure.json').exists():
        receipt.update(outcome='AGGREGATE_CLOSED_BEFORE_RETENTION_TRIGGER',seconds=time.monotonic()-start)
        record.write_text(json.dumps(receipt,indent=2)+'\n')
        raise SystemExit(1)
    time.sleep(2)
receipt.update(outcome='WATCH_DEADLINE',seconds=time.monotonic()-start)
record.write_text(json.dumps(receipt,indent=2)+'\n')
raise SystemExit(1)
