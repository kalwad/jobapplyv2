"""Retain finite existing source/focused receipts; no product commands or decisions."""
from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
OUT = Path('/tmp/japp-m03-w06-windows-correction-retained-20261019')
E = ROOT / 'docs/evidence/m03-w06-windows-loader-correction'
ADOPT = Path('/tmp/japp-m03-w06-windows-correction-adoption-20261019')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == '19762e2e6a1780d736cb265cb47d19fdb74e7744'
assert not OUT.exists() and not E.exists()
OUT.mkdir()
members = {}


def add(name, path):
    assert name not in members
    assert path.is_file() and not path.is_symlink()
    members[name] = path.read_bytes()


for p in sorted(ADOPT.rglob('*')):
    if p.is_file():
        add('canonical-adoption/' + p.relative_to(ADOPT).as_posix(), p)
changes = subprocess.check_output(['git', 'ls-files', '-m', '-o', '--exclude-standard', '-z'], cwd=ROOT).decode().split('\0')
changes = sorted(filter(None, changes))
assert len(changes) == 8
for rel in changes:
    add('actual-postimages/' + rel, ROOT / rel)
add('executed-outer/python.log', Path('/tmp/japp-m03-w06-correction-focused-checks-20261019.outer.log'))
add('executed-outer/native.log', Path('/tmp/japp-m03-w06-correction-native-focus-20261019.outer.log'))
for label, dirname, names in [
    ('manifest-source-review', 'japp-m03-w04-windows-manifest-candidate-independent-review-20261019', ['REVIEW.md', 'findings.json', 'inputs.json', 'review-members.json', 'review-source.py']),
    ('diagnostics-source-review', 'japp-m03-w04-windows-diagnostics-independent-review-20261019', ['REVIEW.md', 'findings.json', 'retention-manifest.json', 'source_review.py']),
    ('proposal-history', 'japp-m03-w04-windows-manifest-ci-proposal-20261019', ['README.md', 'MANIFEST_CONTRACT.md', 'PREPARATION.json', 'source_checks.py', 'diagnostics-only.patch', 'manifest-w06.patch']),
    ('diagnosis', 'japp-m03-w04-windows-entrypoint-diagnosis-20261019', ['DIAGNOSIS.md', 'REPRO_PLAN.md', 'findings.json', 'lock-comparison.json']),
]:
    base = Path('/tmp') / dirname
    for name in names:
        add(label + '/' + name, base / name)
    for child in ['checks', 'history']:
        p = base / child
        if p.is_dir():
            for f in sorted(p.rglob('*')):
                if f.is_file():
                    add(label + '/' + f.relative_to(base).as_posix(), f)
    if label == 'diagnosis':
        for f in sorted((base / 'primary').glob('*.receipt.json')):
            add(label + '/primary/' + f.name, f)
add('retention-writer.py', Path(__file__))
dump(OUT / 'source-postimages.json', {p: {'bytes': len((ROOT/p).read_bytes()), 'sha256': digest((ROOT/p).read_bytes())} for p in changes})
add('source-postimages.json', OUT / 'source-postimages.json')
manifest = {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(members.items())}
dump(OUT / 'members.json', {'scope': 'Finite selected source and actual Mac component receipts; cited outside raw HTML/crate bodies are not included.', 'members': manifest})
archive = OUT / 'proof.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for name, data in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    entries = tar.getmembers()
    assert len(entries) == len(members)
    for item in entries:
        assert item.isfile() and not item.name.startswith('/') and '..' not in Path(item.name).parts
        assert tar.extractfile(item).read() == members[item.name]
E.mkdir()
(E / 'proof.tar.gz').write_bytes(archive.read_bytes())
(E / 'members.json').write_bytes((OUT / 'members.json').read_bytes())
artifacts = {
    'base_head': '19762e2e6a1780d736cb265cb47d19fdb74e7744',
    'base_tree': 'f7196be0a92f871079de48d71e3e443d40ab2e54',
    'source_postimages': json.loads((OUT / 'source-postimages.json').read_text()),
    'proof': {'path': 'proof.tar.gz', 'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes()), 'regular_members': len(members)},
    'members_manifest': {'path': 'members.json', 'sha256': digest((OUT / 'members.json').read_bytes())},
    'scope': 'Actual macOS affected components only. Windows/PowerShell execution, loader cause/fix and normal-app manifest resource merging remain UNVERIFIED. W06 remains IN_PROGRESS; no milestone/gate/requirement acceptance.',
}
dump(E / 'artifacts.json', artifacts)
(E / 'README.md').write_text('''# Windows loader correction candidate

This finite packet binds eight actual source postimages over commit19762e2 and
the executed affected Python and native checks. It is a candidate for actual
Windows CI evaluation; KI-0109 remains IN_PROGRESS.

The Windows/MSVC build adds the pinned Common Controls v6 manifest to link
arguments used by library tests. The original failed executable was not
retained, so its actual missing DLL/export and the failure cause remain
unobserved. Windows resource merging and the candidate fix require execution.

Failure-only diagnostics preserve canonical failure, allow at most eight
existing desktop PE inputs/512MiB, and use bounded SDK inspection. That input
bound does not bound all diagnostic output bytes. System32/SxS export candidates
are not actual loader resolution. No tested PE is launched, DLL loaded or
copied, test rerun, or PATH patched by that diagnostic. PowerShell and SDK
execution are unverified on this Mac.

The six Python/policy commands exit0, including544 affected tests and the exact
1689-case collection. All15 native commands exit0 on macOS;183 identical cases
pass in each of three modes under default parallel execution. Source1919 and
runtime40 maps remain unchanged during their respective checks. The inventory
is updated afterward with exactly10 collected additions, no removals, and the
same two POSIX cases. Strict loader derivation for all three platforms is not
Windows test execution. These are component results, not a new full run.

`artifacts.json` binds the selected archive, exhaustive member manifest and
eight source postimages. Original wrong-cwd Ruff/source-observer failures are
retained. Selected primary-source fetch receipts are included; raw HTML/crate
bodies stay outside this packet. Historical hosted failure is preserved in
`../m03-w04-hosted-ci`. Independent actual-adoption review follows separately.
''')
entry = '''### M03-W06 — Windows loader correction adopted for actual CI evaluation (2026-10-19UTC)

- Revision: eight exact source postimages over commit19762e2e6a1780d736cb265cb47d19fdb74e7744/treef7196be0a92f871079de48d71e3e443d40ab2e54,1919 logical source files before evidence. Target-scoped Windows/MSVC Common Controls v6 link manifest and bounded failure-only SDK/PE diagnostics are adopted after separate20-check manifest and23-check diagnostics source reviews. Canonical failure handling, old tests and browser artifact rules remain intact. Actual missing export/DLL, causal diagnosis, Windows normal-app resource merging and fix remain UNVERIFIED; KI-0109 stays IN_PROGRESS.
- Actual macOS arm64/Node24.18.0/pnpm11.17.0/Python3.12.13/uv0.11.32/Rust1.97.1 commands: `uv run ruff check scripts/check_portability.py scripts/tests/test_ci_workflow.py scripts/tests/test_portability.py`, `uv run ruff format --check` on the same three paths, `uv run mypy` on those paths, `uv run pytest scripts/tests/test_ci_workflow.py scripts/tests/test_portability.py -q` (544PASS111.92s), `uv run python scripts/check_portability.py`, and the exact canonical `uv run pytest ... --collect-only -q` inventory argv all exit0. The strict unchanged canonical parser observes1689 exact POSIX IDs. Raw argv/env/timing/tool hashes and source1919 before/after equality are retained.
- Separate `pnpm verify --suite rust` exits0 in31.411908041s: all15 registry commands pass;183 identical tests pass in each default/all-features/direct SDK protocol mode with0failed/ignored/filtered, ordinary parallel execution and buildjobs2. Source1919/runtime40 byte-and-mode maps remain unchanged. This Mac component result supplies no Windows or new full-run PASS.
- Inventory changes only after both check closures: exactly10 added policy-test IDs/no removals preserve1677 prior common and two POSIX cases. New common1687 digestfe5d7707ee430a5db43afed00f876cc220829cb8cabdcbb7963af2a9e4921595; POSIX1689 digestf1d2992fd74dde2f7261637d14f0f970369b2e9cd771de5aacd5735695051dea. Strict darwin/linux/win32 loader derivations succeed; this does not execute Windows tests. Inventory file1c14438f3129b6041a5b23353bb99853f295a00631851c29825afae3d86a3e3d.
- Evidence: docs/evidence/m03-w06-windows-loader-correction binds the finite source/focused archive and original source-observer/wrong-cwd Ruff failures. The existing hosted failure remains unchanged. Diagnostic input8PE/512MiB is not a total output bound; System32/SxS candidates are not observed loader resolution; no PE/DLL probe launch, PATH patch or test rerun occurs. PowerShell/SDK behavior remains unexecuted here. W06 remains sole IN_PROGRESS,38/300 VERIFIED; no milestone, platform, gate or release acceptance follows.

'''
p = ROOT / 'docs/TEST_EVIDENCE.md'
body = p.read_text()
assert body.count('## Entries\n\n') == 1
p.write_text(body.replace('## Entries\n\n', '## Entries\n\n' + entry, 1))
p = ROOT / 'docs/KNOWN_ISSUES.md'
body = p.read_text()
old = '- Resolution + evidence link: investigate the source-supported Common Controls v6 test-manifest gap and evaluate the separately reviewed target-scoped candidate with actual Windows PE/resource/unchanged native tests. Cause/fix and normal-app resource merging remain unvalidated. Add bounded failure-only native diagnostics without weakening canonical exit handling. See docs/evidence/m03-w04-hosted-ci and docs/TEST_EVIDENCE.md; current work continues in W06.'
new = '- Resolution + evidence link: target-scoped Common Controls v6 manifest candidate and bounded failure-only diagnostics are now integrated with separate source reviews and actual Mac affected checks (544Python/183native each3). Actual Windows PE/resource/unchanged native tests are next; cause/fix and normal-app resource merging remain unvalidated. Canonical failure handling is unchanged. See docs/evidence/m03-w06-windows-loader-correction, docs/evidence/m03-w04-hosted-ci and docs/TEST_EVIDENCE.md; current work continues in W06.'
assert body.count(old) == 1
p.write_text(body.replace(old, new, 1))
print(json.dumps(artifacts['proof']))
