"""Run only extracted pure source-policy cases; no product or PowerShell import."""
from pathlib import Path
import ast
import dataclasses
import hashlib
import json
import re
import types
from typing import Any, cast

import yaml

ROOT = Path(__file__).parent
OVERLAY = ROOT / 'overlay'

def definitions(path, names, namespace):
    module = ast.parse(path.read_text())
    nodes = []
    for node in module.body:
        if isinstance(node, (ast.ClassDef, ast.FunctionDef)) and node.name in names:
            if isinstance(node, ast.FunctionDef):
                node.decorator_list = []
            nodes.append(node)
    if len(nodes) != len(names):
        raise RuntimeError((path, names, [n.name for n in nodes]))
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec'), namespace)

checker = types.SimpleNamespace()
checker_namespace = {'__name__': '__main__', 'dataclass': dataclasses.dataclass, 'Any': Any}
definitions(OVERLAY/'scripts/check_portability.py', {'Violation','_check_artifacts'}, checker_namespace)
checker.Violation = checker_namespace['Violation']
checker._check_artifacts = checker_namespace['_check_artifacts']
policy_namespace = {'Path': Path, 'Any': Any, 'cast': cast, 'yaml': yaml,
                    'REPO_ROOT': OVERLAY, 'check_portability': checker}
definitions(OVERLAY/'scripts/tests/test_portability.py',
            {'load_workflow','verify_job','test_native_loader_artifact_exception_refuses_scope_drift'},
            policy_namespace)
policy_ast = ast.parse((OVERLAY/'scripts/tests/test_portability.py').read_text())
test_node = next(n for n in policy_ast.body if isinstance(n, ast.FunctionDef)
                 and n.name == 'test_native_loader_artifact_exception_refuses_scope_drift')
cases = ast.literal_eval(test_node.decorator_list[0].args[1])
results = []
for field, value in cases:
    policy_namespace[test_node.name](field, value)
    results.append({'case':test_node.name, 'input':[field,value], 'result':'PASS'})

workflow_source = OVERLAY/'scripts/tests/test_ci_workflow.py'
workflow_namespace = {'Any':Any, 'yaml':yaml, 'CI_PATH':OVERLAY/'.github/workflows/ci.yml',
                      're':re, 'ALLOWED_ACTION_ORGS':('actions/',),
                      'SHA_PIN_RE':re.compile(r'^(?P<action>[\w.-]+/[\w.-]+)@(?P<sha>[0-9a-f]{40})$')}
names = {'UniqueKeyLoader','_construct_mapping','load_ci','ci_steps','run_bodies','step_named'}
tests = {'test_workflow_parses_without_duplicate_keys','test_permissions_are_read_only',
         'test_job_has_timeout_and_no_global_shell_default','test_no_continue_on_error_anywhere',
         'test_every_action_is_sha_pinned_official_and_annotated',
         'test_artifact_upload_is_failure_scoped_and_playwright_only',
         'test_only_additional_artifact_is_bounded_windows_native_failure_evidence',
         'test_artifact_upload_name_is_per_matrix_platform'}
definitions(workflow_source, names | tests, workflow_namespace)
loader = workflow_namespace['UniqueKeyLoader']
loader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
                       workflow_namespace['_construct_mapping'])
for name in sorted(tests):
    workflow_namespace[name]()
    results.append({'case':name, 'result':'PASS'})

preimage = (ROOT/'preimages/build-w06.rs').read_text()
candidate = (ROOT/'candidate-w06/apps/desktop/src-tauri/build.rs').read_text()
start = candidate.index('    // Cover executable artifacts including the lib unit-test harness.\n')
if candidate[:start] + '}\n' != preimage:
    raise RuntimeError('Removing only the manifest block must recover exact W06 build.rs')
if hashlib.sha256(preimage.encode()).hexdigest() != 'f43d047546749946a4d6c5966f3839d3cbc9650aeec195f3f3bccfc0be849b42':
    raise RuntimeError('W06 preimage drift')
original = yaml.safe_load((ROOT/'preimages/ci.yml').read_text())
modified = workflow_namespace['load_ci']()
old_steps = original['jobs']['verify']['steps']
new_steps = modified['jobs']['verify']['steps']
old_canonical = next(s for s in old_steps if s.get('run') == 'pnpm verify')
new_canonical = next(s for s in new_steps if s.get('id') == 'canonical_verify')
if {k:v for k,v in new_canonical.items() if k != 'id'} != old_canonical:
    raise RuntimeError('Canonical verification command/environment drift')
added = {'Inspect retained Windows native images after canonical failure',
         'Retain Windows native loader failure evidence'}
projected = [({k:v for k,v in s.items() if k != 'id'} if s is new_canonical else s)
             for s in new_steps if s.get('name') not in added]
if projected != old_steps:
    raise RuntimeError('Existing workflow steps changed beyond the canonical id')
print(json.dumps({'scope':'Pure extracted source-policy checks, not full pytest/canonical/native verification',
                  'results':results,'checks_passed':len(results),
                  'w06_removal_projection':'EXACT','canonical_command_and_existing_steps':'EXACT',
                  'powershell_parse':'UNAVAILABLE: pwsh absent','product_actor_count':0},indent=2))
