# Closed Windows loader failure: bounded source diagnosis

The Windows default desktop unit-test executable exited with `0xc0000139` before any library test summary. The strongest source-supported candidate is a **Common Controls v6 manifest gap in the lib unit-test executable**, made observable when W04 added Tauri mock-app tests. The exact missing DLL/export and actual executable manifest remain **UNOBSERVED**. This is not a confirmed causal diagnosis or a validated fix.

The failed source is immutable head `2a327c6210bfb7236f3d8a572a3a62e9b7e13d63`, tree `4ce9cf0c1f5515252a029584f820ea674a66e05e`, run `39194489970`, Windows job `117874182536`. The current canonical working tree is not an input to this investigation. No compilation, product import, native/test actor, rerun, workflow change, or canonical write occurred.

## Observed failure and comparison

- Complete official current Windows log SHA-256: `8459cf1f471cee9a6947c6bbd963faffeb217d9e97b0d8ea7532330208f5a0c2`. Default `cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml` starts at line 8612. Linking finishes; line 8829 launches `japp_desktop-d259cde1f90c873d.exe`; line 8833 reports `STATUS_ENTRYPOINT_NOT_FOUND`. There is no desktop library test summary and no evidence that an HTTP request or individual library test began.
- The closest earlier Windows native result is head `6d3a6b8ccde5b75e12248ae7bbefc473b72922e4`, tree `34fcf854cb4a1a452b267a02a05e0c34aeb6f89c`, run `39188122249`. It actually passed **70 library tests per mode**, three modes. The earlier count 77 referred to macOS. That historical Windows job still failed elsewhere, so it is not an all-green platform baseline.
- Both logs report Windows Server 2025 `10.0.26100`, runner image `windows-2025-vs2026`, image version `20261007.264.1`. Equal image labels do not prove identical per-job filesystem/PATH/DLL resolution.
- The current log contains strict desktop Clippy `--all-targets --all-features` once, plus the native-host and contract-harness workspaces. It does not contain three desktop-mode Clippy runs. Default desktop test failure prevents the later all-features/custom-protocol desktop test commands. No current desktop passing-test count is inferred.
- The lock comparison adds 33 package/version records, removes none, and changes no existing package/version pair. `tauri 2.12.4`, `tauri-build 2.7.3`, `muda 0.20.0`, `embed-resource 3.0.12`, `tokio 1.53.3`, `mio`, `socket2`, existing `windows*` packages, `getrandom 0.4.3`, `hyper 1.12.0`, and `time 0.3.55` already existed. Direct dependency additions and feature unification can change linked code despite unchanged versions. `lock-comparison.json` retains the actual changed dependency records; it is not a computed Windows feature graph.

## Concrete source chain

1. W04 adds `src/diagnostics/tests/tauri.rs`: line 10 imports `tauri::test::{...mock_builder...}`; lines 35–55 build a real Tauri `MockRuntime` app, and the tests exercise IPC/ACL paths. The prior source has no `mock_builder`/`MockRuntime`/`tauri::test` usage. These are headless test seams, not evidence that Wry or a native GUI ran.
2. The pinned `tauri 2.12.4` manifest defaults include `common-controls-v6` (lines 71–88), which enables `muda/common-controls-v6`. Setting `features=[]` in the application manifest does not disable the dependency's default features.
3. Pinned `muda 0.20.0` documents that feature as using `TaskDialogIndirect` from ComCtl32 v6. `src/platform_impl/windows/mod.rs` lines 1286–1334 contain its feature-gated call. Pinned `windows-sys 0.61.2`, `Windows/Win32/UI/Controls/mod.rs:282`, declares a raw import of `TaskDialogIndirect` from `comctl32.dll`. This establishes a possible import path; final linker retention in the failed PE has not been observed.
4. Both revisions call the same Tauri Windows resource path. The W04 `build.rs` change replaces `tauri_build::build()` with default `Attributes` plus an **ACL** `AppManifest`. That ACL declaration is distinct from a Windows activation manifest. `tauri-build 2.7.3` creates its default Windows Common Controls v6 resource and calls `res.compile()` at line 871; `tauri-winres 0.3.6:541` delegates to `embed_resource::compile`.
5. Pinned `embed-resource 3.0.12:433–443` sees desktop `src/main.rs`, sets `hasbins`, and emits `cargo:rustc-link-arg-bins=...`. Its source explicitly says normal `compile()` links the resource only to binaries. This does not supply a general link argument to the lib unit-test harness. No repository `.cargo` configuration, checked-in Windows manifest, or additional desktop manifest/link-argument emission was found in this exact Git tree. This is the concrete build-coverage gap; actual test PE resources were not retained.
6. Microsoft documents that Windows defaults to ComCtl32 v5 and applications select v6 with an activation manifest. The official Tauri issue #13948 reports the same startup status after adding `tauri::test::mock_app()` and a maintainer points to applying a Windows manifest to the importing/test binary. That analogous upstream report supports prioritizing the candidate; it does not prove this project's missing export.

Every copied registry source file is byte-equal to the member in its already-installed `.crate` archive; that archive SHA-256 matches the exact Cargo.lock checksum. `capture.json` records those joins. There were no dependency downloads or resolution operations.

## Candidate and alternatives

`proposal/candidate-unexecuted.patch` is an **unexecuted two-file candidate against exact 2a327**: retain all current dependencies/tests/ACL/runtime logic, add a checked-in Common Controls v6 activation XML (byte-equal to pinned Tauri's default XML), and emit general `/MANIFEST:EMBED` plus `/MANIFESTINPUT:<absolute path>` link arguments only for target OS Windows and target environment MSVC. General Cargo link arguments cover supported test artifacts as well as application binaries. This avoids assuming `rustc-link-arg-tests` covers a lib unit-test target or inventing an integration-test target.

Existing Tauri resource compilation remains in place for icon/version/normal app resources. The MSVC linker must merge identical Common Controls dependencies for normal app binaries without duplicate-resource/conflicting-manifest failure; **that behavior and the lib harness manifest require actual PE validation**. The candidate is not formatted/compiled/tested or approved for canonical adoption. Its comment describes the intended coverage, not an observed failed-PE import table. A future current-source transplant must use and review the then-current build.rs preimage.

Other options are less narrow: disabling `common-controls-v6` changes application feature behavior; adding `embed-resource::compile_for_everything` as a direct build dependency changes the manifest/lock and can duplicate resource linkage; `__TAURI_WORKSPACE__` is not part of the pinned source path and upstream reports show it is not a reliable fix. None is applied.

Socket/HTTP Windows imports and DLL shadowing remain alternate explanations until imports, resources, resolved modules, and exports are captured. There is no evidence that the OS lacks a Tokio API, a runtime payload DLL was staged into the test loader search path, or a package version regression occurred. No API-client raw FFI/import declaration was found. Clippy success proves compilation/typechecking, not loader success.

## Primary sources retained

Raw primary HTML and URL/status/headers/timestamp/hash receipts are under `primary/`:

- [Tauri issue #13948, maintainer discussion](https://github.com/tauri-apps/tauri/issues/13948).
- [Cargo build-script link-argument scope](https://doc.rust-lang.org/cargo/reference/build-scripts.html#rustc-link-arg).
- [Microsoft Common Controls activation](https://learn.microsoft.com/en-us/windows/win32/controls/cookbook-overview), [TaskDialogIndirect](https://learn.microsoft.com/en-us/windows/win32/api/commctrl/nf-commctrl-taskdialogindirect).
- [MSVC /MANIFESTINPUT](https://learn.microsoft.com/en-us/cpp/build/reference/manifestinput-specify-manifest-input?view=msvc-170), [/MANIFEST](https://learn.microsoft.com/en-us/cpp/build/reference/manifest-create-side-by-side-assembly-manifest?view=msvc-170), [DUMPBIN /IMPORTS](https://learn.microsoft.com/en-us/cpp/build/reference/imports-dumpbin?view=msvc-170), [DLL search order](https://learn.microsoft.com/en-us/windows/win32/dlls/dynamic-link-library-search-order).

Microsoft's [NTSTATUS table](https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-erref/596a1078-e883-4972-9bbc-49e60bebca55) defines this status as an unresolved procedure entry point in a DLL. The ordinary Cargo log omits the substituted DLL/function names.

Preparation failures are retained: the initial guessed Python executable was absent (127); capture v1 requested a nonexistent diagnostics module and failed before registry/docs; v2 expected an unavailable `.cargo-checksum.json` and failed before docs. Their source/stdout/stderr remain unchanged. V3 verifies archive/member equality and closes successfully. These are read-only collection failures, not product RED results.
