"""Independent read/hash/AST inspection only; never imports proposal modules."""
from pathlib import Path
import ast
import copy
import hashlib
import json
import re
import subprocess

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
INPUT = Path('/tmp/japp-m03-w04-windows-manifest-ci-proposal-20261019')
OUT = Path(__file__).parent
COMMIT = '185909baee1fdcbf21e779959f40bad30b0231c9'
checks = []

def check(name, ok, detail=None):
    checks.append({'name': name, 'pass': bool(ok), 'detail': detail})

def sha(data):
    return hashlib.sha256(data).hexdigest()

paths = {
    '.github/workflows/ci.yml': 'ci.yml',
    'scripts/check_portability.py': 'check_portability.py',
    'scripts/tests/test_ci_workflow.py': 'test_ci_workflow.py',
    'scripts/tests/test_portability.py': 'test_portability.py',
}
for relative, local in paths.items():
    actual = subprocess.run(['git', '-C', str(ROOT), 'show', f'{COMMIT}:{relative}'],
                            check=True, capture_output=True).stdout
    saved = (INPUT/'preimages'/local).read_bytes()
    check(f'preimage immutable Git blob: {relative}', actual == saved,
          {'bytes': len(saved), 'sha256': sha(saved)})
config = subprocess.run(['git', '-C', str(ROOT), 'show', f'{COMMIT}:pyproject.toml'],
                        check=True, capture_output=True).stdout
check('check-only pyproject exact immutable Git bytes', config == (INPUT/'overlay/pyproject.toml').read_bytes())
patch = (INPUT/'diagnostics-only.patch').read_bytes()
check('reviewed patch exact requested hash', sha(patch) == 'd0c9573f5360336c417d85811999526485cc677b978c604b962c58b72777fe9d')
sections = re.split(r'(?m)^--- ', patch.decode())[1:]
patch_paths = []
for section in sections:
    lines = section.splitlines(keepends=True)
    before_name = lines.pop(0).rstrip('\n')
    after_name = lines.pop(0).rstrip('\n')[4:]
    relative = after_name.removeprefix('b/')
    patch_paths.append(relative)
    before = b'' if before_name == '/dev/null' else (INPUT/'preimages'/paths[relative]).read_bytes()
    source = before.decode().splitlines(keepends=True)
    result = []
    cursor = 0
    while lines:
        header = lines.pop(0)
        match = re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?:[^\n]*)\n', header)
        if not match:
            raise ValueError(header)
        position = max(0, int(match[1])-1)
        result.extend(source[cursor:position])
        cursor = position
        while lines and not lines[0].startswith('@@ '):
            line = lines.pop(0)
            if line.startswith('\\ No newline'):
                raise ValueError('unexpected unterminated source')
            if line[0] in ' -':
                if cursor >= len(source) or source[cursor] != line[1:]:
                    raise ValueError(('hunk preimage mismatch', relative, cursor))
                cursor += 1
            if line[0] in ' +':
                result.append(line[1:])
    result.extend(source[cursor:])
    check(f'patch exact afterimage: {relative}', ''.join(result).encode() == (INPUT/'overlay'/relative).read_bytes())
check('exact closed five shipping paths', set(patch_paths) == set(paths)|{'scripts/windows-native-loader-diagnostics.ps1'} and len(patch_paths)==5)

def parsed(path):
    return ast.parse(path.read_text(encoding='utf-8'))

def dump(node):
    return ast.dump(node, include_attributes=False)

old = parsed(INPUT/'preimages/test_portability.py')
new = parsed(INPUT/'overlay/scripts/tests/test_portability.py')
new.body = [node for node in new.body if not (isinstance(node, ast.FunctionDef) and node.name == 'test_native_loader_artifact_exception_refuses_scope_drift')]
check('all prior portability module AST nodes unchanged', dump(old)==dump(new))
old = parsed(INPUT/'preimages/test_ci_workflow.py')
new = parsed(INPUT/'overlay/scripts/tests/test_ci_workflow.py')
new.body = [node for node in new.body if not (isinstance(node, ast.FunctionDef) and node.name == 'test_only_additional_artifact_is_bounded_windows_native_failure_evidence')]
expected_filter = dump(ast.parse('step.get("with", {}).get("path", "").rstrip("/") == "test-results"', mode='eval').body)
removed = 0
for node in ast.walk(new):
    if isinstance(node, ast.comprehension):
        retained = [test for test in node.ifs if dump(test) != expected_filter]
        removed += len(node.ifs)-len(retained)
        node.ifs = retained
check('exact two approved upload-list filters', removed == 2)
check('all prior CI test AST nodes unchanged after exact filter reversal', dump(old)==dump(new))
old = parsed(INPUT/'preimages/check_portability.py')
new = parsed(INPUT/'overlay/scripts/check_portability.py')
def remaining(module):
    return ast.Module(body=[node for i,node in enumerate(module.body) if i != 0 and not (isinstance(node, ast.FunctionDef) and node.name=='_check_artifacts')], type_ignores=[])
check('all other checker AST nodes unchanged', dump(remaining(old))==dump(remaining(new)))
for name in ('test_ci_workflow.py', 'test_portability.py'):
    old_asserts = [dump(n) for n in ast.walk(parsed(INPUT/'preimages'/name)) if isinstance(n,ast.Assert)]
    new_asserts = [dump(n) for n in ast.walk(parsed(INPUT/'overlay/scripts/tests'/name)) if isinstance(n,ast.Assert)]
    check(f'all original assertions retained: {name}', all(new_asserts.count(x)>=old_asserts.count(x) for x in set(old_asserts)), {'old':len(old_asserts),'new':len(new_asserts)})

old = (INPUT/'preimages/ci.yml').read_text()
new = (INPUT/'overlay/.github/workflows/ci.yml').read_text()
start = new.index('      - name: Inspect retained Windows native images after canonical failure\n')
end = new.index('      - name: Assert verification left no tracked changes\n', start)
new = new[:start]+new[end:]
new = new.replace('        id: canonical_verify\n','',1)
new = new.replace('# release tag), no live-site tests, failure-only Playwright outputs plus a\n# bounded Windows native-loader diagnostic artifact after canonical failure.\n',
                  '# release tag), no live-site tests, artifacts uploaded only on failure and\n# only Playwright\'s failure-scoped traces from test-results/.\n',1)
check('all prior workflow bytes exact after id/two-step/comment reversal', new==old)
pre = (INPUT/'preimages/build-w06.rs').read_bytes()
candidate = (INPUT/'candidate-w06/apps/desktop/src-tauri/build.rs').read_bytes()
offset = candidate.index(b'    // Cover executable artifacts including the lib unit-test harness.\n')
check('W06 target descriptor preserved: exact trailing-block reversal', candidate[:offset]+b'}\n'==pre and sha(pre)=='f43d047546749946a4d6c5966f3839d3cbc9650aeec195f3f3bccfc0be849b42')
author = json.loads((INPUT/'checks/03-source-helper.stdout').read_text())
check('retained author extracted checks labeled bounded and 17/17', author['checks_passed']==17 and len(author['results'])==17 and all(r['result']=='PASS' for r in author['results']) and 'Pure extracted' in author['scope'])
check('retained corrected-layout Ruff success', (INPUT/'checks/04-ruff-correct-layout.stdout').read_text().strip()=='All checks passed!')
check('wrong-cwd Ruff failure retained', 'Found 387 errors' in (INPUT/'checks/02-ruff-check.stdout').read_text())

inventory=[]
for path in sorted(INPUT.rglob('*')):
    if path.is_file():
        data=path.read_bytes()
        inventory.append({'path':path.relative_to(INPUT).as_posix(),'bytes':len(data),'sha256':sha(data)})
output={'scope':'Independent source/read/hash/AST only; no proposal import, tests, compiler, PowerShell, SDK, PE, CI or product actor',
        'immutable_preimage':COMMIT,'checks':checks,'passed':sum(x['pass'] for x in checks),'total':len(checks),
        'findings':[], 'input_files':inventory}
(OUT/'findings.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({'passed':output['passed'],'total':output['total'],'all_pass':all(x['pass'] for x in checks)}))
