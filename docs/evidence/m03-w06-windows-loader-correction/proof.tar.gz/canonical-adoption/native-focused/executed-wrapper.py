from pathlib import Path
import hashlib,json,os,subprocess,time,datetime,shutil
R=Path('/Users/tanishkalwad/jobapplyv2');B=Path('/tmp/japp-m03-w06-windows-correction-adoption-20261019/native-focused');B.mkdir(exist_ok=False)
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def put(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
env={k:os.environ[k] for k in ['HOME','USER','LOGNAME','TMPDIR','LANG','LC_ALL','CARGO_HOME','RUSTUP_HOME','SDKROOT','DEVELOPER_DIR','MACOSX_DEPLOYMENT_TARGET'] if k in os.environ};env.update(PATH='/opt/homebrew/opt/node@24/bin:'+os.environ['PATH'],UV_OFFLINE='true',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='2',COREPACK_ENABLE_NETWORK='0',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_SYSTEM='/dev/null')
def source():
 names=set()
 for argv in [['git','ls-files','-z'],['git','ls-files','--others','--exclude-standard','-z']]:names.update(v for v in subprocess.check_output(argv,cwd=R,env=env).decode().split('\0') if v)
 return {k:{'bytes':(R/k).stat().st_size,'sha256':sha(R/k)} for k in sorted(names)}
def runtime():
 p=R/'apps/desktop/src-tauri/runtime-payload'
 return {f.relative_to(p).as_posix():{'bytes':f.stat().st_size,'sha256':sha(f),'mode':oct(f.stat().st_mode&0o777)} for f in p.rglob('*') if f.is_file()}
before=source();rb=runtime();assert len(before)==1919 and len(rb)==40;put('source-before.json',before);put('runtime-before.json',rb);shutil.copy2(__file__,B/'executed-wrapper.py')
argv=['pnpm','verify','--suite','rust'];tool=Path(shutil.which('pnpm',path=env['PATH'])).resolve();record={'argv':argv,'cwd':str(R),'environment':dict(env),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,env=env,text=True).strip(),'git_status':subprocess.check_output(['git','status','--porcelain=v1'],cwd=R,env=env,text=True),'tool':str(tool),'tool_sha256':sha(tool),'wrapper_sha256':sha(B/'executed-wrapper.py'),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout_seconds':600,'scope':'Canonical full registered Rust stage; ordinary parallel tests (no RUST_TEST_THREADS), buildjobs2; not whole20 or GUI proof'};put('upfront.json',record);began=time.monotonic()
with (B/'rust.log').open('wb') as out:
 try:p=subprocess.run(argv,cwd=R,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=600,check=False);code=p.returncode
 except subprocess.TimeoutExpired:code=124
record.update(exit_code=code,elapsed_seconds=time.monotonic()-began,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=sha(B/'rust.log'),log_bytes=(B/'rust.log').stat().st_size);put('result.json',record)
after=source();ra=runtime();put('source-after.json',after);put('runtime-after.json',ra);closure={'exit_code':code,'source1919_unchanged':before==after,'runtime40_unchanged':rb==ra,'whole_repository_full':False,'GUI':False};put('closure.json',closure);print(json.dumps({'result':record['exit_code'],'seconds':record['elapsed_seconds'],'closure':closure}),flush=True)
raise SystemExit(0 if code==0 and before==after and rb==ra else 1)
