from pathlib import Path
import difflib,hashlib,json,shutil,tomllib,xml.etree.ElementTree as ET
P=Path('/tmp/japp-m03-w04-windows-entrypoint-diagnosis-20261019')
R=Path('/Users/tanishkalwad/jobapplyv2')
O=Path('/tmp/japp-m03-w04-windows-manifest-candidate-independent-review-20261019')
O.mkdir(exist_ok=False)
H=lambda b:hashlib.sha256(b).hexdigest()
checks=[]
def ck(name,value,detail):
 checks.append({'id':name,'pass':bool(value),'detail':detail})
base=(R/'apps/desktop/src-tauri/build.rs').read_bytes(); old=(P/'git/2a327c6/apps/desktop/src-tauri/build.rs').read_bytes()
after=(P/'proposal/apps/desktop/src-tauri/build.rs').read_bytes(); xml=(P/'proposal/apps/desktop/src-tauri/windows-common-controls.manifest').read_bytes(); patch=(P/'proposal/candidate-unexecuted.patch').read_bytes()
ck('patch-pin',H(patch)=='b2dde3fbd7fbea12527fd848fd8de22b36ff1c52f0469a757324cbe1217b6a45',H(patch))
ck('current-preimage-equals-retained-2a327',base==old and H(base)=='5222596918e03c7ba075f552fba4f285d851cfe37320d97659befa8ae3576a4d',H(base))
block=b'''    // Tauri's resource helper applies its Windows manifest to application bins.\n    // The lib unit-test harness also retains Common Controls v6 imports.\n    if std::env::var("CARGO_CFG_TARGET_OS").as_deref() == Ok("windows")\n        && std::env::var("CARGO_CFG_TARGET_ENV").as_deref() == Ok("msvc")\n    {\n        let manifest = base.join("windows-common-controls.manifest");\n        println!("cargo:rerun-if-changed={}", manifest.display());\n        println!("cargo:rustc-link-arg=/MANIFEST:EMBED");\n        println!("cargo:rustc-link-arg=/MANIFESTINPUT:{}", manifest.display());\n    }\n'''
ck('only-bounded-build-addition',after.count(block)==1 and after.replace(block,b'')==base,'Existing descriptor/runtime/ACL/resource build body is byte-preserved')
expected=''.join(difflib.unified_diff(base.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/apps/desktop/src-tauri/build.rs',tofile='b/apps/desktop/src-tauri/build.rs'))+''.join(difflib.unified_diff([],xml.decode().splitlines(True),fromfile='/dev/null',tofile='b/apps/desktop/src-tauri/windows-common-controls.manifest'))
ck('exact-two-file-patch',patch==expected.encode(),'No Cargo features, dependencies, lockfiles, tests or assertions in patch')
ck('target-windows-and-msvc',b'CARGO_CFG_TARGET_OS' in block and b'Ok("windows")' in block and b'CARGO_CFG_TARGET_ENV' in block and b'Ok("msvc")' in block,'Checks target environment, not build-host cfg')
ck('general-link-args',block.count(b'cargo:rustc-link-arg=')==2 and b'link-arg-bins=' not in block,'Adds flags to Cargo-supported link targets including test executables')
ck('manifest-input-and-embed-paired',b'/MANIFEST:EMBED' in block and b'/MANIFESTINPUT:{}' in block,'MANIFESTINPUT requires EMBED; both are emitted together')
ck('absolute-manifest-source',b'var_os("CARGO_MANIFEST_DIR")' in base and b'let manifest = base.join("windows-common-controls.manifest")' in block,'Cargo-provided absolute manifest directory; no shell quoting layer')
ck('manifest-rerun-directive',b'cargo:rerun-if-changed={}' in block,'Rebuild input is declared inside supported target branch')
ns={'a':'urn:schemas-microsoft-com:asm.v1'}; parsed=ET.fromstring(xml); ident=parsed.find('a:dependency/a:dependentAssembly/a:assemblyIdentity',ns)
ck('xml-exact-common-controls-v6',parsed.tag=='{urn:schemas-microsoft-com:asm.v1}assembly' and parsed.attrib=={'manifestVersion':'1.0'} and ident is not None and ident.attrib=={'type':'win32','name':'Microsoft.Windows.Common-Controls','version':'6.0.0.0','processorArchitecture':'*','publicKeyToken':'6595b64144ccf1df','language':'*'},'No requested execution privilege, executable path or unrelated dependency is introduced')
pinned=P/'crates/tauri-build-2.7.3/src/windows-app-manifest.xml'
ck('xml-byte-identical-pinned-tauri',xml==pinned.read_bytes() and H(xml)=='4636f3ba46080315ac3277d473d433b79c00863c9cdca1c93c0c83554c6a3d43',H(xml))
lock=tomllib.loads((R/'apps/desktop/src-tauri/Cargo.lock').read_text())
for name,ver,checksum in [('tauri-build','2.7.3','641dd5fd297c99ab92717b0428cca5b9c6f960b2ac96ca131b3eebc9d70b8ddc'),('embed-resource','3.0.12','6168487b5e7eb2673e6efe1200b1848016e436a6ca0b8031bf04bd9d493a249f')]:
 ck('lock-'+name,any(x['name']==name and x['version']==ver and x.get('checksum')==checksum for x in lock['package']),ver+' '+checksum)
cap=json.loads((P/'capture.json').read_text())
for rel in ['crates/tauri-build-2.7.3/src/lib.rs','crates/tauri-build-2.7.3/src/windows-app-manifest.xml','crates/embed-resource-3.0.12/src/lib.rs']:
 entry=next(x for x in cap['inputs'] if x['path']==rel); b=(P/rel).read_bytes()
 ck('retained-source-'+rel,len(b)==entry['bytes'] and H(b)==entry['sha256'] and entry.get('archive_member_bytes_equal') is True,'Selected source matches capture; original crate/cache extraction is author-retained, not freshly re-executed here')
for name in ['cargo-build-scripts','ms-manifest-input','ms-manifest-embed']:
 rec=json.loads((P/f'primary/{name}.receipt.json').read_text()); b=(P/rec['path']).read_bytes()
 ck('primary-receipt-'+name,len(b)==rec['bytes'] and H(b)==rec['sha256'] and rec['status']==200,rec['url'])
embed=(P/'crates/embed-resource-3.0.12/src/lib.rs').read_text(); tauri=(P/'crates/tauri-build-2.7.3/src/lib.rs').read_text()
ck('source-lead-bin-only-embedding','cargo:rustc-link-arg-bins=' in embed and 'set_manifest' in tauri and 'res.compile()' in tauri,'Bin-only embed-resource branch and unchanged Tauri resource compilation support candidate rationale, not actual failed-PE diagnosis')
selected=['DIAGNOSIS.md','capture.json','proposal/candidate-unexecuted.patch','proposal/apps/desktop/src-tauri/build.rs','proposal/apps/desktop/src-tauri/windows-common-controls.manifest','git/2a327c6/apps/desktop/src-tauri/build.rs','crates/tauri-build-2.7.3/src/lib.rs','crates/tauri-build-2.7.3/src/windows-app-manifest.xml','crates/embed-resource-3.0.12/src/lib.rs']+[f'primary/{n}.{ext}' for n in ['cargo-build-scripts','ms-manifest-input','ms-manifest-embed'] for ext in ['receipt.json','html']]
inputs=[]
for rel in selected:
 src=P/rel; dst=O/'inputs'/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,dst); b=src.read_bytes(); inputs.append({'path':str(src),'copy':str(dst.relative_to(O)),'bytes':len(b),'sha256':H(b)})
for rel in ['apps/desktop/src-tauri/build.rs','apps/desktop/src-tauri/Cargo.lock']:
 src=R/rel; dst=O/'inputs/current-root'/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,dst); b=src.read_bytes(); inputs.append({'path':str(src),'copy':str(dst.relative_to(O)),'bytes':len(b),'sha256':H(b)})
verdict='CLEAR_SOURCE_ONLY' if all(x['pass'] for x in checks) else 'FINDINGS'
findings={'verdict':verdict,'checks_passed':sum(x['pass'] for x in checks),'checks_total':len(checks),'patch_sha256':H(patch),'candidate_build_rs_sha256':H(after),'candidate_manifest_sha256':H(xml),'material_findings':[],'nonblocking_notes':[{'topic':'comment precision','text':'The comment that the lib harness retains v6 imports is an inferred source lead. Prefer wording describing intended test-harness coverage; the DIAGNOSIS already marks final failed-PE/import/export cause UNOBSERVED.'}],'checks':checks,'not_observed':['Windows candidate compilation or test execution','actual failed PE imports/exports or missing symbol','normal application duplicate-manifest/resource merge behavior','Windows startup fix, platform acceptance or KI closure'],'executed_actions':['Python standard-library data/hash/XML checks only'],'prohibited_actions_performed':[]}
(O/'findings.json').write_text(json.dumps(findings,indent=2)+'\n');(O/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
report=f'''CLEAR in the two-file candidate source scope ({findings['checks_passed']}/{len(checks)} checks). No material source defect found. This permits evaluation of the candidate; it establishes neither the Windows failure cause nor a fix.\n\nThe exact patch `{H(patch)}` adds only the target-Windows/MSVC branch and the 392-byte Common Controls v6 manifest. Current root build.rs matches the retained immutable 2a327 preimage (`{H(base)}`); removing the added block restores every original byte, including runtime descriptor, ACL and Tauri resource work. Cargo dependencies, features, lockfiles, tests and assertions are untouched.\n\nBoth general linker directives are confined to the Windows MSVC target. `/MANIFEST:EMBED` accompanies `/MANIFESTINPUT:` and the manifest path derives from Cargo's absolute manifest directory. The XML is byte-identical to pinned tauri-build 2.7.3's default v6 manifest (`{H(xml)}`). The retained Cargo/MSVC primary receipts support the relevant target/flag scopes and the manifest input requirement; their payload hashes were independently checked. Pinned embed-resource 3.0.12's bins-only branch supports the proposed test-harness coverage rationale. Existing application resource compilation remains active.\n\nNormal application duplicate-resource/manifest merge behavior is UNOBSERVED and needs actual Windows evaluation. So do the final failed PE, imports/exports, exact missing symbol, candidate compilation, startup and Windows acceptance. The original failed PE is not required to begin candidate evaluation. The upstream issue is a source lead, not evidence that this failure has that cause. Actual long or spaced Windows paths were not exercised.\n\nNonblocking comment precision: “The lib unit-test harness also retains Common Controls v6 imports” states the source inference more strongly than the diagnosis. Wording such as “Cover the lib unit-test harness with the v6 manifest too” would describe intent without asserting the unobserved failed PE. This is not a source-clearance blocker.\n\nThis review read selected source, retained primary receipts and immutable capture records, with standard-library hash/XML/data checks. It did not import proposed code, compile, execute Cargo, run actors/tests, access APIs, mutate root, inspect caches broadly or reproduce the Windows failure. Selected exact inputs and machine findings are retained alongside this report.\n'''
(O/'REVIEW.md').write_text(report)
shutil.copyfile('/tmp/japp-review-windows-manifest-source-20261019.py',O/'review-source.py')
manifest=[]
for q in sorted(O.rglob('*')):
 if q.is_file():b=q.read_bytes();manifest.append({'path':q.relative_to(O).as_posix(),'bytes':len(b),'sha256':H(b)})
(O/'review-members.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'verdict':verdict,'checks':len(checks),'report':str(O/'REVIEW.md'),'report_sha256':H((O/'REVIEW.md').read_bytes()),'findings_sha256':H((O/'findings.json').read_bytes()),'manifest_sha256':H((O/'review-members.json').read_bytes())},indent=2))
