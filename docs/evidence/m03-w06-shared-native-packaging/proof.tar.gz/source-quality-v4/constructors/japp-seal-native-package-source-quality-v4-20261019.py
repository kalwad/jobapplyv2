from pathlib import Path
import ast,difflib,hashlib,json,shutil,stat
BASE=Path('/tmp/japp-m03-w06-shared-native-package-source-join-660f-20261019')
QUALITY=Path('/tmp/japp-m03-w06-native-package-static-quality-20261019')
WORK=QUALITY/'work'
OUT=Path('/tmp/japp-m03-w06-shared-native-package-source-quality-v4-20261019')
HELPER=Path('/tmp/japp-m03-w06-native-helper-typing-composition-20261019')
CHILD=Path('/tmp/japp-m03-w06-native-package-strict-source-scope-20261019')
if OUT.exists():raise SystemExit('fresh finite source packet required')
OUT.mkdir()
def sha(data):return hashlib.sha256(data).hexdigest()
def put(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def copy(source,target):
 info=source.lstat()
 if not stat.S_ISREG(info.st_mode) or source.is_symlink():raise ValueError('safe regular source only')
 target.parent.mkdir(parents=True,exist_ok=True);data=source.read_bytes();target.write_bytes(data)
 assert target.read_bytes()==data
files=sorted(p.relative_to(BASE/'afterimages').as_posix() for p in (BASE/'afterimages').rglob('*') if p.is_file())
assert len(files)==15 and sum(n.endswith('.py') for n in files)==12
patch='';bindings={}
for name in files:
 source=WORK/name
 if not name.endswith('.py'):
  assert source.read_bytes()==(BASE/'afterimages'/name).read_bytes()
 copy(source,OUT/'afterimages'/name)
 old=BASE/'preimages'/name
 before=old.read_bytes() if old.exists() else b''
 after=source.read_bytes()
 patch+=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='a/'+name if old.exists() else '/dev/null',tofile='b/'+name))
 bindings[name]={'action':'MODIFY' if old.exists() else 'ADD','base_preimage_sha256':sha(before) if old.exists() else None,'after_sha256':sha(after),'after_bytes':len(after)}
(OUT/'SOURCE_JOIN.patch').write_text(patch)
for p in (BASE/'preimages').rglob('*'):
 if p.is_file():copy(p,OUT/'preimages'/p.relative_to(BASE/'preimages'))
for name in ['CURRENT_PREIMAGES.json','DEFERRED_ASSETS.json','PROTECTED_CURRENT_SOURCE.json','source-manifest.json']:
 copy(BASE/name,OUT/'parent-inputs'/name)
copy(Path('/tmp/japp-m03-w06-native-helper-portability-source-v2-20261019/source-manifest.json'),OUT/'parent-inputs/helper-portability-source-manifest.json')
copy(Path('/tmp/japp-m03-w06-native-helper-portability-root-review-v2-20261019/review.json'),OUT/'parent-inputs/helper-portability-root-review.json')
# Retain complete finite source/observer histories and actual static receipts,
# expressly excluding all mutable tool caches and the duplicated working tree.
excluded={'work','uv-cache','ruff-cache','mypy-cache'}
for p in sorted(QUALITY.rglob('*')):
 rel=p.relative_to(QUALITY)
 if rel.parts[0] in excluded or not p.is_file():continue
 copy(p,OUT/'quality-history'/rel)
for p in sorted(CHILD.rglob('*')):
 if p.is_file():copy(p,OUT/'test-source-correspondence'/p.relative_to(CHILD))
helper_manifest=json.loads((HELPER/'retention-manifest.json').read_text())
# The author manifest formats have a closed list or files mapping. All selected
# originals are small source/receipts; reject caches explicitly regardless.
for p in sorted(HELPER.rglob('*')):
 rel=p.relative_to(HELPER)
 if p.is_file() and not any('cache' in part.lower() for part in rel.parts):
  copy(p,OUT/'helper-author-packet'/rel)
helper_pin='7371248344a87e537cb66cd8ef4650fb521440088be1bd75573dcf3ee5960b1d'
assert sha((WORK/'scripts/_native_package_process.py').read_bytes())==helper_pin
assert all((WORK/n).read_text().count(helper_pin)==1 for n in ['scripts/native_package_ci.py','scripts/tests/test_native_package_pending_owner.py'])
latest=QUALITY/'phase-7-final-module-registration'
for name in ['ruff','mypy','format-check']:
 result=json.loads((latest/(name+'.result.json')).read_text())
 assert result['exit_code']==0 and result['group']=='GONE' and result['owned_child_reaped'] and not result['signals'] and not result['timed_out']
 for suffix in ['stdout','stderr']:
  data=(latest/(name+'.'+suffix)).read_bytes();assert len(data)==result[suffix]['bytes'] and sha(data)==result[suffix]['sha256']
for name in files:
 if name.endswith('.py'):
  assert (latest/'after'/name).read_bytes()==(WORK/name).read_bytes()
  ast.parse((WORK/name).read_text())
put(OUT/'POSTIMAGES.json',{'base_head':'660f9f1deea129ceccba48c9d560daf1791a95ff','base_tree':'be68bdb19d7de4948dba354a4f13543572c5b517','base_tracked_paths':1961,'postimages':bindings,'required_binary_assets':'DEFERRED; see parent-inputs/DEFERRED_ASSETS.json','canonical_adoption':'NONE'})
put(OUT/'STATIC_RESULTS.json',{'scope':'All12 proposed Python files explicitly checked; source-only tools do not execute subjects or tests','final_receipt_directory':'quality-history/phase-7-final-module-registration','ruff':{'exit_code':0,'findings':0},'mypy':{'exit_code':0,'checked_source_files':12},'format_check':{'exit_code':0},'all_owned_groups':'GONE','all_owned_children_reaped':True,'cleanup_signals':0,'initial_ruff_findings':751,'initial_mypy_errors':346,'intermediate_failures':'Retained verbatim with preimages, argv/env/result and source observer corrections','policy_config_sha256':'a008c87d4cbc5eeffe686322be66924c657b1ded0a95ee011da35847d0930dee','source_tool_context':'Existing root uv --no-sync --offline and selected .venv; exact sanitized environment/argv retained; MYPYPATH supplies unchanged canonical dependency source context, no whole interpreter/cache image claim','test_or_collection_results':'NONE','runtime_native_gui_build_results':'NONE','deferred_wheels_copied':False,'different_peer':'PENDING_ROOT_REVIEW'})
(OUT/'HANDOFF.md').write_text('''# Shared foreign packaging source-quality proposal v4

SOURCE/STATIC ONLY — NOT ADOPTED, NOT TESTED, NO W07/W08 CERTIFICATION. This packet is a sparse current660f source join:15 text postimages (5 modifications/10 additions), including12 Python files, plus exact selected immutable preimages. Root's CommonControls build48b13d59/XML4636/PSd592 remain protected and absent from the patch. No document/state/gate/master/ADR/current inventory change is proposed.38VERIFIED/W06soleIN_PROGRESS remain the intended current state.

The immutable v3 packet remains historical. V4 adds only the exact private pipeline-module occupancy refusal and sys.modules identity registration before its authenticated exec; the new typed pipeline dataclass needs that registration. No actual dynamic import failure or actor execution was manufactured. The tiny correction patch and finding are retained in quality-history; final all12 static checks bind the corrected current bytes.

SOURCE_JOIN.patch is the single composed alternative against the immutable660f selected inputs; do not combine it with earlier whole join patches. All prior packets stay immutable. Exact final helper73712483 has the two literal consumer repins; its author packet and semantic map are retained separately from our integration changes. The helper's root-reviewed pathlib/default-PATH fix and later typed/Windows-boundary source remain source claims until different review and actual future evaluation.

Actual final strict static checks explicitly cover all12 Python postimages: Ruff0, mypy0(12 files), format-check0, unchanged copied root pyproject policy. Every owned static process reaped with groupGONE/no signals. Exact commands, environments, versions, stdout/stderr, source before/after and initial751Ruff/346mypy failures are retained. Intermediate partial-context import failures and documentary constructor/source corrections remain historical; final clean receipts bind exact current afterimages. No quality result is inferred from the historical seven mocks or from root's canonical full/CI.

Typing uses concrete records/validated consumed JSON/TOML fields, source-authenticated callable interfaces, and no blanket Any suppression. uv.lock metadata stays opaque until its original selection/consumption point; unused development/extra metadata is not newly refused. Ordered pipeline/CI coordinators retain narrow PLR0912/PLR0915 rationale rather than global rule changes. Curator's original branches/bounds/order are split into typed local state/helpers; thresholds remain exact. Imports and formatting retain their own before/after receipts.

The original23 recipe input and7 pending-owner testcase identities, mocks, finalizers and ownership/oracle conditions are retained. Required unittest→pytest changes have46 explicit correspondences;21 same-class refusal checks now additionally assert their exact fixed refusal category, and the duplicate warning additionally asserts its fixed identity. Typed keyword records preserve the same optional/default scenario controls and complete process interface. All25 CI mutation cases/order and original assertions are mapped;41 old core-policy functions remain byte-exact. These are source assertions, not collected/executed results. All original7 mock/raw outcomes remain historical; final tests need actual canonical-style execution after peer review.

Two exact pure project wheel bodies227795bytes remain DEFERRED by root instruction. Their original paths/hashes/sizes are in parent-inputs/DEFERRED_ASSETS.json. No dependency install/resolution, wheel rebuild/copy, test collection/execution, actor/native/compiler/browser, canonical write or Git mutation occurred here. Root may review the exact final delta and oracle maps, authorize the two exact wheel copies, then perform meaningful focused tests and strict full collection/inventory derivation. New Python totals must come from actual unique collected IDs; preserve old IDs/POSIX-only distinction and retain actual failures. A later full/CI result applies only to its actual source. This packet confers no foreign GUI/install/platform acceptance, milestone promotion or owner decision.
''')
(OUT/'constructors').mkdir()
copy(Path(__file__),OUT/'constructors'/Path(__file__).name)
records={};payload=0
for p in sorted(OUT.rglob('*')):
 if not p.is_file():continue
 info=p.lstat()
 if p.is_symlink() or not stat.S_ISREG(info.st_mode):raise ValueError('safe regular payload only')
 data=p.read_bytes();payload+=len(data)
 if payload>32*1024*1024:raise ValueError('finite source packet bound')
 records[p.relative_to(OUT).as_posix()]={'bytes':len(data),'sha256':sha(data)}
put(OUT/'source-manifest.json',{'state':'SOURCE_STATIC_GREEN_DIFFERENT_PEER_PENDING_NO_EXECUTION','self_excluded':'source-manifest.json','files':records,'payload_file_count':len(records),'payload_bytes':payload,'authority':'NONE','runtime_or_test_execution':'NONE','binary_assets':'DEFERRED'})
print(json.dumps({'output':str(OUT),'patch_sha256':sha((OUT/'SOURCE_JOIN.patch').read_bytes()),'manifest_sha256':sha((OUT/'source-manifest.json').read_bytes()),'payload_files':len(records),'payload_bytes':payload,'helper_sha256':helper_pin},indent=2))
