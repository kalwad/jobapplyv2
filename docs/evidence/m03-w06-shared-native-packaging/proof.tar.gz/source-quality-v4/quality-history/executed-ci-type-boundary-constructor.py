from pathlib import Path
import ast,json
BASE=Path('/tmp/japp-m03-w06-native-package-static-quality-20261019')
p=BASE/'work/scripts/native_package_ci.py'
b=p.read_text()
if (BASE/'before-type-boundaries/scripts/native_package_ci.py').read_text()!=b:
 raise SystemExit('CI working preimage changed')
b=b.replace('import contextlib\n','import contextlib\nfrom collections.abc import Callable, Mapping, Sequence\nfrom dataclasses import dataclass\n',1)
b=b.replace('import traceback\n','import traceback\nfrom typing import TYPE_CHECKING, TypedDict, cast\n\nif TYPE_CHECKING:\n    from native_package_pipeline import Budget, FilePin, ProcessHelper, ToolPin\n',1)
old='''TRACE = None
SEQUENCE = 0
PROCESS = None
DEADLINES = None
'''
new='''class SourceFile(TypedDict):
    sha256: str
    bytes: int
    mode: str


class SourceProjection(TypedDict):
    head: str
    tree: str
    files: dict[str, SourceFile]


@dataclass
class _CoordinatorState:
    trace: Path | None = None
    process: ProcessHelper | None = None
    deadlines: Budget | None = None
    sequence: int = 0


_STATE = _CoordinatorState()


def _context() -> tuple[Path, ProcessHelper, Budget]:
    if _STATE.trace is None or _STATE.process is None or _STATE.deadlines is None:
        raise ValueError("Native coordinator command context is not initialized")
    return _STATE.trace, _STATE.process, _STATE.deadlines


def _wheel_pins(value: object) -> dict[str, FilePin]:
    if not isinstance(value, dict):
        raise ValueError("Project wheel manifest must be an object")
    result: dict[str, FilePin] = {}
    for role in ("contracts", "orchestrator"):
        row = value.get(role)
        if not isinstance(row, dict):
            raise ValueError("Project wheel role must be an object")
        path, pin = row.get("path"), row.get("sha256")
        if not isinstance(path, str) or not isinstance(pin, str):
            raise ValueError("Project wheel role requires text path and digest")
        result[role] = {"path": path, "sha256": pin}
    return result


'''
assert old in b;b=b.replace(old,new)
repls={
'def load_process_helper():':'def load_process_helper() -> ProcessHelper:',
'    return module\n\n\ndef sha(path):':'    for attribute in ("budget", "_validate_budget", "run"):\n        if not callable(getattr(module, attribute, None)):\n            raise ValueError("Pinned native process interface missing")\n    return cast("ProcessHelper", module)\n\n\ndef sha(path: str | Path) -> str:',
'''    identity = lambda row: (
        row.st_dev,
        row.st_ino,
        row.st_size,
        row.st_mtime_ns,
        row.st_mode,
    )''':'''    def identity(row: os.stat_result) -> tuple[int, int, int, int, int]:
        return (row.st_dev, row.st_ino, row.st_size, row.st_mtime_ns, row.st_mode)''',
'def dump(path, value):':'def dump(path: Path, value: object) -> None:',
'def tool(name):':'def tool(name: str) -> ToolPin:',
'''def raw(argv, cwd, env, *, cleanup=False):
    global SEQUENCE
    SEQUENCE += 1
    stem = "ci-command-" + str(SEQUENCE).zfill(3)
    deadlines = dict(DEADLINES)''':'''def raw(
    argv: Sequence[str | Path], cwd: Path, env: Mapping[str, str], *, cleanup: bool = False
) -> bytes:
    trace, process, budget = _context()
    _STATE.sequence += 1
    stem = "ci-command-" + str(_STATE.sequence).zfill(3)
    deadlines = budget.copy()''',
'    result = PROCESS.run(':'    result = process.run(',
'        stem=TRACE / stem,':'        stem=trace / stem,',
'def projection(source, git, env, require_clean=True, *, cleanup=False):':'def projection(\n    source: Path, git: str, env: Mapping[str, str], require_clean: bool = True,\n    *, cleanup: bool = False,\n) -> SourceProjection:',
'    files = {}':'    files: dict[str, SourceFile] = {}',
'            DEADLINES["cleanup_deadline"] - 5 if cleanup else DEADLINES["work_deadline"]':'            _context()[2]["cleanup_deadline"] - 5 if cleanup else _context()[2]["work_deadline"]',
'def main():\n    global TRACE, PROCESS, DEADLINES':'def main() -> None:',
'    TRACE = proof\n    PROCESS = load_process_helper()\n    DEADLINES = PROCESS.budget()':'    _STATE.trace = proof\n    _STATE.process = load_process_helper()\n    deadlines = _STATE.process.budget()\n    _STATE.deadlines = deadlines',
'            "deadlines": dict(DEADLINES),':'            "deadlines": dict(deadlines),',
'    outcome = {':'    outcome: dict[str, object] = {',
'        role_tools = {':'        role_tools: dict[str, ToolPin] = {',
'''        wheel_manifest = json.loads(
            (work / "packaging/native-project-wheels.json").read_text()
        )''':'''        wheel_manifest = _wheel_pins(json.loads(
            (work / "packaging/native-project-wheels.json").read_text()
        ))''',
'        wheels = {}':'        wheels: dict[str, FilePin] = {}',
'''        module_spec.loader.exec_module(module)
        if sha(pipeline_path)''':'''        module_spec.loader.exec_module(module)
        if sha(pipeline_path)''',
'        function_result = {':'        function_result: dict[str, object] = {',
'                            module.main(proof / "native-inputs.json")':'                            entry = getattr(module, "main", None)\n                            if not callable(entry):\n                                raise ValueError("Pinned pipeline entry point missing")\n                            cast(Callable[[Path], None], entry)(proof / "native-inputs.json")',
'        outcome["whole_deadlines"] = dict(DEADLINES)':'        outcome["whole_deadlines"] = dict(deadlines)',
'            time.monotonic() < DEADLINES["cleanup_deadline"]':'            time.monotonic() < deadlines["cleanup_deadline"]',
}
for old,new in repls.items():
 if old not in b:raise AssertionError(old)
 b=b.replace(old,new)
p.write_text(b);ast.parse(b)
(BASE/'executed-ci-type-boundary-constructor.py').write_bytes(Path(__file__).read_bytes())
(BASE/'ci-type-boundary-source-status.derived.json').write_text(json.dumps({'state':'SOURCE_EDITS_IN_PROGRESS_UNVALIDATED','scope':'CI coordinator only; typed source/tool/wheel records and pinned callable interfaces; explicit state object replaces four untyped globals','uninitialized_context':'fails before any command; initialized call ordering and process/deadline objects retained','tests_imports_actors':'NONE','checks_on_current_bytes':'NOT_RUN'},indent=2)+'\n')
print('CI_SOURCE_EDITS_ONLY')
