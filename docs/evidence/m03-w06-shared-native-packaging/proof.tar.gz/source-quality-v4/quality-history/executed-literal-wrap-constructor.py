from pathlib import Path
import ast,json
BASE=Path('/tmp/japp-m03-w06-native-package-static-quality-20261019')
WORK=BASE/'work';H=BASE/'before-literal-wrap';H.mkdir()
files=[p for p in WORK.rglob('*.py') if p.name!='_native_package_process.py']
rows=[]
for p in files:
 b=p.read_text();tree=ast.parse(b);lines=b.splitlines(keepends=True);starts=[];n=0
 for line in lines:starts.append(n);n+=len(line)
 parents={child:node for node in ast.walk(tree) for child in ast.iter_child_nodes(node)}
 edits=[]
 for node in ast.walk(tree):
  if not isinstance(node,ast.Constant) or not isinstance(node.value,(str,bytes)) or len(node.value)<64:continue
  parent=parents.get(node);joined=False
  while parent is not None:
   if isinstance(parent,ast.JoinedStr):joined=True;break
   parent=parents.get(parent)
  if joined:continue
  if not any(len(line.rstrip('\n'))>88 for line in lines[node.lineno-1:node.end_lineno]):continue
  a=starts[node.lineno-1]+node.col_offset;z=starts[node.end_lineno-1]+node.end_col_offset
  indent=' '*(min(node.col_offset,16)+4)
  chunks=[node.value[i:i+40] for i in range(0,len(node.value),40)]
  replacement='(\n'+'\n'.join(indent+repr(v) for v in chunks)+'\n'+' '*min(node.col_offset,16)+')'
  edits.append((a,z,replacement))
 if not edits:continue
 for a,z,value in sorted(edits,reverse=True):b=b[:a]+value+b[z:]
 assert ast.dump(tree,include_attributes=False)==ast.dump(ast.parse(b),include_attributes=False)
 target=H/p.relative_to(WORK);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes());p.write_text(b)
 rows.append({'path':p.relative_to(WORK).as_posix(),'constant_representations_wrapped':len(edits),'entire_ast_equal':True})
# Only module prose wraps; no testcase/function contents change.
p=WORK/'scripts/tests/test_native_package_inputs.py';b=p.read_text()
old='"""UNEXECUTED source counterexamples. No real tool, package, process or network actor."""'
if old in b:
 b=b.replace(old,'"""UNEXECUTED source counterexamples.\n\nNo real tool, package, process or network actor.\n"""');p.write_text(b)
(BASE/'literal-wrap-preservation.derived.json').write_text(json.dumps({'state':'SOURCE_ONLY_UNVALIDATED','literal_ast_equality':rows,'module_docstring_only_wrap':'test_native_package_inputs.py; no test/function content change','subject_execution':'NONE'},indent=2)+'\n')
(BASE/'executed-literal-wrap-constructor.py').write_bytes(Path(__file__).read_bytes())
print('LITERAL_SOURCE_WRAP_ONLY',len(rows))
