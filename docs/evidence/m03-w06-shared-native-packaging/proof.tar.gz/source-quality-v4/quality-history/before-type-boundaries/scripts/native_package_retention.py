"""UNEXECUTED finite artifact curation. No project imports or payload execution."""

from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import stat
import sys
import zipfile

MAX_TOTAL = 1024 * 1024 * 1024
MAX_FILE = 512 * 1024 * 1024
MAX_FILES = 4096


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        while data := stream.read(65536):
            value.update(data)
    return value.hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--proof", type=Path, required=True)
    p.add_argument("--sdk", type=Path, required=True)
    args = p.parse_args()
    base = args.proof.resolve()
    sdk = args.sdk.resolve()
    output = base / "retained"
    if not base.is_absolute() or output.exists():
        raise ValueError("Fresh finite retention directory required")
    base.mkdir(exist_ok=True)
    output.mkdir()
    selected = {}
    total = 0

    def keep(source, relative):
        nonlocal total
        info = source.lstat()
        if (
            not stat.S_ISREG(info.st_mode)
            or getattr(info, "st_file_attributes", 0) & 0x400
        ):
            raise ValueError("Regular evidence only")
        if (
            info.st_size > MAX_FILE
            or total + info.st_size > MAX_TOTAL
            or len(selected) >= MAX_FILES
        ):
            raise ValueError("Finite retention bound exceeded")
        path = output / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, path)
        pin = digest(source)
        if digest(path) != pin:
            raise ValueError("Retention copy changed")
        selected[relative] = {
            "bytes": info.st_size,
            "sha256": pin,
            "original": str(source),
        }
        total += info.st_size

    # Top-level worker receipts/raw output; no environment/cache/target inventory.
    for path in sorted(base.iterdir()):
        if path.is_file() and (
            path.suffix in {".json", ".stdout", ".stderr"}
            or path.name == "owned-command-helper.py"
        ):
            keep(path, "worker/" + path.name)
    preflight = base / "pipeline-preflight"
    if preflight.is_dir():
        for path in sorted(preflight.iterdir()):
            if path.is_file() and path.suffix in {".json", ".stdout", ".stderr"}:
                keep(path, "pipeline-preflight/" + path.name)
    tool_roles = {}
    tool_images = {}
    pins = base / "native-inputs.json"
    if pins.is_file():
        spec = json.loads(pins.read_text())
        allowed = {
            "python",
            "uv",
            "node",
            "pnpm_js",
            "build_pnpm",
            "cargo",
            "rustc",
            "cargo_real",
            "rustc_real",
            "rustup",
            "git",
            "dumpbin",
            "dpkg_deb",
        }
        if set(spec["tools"]) - allowed:
            raise ValueError("Unexpected retained tool role")
        for role, row in spec["tools"].items():
            source = Path(row["resolved_path"])
            if not source.is_absolute() or digest(source) != row["sha256"]:
                raise ValueError("Pinned tool image changed before retention")
            if row["sha256"] not in tool_images:
                relative = "tool-images/" + row["sha256"] + "-" + source.name
                keep(source, relative)
                tool_images[row["sha256"]] = relative
            tool_roles[role] = {
                "invocation": row["path"],
                "resolved_path": row["resolved_path"],
                "sha256": row["sha256"],
                "retained": tool_images[row["sha256"]],
            }
    pipeline = base / "pipeline"
    if pipeline.is_dir():
        for path in sorted(pipeline.iterdir()):
            if path.is_file() and (
                path.suffix
                in {".json", ".stdout", ".stderr", ".rs", ".txt", ".lock", ".py"}
            ):
                keep(path, "pipeline/" + path.name)
        runtime = pipeline / "runtime-build"
        if runtime.is_dir():
            for path in sorted(runtime.iterdir()):
                if path.is_file() and path.suffix in {
                    ".json",
                    ".stdout",
                    ".stderr",
                    ".py",
                }:
                    keep(path, "runtime-build/" + path.name)
            if (runtime / "inputs").is_dir():
                for path in sorted((runtime / "inputs").iterdir()):
                    if path.is_file():
                        keep(path, "runtime-build/inputs/" + path.name)
        for directory in ("deb-inspection",):
            if (pipeline / directory).is_dir():
                for path in sorted((pipeline / directory).iterdir()):
                    if path.is_file():
                        keep(path, directory + "/" + path.name)
        packages = list((pipeline / "target/debug/bundle/deb").glob("*.deb"))
        if len(packages) > 4:
            raise ValueError("Unexpected package count")
        for path in packages:
            keep(path, "packages/" + path.name)
        portable = pipeline / "portable"
        if portable.is_dir():
            # Retain the actual complete delivered folder once, not build caches.
            archive = base / "windows-portable.zip"
            nodes = 0
            size = 0
            with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED) as target:
                for path in sorted(portable.rglob("*")):
                    info = path.lstat()
                    nodes += 1
                    if nodes > 2048:
                        raise ValueError("Portable node bound")
                    if (
                        path.is_symlink()
                        or getattr(info, "st_file_attributes", 0) & 0x400
                    ):
                        raise ValueError("Portable reparse member")
                    if path.is_dir():
                        continue
                    if not stat.S_ISREG(info.st_mode):
                        raise ValueError("Portable regular member required")
                    size += info.st_size
                    if size > 512 * 1024 * 1024:
                        raise ValueError("Portable byte bound")
                    target.write(path, path.relative_to(portable).as_posix())
            keep(archive, "packages/windows-portable.zip")
        image = pipeline / "actor-image.json"
        if image.is_file():
            row = json.loads(image.read_text())
            path = Path(row["path"]).resolve()
            target = (pipeline / "target").resolve()
            if target not in path.parents or digest(path) != row["sha256"]:
                raise ValueError("Actor image reference escaped or changed")
            keep(path, "native-helper/" + path.name)
    if sdk.is_dir():
        for path in sorted(sdk.iterdir()):
            if path.is_file():
                keep(path, "sdk/" + path.name)
    manifest = {
        "scope": "Finite selected raw/build/package/helper evidence; no whole TEMP, target, cache or interpreter image",
        "files": selected,
        "file_count": len(selected),
        "bytes": total,
        "subject_execution": False,
        "selected_tool_image_roles": tool_roles,
        "whole_tool_shared_library_or_SDK_closure_claimed": False,
        "curator": {
            "path": str(Path(__file__)),
            "sha256": digest(Path(__file__)),
            "python": sys.executable,
            "version": sys.version,
        },
    }
    (output / "manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
