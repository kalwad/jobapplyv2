from pathlib import Path
import ast
import hashlib
import json
OUT=Path('/tmp/japp-m03-w06-native-package-static-quality-20261019')
WORK=OUT/'work'
HISTORY=OUT/'before-type-boundaries'
HISTORY.mkdir(exist_ok=True)
paths=['scripts/native_package_pipeline.py','scripts/native_package_ci.py','scripts/native_package_retention.py','scripts/wheel_only_runtime_lock.py']
for n in paths:
 p=HISTORY/n;p.parent.mkdir(parents=True,exist_ok=True)
 if not p.exists():p.write_bytes((WORK/n).read_bytes())
p=WORK/'scripts/wheel_only_runtime_lock.py'
b=(HISTORY/'scripts/wheel_only_runtime_lock.py').read_text();b=b.replace('def make(lock: Path, exported: Path, destination: Path) -> dict:', 'def make(lock: Path, exported: Path, destination: Path) -> dict[str, object]:')
assert b.count('(marker or "").rstrip()')==1
b=b.replace('(marker or "").rstrip()', '""')
p.write_text(b);ast.parse(b)
p=WORK/'scripts/native_package_pipeline.py';b=(HISTORY/'scripts/native_package_pipeline.py').read_text()
b=b.replace('import argparse\n','import argparse\nfrom collections.abc import Callable, Mapping, Sequence\n',1)
b=b.replace('import stat\n','import stat\nimport subprocess\n',1)
b=b.replace('import zipfile\n','import zipfile\nfrom typing import Protocol, TypedDict, cast\n',1)
anchor='BOUND = 512 * 1024 * 1024\n'
defs='''class Budget(TypedDict):
    work_deadline: int | float
    cleanup_deadline: int | float


class FilePin(TypedDict):
    path: str
    sha256: str


class ToolPin(FilePin):
    resolved_path: str


class WheelCodeReceipt(TypedDict):
    wheel_sha256: str
    source_package_files: int
    source_python_files: int
    all_package_file_bytes_equal: bool
    installer_surface_restricted: bool


class ProcessHelper(Protocol):
    def budget(self) -> Budget: ...

    def _validate_budget(self, value: Budget) -> None: ...

    def run(
        self,
        argv: Sequence[str | Path],
        *,
        cwd: Path,
        env: Mapping[str, str],
        stem: Path,
        seconds: float,
        deadlines: Budget,
    ) -> subprocess.CompletedProcess[bytes]: ...


class PipelineSpec(TypedDict):
    deadlines: Budget
    preflight_proof: str
    canonical_root: str
    owned_checkout: str
    output: str
    target: str
    expected_git_head: str
    source_projection: dict[str, str]
    proposal_bindings: dict[str, str]
    tools: dict[str, ToolPin]
    contracts_wheel: FilePin
    orchestrator_wheel: FilePin
    build_environment: dict[str, str]
    host_inventory_reference: FilePin


def _record(value: object) -> dict[str, object]:
    if not isinstance(value, dict):
        raise ValueError("Native record must be an object")
    result: dict[str, object] = {}
    for name, item in value.items():
        if not isinstance(name, str):
            raise ValueError("Native record names must be text")
        result[name] = item
    return result


def _text(value: object) -> str:
    if not isinstance(value, str):
        raise ValueError("Native record field must be text")
    return value


def _text_record(value: object) -> dict[str, str]:
    return {name: _text(item) for name, item in _record(value).items()}


def _file_pin(value: object) -> FilePin:
    row = _text_record(value)
    if set(row) != {"path", "sha256"}:
        raise ValueError("Exact file pin required")
    return {"path": row["path"], "sha256": row["sha256"]}


def _tool_pin(value: object) -> ToolPin:
    row = _text_record(value)
    if set(row) != {"path", "resolved_path", "sha256"}:
        raise ValueError("Exact invocation and physical tool pin required")
    return {"path": row["path"], "resolved_path": row["resolved_path"], "sha256": row["sha256"]}


def _budget(value: object) -> Budget:
    row = _record(value)
    if set(row) != {"work_deadline", "cleanup_deadline"}:
        raise ValueError("Exact native work/cleanup budget required")
    work, cleanup = row["work_deadline"], row["cleanup_deadline"]
    if not isinstance(work, (int, float)) or not isinstance(cleanup, (int, float)):
        raise ValueError("Native deadlines must be numeric")
    return {"work_deadline": work, "cleanup_deadline": cleanup}


def _pipeline_spec(value: object) -> PipelineSpec:
    row = _record(value)
    return {
        "deadlines": _budget(row["deadlines"]),
        "preflight_proof": _text(row["preflight_proof"]),
        "canonical_root": _text(row["canonical_root"]),
        "owned_checkout": _text(row["owned_checkout"]),
        "output": _text(row["output"]),
        "target": _text(row["target"]),
        "expected_git_head": _text(row["expected_git_head"]),
        "source_projection": _text_record(row["source_projection"]),
        "proposal_bindings": _text_record(row["proposal_bindings"]),
        "tools": {name: _tool_pin(item) for name, item in _record(row["tools"]).items()},
        "contracts_wheel": _file_pin(row["contracts_wheel"]),
        "orchestrator_wheel": _file_pin(row["orchestrator_wheel"]),
        "build_environment": _text_record(row["build_environment"]),
        "host_inventory_reference": _file_pin(row["host_inventory_reference"]),
    }


def _process_interface(value: object) -> ProcessHelper:
    for name in ("budget", "_validate_budget", "run"):
        if not callable(getattr(value, name, None)):
            raise ValueError("Pinned native process interface missing")
    # Source is authenticated before and after loading; this is its declared
    # callable interface, not permission to load an unpinned implementation.
    return cast(ProcessHelper, value)


'''
assert b.count(anchor)==1;b=b.replace(anchor,defs+anchor)
replacements={
'def sha(path):':'def sha(path: Path) -> str:',
'def dump(path, value):':'def dump(path: Path, value: object) -> None:',
'def bind(row):':'def bind(row: FilePin) -> Path:',
'def bind_tool(row):':'def bind_tool(row: ToolPin) -> Path:',
'def pinned_lock_helper(expected):':'def pinned_lock_helper(expected: str) -> Callable[[Path, Path, Path], dict[str, object]]:',
'    return module.make':'    make = getattr(module, "make", None)\n    if not callable(make):\n        raise ValueError("Pinned lock interface missing")\n    return cast(Callable[[Path, Path, Path], dict[str, object]], make)',
'def contained(path, root):':'def contained(path: Path, root: Path) -> bool:',
'    checkout, rows, git, env, expected_head, process, deadlines, proof, label\n):':'    checkout: Path, rows: Mapping[str, str], git: Path, env: Mapping[str, str],\n    expected_head: str, process: ProcessHelper, deadlines: Budget, proof: Path, label: str\n) -> None:',
'def wheel_code(wheel, source, namespace):':'def wheel_code(wheel: Path, source: Path, namespace: str) -> WheelCodeReceipt:',
'def pinned_process_helper(expected, canonical_root):':'def pinned_process_helper(expected: str, canonical_root: str) -> ProcessHelper:',
'        actual = Path(existing.__file__).resolve()':'        original_path = existing.__file__\n        if original_path is None:\n            raise ValueError("Pinned native process interface has no source")\n        actual = Path(original_path).resolve()',
'        return existing':'        return _process_interface(existing)',
'    return module\n\n\ndef main(spec_path=None):':'    return _process_interface(module)\n\n\ndef main(spec_path: Path | None = None) -> None:',
'    spec = json.loads(spec_path.read_text(encoding="utf-8"))':'    spec = _pipeline_spec(json.loads(spec_path.read_text(encoding="utf-8")))',
'    records = []':'    records: list[dict[str, object]] = []',
'    def run(label, argv, cwd=checkout, extra_env=None):':'    def run(\n        label: str, argv: Sequence[str | Path], cwd: Path = checkout,\n        extra_env: Mapping[str, str] | None = None,\n    ) -> bytes:',
'        for role, path in tools.items():':'        for role in tools:',
'                row = json.loads(result_path.read_text())':'                row = _record(json.loads(result_path.read_text()))',
'    pnpm = [node, tools["pnpm_js"]]':'    pnpm: list[str | Path] = [node, tools["pnpm_js"]]',
'    command = [\n':'    command: list[str | Path] = [\n',
'    build = pnpm + [':'    build: list[str | Path] = pnpm + [',
}
for old,new in replacements.items():
 if old not in b:raise AssertionError(('missing replacement',old))
 b=b.replace(old,new)
# This source parser is used only for retained compiler records, never execution.
old='''    messages = [
        json.loads(line)
        for line in (output / "13-package-actor-compile.stdout")
        .read_text()
        .splitlines()
        if line.startswith("{")
    ]
    executables = [
        Path(x["executable"])
        for x in messages
        if x.get("reason") == "compiler-artifact"
        and x.get("executable")
        and x.get("target", {}).get("name") == "japp_desktop"
    ]'''
new='''    messages = [
        _record(json.loads(line))
        for line in (output / "13-package-actor-compile.stdout")
        .read_text()
        .splitlines()
        if line.startswith("{")
    ]
    executables: list[Path] = []
    for message in messages:
        target_record = message.get("target", {})
        if (message.get("reason") == "compiler-artifact" and message.get("executable")
                and _record(target_record).get("name") == "japp_desktop"):
            executables.append(Path(_text(message["executable"])))'''
assert old in b;b=b.replace(old,new)
p.write_text(b);ast.parse(b)
(OUT/'executed-type-boundary-constructor.py').write_bytes(Path(__file__).read_bytes())
(OUT/'type-boundary-source-status.derived.json').write_text(json.dumps({'state':'SOURCE_EDITS_IN_PROGRESS_UNVALIDATED','changed':['scripts/wheel_only_runtime_lock.py','scripts/native_package_pipeline.py'],'other_two_owned_preimages_retained':paths[1:3],'new_guards':'TypedDict/Protocol, text/record/file/tool/spec field validation; authenticated callable interfaces','policy_changed':False,'imports_tests_compilation_native':'NONE','static_checks_on_new_bytes':'NOT_RUN'},indent=2)+'\n')
print('SOURCE_BOUNDARY_EDITS_ONLY')
