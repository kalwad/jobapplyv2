from pathlib import Path
import ast,json,re
BASE=Path('/tmp/japp-m03-w06-native-package-static-quality-20261019')
WORK=BASE/'work';H=BASE/'before-sparse-static-fixes';H.mkdir()
paths=['scripts/native_package_ci.py','scripts/native_package_pipeline.py','scripts/tests/test_native_package_inputs.py','scripts/tests/test_native_package_pending_owner.py']
for n in paths:
 p=H/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((WORK/n).read_bytes())
# Explicit keyword records describe the exact unchanged callable contract.
p=WORK/'scripts/native_package_pipeline.py';b=p.read_text()
b=b.replace('from typing import Protocol, TypedDict, cast','from typing import Protocol, TypedDict, Unpack, cast')
old='''class ProcessHelper(Protocol):
    def budget(self) -> Budget: ...

    def _validate_budget(self, value: Budget) -> None: ...

    def run(
        self,
        argv: Sequence[str | Path],
        *,
        cwd: Path,
        env: Mapping[str, str],
        stem: Path,
        seconds: float,
        deadlines: Budget,
    ) -> subprocess.CompletedProcess[bytes]: ...'''
new='''class _RunOptions(TypedDict):
    cwd: Path
    env: Mapping[str, str]
    stem: Path
    seconds: float
    deadlines: Budget


class ProcessHelper(Protocol):
    def budget(self) -> Budget: ...

    def _validate_budget(self, value: Budget) -> None: ...

    def run(
        self, argv: Sequence[str | Path], **options: Unpack[_RunOptions]
    ) -> subprocess.CompletedProcess[bytes]: ...'''
assert old in b;b=b.replace(old,new)
a=b.index('def wheel_code(')
insert='''def _checked_wheel_name(member: zipfile.ZipInfo, names: set[str]) -> str:
    name = member.filename
    part = PurePosixPath(name)
    if name in names or part.is_absolute() or ".." in part.parts or "\\\\" in name:
        raise ValueError("Unsafe wheel member")
    names.add(name)
    return name


'''
b=b[:a]+insert+b[a:]
old='''            name = member.filename
            part = PurePosixPath(name)
            if (
                name in names
                or part.is_absolute()
                or ".." in part.parts
                or "\\\\" in name
            ):
                raise ValueError("Unsafe wheel member")
            names.add(name)'''
new='''            name = _checked_wheel_name(member, names)'''
assert old in b;b=b.replace(old,new);p.write_text(b);ast.parse(b)
p=WORK/'scripts/native_package_ci.py';b=p.read_text()
b=b.replace('"""UNEXECUTED future CI coordinator. Dedicated runner; original source stays read-only."""','"""UNEXECUTED future CI coordinator on a dedicated runner.\n\nOriginal source stays read-only.\n"""')
b=b.replace('def main() -> None:\n','''# Ordered setup/function/final-source closure share one explicit owner context.
# Preserve that chronology rather than split it for branch/statement counts.
def main() -> None:  # noqa: PLR0912, PLR0915
''',1)
b=b.replace('os.environ["ProgramFiles(x86)"]','os.environ["PROGRAMFILES(X86)"]')
p.write_text(b);ast.parse(b)
# Preserve existing error classes and every old condition; add precise fixed
# refusal category messages rather than meaningless broad match patterns.
p=WORK/'scripts/tests/test_native_package_inputs.py';b=p.read_text();tree=ast.parse(b)
messages={
 'test_missing_runtime_dependency_is_refused':'Empty or duplicated export',
 'test_extra_development_dependency_is_refused':'Export differs from the exact locked runtime closure',
 'test_unlocked_version_is_refused':'Export version is not locked',
 'test_direct_url_is_refused':'Non-exact requirement in locked runtime export',
 'test_sdist_only_lock_is_refused':'Exact runtime wheel hash unavailable',
 'test_normalized_duplicate_names_are_refused':'Empty or duplicated export',
 'test_export_cannot_disable_current_unconditional_dependency':'Unconditional runtime export cannot disable a dependency',
 'test_conditional_graph_is_not_silently_selected':'Conditional or extra runtime graph needs explicit selection',
 'test_existing_lock_output_is_preserved':'Fresh output required',
 'test_missing_module_is_refused':'Wheel package files differ from exact current source',
 'test_changed_nonpython_package_resource_is_refused':'Wheel package files differ from exact current source',
 'test_top_level_pth_install_surface_is_refused':'Undeclared wheel install surface',
 'test_data_script_install_surface_is_refused':'Undeclared wheel install surface',
 'test_unexpected_entrypoint_metadata_is_refused':'Undeclared wheel install surface',
 'test_duplicate_wheel_member_is_refused':'Unsafe wheel member',
 'test_symlink_wheel_member_is_refused':'Wheel member must be a regular file',
 'test_foreign_python_namespace_is_refused':'Undeclared wheel install surface',
 'test_traversal_member_is_refused':'Unsafe wheel member',
 'test_native_binary_member_is_refused':'Pure code input required',
 'test_changed_helper_is_refused_before_any_loader':'Reviewed lock helper changed before import',
 'test_tool_alias_must_resolve_to_the_pinned_physical_image':'Native tool alias or image changed',
}
lines=b.splitlines(keepends=True);starts=[];offset=0
for line in lines:starts.append(offset);offset+=len(line)
edits=[];correspondence=[]
for fn in ast.walk(tree):
 if not isinstance(fn,ast.FunctionDef) or fn.name not in messages:continue
 for node in ast.walk(fn):
  if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and isinstance(node.func.value,ast.Name) and node.func.value.id=='pytest' and node.func.attr=='raises':
   assert len(node.args)==1 and isinstance(node.args[0],ast.Name) and node.args[0].id=='ValueError' and not node.keywords
   end=starts[node.end_lineno-1]+node.end_col_offset-1
   match='^'+re.escape(messages[fn.name])+'$'
   edits.append((end,', match='+repr(match)))
   correspondence.append({'case':fn.name,'old_exception':'ValueError','new_exception':'ValueError','additional_message_match':match,'old_body_conditions':'retained; no existing assertion removed','observed_execution':'NONE'})
assert len(correspondence)==len(messages)==21
for pos,s in sorted(edits,reverse=True):b=b[:pos]+s+b[pos:]
b=b.replace('pytest.warns(UserWarning)', 'pytest.warns(UserWarning, match='+repr("^Duplicate name: 'orchestrator/__init__\\.py'$")+')')
b=b.replace('''        with zipfile.ZipFile(wheel, "a") as out:
            with pytest.warns(UserWarning, match='^Duplicate name: \\'orchestrator/__init__\\\\.py\\'$'):
                out.writestr("orchestrator/__init__.py", b"VALUE=1\\n")''','''        with (
            zipfile.ZipFile(wheel, "a") as out,
            pytest.warns(UserWarning, match="^Duplicate name: 'orchestrator/__init__\\\\.py'$"),
        ):
            out.writestr("orchestrator/__init__.py", b"VALUE=1\\n")''')
# Combine nested loader contexts with the same entry/exit ordering.
b=b.replace('''        with patch(
            "native_package_pipeline.importlib.util.spec_from_file_location",
            side_effect=AssertionError("LOADER_MUST_NOT_RUN"),
        ):
            with pytest.raises(ValueError, match='^Reviewed\\ lock\\ helper\\ changed\\ before\\ import$'):
                pinned_lock_helper("0" * 64)''','''        with (
            patch(
                "native_package_pipeline.importlib.util.spec_from_file_location",
                side_effect=AssertionError("LOADER_MUST_NOT_RUN"),
            ),
            pytest.raises(ValueError, match='^Reviewed\\ lock\\ helper\\ changed\\ before\\ import$'),
        ):
            pinned_lock_helper("0" * 64)''')
p.write_text(b);ast.parse(b)
(BASE/'precise-refusal-message-correspondence.derived.json').write_text(json.dumps({'state':'SOURCE_ONLY_NEW_ORACLE_STRENGTHENING_UNEXECUTED','changes':correspondence,'warning':{'old':'UserWarning','new':'UserWarning with fixed zipfile duplicate-member category match'},'test_identities':'same23 input cases; no skips, weakened condition, secondlaunch or signal introduced','source_purpose':'Retain exact error-class assertions plus meaningful refusal identity for unchanged strict PT011/PT030; no catch-all regex or rule waiver'},indent=2)+'\n')
# Typed optional keyword controls keep all seven existing calls/defaults intact.
p=WORK/'scripts/tests/test_native_package_pending_owner.py';b=p.read_text()
b=b.replace('from typing import Protocol, TypedDict, runtime_checkable','from typing import Protocol, TypedDict, Unpack, runtime_checkable')
anchor='@runtime_checkable\nclass _ProcessHelper(Protocol):\n'
insert='''class _RunOptions(TypedDict):
    cwd: Path
    env: Mapping[str, str]
    stem: Path
    seconds: float
    deadlines: _Deadlines


class _Interventions(TypedDict, total=False):
    pidfd: int | None
    proc_error: OSError | None
    pidfd_error: OSError | None
    launch_error: OSError | None
    reaped: bool


'''
assert anchor in b;b=b.replace(anchor,insert+anchor)
old='''    def run(
        self,
        argv: Sequence[str],
        *,
        cwd: Path,
        env: Mapping[str, str],
        stem: Path,
        seconds: float,
        deadlines: _Deadlines,
    ) -> CompletedProcess[bytes]: ...'''
new='''    def run(
        self, argv: Sequence[str], **options: Unpack[_RunOptions]
    ) -> CompletedProcess[bytes]: ...'''
assert old in b;b=b.replace(old,new)
old='''        pidfd: int | None = None,
        proc_error: OSError | None = None,
        pidfd_error: OSError | None = None,
        launch_error: OSError | None = None,
        reaped: bool = False,
    ) -> None:
        h = self.helper'''
new='''        **options: Unpack[_Interventions],
    ) -> None:
        if set(options) - {"pidfd", "proc_error", "pidfd_error", "launch_error", "reaped"}:
            raise TypeError("Unexpected counterproof intervention")
        pidfd = options.get("pidfd")
        proc_error = options.get("proc_error")
        pidfd_error = options.get("pidfd_error")
        launch_error = options.get("launch_error")
        reaped = options.get("reaped", False)
        h = self.helper'''
assert old in b;b=b.replace(old,new);p.write_text(b);ast.parse(b)
# Repin only the sealed helper; no helper write occurs here.
helper=(WORK/'scripts/_native_package_process.py').read_bytes()
import hashlib
helper_pin=hashlib.sha256(helper).hexdigest()
assert helper_pin=='7371248344a87e537cb66cd8ef4650fb521440088be1bd75573dcf3ee5960b1d'
for n in ['scripts/native_package_ci.py','scripts/tests/test_native_package_pending_owner.py']:
 p=WORK/n;b=p.read_text();old='ee3ae0f7c945abe27fff7f6b2325f14ae4acfeff1bb80364d53675816a5d30f8'
 assert b.count(old)==1;b=b.replace(old,helper_pin);p.write_text(b)
(BASE/'sealed-helper-pin-composition.derived.json').write_text(json.dumps({'sealed_helper_sha256':helper_pin,'old_formatted_helper_sha256':'ee3ae0f7c945abe27fff7f6b2325f14ae4acfeff1bb80364d53675816a5d30f8','exact_one_repin_each':['scripts/native_package_ci.py','scripts/tests/test_native_package_pending_owner.py'],'helper_written':False,'tests_or_imports':'NONE'},indent=2)+'\n')
(BASE/'executed-sparse-static-fix-constructor.py').write_bytes(Path(__file__).read_bytes())
print('SPARSE_SOURCE_FIXES_ONLY')
