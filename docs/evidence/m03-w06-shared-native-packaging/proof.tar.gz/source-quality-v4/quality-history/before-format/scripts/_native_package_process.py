"""Unexecuted native package command custody; standard library only.

Windows owns suspended-process/thread/Job handles; Ubuntu owns a fresh session
keeper and pidfds. Escaped Ubuntu sessions are explicitly outside observation.
No function dispatches at import. A nonzero/uncertain cleanup never becomes PASS.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import threading
import time
import traceback

WORK_SECONDS = 2700
CLEANUP_SECONDS = 60
COMMAND_CLEANUP_SECONDS = 15
MAX_CAPTURE = 64 * 1024 * 1024
MAX_SESSION_MEMBERS = 512
_PENDING_WINDOWS_OWNERS = []
_PENDING_LINUX_OWNERS = []


def _write(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def _sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(65536), b''):
            digest.update(block)
    return digest.hexdigest()


_SOURCE_SHA = _sha(__file__)


def budget():
    now = time.monotonic()
    return {'work_deadline': now + WORK_SECONDS,
            'cleanup_deadline': now + WORK_SECONDS + CLEANUP_SECONDS}


def _validate_budget(value):
    if set(value) != {'work_deadline', 'cleanup_deadline'}:
        raise ValueError('Exact native work/cleanup budget required')
    work, close = value['work_deadline'], value['cleanup_deadline']
    if not all(type(x) in (int, float) and math.isfinite(x) for x in (work, close)):
        raise ValueError('Finite native deadlines required')
    if not 0 < close - work <= CLEANUP_SECONDS or close - time.monotonic() > WORK_SECONDS + CLEANUP_SECONDS:
        raise ValueError('Native deadline policy exceeded')


class _Capture:
    def __init__(self, stdout_path, stderr_path):
        self.lock = threading.Lock()
        self.total = 0
        self.discarded = 0
        self.errors = []
        self.overflow = threading.Event()
        self.threads = []
        self.readers = []
        self.writers = []
        for path in (stdout_path, stderr_path):
            read, write = os.pipe()
            self.readers.append(read)
            self.writers.append(write)
            sink = Path(path).open('xb', buffering=0)
            thread = threading.Thread(target=self._drain, args=(read, sink), daemon=True)
            self.threads.append(thread)

    def _drain(self, descriptor, sink):
        try:
            while block := os.read(descriptor, 16384):
                with self.lock:
                    remaining = max(0, MAX_CAPTURE - self.total)
                    retained = block[:remaining]
                    if retained:
                        sink.write(retained)
                        self.total += len(retained)
                    self.discarded += len(block) - len(retained)
                    if len(retained) != len(block):
                        self.overflow.set()
        except BaseException as error:
            self.errors.append({'type': type(error).__name__, 'message': str(error)})
            self.overflow.set()
        finally:
            sink.close()
            os.close(descriptor)

    def start(self):
        for thread in self.threads:
            thread.start()

    def close_parent_writers(self):
        while self.writers:
            os.close(self.writers.pop())

    def finish(self):
        self.close_parent_writers()
        for thread in self.threads:
            thread.join(timeout=1)
        # A blocked daemon retains its own descriptor; do not race-close/reuse it.
        return {'captured_bytes': self.total, 'discarded_bytes': self.discarded,
                'overflow': self.overflow.is_set(), 'errors': self.errors,
                'readers_closed': not any(thread.is_alive() for thread in self.threads)}


def _proc(pid):
    try:
        with (Path('/proc') / str(pid) / 'stat').open('rb') as stream:
            body = stream.read(16385)
        if len(body) > 16384:
            raise ValueError('Bounded process identity required')
        left, right = body.rsplit(b') ', 1)
        fields = right.split()
        return {'pid': int(left.split(b' (', 1)[0]), 'pgid': int(fields[2]),
                'sid': int(fields[3]), 'birth': int(fields[19])}
    except FileNotFoundError:
        return None


def _session_members(sid):
    result = []
    inspected = 0
    for name in os.listdir('/proc'):
        if not name.isdecimal():
            continue
        inspected += 1
        if inspected > 65536:
            raise ValueError('Bounded /proc inventory required')
        row = _proc(int(name))
        if row is not None and row['sid'] == sid:
            result.append(row)
            if len(result) > MAX_SESSION_MEMBERS:
                raise ValueError('Owned session member bound exceeded')
    return result


def _pidfd(row):
    try:
        descriptor = os.pidfd_open(row['pid'])
    except ProcessLookupError:
        return None
    if _proc(row['pid']) != row:
        os.close(descriptor)
        return None
    return descriptor


def _signal_session(saved_keeper, sig, receipts):
    if _proc(saved_keeper['pid']) != saved_keeper:
        raise ValueError('Owned live session witness changed')
    for row in _session_members(saved_keeper['sid']):
        if row['pid'] == saved_keeper['pid']:
            continue
        descriptor = _pidfd(row)
        if descriptor is None:
            continue
        try:
            signal.pidfd_send_signal(descriptor, sig)
            receipts.append({'identity': row, 'signal': signal.Signals(sig).name,
                             'authority': 'held_pidfd_after_same_owned_session_identity'})
        except ProcessLookupError:
            pass
        finally:
            os.close(descriptor)


def _settle_session(saved_keeper, deadline, child=None):
    result = {'signals': [], 'session_members_absent': False,
              'escaped_sessions': 'UNOBSERVED'}
    for sig, grace in ((signal.SIGTERM, 3), (signal.SIGKILL, 3)):
        if child is not None:
            child.poll()
        if not [r for r in _session_members(saved_keeper['sid']) if r['pid'] != saved_keeper['pid']]:
            result['session_members_absent'] = True
            break
        _signal_session(saved_keeper, sig, result['signals'])
        until = min(deadline, time.monotonic() + grace)
        while time.monotonic() < until:
            if child is not None:
                child.poll()
            others = [r for r in _session_members(saved_keeper['sid']) if r['pid'] != saved_keeper['pid']]
            if not others:
                result['session_members_absent'] = True
                break
            time.sleep(.02)
        if result['session_members_absent']:
            break
    result['remaining'] = [r for r in _session_members(saved_keeper['sid']) if r['pid'] != saved_keeper['pid']]
    result['session_members_absent'] = not result['remaining']
    return result


def _linux_worker(control):
    c = json.loads(Path(control).read_text())
    if c['helper_sha256'] != _sha(__file__):
        raise ValueError('Owned keeper source changed before tool launch')
    if not hasattr(os, 'pidfd_open') or not hasattr(signal, 'pidfd_send_signal'):
        raise ValueError('Native Ubuntu pidfd capability required; no PID fallback')
    own = _proc(os.getpid())
    if own is None or own['pid'] != own['pgid'] or own['pid'] != own['sid']:
        raise ValueError('Fresh owned session leader required')
    lease = c['lease_fd']
    os.set_blocking(lease, False)
    child = None
    result = {'keeper': own, 'command': c['argv'], 'exit_code': None,
              'timed_out': False, 'parent_lease_closed': False,
              'escaped_sessions': 'UNOBSERVED'}
    try:
        _write(c['launch'], {'keeper': own, 'command_argv': c['argv'], 'utc_ns': time.time_ns()})
        child = subprocess.Popen(c['argv'], cwd=c['cwd'], env=c['environment'],
                                 stdin=subprocess.DEVNULL, stdout=c['stdout_fd'],
                                 stderr=c['stderr_fd'], shell=False, process_group=0)
        os.close(c['stdout_fd']); os.close(c['stderr_fd'])
        result['owned_direct_child_pid'] = child.pid
        while child.poll() is None:
            try:
                if os.read(lease, 1) == b'':
                    result['parent_lease_closed'] = True
                    break
            except BlockingIOError:
                pass
            if time.monotonic() >= c['deadline']:
                result['timed_out'] = True
                break
            time.sleep(.02)
        result['exit_code'] = child.poll()
    except BaseException as error:
        result['failure'] = {'type': type(error).__name__, 'message': str(error)}
        result['traceback'] = traceback.format_exc()
    finally:
        # Keep this live session witness until every observed same-session child
        # is closed. This includes service-created groups within the session.
        try:
            result['cleanup'] = _settle_session(own, c['cleanup_deadline'], child)
            if child is not None:
                try:
                    result['exit_code'] = child.wait(timeout=max(.01, min(2, c['cleanup_deadline']-time.monotonic())))
                    result['direct_child_reaped'] = True
                except subprocess.TimeoutExpired:
                    result['direct_child_reaped'] = False
        except BaseException as error:
            result['cleanup_error'] = {'type': type(error).__name__, 'message': str(error)}
        os.close(lease)
        _write(c['result'], result)
    return 0 if (result.get('exit_code') == 0 and not result.get('failure') and
                 not result['timed_out'] and not result['parent_lease_closed'] and
                 result.get('direct_child_reaped') and
                 result.get('cleanup', {}).get('session_members_absent') and
                 not result.get('cleanup', {}).get('signals')) else 1


class _WindowsJob:
    """CreateProcessW owns hProcess/hThread; Popen thread ownership is not assumed."""
    def __init__(self, argv, cwd, env, writers):
        import ctypes as C
        from ctypes import wintypes as W
        import msvcrt
        self.C = C; self.W = W
        self.k = C.WinDLL('kernel32', use_last_error=True)
        self.job = self.process = self.thread = None
        self.assigned = False
        self.inherited = []; self.attributes = None
        self.attributes_initialized = False
        self.launch_failure = None
        SIZE = C.c_size_t
        class BASIC(C.Structure):
            _fields_ = [('process_time', C.c_int64), ('job_time', C.c_int64), ('flags', W.DWORD),
                        ('min_ws', SIZE), ('max_ws', SIZE), ('active_limit', W.DWORD),
                        ('affinity', SIZE), ('priority', W.DWORD), ('scheduling', W.DWORD)]
        class IO(C.Structure):
            _fields_ = [(name, C.c_uint64) for name in ('read_ops','write_ops','other_ops','read_bytes','write_bytes','other_bytes')]
        class LIMIT(C.Structure):
            _fields_ = [('basic', BASIC), ('io', IO), ('process_memory', SIZE), ('job_memory', SIZE), ('peak_process', SIZE), ('peak_job', SIZE)]
        class ACCOUNT(C.Structure):
            _fields_ = [(name, C.c_int64) for name in ('user','kernel','period_user','period_kernel')] + [(name,W.DWORD) for name in ('faults','total','active','terminated')]
        class START(C.Structure):
            _fields_ = [('cb', W.DWORD),('reserved',W.LPWSTR),('desktop',W.LPWSTR),('title',W.LPWSTR)] + [(name,W.DWORD) for name in ('x','y','xsize','ysize','xchars','ychars','fill','flags')] + [('show',W.WORD),('reserved_bytes',W.WORD),('reserved_data',C.c_void_p),('stdin',W.HANDLE),('stdout',W.HANDLE),('stderr',W.HANDLE)]
        class STARTEX(C.Structure):
            _fields_ = [('start',START),('attributes',C.c_void_p)]
        class PROCESS(C.Structure):
            _fields_ = [('process',W.HANDLE),('thread',W.HANDLE),('pid',W.DWORD),('tid',W.DWORD)]
        self.ACCOUNT = ACCOUNT
        signatures = {
            'CreateJobObjectW': ([C.c_void_p,W.LPCWSTR],W.HANDLE),
            'SetInformationJobObject': ([W.HANDLE,C.c_int,C.c_void_p,W.DWORD],W.BOOL),
            'QueryInformationJobObject': ([W.HANDLE,C.c_int,C.c_void_p,W.DWORD,C.c_void_p],W.BOOL),
            'TerminateJobObject': ([W.HANDLE,W.UINT],W.BOOL),
            'AssignProcessToJobObject': ([W.HANDLE,W.HANDLE],W.BOOL),
            'CloseHandle': ([W.HANDLE],W.BOOL), 'GetCurrentProcess': ([],W.HANDLE),
            'DuplicateHandle': ([W.HANDLE,W.HANDLE,W.HANDLE,C.POINTER(W.HANDLE),W.DWORD,W.BOOL,W.DWORD],W.BOOL),
            'InitializeProcThreadAttributeList': ([C.c_void_p,W.DWORD,W.DWORD,C.POINTER(SIZE)],W.BOOL),
            'UpdateProcThreadAttribute': ([C.c_void_p,W.DWORD,SIZE,C.c_void_p,SIZE,C.c_void_p,C.c_void_p],W.BOOL),
            'DeleteProcThreadAttributeList': ([C.c_void_p],None),
            'CreateProcessW': ([W.LPCWSTR,W.LPWSTR,C.c_void_p,C.c_void_p,W.BOOL,W.DWORD,C.c_void_p,W.LPCWSTR,C.c_void_p,C.c_void_p],W.BOOL),
            'ResumeThread': ([W.HANDLE],W.DWORD), 'TerminateProcess': ([W.HANDLE,W.UINT],W.BOOL),
            'WaitForSingleObject': ([W.HANDLE,W.DWORD],W.DWORD),
            'GetExitCodeProcess': ([W.HANDLE,C.POINTER(W.DWORD)],W.BOOL),
        }
        for name,(args,result) in signatures.items():
            function = getattr(self.k,name); function.argtypes=args; function.restype=result
        try:
            self.job = self.k.CreateJobObjectW(None,None)
            if not self.job: raise C.WinError(C.get_last_error())
            limits = LIMIT(); limits.basic.flags = 0x2000  # KILL_ON_JOB_CLOSE
            self._ok(self.k.SetInformationJobObject(self.job,9,C.byref(limits),C.sizeof(limits)))
            with open(os.devnull,'rb',buffering=0) as null:
                raw = [msvcrt.get_osfhandle(null.fileno()),*(msvcrt.get_osfhandle(fd) for fd in writers)]
                current = self.k.GetCurrentProcess()
                for handle in raw:
                    duplicate = W.HANDLE()
                    self._ok(self.k.DuplicateHandle(current,handle,current,C.byref(duplicate),0,True,2))
                    self.inherited.append(duplicate.value)
            size=SIZE()
            self.k.InitializeProcThreadAttributeList(None,1,0,C.byref(size))
            if not size.value: raise C.WinError(C.get_last_error())
            self.storage=C.create_string_buffer(size.value)
            self.attributes=C.cast(self.storage,C.c_void_p)
            self._ok(self.k.InitializeProcThreadAttributeList(self.attributes,1,0,C.byref(size)))
            self.attributes_initialized = True
            inherited=(W.HANDLE*3)(*self.inherited)
            self._ok(self.k.UpdateProcThreadAttribute(self.attributes,0,0x20002,C.cast(inherited,C.c_void_p),C.sizeof(inherited),None,None))
            startup=STARTEX();startup.start.cb=C.sizeof(startup);startup.start.flags=0x100
            startup.start.stdin,startup.start.stdout,startup.start.stderr=self.inherited
            startup.attributes=self.attributes
            command=C.create_unicode_buffer(subprocess.list2cmdline(argv))
            environment=C.create_unicode_buffer('\0'.join(k+'='+v for k,v in sorted(env.items(),key=lambda item:item[0].casefold()))+'\0\0')
            created=PROCESS()
            # Suspended: no command code runs before assignment to the held Job.
            self._ok(self.k.CreateProcessW(argv[0],command,None,None,True,0x4|0x80000|0x400,environment,str(cwd),C.byref(startup),C.byref(created)))
            self.process,self.thread=created.process,created.thread
            self.pid,self.tid=int(created.pid),int(created.tid)
            self._ok(self.k.AssignProcessToJobObject(self.job,self.process))
            self.assigned = True
            if self.k.ResumeThread(self.thread) != 1: raise C.WinError(C.get_last_error())
            self._ok(self.k.CloseHandle(self.thread));self.thread=None
        except BaseException as error:
            self.launch_failure={'type':type(error).__name__,'message':str(error)}
            if self.process:
                self.k.TerminateProcess(self.process,125)
                self.k.WaitForSingleObject(self.process,3000)
            if self.job: self.k.TerminateJobObject(self.job,125)
            # The caller already retains this object before __init__. Even a
            # partial launch remains owned until its finally observes closure.
            raise
        finally:
            if self.attributes_initialized:
                self.k.DeleteProcThreadAttributeList(self.attributes);self.attributes=None
                self.attributes_initialized=False
            self.inherited=[handle for handle in self.inherited if not self.k.CloseHandle(handle)]

    def _ok(self,value):
        if not value: raise self.C.WinError(self.C.get_last_error())

    def poll(self):
        observed=self.k.WaitForSingleObject(self.process,0)
        if observed==258: return None
        if observed!=0: raise self.C.WinError(self.C.get_last_error())
        code=self.W.DWORD();self._ok(self.k.GetExitCodeProcess(self.process,self.C.byref(code)))
        return int(code.value)

    def active(self):
        data=self.ACCOUNT();self._ok(self.k.QueryInformationJobObject(self.job,1,self.C.byref(data),self.C.sizeof(data),None))
        return int(data.active)

    def settle(self,deadline):
        if self.process is None:
            return {'held_job':bool(self.job),'terminated_job':False,'job_active_processes':0,
                    'direct_exit':None,'all_job_members_closed':True,'no_process_created':True}
        active=self.active() if self.assigned else 0
        terminated=active!=0 or self.poll() is None
        if self.assigned and active:self._ok(self.k.TerminateJobObject(self.job,125))
        if not self.assigned and self.poll() is None:self._ok(self.k.TerminateProcess(self.process,125))
        while time.monotonic()<deadline and (self.poll() is None or (self.assigned and self.active())):time.sleep(.02)
        active=self.active() if self.assigned else 0
        return {'held_job':True,'assigned_before_resume':self.assigned,'terminated_job':terminated,'job_active_processes':active,
                'direct_exit':self.poll(),'all_job_members_closed':active==0 and self.poll() is not None,
                'outside_job_descendants':'UNOBSERVED'}

    def close(self):
        self.inherited=[handle for handle in self.inherited if not self.k.CloseHandle(handle)]
        for name in ('thread','process','job'):
            value=getattr(self,name,None)
            if value:self._ok(self.k.CloseHandle(value));setattr(self,name,None)
        if self.inherited:raise RuntimeError('Owned inherited native handles remain unclosed')


def run(argv, *, cwd, env, stem, seconds, deadlines):
    """One command; returncode is original only after zero-intervention closure."""
    _validate_budget(deadlines)
    if _PENDING_WINDOWS_OWNERS or _PENDING_LINUX_OWNERS:
        raise RuntimeError('Prior native command owner remains unresolved')
    if _sha(__file__) != _SOURCE_SHA:
        raise ValueError('Pinned command helper source changed')
    if not math.isfinite(seconds) or not 0<seconds<=WORK_SECONDS:
        raise ValueError('Finite command budget required')
    argv=[str(x) for x in argv];cwd=Path(cwd);stem=Path(stem)
    if not argv or not Path(argv[0]).is_absolute() or not cwd.is_absolute() or not stem.is_absolute():
        raise ValueError('Explicit native argv/cwd/evidence required')
    if any('\0' in x for x in argv) or any(not isinstance(v,str) or '\0' in k+v for k,v in env.items()):
        raise ValueError('Native command contains invalid text')
    start=time.monotonic();until=min(deadlines['work_deadline'],start+seconds)
    if start>=until:raise TimeoutError('Whole native pipeline work deadline exhausted')
    close_until=min(deadlines['cleanup_deadline'],until+COMMAND_CLEANUP_SECONDS)
    record={'argv':argv,'cwd':str(cwd),'environment':dict(env),'seconds':seconds,
            'work_deadline':until,'cleanup_deadline':close_until,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'escaped_sessions_or_jobs':'UNOBSERVED'}
    _write(str(stem)+'.upfront.json',record)
    capture=_Capture(str(stem)+'.stdout',str(stem)+'.stderr');capture.start()
    child=windows=None;lease=None;keeper=None;keeper_fd=None;failure=None;exit_code=None;cleanup={}
    try:
        if sys.platform=='win32':
            # Retain the owner before __init__ so partially created suspended
            # hProcess/hThread handles remain reachable on every exception.
            windows=object.__new__(_WindowsJob)
            windows.__init__(argv,cwd,dict(env),capture.writers)
            if windows.inherited:raise RuntimeError('Native inherited-handle cleanup failed after launch')
            _write(str(stem)+'.launch.json',{'kind':'SUSPENDED_THEN_ASSIGNED_JOB_AND_RESUMED','pid':windows.pid,'primary_thread_id':windows.tid,'handles_retained':True})
            capture.close_parent_writers()
            while (exit_code:=windows.poll()) is None:
                if time.monotonic()>=until:raise TimeoutError('Native command work deadline')
                if capture.overflow.is_set():raise ValueError('Native command output cap')
                time.sleep(.02)
            cleanup=windows.settle(min(close_until,time.monotonic()+COMMAND_CLEANUP_SECONDS))
        elif sys.platform=='linux':
            if not hasattr(os,'pidfd_open') or not hasattr(signal,'pidfd_send_signal'):raise ValueError('Ubuntu pidfds required')
            read,lease=os.pipe()
            control={'argv':argv,'cwd':str(cwd),'environment':dict(env),'deadline':until,'cleanup_deadline':close_until,'helper_sha256':_SOURCE_SHA,
                     'lease_fd':read,'stdout_fd':capture.writers[0],'stderr_fd':capture.writers[1],
                     'launch':str(stem)+'.command-launch.json','result':str(stem)+'.session-result.json'}
            _write(str(stem)+'.session-input.json',control)
            with open(str(stem)+'.keeper.stdout','xb') as stdout,open(str(stem)+'.keeper.stderr','xb') as stderr:
                try:
                    child=subprocess.Popen([sys.executable,'-I','-S','-B',str(Path(__file__).resolve()),'--linux-worker',str(stem)+'.session-input.json'],
                                           cwd=cwd,env={'PATH':os.defpath},stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,
                                           start_new_session=True,pass_fds=(read,*capture.writers))
                finally:os.close(read)
                keeper=_proc(child.pid)
                if keeper is None or keeper['sid']!=child.pid or keeper['pgid']!=child.pid:raise ValueError('Owned keeper session unavailable')
                keeper_fd=_pidfd(keeper)
                if keeper_fd is None:raise ValueError('Held keeper pidfd unavailable')
                _write(str(stem)+'.launch.json',{'kind':'OWNED_NEW_SESSION_KEEPER','identity':keeper,'keeper_argv':[sys.executable,'-I','-S','-B',str(Path(__file__).resolve()),'--linux-worker',str(stem)+'.session-input.json']})
                capture.close_parent_writers()
                while child.poll() is None:
                    if time.monotonic()>=until:raise TimeoutError('Native command work deadline')
                    if capture.overflow.is_set():raise ValueError('Native command output cap')
                    time.sleep(.02)
                session=json.loads(Path(str(stem)+'.session-result.json').read_text())
                exit_code=session['exit_code'];cleanup=session.get('cleanup',{})
                if child.returncode!=0 or session.get('failure') or session.get('timed_out') or session.get('parent_lease_closed') or not session.get('direct_child_reaped'):
                    raise RuntimeError('Owned session command or cleanup failed')
        else:raise ValueError('Only native Windows and Ubuntu execution is supported')
        if time.monotonic()>=until:raise TimeoutError('Command completed after work deadline')
    except BaseException as error:
        failure={'type':type(error).__name__,'message':str(error)}
        raise
    finally:
        cleanup_error=None
        final_until=min(close_until,time.monotonic()+COMMAND_CLEANUP_SECONDS)
        try:
            if lease is not None:os.close(lease);lease=None
            if windows is not None and hasattr(windows,'job'):
                final=windows.settle(final_until)
                cleanup={**cleanup,**final,'terminated_job':cleanup.get('terminated_job',False) or final['terminated_job']}
                if final['all_job_members_closed']:windows.close()
                else:_PENDING_WINDOWS_OWNERS.append(windows)
            if child is not None:
                while child.poll() is None and time.monotonic()<final_until:time.sleep(.02)
                if child.poll() is None and keeper is not None and keeper_fd is not None:
                    cleanup=_settle_session(keeper,final_until)
                    signal.pidfd_send_signal(keeper_fd,signal.SIGKILL)
                try:child.wait(timeout=max(.01,min(2,final_until-time.monotonic())))
                except subprocess.TimeoutExpired:pass
                cleanup['keeper_reaped']=child.poll() is not None
                cleanup['session_absent']=keeper is not None and not _session_members(keeper['sid'])
        except BaseException as error:
            cleanup_error={'type':type(error).__name__,'message':str(error)}
            if windows is not None and (any(getattr(windows,name,None) for name in ('process','job','thread')) or getattr(windows,'inherited',[])) and windows not in _PENDING_WINDOWS_OWNERS:
                _PENDING_WINDOWS_OWNERS.append(windows)
        finally:
            # Successful Popen transfers an owner even if the later identity
            # or pidfd acquisition fails. Keep that exact Popen and any partial
            # native identity/handle until closure is proved; no PID fallback.
            # Pre-pidfd refusal is quarantined even if the direct child exits:
            # it never established the required held native session authority.
            if child is not None and not (keeper_fd is not None and cleanup.get('keeper_reaped') and cleanup.get('session_absent')):
                _PENDING_LINUX_OWNERS.append((child,keeper_fd,keeper))
                cleanup['launched_owner_retained']=True
                cleanup['held_pidfd_owner_retained']=keeper_fd is not None
            elif keeper_fd is not None:
                os.close(keeper_fd)
            captured=capture.finish()
            closed=(cleanup.get('all_job_members_closed') if sys.platform=='win32' else cleanup.get('session_absent') and cleanup.get('keeper_reaped'))
            intervened=cleanup.get('terminated_job',False) or bool(cleanup.get('signals'))
            ok=exit_code==0 and failure is None and cleanup_error is None and closed and not intervened and captured['readers_closed'] and not captured['overflow'] and not captured['errors']
            record.update(exit_code=exit_code,success=bool(ok),failure=failure,cleanup_error=cleanup_error,containment=cleanup,capture=captured,
                          seconds_elapsed=time.monotonic()-start,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                          stdout_sha256=_sha(str(stem)+'.stdout'),stderr_sha256=_sha(str(stem)+'.stderr'))
            if windows is not None:
                record['native_launch_failure']=getattr(windows,'launch_failure',None)
                record['retained_inherited_handle_count']=len(getattr(windows,'inherited',[]))
            _write(str(stem)+'.result.json',record)
    if not record['success']:raise RuntimeError('Native command or contained cleanup failed: '+str(stem))
    return subprocess.CompletedProcess(argv,exit_code,Path(str(stem)+'.stdout').read_bytes(),Path(str(stem)+'.stderr').read_bytes())


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--linux-worker',required=True)
    raise SystemExit(_linux_worker(parser.parse_args().linux_worker))
