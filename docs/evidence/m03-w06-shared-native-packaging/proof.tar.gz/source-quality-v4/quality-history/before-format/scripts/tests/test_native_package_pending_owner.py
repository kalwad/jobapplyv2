"""UNEXECUTED mock counterproofs; no native child is allowed to launch.

Future invocation requires its own resource release. This exercises the actual
run() failure/finally path with a held fake Popen. It is not Ubuntu native proof.
"""
from __future__ import annotations

import hashlib
import importlib.util
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock

HELPER = Path(__file__).resolve().parents[1] / '_native_package_process.py'
HELPER_SHA256 = '2655af3d14ae65a4390be5d1c8ef3a99442a77a65a4c83eac7f391fe816a83ea'


class _Clock:
    value = 100

    def monotonic(self):
        self.value += 1
        return self.value


class _HeldChild:
    pid = 43210

    def __init__(self, reaped=False):
        self.reaped = reaped

    def poll(self):
        return 0 if self.reaped else None

    def wait(self, timeout):
        if self.reaped:
            return 0
        raise subprocess.TimeoutExpired('mock held keeper', timeout)


class _Capture:
    def __init__(self, stdout, stderr):
        Path(stdout).write_bytes(b'')
        Path(stderr).write_bytes(b'')
        self.writers = [1, 2]  # Passed only to mocked Popen; never closed here.
        self.overflow = mock.Mock()
        self.overflow.is_set.return_value = False

    def start(self):
        pass

    def close_parent_writers(self):
        self.writers.clear()

    def finish(self):
        self.close_parent_writers()
        return {'captured_bytes': 0, 'discarded_bytes': 0, 'overflow': False,
                'errors': [], 'readers_closed': True}


class PendingBeforePidfd(unittest.TestCase):
    def setUp(self):
        self.assertEqual(hashlib.sha256(HELPER.read_bytes()).hexdigest(), HELPER_SHA256)
        spec = importlib.util.spec_from_file_location('_owned_pending_counterproof', HELPER)
        self.helper = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.helper)  # Future only; no dispatch at import.
        self.owned = tempfile.TemporaryDirectory(prefix='japp-pending-owner-mock-')
        self.addCleanup(self.owned.cleanup)
        self.root = Path(self.owned.name).resolve()

    def exercise(self, *, identity, pidfd=None, proc_error=None, pidfd_error=None,
                 launch_error=None, reaped=False):
        h = self.helper
        child = _HeldChild(reaped)
        clock = _Clock()
        opened = mock.Mock(return_value=child, side_effect=launch_error)
        read_proc = mock.Mock(return_value=identity, side_effect=proc_error)
        acquire = mock.Mock(return_value=pidfd, side_effect=pidfd_error)
        deadlines = {'work_deadline': 1000, 'cleanup_deadline': 1060}
        with mock.patch.object(h.sys, 'platform', 'linux'), \
             mock.patch.object(h, '_Capture', _Capture), \
             mock.patch.object(h.subprocess, 'Popen', opened), \
             mock.patch.object(h, '_proc', read_proc), \
             mock.patch.object(h, '_pidfd', acquire), \
             mock.patch.object(h, '_session_members', return_value=[]), \
             mock.patch.object(h, '_settle_session', side_effect=AssertionError('No acquired pidfd')) as settle, \
             mock.patch.object(h.os, 'pidfd_open', create=True), \
             mock.patch.object(h.signal, 'pidfd_send_signal', create=True) as native_signal, \
             mock.patch.object(h.time, 'monotonic', clock.monotonic), \
             mock.patch.object(h.time, 'sleep'):
            with self.assertRaises((ValueError, OSError)) as original:
                h.run([str(self.root / 'not-launched')], cwd=self.root, env={},
                      stem=self.root / 'first', seconds=1, deadlines=deadlines)
            self.assertEqual(opened.call_count, 1)
            native_signal.assert_not_called()
            settle.assert_not_called()
            if launch_error is not None:
                self.assertIs(original.exception, launch_error)
                self.assertEqual(h._PENDING_LINUX_OWNERS, [])
                return
            if proc_error is not None:
                self.assertIs(original.exception, proc_error)
            if pidfd_error is not None:
                self.assertIs(original.exception, pidfd_error)
            self.assertEqual(len(h._PENDING_LINUX_OWNERS), 1)
            saved_child, saved_fd, saved_identity = h._PENDING_LINUX_OWNERS[0]
            self.assertIs(saved_child, child)
            self.assertIsNone(saved_fd)
            self.assertEqual(saved_identity, identity if proc_error is None else None)
            with self.assertRaisesRegex(RuntimeError, 'Prior native command owner remains unresolved'):
                h.run([str(self.root / 'still-not-launched')], cwd=self.root, env={},
                      stem=self.root / 'second', seconds=1, deadlines=deadlines)
            self.assertEqual(opened.call_count, 1)
            native_signal.assert_not_called()
            self.assertIs(h._PENDING_LINUX_OWNERS[0][0], child)

    def test_missing_identity_retains_exact_launched_popen(self):
        self.exercise(identity=None)

    def test_mismatched_session_retains_exact_launched_popen(self):
        self.exercise(identity={'pid': 43210, 'pgid': 43210, 'sid': 999, 'birth': 7})

    def test_identity_read_error_retains_exact_launched_popen(self):
        self.exercise(identity=None, proc_error=OSError('mock identity unavailable'))

    def test_missing_pidfd_retains_exact_launched_popen(self):
        self.exercise(identity={'pid': 43210, 'pgid': 43210, 'sid': 43210, 'birth': 7})

    def test_pidfd_acquisition_error_retains_exact_launched_popen(self):
        self.exercise(identity={'pid': 43210, 'pgid': 43210, 'sid': 43210, 'birth': 7},
                      pidfd_error=OSError('mock pidfd unavailable'))

    def test_reaped_child_with_unvalidated_session_stays_quarantined(self):
        self.exercise(identity={'pid': 43210, 'pgid': 43210, 'sid': 999, 'birth': 7},
                      reaped=True)

    def test_failed_popen_does_not_invent_a_launched_owner(self):
        self.exercise(identity=None, launch_error=OSError('mock create failure'))


if __name__ == '__main__':
    unittest.main()
