"""Remove sdist approval from an actual uv --locked runtime export; no resolution."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re
import tomllib

def make(lock: Path, exported: Path, destination: Path) -> dict:
    if destination.exists():
        raise ValueError('Fresh output required')
    raw = exported.read_text(encoding='utf-8')
    resolved = tomllib.loads(lock.read_text(encoding='utf-8'))['package']
    packages = {(p['name'].lower().replace('_', '-'), p['version']): p for p in resolved}
    by_name = {p['name']:p for p in resolved}
    if len(by_name)!=len(resolved):
        raise ValueError('Version-disambiguated runtime graph needs explicit review')
    pending=['orchestrator','japp-contracts']; visited=set(); closure=set()
    while pending:
        name=pending.pop()
        if name in visited:continue
        visited.add(name); package=by_name[name]
        if name not in {'orchestrator','japp-contracts'}:
            if package.get('source')!={'registry':'https://pypi.org/simple'}:raise ValueError('Unexpected runtime source')
            closure.add((name.lower().replace('_','-'),package['version']))
        for dependency in package.get('dependencies',[]):
            if set(dependency)!={'name'}:raise ValueError('Conditional or extra runtime graph needs explicit selection')
            pending.append(dependency['name'])
    selected = []
    for line in raw.splitlines():
        value = line.strip()
        if not value or value.startswith(('#', '--hash=')):
            continue
        match = re.fullmatch(r'([A-Za-z0-9_.-]+)==([^ ;\\]+)(\s*;\s*[^\\]+)?\s*\\?', value)
        if match is None:
            raise ValueError('Non-exact requirement in locked runtime export')
        name, version, marker = match.groups()
        if marker is not None:raise ValueError('Unconditional runtime export cannot disable a dependency')
        identity = (name.lower().replace('_', '-'), version)
        if identity not in packages:raise ValueError('Export version is not locked')
        package = packages[identity]
        if package.get('source') != {'registry': 'https://pypi.org/simple'}:
            raise ValueError('Non-PyPI runtime dependency')
        hashes = sorted({w['hash'] for w in package.get('wheels', [])})
        if not hashes or any(re.fullmatch(r'sha256:[0-9a-f]{64}', h) is None for h in hashes):
            raise ValueError('Exact runtime wheel hash unavailable')
        selected.append((name, version, (marker or '').rstrip(), hashes))
    if not selected or len({(x[0].lower().replace('_','-'), x[1]) for x in selected}) != len(selected):
        raise ValueError('Empty or duplicated export')
    if {(n.lower().replace('_','-'),v) for n,v,_,_ in selected}!=closure:
        raise ValueError('Export differs from the exact locked runtime closure')
    lines = ['# Derived from actual uv --locked --no-dev --no-emit-workspace export.',
             '# Only uv.lock wheel hashes retained; no sdist is authorized.']
    for name, version, marker, hashes in selected:
        lines.append(name + '==' + version + marker + ' \\')
        for index, value in enumerate(hashes):
            lines.append('    --hash=' + value + (' \\' if index + 1 < len(hashes) else ''))
    destination.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return {'uv_lock_sha256': hashlib.sha256(lock.read_bytes()).hexdigest(),
            'actual_export_sha256': hashlib.sha256(exported.read_bytes()).hexdigest(),
            'wheel_only_sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
            'packages': [{'name': n, 'version': v, 'marker': m, 'wheel_hashes': h} for n,v,m,h in selected],
            'resolution_performed': False, 'sdist_hashes_authorized': 0}

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('lock', 'exported', 'destination', 'receipt'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    result = make(a.lock, a.exported, a.destination)
    a.receipt.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
