"""The optional native-package recipe cannot weaken canonical CI policy."""

from __future__ import annotations

from copy import deepcopy
from typing import Any

import check_portability
import pytest
from test_ci_workflow import load_ci


def package_job(workflow: dict[str, Any]) -> dict[str, Any]:
    return workflow["jobs"]["native_package_development"]


def test_package_job_has_exact_bounded_contract() -> None:
    workflow = load_ci()
    assert check_portability._native_package_job_valid(workflow)
    violations: list[check_portability.Violation] = []
    required = check_portability._check_matrix(workflow, violations)
    assert required == ("verify", workflow["jobs"]["verify"])
    assert violations == []


@pytest.mark.parametrize(
    "case",
    [
        "needs", "runs_on", "latest", "fail_fast", "extra_axis", "timeout",
        "job_if", "defaults", "permissions", "continue_on_error", "extra_job",
        "missing_step", "reorder", "step_continue", "build_if", "build_shell",
        "build_command", "build_extra", "curator_if", "curator_command",
        "upload_if", "upload_action", "upload_path", "upload_days", "upload_missing",
    ],
)
def test_changed_package_contract_is_refused(case: str) -> None:
    workflow = deepcopy(load_ci())
    job = package_job(workflow)
    steps = job["steps"]
    build, curator, upload = steps[-3:]
    if case == "needs":
        job["needs"] = []
    elif case == "runs_on":
        job["runs-on"] = "ubuntu-24.04"
    elif case == "latest":
        job["strategy"]["matrix"]["os"][1] = "ubuntu-latest"
    elif case == "fail_fast":
        job["strategy"]["fail-fast"] = True
    elif case == "extra_axis":
        job["strategy"]["matrix"]["mode"] = ["debug"]
    elif case == "timeout":
        job["timeout-minutes"] = 61
    elif case == "job_if":
        job["if"] = "false"
    elif case == "defaults":
        job["defaults"] = {"run": {"working-directory": "source"}}
    elif case == "permissions":
        job["permissions"] = {"contents": "write"}
    elif case == "continue_on_error":
        job["continue-on-error"] = True
    elif case == "extra_job":
        workflow["jobs"]["third"] = {"runs-on": "ubuntu-24.04", "steps": []}
    elif case == "missing_step":
        steps.pop(1)
    elif case == "reorder":
        steps[1], steps[2] = steps[2], steps[1]
    elif case == "step_continue":
        steps[0]["continue-on-error"] = True
    elif case == "build_if":
        build["if"] = "runner.os != 'Windows'"
    elif case == "build_shell":
        build["shell"] = "bash"
    elif case == "build_command":
        build["run"] = build["run"].replace("--python $env:PACKAGE_PYTHON", "")
    elif case == "build_extra":
        build["run"] += "\nexit 0\n"
    elif case == "curator_if":
        curator["if"] = "success()"
    elif case == "curator_command":
        curator["run"] = curator["run"].replace("'japp-development-package-proof'", "'other'")
    elif case == "upload_if":
        upload["if"] = "success()"
    elif case == "upload_action":
        upload["uses"] = "actions/upload-artifact@main"
    elif case == "upload_path":
        upload["with"]["path"] = "${{ runner.temp }}/"
    elif case == "upload_days":
        upload["with"]["retention-days"] = 90
    elif case == "upload_missing":
        upload["with"]["if-no-files-found"] = "ignore"
    else:
        raise AssertionError(case)
    assert not check_portability._native_package_job_valid(workflow)
    violations: list[check_portability.Violation] = []
    check_portability._check_matrix(workflow, violations)
    assert any(item.rule == "PORT-CI-002" for item in violations)


def test_package_artifact_exception_is_named_exact_and_opt_in() -> None:
    workflow = load_ci()
    upload = package_job(workflow)["steps"][-1]
    named = [("native_package_development:Retain finite native development evidence", upload)]
    violations: list[check_portability.Violation] = []
    check_portability._check_artifacts(named, violations)
    assert any(item.rule == "PORT-CI-017" for item in violations)
    approved: list[check_portability.Violation] = []
    check_portability._check_artifacts(named, approved, approved_package=True)
    assert approved == []
    wrong_name: list[check_portability.Violation] = []
    check_portability._check_artifacts([("verify:Retain finite native development evidence", upload)], wrong_name, approved_package=True)
    assert any(item.rule == "PORT-CI-017" for item in wrong_name)


def test_package_exception_does_not_allow_always_browser_upload() -> None:
    workflow = deepcopy(load_ci())
    browser = next(step for step in workflow["jobs"]["verify"]["steps"] if str(step.get("uses", "")).startswith("actions/upload-artifact@"))
    browser["if"] = "always()"
    violations: list[check_portability.Violation] = []
    check_portability._check_artifacts([("verify:" + browser["name"], browser)], violations, approved_package=True)
    assert any(item.rule == "PORT-CI-017" for item in violations)


def test_package_exception_does_not_hide_changed_verify_matrix() -> None:
    workflow = deepcopy(load_ci())
    workflow["jobs"]["verify"]["strategy"]["matrix"]["os"].remove("windows-2025")
    assert check_portability._native_package_job_valid(workflow)
    violations: list[check_portability.Violation] = []
    check_portability._check_matrix(workflow, violations)
    assert any(item.rule == "PORT-CI-002" for item in violations)
