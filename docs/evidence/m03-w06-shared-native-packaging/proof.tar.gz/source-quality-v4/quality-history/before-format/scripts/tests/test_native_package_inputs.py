"""UNEXECUTED source counterexamples. No real tool, package, process or network actor."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import patch
import zipfile

from wheel_only_runtime_lock import make
from native_package_pipeline import wheel_code,pinned_lock_helper,bind_tool

W='1'*64
S='2'*64

class Inputs(unittest.TestCase):
    def setUp(self):
        owned=tempfile.TemporaryDirectory(prefix='japp-package-fake-');self.addCleanup(owned.cleanup)
        self.root=Path(owned.name)
        deny=patch('native_package_pipeline.pinned_process_helper',side_effect=AssertionError('NO_PROCESS_IN_FAKE_CASE'))
        deny.start();self.addCleanup(deny.stop)
    def locked(self,export=None,extra=''):
        if export is None:
            export='foo-bar==1.0.0 '+chr(92)+'\n    --hash=sha256:'+S+'\n'
        source='''version = 1
[[package]]
name = "orchestrator"
version = "0.0.1"
source = { editable = "services/orchestrator" }
dependencies = [{ name = "japp-contracts" }, { name = "foo-bar" }]
[[package]]
name = "japp-contracts"
version = "0.0.1"
source = { editable = "packages/contracts" }
[[package]]
name = "foo-bar"
version = "1.0.0"
source = { registry = "https://pypi.org/simple" }
wheels = [{ url = "https://example.invalid/foo.whl", hash = "sha256:WHEEL" }]
sdist = { url = "https://example.invalid/foo.tar.gz", hash = "sha256:SDIST" }
'''.replace('WHEEL',W).replace('SDIST',S)+extra
        lock=self.root/'uv.lock';lock.write_text(source)
        exported=self.root/'export.txt';exported.write_text(export)
        return lock,exported,self.root/'wheels.lock'
    def package(self,entries=None):
        source=self.root/'src';package=source/'orchestrator';package.mkdir(parents=True,exist_ok=True)
        (package/'__init__.py').write_bytes(b'VALUE=1\n');(package/'fixture.json').write_bytes(b'{"version":1}\n')
        files={'orchestrator/__init__.py':b'VALUE=1\n','orchestrator/fixture.json':b'{"version":1}\n',
               'orchestrator-0.0.1.dist-info/METADATA':b'Name: orchestrator\nVersion: 0.0.1\n',
               'orchestrator-0.0.1.dist-info/WHEEL':b'Wheel-Version: 1.0\nTag: py3-none-any\n',
               'orchestrator-0.0.1.dist-info/RECORD':b''}
        if entries is not None:entries(files)
        wheel=self.root/'project.whl'
        with zipfile.ZipFile(wheel,'w') as out:
            for name,data in files.items():out.writestr(name,data)
        return wheel,source
    def test_locked_export_drops_sdist_authorization_and_keeps_exact_wheel(self):
        args=self.locked();result=make(*args);text=args[2].read_text()
        self.assertIn(W,text);self.assertNotIn(S,text);self.assertEqual(len(result['packages']),1)
        self.assertEqual(result['sdist_hashes_authorized'],0);self.assertFalse(result['resolution_performed'])
    def test_missing_runtime_dependency_is_refused(self):
        with self.assertRaises(ValueError):make(*self.locked(export=''))
    def test_extra_development_dependency_is_refused(self):
        extra='\n[[package]]\nname="dev-only"\nversion="1.0.0"\nsource={registry="https://pypi.org/simple"}\nwheels=[{hash="sha256:'+W+'"}]\n'
        with self.assertRaises(ValueError):make(*self.locked(export='foo-bar==1.0.0\ndev-only==1.0.0\n',extra=extra))
    def test_unlocked_version_is_refused(self):
        with self.assertRaises(ValueError):make(*self.locked(export='foo-bar==2.0.0\n'))
    def test_direct_url_is_refused(self):
        with self.assertRaises(ValueError):make(*self.locked(export='foo-bar @ https://example.invalid/foo.whl\n'))
    def test_sdist_only_lock_is_refused(self):
        args=self.locked();args[0].write_text(args[0].read_text().replace('wheels = [{ url = "https://example.invalid/foo.whl", hash = "sha256:'+W+'" }]','wheels = []'))
        with self.assertRaises(ValueError):make(*args)
    def test_normalized_duplicate_names_are_refused(self):
        with self.assertRaises(ValueError):make(*self.locked(export='foo-bar==1.0.0\nfoo_bar==1.0.0\n'))
    def test_export_cannot_disable_current_unconditional_dependency(self):
        with self.assertRaises(ValueError):make(*self.locked(export='foo-bar==1.0.0 ; python_version < "3.0"\n'))
    def test_conditional_graph_is_not_silently_selected(self):
        args=self.locked();args[0].write_text(args[0].read_text().replace('{ name = "foo-bar" }','{ name = "foo-bar", marker = "sys_platform == \'win32\'" }'))
        with self.assertRaises(ValueError):make(*args)
    def test_existing_lock_output_is_preserved(self):
        args=self.locked();args[2].write_bytes(b'OWNED_EXISTING')
        with self.assertRaises(ValueError):make(*args)
        self.assertEqual(args[2].read_bytes(),b'OWNED_EXISTING')
    def test_complete_package_source_and_resource_are_positive(self):
        wheel,source=self.package();result=wheel_code(wheel,source,'orchestrator')
        self.assertEqual(result['source_package_files'],2);self.assertEqual(result['source_python_files'],1)
        self.assertTrue(result['all_package_file_bytes_equal'])
    def test_missing_module_is_refused(self):
        wheel,source=self.package(lambda files:files.pop('orchestrator/__init__.py'))
        with self.assertRaises(ValueError):wheel_code(wheel,source,'orchestrator')
    def test_changed_nonpython_package_resource_is_refused(self):
        wheel,source=self.package(lambda files:files.update({'orchestrator/fixture.json':b'{"version":2}\n'}))
        with self.assertRaises(ValueError):wheel_code(wheel,source,'orchestrator')
    def test_top_level_pth_install_surface_is_refused(self):
        wheel,source=self.package(lambda files:files.update({'unexpected.pth':b'import os\n'}))
        with self.assertRaises(ValueError):wheel_code(wheel,source,'orchestrator')
    def test_data_script_install_surface_is_refused(self):
        wheel,source=self.package(lambda files:files.update({'orchestrator-0.0.1.data/scripts/extra':b'UNDECLARED'}))
        with self.assertRaises(ValueError):wheel_code(wheel,source,'orchestrator')
    def test_unexpected_entrypoint_metadata_is_refused(self):
        wheel,source=self.package(lambda files:files.update({'orchestrator-0.0.1.dist-info/entry_points.txt':b'[console_scripts]\nx=x:y\n'}))
        with self.assertRaises(ValueError):wheel_code(wheel,source,'orchestrator')
    def test_duplicate_wheel_member_is_refused(self):
        wheel,source=self.package()
        with zipfile.ZipFile(wheel,'a') as out:
            with self.assertWarns(UserWarning):out.writestr('orchestrator/__init__.py',b'VALUE=1\n')
        with self.assertRaises(ValueError):wheel_code(wheel,source,'orchestrator')
    def test_symlink_wheel_member_is_refused(self):
        wheel,source=self.package()
        with zipfile.ZipFile(wheel,'a') as out:
            info=zipfile.ZipInfo('orchestrator/link');info.create_system=3;info.external_attr=(stat.S_IFLNK|0o777)<<16
            out.writestr(info,b'__init__.py')
        with self.assertRaises(ValueError):wheel_code(wheel,source,'orchestrator')
    def test_foreign_python_namespace_is_refused(self):
        wheel,source=self.package(lambda files:files.update({'foreign/__init__.py':b''}))
        with self.assertRaises(ValueError):wheel_code(wheel,source,'orchestrator')
    def test_traversal_member_is_refused(self):
        wheel,source=self.package(lambda files:files.update({'../outside':b'UNOWNED'}))
        with self.assertRaises(ValueError):wheel_code(wheel,source,'orchestrator')
    def test_native_binary_member_is_refused(self):
        wheel,source=self.package(lambda files:files.update({'orchestrator/native.pyd':b'NOT_PURE'}))
        with self.assertRaises(ValueError):wheel_code(wheel,source,'orchestrator')
    def test_changed_helper_is_refused_before_any_loader(self):
        with patch('native_package_pipeline.importlib.util.spec_from_file_location',side_effect=AssertionError('LOADER_MUST_NOT_RUN')):
            with self.assertRaises(ValueError):pinned_lock_helper('0'*64)
    def test_tool_alias_must_resolve_to_the_pinned_physical_image(self):
        tool=self.root/'tool';tool.write_bytes(b'FIXED_FAKE_TOOL_NO_EXECUTION')
        row={'path':str(tool),'resolved_path':str(tool.resolve()),'sha256':hashlib.sha256(tool.read_bytes()).hexdigest()}
        self.assertEqual(bind_tool(row),tool)
        row['resolved_path']=str(self.root/'other')
        with self.assertRaises(ValueError):bind_tool(row)

if __name__=='__main__':unittest.main(verbosity=2)
