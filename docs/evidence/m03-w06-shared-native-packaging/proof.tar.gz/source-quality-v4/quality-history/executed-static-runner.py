from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import signal
import subprocess
import time

BASE=Path('/tmp/japp-m03-w06-shared-native-package-source-join-660f-20261019')
FIX=Path('/tmp/japp-m03-w06-native-helper-portability-source-v2-20261019')
OUT=Path('/tmp/japp-m03-w06-native-package-static-quality-20261019')
ROOT=Path('/Users/tanishkalwad/jobapplyv2')
if OUT.exists(): raise SystemExit('fresh outside static output required')
OUT.mkdir()
WORK=OUT/'work'
shutil.copytree(BASE/'afterimages',WORK)
for p in (FIX/'afterimages').rglob('*'):
    if p.is_file(): (WORK/p.relative_to(FIX/'afterimages')).write_bytes(p.read_bytes())
(WORK/'pyproject.toml').write_bytes((BASE/'preimages/pyproject.toml').read_bytes())
(OUT/'executed-static-runner.py').write_bytes(Path(__file__).read_bytes())
files=sorted(str(p.relative_to(WORK)) for p in WORK.rglob('*.py'))
def hashes():
    return {n:{'sha256':hashlib.sha256((WORK/n).read_bytes()).hexdigest(),'bytes':(WORK/n).stat().st_size} for n in files+['pyproject.toml']}
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
write(OUT/'before.json',hashes())
env={k:os.environ[k] for k in ('HOME','USER','LOGNAME','TMPDIR','LANG','LC_ALL','SYSTEMROOT','SystemRoot') if k in os.environ}
env.update({'PATH':str(ROOT/'.venv/bin')+os.pathsep+os.defpath,'VIRTUAL_ENV':str(ROOT/'.venv'),'UV_PROJECT_ENVIRONMENT':str(ROOT/'.venv'),'UV_CACHE_DIR':str(OUT/'uv-cache'),'RUFF_CACHE_DIR':str(OUT/'ruff-cache'),'MYPY_CACHE_DIR':str(OUT/'mypy-cache'),'PYTHONDONTWRITEBYTECODE':'1','UV_OFFLINE':'1'})
UV='/Users/tanishkalwad/.local/bin/uv'
prefix=[UV,'run','--no-sync','--offline','--project',str(ROOT)]
commands=[('uv-version',[UV,'--version']),('ruff-version',prefix+['ruff','--version']),('mypy-version',prefix+['mypy','--version']),('ruff-initial',prefix+['ruff','check','--config',str(WORK/'pyproject.toml'),'--output-format','json',*files]),('format-initial',prefix+['ruff','format','--check','--config',str(WORK/'pyproject.toml'),*files]),('mypy-initial',prefix+['mypy','--config-file',str(WORK/'pyproject.toml'),'--cache-dir',str(OUT/'mypy-cache'),*files])]
write(OUT/'setup.json',{'cwd':str(WORK),'environment':env,'source_paths':files,'config_sha256':hashlib.sha256((WORK/'pyproject.toml').read_bytes()).hexdigest(),'subject_imports_or_tests':'NONE','static_release':'root explicitly released outside Ruff/mypy/format only','command_timeout_seconds':110})
for label,argv in commands:
    rec={'argv':argv,'cwd':str(WORK),'environment':env,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout_seconds':110}
    write(OUT/(label+'.upfront.json'),rec)
    start=time.monotonic(); child=None; events=[]; timed_out=False
    with (OUT/(label+'.stdout')).open('xb') as stdout,(OUT/(label+'.stderr')).open('xb') as stderr:
        child=subprocess.Popen(argv,cwd=WORK,env=dict(env),stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
        rec.update(pid=child.pid,owned_pgid=child.pid)
        write(OUT/(label+'.launch.json'),{'pid':child.pid,'owned_pgid':child.pid})
        try:
            child.wait(timeout=110)
        except subprocess.TimeoutExpired:
            timed_out=True
        finally:
            def live():
                try:os.killpg(child.pid,0);return True
                except ProcessLookupError:return False
            for sig,grace in ((signal.SIGTERM,3),(signal.SIGKILL,3)):
                if not live():break
                os.killpg(child.pid,sig);events.append(signal.Signals(sig).name)
                until=time.monotonic()+grace
                while live() and time.monotonic()<until:
                    child.poll();time.sleep(.02)
            child.wait(timeout=1)
            group='PRESENT' if live() else 'GONE'
    rec.update(exit_code=child.returncode,timed_out=timed_out,signals=events,group=group,owned_child_reaped=child.poll() is not None,elapsed_seconds=time.monotonic()-start,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    for suffix in ('stdout','stderr'):
        data=(OUT/(label+'.'+suffix)).read_bytes()
        rec[suffix]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    write(OUT/(label+'.result.json'),rec)
    print(label,child.returncode,round(rec['elapsed_seconds'],3),group,flush=True)
    if timed_out or group!='GONE':break
write(OUT/'after-initial.json',hashes())
print('STATIC_INITIAL_CLOSED',OUT,flush=True)
