from pathlib import Path
import ast,json
BASE=Path('/tmp/japp-m03-w06-native-package-static-quality-20261019')
p=BASE/'work/scripts/native_package_pipeline.py'
h=BASE/'source-correction-history';h.mkdir(exist_ok=True)
(h/'pipeline-contiguous-phase-proposal.uninvoked.py').write_bytes(p.read_bytes())
b=(BASE/'before-pipeline-phase-split.py').read_text()
b=b.replace('import datetime\n','').replace('import time\n','')
b=b.replace('from collections.abc import Callable, Mapping, Sequence\n','from collections.abc import Callable, Mapping, Sequence\nfrom dataclasses import dataclass\n',1)
old='''def source_projection(
    checkout: Path, rows: Mapping[str, str], git: Path, env: Mapping[str, str],
    expected_head: str, process: ProcessHelper, deadlines: Budget, proof: Path, label: str
) -> None:
'''
new='''@dataclass(frozen=True)
class _ProjectionRequest:
    checkout: Path
    rows: Mapping[str, str]
    git: Path
    env: Mapping[str, str]
    expected_head: str
    process: ProcessHelper
    deadlines: Budget
    proof: Path
    label: str


def source_projection(request: _ProjectionRequest) -> None:
    checkout, rows, git, env = request.checkout, request.rows, request.git, request.env
    expected_head, process = request.expected_head, request.process
    deadlines, proof, label = request.deadlines, request.proof, request.label
'''
assert old in b;b=b.replace(old,new)
old='def main(spec_path: Path | None = None) -> None:\n'
new='''# Keep the ordered package phases and fail-closed guards in one local ownership
# context. Splitting only to satisfy statement/branch counts obscures that order.
def main(spec_path: Path | None = None) -> None:  # noqa: PLR0912, PLR0915
'''
assert old in b;b=b.replace(old,new)
b=b.replace('''    if spec_path is None:
        spec_path = parser.parse_args().spec''','''    if spec_path is None:
        supplied = parser.parse_args().spec
        if not isinstance(supplied, Path):
            raise ValueError("Native spec path is not a Path")
        spec_path = supplied''')
b=b.replace('''    if sha(helper) != json.loads((output / "actor-image.json").read_text())["sha256"]:''','''    image_record = _record(json.loads((output / "actor-image.json").read_text()))
    if sha(helper) != _text(image_record["sha256"]):''')
# Preserve every original projection argument and their order in a typed record.
tree=ast.parse(b);lines=b.splitlines(keepends=True);starts=[];total=0
for line in lines:starts.append(total);total+=len(line)
edits=[]
for node in ast.walk(tree):
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='source_projection':
  start=starts[node.lineno-1]+node.col_offset+len('source_projection(')
  end=starts[node.end_lineno-1]+node.end_col_offset-1
  edits += [(start,'_ProjectionRequest('),(end,')')]
assert len(edits)==6
for pos,text in sorted(edits,reverse=True):b=b[:pos]+text+b[pos:]
# Named bounds retain exact integer values.
b=b.replace('BOUND = 512 * 1024 * 1024\n','BOUND = 512 * 1024 * 1024\nMAX_WHEEL_NODES = 2048\n',1).replace('len(archive.infolist()) > 2048','len(archive.infolist()) > MAX_WHEEL_NODES')
# Equivalent fresh list construction, preserving each argument and order.
b=b.replace('pnpm + ["--version"]','[*pnpm, "--version"]').replace('pnpm + ["install", "--frozen-lockfile"]','[*pnpm, "install", "--frozen-lockfile"]')
b=b.replace('pnpm + ["--filter", "@japp/desktop", "exec", "tauri", "--version"]','[*pnpm, "--filter", "@japp/desktop", "exec", "tauri", "--version"]')
b=b.replace('build: list[str | Path] = pnpm + [','build: list[str | Path] = [*pnpm,').replace('build + ["--", "--locked"]','[*build, "--", "--locked"]')
ast.parse(b);p.write_text(b)
(BASE/'executed-pipeline-minimal-constructor.py').write_bytes(Path(__file__).read_bytes())
(h/'pipeline-phase-choice.derived.json').write_text(json.dumps({'state':'SOURCE_ONLY_UNVALIDATED','chosen':'Smaller original ordered coordinator with explicit typed records and narrow authorized PLR0912/15 rationale','preserved_unselected_history':'pipeline-contiguous-phase-proposal.uninvoked.py','projection_change':'Exact original 9 positional values/order encapsulated into frozen private record to satisfy argument shape rules; no I/O or authority change','list_construction':'Exact original argv elements/order preserved with fresh starred lists','tests_imports_compiler_native':'NONE','static_on_current_bytes':'NOT_RUN'},indent=2)+'\n')
print('MINIMAL_TYPED_PIPELINE_SOURCE_ONLY')
