from pathlib import Path
import ast,json
BASE=Path('/tmp/japp-m03-w06-native-package-static-quality-20261019')
p=BASE/'work/scripts/native_package_pipeline.py';b=p.read_text()
h=BASE/'before-pipeline-phase-split.py';h.write_text(b)
start=b.index('def main(spec_path: Path | None = None) -> None:')
end=b.index('\n\nif __name__ == "__main__":',start)
main=b[start:end]
# Separately named phases retain original command/body source text; only their
# lexical context is made explicit in a typed local context object.
prep=main[main.index('    parser ='):main.index('    records: list[dict[str, object]] = []')]
prep=prep.replace('''    if spec_path is None:
        spec_path = parser.parse_args().spec''','''    if spec_path is None:
        supplied = parser.parse_args().spec
        if not isinstance(supplied, Path):
            raise ValueError("Native spec path is not a Path")
        spec_path = supplied''')
# Move target selection and environment/tool checks into bounded source helpers.
a=prep.index('    if target == "x86_64-pc-windows-msvc":')
z=prep.index('    tools = ',a)
target_body=prep[a:z]
target_body=target_body.replace('    if target ==','    if target ==',1)
target_fn='def _native_target(target: str) -> tuple[str, str]:\n'+target_body+'    return builder, overlay\n\n\n'
prep=prep[:a]+'    builder, overlay = _native_target(target)\n'+prep[z:]
a=prep.index('    tools = ');z=prep.index('    source_projection(',a)
inputs=prep[a:z]
inputs_fn='def _native_inputs(spec: PipelineSpec, target: str) -> tuple[dict[str, Path], dict[str, str]]:\n'+inputs+'    return tools, env\n\n\n'
prep=prep[:a]+'    tools, env = _native_inputs(spec, target)\n'+prep[z:]
prepfn='def _prepare(spec_path: Path | None) -> _Recipe:\n'+prep+'''    return _Recipe(
        spec=spec, checkout=checkout, output=output, target=target,
        builder=builder, overlay=overlay, tools=tools, env=env,
        process=process, deadlines=deadlines,
    )


'''
# Original nested command runner becomes a method retaining all finally captures.
a=main.index('    def run(');z=main.index('    python, uv, node, cargo, rustc =',a)
run=main[a:z]
run=run.replace('''        label: str, argv: Sequence[str | Path], cwd: Path = checkout,
        extra_env: Mapping[str, str] | None = None,
    ) -> bytes:''','''        self, label: str, argv: Sequence[str | Path], cwd: Path | None = None,
        extra_env: Mapping[str, str] | None = None,
    ) -> bytes:
        tools, spec, env = self.tools, self.spec, self.env
        process, deadlines, output = self.process, self.deadlines, self.output
        records = self.records
        if cwd is None:
            cwd = self.checkout''')
context='''@dataclass
class _Recipe:
    spec: PipelineSpec
    checkout: Path
    output: Path
    target: str
    builder: str
    overlay: str
    tools: dict[str, Path]
    env: dict[str, str]
    process: ProcessHelper
    deadlines: Budget
    records: list[dict[str, object]] = field(default_factory=list)

'''+run+'\n'
# Exact contiguous original phases, with unchanged order and arguments.
a=main.index('    python, uv, node, cargo, rustc =')
z=main.index('    exported = output / "runtime-export.txt"',a)
probe=main[a:z]
probe_fn='''def _probe_tools(recipe: _Recipe) -> None:
    tools, run = recipe.tools, recipe.run
'''+probe+'\n\n'
a=z;z=main.index('    descriptors = list(',a)
build=main[a:z]
build_fn='''def _build_package(recipe: _Recipe) -> tuple[Path, str]:
    checkout, output, tools = recipe.checkout, recipe.output, recipe.tools
    target, builder, overlay = recipe.target, recipe.builder, recipe.overlay
    run = recipe.run
    python, uv = tools["python"], tools["uv"]
    pnpm: list[str | Path] = [tools["node"], tools["pnpm_js"]]
    contracts = bind(recipe.spec["contracts_wheel"])
    service = bind(recipe.spec["orchestrator_wheel"])
    make = pinned_lock_helper(recipe.spec["proposal_bindings"]["wheel_only_runtime_lock.py"])
'''+build+'    return runtime, manifest_pin\n\n\n'
a=z;z=main.index('    if target.endswith("windows-msvc"):',a)
desc=main[a:z]
desc_fn='''def _shipping_descriptors(recipe: _Recipe, runtime: Path, manifest_pin: str) -> None:
    output, target = recipe.output, recipe.target
'''+desc+'\n\n'
a=z;z=main.index('    entry = packaged_runtime / (',a)
inspect=main[a:z]
inspect_fn='''def _inspect_package(recipe: _Recipe, runtime: Path, manifest_pin: str) -> tuple[Path, Path]:
    checkout, output, tools = recipe.checkout, recipe.output, recipe.tools
    target, run = recipe.target, recipe.run
    python = tools["python"]
'''+inspect+'    return packaged_runtime, package\n\n\n'
a=z;z=main.index('    dump(\n        output / "closure.json",',a)
actor=main[a:z]
actor=actor.replace('''    if sha(helper) != json.loads((output / "actor-image.json").read_text())["sha256"]:''','''    image_record = _record(json.loads((output / "actor-image.json").read_text()))
    if sha(helper) != _text(image_record["sha256"]):''')
actor_fn='''def _run_package_actor(recipe: _Recipe, packaged_runtime: Path, manifest_pin: str) -> None:
    checkout, output, tools = recipe.checkout, recipe.output, recipe.tools
    spec, target, env = recipe.spec, recipe.target, recipe.env
    process, deadlines, run = recipe.process, recipe.deadlines, recipe.run
    cargo = tools["cargo"]
'''+actor+'\n\n'
closure=main[z:]
closure_fn='''def _close_recipe(recipe: _Recipe, package: Path, manifest_pin: str) -> None:
    output, target, spec = recipe.output, recipe.target, recipe.spec
    records, deadlines = recipe.records, recipe.deadlines
'''+closure+'\n\n'
newmain='''def main(spec_path: Path | None = None) -> None:
    recipe = _prepare(spec_path)
    _probe_tools(recipe)
    runtime, manifest_pin = _build_package(recipe)
    _shipping_descriptors(recipe, runtime, manifest_pin)
    packaged_runtime, package = _inspect_package(recipe, runtime, manifest_pin)
    _run_package_actor(recipe, packaged_runtime, manifest_pin)
    _close_recipe(recipe, package, manifest_pin)
'''
# The original parser loaded the lock callback during preparation. Retain that
# exact early guard/load and pass the authenticated callable into the recipe.
context=context.replace('    deadlines: Budget\n','    deadlines: Budget\n    make: Callable[[Path, Path, Path], dict[str, object]]\n',1)
prepfn=prepfn.replace('        process=process, deadlines=deadlines,','        process=process, deadlines=deadlines, make=make,')
build_fn=build_fn.replace('    make = pinned_lock_helper(recipe.spec["proposal_bindings"]["wheel_only_runtime_lock.py"])','    make = recipe.make')
new=b[:start]+context+target_fn+inputs_fn+prepfn+probe_fn+build_fn+desc_fn+inspect_fn+actor_fn+closure_fn+newmain+b[end:]
new=new.replace('from collections.abc import Callable, Mapping, Sequence\n','from collections.abc import Callable, Mapping, Sequence\nfrom dataclasses import dataclass, field\n',1)
ast.parse(new)
p.write_text(new)
(BASE/'executed-pipeline-phase-constructor.py').write_bytes(Path(__file__).read_bytes())
(BASE/'pipeline-phase-split.derived.json').write_text(json.dumps({'state':'SOURCE_ONLY_UNVALIDATED','scope':'Private typed recipe context and contiguous phase extraction; no registry/command/oracle/budget changes','order':['_prepare','_probe_tools','_build_package','_shipping_descriptors','_inspect_package','_run_package_actor','_close_recipe'],'original_preimage':'before-pipeline-phase-split.py','tests_imports_native_compiler':'NONE','needs_different_peer':'final source delta and original phase/oracle correspondence'},indent=2)+'\n')
print('PIPELINE_PHASE_SOURCE_ONLY')
