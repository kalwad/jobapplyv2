from pathlib import Path
import ast,datetime,hashlib,json,os,signal,subprocess,time
BASE=Path('/tmp/japp-m03-w06-native-package-static-quality-20261019')
WORK=BASE/'work';OUT=BASE/'phase-4-combined12'
if OUT.exists():raise SystemExit('fresh phase required')
OUT.mkdir()
setup=json.loads((BASE/'setup.json').read_text());env=setup['environment']
files=setup['source_paths']
editable=[n for n in files if n!='scripts/_native_package_process.py']
env['MYPYPATH']=os.pathsep.join([str(WORK/'scripts'),str(WORK/'scripts/tests'),'/Users/tanishkalwad/jobapplyv2/scripts','/Users/tanishkalwad/jobapplyv2/scripts/tests','/Users/tanishkalwad/jobapplyv2/services/orchestrator/src','/Users/tanishkalwad/jobapplyv2/packages/contracts/generated/python/src'])
def put(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
for n in files:
 target=OUT/'before'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((WORK/n).read_bytes())
prefix=['/Users/tanishkalwad/.local/bin/uv','run','--no-sync','--offline','--project','/Users/tanishkalwad/jobapplyv2']
commands=[('import-sort', ['ruff','check','--config',str(WORK/'pyproject.toml'),'--select','I','--fix',*editable]),('format-owned',['ruff','format','--config',str(WORK/'pyproject.toml'),*editable]),('ruff',['ruff','check','--config',str(WORK/'pyproject.toml'),'--output-format','json',*files]),('mypy',['mypy','--config-file',str(WORK/'pyproject.toml'),'--cache-dir',str(BASE/'mypy-cache'),*files]),('format-check',['ruff','format','--check','--config',str(WORK/'pyproject.toml'),*files])]
for name,args in commands:
 argv=prefix+args;rec={'argv':argv,'cwd':str(WORK),'environment':env,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout_seconds':110,'scope':'All12 Python files checked; only11 owned non-helper files import-sorted/formatted; exact sealed helper read-only'};put(OUT/(name+'.upfront.json'),rec)
 start=time.monotonic();events=[];timeout=False
 with (OUT/(name+'.stdout')).open('xb') as stdout,(OUT/(name+'.stderr')).open('xb') as stderr:
  child=subprocess.Popen(argv,cwd=WORK,env=dict(env),stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True);put(OUT/(name+'.launch.json'),{'pid':child.pid,'owned_pgid':child.pid})
  try:child.wait(timeout=110)
  except subprocess.TimeoutExpired:timeout=True
  finally:
   def live():
    try:os.killpg(child.pid,0);return True
    except ProcessLookupError:return False
   for sig,grace in ((signal.SIGTERM,3),(signal.SIGKILL,3)):
    if not live():break
    os.killpg(child.pid,sig);events.append(signal.Signals(sig).name);until=time.monotonic()+grace
    while live() and time.monotonic()<until:child.poll();time.sleep(.02)
   child.wait(timeout=1);group='PRESENT' if live() else 'GONE'
 rec.update(exit_code=child.returncode,timed_out=timeout,signals=events,group=group,owned_child_reaped=child.poll() is not None,elapsed_seconds=time.monotonic()-start,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
 for suffix in ('stdout','stderr'):
  data=(OUT/(name+'.'+suffix)).read_bytes();rec[suffix]={'sha256':sha(data),'bytes':len(data)}
 put(OUT/(name+'.result.json'),rec);print(name,rec['exit_code'],round(rec['elapsed_seconds'],3),group,flush=True)
 if timeout or group!='GONE':raise SystemExit('incomplete static closure')
checks=[]
for n in files:
 target=OUT/'after'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((WORK/n).read_bytes())
 old=ast.parse((OUT/'before'/n).read_text());new=ast.parse((WORK/n).read_text())
 functions=lambda tree:{(node.name,node.lineno):ast.dump(node,include_attributes=False) for node in ast.walk(tree) if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef))}
 old_funcs=[ast.dump(x,include_attributes=False) for x in ast.walk(old) if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))]
 new_funcs=[ast.dump(x,include_attributes=False) for x in ast.walk(new) if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))]
 checks.append({'path':n,'before_sha256':sha((OUT/'before'/n).read_bytes()),'after_sha256':sha((WORK/n).read_bytes()),'function_ast_sequence_equal':old_funcs==new_funcs})
put(OUT/'source-preservation.derived.json',{'checks':checks,'all_function_asts_equal':all(c['function_ast_sequence_equal'] for c in checks),'scope':'Only import sorting and formatting are asserted here; prior intentional typed/test source edits have separate preimages/correspondence.'})
(OUT/'executed-runner.py').write_bytes(Path(__file__).read_bytes());print('PHASE4_STATIC_CLOSED',flush=True)
