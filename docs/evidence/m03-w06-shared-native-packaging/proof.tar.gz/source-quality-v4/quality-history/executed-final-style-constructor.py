from pathlib import Path
import ast,json
BASE=Path('/tmp/japp-m03-w06-native-package-static-quality-20261019');WORK=BASE/'work';H=BASE/'before-phase4-source-fixes';H.mkdir()
files=['scripts/native_package_ci.py','scripts/native_package_pipeline.py','scripts/tests/test_native_package_inputs.py']
for n in files:
 p=H/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((WORK/n).read_bytes())
p=WORK/'scripts/native_package_pipeline.py';b=p.read_text().replace('    names = set()','    names: set[str] = set()')
b=b.replace('    # The separately proposed builder patch verifies copied input pins before any command.','    # The separately proposed builder patch verifies copied input pins\n    # before any command.')
b=b.replace('    # This additive cfg(test) derivative is applied only AFTER the shipping package build.','    # This additive cfg(test) derivative is applied only AFTER\n    # the shipping package build.')
p.write_text(b)
p=WORK/'scripts/native_package_ci.py';b=p.read_text().replace('            # VS discovery must already be activated by the workflow; never invent SDK hashes.','            # VS discovery must already be activated by the workflow;\n            # never invent SDK hashes.');p.write_text(b)
p=WORK/'scripts/tests/test_native_package_inputs.py';b=p.read_text();tree=ast.parse(b)
lines=b.splitlines(keepends=True);starts=[];n=0
for line in lines:starts.append(n);n+=len(line)
edits=[]
for node in ast.walk(tree):
 if isinstance(node,ast.keyword) and node.arg=='match' and isinstance(node.value,ast.Constant) and isinstance(node.value.value,str):
  value=node.value;quote='"' if '"' not in value.value else "'"
  a=starts[value.lineno-1]+value.col_offset;z=starts[value.end_lineno-1]+value.end_col_offset
  edits.append((a,z,'r'+quote+value.value+quote))
for a,z,value in sorted(edits,reverse=True):b=b[:a]+value+b[z:]
assert ast.dump(tree,include_attributes=False)==ast.dump(ast.parse(b),include_attributes=False)
# Combine only the two nested context managers; preserve enter and reverse-exit order.
tree=ast.parse(b);lines=b.splitlines(keepends=True);starts=[];n=0
for line in lines:starts.append(n);n+=len(line)
edits=[]
for node in ast.walk(tree):
 if isinstance(node,ast.With) and len(node.body)==1 and isinstance(node.body[0],ast.With):
  inner=node.body[0]
  combined=ast.With(items=node.items+inner.items,body=inner.body,type_comment=node.type_comment)
  ast.fix_missing_locations(combined)
  text=ast.unparse(combined);indent=' '*node.col_offset
  text=text.replace('\n','\n'+indent)
  a=starts[node.lineno-1]+node.col_offset;z=starts[node.end_lineno-1]+node.end_col_offset
  edits.append((a,z,text))
assert len(edits)==2
for a,z,text in sorted(edits,reverse=True):b=b[:a]+text+b[z:]
p.write_text(b);ast.parse(b)
# Wrap long constant representations while preserving exactly every AST value.
wraps=[]
for n in files:
 p=WORK/n;b=p.read_text();tree=ast.parse(b);lines=b.splitlines(keepends=True);starts=[];offset=0
 for line in lines:starts.append(offset);offset+=len(line)
 parents={child:node for node in ast.walk(tree) for child in ast.iter_child_nodes(node)}
 edits=[]
 for node in ast.walk(tree):
  if not isinstance(node,ast.Constant) or not isinstance(node.value,(str,bytes)) or len(node.value)<12:continue
  parent=parents.get(node);joined=False
  while parent is not None:
   if isinstance(parent,ast.JoinedStr):joined=True;break
   parent=parents.get(parent)
  if joined or not any(len(line.rstrip('\n'))>88 for line in lines[node.lineno-1:node.end_lineno]):continue
  a=starts[node.lineno-1]+node.col_offset;z=starts[node.end_lineno-1]+node.end_col_offset
  indent=' '*(min(node.col_offset,16)+4)
  value=node.value
  # A raw representation is needed only when it is itself a match argument.
  parent=parents.get(node);raw=isinstance(parent,ast.keyword) and parent.arg=='match'
  chunks=[];cursor=0
  while cursor<len(value):
   end=min(cursor+30,len(value))
   if raw:
    while end>cursor and len(value[cursor:end])-len(value[cursor:end].rstrip('\\')) & 1:end-=1
   chunk=value[cursor:end];cursor=end
   chunks.append(('r"'+chunk+'"') if raw else repr(chunk))
  replacement='(\n'+'\n'.join(indent+v for v in chunks)+'\n'+' '*min(node.col_offset,16)+')'
  edits.append((a,z,replacement))
 for a,z,text in sorted(edits,reverse=True):b=b[:a]+text+b[z:]
 assert ast.dump(tree,include_attributes=False)==ast.dump(ast.parse(b),include_attributes=False)
 p.write_text(b);wraps.append({'path':n,'literal_representation_edits':len(edits),'entire_ast_equal_after_literal_wrap':True})
(BASE/'phase4-style-preservation.derived.json').write_text(json.dumps({'state':'SOURCE_ONLY_BEFORE_STATIC_CHECKS','literal_values':wraps,'nested_context_combination':{'count':2,'enter_order_and_reverse_exit_order':'preserved','old_calls_assertions_expectedvalues':'preserved'},'new_type_annotation':'names: set[str]','comments':'only three long comments wrapped','tests_imports_native':'NONE'},indent=2)+'\n')
(BASE/'executed-final-style-constructor.py').write_bytes(Path(__file__).read_bytes())
print('FINAL_STYLE_SOURCE_ONLY')
