from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import shutil
import signal
import subprocess
import time
OUT=Path('/tmp/japp-m03-w06-native-package-static-quality-20261019')
WORK=OUT/'work'
setup=json.loads((OUT/'setup.json').read_text());env=setup['environment'];files=setup['source_paths']
SNAP=OUT/'before-format'
if SNAP.exists():raise SystemExit('before-format already exists')
SNAP.mkdir()
for n in files:
    target=SNAP/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((WORK/n).read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
prefix=['/Users/tanishkalwad/.local/bin/uv','run','--no-sync','--offline','--project','/Users/tanishkalwad/jobapplyv2']
def run(label,args):
    argv=prefix+args; rec={'argv':argv,'cwd':str(WORK),'environment':env,'timeout_seconds':110,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()};put(OUT/(label+'.upfront.json'),rec)
    start=time.monotonic();events=[];timeout=False
    with (OUT/(label+'.stdout')).open('xb') as stdout,(OUT/(label+'.stderr')).open('xb') as stderr:
        child=subprocess.Popen(argv,cwd=WORK,env=dict(env),stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
        put(OUT/(label+'.launch.json'),{'pid':child.pid,'owned_pgid':child.pid})
        try:child.wait(timeout=110)
        except subprocess.TimeoutExpired:timeout=True
        finally:
            def live():
                try:os.killpg(child.pid,0);return True
                except ProcessLookupError:return False
            for sig,grace in ((signal.SIGTERM,3),(signal.SIGKILL,3)):
                if not live():break
                os.killpg(child.pid,sig);events.append(signal.Signals(sig).name);until=time.monotonic()+grace
                while live() and time.monotonic()<until:child.poll();time.sleep(.02)
            child.wait(timeout=1);group='PRESENT' if live() else 'GONE'
    rec.update(exit_code=child.returncode,signals=events,timed_out=timeout,group=group,owned_child_reaped=child.poll() is not None,elapsed_seconds=time.monotonic()-start,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    for suffix in ('stdout','stderr'):
        data=(OUT/(label+'.'+suffix)).read_bytes();rec[suffix]={'sha256':sha(data),'bytes':len(data)}
    put(OUT/(label+'.result.json'),rec)
    print(label,rec['exit_code'],rec['elapsed_seconds'],rec['group'],flush=True)
    if timeout or group!='GONE':raise SystemExit('static closure refused')
run('format-owned',['ruff','format','--config',str(WORK/'pyproject.toml'),*files])
old_helper=sha((SNAP/'scripts/_native_package_process.py').read_bytes());new_helper=sha((WORK/'scripts/_native_package_process.py').read_bytes())
repins=[]
for n in ('scripts/native_package_ci.py','scripts/tests/test_native_package_pending_owner.py'):
    p=WORK/n;body=p.read_text();assert body.count(old_helper)==1
    p.write_text(body.replace(old_helper,new_helper));repins.append(n)
put(OUT/'format-helper-repins.derived.json',{'old_helper_sha256':old_helper,'new_helper_sha256':new_helper,'exact_one_literal_repins':repins,'source_author_only':True})
checks=[]
for n in files:
    old=(SNAP/n).read_text();new=(WORK/n).read_text()
    if n in repins:new=new.replace(new_helper,old_helper)
    same=ast.dump(ast.parse(old),include_attributes=False)==ast.dump(ast.parse(new),include_attributes=False)
    checks.append({'path':n,'same_ast_after_only_declared_pin_reversal':same,'before_sha256':sha((SNAP/n).read_bytes()),'after_sha256':sha((WORK/n).read_bytes())})
put(OUT/'format-ast-preservation.derived.json',{'checks':checks,'all_same':all(x['same_ast_after_only_declared_pin_reversal'] for x in checks)})
assert all(x['same_ast_after_only_declared_pin_reversal'] for x in checks)
run('ruff-after-format',['ruff','check','--config',str(WORK/'pyproject.toml'),'--output-format','json',*files])
run('format-after-repin',['ruff','format','--check','--config',str(WORK/'pyproject.toml'),*files])
put(OUT/'after-format.json',{n:{'sha256':sha((WORK/n).read_bytes()),'bytes':(WORK/n).stat().st_size} for n in files+['pyproject.toml']})
(OUT/'executed-format-runner.py').write_bytes(Path(__file__).read_bytes())
print('FORMAT_PHASE_CLOSED',flush=True)
