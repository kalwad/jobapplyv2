from pathlib import Path
p=Path('/tmp/japp-m03-w06-native-package-static-quality-20261019/work/scripts/_native_package_process.py')
s=p.read_text()
s=s.replace('from collections.abc import Mapping, Sequence','from collections.abc import Callable, Mapping, Sequence\nfrom contextlib import suppress').replace('import stat\n','')
s=s.replace('    return cast(int, value)','    return value').replace('    return cast(bool, value)','    return value')
s=s.replace('MAX_SESSION_MEMBERS = 512','MAX_SESSION_MEMBERS = 512\nMAX_PROC_STAT_BYTES = 16384\nMAX_PROC_NAMES = 65536')
s=s.replace('stream.read(16385)','stream.read(MAX_PROC_STAT_BYTES + 1)').replace('len(body) > 16384','len(body) > MAX_PROC_STAT_BYTES').replace('inspected > 65536','inspected > MAX_PROC_NAMES')
s=s.replace('sink = Path(path).open("xb", buffering=0)','sink = Path(path).open("xb", buffering=0)  # noqa: SIM115 -- drain owns/ closes sink')
s=s.replace('for name in os.listdir("/proc"):','for name in os.listdir("/proc"):  # noqa: PTH208 -- bounded snapshot of proc names')
s=s.replace('PLR0912, PLR0915 -- one ordered','PLR0912, PLR0913, PLR0915 -- one ordered')
s=s.replace('datetime.timezone.utc','datetime.UTC')
s=s.replace('    if any("\\0" in x for x in command) or any(\n        not isinstance(v, str) or "\\0" in k + v for k, v in env.items()\n    ):','    if any("\\0" in x for x in command) or any(\n        not _is_text(v) or "\\0" in k + v for k, v in env.items()\n    ):')
s=s.replace('def _write(path:', 'def _is_text(value: object) -> bool:\n    return isinstance(value, str)\n\n\ndef _runtime_platform() -> str:\n    return sys.platform\n\n\ndef _write(path:')
s=s.replace('sys.platform == "win32"','_runtime_platform() == "win32"').replace('sys.platform == "linux"','_runtime_platform() == "linux"')
s=s.replace('''                try:
                    child.wait(
                        timeout=max(0.01, min(2, final_until - time.monotonic()))
                    )
                except subprocess.TimeoutExpired:
                    pass
''','''                with suppress(subprocess.TimeoutExpired):
                    child.wait(
                        timeout=max(0.01, min(2, final_until - time.monotonic()))
                    )
''')
a=s.index('            record.update(')
b=s.index('\n            if windows is not None:',a)
s=s[:a]+'''            record.update({
                "exit_code": exit_code,
                "success": bool(ok),
                "failure": failure,
                "cleanup_error": cleanup_error,
                "containment": cleanup,
                "capture": captured,
                "seconds_elapsed": time.monotonic() - start,
                "end_utc": datetime.datetime.now(datetime.UTC).isoformat(),
                "stdout_sha256": _sha(str(stem) + ".stdout"),
                "stderr_sha256": _sha(str(stem) + ".stderr"),
            })'''+s[b:]
p.write_text(s)
