import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

out=Path('/tmp/japp-m03-w06-native-helper-typing-composition-20261019')
p=Path('/tmp/japp-m03-w06-native-package-static-quality-20261019/work/scripts/_native_package_process.py')
config=Path('/tmp/japp-m03-w06-native-package-static-quality-20261019/work/pyproject.toml')
env={'HOME':str(Path.home()),'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'}
source_before=hashlib.sha256(p.read_bytes()).hexdigest()
commands={
'mypy-final':['/Users/tanishkalwad/jobapplyv2/.venv/bin/mypy','--config-file',str(config),'--cache-dir',str(out/'mypy-cache'),str(p)],
'ruff-final':['/Users/tanishkalwad/jobapplyv2/.venv/bin/ruff','check','--no-cache','--config',str(config),str(p)],
'format-final':['/Users/tanishkalwad/jobapplyv2/.venv/bin/ruff','format','--check','--no-cache','--config',str(config),str(p)]}
for name,argv in commands.items():
    record={'argv':argv,'cwd':str(out),'environment':env,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout_seconds':30,'scope':'STATIC_SOURCE_ONLY_NO_SUBJECT_IMPORT','source_sha256':source_before,'config_sha256':hashlib.sha256(config.read_bytes()).hexdigest()}
    (out/(name+'.upfront.json')).write_text(json.dumps(record,indent=2)+'\n')
    with (out/(name+'.stdout')).open('xb') as stdout,(out/(name+'.stderr')).open('xb') as stderr:
        child=subprocess.run(argv,cwd=out,env=env,stdout=stdout,stderr=stderr,timeout=30,check=False)
    result={'exit_code':child.returncode,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256_after':hashlib.sha256(p.read_bytes()).hexdigest()}
    (out/(name+'.result.json')).write_text(json.dumps(result,indent=2)+'\n')
    assert child.returncode==0 and result['source_sha256_after']==source_before
