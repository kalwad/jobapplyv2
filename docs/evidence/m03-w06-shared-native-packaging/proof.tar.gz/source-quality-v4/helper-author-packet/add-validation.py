from pathlib import Path
p=Path('/tmp/japp-m03-w06-native-package-static-quality-20261019/work/scripts/_native_package_process.py')
s=p.read_text()
validation='''def _load_json(path: Path) -> object:
    # json.loads is dynamically typed; no consumer receives it before checking
    # its closed record, scalar and nested-array shapes below.
    value: object = json.loads(path.read_text(encoding="utf-8"))
    return value


def _json_object(value: object) -> dict[str, object]:
    if not isinstance(value, dict):
        raise ValueError("Native control/receipt must be a JSON object")
    row = cast(dict[object, object], value)
    if any(type(key) is not str for key in row):
        raise ValueError("Native JSON object keys must be strings")
    return {cast(str, key): item for key, item in row.items()}


def _json_int(value: object) -> int:
    if type(value) is not int:
        raise ValueError("Native JSON integer required")
    return cast(int, value)


def _json_number(value: object) -> int | float:
    if type(value) not in (int, float):
        raise ValueError("Native JSON number required")
    number = cast(int | float, value)
    if not math.isfinite(number):
        raise ValueError("Finite native JSON number required")
    return number


def _json_text(value: object) -> str:
    if not isinstance(value, str):
        raise ValueError("Native JSON string required")
    return value


def _json_bool(value: object) -> bool:
    if type(value) is not bool:
        raise ValueError("Native JSON boolean required")
    return cast(bool, value)


def _json_array(value: object) -> list[object]:
    if not isinstance(value, list):
        raise ValueError("Native JSON array required")
    return cast(list[object], value)


def _text_array(value: object) -> list[str]:
    return [_json_text(item) for item in _json_array(value)]


def _error_record(value: object) -> ErrorRecord:
    row = _json_object(value)
    if set(row) != {"type", "message"}:
        raise ValueError("Exact native error receipt required")
    return {"type": _json_text(row["type"]), "message": _json_text(row["message"])}


def _process_identity(value: object) -> ProcessIdentity:
    row = _json_object(value)
    if set(row) != {"pid", "pgid", "sid", "birth"}:
        raise ValueError("Exact native process identity required")
    return {
        "pid": _json_int(row["pid"]),
        "pgid": _json_int(row["pgid"]),
        "sid": _json_int(row["sid"]),
        "birth": _json_int(row["birth"]),
    }


def _signal_receipt(value: object) -> SignalReceipt:
    row = _json_object(value)
    if set(row) != {"identity", "signal", "authority"}:
        raise ValueError("Exact native signal receipt required")
    return {
        "identity": _process_identity(row["identity"]),
        "signal": _json_text(row["signal"]),
        "authority": _json_text(row["authority"]),
    }


def _containment(value: object) -> Containment:
    row = _json_object(value)
    booleans = {
        "session_members_absent", "held_job", "terminated_job",
        "all_job_members_closed", "no_process_created", "assigned_before_resume",
        "keeper_reaped", "session_absent", "launched_owner_retained",
        "held_pidfd_owner_retained",
    }
    texts = {"escaped_sessions", "outside_job_descendants"}
    allowed = booleans | texts | {
        "signals", "remaining", "job_active_processes", "direct_exit"
    }
    if set(row) - allowed:
        raise ValueError("Unexpected native containment receipt field")
    for name in booleans & row.keys():
        _json_bool(row[name])
    for name in texts & row.keys():
        _json_text(row[name])
    if "signals" in row:
        for item in _json_array(row["signals"]):
            _signal_receipt(item)
    if "remaining" in row:
        for item in _json_array(row["remaining"]):
            _process_identity(item)
    if "job_active_processes" in row:
        _json_int(row["job_active_processes"])
    if "direct_exit" in row and row["direct_exit"] is not None:
        _json_int(row["direct_exit"])
    # Every optional key and its complete nested shape was checked above.
    return cast(Containment, row)


def _session_control(value: object) -> SessionControl:
    row = _json_object(value)
    if set(row) != {
        "argv", "cwd", "environment", "deadline", "cleanup_deadline",
        "helper_sha256", "lease_fd", "stdout_fd", "stderr_fd", "launch", "result",
    }:
        raise ValueError("Exact native session control required")
    environment = _json_object(row["environment"])
    return {
        "argv": _text_array(row["argv"]),
        "cwd": _json_text(row["cwd"]),
        "environment": {key: _json_text(item) for key, item in environment.items()},
        "deadline": _json_number(row["deadline"]),
        "cleanup_deadline": _json_number(row["cleanup_deadline"]),
        "helper_sha256": _json_text(row["helper_sha256"]),
        "lease_fd": _json_int(row["lease_fd"]),
        "stdout_fd": _json_int(row["stdout_fd"]),
        "stderr_fd": _json_int(row["stderr_fd"]),
        "launch": _json_text(row["launch"]),
        "result": _json_text(row["result"]),
    }


def _session_result(value: object) -> SessionResult:
    row = _json_object(value)
    required = {
        "keeper", "command", "exit_code", "timed_out", "parent_lease_closed",
        "escaped_sessions",
    }
    optional = {
        "owned_direct_child_pid", "failure", "traceback", "cleanup",
        "direct_child_reaped", "cleanup_error",
    }
    if not required <= row.keys() or set(row) - required - optional:
        raise ValueError("Exact native session result receipt required")
    _process_identity(row["keeper"])
    _text_array(row["command"])
    if row["exit_code"] is not None:
        _json_int(row["exit_code"])
    _json_bool(row["timed_out"])
    _json_bool(row["parent_lease_closed"])
    _json_text(row["escaped_sessions"])
    if "owned_direct_child_pid" in row:
        _json_int(row["owned_direct_child_pid"])
    if "failure" in row:
        _error_record(row["failure"])
    if "traceback" in row:
        _json_text(row["traceback"])
    if "cleanup" in row:
        _containment(row["cleanup"])
    if "direct_child_reaped" in row:
        _json_bool(row["direct_child_reaped"])
    if "cleanup_error" in row:
        _error_record(row["cleanup_error"])
    # Required keys, every optional field and each nested shape are validated.
    return cast(SessionResult, row)


'''
s=s.replace('def _write(path: str | Path, value: object) -> None:',validation+'def _write(path: str | Path, value: object) -> None:')
p.write_text(s)
