import ast
import difflib
import hashlib
import json
from pathlib import Path

out=Path('/tmp/japp-m03-w06-native-helper-typing-composition-20261019')
p=Path('/tmp/japp-m03-w06-native-package-static-quality-20261019/work/scripts/_native_package_process.py')
before=(out/'before.py.txt').read_text()
after=p.read_text()
original=ast.parse(before)
current=ast.parse(after)
fragment=ast.parse(Path('/tmp/japp-m03-w06-windows-job-typing-20261019/windows_job_fragment.py').read_text())
class Normalize(ast.NodeTransformer):
    def visit_AnnAssign(self,n):
        if n.value is None:return None
        return ast.Assign(targets=[self.visit(n.target)],value=self.visit(n.value))
    def visit_Assign(self,n):
        self.generic_visit(n)
        if len(n.targets)>1 and isinstance(n.value,ast.Constant) and n.value.value is None:
            return [ast.Assign(targets=[target],value=ast.Constant(value=None)) for target in n.targets]
        return n
    def visit_FunctionDef(self,n):
        self.generic_visit(n)
        n.returns=None
        for arg in [*n.args.posonlyargs,*n.args.args,*n.args.kwonlyargs]:arg.annotation=None
        return n
    def visit_Name(self,n):
        if n.id=='command':n.id='argv'
        if n.id=='MAX_PROC_STAT_BYTES':return ast.Constant(value=16384)
        if n.id=='MAX_PROC_NAMES':return ast.Constant(value=65536)
        return n
    def visit_Attribute(self,n):
        self.generic_visit(n)
        if ast.dump(n,include_attributes=False)==ast.dump(ast.parse('datetime.UTC',mode='eval').body,include_attributes=False):return ast.parse('datetime.timezone.utc',mode='eval').body
        return n
    def visit_BinOp(self,n):
        self.generic_visit(n)
        if isinstance(n.op,ast.Add) and isinstance(n.left,ast.Constant) and isinstance(n.right,ast.Constant):return ast.Constant(value=n.left.value+n.right.value)
        return n
    def visit_With(self,n):
        self.generic_visit(n)
        if len(n.items)==1:
            c=n.items[0].context_expr
            if isinstance(c,ast.Call) and isinstance(c.func,ast.Name) and c.func.id=='suppress':
                return ast.Try(body=n.body,handlers=[ast.ExceptHandler(type=c.args[0],name=None,body=[ast.Pass()])],orelse=[],finalbody=[])
        return n
    def visit_Call(self,n):
        self.generic_visit(n)
        if isinstance(n.func,ast.Name):
            if n.func.id=='cast':return n.args[1]
            if n.func.id=='Containment':return ast.Dict(keys=[],values=[])
            if n.func.id=='_is_text':return ast.Call(func=ast.Name(id='isinstance',ctx=ast.Load()),args=[n.args[0],ast.Name(id='str',ctx=ast.Load())],keywords=[])
            if n.func.id=='_runtime_platform':return ast.Attribute(value=ast.Name(id='sys',ctx=ast.Load()),attr='platform',ctx=ast.Load())
            if n.func.id in {'_session_control','_session_result'}:
                assert len(n.args)==1 and isinstance(n.args[0],ast.Call) and isinstance(n.args[0].func,ast.Name) and n.args[0].func.id=='_load_json'
                return ast.Call(func=ast.Attribute(value=ast.Name(id='json',ctx=ast.Load()),attr='loads',ctx=ast.Load()),args=[ast.Call(func=ast.Attribute(value=n.args[0].args[0],attr='read_text',ctx=ast.Load()),args=[],keywords=[])],keywords=[])
        if isinstance(n.func,ast.Attribute):
            if isinstance(n.func.value,ast.Name) and n.func.value.id=='_WindowsJob' and n.func.attr=='__init__':
                return ast.Call(func=ast.Attribute(value=n.args[0],attr='__init__',ctx=ast.Load()),args=n.args[1:],keywords=n.keywords)
            if n.func.attr=='open' and isinstance(n.func.value,ast.Call) and isinstance(n.func.value.func,ast.Name) and n.func.value.func.id=='Path' and n.func.value.args and isinstance(n.func.value.args[0],ast.BinOp):
                return ast.Call(func=ast.Name(id='open',ctx=ast.Load()),args=[n.func.value.args[0],*n.args],keywords=n.keywords)
            if n.func.attr=='update' and isinstance(n.func.value,ast.Name) and n.func.value.id=='record' and len(n.args)==1 and isinstance(n.args[0],ast.Dict):
                d=n.args[0]
                return ast.Call(func=n.func,args=[],keywords=[ast.keyword(arg=k.value,value=v) for k,v in zip(d.keys,d.values,strict=True)])
        return n

def norm(n):return ast.dump(Normalize().visit(n),include_attributes=False)
orig={n.name:n for n in original.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
cur={n.name:n for n in current.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
checks={}
for name in ['_write','_sha','budget','_validate_budget','_Capture','_proc','_session_members','_pidfd','_signal_session','_settle_session','_linux_worker','run']:
    a=norm(orig[name]); b=norm(cur[name])
    checks[name]={'equal_after_documented_type_and_syntax_normalization':a==b,'before_normalized_sha256':hashlib.sha256(a.encode()).hexdigest(),'after_normalized_sha256':hashlib.sha256(b.encode()).hexdigest()}
    if a!=b:(out/(name+'-normalization-difference.txt')).write_text('\n'.join(difflib.unified_diff(a.split(', '),b.split(', '))))
standalone=next(n for n in fragment.body if isinstance(n,ast.ClassDef) and n.name=='_WindowsJob')
checks['_WindowsJob_compared_to_checked_fragment']={'equal_after_annotation_erasure':norm(standalone)==norm(cur['_WindowsJob'])}
(out/'semantic-map.json').write_text(json.dumps(checks,indent=2)+'\n')
(out/'whole-source.diff').write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='formatted-original-ee3ae0',tofile='typed-helper-737124')))
print(json.dumps(checks,indent=2))
