import datetime
import hashlib
import json
from pathlib import Path

out=Path('/tmp/japp-m03-w06-native-helper-typing-composition-20261019')
shared=Path('/tmp/japp-m03-w06-native-package-static-quality-20261019/work/scripts/_native_package_process.py')
source=shared.read_bytes()
assert hashlib.sha256(source).hexdigest()=='7371248344a87e537cb66cd8ef4650fb521440088be1bd75573dcf3ee5960b1d'
(out/'helper-after.py.txt').write_bytes(source)
windows=Path('/tmp/japp-m03-w06-windows-job-typing-20261019')
window=[]
for scope,folder in [('original_standalone_fragment',windows),('composed_helper_after_renewed_release',out)]:
    for name in ('mypy-final','ruff-final','format-final'):
        up=json.loads((folder/(name+'.upfront.json')).read_text())
        result=json.loads((folder/(name+'.result.json')).read_text())
        window.append({'scope':scope,'command':name,'started_at':up['started_at'],'ended_at':result['ended_at'],'exit_code':result['exit_code'],'receipt_path':str(folder/(name+'.upfront.json')),'after_0625UTC':up['started_at'][11:19]>'06:25:00'})
(out/'actual-static-times.json').write_text(json.dumps(window,indent=2)+'\n')
(out/'HANDOFF.md').write_text('''# Strict typed native custody helper

Shared owned helper is sealed at SHA256 **7371248344a87e537cb66cd8ef4650fb521440088be1bd75573dcf3ee5960b1d**. Only `work/scripts/_native_package_process.py` was changed; all other shared files and the canonical repository were left untouched. Root transferred this outside file from root to this author before composition. Original formatted 969-line preimage is `before.py.txt` (ee3ae0f7c945abe27fff7f6b2325f14ae4acfeff1bb80364d53675816a5d30f8).

Actual composed-helper strict mypy, Ruff and formatter check all exit0, using the existing unchanged config and existing installed tools. Upfront argv, explicit minimal env, source/config SHA, stdout/stderr and terminal results are retained. No package installation, subject import, test, command actor, native Win32/Linux operation or runtime execution occurred. The earlier standalone Windows static commands occurred AFTER06:25UTC; their original actual timestamped receipts remain at `/tmp/japp-m03-w06-windows-job-typing-20261019`. `actual-static-times.json` records their actual times separately from the composed-helper checks after root's renewed explicit bounded static release. There is no claim that the first checks finished within the original cutoff.

`semantic-map.py` / `semantic-map.json` compare all12 original non-Windows function/class bodies after explicitly enumerated syntax/type-only normalizations, and compare the complete Windows class to the already checked standalone fragment after annotation erasure. All13 comparisons are true. The mapper erases annotations, expands chained constant-None initialization, removes typed identity casts, normalizes named unchanged bounds, old `datetime.timezone.utc`/`datetime.UTC`, source-local runtime platform/text predicates, exact fixed-class initializer call with the same previously retained object, Path.open vs open, equivalent TimeoutExpired suppression, dict update syntax and argv local rename. It intentionally substitutes the new two validated JSON reads back to their old unvalidated reads: that is a separately declared fail-closed structural-validation change, not a claim that malformed input acceptance stayed identical. `whole-source.diff` retains every edit.

The concrete public interface matches the other modules' ProcessHelper Protocol: Budget work/cleanup deadlines (`int|float`), `_validate_budget(Budget)->None`, and `run(Sequence[str|Path], cwd=Path, env=Mapping[str,str], stem=Path, seconds=float, deadlines=Budget)->CompletedProcess[bytes]`. Concrete TypedDicts cover process identity, signals, capture, session control/result, containment and command receipts. JSON control/result input remains dynamically decoded to object, then exact keys, scalar types, finite numbers and every nested array/object shape are checked. Bool is refused as a JSON integer. UTF8 decoding is explicit; this helper's producer uses default ASCII-escaped json.dump output. No widening cast from unchecked JSON to a trusted receipt occurs.

No Any, type-ignore or global lint-rule weakening was added. Local justified exceptions preserve ordered ownership coordination, the drain's transferred sink lifetime, a bounded snapshot of /proc names, and already validated argv-only no-shell launches. The conditional Windows APIs and Linux pidfd APIs have narrow Protocol surfaces; the only broader function registry is for setting unchanged argtypes/restypes, while each invocation has concrete parameters/results. Final return's int cast is justified by the existing success predicate requiring exit_code==0.

Safety order remains: retain `_WindowsJob` before explicit `_WindowsJob.__init__(windows,...)`; retain native hProcess/hThread before Job assignment; assign while suspended; require ResumeThread==1; close held primary thread after resume; preserve native partial-launch unwind and inherited handle finally; retain uncertain owners. Linux retains exact session identity+pidfd and direct Popen; there is no numeric-PID signal fallback. Same capture cap, /proc bounds, TERM/KILL grace, command/work/cleanup windows, daemon-reader ownership, pre-pidfd quarantine and terminal success predicates remain. No result claims complete escaped-session/Job descendant observation. Actual Windows ABI/platform execution and composed product tests remain outside this static proof.

Preparation diagnostics were visible tool responses only: first composed pass reported missing Callable, redundant scalar casts, sys.platform analysis reachability, TypedDict.update keyword typing and original lint issues; second pass reported mypy's instance.__init__ unsound access. They were fixed using explicit platform API predicates, typed dict update, fixed-class initialization with the same owned object and narrow local lint rationale. No product test or actor failure is being claimed. Initial semantic mapper reported only chained `child=windows=None` representation mismatch; its difference file remains. The mapper was corrected to split constant-None chains and all13 comparisons then passed. This is checker preparation history, not product execution.
''')
files={}
for p in sorted(out.iterdir()):
    if p.is_file() and p.name!='retention-manifest.json':
        body=p.read_bytes(); files[p.name]={'sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body)}
manifest={'scope':'SOURCE_ONLY_COHERENT_HELPER_STATIC_CHECKS_NO_ACTORS','source_sha256':hashlib.sha256(source).hexdigest(),'files':files,'generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cache_excluded':True}
(out/'retention-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'helper':manifest['source_sha256'],'manifest':hashlib.sha256((out/'retention-manifest.json').read_bytes()).hexdigest(),'handoff':hashlib.sha256((out/'HANDOFF.md').read_bytes()).hexdigest(),'semantic_map':hashlib.sha256((out/'semantic-map.json').read_bytes()).hexdigest(),'members':len(files),'static_times':window},indent=2))
