import ast
import hashlib
from pathlib import Path

out=Path('/tmp/japp-m03-w06-native-helper-typing-composition-20261019')
shared=Path('/tmp/japp-m03-w06-native-package-static-quality-20261019/work/scripts/_native_package_process.py')
before=(out/'before.py.txt').read_text()
s=before
old=ast.parse(before)
job=next(x for x in old.body if isinstance(x,ast.ClassDef) and x.name=='_WindowsJob')
lines=s.splitlines(keepends=True)
fragment=Path('/tmp/japp-m03-w06-windows-job-typing-20261019')
newjob=(fragment/'class-after.py.txt').read_text()
s=''.join(lines[:job.lineno-1])+newjob+''.join(lines[job.end_lineno:])
prelude=(fragment/'imports-and-ffi-prelude.py.txt').read_text()
ffi=prelude[prelude.index('class _WinFunction'):]
# Existing Windows returns retain exact keys but share the typed containment
# envelope used by command evidence. Native predicates and output data do not change.
ffi=ffi[:ffi.index('class _WindowsClosure')]+'''_WINDOWS_WAIT_TIMEOUT = 258


'''
s=s.replace('from pathlib import Path\n','from pathlib import Path\nfrom collections.abc import Mapping, Sequence\nimport ctypes\nfrom ctypes import wintypes\nimport importlib\nfrom typing import NotRequired, Protocol, TypedDict, cast\n')
constants=s.index('WORK_SECONDS = ')
types='''class Budget(TypedDict):
    work_deadline: int | float
    cleanup_deadline: int | float


class ErrorRecord(TypedDict):
    type: str
    message: str


class ProcessIdentity(TypedDict):
    pid: int
    pgid: int
    sid: int
    birth: int


class SignalReceipt(TypedDict):
    identity: ProcessIdentity
    signal: str
    authority: str


class CaptureResult(TypedDict):
    captured_bytes: int
    discarded_bytes: int
    overflow: bool
    errors: list[ErrorRecord]
    readers_closed: bool


class Containment(TypedDict, total=False):
    signals: list[SignalReceipt]
    session_members_absent: bool
    escaped_sessions: str
    remaining: list[ProcessIdentity]
    held_job: bool
    terminated_job: bool
    job_active_processes: int
    direct_exit: int | None
    all_job_members_closed: bool
    no_process_created: bool
    assigned_before_resume: bool
    outside_job_descendants: str
    keeper_reaped: bool
    session_absent: bool
    launched_owner_retained: bool
    held_pidfd_owner_retained: bool


class SessionControl(TypedDict):
    argv: list[str]
    cwd: str
    environment: dict[str, str]
    deadline: int | float
    cleanup_deadline: int | float
    helper_sha256: str
    lease_fd: int
    stdout_fd: int
    stderr_fd: int
    launch: str
    result: str


class SessionResult(TypedDict):
    keeper: ProcessIdentity
    command: list[str]
    exit_code: int | None
    timed_out: bool
    parent_lease_closed: bool
    escaped_sessions: str
    owned_direct_child_pid: NotRequired[int]
    failure: NotRequired[ErrorRecord]
    traceback: NotRequired[str]
    cleanup: NotRequired[Containment]
    direct_child_reaped: NotRequired[bool]
    cleanup_error: NotRequired[ErrorRecord]


class CommandRecord(TypedDict):
    argv: list[str]
    cwd: str
    environment: dict[str, str]
    seconds: float
    work_deadline: int | float
    cleanup_deadline: int | float
    start_utc: str
    escaped_sessions_or_jobs: str
    exit_code: NotRequired[int | None]
    success: NotRequired[bool]
    failure: NotRequired[ErrorRecord | None]
    cleanup_error: NotRequired[ErrorRecord | None]
    containment: NotRequired[Containment]
    capture: NotRequired[CaptureResult]
    seconds_elapsed: NotRequired[float]
    end_utc: NotRequired[str]
    stdout_sha256: NotRequired[str]
    stderr_sha256: NotRequired[str]
    native_launch_failure: NotRequired[ErrorRecord | None]
    retained_inherited_handle_count: NotRequired[int]


class _CaptureSink(Protocol):
    def write(self, data: bytes, /) -> object: ...
    def close(self) -> None: ...


class _PidfdOS(Protocol):
    def pidfd_open(self, pid: int, flags: int = 0) -> int: ...


class _PidfdSignal(Protocol):
    def pidfd_send_signal(self, pidfd: int, sig: int) -> None: ...


'''
s=s[:constants]+types+ffi+s[constants:]
s=s.replace('_PENDING_WINDOWS_OWNERS = []','_PENDING_WINDOWS_OWNERS: list[_WindowsJob] = []')
s=s.replace('_PENDING_LINUX_OWNERS = []','_PENDING_LINUX_OWNERS: list[\n    tuple[subprocess.Popen[bytes], int | None, ProcessIdentity | None]\n] = []')
replacements={
'def _write(path, value):':'def _write(path: str | Path, value: object) -> None:',
'def _sha(path):':'def _sha(path: str | Path) -> str:',
'def budget():':'def budget() -> Budget:',
'def _validate_budget(value):':'def _validate_budget(value: Budget) -> None:',
'    def __init__(self, stdout_path, stderr_path):':'    def __init__(self, stdout_path: str | Path, stderr_path: str | Path) -> None:',
'        self.errors = []':'        self.errors: list[ErrorRecord] = []',
'        self.threads = []':'        self.threads: list[threading.Thread] = []',
'        self.readers = []':'        self.readers: list[int] = []',
'        self.writers = []':'        self.writers: list[int] = []',
'    def _drain(self, descriptor, sink):':'    def _drain(self, descriptor: int, sink: _CaptureSink) -> None:',
'    def start(self):':'    def start(self) -> None:',
'    def close_parent_writers(self):':'    def close_parent_writers(self) -> None:',
'    def finish(self):':'    def finish(self) -> CaptureResult:',
'def _proc(pid):':'def _proc(pid: int) -> ProcessIdentity | None:',
'def _session_members(sid):\n    result = []':'def _session_members(sid: int) -> list[ProcessIdentity]:\n    result: list[ProcessIdentity] = []',
'def _pidfd(row):':'def _pidfd(row: ProcessIdentity) -> int | None:',
'os.pidfd_open(row["pid"])':'cast(_PidfdOS, os).pidfd_open(row["pid"])',
'def _signal_session(saved_keeper, sig, receipts):':'def _signal_session(\n    saved_keeper: ProcessIdentity, sig: int, receipts: list[SignalReceipt]\n) -> None:',
'signal.pidfd_send_signal(descriptor, sig)':'cast(_PidfdSignal, signal).pidfd_send_signal(descriptor, sig)',
'def _settle_session(saved_keeper, deadline, child=None):\n    result = {':'def _settle_session(\n    saved_keeper: ProcessIdentity,\n    deadline: int | float,\n    child: subprocess.Popen[bytes] | None = None,\n) -> Containment:\n    result: Containment = {',
'def _linux_worker(control):\n    c = json.loads(Path(control).read_text())':'def _linux_worker(control: str | Path) -> int:\n    c = _session_control(_load_json(Path(control)))',
'    child = None\n    result = {':'    child: subprocess.Popen[bytes] | None = None\n    result: SessionResult = {',
'        child = subprocess.Popen(\n            c["argv"],':'        child = subprocess.Popen(  # noqa: S603 -- validated exact argv, no shell\n            c["argv"],',
'            and result.get("cleanup", {}).get("session_members_absent")':'            and result.get("cleanup", Containment()).get("session_members_absent")',
'            and not result.get("cleanup", {}).get("signals")':'            and not result.get("cleanup", Containment()).get("signals")',
'    def settle(self, deadline: float) -> _WindowsClosure | _WindowsAssignedClosure:':'    def settle(self, deadline: float) -> Containment:',
'def run(argv, *, cwd, env, stem, seconds, deadlines):':'def run(  # noqa: PLR0912, PLR0915 -- one ordered owner acquisition/unwind\n    argv: Sequence[str | Path],\n    *,\n    cwd: Path,\n    env: Mapping[str, str],\n    stem: Path,\n    seconds: float,\n    deadlines: Budget,\n) -> subprocess.CompletedProcess[bytes]:',
'    record = {':'    record: CommandRecord = {',
'    child = windows = None\n    lease = None\n    keeper = None\n    keeper_fd = None\n    failure = None\n    exit_code = None\n    cleanup = {}':'    child: subprocess.Popen[bytes] | None = None\n    windows: _WindowsJob | None = None\n    lease: int | None = None\n    keeper: ProcessIdentity | None = None\n    keeper_fd: int | None = None\n    failure: ErrorRecord | None = None\n    exit_code: int | None = None\n    cleanup: Containment = {}',
'            control = {':'            control: SessionControl = {',
'                open(str(stem) + ".keeper.stdout", "xb") as stdout,':'                Path(str(stem) + ".keeper.stdout").open("xb") as stdout,',
'                open(str(stem) + ".keeper.stderr", "xb") as stderr,':'                Path(str(stem) + ".keeper.stderr").open("xb") as stderr,',
'                    child = subprocess.Popen(\n':'                    child = subprocess.Popen(  # noqa: S603 -- pinned helper argv\n',
'                session = json.loads(\n                    Path(str(stem) + ".session-result.json").read_text()\n                )':'                session = _session_result(\n                    _load_json(Path(str(stem) + ".session-result.json"))\n                )',
'                cleanup = session.get("cleanup", {})':'                cleanup = session.get("cleanup", Containment())',
'        cleanup_error = None':'        cleanup_error: ErrorRecord | None = None',
'signal.pidfd_send_signal(keeper_fd, signal.SIGKILL)':'cast(_PidfdSignal, signal).pidfd_send_signal(keeper_fd, signal.SIGKILL)',
'        exit_code,\n        Path(str(stem) + ".stdout").read_bytes(),':'        cast(int, exit_code),\n        Path(str(stem) + ".stdout").read_bytes(),',
}
for a,b in replacements.items():
    if a not in s: raise ValueError('missing replacement: '+a)
    s=s.replace(a,b)
# Retain exact command coercion while making the Sequence interface explicit.
s=s.replace('    argv = [str(x) for x in argv]','    command = [str(x) for x in argv]')
# run only: replace argv reads with the concrete normalized list, excluding parameter.
head,run=s.split('def run(',1)
run=run.replace('"argv": argv,','"argv": command,').replace('if (\n        not argv','if (\n        not command').replace('Path(argv[0])','Path(command[0])').replace('for x in argv) or any','for x in command) or any').replace('windows.__init__(argv,','windows.__init__(command,').replace('        argv,\n        cast(int, exit_code),','        command,\n        cast(int, exit_code),')
s=head+'def run('+run
(out/'after-prevalidation.py.txt').write_text(s)
shared.write_text(s)
print(hashlib.sha256(s.encode()).hexdigest())
