import ast
import hashlib
import json
from pathlib import Path
import re

out=Path('/tmp/japp-m03-w06-measured-corrections-independent-review-20261019')
proposal=Path('/tmp/japp-m03-w06-shared-native-package-measured-corrections-20261019')
raw=Path('/tmp/japp-m03-w06-shared-native-package-focused-actual-20261019')
plan=json.loads((proposal/'PLAN.json').read_text())
checks=[]
def check(n,a,e=True):checks.append({'check':n,'pass':a==e,'actual':a,'expected':e})
def sha(b):return hashlib.sha256(b).hexdigest()
check('exacttwofiles',sorted(plan['changes']),['scripts/check_portability.py','scripts/native_package_pipeline.py'])
for rel,pins in plan['changes'].items():
 old=(proposal/'before'/rel).read_bytes();new=(proposal/'after'/rel).read_bytes()
 check(rel+' beforeSHA',sha(old),pins['before_sha256']);check(rel+' afterSHA',sha(new),pins['after_sha256'])
 def funcs(b):
  s=b.decode();lines=s.splitlines(keepends=True)
  return {n.name:''.join(lines[n.lineno-1:n.end_lineno]) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
 a,b=funcs(old),funcs(new)
 changes=[k for k in a if a[k]!=b[k]]
 check(rel+' exactlyonechangedfunction',changes,['wheel_code'] if 'pipeline' in rel else ['_check_matrix'])
pre=json.loads((raw/'before.json').read_text());post=json.loads((raw/'after.json').read_text())
check('failedfocus source1983 snapshotneutral',pre==post and len(pre['files'])==1983)
check('failedfocus runtime40 snapshotneutral',json.loads((raw/'runtime-before.json').read_text())==json.loads((raw/'runtime-after.json').read_text()) and len(json.loads((raw/'runtime-before.json').read_text()))==40)
for rel,pins in plan['changes'].items():check(rel+' actualfailedfocus preimage',pre['files'][rel]['sha256'],pins['before_sha256'])
logs=raw/'focused-pytest.log';b=logs.read_bytes();text=b.decode()
check('exactfailedsummary',bool(re.search(r'(?m)^2 failed, 713 passed in 113\.80s',text)))
check('exacttwofailedtestidentities',re.findall(r'(?m)^FAILED (\S+)',text),['scripts/tests/test_portability.py::test_real_repository_passes_the_policy','scripts/tests/test_portability.py::test_disconnected_dummy_matrix_cannot_satisfy_policy'])
commands=['static-policy','ruff','format','mypy','focused-pytest']
for name in commands:
 result=json.loads((raw/(name+'-result.json')).read_text())
 check(name+' exit',result['exit_code'],1 if name=='focused-pytest' else 0)
 check(name+' heldleader reaped/groupGONE/no signals',result['owned_leader_reaped'] and result['owned_group_after']=='GONE' and result['cleanup']==[])
 check(name+' originalrawdigest',sha((raw/(name+'.log')).read_bytes()),result['log_sha256'])
check('fivecommands onlynoportability/collectionexecution',sorted(p.name for p in raw.glob('*-result.json')),sorted(n+'-result.json' for n in commands))
closure=json.loads((raw/'closure.json').read_text())
check('closure preserves failure/notallseven',closure['all_seven_commands_executed'] is False and closure['all_executed_commands_exit0'] is False)
check('noGUIhostedmilestoneclaim',closure['milestone_accepted'] is closure['gui_execution'] is closure['hosted_ci'] is False)
assert all(x['pass'] for x in checks)
(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
(out/'findings.json').write_text(json.dumps({'decision':'CLEAR_SOURCE_CORRECTIONS_AND_FAILED_DATA_SCOPE','reviewer':'/root/fresh_safety_review','authority':'NONE','checks':len(checks),'passed':len(checks),'material_findings':[],'corrected_execution':'NOT_EXECUTED_BY_REVIEWER','historical_actual_result':'FOCUSED_FAIL_2_FAILED_713_PASSED_PORTABILITY_AND_COLLECTION_NOTRUN'},indent=2)+'\n')
(out/'REVIEW.md').write_text('''# Measured two-fix independent review: clear

No material finding in the two-file/four-line correction. Both recorded preimages match the actual failed focus1983 source map. Only wheel_code and _check_matrix change; no tests/assertions/config/thresholds/native helper/build/XML/PowerShell source changes. This source admission is not a corrected execution result.

The wheel correction replaces manual namespace+'/' concatenation with PurePosixPath components for the two actual fixed top-level namespaces. Raw archive member names remain dict keys, all existing duplicate/traversal/absolute/backslash/native/symlink/size/metadata refusals remain, and complete actual==expected source/resource equality remains. Thus normalization aliases cannot match canonical expected source files and are still refused. No install surface is added.

The CI correction always excludes the reserved optional package job from canonical matrix candidates. The exact invalid-package002 check still occurs upfront; an invalid package job cannot satisfy the canonical baseline. This removes its accidental contribution to multiple-candidate early return so the existing disconnected dummy matrix reaches the original required-command003 refusal. Invalid package recipes still fail; canonical/oracle policy is not weakened.

Original focus is FAIL: five actual commands execute. Static policy/Ruff/format/mypy exit0; pytest exits1 with exact715 outcomes:713PASS/2FAIL in113.80s. Pytest command wrapper elapsed113.991023s remains distinct. Exact failures are test_real_repository_passes_the_policy (new native pipeline manual path concat003) and test_disconnected_dummy_matrix_cannot_satisfy_policy (required003 absent because invalid package job made multiple matrix candidates). Remaining standalone portability and full-collection commands did NOT run. The outer seven-command wrapper's exit1 is root-observed; local closure explicitly records all_seven=false/all_exit0=false, without fabricating a local outerresult file.

All1983 logical source path/byte/hash/mode rows and HEAD6867ce82/tree6200/status are unchanged across this failed invocation, with the expected dirty adoption context. This is not a clean whole-source/immutable-head result. Runtime40 maps are unchanged. Every five held group/leader is GONE/reaped/no cleanup signals. No Windows/native/runtime/platform/GUI/full/M04/milestone acceptance is inferred from these local tests. No current-tree rebind or failed evidence relabel is performed.

Review only read/hashed original source/raw data and used standard-library AST/documentary parsing. No product module import, test, actor, native/API/browser, compiler, runtime/cache image scan or canonical write occurred. Root's existing corrected focus release governs the next single evaluation; retain any resulting failure.
''')
print(json.dumps({'checks':len(checks),'report':sha((out/'REVIEW.md').read_bytes()),'findings':sha((out/'findings.json').read_bytes())},indent=2))
