import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile

raw=Path('/tmp/japp-m03-w06-shared-native-package-focused-actual-20261019')
correction=Path('/tmp/japp-m03-w06-shared-native-package-measured-corrections-20261019')
review=Path('/tmp/japp-m03-w06-measured-corrections-independent-review-20261019')
output=Path('/tmp/japp-m03-w06-shared-native-package-failed-focus-retained-20261019')
archive=output/'proof.tar.gz'
assert not archive.exists()
inputs={}
for p in sorted(raw.iterdir()):
 assert p.is_file() and not p.is_symlink(),p
 inputs['failed-focus/'+p.name]=p
for p in sorted(correction.rglob('*')):
 if p.is_file():
  assert not p.is_symlink()
  inputs['two-source-corrections/'+p.relative_to(correction).as_posix()]=p
for name in ['REVIEW.md','findings.json','checks.json','audit.py','build-proof.py']:
 inputs['independent-review/'+name]=review/name
members={}
for name,path in inputs.items():
 b=path.read_bytes();assert len(b)<2*1024*1024
 members[name]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'original_path':str(path)}
index=json.dumps({'scope':'EXACT_FAILED_FOCUS_ORIGINALS_PLUS_REVIEWED_TWO_SOURCE_CORRECTIONS_NO_CORRECTED_RESULT','index_excludes_itself':True,'files':members,'omissions':['No runtime/native images/caches/interpreters','No later corrected evaluation data','No fabricated raw local outerresult; wrapperexit1 is rootobserved and originalclosure failure retained']},indent=2).encode()+b'\n'
with tarfile.open(archive,'x:gz') as tf:
 for name,path in inputs.items():
  tf.add(path,arcname=name,recursive=False)
 info=tarfile.TarInfo('members.json');info.size=len(index);info.mode=0o644
 tf.addfile(info,io.BytesIO(index))
expected={**{n:{'sha256':v['sha256'],'bytes':v['bytes']} for n,v in members.items()},'members.json':{'sha256':hashlib.sha256(index).hexdigest(),'bytes':len(index)}}
with tarfile.open(archive) as tf:
 rows=tf.getmembers();names=[r.name for r in rows]
 assert len(names)==len(set(names)) and set(names)==set(expected)
 for r in rows:
  q=PurePosixPath(r.name);assert r.isfile() and not r.issym() and not r.islnk() and not q.is_absolute() and '..' not in q.parts
  b=tf.extractfile(r).read();assert expected[r.name]=={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
 for n,p in inputs.items():assert hashlib.sha256(p.read_bytes()).hexdigest()==members[n]['sha256']
b=archive.read_bytes()
manifest={'archive':{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'members':len(expected)},'files':expected,'scope':'FAILURE_PRESERVED_SOURCE_CORRECTIONS_REVIEW_ONLY_NO_CORRECTED_EXECUTION','raw_originals_unchanged':True,'all_safe_regular_unique_readback':True}
(output/'retention-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(output/'README.md').write_text('Original five-command focused FAIL713PASS/2FAIL with source1983/runtime40 unchanged and all held groups GONE, plus different reviewed two-file source correction. Remaining portability/collection NOTRUN; no corrected result/native/platform/full/milestonePASS. Full exact original source/raw/receipts in the finite index. No native images/caches copied.\n')
print(json.dumps({'archive':manifest['archive'],'outer_manifest_sha256':hashlib.sha256((output/'retention-manifest.json').read_bytes()).hexdigest(),'raw_files':len(list(raw.iterdir())),'correction_files':sum(p.is_file() for p in correction.rglob('*'))},indent=2))
