# Windows fixture and local-origin source review

/root clears13 checks. Both complete files restore their exact beforeimages after reversing the three fixture-literal replacements and six origin arguments plus helper. Same buildstage, nativeAPI count, SystemRoot/env and all4 Rust test assertions remain. Host tmp_path provides an actual absolute fixture directory; platform origin follows the checksum-pinned official Tauri2.12.4 example. Production ACL/CSP/capabilities/commands are untouched. No tests/native execution or WindowsPASS occurs in this review; original660f failures remain.
