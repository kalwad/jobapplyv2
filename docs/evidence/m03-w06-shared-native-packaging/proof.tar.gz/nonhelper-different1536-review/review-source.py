import ast
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess

packet=Path('/tmp/japp-m03-w06-shared-native-package-source-quality-v4-20261019')
v3=Path('/tmp/japp-m03-w06-shared-native-package-source-quality-v3-20261019')
out=Path('/tmp/japp-m03-w06-nonhelper-source-quality-independent-review-20261019')
checks=[]
def check(name,actual,expected=True): checks.append({'check':name,'pass':actual==expected,'actual':actual,'expected':expected})
def sha(b):return hashlib.sha256(b).hexdigest()
m=json.loads((packet/'source-manifest.json').read_text())
check('v4 manifest pin',sha((packet/'source-manifest.json').read_bytes()),'9f71d4868a9c9c399a29f3ee0640268e590f4890e3868409c26059aa01660ae1')
check('v4 patch pin',sha((packet/'SOURCE_JOIN.patch').read_bytes()),'b79fec089b225b38d105aad30d15ea2d6535c8c4783b3301d157ce3b09b6844a')
check('manifest member count',len(m['files']),m['payload_file_count'])
for name,expected in m['files'].items():
 p=packet/name;parts=PurePosixPath(name)
 check('safe regular '+name,not p.is_symlink() and p.is_file() and not parts.is_absolute() and '..' not in parts.parts)
 b=p.read_bytes();check('hash '+name,sha(b),expected['sha256']);check('size '+name,len(b),expected['bytes'])
post=json.loads((packet/'POSTIMAGES.json').read_text())['postimages']
check('15postimages',len(post),15)
for name,expected in post.items():
 b=(packet/'afterimages'/name).read_bytes();check('afterimage '+name,sha(b),expected['after_sha256'])
 if expected['action']=='MODIFY':
  old=(packet/'preimages'/name).read_bytes()
  check('preimage '+name,sha(old),expected['base_preimage_sha256'])
  actual=subprocess.run(['git','-C','/Users/tanishkalwad/jobapplyv2','cat-file','blob','660f9f1deea129ceccba48c9d560daf1791a95ff:'+name],capture_output=True,check=True).stdout
  check('immutable660f '+name,sha(actual),sha(old))
 if name!='scripts/native_package_ci.py':check('v3v4 postimage unchanged '+name,b==(v3/'afterimages'/name).read_bytes())
# Author exclusion: authenticate helper bytes only, no source correctness verdict.
check('helper exact author-excluded737124',post['scripts/_native_package_process.py']['after_sha256'],'7371248344a87e537cb66cd8ef4650fb521440088be1bd75573dcf3ee5960b1d')
patch=(packet/'SOURCE_JOIN.patch').read_text()
paths=re.findall(r'^\+\+\+ b/(.+)$',patch,re.MULTILINE)
check('patch exact closed15paths',sorted(paths),sorted(post))
protected=json.loads((packet/'parent-inputs/PROTECTED_CURRENT_SOURCE.json').read_text())['unchanged_not_in_patch']
check('buildXMLPS not patched',not set(protected)&set(paths))
for name,record in protected.items():
 b=subprocess.run(['git','-C','/Users/tanishkalwad/jobapplyv2','cat-file','blob','660f9f1deea129ceccba48c9d560daf1791a95ff:'+name],capture_output=True,check=True).stdout
 check('protectedimmutable '+name,sha(b),record['sha256'])
# Exact typed refactor preservation of all41 already-existing core rules.
mapfile=packet/'test-source-correspondence/ci-guard-mutation-correspondence.json'
core=json.loads(mapfile.read_text())['core_policy_functions_preserved_byte_for_byte']
a=(packet/'test-source-correspondence/source-quality-pair-beforeimages/scripts/check_portability.py').read_text();b=(packet/'afterimages/scripts/check_portability.py').read_text()
def funcs(s):
 lines=s.splitlines(keepends=True)
 return {n.name:''.join(lines[n.lineno-1:n.end_lineno]) for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
af,bf=funcs(a),funcs(b)
check('corepolicy41 count',len(core),41)
for name in core:check('byteexactcore '+name,af[name],bf[name])
# Existing mutation parameter/order/assertions bind actual source, not just prose.
a=(packet/'test-source-correspondence/source-quality-pair-beforeimages/scripts/tests/test_ci_native_package.py').read_text();b=(packet/'afterimages/scripts/tests/test_ci_native_package.py').read_text()
at,bt=ast.parse(a),ast.parse(b)
def tests(t):return {n.name:n for n in t.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
aa,bb=tests(at),tests(bt);check('CI testcase function identities exact',list(aa),list(bb))
for name in aa:
 old=[ast.dump(n,include_attributes=False) for n in ast.walk(aa[name]) if isinstance(n,ast.Assert)]
 new=[ast.dump(n,include_attributes=False) for n in ast.walk(bb[name]) if isinstance(n,ast.Assert)]
 check('CI original assertions '+name,old,new)
old=aa['test_changed_package_contract_is_refused'];new=bb['test_changed_package_contract_is_refused']
check('25 mutation decorator exact',ast.dump(old.decorator_list[0],include_attributes=False),ast.dump(new.decorator_list[0],include_attributes=False))
check('25 mutation params',len(old.decorator_list[0].args[1].elts),25)
# Static receipts are actual source-bound final checks, not execution claims.
phase=packet/'quality-history/phase-7-final-module-registration'
for stem in ['ruff','mypy','format-check']:
 result=json.loads((phase/(stem+'.result.json')).read_text())
 check('phase7 '+stem+' actualexit0',result.get('exit_code',result.get('exit')),0)
for name in post:
 if name.endswith('.py'):check('phase7 exactchecked '+name,(phase/'after'/name).read_bytes(),(packet/'afterimages'/name).read_bytes())
# Preserve raw checks but summarize byte-valued diagnostics by hashes.
def render(v):
 if isinstance(v,bytes):return {'bytes':len(v),'sha256':sha(v)}
 return v
for row in checks:row['actual']=render(row['actual']);row['expected']=render(row['expected'])
(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'passed':sum(c['pass'] for c in checks),'failed':[c['check'] for c in checks if not c['pass']]},indent=2))
