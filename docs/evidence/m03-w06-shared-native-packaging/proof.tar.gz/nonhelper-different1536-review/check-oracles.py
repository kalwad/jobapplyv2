import ast
import json
from pathlib import Path

packet=Path('/tmp/japp-m03-w06-shared-native-package-source-quality-v4-20261019')
oldroot=Path('/tmp/japp-m03-w06-shared-native-package-source-join-660f-20261019/afterimages')
out=Path('/tmp/japp-m03-w06-nonhelper-source-quality-independent-review-20261019')
checks=[]
class Aliases(ast.NodeTransformer):
 def visit_Name(self,n):
  if n.id=='packages':return ast.Subscript(value=ast.Name(id='result',ctx=ast.Load()),slice=ast.Constant(value='packages'),ctx=ast.Load())
  return n
 def visit_Attribute(self,n):
  self.generic_visit(n)
  if n.attr=='value' and isinstance(n.value,ast.Name) and n.value.id=='original':n.attr='exception'
  return n

def dump(n):return ast.dump(Aliases().visit(n),include_attributes=False)
def methods(source):return {n.name:n for n in ast.walk(ast.parse(source)) if isinstance(n,ast.FunctionDef)}
for rel in ['scripts/tests/test_native_package_inputs.py','scripts/tests/test_native_package_pending_owner.py']:
 old=methods((oldroot/rel).read_text());new=methods((packet/'afterimages'/rel).read_text())
 tests=lambda d:[k for k in d if k.startswith('test_')]
 checks.append({'check':rel+' originaltestidentities','pass':tests(old)==tests(new),'count':len(tests(old))})
 for fn,node in old.items():
  if fn not in new:continue
  actual_asserts=[dump(n.test) for n in ast.walk(new[fn]) if isinstance(n,ast.Assert)]
  raises=[n for n in ast.walk(new[fn]) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='pytest' and n.func.attr in ('raises','warns')]
  for call in ast.walk(node):
   if not isinstance(call,ast.Call) or not isinstance(call.func,ast.Attribute) or not isinstance(call.func.value,ast.Name) or call.func.value.id!='self':continue
   kind=call.func.attr;expected=None;ok=None
   if kind in ('assertEqual','assertIs','assertIn','assertNotIn'):
    op={'assertEqual':ast.Eq,'assertIs':ast.Is,'assertIn':ast.In,'assertNotIn':ast.NotIn}[kind]()
    expected=ast.Compare(left=call.args[0],ops=[op],comparators=[call.args[1]])
   elif kind=='assertIsNone':expected=ast.Compare(left=call.args[0],ops=[ast.Is()],comparators=[ast.Constant(value=None)])
   elif kind=='assertFalse':expected=ast.UnaryOp(op=ast.Not(),operand=call.args[0])
   elif kind=='assertTrue':expected=call.args[0]
   elif kind=='assertRaisesRegex':
    ok=any(n.func.attr=='raises' and len(n.args)==1 and dump(n.args[0])==dump(call.args[0]) and any(k.arg=='match' and dump(k.value)==dump(call.args[1]) for k in n.keywords) for n in raises)
   elif kind in ('assertRaises','assertWarns'):
    target='raises' if kind=='assertRaises' else 'warns'
    ok=any(n.func.attr==target and [dump(a) for a in n.args]==[dump(a) for a in call.args] for n in raises)
   elif kind.startswith('assert'):raise ValueError(kind)
   else:continue
   if expected is not None:ok=dump(expected) in actual_asserts
   checks.append({'check':rel+':'+fn+':'+kind,'pass':ok,'original':ast.unparse(call)})
(out/'oracle-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'passed':sum(c['pass'] for c in checks),'failed':[c for c in checks if not c['pass']]},indent=2))
