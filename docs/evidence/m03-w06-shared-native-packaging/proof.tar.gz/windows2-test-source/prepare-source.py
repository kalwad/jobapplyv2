"""Narrow source preparation only; no tests, compiler or subject imports."""
import ast,difflib,hashlib,json,re,stat,tarfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=Path('/Users/tanishkalwad/jobapplyv2')
CRATE=Path('/Users/tanishkalwad/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/tauri-2.12.4')
paths=['scripts/tests/test_windows_builder.py','apps/desktop/src-tauri/src/diagnostics/tests/tauri.rs']
sha=lambda b:hashlib.sha256(b).hexdigest()
def image(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':sha(b),'mode':oct(stat.S_IMODE(p.stat().st_mode))}
before={rel:(ROOT/rel).read_text() for rel in paths};after={};checks=[]
def check(label,value):checks.append({'id':label,'passed':bool(value)});assert value,label
py=before[paths[0]];marker='    class Buffer(Protocol):\n'
check('one-buffer-fixture-marker',py.count(marker)==1)
py=py.replace(marker,'    trusted_windows = str(tmp_path / "trusted-windows")\n\n'+marker)
check('three-exact-old-path-literals',py.count('"/trusted/windows"')==3)
py=py.replace('"/trusted/windows"','trusted_windows');after[paths[0]]=py
rust=before[paths[1]];anchor='const ID: &str = "req_00000000000000000000000001";\n'
helper='''fn local_app_origin() -> &'static str {
    if cfg!(any(windows, target_os = "android")) {
        "http://tauri.localhost"
    } else {
        "tauri://localhost"
    }
}
'''
check('six-original-local-origin-sites',rust.count('"tauri://localhost"')==6)
check('one-original-id-anchor',rust.count(anchor)==1)
rust=rust.replace('"tauri://localhost"','local_app_origin()').replace(anchor,helper+anchor);after[paths[1]]=rust
check('python-reverse-source-exact',py.replace('    trusted_windows = str(tmp_path / "trusted-windows")\n\n','').replace('trusted_windows','"/trusted/windows"')==before[paths[0]])
check('rust-reverse-source-exact',rust.replace(helper,'').replace('local_app_origin()','"tauri://localhost"')==before[paths[1]])
ast.parse(py)
oldtests={n.name:n for n in ast.parse(before[paths[0]]).body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
newtests={n.name:n for n in ast.parse(py).body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
check('python-test-inventory-exact',set(oldtests)==set(newtests))
check('rust-test-inventory-exact',re.findall(r'#\[test\]\s*fn\s+(\w+)',before[paths[1]])==re.findall(r'#\[test\]\s*fn\s+(\w+)',rust))
historical=json.loads(Path('/tmp/japp-m03-w06-shared-native-package-focused-actual-20261019/before.json').read_text())
check('preimages-exact-focused1983-source',all(image(ROOT/rel)['sha256']==historical['files'][rel]['sha256'] for rel in paths))
lock=(ROOT/'apps/desktop/src-tauri/Cargo.lock').read_text();match=re.search(r'\[\[package\]\]\nname = "tauri"\nversion = "2\.12\.4"\nsource = "registry\+https://github.com/rust-lang/crates.io-index"\nchecksum = "([0-9a-f]{64})"',lock)
check('pinned-tauri-crate-version',match is not None)
archive=Path('/Users/tanishkalwad/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f/tauri-2.12.4.crate')
check('crate-archive-checksum-matches-lock',image(archive)['sha256']==match[1]=='f316751027fc2644221d1a448564d519efb07067fda584879d9cda966391d212')
evidence={}
for name,span in [('src/test/mod.rs',(214,229)),('src/webview/mod.rs',(1961,2008)),('src/manager/mod.rs',(326,355))]:
 p=CRATE/name
 with tarfile.open(archive,'r:gz') as tar:
  member=tar.getmember('tauri-2.12.4/'+name);check('primary-crate-member-regular-'+name,member.isfile() and member.size<256*1024)
  official=tar.extractfile(member).read()
 check('primary-crate-file-bytes-'+name,p.read_bytes()==official);lines=p.read_text().splitlines(True)
 excerpt=''.join(f'{number}: {lines[number-1]}' for number in range(span[0],span[1]+1))
 target=HERE/'primary-source'/(name.replace('/','-')+'.excerpt.txt');target.parent.mkdir(exist_ok=True);target.write_text(excerpt)
 evidence[name]={'original_path':str(p),**image(p),'official_archive_member_sha256':sha(official),'selected_lines':list(span),'excerpt_path':str(target.relative_to(HERE))}
check('pinned-framework-doc-example-exact', 'url: if cfg!(any(windows, target_os = "android")) {\n///                 "http://tauri.localhost"\n///             } else {\n///                 "tauri://localhost"' in (CRATE/'src/test/mod.rs').read_text())
patch=''
for rel in paths:
 for folder,text in [('before',before[rel]),('after',after[rel])]:
  p=HERE/folder/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 patch+=''.join(difflib.unified_diff(before[rel].splitlines(True),after[rel].splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(HERE/'correction.patch').write_text(patch)
source_map={'decision':'SOURCE_ONLY_UNEXECUTED','paths':{rel:{'before':image(HERE/'before'/rel),'after':image(HERE/'after'/rel)} for rel in paths},'checks':checks,'python_changes':'One tmp_path-derived host-absolute string; same fakeNativeAPIcount/return/env assertion. All six build-stage assertions/CLIargs and inherited-env refusal retained; no production builder change.','rust_changes':'One test-only local_app_origin helper mirrors pinnedTauri2.12.4 official test example, six literal callsite adapters. All4 test bodies/assertions/commands/capabilities/CSP/ACL and remote/secondary denials preserved. No production changes.','framework_primary_bindings':evidence,'official_crate_archive':{'original_path':str(archive),**image(archive),'matched_Cargo_lock_checksum':True,'archive_not_duplicated':True},'lock_tauri_entry':match[0],'lock_file_image':image(ROOT/'apps/desktop/src-tauri/Cargo.lock'),'framework_web_lookup':'docs.rs/tauri/2.12.4/tauri/struct.WebviewUrl.html unavailable via web tool; actual pinned official crate archive matched to Cargo.lock and named primarysource members compared byteexact instead.','actual_failure_reference':'/tmp/japp-m03-w06-hosted-ci-660f9f1-20261019/closed-windows-observations.json','scope':'No tests/imports/compiler/native/GUI/store/helper/CI/root writes. Actual crossplatform fixes pending different review and execution; original Windows failures immutable.'}
(HERE/'SOURCE_BINDING.json').write_text(json.dumps(source_map,indent=2,sort_keys=True)+'\n')
(HERE/'HANDOFF.md').write_text('Two independent TEST-ONLY adapters for the actual660f Windows failures; SOURCE ONLY/no execution. Python mocked systemdirectory now derives an absolute path from pytest tmp_path, preserving the fake nativeAPI/count and same strict trusted-SystemRoot assertion plus every buildstage/oracle/CLIarg. Rust six test request sites use one local_app_origin helper matching pinnedTauri2.12.4 official test docs: Windows/Android HTTP tauri.localhost, otherhosts tauri://localhost. Production ACL/CSP/config/commands untouched, all four Rust tests and all assertions/negative remote/secondary cases remain. Both full preimages reverseexact; no existing testbody assertions removed.\n\nSOURCE_BINDING joins actual focused1983 preimages, Cargo.lock version/checksum and the exact329333B official cached .crate archive hash; three named source members compare byteexact and bounded primarysource excerpts are retained. No sourcecache walk or fullcrate copy. Browser docs lookup unavailable; local exact pinned official crate is the primary source. Initial missing .cargo-checksum.json source-preparation refusal retained, not subject/test failure. OriginalCI failure/rootfull/experimentalnative proofs stay distinct. Different source review and actual validation remain necessary; this packet grants no Windows success/GUI/milestone credit.\n')
entries=[]
for p in sorted(HERE.rglob('*')):
 if p.is_file():entries.append({'path':str(p.relative_to(HERE)),**image(p)})
(HERE/'retention-manifest.json').write_text(json.dumps({'decision':'SEALED_SOURCE_ONLY_UNEXECUTED','files':entries},indent=2,sort_keys=True)+'\n')
print(json.dumps({'checks':len(checks),'manifest':image(HERE/'retention-manifest.json'),'patch':image(HERE/'correction.patch'),'after':{rel:image(HERE/'after'/rel) for rel in paths}},indent=2))
