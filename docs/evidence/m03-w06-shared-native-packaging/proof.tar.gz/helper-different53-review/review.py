"""Source/AST/closed-static-receipt audit only; never imports subject."""
import ast,copy,difflib,hashlib,json,re,stat
from pathlib import Path
HERE=Path(__file__).resolve().parent
SUB=Path('/tmp/japp-m03-w06-native-package-static-quality-20261019/work/scripts/_native_package_process.py')
AUTHOR=Path('/tmp/japp-m03-w06-native-helper-typing-composition-20261019')
WIN=Path('/tmp/japp-m03-w06-windows-job-typing-20261019')
sha=lambda b:hashlib.sha256(b).hexdigest()
def pin(p):return {'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
def read(p):return json.loads(p.read_text())
checks=[]
def check(label,value):checks.append({'id':label,'passed':bool(value)});assert value,label
old=(AUTHOR/'before.py.txt').read_text();new=SUB.read_text();ot=ast.parse(old);nt=ast.parse(new)
check('subject737124',sha(new.encode())=='7371248344a87e537cb66cd8ef4650fb521440088be1bd75573dcf3ee5960b1d')
check('preimage-ee3ae0',sha(old.encode())=='ee3ae0f7c945abe27fff7f6b2325f14ae4acfeff1bb80364d53675816a5d30f8')
check('retained-after-exact',SUB.read_bytes()==(AUTHOR/'helper-after.py.txt').read_bytes())
check('whole-diff-exhaustive',(AUTHOR/'whole-source.diff').read_text()==''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='formatted-original-ee3ae0',tofile='typed-helper-737124')))
manifest=read(AUTHOR/'retention-manifest.json')
check('finite26-author-bodies-exact',len(manifest['files'])==26 and all(pin(AUTHOR/name)==meta for name,meta in manifest['files'].items()))

# Only this inspected AST-mutator class is evaluated; never its module, imports,
# file writes, subjects or any candidate native function. Rules were manually
# checked against the whole diff, with JSON validation explicitly exceptional.
mapper=ast.parse((AUTHOR/'semantic-map.py').read_text());normclass=next(n for n in mapper.body if isinstance(n,ast.ClassDef) and n.name=='Normalize')
scope={'ast':ast};exec(compile(ast.Module(body=[normclass],type_ignores=[]),'<inspected-ast-normalizer-only>','exec'),scope)
Normalize=scope['Normalize']
norm=lambda n:ast.dump(Normalize().visit(copy.deepcopy(n)),include_attributes=False)
orig={n.name:n for n in ot.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};cur={n.name:n for n in nt.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
functions=['_write','_sha','budget','_validate_budget','_Capture','_proc','_session_members','_pidfd','_signal_session','_settle_session','_linux_worker','run']
for name in functions:check('documented-normalization-'+name,norm(orig[name])==norm(cur[name]))
ft=ast.parse((WIN/'windows_job_fragment.py').read_text());fragment=next(n for n in ft.body if isinstance(n,ast.ClassDef) and n.name=='_WindowsJob')
check('whole-winclass-checked-fragment',norm(fragment)==norm(cur['_WindowsJob']))

seal=ast.parse((WIN/'seal.py').read_text());wanted={'Names','native_calls','methods','fields_value','layouts','signature_table'}
nodes=[n for n in seal.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in wanted]
scope2={'ast':ast};exec(compile(ast.Module(body=nodes,type_ignores=[]),'<inspected-source-data-grammar-only>','exec'),scope2)
before_win=scope2['Names']().visit(copy.deepcopy(orig['_WindowsJob']));after_win=cur['_WindowsJob']
native=scope2['native_calls'];layouts=scope2['layouts'];signature=scope2['signature_table']
check('23-native-call-asts-exact',native(before_win)==native(after_win) and len(native(after_win))==23)
check('seven-ctypes-layouts-exact',layouts(before_win)==layouts(after_win) and len(layouts(after_win))==7)
check('sixteen-ffi-signatures-exact',signature(before_win)==signature(after_win) and len(ast.literal_eval('[]'))==0 and len(next(n.value.keys for n in ast.walk(after_win) if isinstance(n,ast.AnnAssign) and isinstance(n.target,ast.Name) and n.target.id=='signatures'))==16)
check('windows-method-inventory-exact',scope2['methods'](before_win)==scope2['methods'](after_win))
init=ast.get_source_segment(new,next(n for n in after_win.body if isinstance(n,ast.FunctionDef) and n.name=='__init__'))
run=ast.unparse(cur['run']);pidfd=ast.unparse(cur['_pidfd']);signaler=ast.unparse(cur['_signal_session'])
check('suspended-handle-assign-resume-order',init.index('self.k.CreateProcessW(')<init.index('self.process, self.thread = created.process, created.thread')<init.index('self.k.AssignProcessToJobObject(')<init.index('self.k.ResumeThread(self.thread) != 1')<init.index('self.k.CloseHandle(self.thread)'))
check('retain-owner-before-fixed-initializer',run.index('windows = object.__new__(_WindowsJob)')<run.index('_WindowsJob.__init__(windows, command, cwd, dict(env), capture.writers)'))
check('partial-init-cleanup-preserved','self.k.TerminateProcess(self.process, 125)' in init and 'self.k.WaitForSingleObject(self.process, 3000)' in init and 'self.k.TerminateJobObject(self.job, 125)' in init and 'finally:' in init and 'self.k.CloseHandle(handle)' in init)
check('pidfd-exact-identity-no-pid-signal-fallback','pidfd_open' in pidfd and "_proc(row['pid']) != row" in pidfd and 'pidfd_send_signal' in signaler and not re.search(r'\b(?:os|signal)\.(?:kill|killpg)\(',new))
check('prepidfd-owner-quarantine-preserved','_PENDING_LINUX_OWNERS.append((child, keeper_fd, keeper))' in run and "cleanup['launched_owner_retained'] = True" in run and 'keeper_fd is not None' in run and '_PENDING_WINDOWS_OWNERS.append(windows)' in run)
check('no-Any-ignore-or-blanket-lint','Any' not in new and 'type: ignore' not in new and '# ruff: noqa' not in new and '# mypy:' not in new)
check('unchanged-bounded-policy-literals',all(re.search(rf'^{name}\s*=\s*{value}\s*$',new,re.M) for name,value in [('WORK_SECONDS','2700'),('CLEANUP_SECONDS','60'),('COMMAND_CLEANUP_SECONDS','15'),('MAX_SESSION_MEMBERS','512'),('MAX_PROC_STAT_BYTES','16384'),('MAX_PROC_NAMES','65536')]) and 'MAX_CAPTURE = 64 * 1024 * 1024' in new)
check('same-argv-no-shell-with-local-rationale','shell=False' in new and '# noqa: S603 -- validated exact argv, no shell' in new and '# noqa: S603 -- pinned helper argv' in new)
for name in ['_json_object','_json_int','_json_number','_json_text','_json_bool','_json_array','_text_array','_error_record','_process_identity','_signal_receipt','_containment','_session_control','_session_result']:
 check('closed-shape-validator-present-'+name,name in cur)
check('booleans-refused-as-integers',"type(value) is not int" in ast.unparse(cur['_json_int']) and "type(value) not in (int, float)" in ast.unparse(cur['_json_number']))
check('nonfinite-json-number-refused','math.isfinite(number)' in ast.unparse(cur['_json_number']))
check('closed-control-required-keyset','set(row) !=' in ast.unparse(cur['_session_control']) and 'environment.items()' in ast.unparse(cur['_session_control']))
check('closed-result-optional-nested-validation','set(row) - required - optional' in ast.unparse(cur['_session_result']) and "_containment(row['cleanup'])" in ast.unparse(cur['_session_result']) and "_process_identity(row['keeper'])" in ast.unparse(cur['_session_result']))
check('explicit-utf8-json-read',"read_text(encoding='utf-8')" in ast.unparse(cur['_load_json']))
check('only-two-validated-json-consumers',new.count('_session_control(_load_json(')==1 and '_session_result(\n                    _load_json(' in new)
for label in ('mypy-final','ruff-final','format-final'):
 up=read(AUTHOR/(label+'.upfront.json'));result=read(AUTHOR/(label+'.result.json'))
 check('closed-static-receipt-'+label,result['exit_code']==0 and up['source_sha256']==manifest['source_sha256']==result['source_sha256_after'] and up['scope']=='STATIC_SOURCE_ONLY_NO_SUBJECT_IMPORT')
check('source-stable-at-review-end',pin(SUB)['sha256']=='7371248344a87e537cb66cd8ef4650fb521440088be1bd75573dcf3ee5960b1d')
report={'decision':'CLEAR_BOUNDED_SOURCE_ONLY','checks':checks,'scope':'Exact737124 typed shared helper over ee3ae0. Inspected custody/controlflow and recomputed declared AST correspondences; closed JSON validation is explicitly new failclosed behavior, not malformed-input semantic equivalence. Static receipts observed only; no subject/native imports, tests, Win32/Linux actors, compiler, toolimage/cache walk or root mutation by reviewer. Actual old23+7 mocks and platform ABI/containment remain separate future verification.','known_limits':'Linux escaped sessions and Windows outside-Job descendants UNOBSERVED; selected bounded /proc observation does not become complete descendant authority. No native package, GUI, OSstore, provider or milestone acceptance.'}
(HERE/'findings.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
(HERE/'REVIEW.md').write_text(f"CLEAR {len(checks)}/{len(checks)} bounded SOURCE checks for737124. All12 old non-Windows bodies match under inspected declared syntax/type normalization (the two JSON reads are explicitly new failclosed validation); Windows class matches checked fragment, with23 native-call ASTs,7 layouts and16 signatures preserved.\n\nHeld Windows owner/hProcess/hThread, suspended Assign-before-Resume, partial-init/finally handling, Linux exact pidfd authority, pre-pidfd quarantine, bounds, argv/no-shell and strict success predicates remain source-consistent. New JSON checks close shape/type/nesting/finite-number trust before typed casts; bool integers refused. No Any/type-ignore/global guard weakening. Closed mypy/Ruff/format receipts bind exact source; they do not confer actual platform execution.\n\nNo imports, tests, actors, compiler, OS/native calls, root edits or cache/image walks by this reviewer. Actual old23+7 mocks and native ABI/platform verification remain separate; no package/GUI/store/provider/milestone acceptance.\n")
for p,label in [(SUB,'subject-after.py'),(AUTHOR/'before.py.txt','before.py.txt'),(AUTHOR/'whole-source.diff','whole-source.diff'),(AUTHOR/'HANDOFF.md','author-HANDOFF.md'),(AUTHOR/'retention-manifest.json','author-retention-manifest.json'),(AUTHOR/'semantic-map.json','author-semantic-map.json'),(AUTHOR/'actual-static-times.json','actual-static-times.json')]:
 (HERE/label).write_bytes(p.read_bytes())
manifest_out={'files':{p.name:pin(p) for p in sorted(HERE.iterdir()) if p.is_file()},'scope':report['scope']}
(HERE/'retention-manifest.json').write_text(json.dumps(manifest_out,indent=2,sort_keys=True)+'\n')
print(json.dumps({'checks':len(checks),'review':pin(HERE/'REVIEW.md'),'findings':pin(HERE/'findings.json'),'manifest':pin(HERE/'retention-manifest.json')},indent=2))
