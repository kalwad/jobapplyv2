import { defineConfig } from '@playwright/test';
import base from '/Users/tanishkalwad/.codex/worktrees/w14-independent-review/jobapplyv2/playwright.config.ts';
const root='/Users/tanishkalwad/.codex/worktrees/w14-independent-review/jobapplyv2';
export default defineConfig({...base,testDir:'/tmp/japp-w14-independent-probes',testMatch:'independent-aria.spec.ts',globalSetup:`${root}/e2e/extension/support/global-setup.ts`,outputDir:'/tmp/japp-w14-independent-probes/aria-artifacts',reporter:[['list'],['json',{outputFile:'/tmp/japp-w14-independent-probes/aria-results.json'}]],webServer:{...base.webServer,cwd:root}});
