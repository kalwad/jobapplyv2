# Bounded ARIA selected-option reproduction

This one additional actual-MV3 probe was explicitly authorized by the parent after the seven-case candidate replay and four adjacent failures. It runs against the exact `c9057bd83e3daf970e03b197b2c5f606df48398ea6395bf61cab7c3dc1ab7e5e` candidate; the worktree still differs from the frozen 853-file snapshot only in its three authorized runtime files.

The assumption that supported ARIA widgets derive option identity from their labels is false. `apps/extension/src/drivers/widget-drivers.ts:44-50` prioritizes untrusted `data-value` and `value` over normalized visible text. `:99-122` authorizes the option activation from that raw value, and `:565-578` observes the committed prompt option from the same raw value. Static native-select/radio-only semantic binding therefore does not cover this supported driver path.

Actual W09 approves WORK_MODE_PREFERENCE/REMOTE for a mounted prompt option with `data-value=17`, label Remote. Before executing the held approval, the fixture changes only that option's label to Onsite. Fresh W09 returns PAUSE_FOR_CONFIRMATION/NO_SEMANTIC_MATCH; the held transaction still opens the prompt and commits the option, physically selecting value17/Onsite, with outcome VERIFIED and readiness READY. Native witnesses record exactly two ACTIVATIONs, for mode and remote. These are synthetic loopback data and the actual research Workday-prompt driver; no production source hook was added.

Proof: immutable `independent-aria.spec.ts` / `playwright-aria.config.ts`; raw `native-aria-before-write.json`; command log `aria-before.log`; result JSON `aria-results.json`; failure trace under `aria-artifacts/`. One completed assertion failure, no setup errors. Existing VIRT and unrelated-option positive tests were not edited; final correction must retain their actual regression proof.

All 12 external scenarios now have typed repository-ready draft equivalents under `/tmp/japp-w14-independent-typed-tests` with exact-hash manifest, strict pinned-Node24 TypeScript, typed ESLint, Prettier and fixture/assertion inventory checks. The typed copies have not yet run in the browser. Original external probes remain immutable.

Browser/server/port4761 are released. No further exploratory tests are queued. This remains preliminary W14 defect evidence, not final W15 or Gate PASS.
