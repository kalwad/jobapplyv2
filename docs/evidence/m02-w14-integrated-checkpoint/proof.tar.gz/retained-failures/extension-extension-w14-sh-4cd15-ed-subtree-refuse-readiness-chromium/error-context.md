# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w14-shadow.spec.ts >> W14 open shadow: duplicate identities introduced together in one observed subtree refuse readiness
- Location: e2e/extension/extension-w14-shadow.spec.ts:801:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "ROOT_AMBIGUOUS"
Received: "RECONCILED"
```

# Test source

```ts
  726 |             ),
  727 |         );
  728 |     });
  729 |     const result = requireValue(
  730 |       (await dynExecute(harness, [transaction])).items[0],
  731 |       "missing duplicate error result",
  732 |     );
  733 |     expect(result.status).toBe("EXECUTED");
  734 |     if (result.status === "EXECUTED") {
  735 |       expect(result.result.outcome).not.toBe("VERIFIED");
  736 |       expect(result.result.site_acceptance).toBe("UNKNOWN");
  737 |     }
  738 |     expect(await harness.page.locator("#given").inputValue()).toBe("");
  739 |     expect(
  740 |       reconciled(await dynReconcile(harness, top.frame_context.frame_id))
  741 |         .inventory.readiness,
  742 |     ).toBe("NOT_READY");
  743 |   } finally {
  744 |     await harness.page.close();
  745 |     await harness.controller.close();
  746 |   }
  747 | });
  748 | 
  749 | test("W14 open shadow: duplicate local label IDs do not gain applicant authority", async ({
  750 |   extensionContext,
  751 |   extensionId,
  752 |   serviceWorker,
  753 | }) => {
  754 |   const harness = await openHarness(
  755 |     extensionContext,
  756 |     extensionId,
  757 |     serviceWorker,
  758 |     "/native/",
  759 |   );
  760 |   try {
  761 |     await createShadow(
  762 |       harness,
  763 |       '<span id="label">First name</span><span id="label">Employer first name</span><input id="ambiguous-label" name="first_name" aria-labelledby="label" required>',
  764 |     );
  765 |     const top = foundTopFrame(await scanFrames(harness));
  766 |     expect(top.descriptors).toHaveLength(1);
  767 |     const field = requireValue(
  768 |       top.descriptors[0],
  769 |       "missing ambiguous-label field",
  770 |     );
  771 |     expect(field.label.normalized_text).toBeUndefined();
  772 |     const decision = await resolveFieldDecision({
  773 |       descriptor: field,
  774 |       records: buildApprovedRecordSet([
  775 |         {
  776 |           recordId: await stableSemanticId("record", "shadow-label"),
  777 |           concept: "FIRST_NAME",
  778 |           policy: "FILL_FROM_EXPLICIT_RECORD",
  779 |           confirmation: { state: "MISSING" },
  780 |           valueConfidence: 1,
  781 |         },
  782 |       ]),
  783 |       correlationId: await stableSemanticId("cor", "shadow-label"),
  784 |     });
  785 |     expect(decision.status).toBe("RESOLVED");
  786 |     if (decision.status === "RESOLVED")
  787 |       expect(decision.resolution.decision.final_decision).not.toBe("FILL");
  788 |     expect(
  789 |       reconciled(await dynReconcile(harness, top.frame_context.frame_id))
  790 |         .inventory.counts.required_unresolved,
  791 |     ).toBe(1);
  792 |     expect(await harness.page.locator("#ambiguous-label").inputValue()).toBe(
  793 |       "",
  794 |     );
  795 |   } finally {
  796 |     await harness.page.close();
  797 |     await harness.controller.close();
  798 |   }
  799 | });
  800 | 
  801 | test("W14 open shadow: duplicate identities introduced together in one observed subtree refuse readiness", async ({
  802 |   extensionContext,
  803 |   extensionId,
  804 |   serviceWorker,
  805 | }) => {
  806 |   const harness = await openHarness(
  807 |     extensionContext,
  808 |     extensionId,
  809 |     serviceWorker,
  810 |     "/native/",
  811 |   );
  812 |   try {
  813 |     await createShadow(harness, OWN);
  814 |     const top = foundTopFrame(await scanFrames(harness));
  815 |     expect((await dynStart(harness, top.frame_context.frame_id)).status).toBe(
  816 |       "STARTED",
  817 |     );
  818 |     await dynReconcile(harness, top.frame_context.frame_id);
  819 |     await harness.page.evaluate(() => {
  820 |       const root = document.getElementById("host-0")?.shadowRoot;
  821 |       if (!root) throw new Error("root absent");
  822 |       root.innerHTML =
  823 |         '<input aria-label="First name" name="given" required><input aria-label="First name" name="given" required>';
  824 |     });
  825 |     const result = await dynReconcile(harness, top.frame_context.frame_id);
> 826 |     expect(result.status).toBe("ROOT_AMBIGUOUS");
      |                           ^ Error: expect(received).toBe(expected) // Object.is equality
  827 |     if (result.status === "ROOT_AMBIGUOUS")
  828 |       expect(result.candidate_count).toBe(2);
  829 |   } finally {
  830 |     await harness.page.close();
  831 |     await harness.controller.close();
  832 |   }
  833 | });
  834 | 
  835 | for (const local of ["DOCUMENT", "SHADOW"] as const) {
  836 |   for (const ownership of ["DESCRIPTION", "SECTION"] as const) {
  837 |     test(`W14 ${local} ambiguous ${ownership} ownership never fills applicant fact`, async ({
  838 |       extensionContext,
  839 |       extensionId,
  840 |       serviceWorker,
  841 |     }) => {
  842 |       const harness = await openHarness(
  843 |         extensionContext,
  844 |         extensionId,
  845 |         serviceWorker,
  846 |         "/native/",
  847 |       );
  848 |       try {
  849 |         const duplicates =
  850 |           '<span id="owner">Own contact</span><span id="owner">Employer contact</span>';
  851 |         const markup =
  852 |           ownership === "DESCRIPTION"
  853 |             ? duplicates +
  854 |               '<label for="ambiguous">First name</label><input id="ambiguous" name="given" aria-describedby="owner" required>'
  855 |             : '<section aria-labelledby="owner">' +
  856 |               duplicates +
  857 |               '<label for="ambiguous">First name</label><input id="ambiguous" name="given" required></section>';
  858 |         if (local === "SHADOW") await createShadow(harness, markup);
  859 |         else
  860 |           await setFixture(
  861 |             harness,
  862 |             '<main data-japp-application-root aria-label="Application">' +
  863 |               markup +
  864 |               "</main>",
  865 |           );
  866 |         const top = foundTopFrame(await scanFrames(harness));
  867 |         expect(top.descriptors).toHaveLength(1);
  868 |         const field = requireValue(
  869 |           top.descriptors[0],
  870 |           "ambiguous ownership missing",
  871 |         );
  872 |         const decision = await resolveFieldDecision({
  873 |           descriptor: field,
  874 |           records: buildApprovedRecordSet([
  875 |             {
  876 |               recordId: await stableSemanticId("record", "ambiguous-ownership"),
  877 |               concept: "FIRST_NAME",
  878 |               policy: "FILL_FROM_EXPLICIT_RECORD",
  879 |               confirmation: { state: "MISSING" },
  880 |               valueConfidence: 1,
  881 |             },
  882 |           ]),
  883 |           correlationId: await stableSemanticId("cor", `${local}-${ownership}`),
  884 |         });
  885 |         expect(decision.status).toBe("RESOLVED");
  886 |         if (decision.status === "RESOLVED")
  887 |           expect(decision.resolution.decision.final_decision).not.toBe("FILL");
  888 |         expect(await harness.page.locator("#ambiguous").inputValue()).toBe("");
  889 |         expect(
  890 |           reconciled(await dynReconcile(harness, top.frame_context.frame_id))
  891 |             .inventory.counts.required_unresolved,
  892 |         ).toBe(1);
  893 |       } finally {
  894 |         await harness.page.close();
  895 |         await harness.controller.close();
  896 |       }
  897 |     });
  898 |   }
  899 | }
  900 | 
  901 | test("W14 cached outside host: silently attached competing application refuses previous field authority", async ({
  902 |   extensionContext,
  903 |   extensionId,
  904 |   serviceWorker,
  905 | }) => {
  906 |   const harness = await openHarness(
  907 |     extensionContext,
  908 |     extensionId,
  909 |     serviceWorker,
  910 |     "/native/",
  911 |   );
  912 |   try {
  913 |     await createShadow(harness, OWN);
  914 |     await harness.page.evaluate(() => {
  915 |       const host = document.createElement("aside");
  916 |       host.id = "outside-host";
  917 |       document.body.append(host);
  918 |     });
  919 |     const top = foundTopFrame(await scanFrames(harness));
  920 |     const transaction = await ownFirstNameTransaction(
  921 |       descriptorByLabel(top.descriptors, "First name"),
  922 |       "outside-root",
  923 |     );
  924 |     await dynReconcile(harness, top.frame_context.frame_id);
  925 |     await harness.page.evaluate(() => {
  926 |       document
```