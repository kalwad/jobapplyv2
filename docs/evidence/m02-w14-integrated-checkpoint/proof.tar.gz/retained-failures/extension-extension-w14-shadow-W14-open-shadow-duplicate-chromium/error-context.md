# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-w14-shadow.spec.ts >> W14 open shadow: duplicate
- Location: e2e/extension/extension-w14-shadow.spec.ts:219:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "ROOT_AMBIGUOUS"
Received: "RECONCILED"
```

# Test source

```ts
  335 |                       true,
  336 |                     ) as HTMLInputElement;
  337 |                     replacement.value = value;
  338 |                     node.replaceWith(replacement);
  339 |                   }
  340 |                   meter.rerenders++;
  341 |                 }, 20);
  342 |             },
  343 |             true,
  344 |           );
  345 |           if (scenario === "hidden-host")
  346 |             document
  347 |               .getElementById("host-0")
  348 |               ?.setAttribute("aria-hidden", "true");
  349 |           if (scenario === "transparent-host") {
  350 |             const host = document.getElementById("host-0");
  351 |             if (host) host.style.opacity = "0";
  352 |           }
  353 |           if (scenario === "disabled-host") {
  354 |             const host = document.getElementById("host-0");
  355 |             if (host) {
  356 |               const fieldset = document.createElement("fieldset");
  357 |               fieldset.disabled = true;
  358 |               host.replaceWith(fieldset);
  359 |               fieldset.append(host);
  360 |             }
  361 |           }
  362 |           if (scenario === "local-error") {
  363 |             const error = root.getElementById("error");
  364 |             if (error) error.textContent = "Site rejects this value";
  365 |           }
  366 |         },
  367 |         { scenario },
  368 |       );
  369 |       if (scenario === "local-error") {
  370 |         const current = descriptorByLabel(
  371 |           foundTopFrame(await scanFrames(harness)).descriptors,
  372 |           "First name",
  373 |         );
  374 |         transaction = await ownFirstNameTransaction(
  375 |           current,
  376 |           "shadow-local-error-current-description",
  377 |         );
  378 |       }
  379 |       const result = requireValue(
  380 |         (await dynExecute(harness, [transaction])).items[0],
  381 |         "missing result",
  382 |       );
  383 |       expect(result.status).toBe("EXECUTED");
  384 |       if (result.status !== "EXECUTED")
  385 |         throw new Error("missing driver result");
  386 |       const meter = await harness.page.evaluate(
  387 |         () =>
  388 |           (
  389 |             window as unknown as {
  390 |               shadowMeter: { inputs: number; rerenders: number };
  391 |             }
  392 |           ).shadowMeter,
  393 |       );
  394 |       if (
  395 |         scenario === "duplicate" ||
  396 |         scenario === "late-duplicate" ||
  397 |         scenario === "hidden-host" ||
  398 |         scenario === "transparent-host" ||
  399 |         scenario === "disabled-host" ||
  400 |         scenario === "focus-duplicate"
  401 |       ) {
  402 |         expect(meter.inputs).toBe(0);
  403 |         expect(result.result.outcome).not.toBe("VERIFIED");
  404 |         if (scenario === "duplicate" || scenario === "late-duplicate")
  405 |           expect(result.result.resolution_result).toBe("AMBIGUOUS");
  406 |       } else {
  407 |         expect(meter.inputs).toBe(1);
  408 |         expect(result.result.action_attempt.duration_ms).toBeGreaterThanOrEqual(
  409 |           75,
  410 |         );
  411 |         if (
  412 |           scenario === "removed" ||
  413 |           scenario === "removed-host" ||
  414 |           scenario === "local-error" ||
  415 |           scenario === "during-action-duplicate"
  416 |         )
  417 |           expect(result.result.outcome).not.toBe("VERIFIED");
  418 |         else {
  419 |           expect(result.result.outcome).toBe("VERIFIED");
  420 |           expect(result.result.persistence_verified).toBe(true);
  421 |           expect(result.result.site_acceptance).toBe("ACCEPTED");
  422 |           expect(await harness.page.locator("#given").inputValue()).toBe(
  423 |             "Synthetic",
  424 |           );
  425 |         }
  426 |       }
  427 |       if (
  428 |         scenario === "duplicate" ||
  429 |         scenario === "late-duplicate" ||
  430 |         scenario === "focus-duplicate" ||
  431 |         scenario === "during-action-duplicate"
  432 |       ) {
  433 |         expect(
  434 |           (await dynReconcile(harness, top.frame_context.frame_id)).status,
> 435 |         ).toBe("ROOT_AMBIGUOUS");
      |           ^ Error: expect(received).toBe(expected) // Object.is equality
  436 |       }
  437 |       if (
  438 |         scenario === "rerender" ||
  439 |         scenario === "removed" ||
  440 |         scenario === "removed-host"
  441 |       )
  442 |         expect(meter.rerenders).toBe(1);
  443 |     } finally {
  444 |       await harness.page.close();
  445 |       await harness.controller.close();
  446 |     }
  447 |   });
  448 | }
  449 | 
  450 | test("W14 open shadow: late attached unknown required control joins active reconciliation", async ({
  451 |   extensionContext,
  452 |   extensionId,
  453 |   serviceWorker,
  454 | }) => {
  455 |   const harness = await openHarness(
  456 |     extensionContext,
  457 |     extensionId,
  458 |     serviceWorker,
  459 |     "/native/",
  460 |   );
  461 |   try {
  462 |     await createShadow(harness, OWN);
  463 |     await harness.page.evaluate(() => {
  464 |       const host = document.createElement("div");
  465 |       host.id = "late-host";
  466 |       document.querySelector("main")?.append(host);
  467 |     });
  468 |     const top = foundTopFrame(await scanFrames(harness));
  469 |     expect((await dynStart(harness, top.frame_context.frame_id)).status).toBe(
  470 |       "STARTED",
  471 |     );
  472 |     await dynReconcile(harness, top.frame_context.frame_id);
  473 |     await harness.page.evaluate(() => {
  474 |       const host = document.getElementById("late-host");
  475 |       if (!host) throw new Error("host absent");
  476 |       host.attachShadow({ mode: "open" }).innerHTML =
  477 |         '<label for="unknown">Emergency contact name (required)</label><input id="unknown" required>';
  478 |     });
  479 |     const inventory = reconciled(
  480 |       await dynReconcile(harness, top.frame_context.frame_id),
  481 |     ).inventory;
  482 |     expect(inventory.items.filter((item) => item.required)).toHaveLength(2);
  483 |     expect(inventory.counts.required_unresolved).toBe(2);
  484 |     expect(inventory.readiness).toBe("NOT_READY");
  485 |     expect(await harness.page.locator("#unknown").inputValue()).toBe("");
  486 |   } finally {
  487 |     await harness.page.close();
  488 |     await harness.controller.close();
  489 |   }
  490 | });
  491 | 
  492 | test("W14 open shadow: root capacity refuses complete-inventory claims", async ({
  493 |   extensionContext,
  494 |   extensionId,
  495 |   serviceWorker,
  496 | }) => {
  497 |   const harness = await openHarness(
  498 |     extensionContext,
  499 |     extensionId,
  500 |     serviceWorker,
  501 |     "/native/",
  502 |   );
  503 |   try {
  504 |     await createShadow(harness, OWN, 65);
  505 |     const top = (await scanFrames(harness)).find(
  506 |       (frame) => frame.frame_context.is_top_frame,
  507 |     );
  508 |     expect(top?.root_status).toBe("CAPACITY_EXCEEDED");
  509 |     expect(top?.descriptors).toEqual([]);
  510 |   } finally {
  511 |     await harness.page.close();
  512 |     await harness.controller.close();
  513 |   }
  514 | });
  515 | 
  516 | for (const owner of ["Employer", "Recruiter"] as const) {
  517 |   test(`W14 open shadow: host ${owner} context prevents applicant fill`, async ({
  518 |     extensionContext,
  519 |     extensionId,
  520 |     serviceWorker,
  521 |   }) => {
  522 |     const harness = await openHarness(
  523 |       extensionContext,
  524 |       extensionId,
  525 |       serviceWorker,
  526 |       "/native/",
  527 |     );
  528 |     try {
  529 |       await createShadow(harness, OWN);
  530 |       await harness.page.evaluate((owner) => {
  531 |         const host = document.getElementById("host-0");
  532 |         if (!host) throw new Error("host absent");
  533 |         const section = document.createElement("section");
  534 |         section.setAttribute("aria-label", owner);
  535 |         host.replaceWith(section);
```