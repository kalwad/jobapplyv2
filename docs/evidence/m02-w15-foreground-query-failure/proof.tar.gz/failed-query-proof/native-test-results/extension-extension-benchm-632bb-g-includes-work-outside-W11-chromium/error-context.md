# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: extension/extension-benchmark.spec.ts >> W13 L: total scan and re-resolution scaling includes work outside W11
- Location: e2e/extension/extension-benchmark.spec.ts:61:1

# Error details

```
Error: cdpSession.send: Protocol error (Browser.getBrowserCommandLine): Command line not returned because --enable-automation not set.
```

# Test source

```ts
  46  |     descriptorByLabel(top.descriptors, "First name"),
  47  |     "w13-concurrent",
  48  |     { kind: "TEXT", text: "Synthetic W13" },
  49  |   );
  50  |   const outcomes = await Promise.all([
  51  |     dynExecute(harness, [transaction]),
  52  |     dynExecute(harness, [{ ...transaction }]),
  53  |   ]);
  54  |   expect(outcomes).toHaveLength(2);
  55  |   expect(
  56  |     await harness.page.locator("html").getAttribute("data-physical-fills"),
  57  |   ).toBe("1");
  58  |   await expect(harness.page.locator("#first")).toHaveValue("Synthetic W13");
  59  | });
  60  | 
  61  | test("W13 L: total scan and re-resolution scaling includes work outside W11", async ({
  62  |   extensionContext,
  63  |   extensionId,
  64  |   serviceWorker,
  65  | }, testInfo) => {
  66  |   test.setTimeout(120_000);
  67  |   const rows = [];
  68  |   const profileLabels = ["PROFILE_DIAGNOSTIC_NOT_ACCEPTANCE"];
  69  |   let browserCommandLineRecorded = false;
  70  |   const foregroundState = async (
  71  |     harness: Awaited<ReturnType<typeof openHarness>>,
  72  |   ) => ({
  73  |     target: await harness.page.evaluate(() => ({
  74  |       visibility_state: document.visibilityState,
  75  |       hidden: document.hidden,
  76  |       has_focus: document.hasFocus(),
  77  |     })),
  78  |     controller: await harness.controller.evaluate(() => ({
  79  |       visibility_state: document.visibilityState,
  80  |       hidden: document.hidden,
  81  |       has_focus: document.hasFocus(),
  82  |     })),
  83  |     active_tab_ids: await serviceWorker.evaluate(async () => {
  84  |       const runtime = globalThis as unknown as {
  85  |         chrome: {
  86  |           tabs: {
  87  |             query(query: object): Promise<{ id?: number }[]>;
  88  |           };
  89  |         };
  90  |       };
  91  |       const tabs = await runtime.chrome.tabs.query({
  92  |         active: true,
  93  |         lastFocusedWindow: true,
  94  |       });
  95  |       return tabs.map((tab) => tab.id ?? null);
  96  |     }),
  97  |   });
  98  |   const sampleCount = Number(process.env.JAPP_W13_PERFORMANCE_SAMPLES ?? "1");
  99  |   expect([1, 20]).toContain(sampleCount);
  100 |   for (const count of [
  101 |     8,
  102 |     32,
  103 |     ...Array.from({ length: sampleCount }, () => 128),
  104 |   ]) {
  105 |     const harness = await openHarness(
  106 |       extensionContext,
  107 |       extensionId,
  108 |       serviceWorker,
  109 |       "/native/",
  110 |     );
  111 |     await setFixture(
  112 |       harness,
  113 |       `<form data-japp-application-root="true">${Array.from(
  114 |         { length: count },
  115 |         (_, i) =>
  116 |           `<section aria-label="Section ${String(i)}"><label for="first${String(i)}">First name</label><input id="first${String(i)}" name="first${String(i)}" required></section>`,
  117 |       ).join("")}</form>`,
  118 |     );
  119 |     await harness.page.evaluate(() => {
  120 |       document.documentElement.dataset.physicalFills = "0";
  121 |       document.querySelector("form")?.addEventListener("input", () => {
  122 |         document.documentElement.dataset.physicalFills = String(
  123 |           Number(document.documentElement.dataset.physicalFills) + 1,
  124 |         );
  125 |       });
  126 |     });
  127 |     const cdp = await extensionContext.newCDPSession(harness.page);
  128 |     const browserVersion = await cdp.send("Browser.getVersion");
  129 |     await cdp.send("Performance.enable");
  130 |     const metrics = async () => {
  131 |       const response = await cdp.send("Performance.getMetrics");
  132 |       const metric = (name: string) => {
  133 |         const value = response.metrics.find(
  134 |           (item) => item.name === name,
  135 |         )?.value;
  136 |         if (value === undefined)
  137 |           throw new Error(`CDP metric unavailable: ${name}`);
  138 |         return value;
  139 |       };
  140 |       return {
  141 |         task_duration_s: metric("TaskDuration"),
  142 |         heap_used_bytes: metric("JSHeapUsedSize"),
  143 |       };
  144 |     };
  145 |     if (!browserCommandLineRecorded) {
> 146 |       const browserCommandLine = await cdp.send(
      |                                            ^ Error: cdpSession.send: Protocol error (Browser.getBrowserCommandLine): Command line not returned because --enable-automation not set.
  147 |         "Browser.getBrowserCommandLine",
  148 |       );
  149 |       console.log(
  150 |         `W13_PROFILE_BROWSER_COMMAND_LINE ${JSON.stringify({ labels: profileLabels, arguments: browserCommandLine.arguments, observation_scope: "ACTUAL_LAUNCH_ARGUMENTS_NOT_PROOF_FLAGS_HONORED" })}`,
  151 |       );
  152 |       browserCommandLineRecorded = true;
  153 |     }
  154 |     const originalForeground = await foregroundState(harness);
  155 |     const foregroundStarted = performance.now();
  156 |     await harness.page.bringToFront();
  157 |     const foregroundAcquisitionMs = performance.now() - foregroundStarted;
  158 |     const foregroundBefore = await foregroundState(harness);
  159 |     console.log(
  160 |       `W13_PROFILE_PREWORK ${JSON.stringify({ labels: profileLabels, iteration: rows.length + 1, control_count: count, target_tab_id: harness.tabId, original: originalForeground, foreground_before: foregroundBefore, foreground_acquisition_ms: foregroundAcquisitionMs })}`,
  161 |     );
  162 |     expect(foregroundBefore.target.visibility_state).toBe("visible");
  163 |     expect(foregroundBefore.target.hidden).toBe(false);
  164 |     const before = await metrics();
  165 |     const started = performance.now();
  166 |     const top = foundTopFrame(await scanFrames(harness));
  167 |     expect(top.descriptors).toHaveLength(count);
  168 |     const transactions = [];
  169 |     for (const [i, descriptor] of top.descriptors.entries()) {
  170 |       const transaction = await approvedTransaction(
  171 |         descriptor,
  172 |         `w13-scaling-${String(count)}-${String(i)}`,
  173 |         { kind: "TEXT", text: "Synthetic W13" },
  174 |       );
  175 |       // Minimum accepted settle budget isolates a LOWER BOUND on scanning
  176 |       // cost. Final fresh reconciliation still checks every persisted value.
  177 |       transactions.push({ ...transaction, settle: { budget_ms: 0 } });
  178 |     }
  179 |     for (let i = 0; i < transactions.length; i += 32) {
  180 |       const outcome = await dynExecute(harness, transactions.slice(i, i + 32));
  181 |       for (const item of outcome.items) {
  182 |         expect(item.status).toBe("EXECUTED");
  183 |         if (item.status === "EXECUTED") {
  184 |           expect(item.result.outcome).toBe("VERIFIED");
  185 |         }
  186 |       }
  187 |     }
  188 |     const outcome = reconciled(
  189 |       await dynReconcile(harness, top.frame_context.frame_id),
  190 |     );
  191 |     const elapsed = performance.now() - started;
  192 |     const after = await metrics();
  193 |     expect(outcome.inventory.counts.verified_filled).toBe(count);
  194 |     const work = outcome.snapshot.scanner_work;
  195 |     expect(work).toBeDefined();
  196 |     if (work === undefined) throw new Error("total scanner work missing");
  197 |     expect(work.reresolution_calls).toBeGreaterThanOrEqual(4 * count);
  198 |     // Complete identity capture is shared only while observer revision and
  199 |     // context remain current. Four live target resolutions still run/control.
  200 |     expect(work.index_rebuilds).toBe(1);
  201 |     expect(work.index_hits).toBeGreaterThanOrEqual(4 * count - 1);
  202 |     expect(work.identity_pairs_examined).toBe(count);
  203 |     expect(work.candidate_enumerations).toBeLessThanOrEqual(3);
  204 |     expect(work.candidates_examined).toBeLessThanOrEqual(3 * count);
  205 |     expect(work.descriptors_built).toBe(6 * count);
  206 |     const physicalActions = Number(
  207 |       await harness.page.locator("html").getAttribute("data-physical-fills"),
  208 |     );
  209 |     expect(physicalActions).toBe(count);
  210 |     expect(outcome.snapshot.actions_executed).toBe(count);
  211 |     rows.push({
  212 |       control_count: count,
  213 |       actions_attempted: outcome.snapshot.actions_executed,
  214 |       physical_actions_count: physicalActions,
  215 |       total_wall_clock_ms: elapsed,
  216 |       scanner_work: work,
  217 |       w11_scan_duration_ms: outcome.snapshot.total_scan_duration_ms,
  218 |       w11_root_scans: outcome.snapshot.root_rescans,
  219 |       w11_subtree_scans: outcome.snapshot.affected_subtree_scans,
  220 |       cpu_source: "CHROMIUM_CDP_PERFORMANCE_TASK_DURATION_MAIN_PAGE",
  221 |       task_duration_delta_s: after.task_duration_s - before.task_duration_s,
  222 |       heap_source: "CHROMIUM_CDP_PERFORMANCE_JS_HEAP_USED_SIZE_MAIN_PAGE",
  223 |       heap_before_bytes: before.heap_used_bytes,
  224 |       heap_after_bytes: after.heap_used_bytes,
  225 |       settle_budget_ms: 0,
  226 |       evidence_scope: "LOWER_BOUND_NO_ASYNC_RERENDER_DELAY",
  227 |       browser_product: browserVersion.product,
  228 |       browser_revision: browserVersion.revision,
  229 |     });
  230 |     console.log(
  231 |       `W13_PROFILE_COMPLETED_ROW ${JSON.stringify({ labels: profileLabels, iteration: rows.length, row: rows.at(-1), original: originalForeground, foreground_before: foregroundBefore, foreground_acquisition_ms: foregroundAcquisitionMs })}`,
  232 |     );
  233 |     const foregroundAfter = await foregroundState(harness);
  234 |     console.log(
  235 |       `W13_PROFILE_POSTWORK ${JSON.stringify({ labels: profileLabels, iteration: rows.length, target_tab_id: harness.tabId, foreground_after: foregroundAfter })}`,
  236 |     );
  237 |     expect(foregroundAfter.target.visibility_state).toBe("visible");
  238 |     expect(foregroundAfter.target.hidden).toBe(false);
  239 |     await cdp.detach();
  240 |     await harness.page.close();
  241 |     await harness.controller.close();
  242 |   }
  243 |   const samples = rows
  244 |     .filter((row) => row.control_count === 128)
  245 |     .map((row) => row.total_wall_clock_ms)
  246 |     .sort((a, b) => a - b);
```