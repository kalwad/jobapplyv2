from __future__ import annotations

import argparse
import collections
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
CLONE = BASE / "clone"
PROOF = BASE / "proof"
NODE = "/opt/homebrew/opt/node@24/bin/node"
PNPM = "/opt/homebrew/opt/node@24/bin/pnpm"
FREEZE = json.loads((BASE / "source-freeze.json").read_text())
HEAD = FREEZE["frozen_commit"]
TREE = FREEZE["frozen_tree"]
OVERLAY = "e2e/extension/extension-benchmark.spec.ts"
ORIGINAL_SHA = "e129f819b41b22e7b05447e3a7d86d43c2c5ab1860f62724a4fa857db18904da"
OVERLAY_SHA = "8d982d41dc30f59ac1acdfbbcdaaa6ad66442461702676a7beb9c1c6e8291543"
PATCH_SHA = "e08e3e3350ebbb6deb7b26d3a158c75f56e07f434687bd4d18194d2c95ede91b"
SCOPE = "PROFILE_DIAGNOSTIC_NOT_ACCEPTANCE"
RUNTIME = "sha256:4f5a9608eb23a80a15a81b4a79494901907c4ad7e5c6a996fbce455b498c77d5"
TITLE = "W13 L: total scan and re-resolution scaling includes work outside W11"
ENV = dict(os.environ)
ENV["PATH"] = "/opt/homebrew/opt/node@24/bin:" + ENV.get("PATH", "")
ENV["JAPP_W13_PERFORMANCE_SAMPLES"] = "20"
ENV["PLAYWRIGHT_JSON_OUTPUT_NAME"] = str(PROOF / "results.json")
ARGV = [PNPM, "exec", "playwright", "test", OVERLAY, "--grep", TITLE, "--reporter=line,json"]


def now() -> str:
    return dt.datetime.now(dt.UTC).isoformat()


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def save(name: str, value: object) -> None:
    (PROOF / name).write_text(json.dumps(value, indent=2) + "\n")


def capture(argv: list[str]) -> str:
    return subprocess.check_output(argv, cwd=CLONE, env=ENV, text=True).strip()


def sources() -> dict:
    paths = subprocess.check_output(["git", "ls-files", "-z"], cwd=CLONE).split(b"\0")
    files = []
    for raw in paths:
        if not raw:
            continue
        rel = raw.decode()
        data = (CLONE / rel).read_bytes()
        files.append({"path": rel, "bytes": len(data), "sha256": digest(data)})
    return {
        "at": now(),
        "head": capture(["git", "rev-parse", "HEAD"]),
        "tree": capture(["git", "rev-parse", "HEAD^{tree}"]),
        "status_porcelain": capture(["git", "status", "--porcelain=v1"]),
        "diff_binary": capture(["git", "diff", "--binary"]),
        "files": files,
        "total_bytes": sum(item["bytes"] for item in files),
    }


def verify_sources(value: dict) -> None:
    assert value["head"] == HEAD
    assert value["tree"] == TREE
    assert value["status_porcelain"] == "M " + OVERLAY, value["status_porcelain"]
    assert next(item["sha256"] for item in value["files"] if item["path"] == OVERLAY) == OVERLAY_SHA
    assert capture(["git", "diff", "--name-only"]) == OVERLAY
    assert digest((BASE / "foreground-diagnostic.patch").read_bytes()) == PATCH_SHA
    assert digest((BASE / "benchmark-candidate.ts").read_bytes()) == OVERLAY_SHA
    original = json.loads((PROOF / "frozen-before-overlay-sources.json").read_text())
    expected = [item for item in original["files"] if item["path"] != OVERLAY]
    assert [item for item in value["files"] if item["path"] != OVERLAY] == expected


def runtime() -> dict:
    code = "import {captureRuntimeInventory} from './e2e/extension/legacy-paired-options/runtime-inventory.ts'; console.log(JSON.stringify(captureRuntimeInventory(process.cwd())));"
    value = json.loads(capture([NODE, "--input-type=module", "-e", code]))
    assert value["digest"] == RUNTIME
    assert len(value["files"]) == 355
    assert value["total_bytes"] == 3372811
    return value


def built() -> dict:
    result = {"at": now(), "scope": "Actual build-output endpoints; before is absent in fresh clone. Canonical Playwright global setup builds production and invalid-ACK variants before the test.", "directories": {}}
    for rel in ["apps/extension/dist/chrome-mv3", "apps/extension/dist/invalid-ack/chrome-mv3", "apps/mock-ats-lab/dist"]:
        target = CLONE / rel
        files = []
        if target.exists():
            for path in sorted(target.rglob("*")):
                if path.is_file():
                    data = path.read_bytes()
                    files.append({"path": path.relative_to(CLONE).as_posix(), "bytes": len(data), "sha256": digest(data)})
        result["directories"][rel] = {"exists": target.exists(), "files": files, "total_bytes": sum(item["bytes"] for item in files)}
    return result


def tools() -> dict:
    result = {
        "at": now(),
        "node": capture([NODE, "--version"]),
        "node_exec_path": capture([NODE, "-p", "process.execPath"]),
        "pnpm": capture([PNPM, "--version"]),
        "playwright": capture([PNPM, "exec", "playwright", "--version"]),
        "python": sys.version,
        "platform": platform.platform(),
        "machine": platform.machine(),
    }
    assert result["node"] == "v24.18.0"
    assert result["pnpm"] == "11.17.0"
    assert result["playwright"] == "Version 1.62.0"
    assert sys.version_info[:2] == (3, 12)
    for rel in ["pnpm-lock.yaml", "node_modules/.pnpm/lock.yaml"]:
        data = (CLONE / rel).read_bytes()
        result[rel] = {"bytes": len(data), "sha256": digest(data)}
    return result


def rows_from_log() -> dict:
    raw = (PROOF / "run.log").read_bytes()
    parsed = {}
    tags = ["W13_PROFILE_BROWSER_COMMAND_LINE", "W13_PROFILE_PREWORK", "W13_PROFILE_COMPLETED_ROW", "W13_PROFILE_POSTWORK", "W13_SCALING", "W13_TARGET_P95"]
    for tag in tags:
        marker = (tag + " ").encode()
        lines = [line for line in raw.splitlines(keepends=True) if marker in line]
        (PROOF / (tag + "-exact-lines.log")).write_bytes(b"".join(lines))
        values = []
        for line in lines:
            text = line.decode()
            value, _ = json.JSONDecoder().raw_decode(text[text.index(tag + " ") + len(tag) + 1:])
            values.append(value)
        parsed[tag] = values
    save("all-diagnostic-messages.json", parsed)
    completed = parsed["W13_PROFILE_COMPLETED_ROW"]
    rows = [value["row"] for value in completed]
    save("all-completed-diagnostic-rows.json", rows)
    native = [row for row in rows if row["control_count"] == 128]
    work_checks = {
        "reresolution_calls": 512, "descriptors_built": 768,
        "index_rebuilds": 1, "index_hits": 511, "index_invalidations": 0,
        "candidate_enumerations": 3, "candidates_examined": 384,
        "identity_pairs_examined": 128,
        "preflight_reresolutions": 128, "preaction_reresolutions": 128,
        "settle_reresolutions": 128, "reconcile_reresolutions": 128,
        "other_reresolutions": 0,
    }
    violations = []
    for index, row in enumerate(native, 1):
        for key, expected in {"actions_attempted": 128, "physical_actions_count": 128, "settle_budget_ms": 0}.items():
            if row[key] != expected:
                violations.append({"sample": index, "key": key, "expected": expected, "actual": row[key]})
        for key, expected in work_checks.items():
            if row["scanner_work"][key] != expected:
                violations.append({"sample": index, "key": key, "expected": expected, "actual": row["scanner_work"][key]})
        if "phase_wall_clock_ms" in row:
            violations.append({"sample": index, "key": "unexpected_phase_overlay"})
    aggregate = parsed["W13_SCALING"]
    aggregate_matches_completed = len(aggregate) == 1 and aggregate[0]["rows"] == rows
    full = len(rows) == 22 and len(native) == 20 and aggregate_matches_completed
    p95_ms = None
    p95_sample = None
    if full:
        ordered = sorted(enumerate(native, 1), key=lambda pair: pair[1]["total_wall_clock_ms"])
        p95_sample, p95 = ordered[18]
        p95_ms = p95["total_wall_clock_ms"]
    def states(values, member):
        return dict(collections.Counter(value[member]["target"]["visibility_state"] for value in values))
    return {
        "scope": SCOPE,
        "limits": ["Foreground posture and extra probes differ from canonical benchmark; no acceptance equivalence, KI96 closure, Gate verdict or causal conclusion.", "Added probes/logging consume the unchanged whole-test120000ms deadline outside each original sample interval.", "Point visibility/focus readings do not establish continuous foreground or prove timer behavior.", "Canonical246 timeout and all prior failures remain immutable; one invocation, no retry."],
        "source_commit": HEAD, "source_tree": TREE,
        "overlay_sha256": OVERLAY_SHA, "overlay_patch_sha256": PATCH_SHA,
        "sample_count_requested": 20, "completed_rows": len(rows), "completed_native128_rows": len(native),
        "prework_observations": len(parsed["W13_PROFILE_PREWORK"]),
        "postwork_observations": len(parsed["W13_PROFILE_POSTWORK"]),
        "actual_browser_command_line_observations": len(parsed["W13_PROFILE_BROWSER_COMMAND_LINE"]),
        "all22_aggregate_present_and_matches_completed_rows": full,
        "p95_rank": 19 if full else None, "p95_sample": p95_sample,
        "diagnostic_p95_ms": p95_ms, "threshold_ms": 1500,
        "diagnostic_threshold_pass": p95_ms <= 1500 if full else None,
        "all_completed_native128_workload_checks_pass": not violations,
        "workload_violations": violations,
        "original_target_visibility_states": dict(collections.Counter(value["original"]["target"]["visibility_state"] for value in parsed["W13_PROFILE_PREWORK"])),
        "before_target_visibility_states": states(parsed["W13_PROFILE_PREWORK"], "foreground_before"),
        "after_target_visibility_states": states(parsed["W13_PROFILE_POSTWORK"], "foreground_after"),
        "message_counts": {tag: len(values) for tag, values in parsed.items()},
        "all_message_exact_lines_retained": True,
    }


def discover() -> dict:
    argv = ARGV[:-1] + ["--list", "--reporter=json"]
    env = dict(ENV)
    env.pop("PLAYWRIGHT_JSON_OUTPUT_NAME", None)
    result = subprocess.run(argv, cwd=CLONE, env=env, capture_output=True)
    (PROOF / "discovery.stdout.json").write_bytes(result.stdout)
    (PROOF / "discovery.stderr.log").write_bytes(result.stderr)
    save("discovery-command.json", {"at": now(), "argv": argv, "cwd": str(CLONE), "exit_code": result.returncode, "scope": "Canonical --list skips global setup/build/browser"})
    value = json.loads(result.stdout)
    matches = []
    def visit(suites):
        for suite in suites:
            for spec in suite.get("specs", []):
                matches.append({"file": spec.get("file"), "title": spec["title"], "tests": len(spec.get("tests", []))})
            visit(suite.get("suites", []))
    visit(value["suites"])
    summary = {"at": now(), "exit_code": result.returncode, "matches": matches, "total_specs": len(matches), "total_tests": sum(item["tests"] for item in matches)}
    save("discovery-summary.json", summary)
    assert result.returncode == 0 and len(matches) == 1 and matches[0]["title"] == TITLE and summary["total_tests"] == 1, summary
    return summary


def run() -> int:
    release = json.loads((BASE / "root-actor-release.json").read_text())
    assert release["parent_explicit_release"] is True
    assert release["all_heavy_work_quiesced"] is True
    assert release["frozen_commit"] == HEAD
    assert release["maximum_invocations"] == 1
    assert release["overlay_patch_sha256"] == PATCH_SHA
    assert release["overlay_source_sha256"] == OVERLAY_SHA
    discovery = json.loads((PROOF / "discovery-summary.json").read_text())
    assert discovery["exit_code"] == 0 and discovery["total_specs"] == discovery["total_tests"] == 1
    assert discovery["matches"][0]["title"] == TITLE
    assert not (PROOF / "invocation-started.json").exists(), "ONE_INVOCATION_ONLY"
    before = sources()
    verify_sources(before)
    save("before-sources.json", before)
    save("before-runtime.json", runtime())
    save("before-tools.json", tools())
    save("before-build.json", built())
    save("command.json", {"at": now(), "argv": ARGV, "cwd": str(CLONE), "environment": {key: ENV[key] for key in ["PATH", "JAPP_W13_PERFORMANCE_SAMPLES", "PLAYWRIGHT_JSON_OUTPUT_NAME"]}, "trace_policy": "Original retain-on-failure; no trace override", "parent_release": release, "wrapper_path": str(Path(__file__).resolve()), "wrapper_sha256": digest(Path(__file__).read_bytes())})
    with (PROOF / "invocation-started.json").open("x") as marker:
        marker.write(json.dumps({"at": now(), "one_invocation_only": True}) + "\n")
    started = time.monotonic()
    proc = subprocess.Popen(ARGV, cwd=CLONE, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    with (PROOF / "run.log").open("wb") as log:
        assert proc.stdout is not None
        for line in proc.stdout:
            log.write(line)
            log.flush()
            if b"W13_SCALING " not in line and b"W13_PROFILE_" not in line:
                sys.stdout.buffer.write(line)
                sys.stdout.buffer.flush()
    exit_code = proc.wait()
    save("completion.json", {"at": now(), "exit_code": exit_code, "duration_s": time.monotonic() - started})
    print(f"CHILD_CLOSED: exit={exit_code}; retaining actual raw/native/endpoints before analysis", flush=True)
    # Retain native test artifacts immediately, before any possible later
    # Playwright invocation can clear its default output directory.
    source_artifacts = CLONE / "test-results"
    if source_artifacts.exists():
        shutil.copytree(source_artifacts, PROOF / "native-test-results")
    artifact_files = []
    for path in sorted((PROOF / "native-test-results").rglob("*")):
        if path.is_file():
            data = path.read_bytes()
            artifact_files.append({"path": path.relative_to(PROOF).as_posix(), "bytes": len(data), "sha256": digest(data)})
    save("native-artifact-retention.json", {"at": now(), "files": artifact_files})
    after = sources()
    save("after-sources.json", after)
    save("after-runtime.json", runtime())
    save("after-tools.json", tools())
    save("after-build.json", built())
    verify_sources(after)
    assert before["files"] == after["files"]
    assert before["diff_binary"] == after["diff_binary"]
    summary = rows_from_log()
    summary["child_exit_code"] = exit_code
    summary["all_tracked_source_unchanged"] = True
    summary["only_reviewed_benchmark_overlay"] = True
    save("foreground-diagnostic-summary.json", summary)
    print(json.dumps(summary, indent=2), flush=True)
    assert summary["all_completed_native128_workload_checks_pass"], summary["workload_violations"]
    return exit_code


def setup_source_only() -> None:
    assert FREEZE["runtime_digest"] == RUNTIME
    assert FREEZE["runtime_files"] == 355 and FREEZE["runtime_bytes"] == 3372811
    if CLONE.exists():
        raise RuntimeError("Fresh diagnostic clone required; no setup reuse")
    commands = [
        (["git", "clone", "--no-hardlinks", "/Users/tanishkalwad/jobapplyv2", str(CLONE)], BASE),
        (["git", "checkout", "--detach", HEAD], CLONE),
    ]
    history = []
    with (PROOF / "setup.log").open("wb") as log:
        for argv, cwd in commands:
            result = subprocess.run(argv, cwd=cwd, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            log.write(result.stdout)
            log.flush()
            history.append({"at": now(), "argv": argv, "cwd": str(cwd), "exit_code": result.returncode})
            save("setup-commands.json", history)
            if result.returncode:
                sys.stdout.buffer.write(result.stdout)
                raise RuntimeError("Source setup failed; no browser/performance actor ran")
        original = sources()
        assert original["head"] == HEAD and original["tree"] == TREE
        assert original["status_porcelain"] == ""
        assert next(item["sha256"] for item in original["files"] if item["path"] == OVERLAY) == ORIGINAL_SHA
        save("frozen-before-overlay-sources.json", original)
        for argv in [
            ["git", "apply", str(BASE / "foreground-diagnostic.patch")],
            [PNPM, "install", "--frozen-lockfile", "--offline", "--ignore-scripts"],
        ]:
            result = subprocess.run(argv, cwd=CLONE, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            log.write(result.stdout)
            log.flush()
            history.append({"at": now(), "argv": argv, "cwd": str(CLONE), "exit_code": result.returncode})
            save("setup-commands.json", history)
            if result.returncode:
                sys.stdout.buffer.write(result.stdout)
                raise RuntimeError("Diagnostic source setup failed; no browser/performance actor ran")


parser = argparse.ArgumentParser()
parser.add_argument("--prepare", action="store_true")
parser.add_argument("--run-after-parent-release", action="store_true")
args = parser.parse_args()
PROOF.mkdir(exist_ok=True)
if args.prepare:
    setup_source_only()
    prepared = sources()
    verify_sources(prepared)
    save("prepared-sources.json", prepared)
    save("prepared-runtime.json", runtime())
    save("prepared-tools.json", tools())
    save("prepared-build.json", built())
    save("prepared-plan.json", {"at": now(), "argv": ARGV, "cwd": str(CLONE), "source_only": True, "browser_build_actors": 0, "release_required": True, "scope": SCOPE, "only_reviewed_benchmark_overlay": True, "overlay_sha256": OVERLAY_SHA, "patch_sha256": PATCH_SHA, "frozen_source_binding": FREEZE})
    discovery = discover()
    print("PREPARED_ONLY: frozen source/tools/runtime bound; only exact reviewed benchmark overlay; exactly one existing W13 L test discovered; no build or browser launched.", flush=True)
elif args.run_after_parent_release:
    sys.exit(run())
else:
    parser.error("select --prepare or --run-after-parent-release")
