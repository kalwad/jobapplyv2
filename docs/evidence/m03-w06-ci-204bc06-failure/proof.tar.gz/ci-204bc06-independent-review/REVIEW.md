# Terminal fixed-run CI review — 204bc06

CLEAR AS RECORDED FAILURE. All 615 terminal source/result/artifact joins pass. Run [40790930093](https://github.com/kalwad/jobapplyv2/actions/runs/40790930093), attempt 1, is completed with conclusion FAILURE. No repository file or access setting was changed, and no downloaded executable/artifact was run.

All three actual checkout logs print merge commit `e4687f0d608af7deb1e80b5879a7102c8f1edf8a`. Its API commit binds the PR head `204bc06a374631f4b40d4fc382f573a77ef9242a` as a parent and tree `5b5bfeda09b60654adce335e0e21cd9ad056e120`, exactly the head's independently hashed 2070 Git blobs. This distinguishes the actual tested merge from the PR head identity while proving their tree equivalence.

Mac and Ubuntu each report 18 PASS / 2 FAIL; Python and integrity both refuse the metadata fixture before Python collection/execution. Windows reports 17 PASS / 3 FAIL: the same refusals plus desktop Rust default mode 300 PASS / 16 FAIL; later feature modes were unexecuted. Mac's desktop native tests pass 342 cases in each of three modes; Ubuntu passes 338 per mode. These are ordinary source-CI results, not packaged-native acceptance. All three jobs' fresh Turbo test tasks report 15 successful / zero cached, with ordinary test counts summing to 4006. Complete Vitest case IDs were not emitted as a separate identity channel.

The dependent native development package job is SKIPPED. Three official playwright-failure ZIPs and one Windows native-loader diagnostic ZIP are retained, with all 575 safe regular extracted members byte/hash checked and artifact sizes/digests matching the API. The native-loader diagnostic is separate from the skipped development-package job. Every closed job raw log is byte-identical to its corresponding complete job log inside the official run archive. Curated manifests and raw official logs remain under `ci-204bc06`.

The single authorized repo-scoped self-hosted runner inventory returned HTTP 200 and `total_count: 0`. This supplies no available Windows11/default-GNOME desktop runner and no OS fact inferred from labels. No runner provisioning, registration, broader inventory, or secret/access change occurred.

Later fixture corrections or later CI cannot replace this failure. No future CI, Python execution, native package, GUI, milestone, or release PASS is asserted. This fixed collector is closed; its final snapshot/closure and review bindings are retained.
