from pathlib import Path
import hashlib,json,re,zipfile
base=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');src=base/'ci-204bc06';out=Path(__file__).parent
load=lambda n:json.loads((src/n).read_text());checks=[]
def check(name,value,detail=None):
 checks.append({'name':name,'pass':bool(value),'detail':detail});assert value,(name,detail)
run=load('terminal-run.json');jobs=load('terminal-jobs.json')['jobs'];closure=load('collector-closure.json');bindings=load('checkout-source-bindings.json');immutable=load('immutable-git-source-sha256.json')
check('Exact fixed204bc run and terminalfailure',run['id']==40790930093 and run['run_attempt']==1 and run['head_sha']==immutable['commit'] and run['status']=='completed' and run['conclusion']=='failure')
check('4 terminal jobs and3 canonicalfailures1nativepackageskip',len(jobs)==4 and sum(j['conclusion']=='failure' for j in jobs)==3 and sum(j['conclusion']=='skipped' for j in jobs)==1 and all(j['status']=='completed' for j in jobs))
merge='e4687f0d608af7deb1e80b5879a7102c8f1edf8a';binding=bindings[merge]
check('Actualmerge binds same2070tree and PRheadparent',binding['same_tree_as_run_head'] and binding['tree']==immutable['tree'] and binding['blob_count']==2070 and immutable['commit'] in binding['parents'])
rows_by_job=[]
log_members=load('log-members.json')
for job in jobs:
 if job['conclusion']=='skipped':
  check('Nativepackage job skipped truthfully','native development package' in job['name']);continue
 identity=job['id'];path=src/f'closed-jobs/{identity}.log';raw=path.read_bytes();text=raw.decode();plain='\n'.join(re.sub(r'^\d{4}-\d\d-\d\dT[^ ]+ ', '',line) for line in text.splitlines())
 plain=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',plain)
 found=re.search(r'log -1 --format=%H\n[^\n]*?\b([0-9a-f]{40})\s*\n',plain)
 check('Actual exactcheckout '+str(identity),found is not None and found.group(1)==merge)
 check('Officialcompletejoblog same as runarchive '+str(identity),any(i['bytes']==len(raw) and i['sha256']==hashlib.sha256(raw).hexdigest() and i['path'].endswith(job['name']+'.txt') for i in log_members))
 section=plain.split('== verification summary ==\n')[-1]
 rows=re.findall(r'^(\S+)[ \t]+(ACTIVE)[ \t]+(PASS|FAIL)[ \t]*(.*)$',section,re.M)
 expected_fail={'python','integrity'}|({'rust'} if 'windows' in job['name'] else set())
 check('20unique suites '+str(identity),len(rows)==20 and len({r[0] for r in rows})==20)
 check('Expected exact suite failures '+str(identity),{r[0] for r in rows if r[2]=='FAIL'}==expected_fail)
 reason='dynamic pytest collection hook registration is forbidden in services/orchestrator/tests/test_runtime_metadata.py'
 check('Exactmetadata refusal both diagnostics '+str(identity),section.count('  - '+reason)==2)
 commands=re.findall(r'^\$ (.*)$',plain,re.M)
 check('NoPythoncollection/execution after preflight refusal '+str(identity),not any('pytest' in c for c in commands))
 unit=plain.split('$ pnpm exec turbo run test --force --concurrency=2 -- --reporter=default\n')[1].split('$ pnpm generate:contracts --check')[0]
 package_counts=re.findall(r'^(?:@japp/[^:]+:test:)?[ \t]+Tests[ \t]+(\d+) passed \(\d+\)',unit,re.M)
 check('Unit4006/15fresh '+str(identity),len(package_counts)==15 and sum(int(c) for c in package_counts)==4006 and 'Cached:    0 cached, 15 total' in unit)
 rust_summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;.*$',plain,re.M)
 if 'windows' in job['name']:
  check('Windowsactualnative300PASS16FAIL',('FAILED','300','16','0','0','0') in rust_summaries)
  check('LaterWindowsnative modes unexecuted',not any('--manifest-path apps/desktop/src-tauri/Cargo.toml --all-features' in c or '--manifest-path apps/desktop/src-tauri/Cargo.toml --features tauri/custom-protocol' in c for c in commands))
 check('JobAPIheadmatchesrunhead '+str(identity),job['head_sha']==run['head_sha'])
 rows_by_job.append({'id':identity,'name':job['name'],'status':job['status'],'conclusion':job['conclusion'],'actual_checkout_commit':merge,'actual_checkout_tree':binding['tree'],'passed_suites':sum(r[2]=='PASS' for r in rows),'failed_suites':sorted(expected_fail),'suite_rows':[{'suite':r[0],'verdict':r[2]} for r in rows],'unit_passed':4006,'python':'PREFLIGHT_REFUSED_NO_COLLECTION_EXECUTION','raw_log_bytes':len(raw),'raw_log_sha256':hashlib.sha256(raw).hexdigest(),'rust_raw_summaries':rust_summaries})
artifacts_json=sorted((src/'artifact-lists').glob('*.json'))[-1];artifacts=json.loads(artifacts_json.read_text())['artifacts'];artifact_receipts=[]
for artifact in artifacts:
 identity=artifact['id'];path=src/f'artifacts/{identity}.zip';members=load(f'artifacts/{identity}-members.json');h=hashlib.sha256(path.read_bytes()).hexdigest()
 check('ArtifactAPIidentity/hash '+str(identity),not artifact['expired'] and artifact['size_in_bytes']==path.stat().st_size and artifact['digest']=='sha256:'+h)
 with zipfile.ZipFile(path) as zip:
  regular={i.filename.replace('\\','/'):i for i in zip.infolist() if not i.is_dir()}
  check('Artifactallmembers '+str(identity),set(regular)=={m['path'] for m in members})
  for member in members:
   p=src/f'artifacts/{identity}-contents'/member['path'];data=p.read_bytes()
   check('Artifactretainedmember '+str(identity)+'/'+member['path'],p.is_file() and not p.is_symlink() and len(data)==member['bytes'] and hashlib.sha256(data).hexdigest()==member['sha256'])
 receipt={'id':identity,'name':artifact['name'],'bytes':path.stat().st_size,'sha256':h,'safe_regular_members':len(members)};artifact_receipts.append(receipt)
check('All4downloadedexact',len(artifact_receipts)==4 and {a['id'] for a in artifact_receipts}==set(closure['downloaded_artifacts']))
inventory=load('repo-self-hosted-runner-inventory/summary.json')
check('Noauthorizedselfhostedrepo runners returned',inventory.get('total_count')==0 or inventory.get('response',{}).get('total_count')==0,inventory)
report={'scope':'INDEPENDENT_TERMINAL_CI_204BC06_DATA_JOIN_NO_FUTURE_CI_OR_NATIVE_PACKAGE_ACCEPTANCE','verdict':'CLEAR_AS_RECORDED_FAILURE','checks':checks,'passed_checks':len(checks),'run':run['id'],'run_url':run['html_url'],'run_conclusion':run['conclusion'],'head':run['head_sha'],'actual_checkout':merge,'tree':binding['tree'],'tracked_blob_count':2070,'jobs':rows_by_job,'native_development_package':'SKIPPED','artifacts':artifact_receipts,'no_subject_execution':True,'canonical_writes':0,'self_hosted_runner_inventory':inventory}
(out/'actual-data-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in {'checks','jobs','self_hosted_runner_inventory'}},indent=2))
