"""Read-only API/log/artifact retention for fixed 204bc06 run. Never executes artifacts."""
from pathlib import Path, PurePosixPath
import datetime,hashlib,json,os,re,stat,subprocess,time,zipfile
BASE=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028/ci-204bc06')
BASE.mkdir(exist_ok=False)
HEAD='204bc06a374631f4b40d4fc382f573a77ef9242a'
TREE='5b5bfeda09b60654adce335e0e21cd9ad056e120'
RUN=40790930093
REPO='repos/kalwad/jobapplyv2/'
receipts=[];downloaded_jobs=set();downloaded_artifacts=set();checkout_bindings={};previous=None

def now():return datetime.datetime.now(datetime.UTC).isoformat()
def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        while b:=f.read(1024*1024):h.update(b)
    return h.hexdigest()
def dump(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2)+'\n')
def api(endpoint,name,*,timeout=50,binary=False):
    target=BASE/name;target.parent.mkdir(parents=True,exist_ok=True);start=now()
    with target.open('wb') as output:
        try:
            p=subprocess.run(['gh','api',REPO+endpoint],stdout=output,stderr=subprocess.PIPE,timeout=timeout,check=False)
            receipt={'endpoint':endpoint,'start_utc':start,'end_utc':now(),'exit_code':p.returncode,'path':name,'bytes':target.stat().st_size,'sha256':digest(target)}
            if p.stderr:target.with_name(target.name+'.stderr').write_bytes(p.stderr)
            okay=p.returncode==0
        except subprocess.TimeoutExpired as exc:
            receipt={'endpoint':endpoint,'start_utc':start,'end_utc':now(),'timed_out':True,'path':name,'partial_bytes':target.stat().st_size,'partial_sha256':digest(target)};okay=False
            if exc.stderr:target.with_name(target.name+'.stderr').write_bytes(exc.stderr)
    receipts.append(receipt);dump(BASE/'api-receipts.json',receipts)
    if not okay:return None
    return target if binary else json.loads(target.read_text())

def safe_unzip(path,target,*,max_total=1536*1024*1024,max_file=600*1024*1024):
    target.mkdir(parents=True,exist_ok=False);members=[];seen=set();total=0
    with zipfile.ZipFile(path) as archive:
        assert len(archive.infolist())<=12000,'member count bound'
        for item in archive.infolist():
            name=item.filename.replace('\\','/');pure=PurePosixPath(name)
            assert not pure.is_absolute() and '..' not in pure.parts and pure.parts and ':' not in pure.parts[0] and name not in seen,'unsafe/duplicate ZIP path'
            seen.add(name);kind=stat.S_IFMT(item.external_attr>>16)
            assert kind in (0,stat.S_IFREG,stat.S_IFDIR),'nonregular archive node'
            p=target/name
            if item.is_dir():p.mkdir(parents=True,exist_ok=True);continue
            assert item.file_size<=max_file,'single member bound';total+=item.file_size;assert total<=max_total,'expanded byte bound'
            p.parent.mkdir(parents=True,exist_ok=True)
            with archive.open(item) as src,p.open('xb') as out:
                size=0
                while data:=src.read(1024*1024):size+=len(data);assert size<=item.file_size;out.write(data)
            assert size==item.file_size
            members.append({'path':name,'bytes':size,'sha256':digest(p)})
    return members

def bind_checkout(job_id,path):
    raw=path.read_text(errors='replace')
    # Official checkout action prints one exact git-log commit hash after this command.
    found=re.search(r'log -1 --format=%H\r?\n[^\r\n]*?\b([0-9a-f]{40})\s*\r?\n',raw)
    if not found:return
    commit=found.group(1)
    if commit in checkout_bindings:return
    info=api('git/commits/'+commit,'source-bindings/'+commit+'-commit.json')
    if info is None:return
    tree_id=info['tree']['sha'];tree=api('git/trees/'+tree_id+'?recursive=1','source-bindings/'+commit+'-tree.json')
    if tree is None:return
    assert not tree['truncated']
    checkout_bindings[commit]={'observed_checkout_commit':commit,'observed_in_job':job_id,'tree':tree_id,'blob_count':sum(x['type']=='blob' for x in tree['tree']),'same_tree_as_run_head':tree_id==TREE,'parents':[x['sha'] for x in info['parents']]}
    dump(BASE/'checkout-source-bindings.json',checkout_bindings)
    print(json.dumps({'checkout_binding':checkout_bindings[commit]}),flush=True)

def collect_artifacts(index):
    data=api(f'actions/runs/{RUN}/artifacts?per_page=100',f'artifact-lists/{index:03d}.json')
    if data is None:return
    for artifact in data['artifacts']:
        identity=artifact['id']
        if identity in downloaded_artifacts or artifact['expired']:continue
        # Repository curation is bounded to1GiB; preserve but do not execute delivered bytes.
        if artifact['size_in_bytes']>1536*1024*1024:
            dump(BASE/f'artifacts/{identity}-not-downloaded.json',{'reason':'artifact exceeds finite collector bound','metadata':artifact});continue
        path=api(f'actions/artifacts/{identity}/zip',f'artifacts/{identity}.zip',timeout=240,binary=True)
        if path is None:continue
        target=BASE/f'artifacts/{identity}-contents'
        try:
            members=safe_unzip(path,target);dump(BASE/f'artifacts/{identity}-members.json',members)
            manifests=list(target.rglob('manifest.json'));verification=[]
            for manifest in manifests:
                value=json.loads(manifest.read_text())
                if not isinstance(value,dict) or not isinstance(value.get('files'),dict):continue
                verified=[]
                for name,row in value['files'].items():
                    q=PurePosixPath(name);assert not q.is_absolute() and '..' not in q.parts
                    p=manifest.parent/name
                    verified.append({'path':name,'present_regular':p.is_file() and not p.is_symlink(),'matches':p.is_file() and p.stat().st_size==row['bytes'] and digest(p)==row['sha256']})
                verification.append({'manifest':manifest.relative_to(target).as_posix(),'declared_count':value.get('file_count'),'declared_bytes':value.get('bytes'),'verified_members':verified,'all_exact':all(x['present_regular'] and x['matches'] for x in verified)})
            dump(BASE/f'artifacts/{identity}-retention-verification.json',verification)
            downloaded_artifacts.add(identity)
            print(json.dumps({'artifact_retained':identity,'name':artifact['name'],'archive_bytes':path.stat().st_size,'archive_sha256':digest(path),'safe_regular_members':len(members),'retention_manifests_exact':all(x['all_exact'] for x in verification)}),flush=True)
        except (OSError,ValueError,AssertionError,zipfile.BadZipFile) as exc:
            dump(BASE/f'artifacts/{identity}-retention-error.json',{'metadata':artifact,'error_type':type(exc).__name__,'error':str(exc),'raw_zip_retained':True});print(json.dumps({'artifact_review_error':identity,'error_type':type(exc).__name__}),flush=True)

head=api('git/commits/'+HEAD,'head-commit.json');assert head and head['sha']==HEAD and head['tree']['sha']==TREE
source=api('git/trees/'+TREE+'?recursive=1','head-tree.json');assert source and not source['truncated'] and sum(x['type']=='blob' for x in source['tree'])==2070
(BASE/'collector-executed.py').write_bytes(Path(__file__).read_bytes())
dump(BASE/'collector-context.json',{'run':RUN,'head':HEAD,'tree':TREE,'source_blobs':2070,'start_utc':now(),'scope':'READ_ONLY_GET_API_AND_OFFICIAL_LOG_ARTIFACT_RETENTION_NO_CANONICAL_WRITES_OR_SUBJECT_EXECUTION'})
for index in range(181):
    run=api(f'actions/runs/{RUN}',f'snapshots/{index:03d}-run.json');data=api(f'actions/runs/{RUN}/jobs?per_page=100',f'snapshots/{index:03d}-jobs.json')
    if run is not None and data is not None:
        assert run['head_sha']==HEAD and run['run_attempt']==1
        jobs=data['jobs'];state=(run['status'],run['conclusion'],tuple((x['id'],x['name'],x['status'],x['conclusion'],next((s['number'] for s in x['steps'] if s['status']=='in_progress'),None)) for x in jobs))
        if state!=previous:
            print(json.dumps({'observed_utc':now(),'run':RUN,'status':run['status'],'conclusion':run['conclusion'],'jobs':[{'id':x['id'],'name':x['name'],'status':x['status'],'conclusion':x['conclusion'],'current_step':next((s['name'] for s in x['steps'] if s['status']=='in_progress'),None)} for x in jobs]}),flush=True);previous=state
        new_closed=False
        for job in jobs:
            if job['status']=='completed' and job['conclusion']!='skipped' and job['id'] not in downloaded_jobs:
                path=api(f'actions/jobs/{job["id"]}/logs',f'closed-jobs/{job["id"]}.log',binary=True)
                if path is None:continue
                downloaded_jobs.add(job['id']);new_closed=True;bind_checkout(job['id'],path)
                print(json.dumps({'closed_job_retained':job['id'],'name':job['name'],'conclusion':job['conclusion'],'bytes':path.stat().st_size,'sha256':digest(path)}),flush=True)
                if job['conclusion']!='success':
                    text=path.read_text(errors='replace');tail=text[text.rfind('== verification summary =='):] if '== verification summary ==' in text else text[-12000:]
                    (BASE/f'closed-jobs/{job["id"]}-failure-excerpt.txt').write_text(tail)
                    print(json.dumps({'terminal_job_failure':job['id'],'name':job['name'],'excerpt_path':str(BASE/f'closed-jobs/{job["id"]}-failure-excerpt.txt')}),flush=True)
        if new_closed:collect_artifacts(index)
        if run['status']=='completed':
            dump(BASE/'terminal-run.json',run);dump(BASE/'terminal-jobs.json',data);collect_artifacts(index)
            logs=api(f'actions/runs/{RUN}/logs','official-logs.zip',timeout=120,binary=True)
            if logs is not None:
                try:members=safe_unzip(logs,BASE/'logs',max_total=256*1024*1024,max_file=32*1024*1024);dump(BASE/'log-members.json',members)
                except (OSError,ValueError,AssertionError,zipfile.BadZipFile) as exc:dump(BASE/'log-retention-error.json',{'error_type':type(exc).__name__,'error':str(exc)})
            dump(BASE/'collector-closure.json',{'end_utc':now(),'run_status':run['status'],'run_conclusion':run['conclusion'],'downloaded_jobs':sorted(downloaded_jobs),'downloaded_artifacts':sorted(downloaded_artifacts),'checkout_bindings':checkout_bindings,'no_subject_execution':True,'canonical_writes':0})
            print(json.dumps({'terminal_run':RUN,'conclusion':run['conclusion'],'retained_jobs':len(downloaded_jobs),'retained_artifacts':len(downloaded_artifacts)}),flush=True);break
    if index==180:
        dump(BASE/'collector-time-limit.json',{'end_utc':now(),'product_conclusion':'UNOBSERVED_NOT_ASSUMED','polls':181});print(json.dumps({'collector_limit':True,'product_conclusion':'UNOBSERVED'}),flush=True);break
    time.sleep(60)
