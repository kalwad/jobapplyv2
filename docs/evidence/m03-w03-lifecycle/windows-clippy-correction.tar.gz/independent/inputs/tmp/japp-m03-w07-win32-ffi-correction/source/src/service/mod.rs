mod authority_hub;
mod lifecycle_state;
mod platform;
mod protocol;
pub mod restart;
pub mod session_hub;
mod supervisor;

pub use platform::{ConfiguredRuntime, MonotonicClock};
pub use protocol::{Bootstrap, ReadyFrame, ServiceIdentity};
pub use supervisor::*;

mod managed_restart;
pub use managed_restart::ManagedService;

mod runtime_integrity;
#[cfg(any(windows, feature = "windows-source-check"))]
mod windows_native;
mod windows_policy;
