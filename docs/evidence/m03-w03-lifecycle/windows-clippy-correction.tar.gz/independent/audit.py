"""Independent read-only source and receipt audit, without imports or actors."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import shutil
import subprocess

BASE=Path('/tmp/japp-m03-w03-windows-clippy-correction-20261019')
OUT=Path(__file__).parent
ROOT=Path('/Users/tanishkalwad/jobapplyv2')
SOURCE=BASE/'source'
HEAD='cac56a00abdd7c86e148b10fd26ea317d62b4361'
checks=[]
inputs={}

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        while data:=f.read(1048576):h.update(data)
    return h.hexdigest()

def keep(p,copy=True):
    p=Path(p)
    row={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
    if copy:
        target=OUT/'inputs'/str(p).lstrip('/')
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(p,target)
        assert sha(target)==row['sha256']
        row['copy']=str(target.relative_to(OUT))
    inputs[str(p)]=row
    return row

def read(p):keep(p);return json.loads(Path(p).read_text())
def check(name,condition,detail):checks.append({'name':name,'pass':bool(condition),'detail':detail})
def git(*argv):return subprocess.check_output(['git','-C',str(ROOT),*argv])
before={'head':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'status':git('status','--porcelain=v1').decode()}
retention=read(BASE/'retention.json')
check('sealed handoff/source/patch/retention identities',sha(BASE/'HANDOFF.md')=='f6909930a9b6f7f2c199147beb21d00480a342a719396a764942362b1e77f53a' and sha(BASE/'source-final.json')=='167fa2b3562d71875c98085827c2bed5be3352c3c07c62af8608902900213c7b' and sha(BASE/'windows-clippy-correction.patch')=='b7d49f4b25da9ca601a599b82f27c118a7723b0d4be190013269ff82978ba82a' and sha(BASE/'retention.json')=='c769896b9d84115a7586a2a128b2074f8fb455e7287a1369d676174200d2865d','Author-provided exact sealed identifiers.')
allretained=[]
for row in retention['files']:
    p=BASE/row['path']
    actual=keep(p,copy=not row['path'].startswith(('source/','produced-test-binaries/')))
    allretained.append(actual['sha256']==row['sha256'] and actual['bytes']==row['bytes'])
check('all retained input hashes and sizes',all(allretained),{'records':len(allretained)})
initial=read(BASE/'source-before.json')['files']
final=read(BASE/'source-final.json')['files']
check('all 1790 final logical source bytes bound',len(final)==1790 and all(sha(SOURCE/x['path'])==x['sha256'] and (SOURCE/x['path']).stat().st_size==x['bytes'] for x in final),'Ignored generated files and cloned Cargo cache are outside the logical source manifest.')
check('unchanged logical path inventory', [x['path'] for x in initial]==[x['path'] for x in final] and len({x['path'] for x in final})==1790,'No logical path added or deleted.')
changed=[b['path'] for a,b in zip(initial,final) if a!=b]
expected=['apps/desktop/src-tauri/src/service/'+x for x in ['mod.rs','platform.rs','protocol.rs','supervisor.rs']]
check('only four exact logical files changed',changed==expected,changed)
git_oids={}
for row in git('ls-tree','-rz','--full-tree',HEAD).split(b'\0'):
    if row:
        metadata,path=row.split(b'\t',1)
        git_oids[path.decode()]=metadata.split()[2].decode()
check('upfront source equals actual candidate Git blobs',set(git_oids)=={x['path'] for x in initial} and all(hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==git_oids[x['path']] and hashlib.sha256(data).hexdigest()==x['sha256'] for x in initial for data in [(ROOT/x['path']).read_bytes()]),{'base_commit':HEAD})
patch=''
oldnew={}
for path in expected:
    old=git('show',HEAD+':'+path).decode()
    new=(SOURCE/path).read_text()
    oldnew[path]=(old,new)
    keep(SOURCE/path)
    patch+=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path))
check('patch exact against Git source',patch==(BASE/'windows-clippy-correction.patch').read_text(),'The patch was independently reconstructed from immutable base Git and final bytes.')
old,new=oldnew[expected[0]]
check('mod reexports narrow to actual consumers',new==old.replace('pub use protocol::{Bootstrap, ReadyFrame, ServiceIdentity};','#[cfg(any(unix, test))]\npub use protocol::Bootstrap;\n#[cfg(unix)]\npub use protocol::ReadyFrame;\npub use protocol::ServiceIdentity;'),'Only import/reexport availability changes; unconditional common protocol type definitions remain.')
old,new=oldnew[expected[1]]
check('platform imports narrow to actual consumers',new==old.replace('use super::{\n    Bootstrap, Clock, OwnedProcess, ReadyFrame, RuntimeAdapter, ServiceIdentity, SpawnPermit,\n    SupervisorError,\n};','#[cfg(any(unix, test))]\nuse super::Bootstrap;\n#[cfg(unix)]\nuse super::ReadyFrame;\nuse super::{Clock, OwnedProcess, RuntimeAdapter, ServiceIdentity, SpawnPermit, SupervisorError};'),'No runtime, child ownership, cleanup, platform stub or Unix adapter code changes.')
old,new=oldnew[expected[2]]
wanted=old.replace('use std::io::{Read, Write};','#[cfg(any(unix, test))]\nuse std::io::{Read, Write};').replace('pub const MAX_FRAME_BYTES','#[cfg(any(unix, test))]\npub const MAX_FRAME_BYTES').replace('    pub fn write_to(','    #[cfg(any(unix, test))]\n    pub fn write_to(').replace('    pub fn read_from(','    #[cfg(any(unix, test))]\n    pub fn read_from(')
check('protocol bodies bounds schemas and contract byte exact',new==wanted,'Only four cfg annotations added; all serializers/readers/limits/type definitions/validation remain exact.')
old,new=oldnew[expected[3]]
annotation='    #[cfg_attr(\n        all(not(unix), not(test)),\n        expect(\n            dead_code,\n            reason = "non-Unix cleanup producer is unavailable until M03-W07"\n        )\n    )]\n'
check('variant-only non-Unix production lint expectation',new==old.replace('    CleanupPending,',annotation+'    CleanupPending,'),'The typed variant and every method/transition remain unconditional and byte exact. No module/crate warning suppression.')
check('all other 1786 logical source inputs exact',sum(a==b for a,b in zip(initial,final))==1786,'Includes all locks, registry, inventory, runtime descriptors, auth/service schemas, tauri lifecycle and build policy.')

preservation=read(BASE/'preservation.json')
for row in preservation['test_regions']:
    old,new=oldnew[row['path']]
    marker=row['marker']
    a=old[old.index(marker):].encode();b=new[new.index(marker):].encode()
    check(row['path']+' exact tests through EOF',a==b and hashlib.sha256(a).hexdigest()==row['sha256'] and len(a)==row['bytes'] and a.count(b'#[test]')==row['test_markers'] and len(re.findall(rb'\bassert(?:_eq|_ne)?!',a))==row['assertion_macros'],row)
original=(BASE/'commands/original-mac-test-list/stdout.log').read_text()
corrected=(BASE/'commands/corrected-test-list/stdout.log').read_text()
ids=lambda text:sorted(re.findall(r'^(.+): test$',text,re.M))
check('all 77 old native test IDs preserved',len(ids(original))==77 and ids(original)==ids(corrected)==preservation['original_ids'],'IDs from both actual compiled test lists, not source-marker counting.')
commands=read(BASE/'command-index.json')
check('ten actual commands retained',len(commands)==10,'Original list, final list, fmt, four Clippy feature modes and three native test executions.')
for commanddir in sorted((BASE/'commands').iterdir()):
    name=commanddir.name
    inv=read(commanddir/'invocation.json')
    res=read(commanddir/'result.json')
    source_before=read(commanddir/'source-before.json')
    source_after=read(commanddir/'source-after.json')
    expected_source=initial if name=='original-mac-test-list' else final
    check(name+' before/after/source binding',source_before==source_after==expected_source and sha(commanddir/'source-before.json')==inv['upfront_source_manifest_sha256'] and inv['wrapper_sha256']==sha(BASE/'run-command.py'),'All 1790 logical source files are bound before and after this command.')
    check(name+' raw result and execution binding',all(res[k]==v for k,v in inv.items()) and res['exit_code']==0 and res['source_unchanged'] and res['root_matches_upfront'] and res['root_unchanged_during_command'] and res['started_utc']<=res['ended_utc'] and res['elapsed_seconds']>=0 and all(sha(commanddir/(stream+'.log'))==res[stream]['sha256'] and (commanddir/(stream+'.log')).stat().st_size==res[stream]['bytes'] for stream in ['stdout','stderr']),res['argv'])
    if name.startswith('corrected-clippy'):
        check(name+' strict lint policy',res['argv'][-3:]==['--','-D','warnings'] and '--all-targets' in res['argv'] and '--locked' in res['argv'] and '--offline' in res['argv'] and res['argv'][0:2]==['cargo','clippy'],'Actual local/macOS compile evidence only; no Windows GREEN.')
    if name.startswith('corrected-test-') and name!='corrected-test-list':
        text=(commanddir/'stdout.log').read_text()
        executed=sorted(re.findall(r'^test (.+) \.\.\. ok$',text,re.M))
        check(name+' all actual test results',executed==preservation['original_ids'] and '77 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in text,'77 actual local test bodies PASS; no list-only test credit.')
for row in preservation['produced_binaries']:
    actual=keep(BASE/row['retained'],copy=False)
    check(row['retained']+' produced binary binding',actual['sha256']==row['sha256'] and actual['bytes']==row['bytes'],'Explicitly copied after execution, not an upfront actor receipt.')

ci=BASE/'upfront'
windows=(ci/'windows-complete-raw.txt').read_text()
check('actual Windows warning causes retained',all(x in windows for x in ['unused imports: `Bootstrap` and `ReadyFrame`','unused import: `ReadyFrame`','constant `MAX_FRAME_BYTES` is never used','method `write_to` is never used','associated function `read_from` is never used','variant `CleanupPending` is never constructed','1648 passed']),'Actual Windows CI RED; local checks do not replace a fresh Windows strict compiler run.')
w07=Path('/tmp/japp-m03-w07-win32-ffi-correction/source/src/service')
for name in ['mod.rs','protocol.rs','windows_native.rs','windows_policy.rs']:
    keep(w07/name)
check('future W07 consumer conflict explicitly disclosed','use super::{Bootstrap, OwnedProcess, ReadyFrame, SpawnPermit, SupervisorError};' in (w07/'windows_native.rs').read_text() and 'ReadyFrame::read_from' in (w07/'windows_policy.rs').read_text() and 'Err(SupervisorError::CleanupPending)' in (w07/'windows_policy.rs').read_text() and 'M03-W07 integration must restore' in (BASE/'HANDOFF.md').read_text(),'Before W07 integration restore/rebase actual Windows imports, reader availability and remove now-unfulfilled variant expectation. No blind full-file merge.')
after={'head':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'status':git('status','--porcelain=v1').decode()}
check('review root neutrality',before==after and before['head']==HEAD and before['status']=='',after)
(OUT/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
(OUT/'input-retention.json').write_text(json.dumps({'scope':'READ_ONLY_INDEPENDENT_SOURCE_AND_RECEIPT_REVIEW; large original source and produced binaries hash-bound in place','records':list(inputs.values())},indent=2)+'\n')
print(json.dumps({'checks':len(checks),'clear':sum(x['pass'] for x in checks),'failed':[x['name'] for x in checks if not x['pass']],'input_bindings':len(inputs)}))
