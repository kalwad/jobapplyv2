from __future__ import annotations
import difflib
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

BASE = Path(__file__).resolve().parent
SOURCE = BASE / 'source'
ROOT = Path('/Users/tanishkalwad/jobapplyv2')

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def put(name: str, data: object) -> None:
    (BASE / name).write_text(json.dumps(data, indent=2) + '\n')

def main() -> None:
    initial = json.loads((BASE / 'source-before.json').read_text())['files']
    after = [{'path': row['path'], 'bytes': len(data), 'sha256': sha(data)}
             for row in initial for data in [(SOURCE / row['path']).read_bytes()]]
    changed = [new['path'] for old, new in zip(initial, after, strict=True) if old != new]
    expected = ['apps/desktop/src-tauri/src/service/' + name for name in ['mod.rs', 'platform.rs', 'protocol.rs', 'supervisor.rs']]
    assert changed == expected, changed
    put('source-final.json', {'files': after})
    patch = ''.join(''.join(difflib.unified_diff((BASE / 'upfront' / path).read_text().splitlines(keepends=True),
                                               (SOURCE / path).read_text().splitlines(keepends=True),
                                               fromfile='a/' + path, tofile='b/' + path)) for path in changed)
    (BASE / 'windows-clippy-correction.patch').write_text(patch)
    put('source-delta.json', {'base_head': 'cac56a00abdd7c86e148b10fd26ea317d62b4361',
        'base_tree': '7d7afc0a24a8370fda79cb26d46e945bb056842d', 'changed_files': changed,
        'unchanged_files': len(initial) - len(changed), 'new_files': [], 'deleted_files': [],
        'patch_sha256': sha(patch.encode())})
    original_list = (BASE / 'commands/original-mac-test-list/stdout.log').read_text()
    final_list = (BASE / 'commands/corrected-test-list/stdout.log').read_text()
    before_ids = sorted(re.findall(r'^(.+): test$', original_list, re.M))
    after_ids = sorted(re.findall(r'^(.+): test$', final_list, re.M))
    assert before_ids == after_ids and len(before_ids) == 77
    preserved_regions = []
    for file in ['platform.rs', 'protocol.rs', 'supervisor.rs']:
        path = 'apps/desktop/src-tauri/src/service/' + file
        old = (BASE / 'upfront' / path).read_bytes()
        new = (SOURCE / path).read_bytes()
        marker = b'    #[cfg(test)]\n    mod tests' if file == 'platform.rs' else b'#[cfg(test)]\nmod tests'
        old_region = old[old.index(marker):]
        new_region = new[new.index(marker):]
        assert old_region == new_region
        preserved_regions.append({'path': path, 'marker': marker.decode(), 'bytes': len(old_region), 'sha256': sha(old_region),
                                  'test_markers': old_region.count(b'#[test]'), 'assertion_macros': len(re.findall(rb'\bassert(?:_eq|_ne)?!', old_region)), 'byte_exact': True})
    tests = []
    produced_binaries = []
    (BASE / 'produced-test-binaries').mkdir(exist_ok=False)
    for mode in ['default', 'app-feature', 'dependency-feature']:
        name = 'corrected-test-' + mode
        result = json.loads((BASE / 'commands' / name / 'result.json').read_text())
        stdout = (BASE / 'commands' / name / 'stdout.log').read_text()
        executed = sorted(re.findall(r'^test (.+) \.\.\. ok$', stdout, re.M))
        assert result['exit_code'] == 0 and executed == before_ids
        assert '77 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in stdout
        stderr = (BASE / 'commands' / name / 'stderr.log').read_text()
        binaries = re.findall(r'^\s*Running unittests .+ \((.+)\)$', stderr, re.M)
        for index, path in enumerate(binaries):
            binary = Path(path)
            destination = BASE / 'produced-test-binaries' / (mode + '-' + str(index))
            shutil.copy2(binary, destination)
            produced_binaries.append({'command': name, 'cargo_output_path': str(binary), 'retained': str(destination.relative_to(BASE)),
                                      'bytes': destination.stat().st_size, 'sha256': sha(destination.read_bytes()),
                                      'scope': 'produced test executable copied after execution, not a pre-execution actor receipt'})
        tests.append({'mode': mode, 'executed_ids': executed, 'pass': 77, 'fail': 0, 'ignored': 0, 'filtered': 0})
    put('preservation.json', {'all_77_old_ids_exact': True, 'all_77_old_bodies_and_assertions_exact': True,
        'basis': 'All Rust files except four prefix-only edits are byte exact; every changed source containing tests has a byte-exact region starting at its first test module and extending to EOF. This includes all five protocol bodies. Test ID equality and each executed result are independently recorded.',
        'test_regions': preserved_regions, 'original_ids': before_ids, 'test_runs': tests, 'produced_binaries': produced_binaries})
    upfront_root = json.loads((BASE / 'root-before.json').read_text())
    root_after = [{'path': row['path'], 'bytes': len(data), 'sha256': sha(data)}
                  for row in initial for data in [(ROOT / row['path']).read_bytes()]]
    assert root_after == upfront_root['files']
    put('root-final-neutrality.json', {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
        'status': subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=ROOT).decode(),
        'all_1790_files_match_upfront': True, 'files': root_after})
    shutil.copy2('/tmp/japp-m03-w03-windows-clippy-author.py', BASE / 'preparation-wrapper.py')
    commands = [json.loads(path.read_text()) for path in sorted((BASE / 'commands').glob('*/result.json'))]
    assert len(commands) == 10 and all(command['exit_code'] == 0 and command['source_unchanged'] and command['root_matches_upfront'] for command in commands)
    put('command-index.json', commands)
    print(json.dumps({'source_sha256': sha((BASE / 'source-final.json').read_bytes()), 'patch_sha256': sha(patch.encode()),
                      'changed': changed, 'commands': len(commands), 'old_test_ids': len(before_ids)}))

if __name__ == '__main__':
    main()
