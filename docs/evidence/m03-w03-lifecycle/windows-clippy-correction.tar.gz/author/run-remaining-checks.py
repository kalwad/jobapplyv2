from pathlib import Path
import subprocess
import sys

base = Path(__file__).resolve().parent
manifest = 'apps/desktop/src-tauri/Cargo.toml'
checks = [
    ('corrected-clippy-app-feature', ['cargo', 'clippy', '--locked', '--offline', '--manifest-path', manifest, '--all-targets', '--features', 'custom-protocol', '--', '-D', 'warnings']),
    ('corrected-clippy-dependency-feature', ['cargo', 'clippy', '--locked', '--offline', '--manifest-path', manifest, '--all-targets', '--features', 'tauri/custom-protocol', '--', '-D', 'warnings']),
    ('corrected-clippy-all-features', ['cargo', 'clippy', '--locked', '--offline', '--manifest-path', manifest, '--all-targets', '--all-features', '--', '-D', 'warnings']),
    ('corrected-test-default', ['cargo', 'test', '--locked', '--offline', '--manifest-path', manifest]),
    ('corrected-test-app-feature', ['cargo', 'test', '--locked', '--offline', '--manifest-path', manifest, '--features', 'custom-protocol']),
    ('corrected-test-dependency-feature', ['cargo', 'test', '--locked', '--offline', '--manifest-path', manifest, '--features', 'tauri/custom-protocol']),
    ('corrected-test-list', ['cargo', 'test', '--locked', '--offline', '--manifest-path', manifest, '--', '--list']),
]
for name, argv in checks:
    result = subprocess.run([sys.executable, str(base / 'run-command.py'), name, *argv], cwd=base / 'source')
    if result.returncode:
        raise SystemExit(result.returncode)
