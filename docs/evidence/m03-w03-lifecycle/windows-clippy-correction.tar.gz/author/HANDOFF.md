# M03-W03 Windows strict-Clippy correction proposal

This is an isolated source proposal. The root repository remains at `cac56a00abdd7c86e148b10fd26ea317d62b4361`, tree `7d7afc0a24a8370fda79cb26d46e945bb056842d`, with all 1,790 tracked inputs unchanged and a clean status. No native app, service, socket, browser, Windows probe, SDK installation, hosted job, or milestone acceptance was executed by this proposal.

## Actual failure and correction

Native Windows CI run [39164520190](https://github.com/kalwad/jobapplyv2/actions/runs/39164520190) checked out merge commit `ab2d8a5be6efc6c7bcc822b28add09d17743edae`, whose tree is exactly the root tree above. Its raw Windows log records 1,648 Python tests passing, then strict desktop Clippy failing: unused Bootstrap/ReadyFrame imports, unused stream bound/write/read helpers, and CleanupPending without a production Windows constructor. The retained `upfront/logs.zip`, raw Windows text, run/jobs JSON and actual checkout record preserve this actual Windows RED. It is not a startup or service failure, and no global warning policy is relaxed.

The four-file patch:

- Conditions the existing Bootstrap import/reexport on `any(unix, test)` and ReadyFrame import/reexport on `unix`, matching their current platform adapter consumers. Shared core imports continue to use the unconditional private protocol types directly.
- Conditions only the stream I/O imports, MAX_FRAME_BYTES, Bootstrap.write_to and ReadyFrame.read_from on `any(unix, test)`. Those stream methods have no production Windows consumer until the Windows backend is implemented. All method bodies, constructors, schema validation, bounds and identity checks remain byte exact.
- Keeps CleanupPending unconditional in the typed common contract and adds a variant-only `cfg_attr(all(not(unix), not(test)), expect(dead_code, reason = ...))`. It does not allow or suppress arbitrary warnings. The expectation must become unfulfilled when a non-Unix producer is added; remove it when integrating that producer.

M03-W07 integration must restore the stream helpers/bound/imports for the actual Windows consumer, or replace them with the reviewed bounded Windows transport implementation that consumes them, and remove the variant-only expectation once CleanupPending has a production Windows constructor. Do not copy this temporary condition blindly into a completed Windows backend.

## Exact source and patch

`source-final.json` SHA-256: `167fa2b3562d71875c98085827c2bed5be3352c3c07c62af8608902900213c7b`.

`windows-clippy-correction.patch` SHA-256: `b7d49f4b25da9ca601a599b82f27c118a7723b0d4be190013269ff82978ba82a`.

The patch changes only `apps/desktop/src-tauri/src/service/{mod,platform,protocol,supervisor}.rs`. The other 1,786 logical source files, lockfiles, test bodies and assertions are unchanged. No source file is added or deleted. Apply only the patch or those four manifest-bound files. The full `source` directory contains ignored generated frontend/Tauri files and is not an integration patch.

## Actual validation

All 10 recorded commands exited zero with all logical source hashes unchanged before/after, and root inputs matching the upfront snapshot:

- Original and corrected macOS native test inventories: exactly the same 77 test IDs.
- `cargo fmt --manifest-path apps/desktop/src-tauri/Cargo.toml --check`.
- Strict `cargo clippy --locked --offline --manifest-path apps/desktop/src-tauri/Cargo.toml --all-targets` with `-D warnings`, in default, `--features custom-protocol`, `--features tauri/custom-protocol`, and CI-equivalent `--all-features` modes.
- `cargo test --locked --offline --manifest-path apps/desktop/src-tauri/Cargo.toml` in default, app custom-protocol and dependency custom-protocol modes: each 77 passed, zero failed/ignored/filtered.

The three changed files containing tests have byte-exact regions starting at their first test module and extending through EOF. Every other Rust file is byte exact. This preserves all five protocol test bodies, all old native bodies, and their assertions. `preservation.json` records these regions and each executed test ID. The produced test binaries are copied and hashed after execution; these copies are not described as pre-execution actor receipts.

Every command retains exact argv, cwd, PATH/CARGO_TARGET_DIR overrides, upfront and post-command 1,790-file manifests, UTC and monotonic timings, raw stdout/stderr hashes, exit status and neutrality results. Node 24.18.0 and Cargo/Rust toolchain 1.97.1 were selected. The caller environment was inherited except for the two recorded overrides; no claim of a fully archived caller environment is made. Cargo used only the isolated APFS copy-on-write target cache under this directory, and `--locked --offline` prevented dependency resolution or installation. The root frontend assets were copied and separately hashed; the isolated native staging directory contains its tracked `.gitignore` and no manifest/runtime payload. Thus the compiler sees the honest unavailable-runtime descriptor for this isolated source check, not a new packaged runtime.

The initial freeze observer incorrectly assumed the native test module name was `tests`; shipping source calls it `bounded_reader_tests`. Its source and failure transcription are retained, and `freeze-v2.py` corrects only that observation marker. No source correction, test body, compiled result or patch changed. This is not a product RED.

## Scope and next steps

This is macOS compiler and unit evidence for a source correction prompted by actual Windows CI. It is **not Windows GREEN**, Windows runtime/package proof, or M03-W03 completion. Independent review by a different agent, root adoption/validation and a fresh actual Windows strict-Clippy/CI result remain required. Existing native lifecycle evidence must remain bound to its original source candidate; the root owns the decision on what additional validation the four compiler-only changes require.

`retention.json` exhaustively binds the retained inputs, source files, generated frontend input copies, commands, raw evidence, test binaries and handoff. It excludes the disposable 4.6 GiB cloned Cargo cache and generated Tauri schema files; those are not presented as retained source inputs or independent evidence. Do not archive the 260 MiB historic logical source archive into a single GitHub blob; use the Git commit plus this delta and hash-bound evidence when making the durable packet.
