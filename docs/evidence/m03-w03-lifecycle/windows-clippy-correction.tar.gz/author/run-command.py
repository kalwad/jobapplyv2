from __future__ import annotations
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
SOURCE = BASE / 'source'
ROOT = Path('/Users/tanishkalwad/jobapplyv2')
PATHS = [row['path'] for row in json.loads((BASE / 'root-before.json').read_text())['files']]

def manifest(base: Path) -> list[dict[str, object]]:
    return [{'path': path, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            for path in PATHS for data in [(base / path).read_bytes()]]

def main() -> int:
    name, *argv = sys.argv[1:]
    output = BASE / 'commands' / name
    output.mkdir(parents=True, exist_ok=False)
    before = manifest(SOURCE)
    root_before = manifest(ROOT)
    (output / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
    env = os.environ.copy()
    env['PATH'] = '/opt/homebrew/opt/node@24/bin:' + env['PATH']
    env['CARGO_TARGET_DIR'] = str(BASE / 'cargo-target')
    receipt = {'argv': argv, 'cwd': str(SOURCE), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'environment_overrides': {key: env[key] for key in ['PATH', 'CARGO_TARGET_DIR']},
               'wrapper_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               'upfront_source_manifest_sha256': hashlib.sha256((output / 'source-before.json').read_bytes()).hexdigest()}
    (output / 'invocation.json').write_text(json.dumps(receipt, indent=2) + '\n')
    started = time.monotonic()
    with (output / 'stdout.log').open('wb') as stdout, (output / 'stderr.log').open('wb') as stderr:
        result = subprocess.run(argv, cwd=SOURCE, env=env, stdout=stdout, stderr=stderr)
    after = manifest(SOURCE)
    root_after = manifest(ROOT)
    (output / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
    receipt.update({'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'elapsed_seconds': time.monotonic() - started,
                    'exit_code': result.returncode, 'source_unchanged': before == after,
                    'root_unchanged_during_command': root_before == root_after,
                    'root_matches_upfront': root_after == json.loads((BASE / 'root-before.json').read_text())['files'],
                    'stdout': {'sha256': hashlib.sha256((output / 'stdout.log').read_bytes()).hexdigest(), 'bytes': (output / 'stdout.log').stat().st_size},
                    'stderr': {'sha256': hashlib.sha256((output / 'stderr.log').read_bytes()).hexdigest(), 'bytes': (output / 'stderr.log').stat().st_size}})
    (output / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'command': name, 'exit_code': result.returncode, 'elapsed_seconds': receipt['elapsed_seconds'], 'source_unchanged': receipt['source_unchanged'], 'root_matches_upfront': receipt['root_matches_upfront']}), flush=True)
    return result.returncode if before == after and root_before == root_after else 99

if __name__ == '__main__':
    raise SystemExit(main())
