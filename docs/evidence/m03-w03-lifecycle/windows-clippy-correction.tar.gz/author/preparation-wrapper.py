from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
OUT = Path('/tmp/japp-m03-w03-windows-clippy-correction-20261019')
SOURCE = OUT / 'source'
FILES = [
    'apps/desktop/src-tauri/src/service/mod.rs',
    'apps/desktop/src-tauri/src/service/platform.rs',
    'apps/desktop/src-tauri/src/service/protocol.rs',
    'apps/desktop/src-tauri/src/service/supervisor.rs',
]

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2) + '\n')

def tracked() -> list[str]:
    return subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().rstrip('\0').split('\0')

def manifest(base: Path, paths: list[str]) -> list[dict[str, object]]:
    return [{'path': path, 'bytes': len(data), 'sha256': digest(data)}
            for path in paths for data in [(base / path).read_bytes()]]

def main() -> None:
    OUT.mkdir(exist_ok=False)
    (OUT / 'upfront').mkdir()
    SOURCE.mkdir()
    paths = tracked()
    before = manifest(ROOT, paths)
    write_json(OUT / 'root-before.json', {
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
        'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT).decode().strip(),
        'status': subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=ROOT).decode(),
        'files': before,
    })
    for item in before:
        source = ROOT / str(item['path'])
        target = SOURCE / str(item['path'])
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        assert digest(target.read_bytes()) == item['sha256']
    for name in FILES:
        target = OUT / 'upfront' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / name, target)
    raw = Path('/tmp/japp-m03-w03-hosted-ci-cac56-20261018')
    for name in ['windows-complete-raw.txt', 'logs.zip', 'run.json', 'jobs.json', 'actual-checkout-commit.json', 'zip-members.json']:
        shutil.copy2(raw / name, OUT / 'upfront' / name)
    assert before == manifest(ROOT, paths)
    write_json(OUT / 'source-before.json', {'files': manifest(SOURCE, paths)})
    front = ROOT / 'apps/desktop/dist'
    shutil.copytree(front, SOURCE / 'apps/desktop/dist')
    front_paths = sorted(str(path.relative_to(front)) for path in front.rglob('*') if path.is_file())
    write_json(OUT / 'frontend-inputs.json', {'origin': str(front), 'files': manifest(front, front_paths)})
    copy_argv = ['/bin/cp', '-cR', str(ROOT / 'apps/desktop/src-tauri/target'), str(OUT / 'cargo-target')]
    started = time.monotonic()
    copied = subprocess.run(copy_argv, capture_output=True)
    (OUT / 'cache-clone.stdout').write_bytes(copied.stdout)
    (OUT / 'cache-clone.stderr').write_bytes(copied.stderr)
    write_json(OUT / 'cache-clone.json', {'argv': copy_argv, 'cwd': str(ROOT), 'exit_code': copied.returncode, 'elapsed_seconds': time.monotonic() - started, 'scope': 'isolated APFS copy-on-write Cargo cache; no target output in the root is written'})
    copied.check_returncode()
    write_json(OUT / 'root-after-preparation.json', {'files': manifest(ROOT, paths), 'unchanged': before == manifest(ROOT, paths)})
    print(json.dumps({'output': str(OUT), 'source_files': len(paths), 'root_unchanged': before == manifest(ROOT, paths)}), flush=True)

if __name__ == '__main__':
    main()
