"""Read-only durable-packet binding audit; no product or proof execution."""
from pathlib import Path, PurePosixPath
import collections
import hashlib
import json
import shutil
import stat
import subprocess
import tarfile

BASE=Path('/Users/tanishkalwad/jobapplyv2-evidence/m03-w03-cac56-native-20261019')
PACK=Path('/tmp/japp-m03-w03-native-retained-20261019')
OUT=Path(__file__).parent
ROOT=Path('/Users/tanishkalwad/jobapplyv2')
NATIVE=Path('/tmp/japp-m03-w03-independent-native-actual-review-20261019')
SOURCE_SHA='d6c7fc9d1d58d10a942c21693a221d017491b83823b8d7ce359d394a51dc19b4'
checks=[]
inputs={}

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        while data:=f.read(1048576):h.update(data)
    return h.hexdigest()

def keep(p,copy=False):
    p=Path(p); row={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
    if copy:
        target=OUT/'inputs'/str(p).lstrip('/')
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(p,target)
        assert sha(target)==row['sha256']
        row['copy']=str(target.relative_to(OUT))
    inputs[str(p)]=row
    return row

def read(p):keep(p,True);return json.loads(Path(p).read_text())
def check(name,condition,detail):checks.append({'name':name,'pass':bool(condition),'detail':detail})
def regular_paths(p):
    return sorted(x.relative_to(p).as_posix() for x in p.rglob('*') if x.is_file() and '__pycache__' not in x.relative_to(p).parts)

selection=read(BASE/'selection.json')
retention=read(BASE/'retention-manifest.json')
archive_manifest=read(PACK/'archive-manifest.json')
check('exact frozen retention identity',sha(BASE/'retention-manifest.json')=='6beddb56e8c883df5ea1061f2a7debe3039a4c7d27924c3816c048018667d54f','Supplied final native selected-packet identity.')
check('actual candidate identity and scope',selection['source_commit']=='cac56a00abdd7c86e148b10fd26ea317d62b4361' and selection['source_tree']=='7d7afc0a24a8370fda79cb26d46e945bb056842d' and selection['scope']=='ACTUAL_CAC56_NATIVE_AND_PRIOR_LOCAL_FULL_DATA; NOT_W03_ACCEPTANCE',selection['scope'])
check('exact full local file inventory',set(regular_paths(BASE))==set(retention)|{'retention-manifest.json'}, {'declared':len(retention),'actual':len(regular_paths(BASE))})
binding=[]
for path,row in retention.items():
    p=BASE/path
    rel=PurePosixPath(path)
    assert not rel.is_absolute() and '..' not in rel.parts
    actual=keep(p)
    binding.append(not p.is_symlink() and actual['sha256']==row['sha256'] and actual['bytes']==row['bytes'])
check('every local durable byte/hash/size binding',all(binding),{'files':len(binding)})
logical=set();valid=[];bycategory=collections.defaultdict(list)
for row in selection['records']:
    key=(row['category'],row['relative_path'])
    logical.add(key);bycategory[row['category']].append(row)
    stored=retention[row['stored_path']]
    original=keep(row['original_path'])
    valid.append(original['sha256']==row['sha256']==stored['sha256'] and original['bytes']==row['bytes']==stored['bytes'] and stat.S_ISREG(Path(row['original_path']).lstat().st_mode) and not Path(row['original_path']).is_symlink())
check('all 907 logical references bind exact original and durable bytes',len(logical)==len(selection['records'])==selection['logical_records']==907 and all(valid),{'logical_records':len(logical)})
unique={x['stored_path']:x for x in selection['records']}
check('deduplicated storage counts and content addresses',len(unique)==selection['unique_stored_files']==872 and sum(x['bytes'] for x in unique.values())==selection['unique_stored_bytes'] and all(not p.startswith('blobs/') or p=='blobs/'+x['sha256'] for p,x in unique.items()),{'files':len(unique),'bytes':sum(x['bytes'] for x in unique.values())})
cases={
 'canonical-close':Path('/tmp/japp-m03-w03-canonical-close-v3-20261018'),
 'canonical-quit':Path('/tmp/japp-m03-w03-canonical-quit-v3-20261018'),
 'canonical-forced':Path('/tmp/japp-m03-w03-canonical-forced-v3-20261018'),
 'contained-close':Path('/tmp/japp-m03-w03-contained-v3-native-20261019'),
 'escaped-retry':Path('/tmp/japp-m03-w03-escaped-v3-native-20261019'),
}
for name,original in cases.items():
    rows=bycategory['cases/'+name]
    check(name+' complete raw case selection',[r['relative_path'] for r in rows]==regular_paths(original),'All non-cache files, including raw observer output/events, exact upfront source/artifact copies and native action/PNG/AX evidence, selected.')
    results=[r for r in rows if r['relative_path']=='proof/case-result.json']
    outcome=json.loads((BASE/results[0]['stored_path']).read_text())
    check(name+' actual result remains unaltered',outcome['pass'] is True and outcome['spectator_unchanged'] is True,'The packet preserves the original root execution; collection is not a new execution.')
for name in ['canonical-close','contained-close','escaped-retry']:
    original=Path(selection['actual_apps'][name])
    rows=bycategory['actual-apps/'+name]
    check(name+' full 42-file actual application retained',[r['relative_path'] for r in rows]==regular_paths(original) and len(rows)==42,'Large executable blobs are mapped by selection.json; the directory need not be directly runnable.')
for label,original,category in [
 ('canonical',Path('/tmp/japp-m03-w03-root-app-build-v3-20261018'),'canonical-build'),
 ('native independent review',NATIVE,'native-independent-review'),
 ('hosted CI',Path('/tmp/japp-m03-w03-hosted-ci-cac56-20261018'),'hosted-ci-cac56'),
 ('local full pack',Path('/tmp/japp-m03-w03-full-v3-retained-20261018'),'local-full-v3-pack'),
 ('full independent review',Path('/tmp/japp-m03-w03-independent-root-integration-review-20261018/full-v3-data-review'),'full-v3-independent-review'),
]:
    rows=bycategory[category]
    check(label+' complete stated tree selection',[r['relative_path'] for r in rows]==regular_paths(original),{'files':len(rows)})
for label,original in [('contained',Path('/tmp/japp-m03-w03-root-fixture-apps-v3-20261018/contained')),('escaped',Path('/tmp/japp-m03-w03-root-fixture-apps-v3-serial-20261018/escaped'))]:
    for suffix,base,recursive in [('top',original,False),('app-upfront',original/'app-upfront',True),('fixture-input',original/'fixture-input',True),('native-build-top',original/'native-build',False)]:
        category='fixture-builds/'+label+'/'+suffix
        desired=regular_paths(base) if recursive else sorted(p.name for p in base.iterdir() if p.is_file())
        check(category+' exact stated selection',[r['relative_path'] for r in bycategory[category]]==desired,{'files':len(desired)})
exclusions=selection['excluded_transient_files']
check('only transient import cache explicitly excluded',len(exclusions)==10 and all('__pycache__' in Path(x['original_path']).parts and 'Python import cache' in x['reason'] for x in exclusions),'Authoritative retained helper Python source remains selected.')
native_findings=read(NATIVE/'findings.json')
check('sealed earlier native review remains immutable',sha(NATIVE/'findings.json')=='b48a1b5efa8a0dd1ba7c059a0993d92e66625e2b48e61084cb7d2951890511d4' and sha(NATIVE/'REVIEW.md')=='00f6cf28f9fa5392d5d41af735ff476693721f256c7522b233329ce1d168a037' and sha(NATIVE/'retention-manifest.json')=='3d76789e3f4e222bac0a2943266ead6ef7585b7faaf5f413d081721cb0af526e' and native_findings['whole_w03_accepted'] is False,'This is a new additive packet-binding closure, not an edit to the native-data decision.')
before=read(BASE/'tracked-before.json');after=read(BASE/'tracked-after.json')
git_tree={}
for raw in subprocess.check_output(['git','-C',str(ROOT),'ls-tree','-rz','--full-tree','cac56a00abdd7c86e148b10fd26ea317d62b4361']).split(b'\0'):
    if raw:
        m,p=raw.split(b'\t',1);git_tree[p.decode()]=m.split()[2].decode()
check('collector snapshots bind actual immutable candidate tree',before==after and before['head']==selection['source_commit'] and before['tree']==selection['source_tree'] and before['status']=='' and len(before['files'])==1790 and {p:v['git_blob'] for p,v in before['files'].items()}==git_tree,'Collection snapshots, not current moving checkout state, prove the cac56 source binding.')
archive=PACK/'native-cac56-selected.tar.gz'
keep(archive)
check('exact remote selected archive identity',sha(archive)==archive_manifest['sha256']=='f5f6d9564e81f9167cb26bec43cc2071d50b53f5e6e58bcb0693ddb6bca68683' and archive.stat().st_size==archive_manifest['bytes']==66751841,archive.stat().st_size)
members={};modebits={}
with tarfile.open(archive,'r:gz') as tf:
    for member in tf:
        p=PurePosixPath(member.name)
        assert member.isfile() and not p.is_absolute() and '..' not in p.parts and member.name not in members
        f=tf.extractfile(member);assert f is not None
        h=hashlib.sha256();size=0
        while data:=f.read(1048576):h.update(data);size+=len(data)
        members[member.name]={'sha256':h.hexdigest(),'bytes':size}
        modebits[member.name]=member.mode
        assert size==member.size
check('879 safe regular archive members verify independently',members==archive_manifest['members'] and len(members)==879,'No extraction, links, duplicate names, absolute paths, traversal or special members.')
omitted='blobs/'+SOURCE_SHA
expected=dict(retention)
expected['retention-manifest.json']={'sha256':sha(BASE/'retention-manifest.json'),'bytes':(BASE/'retention-manifest.json').stat().st_size}
check('archive matches all selected local bytes except one declared blob',set(members)==set(expected)-{omitted} and all(value==expected[path] for path,value in members.items()) and archive_manifest['omitted_local_only']=={omitted:expected[omitted]} and expected[omitted]['bytes']==273090560,'Only the source-archive blob is locally retained and intentionally absent from the review tar.')
source_refs=[x for x in selection['records'] if x['sha256']==SOURCE_SHA]
check('all duplicate source archive references remain explicit',len(source_refs)>=5 and all(x['stored_path']==omitted and x['bytes']==273090560 for x in source_refs),'Every source archive logical reference resolves to the one exact local durable blob.')
sourcehashes={}
sourceoids={}
with tarfile.open(BASE/omitted) as tf:
    for member in tf:
        if member.isdir():continue
        p=PurePosixPath(member.name)
        assert member.isfile() and not p.is_absolute() and '..' not in p.parts and member.name not in sourcehashes
        data=tf.extractfile(member).read()
        sourcehashes[member.name]=hashlib.sha256(data).hexdigest()
        sourceoids[member.name]=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
check('omitted remote source archive fully retained and equals Git locally',sourceoids==git_tree and len(sourcehashes)==1790 and sourcehashes==json.loads((NATIVE/'source-archive-file-hashes.json').read_text()),'No unavailable source bytes or reconstructed archive claim; complete local bytes independently inspected.')
keep(BASE/'README.md',True);keep(BASE/'collector.py',True)
check('selection and omissions are honestly disclosed','post-execution' in (BASE/'README.md').read_text() and len(selection['omissions'])==3 and 'omits only' in selection['omissions'][2] and 'NOT_W03_ACCEPTANCE' in selection['scope'],'No Windows PASS, whole-package acceptance, new execution or complete toolchain/cache archival claim.')
(OUT/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
(OUT/'input-retention.json').write_text(json.dumps({'scope':'READ_ONLY_PACKET_BINDING; original packet/archives hash-bound in place and small packet manifests copied','records':list(inputs.values())},indent=2)+'\n')
(OUT/'archive-members-observed.json').write_text(json.dumps(members,indent=2)+'\n')
(OUT/'selection-category-counts.json').write_text(json.dumps({k:len(v) for k,v in sorted(bycategory.items())},indent=2)+'\n')
print(json.dumps({'checks':len(checks),'clear':sum(x['pass'] for x in checks),'failed':[x['name'] for x in checks if not x['pass']],'local_files':len(retention)+1,'logical_records':len(logical),'tar_members':len(members),'input_bindings':len(inputs),'source_archive_references':len(source_refs)}))
