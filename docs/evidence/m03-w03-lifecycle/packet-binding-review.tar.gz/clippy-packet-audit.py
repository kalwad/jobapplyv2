"""Additive read-only binding audit of the separate Clippy source packet."""
from pathlib import Path, PurePosixPath
import hashlib,json,shutil,subprocess,tarfile

BASE=Path('/Users/tanishkalwad/jobapplyv2-evidence/m03-w03-clippy-correction-20261019')
PACK=Path('/tmp/japp-m03-w03-clippy-retained-20261019')
AUTHOR=Path('/tmp/japp-m03-w03-windows-clippy-correction-20261019')
REVIEW=Path('/tmp/japp-m03-w03-independent-windows-clippy-review-20261019')
OUT=Path(__file__).parent
checks=[];inputs={}
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
def keep(p,copy=False):
 p=Path(p);row={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
 if copy:
  t=OUT/'inputs'/str(p).lstrip('/');t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,t);assert sha(t)==row['sha256'];row['copy']=str(t.relative_to(OUT))
 inputs[str(p)]=row;return row
def read(p):keep(p,True);return json.loads(Path(p).read_text())
def check(name,condition,detail):checks.append({'name':name,'pass':bool(condition),'detail':detail})
sel=read(BASE/'selection.json');ret=read(BASE/'retention.json');arc=read(PACK/'archive-manifest.json')
check('Clippy exact frozen durable identity',sha(BASE/'retention.json')=='cbfc9e90aa04575051dd7ae21b42dcd095d656abf65e3d2a2037c0c7cf11caaa',len(ret))
actual={p.relative_to(BASE).as_posix() for p in BASE.rglob('*') if p.is_file()}
check('Clippy exact durable file inventory',actual==set(ret)|{'retention.json'},len(actual))
valid=[]
for name,row in ret.items():
 p=BASE/name;q=keep(p);valid.append(not p.is_symlink() and q['sha256']==row['sha256'] and q['bytes']==row['bytes'])
check('Clippy all local durable hashes/sizes',all(valid),len(valid))
keys=set();valid=[]
for row in sel['records']:
 p=Path(row['original']);q=keep(p);keys.add(row['stored'])
 valid.append(q['sha256']==row['sha256']==ret[row['stored']]['sha256'] and q['bytes']==row['bytes']==ret[row['stored']]['bytes'])
check('Clippy all 207 original logical references exact',len(keys)==len(sel['records'])==207 and all(valid),len(sel['records']))
author_desired={p.relative_to(AUTHOR).as_posix() for p in AUTHOR.rglob('*') if p.is_file() and p.relative_to(AUTHOR).parts[0] not in ('source','cargo-target','produced-test-binaries')}
author_actual={x['stored'][7:] for x in sel['records'] if x['stored'].startswith('author/')}
check('Clippy complete stated author receipt selection',author_actual==author_desired,len(author_actual))
review_desired={p.relative_to(REVIEW).as_posix() for p in REVIEW.rglob('*') if p.is_file()}
review_actual={x['stored'][12:] for x in sel['records'] if x['stored'].startswith('independent/')}
check('Clippy complete sealed source review retained',review_actual==review_desired and sha(REVIEW/'findings.json')=='ed7ca360ef3744b7f2dd384327feb0bf1317de63fd4832f341fbd259fcd91c9a' and sha(REVIEW/'retention-manifest.json')=='e12572c5049230bffeb2d07e460611f0c868a072f3822228def526281a544a99',len(review_actual))
for name in ['mod.rs','platform.rs','protocol.rs','supervisor.rs']:
 rel='apps/desktop/src-tauri/src/service/'+name
 before=subprocess.check_output(['git','-C','/Users/tanishkalwad/jobapplyv2','show','cac56a00abdd7c86e148b10fd26ea317d62b4361:'+rel])
 check('Clippy '+name+' exact before/after bytes',(BASE/'before'/rel).read_bytes()==before and (BASE/'after'/rel).read_bytes()==(AUTHOR/'source'/rel).read_bytes(),'Before is immutable cac56 Git, after is the independently cleared final source.')
archive=PACK/'windows-clippy-correction.tar.gz';keep(archive)
check('Clippy exact tar identity',sha(archive)==arc['sha256']=='1b400396e5a836fb446a1db28a3fcc0439a139a194fa64f664884af1c5118029' and archive.stat().st_size==arc['bytes']==6913985,archive.stat().st_size)
members={}
with tarfile.open(archive,'r:gz') as t:
 for m in t:
  p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts and m.name not in members
  f=t.extractfile(m);assert f is not None;h=hashlib.sha256();n=0
  while b:=f.read(1048576):h.update(b);n+=len(b)
  assert n==m.size;members[m.name]={'sha256':h.hexdigest(),'bytes':n}
check('Clippy 208 safe regular members exact',members==arc['members'] and len(members)==208,'No extraction, links, duplicate paths or special files.')
expected=dict(ret);expected['retention.json']={'sha256':sha(BASE/'retention.json'),'bytes':(BASE/'retention.json').stat().st_size}
omitted=set(sel['remote_omitted_paths'])
check('Clippy six local-only produced binaries honestly omitted',len(omitted)==6 and all(x.startswith('local-only-binaries/') for x in omitted) and {x:expected[x] for x in omitted}==arc['omitted_local_only'] and set(members)==set(expected)-omitted and all(value==expected[name] for name,value in members.items()),'The exact produced-after-execution binary copies are durable locally; they are not upfront actor receipts or present in the selected review tar.')
check('Clippy scope and missing Windows GREEN preserved',sel['scope']=='POST_EXECUTION_SOURCE_CORRECTION_RETENTION_ONLY' and sel['source_base']=='cac56a00abdd7c86e148b10fd26ea317d62b4361' and len(sel['omissions'])==2 and 'Actual Windows GREEN' in (BASE/'README.md').read_text(),'No whole source/cache, native actor, actual Windows PASS or whole-W03 claim.')
keep(BASE/'README.md',True);keep(BASE/'collector.py',True)
(OUT/'clippy-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
(OUT/'clippy-input-retention.json').write_text(json.dumps({'scope':'READ_ONLY_SEPARATE_CLIPPY_PACKET_BINDING','records':list(inputs.values())},indent=2)+'\n')
(OUT/'clippy-archive-members-observed.json').write_text(json.dumps(members,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'clear':sum(x['pass'] for x in checks),'failed':[x['name'] for x in checks if not x['pass']],'local_files':len(actual),'logical_records':len(sel['records']),'tar_members':len(members),'input_bindings':len(inputs)}))
