"""Post-execution retention, not an execution/validation or approval tool."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tarfile
from datetime import datetime, timezone

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
DEST = Path('/Users/tanishkalwad/jobapplyv2-evidence/m03-w03-cac56-native-20261019')
PACK = Path('/tmp/japp-m03-w03-native-retained-20261019')
HEAD = 'cac56a00abdd7c86e148b10fd26ea317d62b4361'
TREE = '7d7afc0a24a8370fda79cb26d46e945bb056842d'
SOURCE_SHA = 'd6c7fc9d1d58d10a942c21693a221d017491b83823b8d7ce359d394a51dc19b4'


def git(*args: str) -> bytes:
    return subprocess.check_output(['git', *args], cwd=ROOT)


def digest(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def root_state() -> dict:
    entries = git('ls-tree', '-r', '-z', HEAD).split(b'\0')
    records = {}
    for entry in entries:
        if not entry:
            continue
        metadata, raw_path = entry.split(b'\t', 1)
        mode, kind, blob = metadata.decode().split()
        relative = raw_path.decode()
        path = ROOT / relative
        assert kind == 'blob' and stat.S_ISREG(path.lstat().st_mode), relative
        raw = path.read_bytes()
        assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == blob, relative
        records[relative] = {'git_mode': mode, 'git_blob': blob, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    state = {'head': git('rev-parse', 'HEAD').decode().strip(), 'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(), 'status': git('status', '--porcelain=v1').decode(), 'files': records}
    assert state['head'] == HEAD and state['tree'] == TREE and not state['status']
    assert len(records) == 1790
    return state


def main() -> None:
    assert not DEST.exists() and not PACK.exists(), 'Never overwrite a prior retention packet'
    DEST.mkdir(parents=True)
    PACK.mkdir()
    shutil.copyfile(__file__, DEST / 'collector.py')
    before = root_state()
    write_json(DEST / 'tracked-before.json', before)
    write_json(DEST / 'invocation.json', {'argv': sys.argv, 'cwd': os.getcwd(), 'started_at_utc': datetime.now(timezone.utc).isoformat(), 'scope': 'POST_EXECUTION_SELECTED_RETENTION_ONLY', 'collector_sha256': digest(Path(__file__))})
    records = []
    excluded = []
    seen = set()

    def add_file(category: str, relative: str, path: Path) -> None:
        assert not Path(relative).is_absolute() and '..' not in Path(relative).parts
        logical = f'{category}/{relative}'
        assert logical not in seen, logical
        seen.add(logical)
        info = path.lstat()
        assert stat.S_ISREG(info.st_mode), path
        checksum = digest(path)
        if info.st_size > 4 * 1024 * 1024:
            stored = f'blobs/{checksum}'
        else:
            stored = f'records/{logical}'
        target = DEST / stored
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            assert digest(target) == checksum and target.stat().st_size == info.st_size
        else:
            shutil.copyfile(path, target)
            target.chmod(stat.S_IMODE(info.st_mode))
        assert digest(path) == checksum and digest(target) == checksum
        records.append({'category': category, 'relative_path': relative, 'original_path': str(path), 'sha256': checksum, 'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode), 'stored_path': stored})

    def add_tree(category: str, base: Path, recursive: bool = True) -> None:
        assert base.is_dir()
        for path in sorted(base.rglob('*') if recursive else base.iterdir()):
            relative = path.relative_to(base)
            if '__pycache__' in relative.parts:
                if path.is_file():
                    excluded.append({'original_path': str(path), 'reason': 'Transient Python import cache; retained Python sources are authoritative'})
                continue
            assert not path.is_symlink(), path
            if path.is_file():
                add_file(category, relative.as_posix(), path)

    cases = {
        'canonical-close': Path('/tmp/japp-m03-w03-canonical-close-v3-20261018'),
        'canonical-quit': Path('/tmp/japp-m03-w03-canonical-quit-v3-20261018'),
        'canonical-forced': Path('/tmp/japp-m03-w03-canonical-forced-v3-20261018'),
        'contained-close': Path('/tmp/japp-m03-w03-contained-v3-native-20261019'),
        'escaped-retry': Path('/tmp/japp-m03-w03-escaped-v3-native-20261019'),
    }
    for name, base in cases.items():
        add_tree('cases/' + name, base)
        result = json.loads((base / 'proof/case-result.json').read_text())
        assert result['pass'] and result['spectator_unchanged']
        assert (base / 'observer-exit-code.txt').read_text().strip() == '0'
    app_roots = {}
    for name in ('canonical-close', 'contained-close', 'escaped-retry'):
        config = json.loads((cases[name] / 'case-input.json').read_text())
        app = Path(config['artifacts']['app']['path']).parents[2]
        app_roots[name] = str(app)
        add_tree('actual-apps/' + name, app)
        assert len(list(app.rglob('*'))) >= 42
        assert sum(path.is_file() for path in app.rglob('*')) == 42
    canonical_build = Path('/tmp/japp-m03-w03-root-app-build-v3-20261018')
    add_tree('canonical-build', canonical_build)
    for name, base in {
        'contained': Path('/tmp/japp-m03-w03-root-fixture-apps-v3-20261018/contained'),
        'escaped': Path('/tmp/japp-m03-w03-root-fixture-apps-v3-serial-20261018/escaped'),
    }.items():
        add_tree('fixture-builds/' + name + '/top', base, recursive=False)
        add_tree('fixture-builds/' + name + '/app-upfront', base / 'app-upfront')
        add_tree('fixture-builds/' + name + '/fixture-input', base / 'fixture-input')
        add_tree('fixture-builds/' + name + '/native-build-top', base / 'native-build', recursive=False)
    add_tree('native-independent-review', Path('/tmp/japp-m03-w03-independent-native-actual-review-20261019'))
    add_tree('hosted-ci-cac56', Path('/tmp/japp-m03-w03-hosted-ci-cac56-20261018'))
    add_tree('local-full-v3-pack', Path('/tmp/japp-m03-w03-full-v3-retained-20261018'))
    add_tree('full-v3-independent-review', Path('/tmp/japp-m03-w03-independent-root-integration-review-20261018/full-v3-data-review'))
    after = root_state()
    assert before == after
    write_json(DEST / 'tracked-after.json', after)
    unique = {record['stored_path']: record for record in records}
    assert any(record['sha256'] == SOURCE_SHA and record['bytes'] == 273090560 for record in records)
    write_json(DEST / 'selection.json', {'scope': 'ACTUAL_CAC56_NATIVE_AND_PRIOR_LOCAL_FULL_DATA; NOT_W03_ACCEPTANCE', 'source_commit': HEAD, 'source_tree': TREE, 'actual_apps': app_roots, 'selection_rules': ['All five case files except transient __pycache__', 'Three complete actual 42-file apps', 'Canonical complete build packet including upfront app and source archive', 'Fixture top-level build files, complete upfront apps, fixture inputs and native-build top-level receipts; no dependency/cargo/cache trees', 'Complete sealed native independent review including its preserved audit-premise failure', 'Complete collected hosted CI packet', 'Complete retained local full-v3 pack and independent data review'], 'omissions': ['No full interpreter/OS SDK/toolchain or Cargo/node/venv cache archival', 'Other historical failed/discovery packets remain at their recorded original paths and are not copied here', 'The selected remote review archive omits only the one 273090560-byte canonical source-archive blob; all its duplicate logical references remain hash-mapped and its exact bytes are retained in this durable local store'], 'excluded_transient_files': excluded, 'records': records, 'logical_records': len(records), 'unique_stored_files': len(unique), 'unique_stored_bytes': sum(record['bytes'] for record in unique.values())})
    (DEST / 'README.md').write_text('This is a post-execution selected retention packet for five actual macOS W03 cases at cac56, the separately reviewed local full-v3 PASS, and the actual hosted CI failure. It makes no new execution, approval, Windows PASS, or whole-package completion claim. Raw historical absolute paths and upfront scopes remain unchanged. selection.json maps original files and duplicate copies to durable records or SHA-256 blobs. Source archive d6c7fc9d… is retained once locally; it is omitted from the remote review tar solely to avoid a 273 MB Git object. All other selected bytes, including complete actual and upfront app files, are in the remote tar. All tracked root bytes, HEAD and tree are identical before/after collection. The sealed independent native review defines limits on normal action timing, AX diffs, 401 proof and current Windows failure.\n')
    write_json(DEST / 'collection-result.json', {'finished_at_utc': datetime.now(timezone.utc).isoformat(), 'source_unchanged': before == after, 'logical_records': len(records), 'unique_stored_files': len(unique), 'scope': 'RETENTION_COMPLETED_NOT_W03_ACCEPTANCE'})
    retention = {}
    for path in sorted(DEST.rglob('*')):
        if path.is_file():
            retention[path.relative_to(DEST).as_posix()] = {'sha256': digest(path), 'bytes': path.stat().st_size}
    write_json(DEST / 'retention-manifest.json', retention)
    archive = PACK / 'native-cac56-selected.tar.gz'
    omitted = f'blobs/{SOURCE_SHA}'
    with tarfile.open(archive, 'w:gz', compresslevel=6) as output:
        for path in sorted(DEST.rglob('*')):
            relative = path.relative_to(DEST).as_posix()
            if path.is_file() and relative != omitted:
                output.add(path, arcname=relative, recursive=False)
    assert archive.stat().st_size < 95 * 1024 * 1024, 'Review tar must fit ordinary GitHub file limits'
    archive_members = {}
    with tarfile.open(archive, 'r:gz') as stream:
        for member in stream:
            assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            handle = stream.extractfile(member)
            assert handle is not None
            archive_members[member.name] = {'sha256': hashlib.file_digest(handle, 'sha256').hexdigest(), 'bytes': member.size}
    expected = dict(retention)
    expected['retention-manifest.json'] = {'sha256': digest(DEST / 'retention-manifest.json'), 'bytes': (DEST / 'retention-manifest.json').stat().st_size}
    assert set(archive_members) == set(expected) - {omitted}
    assert all(value == expected[name] for name, value in archive_members.items())
    write_json(PACK / 'archive-manifest.json', {'archive': str(archive), 'sha256': digest(archive), 'bytes': archive.stat().st_size, 'durable_local_store': str(DEST), 'durable_retention_manifest_sha256': digest(DEST / 'retention-manifest.json'), 'omitted_local_only': {omitted: expected[omitted]}, 'members': archive_members})
    print(json.dumps({'durable': str(DEST), 'retention_sha256': digest(DEST / 'retention-manifest.json'), 'archive': str(archive), 'archive_sha256': digest(archive), 'archive_bytes': archive.stat().st_size, 'members': len(archive_members), 'logical_records': len(records)}))


if __name__ == '__main__':
    main()
