from pathlib import Path
import hashlib,json,shutil,tarfile,stat,subprocess
base=Path('/tmp/japp-m03-w03-windows-clippy-correction-20261019'); review=Path('/tmp/japp-m03-w03-independent-windows-clippy-review-20261019')
dest=Path('/Users/tanishkalwad/jobapplyv2-evidence/m03-w03-clippy-correction-20261019'); packet=Path('/tmp/japp-m03-w03-clippy-retained-20261019')
assert not dest.exists() and not packet.exists();dest.mkdir(parents=True);packet.mkdir()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
rows=[];omitted=[]
def copy(p,rel):
 assert stat.S_ISREG(p.lstat().st_mode)
 out=dest/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out);assert sha(p)==sha(out)
 rows.append({'original':str(p),'stored':rel,'bytes':p.stat().st_size,'sha256':sha(p)})
for p in sorted(base.rglob('*')):
 rel=p.relative_to(base)
 if rel.parts[0] in ('source','cargo-target'):continue
 if p.is_file():
  if rel.parts[0]=='produced-test-binaries':
   relout='local-only-binaries/'+rel.name;copy(p,relout);omitted.append(relout)
  else:copy(p,'author/'+str(rel))
for rel in ('apps/desktop/src-tauri/src/service/mod.rs','apps/desktop/src-tauri/src/service/platform.rs','apps/desktop/src-tauri/src/service/protocol.rs','apps/desktop/src-tauri/src/service/supervisor.rs'):
 copy(base/'source'/rel,'after/'+rel)
 out=dest/'before'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(subprocess.check_output(['git','show','cac56a00abdd7c86e148b10fd26ea317d62b4361:'+rel],cwd='/Users/tanishkalwad/jobapplyv2'))
for p in sorted(review.rglob('*')):
 if p.is_file():copy(p,'independent/'+str(p.relative_to(review)))
copy(Path(__file__),'collector.py')
write(dest/'selection.json',{'scope':'POST_EXECUTION_SOURCE_CORRECTION_RETENTION_ONLY','source_base':'cac56a00abdd7c86e148b10fd26ea317d62b4361','records':rows,'omissions':['Whole unchanged1790-file proposal source remains reconstructible from base Git plus exact four-file patch; no Cargo target/cache archived','Six produced-after-execution test executable copies retained locally under local-only-binaries/ but omitted from the remote archive; no upfront actor provenance is claimed'],'remote_omitted_paths':omitted})
(dest/'README.md').write_text('Four-file Windows strict-Clippy correction prompted by actual hosted failure. All original Mac77test IDs/bodies/assertions and runtime contracts remain exact. The ten Mac checks and independent53check source review passed. Actual Windows GREEN and wholeW03 acceptance still require fresh validation. selection.json discloses local-only produced test executable copies and excludes disposable caches/unchanged source; exact before/after files, source manifests, raw commands, initial freeze-premise failure, official Windows RED logs and independent report are retained.\n')
manifest={str(p.relative_to(dest)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(dest.rglob('*')) if p.is_file()};write(dest/'retention.json',manifest)
archive=packet/'windows-clippy-correction.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for p in sorted(dest.rglob('*')):
  rel=str(p.relative_to(dest))
  if p.is_file() and rel not in omitted:t.add(p,arcname=rel,recursive=False)
actual={}
with tarfile.open(archive,'r:gz') as t:
 for m in t:
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  f=t.extractfile(m);actual[m.name]={'bytes':m.size,'sha256':hashlib.file_digest(f,'sha256').hexdigest()}
expected={**manifest,'retention.json':{'bytes':(dest/'retention.json').stat().st_size,'sha256':sha(dest/'retention.json')}}
assert set(actual)==set(expected)-set(omitted) and all(expected[p]==v for p,v in actual.items())
write(packet/'archive-manifest.json',{'archive':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'durable_local_store':str(dest),'retention_sha256':sha(dest/'retention.json'),'omitted_local_only':{p:expected[p] for p in omitted},'members':actual})
print(json.dumps({'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(actual),'retention_sha256':sha(dest/'retention.json')}))
