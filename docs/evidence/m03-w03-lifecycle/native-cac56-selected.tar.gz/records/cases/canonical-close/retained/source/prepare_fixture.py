"""Create TEST ONLY fixture entry inputs; never builds or launches a service."""

from __future__ import annotations

import argparse
import json
import secrets
from pathlib import Path

from japp_lifecycle_probe import digest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=["contained", "escaped"], required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--contracts-wheel", type=Path, required=True)
    parser.add_argument("--orchestrator-wheel", type=Path, required=True)
    args = parser.parse_args()
    if not args.output.is_absolute() or args.output.exists():
        raise ValueError("Fresh absolute test-only fixture directory required")
    wheels = {}
    for name in ["contracts_wheel", "orchestrator_wheel"]:
        path: Path = getattr(args, name).resolve(strict=True)
        if not path.is_file() or path.suffix != ".whl":
            raise ValueError("Actual canonical wheel file required")
        wheels[name] = {"path": str(path), "sha256": digest(path)}
    args.output.mkdir(mode=0o700)
    nonce = secrets.token_hex(16)
    marker = args.output / "owned-writer.json"
    source = (
        "from pathlib import Path\nfrom service_fixture import run\n"
        f"raise SystemExit(run({args.mode!r}, Path({str(marker)!r}), {nonce!r}))\n"
    )
    entry = args.output / "fixture_entry.py"
    entry.write_text(source)
    recipe = {
        "scope": "TEST_ONLY_WRITER_NOT_CANONICAL_RUNTIME",
        "mode": args.mode,
        "marker": str(marker),
        "nonce": nonce,
        "canonical_wheels": wheels,
        "entry_source": str(entry),
        "entry_sha256": digest(entry),
        "worker_lifetime_fallback_seconds": 120,
        "release": "unique nonce-bound control file; no arbitrary PID signals",
        "build_status": "NOT_EXECUTED",
    }
    (args.output / "fixture-recipe.json").write_text(
        json.dumps(recipe, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
