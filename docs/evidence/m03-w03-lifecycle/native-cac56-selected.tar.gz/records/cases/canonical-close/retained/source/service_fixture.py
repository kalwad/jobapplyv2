"""TEST ONLY: canonical service entry with an explicitly owned silent writer fixture."""

from __future__ import annotations

import importlib
import json
import os
import subprocess
import sys
import time
from dataclasses import asdict
from pathlib import Path
from typing import Literal

from japp_mac_probe import MacProbe

# Retain the handle without entering Popen's wait-on-context-exit behavior.
OWNED_FIXTURE_WORKERS: list[subprocess.Popen[bytes]] = []
WORKER_LIFETIME_SECONDS = 120
NONCE_LENGTH = 32
MAX_RELEASE_BYTES = 64


def run(mode: Literal["contained", "escaped"], marker: Path, nonce: str) -> int:
    if not marker.is_absolute() or marker.exists() or len(nonce) != NONCE_LENGTH:
        raise ValueError("Fresh build-bound test fixture marker required")
    if sys.argv[1:] == ["--japp-fixture-worker"]:
        identity = MacProbe().identity(os.getpid())
        if identity is None:
            raise ValueError("Test worker identity unavailable")
        marker.write_text(
            json.dumps(
                {
                    "scope": "TEST_ONLY_WRITER",
                    "mode": mode,
                    "nonce": nonce,
                    "identity": asdict(identity),
                }
            )
            + "\n"
        )
        # FD1 is inherited and silent; stdin is DEVNULL.
        release = marker.with_suffix(".release")
        deadline = time.monotonic() + WORKER_LIFETIME_SECONDS
        reason = "fixture_lifetime_expired"
        while time.monotonic() < deadline:
            if (
                release.is_file()
                and release.stat().st_size <= MAX_RELEASE_BYTES
                and release.read_text().strip() == nonce
            ):
                reason = "owned_observer_release"
                break
            time.sleep(0.05)
        marker.with_suffix(".exit.json").write_text(
            json.dumps(
                {
                    "scope": "TEST_ONLY_WRITER",
                    "nonce": nonce,
                    "reason": reason,
                    "pid": identity.pid,
                    "monotonic": time.monotonic(),
                }
            )
            + "\n"
        )
        return 0 if reason == "owned_observer_release" else 70
    if sys.argv[1:]:
        raise ValueError("Only the explicit test worker branch accepts an argument")
    worker = subprocess.Popen(
        [sys.executable, "--japp-fixture-worker"],
        stdin=subprocess.DEVNULL,
        stdout=None,
        stderr=subprocess.DEVNULL,
        close_fds=True,
        start_new_session=mode == "escaped",
    )
    OWNED_FIXTURE_WORKERS.append(worker)
    runner = importlib.import_module("orchestrator.runner")

    return int(runner.main())
