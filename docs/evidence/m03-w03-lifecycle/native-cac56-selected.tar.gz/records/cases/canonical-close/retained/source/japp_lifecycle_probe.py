"""Retained W03 proof helper. GUI actions are performed separately by root/CUA."""

from __future__ import annotations

import argparse
import hashlib
import json
import selectors
import shutil
import subprocess
import sys
import time
from contextlib import ExitStack
from dataclasses import asdict
from pathlib import Path
from typing import cast

from japp_mac_probe import MacProbe, RealClock
from japp_probe_core import Identity, Probe, absence, force_owned_parent, same_process

MAX_BYTES = 512 * 1024 * 1024
MAX_MARKER_BYTES = 8192
MODULES = [
    "japp_lifecycle_probe.py",
    "japp_probe_core.py",
    "japp_mac_probe.py",
    "service_fixture.py",
    "prepare_fixture.py",
    "build-test-fixture-runtime.py",
]
REQUIRED_ARTIFACTS = {
    "app",
    "service",
    "root_source",
    "runtime_manifest",
    "contracts_wheel",
    "orchestrator_wheel",
}


def digest(path: Path) -> str:
    initial = path.stat()
    total = 0
    result = hashlib.sha256()
    with path.open("rb") as source:
        while chunk := source.read(16384):
            total += len(chunk)
            if total > MAX_BYTES:
                raise ValueError("Proof input exceeds finite bound")
            result.update(chunk)
        final = path.stat()
        if (initial.st_dev, initial.st_ino, initial.st_size, initial.st_mtime_ns) != (
            final.st_dev,
            final.st_ino,
            final.st_size,
            final.st_mtime_ns,
        ) or total != initial.st_size:
            raise ValueError("Proof input changed while retained")
    return result.hexdigest()


def prepare(config_path: Path, run: Path) -> None:
    if not run.is_absolute() or run.exists():
        raise ValueError("Fresh absolute proof directory required")
    config = json.loads(config_path.read_text())
    if config["operation"] not in {"observe", "owned-force"} or config["scope"] not in {
        "canonical",
        "contained",
        "escaped",
    }:
        raise ValueError("Explicit case operation/scope required")
    if config["operation"] == "owned-force" and config["scope"] != "canonical":
        raise ValueError("Forcekill is canonical only")
    artifacts = config["artifacts"]
    if set(artifacts) != REQUIRED_ARTIFACTS:
        raise ValueError("Actual root source/runtime/wheel bindings are required")
    run.mkdir(mode=0o700)
    source_root = Path(__file__).resolve().parent
    retained = run / "retained"
    (retained / "source").mkdir(parents=True)
    records: list[dict[str, object]] = []
    for name in MODULES:
        source = source_root / name
        target = retained / "source" / name
        shutil.copy2(source, target)
        records.append(
            {
                "role": "helper-source",
                "original": str(source),
                "copy": str(target),
                "sha256": digest(source),
            }
        )
    for name, raw in artifacts.items():
        source = Path(raw["path"]).resolve(strict=True)
        expected = raw["sha256"]
        if not source.is_file() or digest(source) != expected:
            raise ValueError("Actual artifact hash mismatch")
        target = retained / (name + ".executed-or-input-bytes")
        shutil.copy2(source, target)
        if digest(target) != expected:
            raise ValueError("Retained artifact copy mismatch")
        artifacts[name]["path"] = str(source)
        records.append(
            {
                "role": name,
                "original": str(source),
                "copy": str(target),
                "sha256": expected,
            }
        )
    lsof = Path("/usr/sbin/lsof").resolve(strict=True)
    lsof_copy = retained / "lsof.executed-bytes"
    shutil.copyfile(lsof, lsof_copy)
    if digest(lsof_copy) != digest(lsof):
        raise ValueError("Retained observer bytes mismatch")
    records.append(
        {
            "role": "observer-lsof",
            "original": str(lsof),
            "copy": str(lsof_copy),
            "sha256": digest(lsof),
        }
    )
    python = Path(sys.executable).resolve(strict=True)
    target = retained / "python.executed-bytes"
    shutil.copy2(python, target)
    records.append(
        {
            "role": "interpreter",
            "original": str(python),
            "copy": str(target),
            "sha256": digest(python),
        }
    )
    runtime = json.loads(Path(artifacts["runtime_manifest"]["path"]).read_text())
    for key in ["contracts_wheel", "orchestrator_wheel"]:
        if runtime["source_inputs"][key + "_sha256"] != artifacts[key]["sha256"]:
            raise ValueError(
                "Runtime does not bind the declared actual canonical wheels"
            )
    config["interpreter"] = str(python)
    (run / "case-input.json").write_text(json.dumps(config, indent=2) + "\n")
    command = [
        str(python),
        str(retained / "source/japp_lifecycle_probe.py"),
        "run",
        "--prepared",
        str(run),
    ]
    (run / "upfront-retention.json").write_text(
        json.dumps(
            {
                "scope": "TEST_PROOF_ONLY_NOT_EXECUTED",
                "records": records,
                "argv": command,
                "case_input_sha256": digest(run / "case-input.json"),
                "app_child_environment": {"PATH": "/usr/bin:/bin"},
            },
            indent=2,
        )
        + "\n"
    )
    sys.stdout.write(json.dumps({"prepared": str(run), "argv": command}) + "\n")


def verified_prepared(run: Path) -> dict[str, object]:
    upfront = json.loads((run / "upfront-retention.json").read_text())
    if digest(run / "case-input.json") != upfront["case_input_sha256"]:
        raise ValueError("Prepared case input changed")
    for row in upfront["records"]:
        if (
            digest(Path(row["original"])) != row["sha256"]
            or digest(Path(row["copy"])) != row["sha256"]
        ):
            raise ValueError("Upfront retained source/executed input changed")
    config = json.loads((run / "case-input.json").read_text())
    if Path(sys.executable).resolve() != Path(config["interpreter"]):
        raise ValueError("Actual executing interpreter differs from retained bytes")
    return cast("dict[str, object]", config)


def read_fixture_identity(
    marker: Path, scope: str, nonce: str, service: Identity, probe: Probe
) -> Identity | None:
    """Capture the owned writer even while the service listener is still starting."""
    if not marker.is_file():
        return None
    if marker.stat().st_size > MAX_MARKER_BYTES:
        raise ValueError("Fixture marker exceeds bound")
    data = json.loads(marker.read_text())
    worker = Identity(**data["identity"])
    if (
        data["scope"] != "TEST_ONLY_WRITER"
        or data["mode"] != scope
        or data["nonce"] != nonce
        or worker.ppid != service.pid
        or worker.executable != service.executable
        or not same_process(worker, probe.identity(worker.pid))
        or (scope == "contained" and worker.pgid != service.pgid)
        or (scope == "escaped" and worker.pgid != worker.pid)
    ):
        raise ValueError(
            "Fixture worker parent/birth/executable/group binding mismatch"
        )
    return worker


def run_case(run: Path, observed_app_pid: int | None) -> None:  # noqa: PLR0912, PLR0915 - one ordered proof case.
    config = verified_prepared(run)
    if config["operation"] == "owned-force" and config["scope"] != "canonical":
        raise ValueError("Forcekill is canonical only")
    artifacts = cast("dict[str, dict[str, str]]", config["artifacts"])
    app_exe, service_exe = artifacts["app"]["path"], artifacts["service"]["path"]
    output = run / "proof"
    output.mkdir()
    events = (output / "events.jsonl").open("x")
    probe, clock = MacProbe(), RealClock()
    app_child: subprocess.Popen[bytes] | None = None
    spectator: subprocess.Popen[bytes] | None = None
    spectator_identity: Identity | None = None
    worker: Identity | None = None
    app: Identity | None = None
    service: Identity | None = None
    port: int | None = None
    outcome: dict[str, object] = {
        "pass": False,
        "scope": config["scope"],
        "gui_evidence": "ROOT_CUA_REQUIRED",
    }
    event_number = 0
    marker = config.get("fixture_marker")
    nonce = config.get("fixture_nonce")
    if config["scope"] != "canonical" and (
        not isinstance(marker, str) or not isinstance(nonce, str)
    ):
        raise ValueError("Fixture marker and nonce required before launching")
    app_logs = ExitStack()

    def emit(kind: str, data: object) -> None:
        nonlocal event_number
        event_number += 1
        row = {
            "sequence": event_number,
            "kind": kind,
            "monotonic": time.monotonic(),
            "utc_ns": time.time_ns(),
            "data": data,
        }
        text = json.dumps(row)
        events.write(text + "\n")
        events.flush()
        sys.stdout.write(text + "\n")
        sys.stdout.flush()

    try:
        emit("ACTOR_BEGIN", {"argv": sys.argv, "operation": config["operation"]})
        emit(
            "BEFORE_SPECTATOR_LAUNCH",
            {
                "argv": [
                    str(config["interpreter"]),
                    "-c",
                    "import time; time.sleep(300)",
                ],
                "cwd": str(run),
                "environment": {"PATH": "/usr/bin:/bin"},
            },
        )
        spectator = subprocess.Popen(  # noqa: S603 - retained interpreter, owned spectator.
            [str(config["interpreter"]), "-c", "import time; time.sleep(300)"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
            start_new_session=True,
            env={"PATH": "/usr/bin:/bin"},
        )
        spectator_identity = probe.identity(spectator.pid)
        if spectator_identity is None:
            raise ValueError("Owned spectator identity unavailable")
        if config["operation"] == "owned-force":
            if observed_app_pid is not None:
                raise ValueError(
                    "Forcekill cannot accept an arbitrary observed app PID"
                )
            emit(
                "BEFORE_OWNED_APP_LAUNCH",
                {
                    "argv": [app_exe],
                    "cwd": str(run),
                    "environment": {"PATH": "/usr/bin:/bin"},
                },
            )
            app_child = subprocess.Popen(  # noqa: S603 - approved app with Popen ownership.
                [app_exe],
                cwd=run,
                env={"PATH": "/usr/bin:/bin"},
                stdin=subprocess.DEVNULL,
                stdout=app_logs.enter_context((output / "app.stdout").open("xb")),
                stderr=app_logs.enter_context((output / "app.stderr").open("xb")),
                close_fds=True,
            )
            app_pid = app_child.pid
        else:
            if observed_app_pid is None or observed_app_pid <= 0:
                raise ValueError(
                    "LaunchServices observation requires root's exact app PID"
                )
            app_pid = observed_app_pid
        app = probe.identity(app_pid)
        if app is None or app.executable != app_exe:
            raise ValueError("App identity differs from bound executable")
        deadline = time.monotonic() + 20
        listener_number = 0
        while time.monotonic() < deadline:
            matches = [
                identity
                for pid in probe.children(app.pid)
                if (identity := probe.identity(pid)) is not None
                and identity.executable == service_exe
            ]
            if len(matches) > 1:
                raise ValueError("Duplicate exact service children")
            if matches:
                service = matches[0]
                if service.ppid != app.pid or service.pgid != service.pid:
                    raise ValueError("Service parent/group ownership mismatch")
                if (
                    isinstance(marker, str)
                    and isinstance(nonce, str)
                    and worker is None
                ):
                    worker = read_fixture_identity(
                        Path(marker), str(config["scope"]), nonce, service, probe
                    )
                listener_number += 1
                port = probe.listener(
                    service.pid, output / f"listener-{listener_number}.stdout"
                )
                if port is not None:
                    break
            time.sleep(0.05)
        if (
            service is None
            or port is None
            or not same_process(service, probe.identity(service.pid))
            or not same_process(app, probe.identity(app.pid))
        ):
            raise ValueError("Owned service/listener baseline deadline")
        if config["scope"] != "canonical":
            if not isinstance(marker, str) or not isinstance(nonce, str):
                raise ValueError("Fixture binding unavailable")
            while worker is None and time.monotonic() < deadline:
                worker = read_fixture_identity(
                    Path(marker), str(config["scope"]), nonce, service, probe
                )
                if worker is None:
                    time.sleep(0.05)
            if worker is None:
                raise ValueError("Fixture worker baseline deadline")
        emit(
            "BASELINE_READY",
            {
                "app": asdict(app),
                "service": asdict(service),
                "port": port,
                "spectator": asdict(spectator_identity),
                "worker": asdict(worker) if worker else None,
                "native_running_title": "ROOT_CUA_MUST_CAPTURE",
                "authenticated_health": "NOT_CLAIMED_W04_REQUIRED",
            },
        )
        selector = selectors.DefaultSelector()
        selector.register(sys.stdin, selectors.EVENT_READ)
        expires = time.monotonic() + 180
        armed: float | None = None
        explicitly_released = False
        while time.monotonic() < expires:
            for _key, _mask in selector.select(0.1):
                command = sys.stdin.readline().strip()
                if command == "force-parent":
                    if app_child is None:
                        raise ValueError(
                            "No retained app Popen handle; observation cannot forcekill"
                        )
                    result = force_owned_parent(
                        app_child, app, service, port, probe, clock, 12
                    )
                    result["spectator_unchanged"] = same_process(
                        spectator_identity, probe.identity(spectator.pid)
                    )
                    result["pass"] = bool(result["pass"]) and bool(
                        result["spectator_unchanged"]
                    )
                    emit("FORCE_PARENT_RESULT", result)
                    outcome.update(result)
                    outcome["case_complete"] = True
                    break
                if command in {"arm-close", "arm-quit", "arm-retry"}:
                    armed = time.monotonic()
                    emit(
                        "GUI_ACTION_ARMED",
                        {"command": command, "root_cua_action_follows": True},
                    )
                elif command == "release-escaped":
                    if (
                        config["scope"] != "escaped"
                        or worker is None
                        or not same_process(worker, probe.identity(worker.pid))
                    ):
                        raise ValueError(
                            "No saved exact escaped fixture worker authority"
                        )
                    emit("BEFORE_OWNED_FIXTURE_RELEASE", asdict(worker))
                    if not isinstance(marker, str) or not isinstance(
                        config.get("fixture_nonce"), str
                    ):
                        raise ValueError("Owned fixture release binding unavailable")
                    Path(marker).with_suffix(".release").write_text(
                        str(config["fixture_nonce"]) + "\n"
                    )
                    explicitly_released = True
                    emit(
                        "OWNED_FIXTURE_RELEASE_SENT",
                        {"pid": worker.pid, "method": "nonce_bound_owned_control_file"},
                    )
                elif command == "snapshot":
                    emit(
                        "OBSERVATION",
                        {
                            **absence(app, service, port, probe),
                            "worker_present": probe.present(worker.pid)
                            if worker
                            else False,
                            "spectator_unchanged": same_process(
                                spectator_identity, probe.identity(spectator.pid)
                            ),
                        },
                    )
                elif command == "finish":
                    final = absence(app, service, port, probe)
                    release_proven = True
                    if config["scope"] == "escaped":
                        release_proven = False
                        if (
                            isinstance(marker, str)
                            and isinstance(nonce, str)
                            and worker is not None
                        ):
                            exit_marker = Path(marker).with_suffix(".exit.json")
                            if (
                                explicitly_released
                                and exit_marker.is_file()
                                and exit_marker.stat().st_size <= MAX_MARKER_BYTES
                            ):
                                exit_record = json.loads(exit_marker.read_text())
                                release_proven = (
                                    exit_record.get("scope") == "TEST_ONLY_WRITER"
                                    and exit_record.get("nonce") == nonce
                                    and exit_record.get("pid") == worker.pid
                                    and exit_record.get("reason")
                                    == "owned_observer_release"
                                )
                    outcome.update(
                        escaped_explicit_release_proven=release_proven,
                        pass_=all(final.values()),
                        final=final,
                        worker_absent=not probe.present(worker.pid) if worker else True,
                        spectator_unchanged=same_process(
                            spectator_identity, probe.identity(spectator.pid)
                        ),
                        parent_wait_included=app_child is not None,
                        action_arm_to_observation_ms=(time.monotonic() - armed) * 1000
                        if armed
                        else None,
                    )
                    outcome["pass"] = (
                        bool(outcome["pass_"])
                        and bool(outcome["worker_absent"])
                        and bool(outcome["spectator_unchanged"])
                        and release_proven
                    )
                    emit("FINAL_OBSERVATION", outcome)
                    break
                elif command == "":
                    raise ValueError(
                        "Root command stream closed before explicit finish"
                    )
            else:
                continue
            if outcome.get("final") is not None or outcome.get("case_complete") is True:
                break
        else:
            raise ValueError("Bounded case observer deadline")
    except (OSError, ValueError, subprocess.TimeoutExpired) as error:
        outcome.update(
            pass_=False, failure=type(error).__name__, failure_detail=str(error)
        )
        emit("CASE_FAILED", outcome)
    finally:
        # Capture an already-created writer even if startup failed before READY.
        try:
            if (
                worker is None
                and service is not None
                and isinstance(marker, str)
                and isinstance(nonce, str)
            ):
                worker = read_fixture_identity(
                    Path(marker), str(config["scope"]), nonce, service, probe
                )
            # The unique build-bound nonce control file is safe even if the writer
            # exits before its identity is observed. No PID is signalled here.
            if isinstance(marker, str) and isinstance(nonce, str):
                Path(marker).with_suffix(".release").write_text(nonce + "\n")
            # Release the captured fixture through its owned control file.
            if (
                worker is not None
                and same_process(worker, probe.identity(worker.pid))
                and isinstance(marker, str)
                and isinstance(config.get("fixture_nonce"), str)
            ):
                emit("FINALLY_OWNED_WORKER_RELEASE", asdict(worker))
                Path(marker).with_suffix(".release").write_text(
                    str(config["fixture_nonce"]) + "\n"
                )
                release_deadline = time.monotonic() + 2
                while probe.present(worker.pid) and time.monotonic() < release_deadline:
                    time.sleep(0.05)
                if probe.present(worker.pid):
                    outcome["failure"] = "OWNED_FIXTURE_REMAINED_AFTER_RELEASE"
        except (OSError, ValueError):
            outcome["failure"] = "OWNED_FIXTURE_CLEANUP_OBSERVATION_FAILED"
        for owned, saved in [(app_child, app), (spectator, spectator_identity)]:
            try:
                if (
                    owned is not None
                    and saved is not None
                    and owned.poll() is None
                    and same_process(saved, probe.identity(owned.pid))
                ):
                    emit("FINALLY_OWNED_CHILD_RELEASE", asdict(saved))
                    owned.kill()
                    owned.wait(timeout=2)
            except (OSError, ValueError, subprocess.TimeoutExpired):
                outcome["failure"] = "OWNED_CHILD_FINALLY_CLEANUP_FAILED"
        outcome["pass"] = bool(outcome.get("pass")) and "failure" not in outcome
        (output / "case-result.json").write_text(json.dumps(outcome, indent=2) + "\n")
        app_logs.close()
        events.close()
    if not outcome["pass"]:
        raise SystemExit(1)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    prep = sub.add_parser("prepare")
    prep.add_argument("--config", type=Path, required=True)
    prep.add_argument("--run-dir", type=Path, required=True)
    run = sub.add_parser("run")
    run.add_argument("--prepared", type=Path, required=True)
    run.add_argument("--observe-app-pid", type=int)
    args = parser.parse_args()
    if args.command == "prepare":
        prepare(args.config, args.run_dir)
    else:
        run_case(args.prepared, args.observe_app_pid)


if __name__ == "__main__":
    main()
