"""Read-only unauthorized request against the exact observer-owned listener."""
import dataclasses
from contextlib import closing
import hashlib
import http.client
import json
from pathlib import Path
import sys
import time

run = Path(sys.argv[1]).resolve(strict=True)
sys.path.insert(0, str(run / 'retained/source'))
from japp_mac_probe import MacProbe
from japp_probe_core import Identity, same_process

output = run / 'proof/unauthorized'
output.mkdir(exist_ok=False)
source = Path(__file__).resolve()
source_sha = hashlib.sha256(source.read_bytes()).hexdigest()
(output / 'executed-source.py').write_bytes(source.read_bytes())
events = [json.loads(line) for line in (run / 'proof/events.jsonl').read_text().splitlines()]
baseline = [row['data'] for row in events if row['kind'] == 'BASELINE_READY'][-1]
service = Identity(**baseline['service'])
port = baseline['port']
probe = MacProbe()
assert same_process(service, probe.identity(service.pid)), 'Owned service changed before request'
receipt = {'argv': sys.argv, 'source_sha256': source_sha, 'interpreter': str(Path(sys.executable).resolve()), 'service': dataclasses.asdict(service), 'port': port, 'method': 'GET', 'path': '/api/v1/health', 'authorization': 'ABSENT', 'timeout_seconds': 2, 'started_monotonic': time.monotonic(), 'started_utc_ns': time.time_ns()}
(output / 'invocation.json').write_text(json.dumps(receipt, indent=2) + '\n')
with closing(http.client.HTTPConnection('127.0.0.1', port, timeout=2)) as connection:
    connection.request('GET', '/api/v1/health')
    response = connection.getresponse()
    body = response.read(65537)
    assert len(body) <= 65536, 'Response exceeded bound'
    (output / 'response.body').write_bytes(body)
    headers = response.getheaders()
    status = response.status
assert same_process(service, probe.identity(service.pid)), 'Owned service changed after request'
payload = json.loads(body)
canonical_rejection = status == 401 and payload['payload']['code'] == 'TRANSPORT_UNAUTHENTICATED' and payload['envelope']['schema_id'] == 'urn:japp:schema:error:record:v1'
receipt.update(status=status, headers=headers, body_sha256=hashlib.sha256(body).hexdigest(), body_bytes=len(body), ended_monotonic=time.monotonic(), ended_utc_ns=time.time_ns(), owned_identity_unchanged=True, pass_=canonical_rejection)
(output / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
raise SystemExit(0 if canonical_rejection else 1)
