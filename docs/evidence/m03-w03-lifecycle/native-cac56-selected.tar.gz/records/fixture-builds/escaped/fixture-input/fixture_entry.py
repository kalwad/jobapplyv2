from pathlib import Path
from service_fixture import run
raise SystemExit(run('escaped', Path('/private/tmp/japp-m03-w03-root-fixture-apps-v3-serial-20261018/escaped/fixture-input/owned-writer.json'), 'dd983a033c43f4262b1ee79c7157ee71'))
