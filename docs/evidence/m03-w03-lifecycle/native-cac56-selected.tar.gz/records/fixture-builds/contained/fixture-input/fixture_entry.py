from pathlib import Path
from service_fixture import run
raise SystemExit(run('contained', Path('/private/tmp/japp-m03-w03-root-fixture-apps-v3-20261018/contained/fixture-input/owned-writer.json'), 'db0b166900b48a90f65df2c5ef77aff8'))
