"""Read-only independent audit; never import or execute the product/proof helpers."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import shutil
import subprocess
import tarfile
import time

OUT = Path(__file__).parent
ROOT = Path('/Users/tanishkalwad/jobapplyv2')
HEAD = 'cac56a00abdd7c86e148b10fd26ea317d62b4361'
TREE = '7d7afc0a24a8370fda79cb26d46e945bb056842d'
checks = []
inputs = {}

def sha(path):
    p = Path(path)
    h = hashlib.sha256()
    with p.open('rb') as f:
        while data := f.read(1048576): h.update(data)
    return h.hexdigest()

def retain(path, label=None, copy=True):
    p = Path(path)
    digest = sha(p)
    item = {'path':str(p), 'sha256':digest, 'bytes':p.stat().st_size}
    if copy:
        target = OUT / 'inputs' / (label or str(p).lstrip('/'))
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p,target)
        assert sha(target) == digest
        item['copy'] = str(target.relative_to(OUT))
    inputs[str(p)] = item
    return digest

def read(path, copy=True):
    retain(path,copy=copy)
    return json.loads(Path(path).read_text())

def check(name, condition, detail):
    checks.append({'name':name, 'pass':bool(condition), 'detail':detail})

def git(*argv):
    return subprocess.check_output(['git','-C',str(ROOT),*argv])

def file_tree(base):
    base=Path(base)
    result={}
    for p in sorted(base.rglob('*')):
        if p.is_file():
            assert not p.is_symlink()
            result[p.relative_to(base).as_posix()]={'sha256':sha(p),'bytes':p.stat().st_size}
    return result

root_before={'head':git('rev-parse','HEAD').decode().strip(), 'tree':git('rev-parse','HEAD^{tree}').decode().strip(), 'status':git('status','--porcelain=v1').decode()}
build=Path('/tmp/japp-m03-w03-root-app-build-v3-20261018')
tracked=read(build/'tracked-before.json')
check('current root source identity',root_before=={'head':HEAD,'tree':TREE,'status':''},root_before)
check('build source neutrality',tracked==read(build/'tracked-after.json') and len(tracked)==1790, {'tracked':len(tracked)})
check('current tracked bytes equal build input',all(sha(ROOT/p)==h for p,h in tracked.items()),'All 1790 tracked paths hashed without executing the product.')

archive=build/'root-source-cac56a0.tar'
retain(archive,copy=False)
git_tree={}
for line in git('ls-tree','-rz','--full-tree',HEAD).split(b'\0'):
    if not line:continue
    metadata,name=line.split(b'\t',1)
    mode,kind,oid=metadata.decode().split()
    assert kind=='blob'
    git_tree[name.decode()]=oid
archive_hashes={}
archive_oids={}
with tarfile.open(archive) as tar:
    for member in tar:
        p=PurePosixPath(member.name)
        assert not p.is_absolute() and '..' not in p.parts
        if member.isdir():continue
        assert member.isfile() and member.name not in archive_hashes
        data=tar.extractfile(member).read()
        archive_hashes[member.name]=hashlib.sha256(data).hexdigest()
        archive_oids[member.name]=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
check('actual source archive equals immutable Git blobs',archive_hashes==tracked and archive_oids==git_tree,{'regular_files':len(archive_hashes),'archive_sha256':sha(archive)})
(OUT/'source-archive-file-hashes.json').write_text(json.dumps(archive_hashes,indent=2)+'\n')

cases={}
for stem in ['canonical-close-v3-20261018','canonical-quit-v3-20261018','canonical-forced-v3-20261018','contained-v3-native-20261019','escaped-v3-native-20261019']:
    base=Path('/tmp/japp-m03-w03-'+stem)
    config=read(base/'case-input.json')
    upfront=read(base/'upfront-retention.json')
    result=read(base/'proof/case-result.json')
    raw_events=(base/'proof/events.jsonl').read_text()
    events=[json.loads(x) for x in raw_events.splitlines()]
    baseline=next(x['data'] for x in events if x['kind']=='BASELINE_READY')
    retain(base/'proof/events.jsonl')
    for p in sorted(base.rglob('*')):
        if p.is_file() and 'retained' not in p.relative_to(base).parts:
            retain(p)
    bindings=[]
    for row in upfront['records']:
        copy = row['role']=='helper-source'
        original=retain(row['original'],copy=False)
        retained=retain(row['copy'],copy=copy)
        bindings.append(original==retained==row['sha256'])
    check(stem+' upfront original/copy binding',all(bindings) and len(bindings)==14 and sha(base/'case-input.json')==upfront['case_input_sha256'],{'records':len(bindings)})
    check(stem+' current source binding',config['source_commit']==HEAD and config['source_tree']==TREE and config['artifacts']['root_source']['sha256']==sha(archive),config['source_commit'])
    check(stem+' actual receipt sequence and clocks',[x['sequence'] for x in events]==list(range(1,len(events)+1)) and all(a['monotonic']<=b['monotonic'] and a['utc_ns']<=b['utc_ns'] for a,b in zip(events,events[1:])),{'event_count':len(events)})
    console=[json.loads(line) for line in (base/'observer-console.txt').read_text().splitlines() if line.startswith('{"sequence"')]
    check(stem+' raw console equals flushed event stream',console==events,'Raw console includes every JSON event in the same order.')
    check(stem+' execution result',result['pass'] is True and (base/'observer-exit-code.txt').read_text().strip()=='0' and not any(x['kind']=='CASE_FAILED' for x in events),result)
    app,service,spectator=baseline['app'],baseline['service'],baseline['spectator']
    check(stem+' exact service ownership',app['executable']==config['artifacts']['app']['path'] and service['executable']==config['artifacts']['service']['path'] and service['ppid']==app['pid'] and service['pgid']==service['pid'] and service['start_seconds']>=app['start_seconds'] and app['start_microseconds']>=0 and service['start_microseconds']>=0 and len({app['pid'],service['pid'],spectator['pid']})==3,baseline)
    listener_records=[]
    for p in sorted((base/'proof').glob('listener-*.command.json')):
        invocation=read(p)
        completion=read(p.with_suffix('.result.json'))
        stdout=p.with_name(p.name.replace('.command.json','.stdout'))
        lines=stdout.read_text().splitlines()
        listener_records.append({'invocation':invocation,'result':completion,'stdout':lines})
        check(stem+' '+p.name+' lsof receipt',invocation['argv']==['/usr/sbin/lsof','-nP','-a','-p',str(service['pid']),'-iTCP','-sTCP:LISTEN','-F','pn'] and invocation['monotonic_before']<=completion['monotonic_after'] and completion['returncode'] in [0,1],completion)
    success=[r for r in listener_records if r['result']['returncode']==0]
    check(stem+' exclusive IPv4 listener',len(success)==1 and success[0]['stdout']==['p'+str(service['pid']),'n127.0.0.1:'+str(baseline['port'])],{'receipts':len(listener_records),'success':success})
    check(stem+' spectator remains through final assertion',result['spectator_unchanged'] is True and events[-1]['kind']=='FINALLY_OWNED_CHILD_RELEASE' and events[-1]['data']['pid']==spectator['pid'],'Owned spectator is released only after the case result event.')
    if config['operation']=='owned-force':
        force=next(x['data'] for x in events if x['kind']=='FORCE_PARENT_RESULT')
        last=force['observations'][-1]
        check(stem+' owned launch authority',any(x['kind']=='BEFORE_OWNED_APP_LAUNCH' and x['data']['argv']==[app['executable']] for x in events) and '--observe-app-pid' not in events[0]['data']['argv'] and force['app_identity']==app and force['service_identity']==service,'Only the helper-owned Popen child is signalled; no observed PID force path.')
        check(stem+' complete bounded force interval',force['parent_wait_included'] is True and force['parent_exit_code']==-9 and force['before_signal_monotonic']<=force['after_signal_monotonic']<=force['parent_wait_started']<=force['parent_wait_finished']<=last['monotonic'] and abs((last['monotonic']-force['before_signal_monotonic'])*1000-force['elapsed_ms'])<1 and force['elapsed_ms']<=force['declared_bound_seconds']*1000==12000 and all(last[k] is True for k in ['app_pid_absent','service_pid_absent','service_group_absent','listener_closed']),force)
    else:
        final=next(x['data'] for x in events if x['kind']=='FINAL_OBSERVATION')
        arms=[x for x in events if x['kind']=='GUI_ACTION_ARMED']
        check(stem+' final actual absence',final==result and all(final['final'].values()) and final['worker_absent'] is True and final['parent_wait_included'] is False and len(arms)>=1,final)
        for p in sorted(base.glob('root-*-action-upfront.json')):
            a=read(p); b=read(p.with_name(p.name.replace('-upfront','-result')))
            check(stem+' '+p.name+' native action',all(b[k]==v for k,v in a.items()) and b['observedAppPid']==app['pid'] and b['actionReturned']=='completed' and b['completedUtc']>=b['requestedUtc'],{'action':b['action'],'element':b['element']})
    if config['scope']!='canonical':
        marker=Path(config['fixture_marker'])
        recipe=read(marker.parent/'fixture-recipe.json')
        marked=read(marker)
        retain(marker.with_suffix('.release'))
        worker=baseline['worker']
        check(stem+' actual fixture worker identity',marked['identity']==worker and marked['nonce']==config['fixture_nonce']==recipe['nonce'] and sha(marker.parent/'fixture-recipe.json')==config['fixture_recipe_sha256'] and worker['ppid']==service['pid'] and worker['executable']==service['executable'] and (worker['pgid']==service['pgid'] if config['scope']=='contained' else worker['pgid']==worker['pid']),marked)
        if config['scope']=='escaped':
            exit_record=read(marker.with_suffix('.exit.json'))
            release=next(x for x in events if x['kind']=='OWNED_FIXTURE_RELEASE_SENT')
            before_release=[x['data'] for x in events if x['kind']=='OBSERVATION' and x['monotonic']<release['monotonic']]
            check(stem+' finite failure keeps UI and only escaped writer',len(before_release)==2 and all(x['app_pid_absent'] is False and x['service_pid_absent'] is True and x['service_group_absent'] is True and x['listener_closed'] is True and x['worker_present'] is True and x['spectator_unchanged'] is True for x in before_release) and 'Could not stop local service; retry Quit' in (base/'root-cleanup-failure-ax.txt').read_text(),'Both snapshots precede the nonce-bound release; UI error PNG inspected separately.')
            check(stem+' explicit release and retry rather than fallback TTL',exit_record['nonce']==config['fixture_nonce'] and exit_record['pid']==worker['pid'] and exit_record['reason']=='owned_observer_release' and release['monotonic']<=exit_record['monotonic']<release['monotonic']+2 and result['escaped_explicit_release_proven'] is True and [x['data']['command'] for x in events if x['kind']=='GUI_ACTION_ARMED']==['arm-close','arm-retry'] and exit_record['monotonic']-events[0]['monotonic']<120,exit_record)
    cases[stem]={'base':str(base),'config':config,'baseline':baseline,'result':result}

def normalized(d):return {k:{'sha256':v['sha256'],'bytes':v['bytes']} for k,v in d.items()}
for label,meta,appbase,upfrontbase,stage in [
 ('canonical',build/'app-tree.json',Path(read(build/'app.json')['path']),build/'app-upfront/Desktop App.app',ROOT/'apps/desktop/src-tauri/runtime-payload'),
 ('contained',Path('/tmp/japp-m03-w03-root-fixture-apps-v3-20261018/contained/app-upfront-tree.json'),Path('/tmp/japp-m03-w03-root-fixture-apps-v3-20261018/contained/cargo-target/debug/bundle/macos/Desktop App.app'),Path('/tmp/japp-m03-w03-root-fixture-apps-v3-20261018/contained/app-upfront/Desktop App.app'),Path('/tmp/japp-m03-w03-root-fixture-apps-v3-20261018/contained/native-build/runtime-stage')),
 ('escaped',Path('/tmp/japp-m03-w03-root-fixture-apps-v3-serial-20261018/escaped/app-upfront-tree.json'),Path('/tmp/japp-m03-w03-root-fixture-apps-v3-serial-20261018/escaped/cargo-target/debug/bundle/macos/Desktop App.app'),Path('/tmp/japp-m03-w03-root-fixture-apps-v3-serial-20261018/escaped/app-upfront/Desktop App.app'),Path('/tmp/japp-m03-w03-root-fixture-apps-v3-serial-20261018/escaped/native-build/runtime-stage')),
]:
    declared=normalized(read(meta))
    actual=file_tree(appbase); pre=file_tree(upfrontbase)
    runtime=file_tree(appbase/'Contents/Resources/runtime')
    staged=file_tree(stage)
    check(label+' whole actual app/upfront equality',actual==pre==declared and len(actual)==42,{'files':len(actual)})
    check(label+' bundle equals full runtime stage',runtime==staged and len(staged)==40,{'files':len(staged)})
    manifest=read(stage/'manifest.json')
    declared_runtime={x['path']:{'sha256':x['sha256'],'bytes':x['bytes']} for x in manifest['files']}
    check(label+' complete manifest file declarations',len(declared_runtime)==39 and declared_runtime=={k:v for k,v in staged.items() if k!='manifest.json'},manifest['source_inputs'])
    (OUT/(label+'-actual-app-tree.json')).write_text(json.dumps(actual,indent=2)+'\n')

quitbase=Path(cases['canonical-quit-v3-20261018']['base'])
unauth=read(quitbase/'proof/unauthorized/result.json')
outer=read(quitbase/'unauthorized-outer-result.json')
response=read(quitbase/'proof/unauthorized/response.body')
check('actual unauthorized HTTP observation binding',unauth['service']==cases['canonical-quit-v3-20261018']['baseline']['service'] and unauth['port']==cases['canonical-quit-v3-20261018']['baseline']['port'] and unauth['owned_identity_unchanged'] is True and outer['exit_code']==0 and outer['source_sha256']==outer['source_sha256_after']==sha(quitbase/'unauthorized-proof-source.py')==sha(quitbase/'proof/unauthorized/executed-source.py') and outer['stdout_sha256']==sha(quitbase/'unauthorized.stdout') and outer['stderr_sha256']==sha(quitbase/'unauthorized.stderr'),unauth)
check('actual raw 401 code and schema-URN rejection',unauth['status']==401 and unauth['authorization']=='ABSENT' and unauth['method']=='GET' and unauth['path']=='/api/v1/health' and unauth['body_sha256']==sha(quitbase/'proof/unauthorized/response.body') and response['payload']['code']=='TRANSPORT_UNAUTHENTICATED' and response['envelope']['schema_id']=='urn:japp:schema:error:record:v1','No authenticated response, HMAC or full-schema validation is inferred.')

ci=Path('/tmp/japp-m03-w03-hosted-ci-cac56-20261018')
ci_run=read(ci/'run.json'); jobs=read(ci/'jobs.json'); checkout=read(ci/'actual-checkout-commit.json')
retain(ci/'windows-complete-raw.txt')
check('actual hosted CI gap remains explicit',ci_run['head_sha']==HEAD and ci_run['conclusion']=='failure' and checkout['tree']['sha']==TREE and [(j['name'],j['conclusion']) for j in jobs['jobs']]==[('doctor + verify (ubuntu-24.04)','success'),('doctor + verify (windows-2025)','failure'),('doctor + verify (macos-15)','success')],{'run':ci_run['id'],'actual_checkout':checkout['sha'],'tree':checkout['tree']['sha']})

root_after={'head':git('rev-parse','HEAD').decode().strip(), 'tree':git('rev-parse','HEAD^{tree}').decode().strip(), 'status':git('status','--porcelain=v1').decode()}
check('review source neutrality',root_before==root_after and all(sha(ROOT/p)==h for p,h in tracked.items()),root_after)
(OUT/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
(OUT/'case-summary.json').write_text(json.dumps(cases,indent=2)+'\n')
(OUT/'input-retention.json').write_text(json.dumps({'scope':'READ_ONLY_REVIEW_INPUTS; large original executed artifacts hash-bound in place, small receipts copied','records':list(inputs.values())},indent=2)+'\n')
print(json.dumps({'checks':len(checks),'clear':sum(x['pass'] for x in checks),'failed':[x['name'] for x in checks if not x['pass']],'input_bindings':len(inputs),'root_before':root_before,'root_after':root_after}))
