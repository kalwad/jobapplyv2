import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/Users/tanishkalwad/jobapplyv2')
OUT = Path('/tmp/japp-m03-w03-root-app-build-v3-20261018')
OUT.mkdir(exist_ok=False)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def tracked():
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).split(b'\0')
    return {os.fsdecode(n): digest(ROOT / os.fsdecode(n)) for n in names if n}

def tree(base):
    result = {}
    for p in sorted(base.rglob('*')):
        relative = p.relative_to(base).as_posix()
        if p.is_symlink():
            result[relative] = {'kind': 'symlink', 'target': os.readlink(p)}
        elif p.is_file():
            result[relative] = {'kind': 'file', 'bytes': p.stat().st_size, 'sha256': digest(p)}
    return result

assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT) == b''
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
source_tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip()
before = tracked()
write('tracked-before.json', before)
stage = ROOT / 'apps/desktop/src-tauri/runtime-payload'
stage_before = tree(stage)
write('runtime-stage-before.json', stage_before)
overlay = OUT / 'local-app-build.json'
overlay.write_text(json.dumps({'bundle': {'active': True}}, indent=2) + '\n')
env = {key: os.environ[key] for key in ['HOME', 'USER', 'LOGNAME', 'TMPDIR', 'LANG', 'LC_ALL'] if key in os.environ}
env['PATH'] = '/opt/homebrew/opt/node@24/bin:' + os.environ['PATH']
argv = ['pnpm', '--filter', '@japp/desktop', 'exec', 'tauri', 'build', '--debug', '--bundles', 'app', '--config', str(overlay), '--ci', '--', '--locked', '--offline']
record = {'source_commit': head, 'source_tree': source_tree, 'argv': argv, 'cwd': str(ROOT), 'environment': env, 'overlay_sha256': digest(overlay), 'observer_source_sha256': digest(Path(__file__)), 'interpreter': os.path.realpath(os.sys.executable), 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'scope': 'Actual local debug .app build for W03 lifecycle proof; no platform/signing/release certification.'}
write('invocation.json', record)
(OUT / 'executed-wrapper.py').write_bytes(Path(__file__).read_bytes())
started = time.monotonic()
with (OUT / 'stdout-stderr.log').open('wb') as log:
    process = subprocess.run(argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, check=False)
record.update({'exit_code': process.returncode, 'ended_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'elapsed_seconds': time.monotonic() - started})
write('invocation.json', record)
after = tracked()
write('tracked-after.json', after)
write('runtime-stage-after.json', tree(stage))
neutrality = {'tracked_unchanged': before == after, 'stage_unchanged': stage_before == tree(stage), 'git_status': subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)}
write('neutrality.json', neutrality)
descriptors = ROOT / 'apps/desktop/src-tauri/target/debug/build'
copied = []
for source in descriptors.glob('japp-desktop-*/out/*'):
    if source.is_file() and 'runtime' in source.name:
        destination = OUT / 'descriptors' / source.parent.parent.name / source.name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(source.read_bytes())
        copied.append({'source': str(source), 'retained': str(destination), 'sha256': digest(source)})
write('generated-descriptors.json', copied)
app = ROOT / 'apps/desktop/src-tauri/target/debug/bundle/macos/Desktop App.app'
if app.is_dir():
    write('app-tree.json', tree(app))
    write('app.json', {'path': str(app), 'main_executable': str(app / 'Contents/MacOS/japp-desktop'), 'main_sha256': digest(app / 'Contents/MacOS/japp-desktop')})
assert neutrality['tracked_unchanged'] and neutrality['stage_unchanged'] and neutrality['git_status'] == '', neutrality
print(json.dumps(record))
raise SystemExit(process.returncode)
