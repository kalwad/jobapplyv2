from pathlib import Path,PurePosixPath
import datetime,hashlib,io,json,stat,tarfile
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');O=E/'m03-w07-portable-sdk-path-evidence-v1';O.mkdir(exist_ok=False)
def pin(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode);b=p.read_bytes();return {'bytes':len(b),'mode':stat.S_IMODE(s.st_mode),'sha256':hashlib.sha256(b).hexdigest()}
def dump(n,v):(O/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
files={'packet-builder-executed.py':Path(__file__)}
for name,p in [('failed-full',E/'full-07eb77b'),('failed-full-independent-review',E/'full-07eb77b-independent-review'),('path-correction',E/'portable-msvc-path-fix-v1'),('path-independent-review',E/'portable-msvc-path-fix-review-v1')]:
 for f in sorted(p.rglob('*')):
  s=f.lstat()
  if stat.S_ISDIR(s.st_mode):continue
  assert stat.S_ISREG(s.st_mode);files[name+'/'+f.relative_to(p).as_posix()]=f
for n in ['immutable-git-source-sha256.json','immutable-source-api-join.json','head-commit.json','head-tree.json']:
 files['immutable-source/'+n]=E/'ci-07eb77b'/n
rows=[]
with tarfile.open(O/'proof.tar.gz','w:gz',format=tarfile.PAX_FORMAT) as ar:
 for n,p in sorted(files.items()):
  rel=PurePosixPath(n);assert not rel.is_absolute() and '..' not in rel.parts
  r=pin(p);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'];t=tarfile.TarInfo(n);t.size=len(b);t.mode=r['mode'];t.mtime=0;t.uid=t.gid=0;ar.addfile(t,io.BytesIO(b));assert pin(p)==r;rows.append({'path':n,'source_path':str(p),**r})
with tarfile.open(O/'proof.tar.gz','r:gz') as ar:
 ms=ar.getmembers();assert len(ms)==len(rows)
 for m,r in zip(ms,rows,strict=True):
  assert m.isfile() and m.name==r['path'] and m.mode==r['mode'];b=ar.extractfile(m).read();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
dump('retention-manifest.json',{'scope':'EXACT_SELECTED_ORIGINAL_BYTES_FULLMODES_SAFE_REGULAR_MEMBERS_NO_RUNTIME_PAYLOAD_OR_ALL_GIT_BODIES_INCLUDED','safe_regular_members':len(rows),'uncompressed_bytes':sum(r['bytes'] for r in rows),'members':rows})
dump('artifact.json',{'path':'proof.tar.gz',**pin(O/'proof.tar.gz')})
dump('summary.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'failed_full':{'head':'07eb77bd4dde2cd41e867cc7512bae28f1a721b8','tree':'eadbd0d66cacc8561c4a3925b8aed907f5f7f8fd','doctor_exit_code':0,'doctor_seconds':6.3361471249954775,'verify_exit_code':1,'verify_seconds':1180.4195218330715,'active_suite_passes':18,'active_suite_failures':2,'actual_python_passes':2140,'actual_python_failures':1,'source_files':2182,'runtime_files':40,'source_runtime_bytes_modes_equal':True,'clean_status_endpoints':True,'head_tree_end_observation_equal':True,'independent_joins':2269,'independent_report_sha256':'75fb7881f27fd43130fa2acf153e8bf415a80682db507c8b5184ba20561f0343'},'correction':{'source_sha256':'a6c913cd5df90a4bfa4cced37b75a0a4ef1fe14c2624ea77e61d3310270d9dd3','changed_product_files':1,'checkers_tests_inventory_changed':False,'focused_cases_passed':13,'focus_seconds':0.73,'strict_commands_passed':3,'extra_wrong_interpreter_cli_exit_code':2,'correct_offline_uv_cli_exit_code':0,'correct_cli_seconds':0.7180827090051025,'independent_joins':65,'independent_report_sha256':'3322e814901ffdd2e365d9b53bb69bed4b410d6b0ff48016b5430ac4aae53238','fresh_full_or_foreign_validation':False},'milestone_or_release_credit':False})
(O/'README.md').write_text('''# Recorded full failure and portable SDK path correction

Clean07eb77b doctor passes28 checks; the complete aggregate actually ends18PASS/2FAIL. Python reports2140PASS/1FAIL391.89s and portability independently rejects the same new /bin/Hostx64/x64/dumpbin.exe f-string fragment under PORT-SRC-001. All other18 suites pass, including4006 fresh TypeScript cases, browser278/2/62/17 and342 native cases in each of3 modes. Both outer children are reaped/groups absent/no signals, all2182 source and40 runtime bytes/full modes match at endpoints, both Git statuses are clean and immediate endingHEAD/tree equal the starting pointers. Different2269-join review clears the record as a FAILURE.

The one-expression correction composes the same SDK path through individual pathlib segments. No checker, test oracle or inventory changes. Three strict checks,13 unchanged focused cases and the existing offline-uv portability CLI pass; different65-join source/data review clears that limited correction. A first extra CLI used the wrongly isolated interpreter and exited2 because PyYAML was unavailable; its exact raw failure remains distinct, followed by the separate correct invocation. No earlier command was relabeled.

This archive preserves selected source maps, original exact raw output/closures, all33 browser visual files, correction before/after/test bodies and both independent reviews in original bytes and full modes. There are29 unique visual bodies among19PNG+14metadata; all19PNG match earlier9872 captures. The visual retention record was sealed while the aggregate was still running and remains historical; later closure records the actual failure. Immutable Git body hashes/API/tree records bind the tested source; full2182 Git bodies and40 runtime payload bodies are not included here. No native GUI/certification or fresh full/hosted validation of the correction, work-package acceptance or release readiness is claimed.
''')
print(json.dumps({'members':len(rows),'proof':pin(O/'proof.tar.gz')}))
