"""Read-only closed-full data review; no subject imports, execution or current-tree assertion."""
from pathlib import Path
import collections, hashlib, json, re, shlex, subprocess
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');B=E/'full-07eb77b';O=Path(__file__).parent
load=lambda n:json.loads((B/n).read_bytes())
immutable=json.loads((E/'ci-07eb77b-immutable-git-source-sha256.json').read_bytes())
old=json.loads((E/'ci-9872aca/immutable-git-source-sha256.json').read_bytes())
context=load('context.json');end=load('end-context.json');before=load('before.json');after=load('after.json');closure=load('closure.json');results=load('results.json');checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def check(name,value,detail=None):checks.append({'name':name,'pass':bool(value),'detail':detail})
check('exact starting and ending07eb head/tree receipts',context['commit']==end['commit']==immutable['commit']=='07eb77bd4dde2cd41e867cc7512bae28f1a721b8' and context['tree']==end['tree']==immutable['tree']=='eadbd0d66cacc8561c4a3925b8aed907f5f7f8fd')
check('all2182 source full-mode endpoints exact',len(before['source'])==len(after['source'])==2182 and before['source']==after['source'])
check('all40 runtime full-mode endpoints exact',len(before['runtime'])==len(after['runtime'])==40 and before['runtime']==after['runtime'])
check('both clean status endpoints',before['git_status']==after['git_status']=='')
check('source membership exact immutable map',set(before['source'])==set(immutable['files']))
for path,row in before['source'].items():
    pin=immutable['files'][path]
    check('immutable source body '+path,row['bytes']==pin['bytes'] and row['sha256']==pin['sha256'] and bool(row['mode']&0o111)==(pin['git_mode']=='100755'))
mac=json.loads((E/'mac-package-refreshed/app-build-after.json').read_bytes())
check('runtime endpoint exact retained reviewed baseline',before['runtime']==mac['runtime'])
check('closure truthfully marks failure and equal endpoints/endcontext',closure['source_count']==2182 and closure['runtime_count']==40 and closure['source_bytes_modes_unchanged'] and closure['runtime_bytes_modes_unchanged'] and closure['commit_and_tree_equal_at_end_observation'] and not closure['all_commands_exit_zero'])
check('exact actual doctor/verify argv and exit0/1',[r['argv']for r in results]==[['pnpm','run','doctor'],['pnpm','verify']]and[r['exit_code']for r in results]==[0,1])
for row in results:
    check('natural closed owned '+row['name'],not row['timeout']and row['direct_child_reaped']and row['observed_group']=='ABSENT'and row['outer_cleanup_signals']==[]and row['seconds']>0)
check('exact elapsed records',results[0]['seconds']==6.3361471249954775 and results[1]['seconds']==1180.4195218330715)
doctor=(B/'doctor.log').read_text();log=(B/'verify.log').read_text();commands=re.findall(r'^\$ (.*)$',log,re.M)
check('doctor28 actualPASS','summary: 28 pass, 0 warning, 0 fail, 0 not-yet-applicable'in doctor)
section=log.split('== verification summary ==\n')[-1];rows=re.findall(r'^(\S+)[ \t]+ACTIVE[ \t]+(PASS|FAIL)[ \t]*(.*)$',section,re.M)
check('exact18PASS2FAIL actualsummary',len(rows)==len({r[0]for r in rows})==20 and {r[0]for r in rows if r[1]=='FAIL'}=={'python','portability'}and sum(r[1]=='PASS'for r in rows)==18 and'verification exit code: 1'in section)
# Data-only Git reads supply the tested inventory/literal; never import the verifier or test code.
def blob(path):
    pin=immutable['files'][path];body=subprocess.check_output(['git','cat-file','blob',pin['git_blob']],cwd='/Users/tanishkalwad/jobapplyv2');check('selected immutable Git blob '+path,len(body)==pin['bytes']and sha(body)==pin['sha256']);return body
inventory_body=blob('scripts/python-test-inventory.v1.json');inventory=json.loads(inventory_body);(O/'tested-python-inventory.json').write_bytes(inventory_body)
common=inventory['common']['node_ids'];expected=tuple(sorted(common+inventory['posix_only_node_ids']));digest=sha(('\n'.join(expected)+'\n').encode());relatives=tuple(sorted({i.split('::',1)[0]for i in expected}))
check('tested committed2139common plus2POSIX IDs',inventory['common']['count']==len(common)==2139 and sha(('\n'.join(common)+'\n').encode())==inventory['common']['sha256']and len(expected)==len(set(expected))==2141)
prefix=('uv','run','pytest','-c','pyproject.toml','--rootdir=.','--confcutdir=.','-o','addopts=','-ra','--strict-markers','--strict-config','--disable-plugin-autoload')
py=[c for c in commands if c.startswith('uv run pytest ')]
check('exact real collection and execution argv',len(py)==2 and tuple(shlex.split(py[0]))==prefix+('--collect-only','-q')+relatives and tuple(shlex.split(py[1]))==prefix+relatives)
collection=log.split('$ '+py[0]+'\n')[1].split('\n$ ')[0];ids=[line.strip()for line in collection.splitlines()if line.split('::',1)[0]in relatives]
check('actual collection exact2141 distinct committed IDs/digest',len(ids)==len(set(ids))==2141 and tuple(sorted(ids))==expected and sha(('\n'.join(sorted(ids))+'\n').encode())==digest)
execution=log.split('$ '+py[1]+'\n')[1].split('\n$ ')[0]
check('actual2140ordinaryPASS1FAIL391.89 summary',re.search(r'^=+ 1 failed, 2140 passed in 391\.89s \(0:06:31\) =+$',execution,re.M)is not None)
failed=re.findall(r'^FAILED (\S+)',execution,re.M)
check('sole actual failed identity unchanged policy oracle',failed==['scripts/tests/test_portability.py::test_real_repository_passes_the_policy'])
fragment="hard-coded POSIX system path '/bin' in runtime literal '/bin/Hostx64/x64/dumpbin.exe'; use tempfile/pathlib or isolate it in a platform-specific module with a tested per-platform equivalent"
check('exact standalone portability refusal fragment',"FAIL: PORT-SRC-001 [scripts/native_package_ci.py]: "+fragment in log)
script=blob('scripts/native_package_ci.py');check('tested SDK construction contains exact offending fragment',b'/bin/Hostx64/x64/dumpbin.exe'in script)
for path in ['scripts/check_portability.py','scripts/tests/test_portability.py','scripts/verify.py']:
    check('unchanged oracle from validated9872 '+path,immutable['files'][path]==old['files'][path])
check('unchanged reviewed negative metadata fixture',before['source']['services/orchestrator/tests/test_runtime_metadata.py']['sha256']=='50b5e27e4076a60012e17f57f4b0b8a2f3a8777da87665f6436a9eecdd771add')
unit=log.split('$ pnpm exec turbo run test --force --concurrency=2 -- --reporter=default\n')[1].split('$ pnpm generate:contracts --check')[0];counts=re.findall(r'^(@japp/[^:]+):test:\s+Tests\s+(\d+) passed \(\d+\)',unit,re.M)
check('actual15 fresh TS tasks4006',len(counts)==len(dict(counts))==15 and sum(int(c)for _,c in counts)==4006 and'Tasks:    15 successful, 15 total'in unit and'Cached:    0 cached, 15 total'in unit and'cache hit'not in unit)
check('ordinary browser278/public2/contact62/visual17 summaries',all(re.search(r'^  '+str(n)+r' passed \(',log,re.M)for n in [278,2,62,17]))
for command,count in [('cargo test --manifest-path services/native-host/Cargo.toml',1),('cargo test --locked --offline --manifest-path packages/contracts/test/contract/rust-harness/Cargo.toml',10)]:
    piece=log.split('$ '+command+'\n')[1].split('\n$ ')[0]
    check('separate native unit/contract ordinary '+str(count),f'test result: ok. {count} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;'in piece)
native=[]
for suffix in ['',' --all-features',' --features tauri/custom-protocol']:
    command='cargo test --locked --manifest-path apps/desktop/src-tauri/Cargo.toml'+suffix;start=log.index('$ '+command+'\n');finish=log.find('\n$ ',start+len(command));piece=log[start:finish if finish!=-1 else None];names=re.findall(r'^test (\S+) \.\.\. ok$',piece,re.M);identity=sha(('\n'.join(sorted(names))+'\n').encode())
    check('actual342 unique native IDs '+(suffix or'default'),len(names)==len(set(names))==342 and'test result: ok. 342 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;'in piece)
    native.append({'argv':shlex.split(command),'passed':342,'names':names,'names_sha256':identity})
check('three native actualID sets equal',len({n['names_sha256']for n in native})==1)
retention_body=(B/'retained-visual/retention.json').read_bytes();visual=json.loads(retention_body);vf=visual['files'];prior=json.loads((E/'full-9872aca/retained-visual/retention.json').read_bytes());priorrows={r['path']:r for r in prior['files']};kinds=collections.Counter(Path(r['path']).suffix for r in vf);bodycounts=collections.Counter(r['sha256']for r in vf)
check('exact visual retention hash and33files/29bodies',sha(retention_body)=='1fde9dcd86c7603dab472f399544f719f9e55781f8a0ec5c87e44c98a9cdace4'and len(vf)==33 and kinds=={'.png':19,'.json':14}and len(bodycounts)==29 and sum(n==2 for n in bodycounts.values())==4)
for row in vf:
    p=B/'retained-visual'/row['path'];body=p.read_bytes();check('retained visual '+row['path'],p.is_file()and not p.is_symlink()and len(body)==row['bytes']and sha(body)==row['sha256'])
    if p.suffix=='.png':check('PNG signature and prior9872 equalbytes '+row['path'],body.startswith(b'\x89PNG\r\n\x1a\n')and priorrows[row['path']]['sha256']==row['sha256']and(E/'full-9872aca/retained-visual'/row['path']).read_bytes()==body)
report={'scope':'INDEPENDENT_RECORDED_LOCAL_FULL07EB_FAILURE_NO_LATER_FIX_CREDIT','verdict':'CLEAR_AS_RECORDED18PASS2FAIL','checks':checks,'passed_checks':sum(c['pass']for c in checks),'total_checks':len(checks),'commit':context['commit'],'tree':context['tree'],'start_context':context,'end_context':end,'closure':closure,'actual_results':results,'aggregate_suites':[{'suite':r[0],'result':r[1]}for r in rows],'python_collection_argv':shlex.split(py[0]),'python_execution_argv':shlex.split(py[1]),'python_collection_ids':list(expected),'python_inventory_digest':digest,'actual_python_passed':2140,'actual_python_failed':failed,'python_seconds':391.89,'portability_refusal_fragment':fragment,'unit_package_counts':{k:int(v)for k,v in counts},'native_modes':native,'visual_files':33,'visual_unique_bodies':29,'source_files':2182,'runtime_files':40,'no_subject_imports_or_execution':True,'canonical_writes':0,'limits':['Later one-line SDK construction correction receives no credit from this failed immutable07eb run','Current dirty canonical tree is not asserted equal to the tested snapshot','Endpoint equality does not prove every intermediate source state','Browser visual comparisons do not grant nativeGUI/final visual approval','Current hostedCI remains separate pending evidence; no foreign desktop/package/milestone/release acceptance']}
(O/'actual-data-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'passed':report['passed_checks'],'total':len(checks),'failures':[x['name']for x in checks if not x['pass']],'python_inventory_digest':digest},indent=2));assert all(x['pass']for x in checks)
