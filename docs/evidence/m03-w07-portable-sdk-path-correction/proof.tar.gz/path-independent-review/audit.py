"""Sealed one-expression source/data audit; no subject import or execution."""
from pathlib import Path, PureWindowsPath
import ast, hashlib, json, stat
E=Path('/Users/tanishkalwad/jobapplyv2-evidence/resume-20261028');B=E/'portable-msvc-path-fix-v1';O=Path(__file__).parent;checks=[]
load=lambda n:json.loads((B/n).read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
def check(name,value):checks.append({'name':name,'pass':bool(value)})
source=load('SOURCE.json');immutable=json.loads((E/'ci-07eb77b-immutable-git-source-sha256.json').read_bytes())
check('exact sealed SOURCE',sha((B/'SOURCE.json').read_bytes())=='a6c913cd5df90a4bfa4cced37b75a0a4ef1fe14c2624ea77e61d3310270d9dd3')
check('30 sealed safe regular records',len(source['files'])==30)
for row in source['files']:
    p=B/row['path'];s=p.lstat();check('sealed '+row['path'],stat.S_ISREG(s.st_mode)and not p.is_symlink()and s.st_size==row['bytes']and stat.S_IMODE(s.st_mode)==row['mode']and sha(p.read_bytes())==row['sha256'])
before=(B/'native_package_ci.before.py').read_bytes();after=(B/'native_package_ci.after.py').read_bytes()
check('before exact tested immutable07eb and after declaredpin',sha(before)==immutable['files']['scripts/native_package_ci.py']['sha256']=='3386e7a867775ffbbb07f9b9171e1b62266288da3079dec0089cb72e7b032e79'and sha(after)=='fe74d90b7db46b1a7f61c9878994eb6afa56fe6f75e0b1aa2553d49f441c4c9d')
old=b'    image = installation / f"VC/Tools/MSVC/{version}/bin/Hostx64/x64/dumpbin.exe"\n'
new=b'    image = (\n        installation\n        / "VC"\n        / "Tools"\n        / "MSVC"\n        / version\n        / "bin"\n        / "Hostx64"\n        / "x64"\n        / "dumpbin.exe"\n    )\n'
check('only exact path expression text changed',before.count(old)==1 and before.replace(old,new,1)==after)
trees=[ast.parse(b)for b in(before,after)]
for tree in trees:
    function=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='declared_dumpbin')
    assignments=[n for n in ast.walk(function)if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='image'for t in n.targets)]
    check('one image assignment in declared_dumpbin',len(assignments)==1)
    assignments[0].value=ast.Constant(value='REVIEW_ONLY_EXPRESSION_PLACEHOLDER')
check('entire other AST unchanged',ast.dump(trees[0],include_attributes=False)==ast.dump(trees[1],include_attributes=False))
for version in ['14.29.30133','14.44.35207','14.51.36231']:
    installation=PureWindowsPath('C:/Program Files/Visual Studio 应用')
    check('stdlib data-only Windows path equivalence '+version,installation/f'VC/Tools/MSVC/{version}/bin/Hostx64/x64/dumpbin.exe'==installation/'VC'/'Tools'/'MSVC'/version/'bin'/'Hostx64'/'x64'/'dumpbin.exe')
for part,expectedcodes in [('quality',[0,0,0,0,2]),('quality-v2',[0])]:
    start=load(part+'/before.json');finish=load(part+'/after.json');closure=load(part+'/closure.json');rows=load(part+'/results.json')
    check('equal2182 full-mode/status/head/tree endpoints '+part,start==finish and len(start['files'])==closure['tracked_files']==2182 and closure['source_bytes_fullmodes_status_head_tree_equal'])
    check('exact base HEAD/tree and sole dirty source '+part,start['head']==immutable['commit']and start['tree']==immutable['tree']and start['status']==' M scripts/native_package_ci.py\n')
    check('all source bodies match tested map except exact afterimage '+part,set(start['files'])==set(immutable['files'])and all(row['sha256']==(sha(after)if path=='scripts/native_package_ci.py'else immutable['files'][path]['sha256'])and row['bytes']==(len(after)if path=='scripts/native_package_ci.py'else immutable['files'][path]['bytes'])and bool(row['mode']&0o111)==(immutable['files'][path]['git_mode']=='100755')for path,row in start['files'].items()))
    check('actual exact exit sequence '+part,[r['exit_code']for r in rows]==expectedcodes)
    for i,row in enumerate(rows):
        check('closed bounded owned '+part+'/'+str(i+1),not row['timeout']and row['signals']==[]and row['reaped']and row['group']=='ABSENT'and 0<row['seconds']<180)
    check('copied executed wrapper '+part,(B/part/'executed-wrapper.py').read_bytes()==(B/('run_quality.py'if part=='quality'else'run_portability_v2.py')).read_bytes())
    if part=='quality':check('first sequence does not relabel allfivePASS',not closure['all_five_commands_closed_zero'])
    else:check('separate v2 correct CLI actualPASS',closure['all_one_command_closed_zero']and rows[0]['argv']==['uv','run','--no-sync','--offline','python','scripts/check_portability.py','--quiet'])
q=load('quality/results.json');v=load('quality-v2/results.json')
check('strict Ruff check/format/Mypy exact commands',[r['argv']for r in q[:3]]==[['uv','run','--no-sync','--offline','ruff','check','--config','pyproject.toml','scripts/native_package_ci.py'],['uv','run','--no-sync','--offline','ruff','format','--check','--config','pyproject.toml','scripts/native_package_ci.py'],['uv','run','--no-sync','--offline','mypy','--config-file','pyproject.toml','scripts/native_package_ci.py']])
check('unchanged13-case exact selectors',q[3]['argv'][-2:]==['scripts/tests/test_native_sdk_discovery.py','scripts/tests/test_portability.py::test_real_repository_passes_the_policy']and'--disable-plugin-autoload'in q[3]['argv'])
raw=(B/'quality/04.stdout').read_text();check('actual13ordinaryPASS0.73s','collected 13 items'in raw and'scripts/tests/test_native_sdk_discovery.py ............'in raw and'13 passed in 0.73s'in raw)
check('first CLI observer dependency refusal explicit',q[4]['argv']==['python3','-I','-B','scripts/check_portability.py','--quiet']and b"PyYAML unavailable (No module named 'yaml')"in(B/'quality/05.stderr').read_bytes())
check('correct CLI raw pass and elapsed',b'PASS: portability policy validated'in(B/'quality-v2/01.stdout').read_bytes()and v[0]['seconds']==0.7180827090051025 and not(B/'quality-v2/01.stderr').read_bytes())
for name,path in [('test_native_sdk_discovery.before.py','scripts/tests/test_native_sdk_discovery.py'),('test_portability.before.py','scripts/tests/test_portability.py')]:
    check('preserved test oracle body '+path,sha((B/name).read_bytes())==immutable['files'][path]['sha256'])
report={'scope':'Different source and actual-data review of one SDK path expression; no subject execution/imports','verdict':'CLEAR_FOR_SCOPED_PORTABLE_PATH_CORRECTION_FOCUSED_EVIDENCE_ONLY','checks':checks,'passed':sum(x['pass']for x in checks),'total':len(checks),'before_sha256':sha(before),'after_sha256':sha(after),'original_failed_full_commit':immutable['commit'],'limits':['PureWindowsPath comparison is a data-only semantic model, not actual Windows execution','Original full07eb is18PASS2FAIL and current hostedCI remains separately pending','Actual first CLI exit2 retained as observer-invocation dependency error; separate v2 PASS does not relabel it','No checker/test/inventory/default selection/bounds change','No fresh aggregate, package/nativeGUI, foreign certification, milestone or release claim','Current canonical bodies were not imported/executed or asserted equal by reviewer']}
(O/'checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'passed':report['passed'],'total':len(checks),'failures':[x['name']for x in checks if not x['pass']]}));assert all(x['pass']for x in checks)
